// SPDX-License-Identifier: Apache-2.0
//! Curve namespace prototypes and topology rows.
//!
//! Prototype rows identify curves and their generating features. Topology rows
//! add the two face sides and successor curve for each native half-edge. Curve
//! parameter records decode scalar bodies. Relation evaluation resolves
//! assignments and recognizes exact cylindrical helix programs.

use std::collections::{BTreeMap, BTreeSet};
use std::num::NonZeroU32;

use cadmpeg_core::bytes::{find_from as find, find_in};
use cadmpeg_core::decode::{bounded_len, index_from_u32};

use crate::psb::{self, compact_int, reference_id};
use crate::scalar;

const EPS_RELATION_ROUND: f64 = 1.0e-9;
const EPS_DIMENSION_SOLUTION: f64 = 1.0e-9;
const EPS_LINEAR_SYSTEM_COEFFICIENT: f64 = 1.0e-12;
const EPS_LINEAR_SYSTEM_RESIDUAL: f64 = 1.0e-9;
const EPS_ORDINATE_AGREEMENT: f64 = 1.0e-9;
const EPS_CIRCLE_RESIDUAL: f64 = 1.0e-9;
const EPS_ANGLE_AGREEMENT: f64 = 1.0e-6;
const EPS_RADIUS_AGREEMENT: f64 = 1.0e-9;

/// A labeled curve namespace entry.
///
/// `type_byte` remains raw because the namespace grammar does not define its
/// geometric interpretation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurvePrototype {
    /// The row's `crv_id`: the curve's identifier in the `crv_array`
    /// namespace, referenced by `srf_array` and topology row `E0`/`E1`
    /// fields.
    pub(crate) id: u32,
    /// The row's raw `type` byte. Its geometric meaning is not identified by
    /// the namespace grammar alone ([spec §4](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/creo_prt.md#4-curve-namespace-crv_array)); the curve-body evaluator
    /// determines the interpretation.
    pub(crate) type_byte: u8,
    /// The `feat_id` compact integer, when the labeled row has one: the
    /// feature that generated this curve.
    pub(crate) feature_id: Option<u32>,
    /// The two named-prototype `crv_pnt_dir` orientation flags, when the
    /// prototype carries a complete direction array.
    directions: Option<[u8; 2]>,
    /// Byte offset of this prototype's `crv_array` label in the original
    /// stream.
    pub(crate) offset: usize,
}

/// One source line in a curve-equation expression program.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurveExpressionLine {
    /// UTF-8 source text without its NUL terminator.
    pub(crate) text: String,
    /// Byte offset of the first source byte.
    pub(crate) offset: usize,
}

/// Expression program stored by a curve-from-equation entity.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveExpressionRecord {
    /// Entity identifier from the enclosing record.
    pub(crate) entity_id: u32,
    /// Whether the enclosing record is `backup_ents(crv_fr_eqn)`.
    pub(crate) backup: bool,
    /// Bounded native placement frame carried by the equation entity.
    pub(crate) local_system: Option<CurveExpressionLocalSystem>,
    /// Ordered source lines declared by the `f8` array.
    pub(crate) lines: Vec<CurveExpressionLine>,
    /// Assignment statements in source order.
    pub(crate) assignments: Vec<CurveExpressionAssignment>,
    /// Complete simultaneous-equation blocks in source order.
    pub(crate) solve_blocks: Vec<CurveExpressionSolveBlock>,
    /// Whether a `SOLVE`/`FOR` control sequence is malformed or incomplete.
    pub(crate) unresolved_solve_control: bool,
    /// Curve-equation constructs prohibited by the Creo expression grammar.
    pub(crate) prohibited_constructs: Vec<String>,
    /// Count of conditions and assignments, keyed by the text work cap that
    /// dropped their value.
    pub(crate) text_work_caps: BTreeMap<&'static str, usize>,
    /// Byte offset of the enclosing entity label.
    pub(crate) offset: usize,
    /// Byte offset of the `expression` field.
    pub(crate) expression_offset: usize,
}

/// Count-bounded `local_sys` payload carried by a curve-equation entity.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveExpressionLocalSystem {
    /// Tuple dimensionality from the `f9` wrapper.
    pub(crate) dimensions: u32,
    /// Stored tuple count from the `f9` wrapper.
    pub(crate) count: u32,
    /// Exact stateful scalar body through the next named field.
    pub(crate) body: Vec<u8>,
    /// Twelve explicit scalar slots, absent when the body uses inheritance or
    /// contains a scalar form that is not decoded.
    pub(crate) explicit_slots: Option<cadmpeg_ir::units::FiniteVector<12>>,
    /// Byte offset of the `local_sys` named-record header.
    pub(crate) offset: usize,
}

/// One executable assignment in a curve expression program.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveExpressionAssignment {
    /// Typed relation target receiving the right-hand value.
    pub(crate) target: CurveExpressionTarget,
    /// Exact right-hand expression after surrounding ASCII whitespace removal.
    pub(crate) expression: String,
    /// Referenced identifiers in first-appearance order.
    pub(crate) dependencies: Vec<String>,
    /// Sequentially evaluated value when every dependency is resolved.
    pub(crate) value: Option<CurveExpressionValue>,
    /// Whether the source-ordered conditional program executes this assignment.
    pub(crate) activation: CurveExpressionActivation,
    /// Byte offset of the assignment source line.
    pub(crate) offset: usize,
}

/// One `SOLVE`/`FOR` simultaneous-equation block.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveExpressionSolveBlock {
    /// Ordered equations between the `SOLVE` and `FOR` lines.
    pub(crate) equations: Vec<CurveExpressionEquation>,
    /// Ordered one-way relations in the block that do not involve an unknown.
    pub(crate) assignments: Vec<CurveExpressionAssignment>,
    /// Ordered unknowns declared by the terminating `FOR` line.
    pub(crate) unknowns: Vec<SolveUnknown>,
    /// Byte offset of the `SOLVE` line.
    pub(crate) offset: usize,
    /// Byte offset of the terminating `FOR` line.
    pub(crate) for_offset: usize,
    /// Local work caps that fired while the block stayed unsolved.
    pub(crate) work_caps: BTreeSet<&'static str>,
}

/// One declared solve unknown and its optional solution.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct SolveUnknown {
    /// Declared variable name.
    pub(crate) name: String,
    /// Solved value, absent when the unknown remains unresolved.
    pub(crate) solution: Option<CurveExpressionValue>,
}

/// One equation in a simultaneous-equation block.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurveExpressionEquation {
    /// Exact left-hand expression after surrounding ASCII whitespace removal.
    pub(crate) left: String,
    /// Exact right-hand expression after surrounding ASCII whitespace removal.
    pub(crate) right: String,
    /// Referenced identifiers in first-appearance order across both sides.
    pub(crate) dependencies: Vec<String>,
    /// Byte offset of the equation source line.
    pub(crate) offset: usize,
}

/// Target of one curve-expression assignment.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub(crate) enum CurveExpressionTarget {
    /// Scalar parameter target.
    Parameter {
        /// Assigned identifier.
        name: String,
        /// Unit expression declared on a newly created parameter target.
        declared_unit: Option<String>,
    },
    /// Dimension or parameter qualified by a relation scope.
    ScopedSymbol {
        /// Complete scoped relation identifier.
        name: String,
    },
    /// Unscoped Creo dimension, tolerance, or pattern system symbol.
    SystemSymbol {
        /// Complete system identifier.
        name: String,
        /// Namespace family selected by the identifier prefix.
        family: CurveExpressionSystemSymbolFamily,
    },
    /// Write invocation of a registered relation function.
    FunctionWrite {
        /// Registered function identifier.
        name: String,
        /// Exact argument expressions in source order.
        arguments: Vec<String>,
    },
    /// Cell of a series or list parameter.
    TableCell {
        /// Table-valued parameter identifier.
        parameter: String,
        /// Exact one-based row selector expression.
        row: String,
        /// Exact column selector expression when present.
        column: Option<String>,
    },
}

/// Namespace family of an unscoped Creo relation system symbol.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum CurveExpressionSystemSymbolFamily {
    /// Parent-model or assembly dimension (`d#`).
    Dimension,
    /// Section dimension (`sd#`).
    SectionDimension,
    /// Reference dimension (`rd#`).
    ReferenceDimension,
    /// Section reference dimension (`rsd#`).
    SectionReferenceDimension,
    /// Known parent dimension used in a section (`kd#`).
    KnownDimension,
    /// Driven dimension (`ad#`).
    DrivenDimension,
    /// Pattern instance count (`p#`).
    PatternCount,
    /// Plus, minus, or symmetric tolerance component.
    Tolerance,
}

impl CurveExpressionAssignment {
    pub(crate) fn parameter_target(&self) -> Option<(&str, Option<&str>)> {
        match &self.target {
            CurveExpressionTarget::Parameter {
                name,
                declared_unit,
            } => Some((name, declared_unit.as_deref())),
            CurveExpressionTarget::ScopedSymbol { .. }
            | CurveExpressionTarget::SystemSymbol { .. }
            | CurveExpressionTarget::FunctionWrite { .. }
            | CurveExpressionTarget::TableCell { .. } => None,
        }
    }

    fn scalar_target(&self) -> Option<(&str, Option<&str>)> {
        match &self.target {
            CurveExpressionTarget::Parameter {
                name,
                declared_unit,
            } => Some((name, declared_unit.as_deref())),
            CurveExpressionTarget::ScopedSymbol { name } => Some((name, None)),
            CurveExpressionTarget::SystemSymbol { name, .. } => Some((name, None)),
            CurveExpressionTarget::FunctionWrite { .. } => None,
            CurveExpressionTarget::TableCell { .. } => None,
        }
    }
}

/// A deterministic value produced by a curve relation expression.
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
#[serde(untagged)]
pub(crate) enum CurveExpressionValue {
    /// Dimensionless numeric value.
    Number(cadmpeg_ir::scalar::FiniteReal),
    /// Length in canonical millimeters.
    Length(cadmpeg_ir::scalar::FiniteReal),
    /// Angle in relation degrees.
    Angle(cadmpeg_ir::scalar::FiniteReal),
    /// Quantity whose physical dimension has no dedicated neutral value type.
    Quantity(CurveExpressionQuantity),
    /// UTF-8 string value.
    String(String),
}

impl CurveExpressionValue {
    fn truth(&self) -> Option<bool> {
        match self {
            Self::Number(value) => Some(value.get() != 0.0),
            Self::Length(_) | Self::Angle(_) | Self::Quantity(_) | Self::String(_) => None,
        }
    }
}

/// Canonically scaled relation quantity represented by physical base powers.
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize)]
pub(crate) struct CurveExpressionQuantity {
    value: cadmpeg_ir::scalar::FiniteReal,
    #[serde(flatten)]
    dimension: ResidualRelationDimension,
}

/// Physical powers that have no dedicated relation value variant.
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize)]
struct ResidualRelationDimension {
    #[serde(rename = "length_power")]
    length: i8,
    #[serde(rename = "mass_power")]
    mass: i8,
    #[serde(rename = "time_power")]
    time: i8,
    #[serde(rename = "angle_power")]
    angle: i8,
    #[serde(rename = "temperature_power")]
    temperature: i8,
}

impl ResidualRelationDimension {
    fn new(dimension: RelationDimension) -> Option<Self> {
        if [
            RelationDimension::default(),
            RelationDimension::LENGTH,
            RelationDimension::ANGLE,
        ]
        .contains(&dimension)
        {
            return None;
        }
        Some(Self {
            length: dimension.length,
            mass: dimension.mass,
            time: dimension.time,
            angle: dimension.angle,
            temperature: dimension.temperature,
        })
    }
}

impl CurveExpressionQuantity {
    pub(crate) fn new(value: f64, powers: [i8; 5]) -> Option<Self> {
        let [length, mass, time, angle, temperature] = powers;
        Some(Self {
            value: cadmpeg_ir::scalar::FiniteReal::new(value)?,
            dimension: ResidualRelationDimension::new(RelationDimension {
                length,
                mass,
                time,
                angle,
                temperature,
            })?,
        })
    }

    pub(crate) fn value(self) -> f64 {
        self.value.get()
    }

    pub(crate) fn powers(self) -> [i8; 5] {
        let dimension = self.dimension;
        [
            dimension.length,
            dimension.mass,
            dimension.time,
            dimension.angle,
            dimension.temperature,
        ]
    }

    fn dimension(self) -> RelationDimension {
        let [length, mass, time, angle, temperature] = self.powers();
        RelationDimension {
            length,
            mass,
            time,
            angle,
            temperature,
        }
    }
}

/// Evaluation state of an assignment inside relation conditionals.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum CurveExpressionActivation {
    /// The assignment executes in the current source-ordered evaluation.
    Active,
    /// A resolved enclosing condition excludes the assignment.
    Inactive,
    /// An enclosing condition cannot be evaluated from available scalar values.
    Conditional,
}

impl CurveExpressionActivation {
    pub(crate) const fn token(self) -> &'static str {
        match self {
            Self::Active => "active",
            Self::Inactive => "inactive",
            Self::Conditional => "conditional",
        }
    }
}

/// Exact cylindrical helix parameters from a `crv_fr_eqn` program.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) struct CurveExpressionHelix {
    /// Constant cylindrical radius in model millimeters.
    pub(crate) radius: cadmpeg_ir::scalar::PositiveLength,
    /// Signed axial rise from `t = 0` through `t = 1`.
    pub(crate) height: cadmpeg_ir::scalar::FiniteReal,
    /// Native axial coordinate at `t = 0`.
    pub(crate) z_start: cadmpeg_ir::scalar::FiniteReal,
    /// Positive angular travel in revolutions.
    pub(crate) revolutions: cadmpeg_ir::scalar::PositiveReal,
    /// Angular position at `t = 0`, in radians.
    pub(crate) start_angle: cadmpeg_ir::scalar::Angle,
    /// Whether angular travel decreases as `t` increases.
    pub(crate) clockwise: bool,
}

impl CurveExpressionHelix {
    fn new(
        radius: f64,
        height: f64,
        z_start: f64,
        revolutions: f64,
        start_angle: f64,
        clockwise: bool,
    ) -> Option<Self> {
        Some(Self {
            radius: cadmpeg_ir::scalar::PositiveLength::new(radius)?,
            height: cadmpeg_ir::scalar::FiniteReal::new(height)?,
            z_start: cadmpeg_ir::scalar::FiniteReal::new(z_start)?,
            revolutions: cadmpeg_ir::scalar::PositiveReal::new(revolutions)?,
            start_angle: cadmpeg_ir::scalar::Angle::new(start_angle)?,
            clockwise,
        })
    }
}

/// A curve row with a uniquely delimited topology suffix.
///
/// `faces` and `next_edges` preserve the two native sides in order.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurveTopologyRow {
    /// The row's `crv_id`, matching a [`CurvePrototype::id`] in the same
    /// `crv_array` namespace.
    pub(crate) id: u32,
    /// The row's raw `type` byte; see [`CurvePrototype::type_byte`].
    pub(crate) type_byte: u8,
    /// The `feat_id` compact integer: the feature that generated this
    /// curve.
    pub(crate) feature_id: u32,
    /// The two `crv_pnt_dir` orientation-flag bytes, one per half-edge side.
    /// These are per-side orientation flags, not a tangent vector
    /// ([spec §4](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/creo_prt.md#4-curve-namespace-crv_array)).
    pub(crate) directions: [u8; 2],
    /// The `F0`/`F1` suffix fields: the `srf_array` face identifiers
    /// bounding the curve's two half-edge sides, absent where the side is
    /// unbounded.
    pub(crate) faces: [Option<NonZeroU32>; 2],
    /// The `E0`/`E1` suffix fields: the `crv_array` identifier of the next
    /// edge for each of the two half-edge sides, used to walk loops
    /// ([spec §4](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/creo_prt.md#4-curve-namespace-crv_array)).
    pub(crate) next_edges: [u32; 2],
    /// Byte offset of the row's `crv_id` field in the original stream.
    pub(crate) offset: usize,
}

impl CurveTopologyRow {
    /// The face identifiers bounding the two half-edge sides, in side order,
    /// skipping sides that bound no face.
    pub(crate) fn bounded_face_ids(&self) -> impl Iterator<Item = u32> + '_ {
        self.faces.iter().flatten().map(|face| face.get())
    }

    /// Whether either half-edge side bounds `face_id`.
    pub(crate) fn bounds_face(&self, face_id: u32) -> bool {
        self.bounded_face_ids().any(|bounded| bounded == face_id)
    }

    /// The stored `F0`/`F1` fields, with `0` for a side that bounds no face.
    pub(crate) fn stored_face_ids(&self) -> [u32; 2] {
        self.faces.map(stored_face_reference)
    }
}

impl CurvePrototypeTopology {
    /// The stored `crv_hdr_geom_ptr[0/1]` fields, with `0` for a side that
    /// names no surface.
    pub(crate) fn stored_face_ids(&self) -> [u32; 2] {
        self.faces.map(stored_face_reference)
    }
}

/// One-sided cross-section pointers in stored field order.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct DepdbCurveSuffix {
    section_plane: u32,
    next_curve: u32,
    reference_surface: u32,
}

impl serde::Serialize for DepdbCurveSuffix {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        serde::Serialize::serialize(
            &[
                0,
                self.section_plane,
                0,
                self.next_curve,
                self.reference_surface,
                0,
            ],
            serializer,
        )
    }
}

/// One DEPDB cross-section curve row with its one-sided topology suffix.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct DepdbCurveRow {
    /// Curve identifier in the cross-section `crv_array` namespace.
    pub(crate) id: u32,
    /// Raw curve-family discriminator.
    pub(crate) type_byte: u8,
    /// Owning feature identifier.
    pub(crate) feature_id: u32,
    /// Stored per-side direction flags.
    pub(crate) directions: [u8; 2],
    /// Stored face, successor, and reference-geometry pointer pairs.
    pub(crate) suffix: DepdbCurveSuffix,
    /// Exact bytes between the fixed prefix and one-sided suffix.
    pub(crate) body: Vec<u8>,
    /// Decoded scalar tokens with exact body-relative spans.
    pub(crate) scalar_tokens: Vec<CurveParameterScalar>,
    /// Canonical entity references with exact body-relative spans.
    pub(crate) references: Vec<CurveParameterReference>,
    /// Maximal body spans not claimed by a scalar or reference token.
    pub(crate) opaque_spans: Vec<CurveParameterOpaqueSpan>,
    /// Byte offset of the row identifier.
    pub(crate) offset: usize,
}

/// Bounded analytic parameter body from one positional `crv_array` row.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveParameterRecord {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Raw curve-family discriminator.
    pub(crate) type_byte: u8,
    /// Exact bytes between direction flags and the selected suffix boundary.
    pub(crate) body: Vec<u8>,
    /// Scalar tokens with exact body-relative spans.
    pub(crate) scalar_tokens: Vec<CurveParameterScalar>,
    /// Canonical entity references with exact body-relative spans.
    pub(crate) references: Vec<CurveParameterReference>,
    /// Maximal byte spans not claimed by scalar or reference tokens.
    pub(crate) opaque_spans: Vec<CurveParameterOpaqueSpan>,
    /// Positional `ref_geom[0]` and `ref_geom[1]` values following the four
    /// topology references.
    pub(crate) reference_geometry: [u32; 2],
    /// Byte offset of the positional row in the original stream.
    pub(crate) offset: usize,
    /// Byte offset of the first parameter-body byte in the original stream.
    pub(crate) body_offset: usize,
    /// Byte offset of the selected body/suffix boundary in the original stream.
    pub(crate) suffix_offset: usize,
    /// Only a complete `fc <count>` body selects this row's suffix boundary.
    pub(crate) count_framed: bool,
}

#[cfg(test)]
impl CurveParameterRecord {
    /// Decoded scalar values in byte order.
    pub(crate) fn scalar_values(&self) -> Vec<f64> {
        self.scalar_tokens.iter().map(|token| token.value).collect()
    }

    /// Canonical entity references skipped while walking the scalar lane.
    pub(crate) fn skipped_references(&self) -> Vec<u32> {
        self.references
            .iter()
            .map(|reference| reference.entity_id)
            .collect()
    }
}

/// One decoded scalar token in a positional curve body.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct CurveParameterScalar {
    /// Decoded scalar value.
    pub(crate) value: f64,
    /// Exact token bytes.
    pub(crate) raw: Vec<u8>,
    /// Body-relative token offset.
    pub(crate) offset: usize,
}

/// One canonical entity reference in a positional curve body.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurveParameterReference {
    /// Referenced entity identifier.
    pub(crate) entity_id: u32,
    /// Body-relative reference-token offset, including `f7`.
    pub(crate) offset: usize,
    /// Reference-token length in bytes, including `f7`.
    pub(crate) length: usize,
}

/// One maximal unclaimed byte span in a positional curve body.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurveParameterOpaqueSpan {
    /// Exact unclaimed bytes.
    pub(crate) raw: Vec<u8>,
    /// Body-relative span offset.
    pub(crate) offset: usize,
}

/// Two pcurve endpoints represented in both adjacent face parameter frames.
/// Both reader routes admit finite coordinates before constructing this record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct PcurveEndpoints {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Adjacent face identifiers corresponding to face frames zero and one.
    pub(crate) faces: [Option<NonZeroU32>; 2],
    /// Endpoint A then B in the first face's local UV frame.
    pub(crate) face_0_endpoints: [[f64; 2]; 2],
    /// Endpoint A then B in the second face's local UV frame.
    pub(crate) face_1_endpoints: [[f64; 2]; 2],
    /// Byte offset of the source positional curve row.
    pub(crate) offset: usize,
}

impl PcurveEndpoints {
    /// Stored face identifiers, with zero for an absent face.
    pub(crate) fn stored_face_ids(&self) -> [u32; 2] {
        self.faces.map(stored_face_reference)
    }
}

/// Ordered samples of one curve represented in both incident-face charts.
/// Every stored sample coordinate is finite at reader admission.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct TwoChartPcurveSamples {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Adjacent face identifiers in sample-chart order.
    pub(crate) faces: [u32; 2],
    /// Pointwise-corresponding `[F0(u, v), F1(u, v)]` chart samples.
    pub(crate) samples: Vec<[[f64; 2]; 2]>,
    /// Byte offset of the source positional curve row.
    pub(crate) offset: usize,
}

/// One-sided endpoint path from the complete short fc 02 curve body.
/// Every stored endpoint coordinate is finite at reader admission.
///
/// The body carries one path in the first topology face's parameter chart;
/// the second face remains a carrier-only join. The retained terminal operand
/// is deliberately not interpreted by this record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Fc02ShortPcurveEndpoints {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Adjacent surface identifiers from the topology row.
    pub(crate) faces: [u32; 2],
    /// Endpoint A then B in the first face's parameter frame.
    pub(crate) face_0_endpoints: [[f64; 2]; 2],
    /// Byte offset of the source positional curve row.
    pub(crate) offset: usize,
}

/// Ordered world-coordinate lane from an `fc <subtype>` dense curve body.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct FcCurveCoordinates {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Byte following the `fc` body prefix.
    pub(crate) subtype: u8,
    /// Exact complete curve parameter body, including the `fc` prefix.
    pub(crate) body: Vec<u8>,
    /// Ordered exact world-coordinate values, in mm.
    pub(crate) values_mm: Vec<f64>,
    /// World-coordinate tokens with exact body-relative spans.
    pub(crate) tokens: Vec<FcCurveCoordinateToken>,
    /// Maximal body spans not owned by a recognized coordinate token.
    pub(crate) opaque_spans: Vec<FcCurveOpaqueSpan>,
    /// Byte offset of the source positional curve row.
    pub(crate) offset: usize,
}

/// One recognized world-coordinate token in an `fc <subtype>` body.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct FcCurveCoordinateToken {
    /// Decoded model length in millimeters.
    pub(crate) value_mm: f64,
    /// Exact source bytes occupied by the token.
    pub(crate) raw: cadmpeg_ir::native::bytes::NativeBytes<Vec<u8>>,
    /// Token offset relative to the complete curve parameter body.
    pub(crate) offset: usize,
}

impl serde::Serialize for FcCurveCoordinateToken {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeStruct;
        let mut wire = serializer.serialize_struct("FcCurveCoordinateToken", 4)?;
        wire.serialize_field("value_mm", &self.value_mm)?;
        wire.serialize_field("raw", &self.raw)?;
        wire.serialize_field("offset", &self.offset)?;
        wire.serialize_field("length", &self.raw.len())?;
        wire.end()
    }
}

/// One maximal unclaimed span in an `fc <subtype>` body.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct FcCurveOpaqueSpan {
    /// Exact source bytes in the span.
    raw: cadmpeg_ir::native::bytes::NativeBytes<Vec<u8>>,
    /// Span offset relative to the complete curve parameter body.
    offset: usize,
}

impl serde::Serialize for FcCurveOpaqueSpan {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeStruct;
        let mut wire = serializer.serialize_struct("FcCurveOpaqueSpan", 3)?;
        wire.serialize_field("raw", &self.raw)?;
        wire.serialize_field("offset", &self.offset)?;
        wire.serialize_field("length", &self.raw.len())?;
        wire.end()
    }
}

/// Direction of stored parameters relative to row-frame polar angles.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ParameterSense {
    /// Parameters increase with polar angle.
    Increasing,
    /// Parameters decrease with polar angle.
    Decreasing,
}

impl ParameterSense {
    /// Signed parameter multiplier.
    pub(crate) fn as_i8(self) -> i8 {
        match self {
            Self::Increasing => 1,
            Self::Decreasing => -1,
        }
    }
}

/// Relation between stored circle parameters and row-frame polar angles.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) enum Fc05AngleParameterRelation {
    /// Neither unique parameter sense establishes a reference direction.
    Inconsistent,
    /// A unique parameter sense establishes a reference direction.
    Consistent {
        /// Direction of increasing stored parameters.
        sense: ParameterSense,
        /// Unit radial direction at stored parameter zero.
        reference_direction_row_frame: [f64; 2],
    },
}

/// Circle proven by the decoded points of an `fc 05` curve body.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Fc05Circle {
    /// Owning curve identifier.
    pub(crate) curve_id: u32,
    /// Circle center in the FC row's in-plane coordinate frame.
    pub(crate) center_row_frame: [f64; 2],
    /// Exact radius in mm.
    pub(crate) radius_mm: f64,
    /// Finite radial quotient from the fitted center to the first stored sample.
    pub(crate) sample_direction_row_frame: cadmpeg_ir::units::HypotDirection2,
    /// Stored parameter relation and its reference direction.
    pub(crate) angle_parameter: Fc05AngleParameterRelation,
    /// Constant cap-plane ordinate when present in every point.
    pub(crate) cap_ordinate_row_frame: Option<f64>,
    /// Number of points participating in validation.
    pub(crate) point_count: usize,
    /// Maximum absolute radial residual.
    pub(crate) max_residual: f64,
    /// Byte offset of the source positional curve row.
    pub(crate) offset: usize,
}

/// One circle edge joining a cylinder to a cap plane.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Fc05CapEdge {
    /// Circle curve identifier.
    pub(crate) curve_id: u32,
    /// Opposite cap plane identifier.
    pub(crate) cap_plane_id: u32,
    /// Cap ordinate in the owning feature's row frame.
    pub(crate) cap_ordinate_row_frame: f64,
}

/// Two or more topology-bound `fc 05` cap circles that establish one native
/// cylinder's radius and row-frame axis line, but not its model-space frame.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Fc05CylinderCapPair {
    /// Cylinder surface identifier shared by every cap edge.
    pub(crate) surface_id: u32,
    /// Agreeing cap edges in source order.
    pub(crate) cap_edges: Vec<Fc05CapEdge>,
    /// Shared center in the owning feature's row frame.
    pub(crate) center_row_frame: [f64; 2],
    /// Shared exact radius in mm.
    pub(crate) radius_mm: f64,
    /// Unit radial direction at parameter zero in the row's `(x, z)` frame.
    pub(crate) reference_direction_row_frame: [f64; 2],
    /// Shared signed parameter-to-polar-angle relation.
    pub(crate) parameter_sense: ParameterSense,
    /// At least two distinct cap ordinates in the owning feature's row frame.
    pub(crate) cap_ordinates_row_frame: Vec<f64>,
    /// Byte offset of the first participating curve row.
    pub(crate) offset: usize,
}

/// Complete eight-slot pcurve endpoints from a labeled curve prototype.
/// Every stored endpoint coordinate is finite at reader admission.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct PrototypePcurveEndpoints {
    /// Prototype curve identifier.
    pub(crate) curve_id: u32,
    /// Endpoint A then B in schema face frame zero.
    pub(crate) face_0_endpoints: [[f64; 2]; 2],
    /// Endpoint A then B in schema face frame one.
    pub(crate) face_1_endpoints: [[f64; 2]; 2],
    /// Byte offset of the `crv_pnt_arr` label in the original stream.
    pub(crate) offset: usize,
}

/// Four labeled topology references of a curve prototype.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CurvePrototypeTopology {
    /// Prototype curve identifier.
    pub(crate) curve_id: u32,
    /// Adjacent surface identifiers from `crv_hdr_geom_ptr[0/1]`, absent
    /// where the side names no surface.
    pub(crate) faces: [Option<NonZeroU32>; 2],
    /// Per-face successor curve identifiers from `next_crv_hdr_ptr[0/1]`.
    pub(crate) next_edges: [u32; 2],
    /// Byte offset of the prototype namespace.
    pub(crate) offset: usize,
}

/// Prototype pcurve endpoints bound to their two labeled adjacent faces.
/// Binding preserves the reader's finite endpoint admission.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct BoundPrototypePcurve {
    /// Prototype curve identifier.
    pub(crate) curve_id: u32,
    /// Adjacent face identifiers corresponding to UV frames zero and one.
    pub(crate) faces: [Option<NonZeroU32>; 2],
    /// Endpoint A then B in the first face's UV frame.
    pub(crate) face_0_endpoints: [[f64; 2]; 2],
    /// Endpoint A then B in the second face's UV frame.
    pub(crate) face_1_endpoints: [[f64; 2]; 2],
    /// Byte offset of the source prototype pcurve.
    pub(crate) offset: usize,
}

impl BoundPrototypePcurve {
    /// Stored face identifiers, with zero for an absent face.
    pub(crate) fn stored_face_ids(&self) -> [u32; 2] {
        self.faces.map(stored_face_reference)
    }
}

/// Discover every labeled `crv_array` prototype. A label range ends at the
/// following `crv_array` label, so DEPDB-concatenated namespaces remain
/// independent.
pub(crate) fn prototypes(payload: &[u8]) -> Vec<CurvePrototype> {
    let mut result = Vec::new();
    let mut start = 0;
    while let Some(relative) = find(payload, b"crv_array\0", start) {
        let section_start = relative;
        start = relative + b"crv_array\0".len();
        let section_end = find(payload, b"crv_array\0", start).unwrap_or(payload.len());
        let Some(id_label) = find_in(payload, b"crv_id\0", start, section_end) else {
            continue;
        };
        let id_start = id_label + b"crv_id\0".len();
        let (id, id_end) = compact_int(payload, id_start);
        if id_end == id_start {
            continue;
        }
        let Some(type_label) = find_in(payload, b"type\0", id_end, section_end) else {
            continue;
        };
        let Some(&type_byte) = payload.get(type_label + b"type\0".len()) else {
            continue;
        };
        let feature_id = find_in(payload, b"feat_id\0", id_end, section_end).and_then(|label| {
            let value_start = label + b"feat_id\0".len();
            let (value, end) = compact_int(payload, value_start);
            (end != value_start).then_some(value)
        });
        let directions =
            find_in(payload, b"crv_pnt_dir\0", id_end, section_end).and_then(|label| {
                let value_start = label + b"crv_pnt_dir\0".len();
                (payload.get(value_start) == Some(&psb::token::ARRAY_OPEN)).then_some(())?;
                let (count, after_count) = compact_int(payload, value_start + 1);
                (count == 2).then_some(())?;
                let directions = [*payload.get(after_count)?, *payload.get(after_count + 1)?];
                directions
                    .iter()
                    .all(|direction| matches!(direction, 0x01 | 0xf6))
                    .then_some(directions)
            });
        result.push(CurvePrototype {
            id,
            type_byte,
            feature_id,
            directions,
            offset: section_start,
        });
    }
    result
}

/// Promote a uniquely referenced named-prototype topology record to a native
/// half-edge row when its positional successor references the prototype ID.
///
/// A named prototype is a schema record by default. A successor reference is
/// the byte-backed evidence that the prototype also supplies an edge identity
/// in the enclosing topology graph. The promotion remains withheld when the
/// prototype, topology record, or face namespace is ambiguous.
pub(crate) fn prototype_topology_rows(
    prototypes: &[CurvePrototype],
    prototype_topology: &[CurvePrototypeTopology],
    positional_rows: &[CurveTopologyRow],
    face_ids: &BTreeSet<u32>,
) -> Vec<CurveTopologyRow> {
    let mut prototype_counts = BTreeMap::<u32, usize>::new();
    for prototype in prototypes {
        match prototype_counts.entry(prototype.id) {
            std::collections::btree_map::Entry::Occupied(mut entry) => *entry.get_mut() += 1,
            std::collections::btree_map::Entry::Vacant(entry) => {
                entry.insert(1);
            }
        }
    }
    let mut topology_counts = BTreeMap::<u32, usize>::new();
    for topology in prototype_topology {
        match topology_counts.entry(topology.curve_id) {
            std::collections::btree_map::Entry::Occupied(mut entry) => *entry.get_mut() += 1,
            std::collections::btree_map::Entry::Vacant(entry) => {
                entry.insert(1);
            }
        }
    }
    let mut positional_ids = BTreeSet::new();
    for row in positional_rows {
        positional_ids.insert(row.id);
    }
    let mut referenced_ids = BTreeSet::new();
    for id in positional_rows
        .iter()
        .flat_map(|row| row.next_edges)
        .chain(prototype_topology.iter().flat_map(|row| row.next_edges))
        .filter(|id| *id != 0)
    {
        referenced_ids.insert(id);
    }
    let mut rows = Vec::new();
    for topology in prototype_topology {
        if positional_ids.contains(&topology.curve_id)
            || prototype_counts.get(&topology.curve_id) != Some(&1)
            || topology_counts.get(&topology.curve_id) != Some(&1)
            || !referenced_ids.contains(&topology.curve_id)
            || !topology
                .faces
                .iter()
                .all(|face_id| face_id.is_none_or(|id| face_ids.contains(&id.get())))
        {
            continue;
        }
        let Some(prototype) = prototypes
            .iter()
            .find(|prototype| prototype.id == topology.curve_id)
        else {
            continue;
        };
        let Some(directions) = prototype.directions else {
            continue;
        };
        rows.push(CurveTopologyRow {
            id: topology.curve_id,
            type_byte: prototype.type_byte,
            feature_id: prototype.feature_id.unwrap_or(0),
            directions,
            faces: topology.faces,
            next_edges: topology.next_edges,
            offset: topology.offset,
        });
    }
    rows.as_mut_slice().sort_by_key(|left| left.offset);
    rows
}

/// Decode bounded curve-from-equation expression programs.
#[cfg(test)]
pub(crate) fn expression_records(payload: &[u8]) -> Vec<CurveExpressionRecord> {
    crate::decode::with_service_context(|ctx| {
        expression_records_with_model_name(ctx, payload, None)
    })
    .expect("test curve expression records")
}

/// Decode curve-expression programs with an unambiguous current-model name.
pub(crate) fn expression_records_with_model_name(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    payload: &[u8],
    model_name: Option<&str>,
) -> Result<Vec<CurveExpressionRecord>, cadmpeg_core::CodecError> {
    const PRIMARY: &[u8] = b"entity(crv_fr_eqn)\0";
    const BACKUP: &[u8] = b"backup_ents(crv_fr_eqn)\0";
    const ID: &[u8] = b"\xe0\x01id\0";
    const EXPRESSION: &[u8] = b"\xe0\x0aexpression\0";
    const LOCAL_SYSTEM: &[u8] = b"\xe0\x02local_sys\0\xf9";

    let mut labels = Vec::new();
    for (label, backup) in [(PRIMARY, false), (BACKUP, true)] {
        let mut start = 0;
        while let Some(offset) = find(payload, label, start) {
            labels.push((offset, label.len(), backup));
            start = offset + label.len();
        }
    }
    labels.sort_unstable_by_key(|left| left.0);

    let cache = scalar::ScalarCache::from_section_checked(payload);
    let mut records = Vec::new();
    for (index, &(offset, label_len, backup)) in labels.iter().enumerate() {
        let end = labels
            .get(index + 1)
            .map_or(payload.len(), |(next, _, _)| *next);
        let Some(id_label) = find_in(payload, ID, offset + label_len, end) else {
            continue;
        };
        let id_start = id_label + ID.len();
        let (entity_id, after_id) = compact_int(payload, id_start);
        if after_id == id_start {
            continue;
        }
        let local_system =
            (|| -> Result<Option<CurveExpressionLocalSystem>, cadmpeg_core::CodecError> {
                let Some(offset) = find_in(payload, LOCAL_SYSTEM, after_id, end) else {
                    return Ok(None);
                };
                let extents_start = offset + LOCAL_SYSTEM.len();
                let (dimensions, dimensions_end) = compact_int(payload, extents_start);
                let (count, body_start) = compact_int(payload, dimensions_end);
                if dimensions_end <= extents_start
                    || body_start <= dimensions_end
                    || body_start > end
                {
                    return Ok(None);
                }
                let body_end = payload[body_start..end]
                    .windows(1)
                    .position(|window| window[0] == psb::token::NAMED_RECORD)
                    .map_or(end, |relative| body_start + relative);
                let body = payload[body_start..body_end].to_vec();
                Ok(Some(CurveExpressionLocalSystem {
                    dimensions,
                    count,
                    explicit_slots: ((dimensions, count) == (4, 3))
                        .then(|| scalar::decode_explicit_local_system_slots(&body, &cache))
                        .flatten(),
                    body,
                    offset,
                }))
            })()?;
        let Some(expression_offset) = find_in(payload, EXPRESSION, after_id, end) else {
            continue;
        };
        let opener = expression_offset + EXPRESSION.len();
        if payload.get(opener) != Some(&psb::token::ARRAY_OPEN) {
            continue;
        }
        let (count, mut cursor) = compact_int(payload, opener + 1);
        if cursor == opener + 1 || cursor > end {
            continue;
        }
        let mut lines = Vec::new();
        for _ in 0..count {
            let Some(relative_end) = payload[cursor..end].iter().position(|byte| *byte == 0) else {
                lines.clear();
                break;
            };
            let line_end = cursor + relative_end;
            let Ok(text) = std::str::from_utf8(&payload[cursor..line_end]) else {
                lines.clear();
                break;
            };
            lines.push(CurveExpressionLine {
                text: text.to_owned(),
                offset: cursor,
            });
            cursor = line_end + 1;
        }
        if lines.len() == index_from_u32(count) {
            let prohibited_constructs = curve_equation_prohibited_constructs(&lines);
            let mut solve_program = curve_expression_solve_program(&lines);
            let mut evaluation = evaluate_expression_program_details(
                ctx,
                &lines,
                model_name,
                &ExternalRelationSymbols::default(),
            )?;
            if !prohibited_constructs.is_empty() || solve_program.unresolved_control {
                for assignment in &mut evaluation.assignments {
                    assignment.value = None;
                }
                evaluation.solve_solutions.clear();
                evaluation.solve_work_caps.clear();
                evaluation.text_work_caps.clear();
            }
            synchronize_solve_blocks(
                &mut solve_program.blocks,
                &evaluation.assignments,
                &evaluation.solve_solutions,
                &evaluation.solve_work_caps,
            );
            records.push(CurveExpressionRecord {
                entity_id,
                backup,
                local_system,
                lines,
                assignments: evaluation.assignments,
                solve_blocks: solve_program.blocks,
                unresolved_solve_control: solve_program.unresolved_control,
                prohibited_constructs,
                text_work_caps: evaluation.text_work_caps,
                offset,
                expression_offset,
            });
        }
    }
    Ok(records)
}

pub(crate) fn reevaluate_expression_records(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    records: &mut [CurveExpressionRecord],
    model_name: Option<&str>,
    external_symbols: &ExternalRelationSymbols,
) -> Result<(), cadmpeg_core::CodecError> {
    for record in records {
        let mut evaluation =
            evaluate_expression_program_details(ctx, &record.lines, model_name, external_symbols)?;
        if !record.prohibited_constructs.is_empty() || record.unresolved_solve_control {
            for assignment in &mut evaluation.assignments {
                assignment.value = None;
            }
            evaluation.solve_solutions.clear();
            evaluation.solve_work_caps.clear();
            evaluation.text_work_caps.clear();
        }
        synchronize_solve_blocks(
            &mut record.solve_blocks,
            &evaluation.assignments,
            &evaluation.solve_solutions,
            &evaluation.solve_work_caps,
        );
        record.assignments = evaluation.assignments;
        record.text_work_caps = evaluation.text_work_caps;
    }
    Ok(())
}

fn synchronize_solve_blocks(
    blocks: &mut [CurveExpressionSolveBlock],
    assignments: &[CurveExpressionAssignment],
    solutions: &BTreeMap<usize, Vec<CurveExpressionValue>>,
    work_caps: &BTreeMap<usize, BTreeSet<&'static str>>,
) {
    for block in blocks {
        for assignment in &mut block.assignments {
            if let Some(evaluated) = assignments
                .iter()
                .find(|evaluated| evaluated.offset == assignment.offset)
            {
                assignment.value = evaluated.value.as_ref().map(copy_expression_value);
                assignment.activation = evaluated.activation;
            }
        }
        let values = solutions.get(&block.offset);
        for (index, unknown) in block.unknowns.iter_mut().enumerate() {
            unknown.solution = values
                .and_then(|values| values.get(index))
                .map(copy_expression_value);
        }
        block.work_caps = work_caps.get(&block.offset).cloned().unwrap_or_default();
    }
}

fn curve_equation_prohibited_constructs(lines: &[CurveExpressionLine]) -> Vec<String> {
    const PROHIBITED_FUNCTIONS: &[&str] =
        &["abs", "ceil", "floor", "extract", "if", "itos", "search"];
    let mut prohibited = BTreeSet::new();
    for line in lines {
        let source = line.text.trim();
        if source.starts_with("/*") {
            continue;
        }
        for keyword in ["if", "else", "endif"] {
            if starts_relation_keyword(source, keyword) && !prohibited.contains(keyword) {
                prohibited.insert(keyword.to_owned());
            }
        }
        let bytes = source.as_bytes();
        let mut cursor = 0;
        while cursor < bytes.len() {
            if matches!(bytes[cursor], b'\'' | b'"') {
                let delimiter = bytes[cursor];
                cursor += 1;
                while bytes.get(cursor).is_some_and(|byte| *byte != delimiter) {
                    cursor += 1;
                }
                cursor += usize::from(bytes.get(cursor) == Some(&delimiter));
                continue;
            }
            if bytes[cursor] == b'_' || bytes[cursor].is_ascii_alphabetic() {
                let start = cursor;
                let Some(end) = expression_identifier_end(bytes, start) else {
                    cursor += 1;
                    continue;
                };
                cursor = end;
                let mut following = cursor;
                while bytes.get(following).is_some_and(u8::is_ascii_whitespace) {
                    following += 1;
                }
                let name = &source[start..end];
                if bytes.get(following) == Some(&b'(')
                    && PROHIBITED_FUNCTIONS
                        .iter()
                        .any(|candidate| name.eq_ignore_ascii_case(candidate))
                    && !prohibited
                        .iter()
                        .any(|known: &String| known.eq_ignore_ascii_case(name))
                {
                    let mut name = name.to_owned();
                    name.make_ascii_lowercase();
                    prohibited.insert(name);
                }
                continue;
            }
            cursor += 1;
        }
    }
    let mut ordered = Vec::new();
    ordered.extend(prohibited);
    ordered
}

#[derive(Default)]
pub(crate) struct ExternalRelationSymbols {
    values: BTreeMap<String, Option<CurveExpressionValue>>,
}

impl ExternalRelationSymbols {
    pub(crate) fn observe(&mut self, mut name: String, value: Option<CurveExpressionValue>) {
        use std::collections::btree_map::Entry;

        name.make_ascii_lowercase();
        match self.values.entry(name) {
            Entry::Vacant(entry) => {
                entry.insert(value);
            }
            Entry::Occupied(mut entry) if entry.get() != &value => {
                entry.insert(None);
            }
            Entry::Occupied(_) => {}
        }
    }
}

fn expression_assignment(line: &CurveExpressionLine) -> Option<CurveExpressionAssignment> {
    let source = line.text.trim();
    if source.starts_with("/*") {
        return None;
    }
    let (name, expression) = split_expression_assignment(source)?;
    let target = expression_assignment_target(name.trim())?;
    let expression = expression.trim();
    if expression.is_empty() {
        return None;
    }
    let mut dependencies = Vec::<String>::new();
    if let CurveExpressionTarget::TableCell {
        parameter,
        row,
        column,
    } = &target
    {
        dependencies.push(parameter.to_owned());
        extend_expression_dependencies(&mut dependencies, row)?;
        if let Some(column) = column {
            extend_expression_dependencies(&mut dependencies, column)?;
        }
    } else if let CurveExpressionTarget::FunctionWrite { arguments, .. } = &target {
        for argument in arguments {
            extend_expression_dependencies(&mut dependencies, argument)?;
        }
    }
    extend_expression_dependencies(&mut dependencies, expression)?;
    Some(CurveExpressionAssignment {
        target,
        expression: expression.to_owned(),
        dependencies,
        value: None,
        activation: CurveExpressionActivation::Active,
        offset: line.offset,
    })
}

fn extend_expression_dependencies(dependencies: &mut Vec<String>, expression: &str) -> Option<()> {
    let bytes = expression.as_bytes();
    let mut cursor = 0;
    while cursor < bytes.len() {
        if matches!(bytes[cursor], b'\'' | b'"') {
            let delimiter = bytes[cursor];
            cursor += 1;
            while bytes.get(cursor).is_some_and(|byte| *byte != delimiter) {
                cursor += 1;
            }
            if bytes.get(cursor) == Some(&delimiter) {
                cursor += 1;
            }
        } else if bytes[cursor].is_ascii_digit()
            || (bytes[cursor] == b'.' && bytes.get(cursor + 1).is_some_and(u8::is_ascii_digit))
        {
            while bytes
                .get(cursor)
                .is_some_and(|byte| byte.is_ascii_digit() || *byte == b'.')
            {
                cursor += 1;
            }
            if bytes
                .get(cursor)
                .is_some_and(|byte| matches!(byte, b'e' | b'E'))
                && bytes.get(cursor + 1).is_some_and(|byte| {
                    byte.is_ascii_digit()
                        || (matches!(byte, b'+' | b'-')
                            && bytes.get(cursor + 2).is_some_and(u8::is_ascii_digit))
                })
            {
                cursor += 1;
                if bytes
                    .get(cursor)
                    .is_some_and(|byte| matches!(byte, b'+' | b'-'))
                {
                    cursor += 1;
                }
                while bytes.get(cursor).is_some_and(u8::is_ascii_digit) {
                    cursor += 1;
                }
            }
        } else if bytes[cursor] == b'[' {
            if let Some(end) = bytes[cursor + 1..].iter().position(|byte| *byte == b']') {
                cursor += end + 2;
            } else {
                cursor += 1;
            }
        } else if bytes[cursor] == b'_' || bytes[cursor].is_ascii_alphabetic() {
            let start = cursor;
            let end = expression_identifier_end(bytes, start)?;
            cursor = end;
            let dependency = &expression[start..cursor];
            let mut following = cursor;
            while bytes.get(following).is_some_and(u8::is_ascii_whitespace) {
                following += 1;
            }
            let function =
                bytes.get(following) == Some(&b'(') && creo_relation_function(dependency).is_some();
            let constant = reserved_relation_scalar(dependency).is_some();
            if !function
                && !constant
                && !dependencies
                    .iter()
                    .any(|existing| existing.eq_ignore_ascii_case(dependency))
            {
                dependencies.push(dependency.to_owned());
            }
        } else {
            cursor += 1;
        }
    }
    Some(())
}

fn split_expression_assignment(source: &str) -> Option<(&str, &str)> {
    let bytes = source.as_bytes();
    let mut nesting = 0usize;
    let mut delimiter = None;
    let mut cursor = 0;
    while cursor < bytes.len() {
        if let Some(quote) = delimiter {
            if bytes[cursor] == quote {
                delimiter = None;
            }
            cursor += 1;
            continue;
        }
        match bytes[cursor] {
            byte @ (b'\'' | b'"') => delimiter = Some(byte),
            b'(' => nesting = nesting.checked_add(1)?,
            b')' => nesting = nesting.checked_sub(1)?,
            b'=' if nesting == 0
                && !bytes
                    .get(..cursor)
                    .and_then(|prefix| prefix.last())
                    .is_some_and(|byte| matches!(byte, b'=' | b'!' | b'~' | b'<' | b'>'))
                && bytes.get(cursor + 1) != Some(&b'=') =>
            {
                return Some((source.get(..cursor)?, source.get(cursor + 1..)?));
            }
            _ => {}
        }
        cursor += 1;
    }
    None
}

#[derive(Default)]
struct CurveExpressionSolveProgram {
    blocks: Vec<CurveExpressionSolveBlock>,
    line_indices: BTreeSet<usize>,
    executable_line_indices: BTreeSet<usize>,
    unresolved_control: bool,
}

struct PendingCurveExpressionSolveBlock {
    statements: Vec<PendingCurveExpressionSolveStatement>,
    offset: usize,
    valid: bool,
}

struct PendingCurveExpressionSolveStatement {
    equation: CurveExpressionEquation,
    assignment: Option<CurveExpressionAssignment>,
    line_index: usize,
}

fn curve_expression_solve_program(lines: &[CurveExpressionLine]) -> CurveExpressionSolveProgram {
    let mut program = CurveExpressionSolveProgram::default();
    let mut pending = None::<PendingCurveExpressionSolveBlock>;
    for (index, line) in lines.iter().enumerate() {
        let source = line.text.trim();
        let Some(block) = pending.as_mut() else {
            if starts_relation_keyword(source, "solve") {
                program.line_indices.insert(index);
                pending = Some(PendingCurveExpressionSolveBlock {
                    statements: Vec::new(),
                    offset: line.offset,
                    valid: source.eq_ignore_ascii_case("solve"),
                });
            } else if starts_relation_keyword(source, "for") {
                program.line_indices.insert(index);
                program.unresolved_control = true;
            }
            continue;
        };

        program.line_indices.insert(index);
        if starts_relation_keyword(source, "solve") {
            program.unresolved_control = true;
            block.valid = false;
            continue;
        }
        if starts_relation_keyword(source, "for") {
            let unknowns = match conditional_keyword_expression(source, "for") {
                Some(unknowns) => curve_expression_solve_unknowns(unknowns),
                None => None,
            };
            let mut equations = Vec::new();
            let mut assignments = Vec::new();
            let mut assignment_line_indices = Vec::new();
            if let Some(unknowns) = &unknowns {
                for statement in std::mem::take(&mut block.statements) {
                    if statement.equation.dependencies.iter().any(|dependency| {
                        unknowns
                            .iter()
                            .any(|unknown| unknown.name.eq_ignore_ascii_case(dependency))
                    }) {
                        equations.push(statement.equation);
                    } else if let Some(assignment) = statement.assignment {
                        assignment_line_indices.push(statement.line_index);
                        assignments.push(assignment);
                    } else {
                        block.valid = false;
                    }
                }
            }
            if let Some(unknowns) = unknowns.filter(|_| block.valid && !equations.is_empty()) {
                for index in assignment_line_indices {
                    program.executable_line_indices.insert(index);
                }
                program.blocks.push(CurveExpressionSolveBlock {
                    equations,
                    assignments,
                    unknowns,
                    offset: block.offset,
                    for_offset: line.offset,
                    work_caps: BTreeSet::new(),
                });
            } else {
                program.unresolved_control = true;
            }
            pending = None;
            continue;
        }
        if source.is_empty() || source.starts_with("/*") {
            continue;
        }
        let Some((left, right)) = split_expression_assignment(source) else {
            program.unresolved_control = true;
            block.valid = false;
            continue;
        };
        let (left, right) = (left.trim(), right.trim());
        if left.is_empty() || right.is_empty() || split_expression_assignment(right).is_some() {
            program.unresolved_control = true;
            block.valid = false;
            continue;
        }
        let mut dependencies = Vec::new();
        if extend_expression_dependencies(&mut dependencies, left).is_none()
            || extend_expression_dependencies(&mut dependencies, right).is_none()
        {
            program.unresolved_control = true;
            block.valid = false;
            continue;
        }
        block.statements.push(PendingCurveExpressionSolveStatement {
            equation: CurveExpressionEquation {
                left: left.to_owned(),
                right: right.to_owned(),
                dependencies,
                offset: line.offset,
            },
            assignment: expression_assignment(line),
            line_index: index,
        });
    }
    if pending.is_some() {
        program.unresolved_control = true;
    }
    program
}

fn curve_expression_solve_unknowns(source: &str) -> Option<Vec<SolveUnknown>> {
    let mut unknowns = Vec::<SolveUnknown>::new();
    for name in source
        .split(|character: char| character == ',' || character.is_ascii_whitespace())
        .filter(|variable| !variable.is_empty())
    {
        if !valid_scoped_expression_identifier(name) {
            return None;
        }
        if unknowns
            .iter()
            .any(|known| known.name.eq_ignore_ascii_case(name))
        {
            return None;
        }
        unknowns.push(SolveUnknown {
            name: name.to_owned(),
            solution: None,
        });
    }
    (!unknowns.is_empty()).then_some(unknowns)
}

fn expression_assignment_target(source: &str) -> Option<CurveExpressionTarget> {
    if let Some((name, arguments)) = expression_target_function_call(source) {
        if name.eq_ignore_ascii_case("value") {
            let [parameter, row, rest @ ..] = arguments.as_slice() else {
                return None;
            };
            let column = match rest {
                [] => None,
                [column] => Some((*column).to_owned()),
                _ => return None,
            };
            if !valid_expression_identifier(parameter) {
                return None;
            }
            return Some(CurveExpressionTarget::TableCell {
                parameter: (*parameter).to_owned(),
                row: (*row).to_owned(),
                column,
            });
        }
        let mut retained_arguments = Vec::new();
        for argument in arguments {
            retained_arguments.push(argument.to_owned());
        }
        return Some(CurveExpressionTarget::FunctionWrite {
            name: name.to_owned(),
            arguments: retained_arguments,
        });
    }
    let (name, declared_unit) = if source.ends_with(']') {
        let unit_start = source.rfind('[')?;
        let unit = source.get(unit_start + 1..source.len() - 1)?;
        let unit = unit.trim();
        if unit.is_empty() {
            return None;
        }
        let name = source.get(..unit_start)?;
        (name.trim_end(), Some(unit))
    } else {
        (source, None)
    };
    if name.contains(':') {
        if declared_unit.is_some() || !valid_scoped_expression_identifier(name) {
            return None;
        }
        Some(CurveExpressionTarget::ScopedSymbol {
            name: name.to_owned(),
        })
    } else if let Some(family) = expression_system_symbol_family(name) {
        if declared_unit.is_some() {
            return None;
        }
        Some(CurveExpressionTarget::SystemSymbol {
            name: name.to_owned(),
            family,
        })
    } else {
        if !valid_expression_identifier(name) {
            return None;
        }
        let declared_unit = declared_unit.map(std::borrow::ToOwned::to_owned);
        Some(CurveExpressionTarget::Parameter {
            name: name.to_owned(),
            declared_unit,
        })
    }
}

fn expression_target_function_call(source: &str) -> Option<(&str, Vec<&str>)> {
    let argument_start = source.find('(')?;
    if !source.ends_with(')') {
        return None;
    }
    let name = source.get(..argument_start)?;
    let name = name.trim_end();
    if !valid_expression_identifier(name) {
        return None;
    }
    let body = source.get(argument_start + 1..source.len() - 1)?;
    let arguments = if body.trim().is_empty() {
        Vec::new()
    } else {
        let arguments = split_assignment_target_arguments(body)?;
        arguments
    };
    Some((name, arguments))
}

fn valid_expression_identifier(name: &str) -> bool {
    !name.is_empty()
        && name.bytes().enumerate().all(|(index, byte)| {
            byte == b'_' || byte.is_ascii_alphabetic() || (index > 0 && byte.is_ascii_digit())
        })
}

fn valid_scoped_expression_identifier(name: &str) -> bool {
    expression_identifier_end(name.as_bytes(), 0) == Some(name.len())
}

fn expression_system_symbol_family(name: &str) -> Option<CurveExpressionSystemSymbolFamily> {
    let digit_start = name
        .bytes()
        .position(|byte| byte.is_ascii_digit())
        .filter(|digit_start| *digit_start != 0)?;
    name.get(digit_start..)?
        .bytes()
        .all(|byte| byte.is_ascii_digit())
        .then_some(())?;
    let prefix = name.get(..digit_start)?;
    if prefix.eq_ignore_ascii_case("d") {
        Some(CurveExpressionSystemSymbolFamily::Dimension)
    } else if prefix.eq_ignore_ascii_case("sd") {
        Some(CurveExpressionSystemSymbolFamily::SectionDimension)
    } else if prefix.eq_ignore_ascii_case("rd") {
        Some(CurveExpressionSystemSymbolFamily::ReferenceDimension)
    } else if prefix.eq_ignore_ascii_case("rsd") {
        Some(CurveExpressionSystemSymbolFamily::SectionReferenceDimension)
    } else if prefix.eq_ignore_ascii_case("kd") {
        Some(CurveExpressionSystemSymbolFamily::KnownDimension)
    } else if prefix.eq_ignore_ascii_case("ad") {
        Some(CurveExpressionSystemSymbolFamily::DrivenDimension)
    } else if prefix.eq_ignore_ascii_case("p") {
        Some(CurveExpressionSystemSymbolFamily::PatternCount)
    } else if ["tpm", "tp", "tm"]
        .into_iter()
        .any(|family| prefix.eq_ignore_ascii_case(family))
    {
        Some(CurveExpressionSystemSymbolFamily::Tolerance)
    } else {
        None
    }
}

fn split_assignment_target_arguments(source: &str) -> Option<Vec<&str>> {
    let mut arguments = Vec::new();
    let mut start = 0;
    let mut nesting = 0usize;
    let mut delimiter = None;
    for (offset, byte) in source.bytes().enumerate() {
        if let Some(quote) = delimiter {
            if byte == quote {
                delimiter = None;
            }
            continue;
        }
        match byte {
            b'\'' | b'"' => delimiter = Some(byte),
            b'(' => {
                let next = nesting.checked_add(1)?;
                nesting = next;
            }
            b')' => {
                let next = nesting.checked_sub(1)?;
                nesting = next;
            }
            b',' if nesting == 0 => {
                let argument = source.get(start..offset)?;
                let argument = argument.trim();
                if argument.is_empty() {
                    return None;
                }
                arguments.push(argument);
                start = offset + 1;
            }
            _ => {}
        }
    }
    if delimiter.is_some() || nesting != 0 {
        return None;
    }
    let argument = source.get(start..)?;
    let argument = argument.trim();
    if argument.is_empty() {
        return None;
    }
    arguments.push(argument);
    Some(arguments)
}

fn reserved_relation_scalar(name: &str) -> Option<f64> {
    if name.eq_ignore_ascii_case("pi") {
        Some(std::f64::consts::PI)
    } else if name.eq_ignore_ascii_case("g") {
        Some(9_800.0)
    } else if name.eq_ignore_ascii_case("true") || name.eq_ignore_ascii_case("yes") {
        Some(1.0)
    } else if name.eq_ignore_ascii_case("false") || name.eq_ignore_ascii_case("no") {
        Some(0.0)
    } else {
        None
    }
}

fn expression_identifier_end(source: &[u8], start: usize) -> Option<usize> {
    source
        .get(start)
        .is_some_and(|byte| *byte == b'_' || byte.is_ascii_alphabetic())
        .then_some(())?;
    let mut cursor = start + 1;
    while source
        .get(cursor)
        .is_some_and(|byte| *byte == b'_' || byte.is_ascii_alphabetic() || byte.is_ascii_digit())
    {
        cursor += 1;
    }
    while source.get(cursor) == Some(&b':')
        && source.get(cursor + 1).is_some_and(|byte| {
            *byte == b'_' || byte.is_ascii_alphabetic() || byte.is_ascii_digit()
        })
    {
        cursor += 2;
        while source.get(cursor).is_some_and(|byte| {
            *byte == b'_' || byte.is_ascii_alphabetic() || byte.is_ascii_digit()
        }) {
            cursor += 1;
        }
    }
    Some(cursor)
}

#[derive(Debug, Clone)]
struct ConditionalFrame {
    parent: CurveExpressionActivation,
    condition: Option<bool>,
}

#[derive(Default)]
enum ConditionalStack {
    #[default]
    Empty,
    Open {
        frame: ConditionalFrame,
        parents: Vec<ConditionalFrame>,
    },
}

impl ConditionalStack {
    fn push(&mut self, frame: ConditionalFrame) {
        match self {
            Self::Empty => {
                *self = Self::Open {
                    frame,
                    parents: Vec::new(),
                };
            }
            Self::Open {
                frame: parent,
                parents,
            } => {
                parents.push(std::mem::replace(parent, frame));
            }
        }
    }

    fn alternative(&self) -> CurveExpressionActivation {
        match self {
            Self::Empty => CurveExpressionActivation::Conditional,
            Self::Open { frame, .. } => branch_activation(frame.parent, frame.condition, true),
        }
    }

    fn end(&mut self) -> CurveExpressionActivation {
        match std::mem::take(self) {
            Self::Empty => CurveExpressionActivation::Conditional,
            Self::Open { frame, mut parents } => {
                if let Some(parent) = parents.pop() {
                    *self = Self::Open {
                        frame: parent,
                        parents,
                    };
                }
                frame.parent
            }
        }
    }
}

fn conditional_keyword_expression<'a>(source: &'a str, keyword: &str) -> Option<&'a str> {
    let source = source.trim();
    let prefix = source.get(..keyword.len())?;
    prefix.eq_ignore_ascii_case(keyword).then_some(())?;
    source
        .as_bytes()
        .get(keyword.len())
        .is_some_and(u8::is_ascii_whitespace)
        .then_some(())?;
    let expression = source.get(keyword.len()..)?.trim_start();
    (!expression.is_empty()).then_some(expression)
}

fn starts_relation_keyword(source: &str, keyword: &str) -> bool {
    let source = source.trim();
    source
        .get(..keyword.len())
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case(keyword))
        && source
            .as_bytes()
            .get(keyword.len())
            .is_none_or(u8::is_ascii_whitespace)
}

fn expression_program_control_is_valid(lines: &[CurveExpressionLine]) -> bool {
    let mut else_seen = Vec::new();
    for line in lines {
        let source = line.text.trim();
        if starts_relation_keyword(source, "if") {
            if conditional_keyword_expression(source, "if").is_none() {
                return false;
            }
            else_seen.push(false);
        } else if starts_relation_keyword(source, "else") {
            if !source.eq_ignore_ascii_case("else") {
                return false;
            }
            let Some(seen) = else_seen.last_mut() else {
                return false;
            };
            if *seen {
                return false;
            }
            *seen = true;
        } else if starts_relation_keyword(source, "endif")
            && (!source.eq_ignore_ascii_case("endif") || else_seen.pop().is_none())
        {
            return false;
        }
    }
    else_seen.is_empty()
}

fn branch_activation(
    parent: CurveExpressionActivation,
    condition: Option<bool>,
    alternative: bool,
) -> CurveExpressionActivation {
    match parent {
        CurveExpressionActivation::Inactive => CurveExpressionActivation::Inactive,
        CurveExpressionActivation::Conditional => CurveExpressionActivation::Conditional,
        CurveExpressionActivation::Active => match condition {
            Some(selected) if selected != alternative => CurveExpressionActivation::Active,
            Some(_) => CurveExpressionActivation::Inactive,
            None => CurveExpressionActivation::Conditional,
        },
    }
}

struct CurveExpressionEvaluation {
    assignments: Vec<CurveExpressionAssignment>,
    solve_solutions: BTreeMap<usize, Vec<CurveExpressionValue>>,
    solve_work_caps: BTreeMap<usize, BTreeSet<&'static str>>,
    text_work_caps: BTreeMap<&'static str, usize>,
}

fn copy_expression_value(value: &CurveExpressionValue) -> CurveExpressionValue {
    match value {
        CurveExpressionValue::String(text) => CurveExpressionValue::String(text.to_owned()),
        value => value.clone(),
    }
}

fn evaluate_expression_program_details(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    lines: &[CurveExpressionLine],
    model_name: Option<&str>,
    external_symbols: &ExternalRelationSymbols,
) -> Result<CurveExpressionEvaluation, cadmpeg_core::CodecError> {
    let solve_program = curve_expression_solve_program(lines);
    let solve_line_is_executable = |index: &usize| {
        !solve_program.line_indices.contains(index)
            || solve_program.executable_line_indices.contains(index)
    };
    let control_is_valid = expression_program_control_is_valid(lines);
    let mut parsed_assignments = ctx.alloc_filled(
        lines.len(),
        None::<CurveExpressionAssignment>,
        "creo parsed expression assignment slots",
    )?;
    for (index, line) in lines.iter().enumerate() {
        if solve_line_is_executable(&index) {
            parsed_assignments[index] = expression_assignment(line);
        }
    }
    if !control_is_valid {
        let mut assignments = Vec::new();
        for mut assignment in parsed_assignments.into_iter().flatten() {
            assignment.activation = CurveExpressionActivation::Conditional;
            assignments.push(assignment);
        }
        return Ok(CurveExpressionEvaluation {
            assignments,
            solve_solutions: BTreeMap::new(),
            solve_work_caps: BTreeMap::new(),
            text_work_caps: BTreeMap::new(),
        });
    }

    let mut existing_symbols = BTreeSet::new();
    for name in external_symbols.values.keys() {
        existing_symbols.insert(name.to_owned());
    }
    for assignment in parsed_assignments.iter().flatten() {
        if let Some((name, _)) = assignment.scalar_target() {
            let mut key = name.to_owned();
            key.make_ascii_lowercase();
            existing_symbols.insert(key);
        }
    }
    for unknown in solve_program
        .blocks
        .iter()
        .flat_map(|block| &block.unknowns)
    {
        let mut key = unknown.name.clone();
        key.make_ascii_lowercase();
        existing_symbols.insert(key);
    }
    let context = RelationEvaluationContext {
        model_name,
        existing_symbols: Some(&existing_symbols),
    };
    let mut values = BTreeMap::new();
    let mut defined_symbols = BTreeSet::new();
    for (name, value) in &external_symbols.values {
        defined_symbols.insert(name.to_owned());
        if let Some(value) = value {
            values.insert(name.to_owned(), copy_expression_value(value));
        }
    }
    let mut stack = ConditionalStack::default();
    let mut activity = CurveExpressionActivation::Active;
    let mut assignments = Vec::<CurveExpressionAssignment>::new();
    let mut solve_solutions = BTreeMap::new();
    let mut solve_work_caps = BTreeMap::new();
    let mut text_work_caps = BTreeMap::<&'static str, usize>::new();
    let mut kept_text_bytes = 0usize;
    let mut solve_block_dimensions = BTreeMap::new();
    let mut solve_block_initial_values = BTreeMap::new();
    for (index, line) in lines.iter().enumerate() {
        if let Some(block) = solve_program
            .blocks
            .iter()
            .find(|block| block.offset == line.offset)
        {
            let mut dimensions =
                ctx.alloc_filled(block.unknowns.len(), None, "creo solve dimension snapshots")?;
            let mut initial_values = ctx.alloc_filled(
                block.unknowns.len(),
                None,
                "creo solve initial value snapshots",
            )?;
            for ((dimension, initial), unknown) in dimensions
                .iter_mut()
                .zip(&mut initial_values)
                .zip(&block.unknowns)
            {
                let mut key = unknown.name.clone();
                key.make_ascii_lowercase();
                let value = values.get(&key);
                *dimension = value
                    .and_then(quantity_parts_ref)
                    .map(|(_, dimension)| dimension);
                *initial = value.map(copy_expression_value);
                values.remove(&key);
                if !defined_symbols.contains(&key) {
                    defined_symbols.insert(key.clone());
                }
                for assignment in &mut assignments {
                    if assignment
                        .scalar_target()
                        .is_some_and(|(name, _)| name.eq_ignore_ascii_case(&key))
                    {
                        assignment.value = None;
                    }
                }
            }
            solve_block_dimensions.insert(block.offset, dimensions);
            solve_block_initial_values.insert(block.offset, initial_values);
        }
        if let Some(block) = solve_program
            .blocks
            .iter()
            .find(|block| block.for_offset == line.offset)
        {
            let mut block_work_caps = BTreeSet::new();
            let affine_solution = match solve_block_dimensions.get(&block.offset) {
                Some(dimensions) => match infer_solve_variable_dimensions(
                    ctx,
                    block,
                    &values,
                    dimensions,
                    context,
                    &mut block_work_caps,
                )? {
                    Some(dimensions) => {
                        solve_affine_expression_block(ctx, block, &values, &dimensions, context)?
                    }
                    None => None,
                },
                None => None,
            };
            let solution = match affine_solution {
                Some(solution) => Some(solution),
                None => match (
                    solve_block_dimensions.get(&block.offset),
                    solve_block_initial_values.get(&block.offset),
                ) {
                    (Some(dimensions), Some(initial_values)) => solve_nonlinear_expression_block(
                        ctx,
                        block,
                        &values,
                        dimensions,
                        initial_values,
                        context,
                        &mut block_work_caps,
                    )?,
                    _ => None,
                },
            };
            if solution.is_none() && !block_work_caps.is_empty() {
                solve_work_caps.insert(block.offset, block_work_caps);
            }
            if let Some(solution) = solution {
                for (variable, value) in block
                    .unknowns
                    .iter()
                    .map(|unknown| &unknown.name)
                    .zip(&solution)
                {
                    let mut key = variable.to_owned();
                    key.make_ascii_lowercase();
                    for assignment in &mut assignments {
                        if assignment
                            .scalar_target()
                            .is_some_and(|(name, _)| name.eq_ignore_ascii_case(&key))
                        {
                            assignment.value = Some(copy_expression_value(value));
                        }
                    }
                    values.insert(key, copy_expression_value(value));
                }
                solve_solutions.insert(block.offset, solution);
            }
        }
        if !solve_line_is_executable(&index) {
            continue;
        }
        let source = line.text.trim();
        if let Some(condition_source) = conditional_keyword_expression(source, "if") {
            let condition = if activity == CurveExpressionActivation::Active {
                let mut text_capped = false;
                let condition = parse_capped_relation_expression::<CurveExpressionValue>(
                    ctx,
                    condition_source,
                    &values,
                    context,
                    &mut text_capped,
                )?;
                if text_capped {
                    *text_work_caps
                        .entry("MAX_RELATION_EXPRESSION_TEXT_BYTES")
                        .or_default() += 1;
                }
                condition.and_then(|value| value.truth())
            } else {
                None
            };
            let parent = activity;
            activity = branch_activation(parent, condition, false);
            stack.push(ConditionalFrame { parent, condition });
            continue;
        }
        if source.eq_ignore_ascii_case("else") {
            activity = stack.alternative();
            continue;
        }
        if source.eq_ignore_ascii_case("endif") {
            activity = stack.end();
            continue;
        }
        let Some(mut assignment) = parsed_assignments.get_mut(index).and_then(Option::take) else {
            continue;
        };
        assignment.activation = activity;
        let Some((name, declared_unit)) = assignment.scalar_target() else {
            assignments.push(assignment);
            continue;
        };
        let mut key = name.to_owned();
        key.make_ascii_lowercase();
        let declaration_is_valid = declared_unit.is_none() || !defined_symbols.contains(&key);
        if !defined_symbols.contains(&key) {
            defined_symbols.insert(key.clone());
        }
        match activity {
            CurveExpressionActivation::Active => {
                let mut text_capped = false;
                assignment.value = if declaration_is_valid {
                    parse_capped_relation_expression::<CurveExpressionValue>(
                        ctx,
                        &assignment.expression,
                        &values,
                        context,
                        &mut text_capped,
                    )?
                    .map(|value| apply_declared_relation_unit(ctx, value, declared_unit))
                    .transpose()?
                    .flatten()
                } else {
                    None
                };
                if text_capped {
                    *text_work_caps
                        .entry("MAX_RELATION_EXPRESSION_TEXT_BYTES")
                        .or_default() += 1;
                }
                if let Some(text_len) = assignment
                    .value
                    .as_ref()
                    .and_then(ExpressionValue::text_len)
                {
                    match kept_text_bytes
                        .checked_add(text_len)
                        .filter(|kept| *kept <= MAX_RELATION_PROGRAM_TEXT_BYTES)
                    {
                        Some(kept) => kept_text_bytes = kept,
                        None => {
                            assignment.value = None;
                            *text_work_caps
                                .entry("MAX_RELATION_PROGRAM_TEXT_BYTES")
                                .or_default() += 1;
                        }
                    }
                }
                if let Some(value) = assignment.value.as_ref() {
                    let value = copy_expression_value(value);
                    values.insert(key, value);
                } else {
                    values.remove(&key);
                }
            }
            CurveExpressionActivation::Inactive => {}
            CurveExpressionActivation::Conditional => {
                values.remove(&key);
            }
        }
        assignments.push(assignment);
    }
    Ok(CurveExpressionEvaluation {
        assignments,
        solve_solutions,
        solve_work_caps,
        text_work_caps,
    })
}

#[derive(Clone, Copy, Default)]
struct RelationEvaluationContext<'a> {
    model_name: Option<&'a str>,
    existing_symbols: Option<&'a BTreeSet<String>>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
struct RelationDimension {
    length: i8,
    mass: i8,
    time: i8,
    angle: i8,
    temperature: i8,
}

impl RelationDimension {
    const LENGTH: Self = Self {
        length: 1,
        mass: 0,
        time: 0,
        angle: 0,
        temperature: 0,
    };
    const MASS: Self = Self {
        length: 0,
        mass: 1,
        time: 0,
        angle: 0,
        temperature: 0,
    };
    const TIME: Self = Self {
        length: 0,
        mass: 0,
        time: 1,
        angle: 0,
        temperature: 0,
    };
    const ANGLE: Self = Self {
        length: 0,
        mass: 0,
        time: 0,
        angle: 1,
        temperature: 0,
    };
    const TEMPERATURE: Self = Self {
        length: 0,
        mass: 0,
        time: 0,
        angle: 0,
        temperature: 1,
    };
    const FORCE: Self = Self {
        length: 1,
        mass: 1,
        time: -2,
        angle: 0,
        temperature: 0,
    };
    const ACCELERATION: Self = Self {
        length: 1,
        mass: 0,
        time: -2,
        angle: 0,
        temperature: 0,
    };

    fn combine(self, right: Self, subtract: bool) -> Option<Self> {
        let sign = if subtract { -1 } else { 1 };
        Some(Self {
            length: self.length.checked_add(right.length.checked_mul(sign)?)?,
            mass: self.mass.checked_add(right.mass.checked_mul(sign)?)?,
            time: self.time.checked_add(right.time.checked_mul(sign)?)?,
            angle: self.angle.checked_add(right.angle.checked_mul(sign)?)?,
            temperature: self
                .temperature
                .checked_add(right.temperature.checked_mul(sign)?)?,
        })
    }

    fn scale(self, exponent: i8) -> Option<Self> {
        Some(Self {
            length: self.length.checked_mul(exponent)?,
            mass: self.mass.checked_mul(exponent)?,
            time: self.time.checked_mul(exponent)?,
            angle: self.angle.checked_mul(exponent)?,
            temperature: self.temperature.checked_mul(exponent)?,
        })
    }

    fn root(self, degree: i8) -> Option<Self> {
        (degree > 0
            && self.length % degree == 0
            && self.mass % degree == 0
            && self.time % degree == 0
            && self.angle % degree == 0
            && self.temperature % degree == 0)
            .then_some(Self {
                length: self.length / degree,
                mass: self.mass / degree,
                time: self.time / degree,
                angle: self.angle / degree,
                temperature: self.temperature / degree,
            })
    }
}

#[derive(Clone, Copy)]
struct RelationUnit {
    scale: f64,
    offset: f64,
    dimension: RelationDimension,
}

impl RelationUnit {
    fn combine(self, right: Self, divide: bool) -> Option<Self> {
        (self.offset == 0.0 && right.offset == 0.0).then_some(())?;
        let scale = if divide {
            self.scale / right.scale
        } else {
            self.scale * right.scale
        };
        scale.is_finite().then_some(Self {
            scale,
            offset: 0.0,
            dimension: self.dimension.combine(right.dimension, divide)?,
        })
    }

    fn power(self, exponent: i8) -> Option<Self> {
        (self.offset == 0.0).then_some(())?;
        let scale = self.scale.powi(i32::from(exponent));
        scale.is_finite().then_some(Self {
            scale,
            offset: 0.0,
            dimension: self.dimension.scale(exponent)?,
        })
    }
}

fn relation_unit(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    source: &str,
) -> Result<Option<RelationUnit>, cadmpeg_core::CodecError> {
    let mut parser = RelationUnitParser {
        source: source.as_bytes(),
        cursor: 0,
        nesting: 0,
        ctx,
        resource_error: None,
    };
    let unit = parser.expression();
    if let Some(error) = parser.resource_error {
        return Err(error);
    }
    parser.whitespace();
    Ok(unit.filter(|_| parser.cursor == parser.source.len()))
}

struct RelationUnitParser<'a> {
    ctx: &'a cadmpeg_core::decode::DecodeContext<'a>,
    resource_error: Option<cadmpeg_core::CodecError>,
    source: &'a [u8],
    cursor: usize,
    nesting: usize,
}

impl RelationUnitParser<'_> {
    fn admit<T>(&mut self, result: Result<T, cadmpeg_core::CodecError>) -> Option<T> {
        match result {
            Ok(value) => Some(value),
            Err(error) => {
                self.resource_error = Some(error);
                None
            }
        }
    }

    fn expression(&mut self) -> Option<RelationUnit> {
        let mut unit = self.power()?;
        loop {
            self.whitespace();
            let divide = match self.source.get(self.cursor) {
                Some(b'*') => false,
                Some(b'/') => true,
                _ => return Some(unit),
            };
            self.cursor += 1;
            unit = unit.combine(self.power()?, divide)?;
        }
    }

    fn power(&mut self) -> Option<RelationUnit> {
        let unit = self.primary()?;
        self.whitespace();
        if self.source.get(self.cursor) != Some(&b'^') {
            return Some(unit);
        }
        self.cursor += 1;
        self.whitespace();
        let negative = self.source.get(self.cursor) == Some(&b'-');
        if negative || self.source.get(self.cursor) == Some(&b'+') {
            self.cursor += 1;
        }
        let start = self.cursor;
        while self.source.get(self.cursor).is_some_and(u8::is_ascii_digit) {
            self.cursor += 1;
        }
        let magnitude = std::str::from_utf8(self.source.get(start..self.cursor)?)
            .ok()?
            .parse::<i16>()
            .ok()?;
        let exponent = if negative { -magnitude } else { magnitude };
        unit.power(i8::try_from(exponent).ok()?)
    }

    fn primary(&mut self) -> Option<RelationUnit> {
        self.whitespace();
        if self.source.get(self.cursor) == Some(&b'(') {
            (self.nesting < MAX_EXPRESSION_NESTING).then_some(())?;
            let _depth = self.admit(self.ctx.enter_nested("creo relation unit depth"))?;
            self.cursor += 1;
            self.nesting += 1;
            let unit = self.expression()?;
            self.nesting -= 1;
            self.whitespace();
            (self.source.get(self.cursor) == Some(&b')')).then_some(())?;
            self.cursor += 1;
            return Some(unit);
        }
        let start = self.cursor;
        while self
            .source
            .get(self.cursor)
            .is_some_and(|byte| byte.is_ascii_alphabetic() || *byte == b'_')
        {
            self.cursor += 1;
        }
        let symbol = std::str::from_utf8(self.source.get(start..self.cursor)?).ok()?;
        relation_unit_symbol(symbol)
    }

    fn whitespace(&mut self) {
        while self
            .source
            .get(self.cursor)
            .is_some_and(u8::is_ascii_whitespace)
        {
            self.cursor += 1;
        }
    }
}

fn relation_unit_symbol(symbol: &str) -> Option<RelationUnit> {
    let (scale, offset, dimension) = match symbol {
        _ if symbol.eq_ignore_ascii_case("k") => (1.0, 0.0, RelationDimension::TEMPERATURE),
        _ if symbol.eq_ignore_ascii_case("c") => (1.0, 273.15, RelationDimension::TEMPERATURE),
        _ if symbol.eq_ignore_ascii_case("f") => (
            5.0 / 9.0,
            459.67 * 5.0 / 9.0,
            RelationDimension::TEMPERATURE,
        ),
        _ if symbol.eq_ignore_ascii_case("r") => (5.0 / 9.0, 0.0, RelationDimension::TEMPERATURE),
        symbol => {
            let (scale, dimension) = multiplicative_relation_unit_symbol(symbol)?;
            (scale, 0.0, dimension)
        }
    };
    Some(RelationUnit {
        scale,
        offset,
        dimension,
    })
}

fn multiplicative_relation_unit_symbol(symbol: &str) -> Option<(f64, RelationDimension)> {
    Some(match symbol {
        _ if symbol.eq_ignore_ascii_case("mm") => (1.0, RelationDimension::LENGTH),
        _ if symbol.eq_ignore_ascii_case("cm") => (10.0, RelationDimension::LENGTH),
        _ if symbol.eq_ignore_ascii_case("m") => (1_000.0, RelationDimension::LENGTH),
        _ if symbol.eq_ignore_ascii_case("in") || symbol.eq_ignore_ascii_case("inch") => {
            (25.4, RelationDimension::LENGTH)
        }
        _ if symbol.eq_ignore_ascii_case("ft") || symbol.eq_ignore_ascii_case("foot") => {
            (304.8, RelationDimension::LENGTH)
        }
        _ if symbol.eq_ignore_ascii_case("micron") => (0.001, RelationDimension::LENGTH),
        _ if symbol.eq_ignore_ascii_case("sq_mm") => (1.0, RelationDimension::LENGTH.scale(2)?),
        _ if symbol.eq_ignore_ascii_case("sq_cm") => (100.0, RelationDimension::LENGTH.scale(2)?),
        _ if symbol.eq_ignore_ascii_case("sq_m") => {
            (1_000_000.0, RelationDimension::LENGTH.scale(2)?)
        }
        _ if symbol.eq_ignore_ascii_case("sq_in") => (645.16, RelationDimension::LENGTH.scale(2)?),
        _ if symbol.eq_ignore_ascii_case("sq_ft") => {
            (92_903.04, RelationDimension::LENGTH.scale(2)?)
        }
        _ if symbol.eq_ignore_ascii_case("cu_mm") => (1.0, RelationDimension::LENGTH.scale(3)?),
        _ if symbol.eq_ignore_ascii_case("cu_cm") => (1_000.0, RelationDimension::LENGTH.scale(3)?),
        _ if symbol.eq_ignore_ascii_case("cu_m") => {
            (1_000_000_000.0, RelationDimension::LENGTH.scale(3)?)
        }
        _ if symbol.eq_ignore_ascii_case("cu_in") => {
            (16_387.064, RelationDimension::LENGTH.scale(3)?)
        }
        _ if symbol.eq_ignore_ascii_case("cu_ft") => {
            (28_316_846.592, RelationDimension::LENGTH.scale(3)?)
        }
        _ if symbol.eq_ignore_ascii_case("kg") => (1.0, RelationDimension::MASS),
        _ if symbol.eq_ignore_ascii_case("g") => (0.001, RelationDimension::MASS),
        _ if symbol.eq_ignore_ascii_case("mg") => (0.000_001, RelationDimension::MASS),
        _ if symbol.eq_ignore_ascii_case("lb") || symbol.eq_ignore_ascii_case("lbm") => {
            (0.453_592_37, RelationDimension::MASS)
        }
        _ if symbol.eq_ignore_ascii_case("slug") => (14.593_902_937_206_4, RelationDimension::MASS),
        _ if symbol.eq_ignore_ascii_case("tonne") => (1_000.0, RelationDimension::MASS),
        _ if symbol.eq_ignore_ascii_case("s")
            || symbol.eq_ignore_ascii_case("sec")
            || symbol.eq_ignore_ascii_case("second") =>
        {
            (1.0, RelationDimension::TIME)
        }
        _ if symbol.eq_ignore_ascii_case("msec") => (0.001, RelationDimension::TIME),
        _ if symbol.eq_ignore_ascii_case("min") || symbol.eq_ignore_ascii_case("minute") => {
            (60.0, RelationDimension::TIME)
        }
        _ if symbol.eq_ignore_ascii_case("hr") || symbol.eq_ignore_ascii_case("hour") => {
            (3_600.0, RelationDimension::TIME)
        }
        _ if symbol.eq_ignore_ascii_case("day") => (86_400.0, RelationDimension::TIME),
        _ if symbol.eq_ignore_ascii_case("deg") || symbol.eq_ignore_ascii_case("degree") => {
            (1.0, RelationDimension::ANGLE)
        }
        _ if symbol.eq_ignore_ascii_case("rad") || symbol.eq_ignore_ascii_case("radian") => {
            (180.0 / std::f64::consts::PI, RelationDimension::ANGLE)
        }
        _ if symbol.eq_ignore_ascii_case("n") || symbol.eq_ignore_ascii_case("newton") => {
            (1_000.0, RelationDimension::FORCE)
        }
        _ if symbol.eq_ignore_ascii_case("kn") => (1_000_000.0, RelationDimension::FORCE),
        _ if symbol.eq_ignore_ascii_case("dyne") => (0.01, RelationDimension::FORCE),
        _ if symbol.eq_ignore_ascii_case("lbf") => (4_448.221_615_260_5, RelationDimension::FORCE),
        _ if symbol.eq_ignore_ascii_case("ton") => (9_806_650.0, RelationDimension::FORCE),
        _ if symbol.eq_ignore_ascii_case("erg") => (
            0.1,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH, false)?,
        ),
        _ if symbol.eq_ignore_ascii_case("joule") => (
            1_000_000.0,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH, false)?,
        ),
        _ if symbol.eq_ignore_ascii_case("kw") => (
            1_000_000_000.0,
            RelationDimension::FORCE
                .combine(RelationDimension::LENGTH, false)?
                .combine(RelationDimension::TIME, true)?,
        ),
        "mW" => (
            1_000.0,
            RelationDimension::FORCE
                .combine(RelationDimension::LENGTH, false)?
                .combine(RelationDimension::TIME, true)?,
        ),
        "MW" => (
            1_000_000_000_000.0,
            RelationDimension::FORCE
                .combine(RelationDimension::LENGTH, false)?
                .combine(RelationDimension::TIME, true)?,
        ),
        _ if symbol.eq_ignore_ascii_case("pa") => (
            0.001,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH.scale(2)?, true)?,
        ),
        _ if symbol.eq_ignore_ascii_case("mpa") => (
            1_000.0,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH.scale(2)?, true)?,
        ),
        _ if symbol.eq_ignore_ascii_case("gpa") => (
            1_000_000.0,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH.scale(2)?, true)?,
        ),
        _ if symbol.eq_ignore_ascii_case("psi") => (
            6.894_757_293_168_361,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH.scale(2)?, true)?,
        ),
        _ if symbol.eq_ignore_ascii_case("ksi") => (
            6_894.757_293_168_361,
            RelationDimension::FORCE.combine(RelationDimension::LENGTH.scale(2)?, true)?,
        ),
        _ => return None,
    })
}

trait ExpressionValue: Sized + Clone {
    fn number(value: f64) -> Option<Self>;
    fn reserved(name: &str) -> Option<Self> {
        reserved_relation_scalar(name).and_then(Self::number)
    }
    fn string(_value: String) -> Option<Self> {
        None
    }
    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError>;
    fn finite(&self) -> bool;
    /// Bytes of string text this value holds, or `None` when it holds none.
    fn text_len(&self) -> Option<usize> {
        None
    }
}

impl ExpressionValue for f64 {
    fn number(value: f64) -> Option<Self> {
        Some(value)
    }

    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self + right))
    }

    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self * unit.scale + unit.offset))
    }

    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self - right))
    }

    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self * right))
    }

    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self / right))
    }

    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self.powf(right)))
    }

    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(f64::from(operator.evaluate(self, right))))
    }

    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(f64::from(self != 0.0 && right != 0.0)))
    }

    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(f64::from(self != 0.0 || right != 0.0)))
    }

    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(f64::from(self == 0.0)))
    }

    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        _context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            scope.is_none().then_some(())?;
            evaluate_creo_math_function(name, arguments)
        };
        Ok(arithmetic())
    }

    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(-self))
    }

    fn finite(&self) -> bool {
        self.is_finite()
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct AffineValue {
    constant: f64,
    linear: f64,
}

impl ExpressionValue for AffineValue {
    fn number(value: f64) -> Option<Self> {
        Some(Self {
            constant: value,
            linear: 0.0,
        })
    }

    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(Self {
            constant: self.constant + right.constant,
            linear: self.linear + right.linear,
        }))
    }

    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(Self {
            constant: self.constant * unit.scale + unit.offset,
            linear: self.linear * unit.scale,
        }))
    }

    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(Self {
            constant: self.constant - right.constant,
            linear: self.linear - right.linear,
        }))
    }

    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok((self.linear == 0.0 || right.linear == 0.0).then_some(Self {
            constant: self.constant * right.constant,
            linear: self.constant * right.linear + self.linear * right.constant,
        }))
    }

    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(
            (right.linear == 0.0 && right.constant != 0.0).then_some(Self {
                constant: self.constant / right.constant,
                linear: self.linear / right.constant,
            }),
        )
    }

    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            if right.linear == 0.0 && right.constant == 1.0 {
                return Some(self);
            }
            if right.linear == 0.0 && right.constant == 0.0 {
                return Self::number(1.0);
            }
            (self.linear == 0.0 && right.linear == 0.0)
                .then(|| self.constant.powf(right.constant))
                .filter(|value| value.is_finite())
                .and_then(Self::number)
        };
        Ok(arithmetic())
    }

    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok((self.linear == 0.0 && right.linear == 0.0)
            .then(|| Self::number(f64::from(operator.evaluate(self.constant, right.constant))))
            .flatten())
    }

    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok((self.linear == 0.0 && right.linear == 0.0)
            .then(|| Self::number(f64::from(self.constant != 0.0 && right.constant != 0.0)))
            .flatten())
    }

    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok((self.linear == 0.0 && right.linear == 0.0)
            .then(|| Self::number(f64::from(self.constant != 0.0 || right.constant != 0.0)))
            .flatten())
    }

    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok((self.linear == 0.0)
            .then(|| Self::number(f64::from(self.constant == 0.0)))
            .flatten())
    }

    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        _context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            scope.is_none().then_some(())?;
            let mut constants = [0.0; 3];
            if arguments.len() > constants.len() {
                return None;
            }
            for (slot, argument) in constants.iter_mut().zip(arguments) {
                (argument.linear == 0.0).then_some(())?;
                *slot = argument.constant;
            }
            evaluate_creo_math_function(name, &constants[..arguments.len()]).and_then(Self::number)
        };
        Ok(arithmetic())
    }

    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(Self {
            constant: -self.constant,
            linear: -self.linear,
        }))
    }

    fn finite(&self) -> bool {
        self.constant.is_finite() && self.linear.is_finite()
    }
}

#[derive(Debug, Clone, PartialEq)]
struct SimultaneousAffineValue {
    dimension: RelationDimension,
    constant: f64,
    coefficients: BTreeMap<String, f64>,
}

impl SimultaneousAffineValue {
    fn constant(value: f64, dimension: RelationDimension) -> Self {
        Self {
            dimension,
            constant: value,
            coefficients: BTreeMap::new(),
        }
    }

    fn scale(mut self, factor: f64) -> Self {
        self.constant *= factor;
        for coefficient in self.coefficients.values_mut() {
            *coefficient *= factor;
        }
        self
    }

    fn combine(mut self, right: Self, subtract: bool) -> Option<Self> {
        if self.dimension != right.dimension {
            return None;
        }
        let sign = if subtract { -1.0 } else { 1.0 };
        self.constant += sign * right.constant;
        for (variable, coefficient) in right.coefficients {
            match self.coefficients.entry(variable) {
                std::collections::btree_map::Entry::Occupied(mut entry) => {
                    let value = entry.get_mut();
                    *value += sign * coefficient;
                    if *value == 0.0 {
                        entry.remove();
                    }
                }
                std::collections::btree_map::Entry::Vacant(entry) => {
                    let value = sign * coefficient;
                    if value != 0.0 {
                        entry.insert(value);
                    }
                }
            }
        }
        Some(self)
    }

    fn as_curve_value(&self) -> Option<CurveExpressionValue> {
        self.coefficients
            .is_empty()
            .then(|| quantity_value(self.constant, self.dimension))
            .flatten()
    }

    fn constant_difference(&self, right: &Self) -> Option<f64> {
        if self.dimension != right.dimension {
            return None;
        }
        if self
            .coefficients
            .iter()
            .any(|(name, value)| *value != right.coefficients.get(name).map_or(0.0, |value| *value))
            || right.coefficients.iter().any(|(name, value)| {
                *value != self.coefficients.get(name).map_or(0.0, |value| *value)
            })
        {
            return None;
        }
        (self.constant - right.constant)
            .is_finite()
            .then_some(self.constant - right.constant)
    }

    fn constant_truth(&self) -> Option<bool> {
        (self.dimension == RelationDimension::default() && self.coefficients.is_empty())
            .then_some(self.constant != 0.0)
    }
}

impl ExpressionValue for SimultaneousAffineValue {
    fn number(value: f64) -> Option<Self> {
        Some(Self::constant(value, RelationDimension::default()))
    }

    fn reserved(name: &str) -> Option<Self> {
        let value = CurveExpressionValue::reserved(name)?;
        let (value, dimension) = quantity_parts_ref(&value)?;
        Some(Self::constant(value, dimension))
    }

    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        if scope.is_some() {
            return Ok(None);
        }
        match (name, arguments) {
            (CreoMathFunction::If, [condition, when_true, when_false]) => {
                if when_true.constant_difference(when_false) == Some(0.0) {
                    return Ok(Some(when_true.clone()));
                }
                let Some(CurveExpressionValue::Number(condition)) = condition.as_curve_value()
                else {
                    return Ok(None);
                };
                return Ok(Some(if condition.get() == 0.0 {
                    when_false.clone()
                } else {
                    when_true.clone()
                }));
            }
            (name @ (CreoMathFunction::Min | CreoMathFunction::Max), [left, right]) => {
                let Some(difference) = left.constant_difference(right) else {
                    return Ok(None);
                };
                let Some(selects_left) = extremum_selects_left(name, difference, 0.0) else {
                    return Ok(None);
                };
                return Ok(Some(if selects_left {
                    left.clone()
                } else {
                    right.clone()
                }));
            }
            (CreoMathFunction::Sign, [value, _])
                if value.coefficients.is_empty() && value.constant == 0.0 =>
            {
                return Ok(Some(value.clone()));
            }
            (CreoMathFunction::Bound, [value, lower, upper]) => {
                let Some(bounds_difference) = lower.constant_difference(upper) else {
                    return Ok(None);
                };
                if bounds_difference >= 0.0 {
                    return Ok(None);
                }
                let Some(lower_difference) = value.constant_difference(lower) else {
                    return Ok(None);
                };
                if lower_difference < 0.0 {
                    return Ok(Some(lower.clone()));
                }
                let Some(upper_difference) = value.constant_difference(upper) else {
                    return Ok(None);
                };
                return Ok(Some(if upper_difference > 0.0 {
                    upper.clone()
                } else {
                    value.clone()
                }));
            }
            (CreoMathFunction::Dead, [value, lower, upper]) => {
                let Some(bounds_difference) = lower.constant_difference(upper) else {
                    return Ok(None);
                };
                if bounds_difference > 0.0 {
                    return Ok(None);
                }
                let Some(lower_difference) = value.constant_difference(lower) else {
                    return Ok(None);
                };
                if lower_difference < 0.0 {
                    return Ok(value.clone().combine(lower.clone(), true));
                }
                let Some(upper_difference) = value.constant_difference(upper) else {
                    return Ok(None);
                };
                if upper_difference > 0.0 {
                    return Ok(value.clone().combine(upper.clone(), true));
                }
                return Ok(Some(Self::constant(0.0, value.dimension)));
            }
            (CreoMathFunction::Near | CreoMathFunction::DblInTol, [left, right, tolerance]) => {
                let Some(difference) = left.constant_difference(right) else {
                    return Ok(None);
                };
                let Some(tolerance_value) = tolerance.as_curve_value() else {
                    return Ok(None);
                };
                let Some((tolerance, tolerance_dimension)) = quantity_parts_ref(&tolerance_value)
                else {
                    return Ok(None);
                };
                if left.dimension != tolerance_dimension || tolerance < 0.0 {
                    return Ok(None);
                }
                return Ok(Self::number(f64::from(difference.abs() <= tolerance)));
            }
            (CreoMathFunction::Pow, [base, exponent]) => {
                return base.clone().power_checked(exponent.clone());
            }
            _ => {}
        }
        let mut numeric_arguments = Vec::new();
        for argument in arguments {
            let Some(value) = argument.as_curve_value() else {
                return Ok(None);
            };
            numeric_arguments.push(value);
        }
        if matches!(
            name,
            CreoMathFunction::Itos
                | CreoMathFunction::Rtos
                | CreoMathFunction::RelModelName
                | CreoMathFunction::RelModelType
        ) {
            return Ok(None);
        }
        let Some(result) =
            CurveExpressionValue::function_checked(name, None, &numeric_arguments, context)?
        else {
            return Ok(None);
        };
        let Some((value, dimension)) = quantity_parts_ref(&result) else {
            return Ok(None);
        };
        Ok(Some(Self::constant(value, dimension)))
    }

    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            (self.dimension == RelationDimension::default()).then_some(())?;
            let mut value = self.scale(unit.scale);
            value.dimension = unit.dimension;
            value.constant += unit.offset;
            Some(value)
        };
        Ok(arithmetic())
    }

    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(self.combine(right, false))
    }

    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(self.combine(right, true))
    }

    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            if self.coefficients.is_empty() {
                let dimension = self.dimension.combine(right.dimension, false)?;
                let mut result = right.scale(self.constant);
                result.dimension = dimension;
                Some(result)
            } else if right.coefficients.is_empty() {
                let dimension = self.dimension.combine(right.dimension, false)?;
                let mut result = self.scale(right.constant);
                result.dimension = dimension;
                Some(result)
            } else {
                None
            }
        };
        Ok(arithmetic())
    }

    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            (right.coefficients.is_empty() && right.constant != 0.0).then_some(())?;
            let dimension = self.dimension.combine(right.dimension, true)?;
            let mut result = self.scale(1.0 / right.constant);
            result.dimension = dimension;
            Some(result)
        };
        Ok(arithmetic())
    }

    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            if !right.coefficients.is_empty() || right.dimension != RelationDimension::default() {
                return None;
            }
            if right.constant == 1.0 {
                return Some(self);
            }
            if right.constant == 0.0 {
                return Self::number(1.0);
            }
            let value = self.as_curve_value()?;
            let exponent =
                CurveExpressionValue::Number(cadmpeg_ir::scalar::FiniteReal::new(right.constant)?);
            let result = quantity_power(&value, &exponent)?;
            let (value, dimension) = quantity_parts_ref(&result)?;
            value.is_finite().then(|| Self::constant(value, dimension))
        };
        Ok(arithmetic())
    }

    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let Some(difference) = self.constant_difference(&right) else {
            return Ok(None);
        };
        Ok(Self::number(f64::from(operator.evaluate(difference, 0.0))))
    }

    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            if self.constant_truth() == Some(false) || right.constant_truth() == Some(false) {
                return Self::number(0.0);
            }
            let left = self.as_curve_value()?;
            let right = right.as_curve_value()?;
            let CurveExpressionValue::Number(value) =
                numeric_binary(left, right, |left, right| {
                    f64::from(left != 0.0 && right != 0.0)
                })?
            else {
                return None;
            };
            Self::number(value.get())
        };
        Ok(arithmetic())
    }

    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            if self.constant_truth() == Some(true) || right.constant_truth() == Some(true) {
                return Self::number(1.0);
            }
            let left = self.as_curve_value()?;
            let right = right.as_curve_value()?;
            let CurveExpressionValue::Number(value) =
                numeric_binary(left, right, |left, right| {
                    f64::from(left != 0.0 || right != 0.0)
                })?
            else {
                return None;
            };
            Self::number(value.get())
        };
        Ok(arithmetic())
    }

    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let value = self.as_curve_value()?;
            let CurveExpressionValue::Number(value) = numeric_binary(
                value,
                CurveExpressionValue::Number(cadmpeg_ir::scalar::FiniteReal::ZERO),
                |left, _| f64::from(left == 0.0),
            )?
            else {
                return None;
            };
            Self::number(value.get())
        };
        Ok(arithmetic())
    }

    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(Some(self.scale(-1.0)))
    }

    fn finite(&self) -> bool {
        self.constant.is_finite() && self.coefficients.values().all(|value| value.is_finite())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct DimensionRational {
    numerator: i64,
    denominator: i64,
}

impl Default for DimensionRational {
    fn default() -> Self {
        Self {
            numerator: 0,
            denominator: 1,
        }
    }
}

impl DimensionRational {
    fn new(numerator: i64, denominator: i64) -> Option<Self> {
        (denominator != 0).then_some(())?;
        let (numerator, denominator) = if denominator < 0 {
            (numerator.checked_neg()?, denominator.checked_neg()?)
        } else {
            (numerator, denominator)
        };
        let mut left = numerator.unsigned_abs();
        let mut right = denominator.unsigned_abs();
        while right != 0 {
            let remainder = left % right;
            left = right;
            right = remainder;
        }
        let divisor = i64::try_from(left).ok()?;
        Some(Self {
            numerator: numerator / divisor,
            denominator: denominator / divisor,
        })
    }

    fn integer(value: i8) -> Self {
        Self {
            numerator: i64::from(value),
            denominator: 1,
        }
    }

    fn one() -> Self {
        Self {
            numerator: 1,
            denominator: 1,
        }
    }

    fn combine(self, right: Self, subtract: bool) -> Option<Self> {
        let sign = if subtract { -1 } else { 1 };
        let numerator = self.numerator.checked_mul(right.denominator)?.checked_add(
            right
                .numerator
                .checked_mul(self.denominator)?
                .checked_mul(sign)?,
        )?;
        let denominator = self.denominator.checked_mul(right.denominator)?;
        Self::new(numerator, denominator)
    }

    fn scale(self, factor: i8) -> Option<Self> {
        Self::new(
            self.numerator.checked_mul(i64::from(factor))?,
            self.denominator,
        )
    }

    fn divide(self, divisor: i16) -> Option<Self> {
        let divisor = i64::from(divisor);
        (divisor != 0).then_some(())?;
        Self::new(self.numerator, self.denominator.checked_mul(divisor)?)
    }

    fn as_f64(self) -> Option<f64> {
        Some(
            cadmpeg_core::convert::f64_from_i64(self.numerator)?
                / cadmpeg_core::convert::f64_from_i64(self.denominator)?,
        )
    }

    fn is_zero(self) -> bool {
        self.numerator == 0
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct DimensionForm {
    constant: DimensionRational,
    variables: BTreeMap<String, DimensionRational>,
}

impl DimensionForm {
    fn combine(mut self, right: Self, subtract: bool) -> Option<Self> {
        self.constant = self.constant.combine(right.constant, subtract)?;
        for (name, coefficient) in right.variables {
            if let Some(value) = self.variables.get_mut(&name) {
                *value = (*value).combine(coefficient, subtract)?;
                if value.is_zero() {
                    self.variables.remove(&name);
                }
            } else {
                let value = DimensionRational::default().combine(coefficient, subtract)?;
                if !value.is_zero() {
                    self.variables.insert(name, value);
                }
            }
        }
        Some(self)
    }

    fn constant(value: i8) -> Self {
        Self {
            constant: DimensionRational::integer(value),
            variables: BTreeMap::new(),
        }
    }

    fn variable(name: String) -> Self {
        Self {
            constant: DimensionRational::default(),
            variables: BTreeMap::from([(name, DimensionRational::one())]),
        }
    }

    fn scale(mut self, factor: i8) -> Option<Self> {
        self.constant = self.constant.scale(factor)?;
        for coefficient in self.variables.values_mut() {
            *coefficient = (*coefficient).scale(factor)?;
        }
        self.variables
            .retain(|_, coefficient| !coefficient.is_zero());
        Some(self)
    }

    fn divide_exact(mut self, divisor: i16) -> Option<Self> {
        self.constant = self.constant.divide(divisor)?;
        for coefficient in self.variables.values_mut() {
            *coefficient = (*coefficient).divide(divisor)?;
        }
        self.variables
            .retain(|_, coefficient| !coefficient.is_zero());
        Some(self)
    }

    fn is_zero(&self) -> bool {
        self.constant.is_zero() && self.variables.is_empty()
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct SymbolicRelationDimension {
    axes: [DimensionForm; 5],
}

impl SymbolicRelationDimension {
    fn from_relation_dimension(dimension: RelationDimension) -> Self {
        Self {
            axes: [
                DimensionForm::constant(dimension.length),
                DimensionForm::constant(dimension.mass),
                DimensionForm::constant(dimension.time),
                DimensionForm::constant(dimension.angle),
                DimensionForm::constant(dimension.temperature),
            ],
        }
    }

    fn variable(name: &str) -> Self {
        Self {
            axes: [
                DimensionForm::variable(dimension_variable_key(name, 0)),
                DimensionForm::variable(dimension_variable_key(name, 1)),
                DimensionForm::variable(dimension_variable_key(name, 2)),
                DimensionForm::variable(dimension_variable_key(name, 3)),
                DimensionForm::variable(dimension_variable_key(name, 4)),
            ],
        }
    }

    fn combine(self, right: Self, subtract: bool) -> Option<Self> {
        let [left_length, left_mass, left_time, left_angle, left_temperature] = self.axes;
        let [right_length, right_mass, right_time, right_angle, right_temperature] = right.axes;
        let length = left_length.combine(right_length, subtract)?;
        let mass = left_mass.combine(right_mass, subtract)?;
        let time = left_time.combine(right_time, subtract)?;
        let angle = left_angle.combine(right_angle, subtract)?;
        let temperature = left_temperature.combine(right_temperature, subtract)?;
        Some(Self {
            axes: [length, mass, time, angle, temperature],
        })
    }

    fn scale(self, factor: i8) -> Option<Self> {
        let [length, mass, time, angle, temperature] = self.axes;
        Some(Self {
            axes: [
                length.scale(factor)?,
                mass.scale(factor)?,
                time.scale(factor)?,
                angle.scale(factor)?,
                temperature.scale(factor)?,
            ],
        })
    }

    fn root(self, degree: i16) -> Option<Self> {
        (degree > 0).then_some(())?;
        let [length, mass, time, angle, temperature] = self.axes;
        Some(Self {
            axes: [
                length.divide_exact(degree)?,
                mass.divide_exact(degree)?,
                time.divide_exact(degree)?,
                angle.divide_exact(degree)?,
                temperature.divide_exact(degree)?,
            ],
        })
    }

    fn is_zero(&self) -> bool {
        self.axes.iter().all(DimensionForm::is_zero)
    }
}

fn dimension_variable_key(name: &str, axis: usize) -> String {
    format!("{name}#{axis}")
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct DimensionEquality {
    left: SymbolicRelationDimension,
    right: SymbolicRelationDimension,
}

#[derive(Debug, Clone)]
enum DimensionProbeKind {
    Numeric(Option<f64>),
    Text(Option<String>),
}

enum DimensionProbeNumber {
    Unknown,
    Known(f64),
}

impl DimensionProbeNumber {
    fn into_option(self) -> Option<f64> {
        match self {
            Self::Unknown => None,
            Self::Known(value) => Some(value),
        }
    }
}

#[derive(Debug, Clone)]
struct DimensionProbeValue {
    dimension: SymbolicRelationDimension,
    kind: DimensionProbeKind,
    constraints: Vec<DimensionEquality>,
}

impl DimensionProbeValue {
    fn numeric(value: Option<f64>) -> Self {
        Self {
            dimension: SymbolicRelationDimension::default(),
            kind: DimensionProbeKind::Numeric(value),
            constraints: Vec::new(),
        }
    }

    fn text(value: Option<String>) -> Self {
        Self {
            dimension: SymbolicRelationDimension::default(),
            kind: DimensionProbeKind::Text(value),
            constraints: Vec::new(),
        }
    }

    fn variable(name: &str) -> Self {
        Self {
            dimension: SymbolicRelationDimension::variable(name),
            kind: DimensionProbeKind::Numeric(None),
            constraints: Vec::new(),
        }
    }

    fn from_relation_value(value: &CurveExpressionValue) -> Option<Self> {
        match value {
            CurveExpressionValue::String(_) => None,
            value => {
                let (value, dimension) = quantity_parts_ref(value)?;
                Some(Self {
                    dimension: SymbolicRelationDimension::from_relation_dimension(dimension),
                    kind: DimensionProbeKind::Numeric(Some(value)),
                    constraints: Vec::new(),
                })
            }
        }
    }

    fn numeric_value(&self) -> Option<f64> {
        match &self.kind {
            DimensionProbeKind::Numeric(value) => *value,
            DimensionProbeKind::Text(_) => None,
        }
    }

    fn text_value(&self) -> Option<&str> {
        match &self.kind {
            DimensionProbeKind::Text(Some(value)) => Some(value),
            DimensionProbeKind::Numeric(_) | DimensionProbeKind::Text(None) => None,
        }
    }

    fn with_constraint(
        mut self,
        left: SymbolicRelationDimension,
        right: SymbolicRelationDimension,
    ) -> Self {
        self.constraints.push(DimensionEquality { left, right });
        self
    }

    fn constrain_to(self, dimension: SymbolicRelationDimension) -> Self {
        let current = self.dimension.clone();
        self.with_constraint(current, dimension)
    }

    fn merge_constraints(left: &Self, right: &Self) -> Vec<DimensionEquality> {
        let mut constraints = Vec::new();
        for constraint in left.constraints.iter().chain(&right.constraints) {
            constraints.push(constraint.clone());
        }
        constraints
    }

    fn argument_constraints(arguments: &[Self]) -> Vec<DimensionEquality> {
        let mut constraints = Vec::new();
        for constraint in arguments.iter().flat_map(|argument| &argument.constraints) {
            constraints.push(constraint.clone());
        }
        constraints
    }

    fn push_constraint(
        constraints: &mut Vec<DimensionEquality>,
        left: &SymbolicRelationDimension,
        right: &SymbolicRelationDimension,
    ) {
        constraints.push(DimensionEquality {
            left: left.clone(),
            right: right.clone(),
        });
    }

    fn numeric_result(
        dimension: SymbolicRelationDimension,
        value: Option<f64>,
        constraints: Vec<DimensionEquality>,
    ) -> Self {
        Self {
            dimension,
            kind: DimensionProbeKind::Numeric(value),
            constraints,
        }
    }

    fn text_result(value: Option<String>, constraints: Vec<DimensionEquality>) -> Self {
        Self {
            dimension: SymbolicRelationDimension::default(),
            kind: DimensionProbeKind::Text(value),
            constraints,
        }
    }

    fn optional_math(name: CreoMathFunction, arguments: &[Self]) -> Option<DimensionProbeNumber> {
        let mut values = [0.0; 3];
        for (index, argument) in arguments.iter().enumerate() {
            let slot = values.get_mut(index)?;
            let Some(value) = argument.numeric_value() else {
                return Some(DimensionProbeNumber::Unknown);
            };
            *slot = value;
        }
        evaluate_creo_math_function(name, &values[..arguments.len()])
            .map(DimensionProbeNumber::Known)
    }

    fn optional_round(
        value: &Self,
        decimal_places: Option<&Self>,
        upward: bool,
    ) -> Option<DimensionProbeNumber> {
        let Some(value) = value.numeric_value() else {
            return Some(DimensionProbeNumber::Unknown);
        };
        let decimal_places = match decimal_places {
            Some(decimal_places) => {
                let Some(decimal_places) = decimal_places.numeric_value() else {
                    return Some(DimensionProbeNumber::Unknown);
                };
                decimal_places
            }
            None => 0.0,
        };
        relation_round(value, decimal_places, upward).map(DimensionProbeNumber::Known)
    }
}

impl DimensionProbeValue {
    fn numeric_function_checked(
        name: CreoMathFunction,
        arguments: &[Self],
        mut constraints: Vec<DimensionEquality>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let numeric =
            |name| Self::optional_math(name, arguments).map(DimensionProbeNumber::into_option);
        match (name, arguments) {
            (
                name @ (CreoMathFunction::Sin | CreoMathFunction::Cos | CreoMathFunction::Tan),
                [argument],
            ) => {
                Self::push_constraint(
                    &mut constraints,
                    &argument.dimension,
                    &SymbolicRelationDimension::from_relation_dimension(RelationDimension::ANGLE),
                );
                let Some(value) = numeric(name) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            (
                name @ (CreoMathFunction::Asin | CreoMathFunction::Acos | CreoMathFunction::Atan),
                [argument],
            ) => {
                Self::push_constraint(
                    &mut constraints,
                    &argument.dimension,
                    &SymbolicRelationDimension::default(),
                );
                let Some(value) = numeric(name) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::from_relation_dimension(RelationDimension::ANGLE),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::Atan2, [left, right]) => {
                Self::push_constraint(&mut constraints, &left.dimension, &right.dimension);
                let Some(value) = numeric(CreoMathFunction::Atan2) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::from_relation_dimension(RelationDimension::ANGLE),
                    value,
                    constraints,
                )))
            }
            (
                name @ (CreoMathFunction::Sinh
                | CreoMathFunction::Cosh
                | CreoMathFunction::Tanh
                | CreoMathFunction::Log
                | CreoMathFunction::Ln
                | CreoMathFunction::Exp),
                [argument],
            ) => {
                Self::push_constraint(
                    &mut constraints,
                    &argument.dimension,
                    &SymbolicRelationDimension::default(),
                );
                let Some(value) = numeric(name) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::Sign, [value, sign]) => {
                let numeric_value =
                    value
                        .numeric_value()
                        .zip(sign.numeric_value())
                        .map(|(value, sign)| {
                            if sign < 0.0 {
                                -value.abs()
                            } else {
                                value.abs()
                            }
                        });
                Ok(Some(Self::numeric_result(
                    value.dimension.clone(),
                    numeric_value,
                    constraints,
                )))
            }
            (CreoMathFunction::Mod, [left, right]) => {
                Self::push_constraint(&mut constraints, &left.dimension, &right.dimension);
                if right.numeric_value().is_some_and(|value| value == 0.0) {
                    return Ok(None);
                }
                let value = left
                    .numeric_value()
                    .zip(right.numeric_value())
                    .map(|(left, right)| left % right);
                Ok(Some(Self::numeric_result(
                    left.dimension.clone(),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::If, [condition, when_true, when_false]) => {
                Self::push_constraint(
                    &mut constraints,
                    &condition.dimension,
                    &SymbolicRelationDimension::default(),
                );
                match (&when_true.kind, &when_false.kind) {
                    (DimensionProbeKind::Text(left), DimensionProbeKind::Text(right)) => {
                        let value = match condition
                            .numeric_value()
                            .zip(left.as_ref().zip(right.as_ref()))
                        {
                            Some((condition, (left, right))) => {
                                let selected = if condition == 0.0 { right } else { left };
                                Some(selected.to_owned())
                            }
                            None => None,
                        };
                        Ok(Some(Self::text_result(value, constraints)))
                    }
                    (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right)) => {
                        Self::push_constraint(
                            &mut constraints,
                            &when_true.dimension,
                            &when_false.dimension,
                        );
                        let value = condition.numeric_value().zip(left.zip(*right)).map(
                            |(condition, (left, right))| {
                                if condition == 0.0 {
                                    right
                                } else {
                                    left
                                }
                            },
                        );
                        Ok(Some(Self::numeric_result(
                            when_true.dimension.clone(),
                            value,
                            constraints,
                        )))
                    }
                    _ => Ok(None),
                }
            }
            (CreoMathFunction::Bound | CreoMathFunction::Dead, [value, lower, upper]) => {
                Self::push_constraint(&mut constraints, &value.dimension, &lower.dimension);
                Self::push_constraint(&mut constraints, &value.dimension, &upper.dimension);
                let numeric = value
                    .numeric_value()
                    .zip(lower.numeric_value())
                    .zip(upper.numeric_value())
                    .and_then(|((value, lower), upper)| {
                        if name == CreoMathFunction::Bound {
                            if lower >= upper {
                                return None;
                            }
                            Some(if value < lower {
                                lower
                            } else if value > upper {
                                upper
                            } else {
                                value
                            })
                        } else {
                            if lower > upper {
                                return None;
                            }
                            Some(if value < lower {
                                value - lower
                            } else if value > upper {
                                value - upper
                            } else {
                                0.0
                            })
                        }
                    });
                Ok(Some(Self::numeric_result(
                    value.dimension.clone(),
                    numeric,
                    constraints,
                )))
            }
            (CreoMathFunction::Near | CreoMathFunction::DblInTol, [left, right, tolerance]) => {
                Self::push_constraint(&mut constraints, &left.dimension, &right.dimension);
                Self::push_constraint(&mut constraints, &left.dimension, &tolerance.dimension);
                let numeric = left
                    .numeric_value()
                    .zip(right.numeric_value())
                    .zip(tolerance.numeric_value())
                    .and_then(|((left, right), tolerance)| {
                        (tolerance >= 0.0).then_some(f64::from((left - right).abs() <= tolerance))
                    });
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    numeric,
                    constraints,
                )))
            }
            (name @ (CreoMathFunction::Min | CreoMathFunction::Max), [left, right]) => {
                Self::push_constraint(&mut constraints, &left.dimension, &right.dimension);
                let numeric =
                    left.numeric_value()
                        .zip(right.numeric_value())
                        .map(|(left, right)| {
                            if extremum_selects_left(name, left, right) == Some(true) {
                                left
                            } else {
                                right
                            }
                        });
                Ok(Some(Self::numeric_result(
                    left.dimension.clone(),
                    numeric,
                    constraints,
                )))
            }
            (CreoMathFunction::Pow, [base, exponent]) => {
                base.clone().power_checked(exponent.clone())
            }
            (CreoMathFunction::Sqrt, [argument]) => {
                let Some(dimension) = argument.dimension.clone().root(2) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    dimension,
                    argument.numeric_value().map(f64::sqrt),
                    constraints,
                )))
            }
            (CreoMathFunction::Abs, [argument]) => Ok(Some(Self::numeric_result(
                argument.dimension.clone(),
                argument.numeric_value().map(f64::abs),
                constraints,
            ))),
            (CreoMathFunction::Ceil | CreoMathFunction::Floor, [argument]) => {
                let Some(value) =
                    Self::optional_round(argument, None, name == CreoMathFunction::Ceil)
                else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    argument.dimension.clone(),
                    value.into_option(),
                    constraints,
                )))
            }
            (CreoMathFunction::Ceil | CreoMathFunction::Floor, [argument, decimal_places]) => {
                let decimal_places = decimal_places
                    .clone()
                    .constrain_to(SymbolicRelationDimension::default());
                for constraint in &decimal_places.constraints {
                    constraints.push(constraint.clone());
                }
                let Some(value) = Self::optional_round(
                    argument,
                    Some(&decimal_places),
                    name == CreoMathFunction::Ceil,
                ) else {
                    return Ok(None);
                };
                Ok(Some(Self::numeric_result(
                    argument.dimension.clone(),
                    value.into_option(),
                    constraints,
                )))
            }
            _ => Ok(None),
        }
    }
}

impl ExpressionValue for DimensionProbeValue {
    fn number(value: f64) -> Option<Self> {
        Some(Self::numeric(Some(value)))
    }

    fn reserved(name: &str) -> Option<Self> {
        Self::from_relation_value(&CurveExpressionValue::reserved(name)?)
    }

    fn string(value: String) -> Option<Self> {
        Some(Self::text(Some(value)))
    }

    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let Self {
            dimension,
            kind: DimensionProbeKind::Numeric(value),
            mut constraints,
        } = self
        else {
            return Ok(None);
        };
        constraints.push(DimensionEquality {
            left: dimension,
            right: SymbolicRelationDimension::default(),
        });
        let value = value
            .map(|value| value * unit.scale + unit.offset)
            .filter(|value| value.is_finite());
        Ok(Some(Self::numeric_result(
            SymbolicRelationDimension::from_relation_dimension(unit.dimension),
            value,
            constraints,
        )))
    }

    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        match (&self.kind, &right.kind) {
            (DimensionProbeKind::Text(left), DimensionProbeKind::Text(right_value)) => {
                let constraints = Self::merge_constraints(&self, &right);
                let value = match left.as_ref().zip(right_value.as_ref()) {
                    Some((left, right)) => {
                        let mut value = left.to_owned();
                        value.push_str(right);
                        Some(value)
                    }
                    None => None,
                };
                Ok(Some(Self::text_result(value, constraints)))
            }
            (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) => {
                let mut constraints = Self::merge_constraints(&self, &right);
                Self::push_constraint(&mut constraints, &self.dimension, &right.dimension);
                Ok(Some(Self::numeric_result(
                    self.dimension.clone(),
                    (*left).zip(*right_value).map(|(left, right)| left + right),
                    constraints,
                )))
            }
            _ => Ok(None),
        }
    }

    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) =
            (&self.kind, &right.kind)
        else {
            return Ok(None);
        };
        let mut constraints = Self::merge_constraints(&self, &right);
        Self::push_constraint(&mut constraints, &self.dimension, &right.dimension);
        Ok(Some(Self::numeric_result(
            self.dimension.clone(),
            (*left).zip(*right_value).map(|(left, right)| left - right),
            constraints,
        )))
    }

    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) =
            (&self.kind, &right.kind)
        else {
            return Ok(None);
        };
        let constraints = Self::merge_constraints(&self, &right);
        let value = (*left).zip(*right_value).map(|(left, right)| left * right);
        let Some(dimension) = self.dimension.combine(right.dimension, false) else {
            return Ok(None);
        };
        Ok(Some(Self::numeric_result(dimension, value, constraints)))
    }

    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) =
            (&self.kind, &right.kind)
        else {
            return Ok(None);
        };
        if right_value.is_some_and(|value| value == 0.0) {
            return Ok(None);
        }
        let constraints = Self::merge_constraints(&self, &right);
        let value = (*left).zip(*right_value).map(|(left, right)| left / right);
        let Some(dimension) = self.dimension.combine(right.dimension, true) else {
            return Ok(None);
        };
        Ok(Some(Self::numeric_result(dimension, value, constraints)))
    }

    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let DimensionProbeKind::Numeric(exponent) = &right.kind else {
            return Ok(None);
        };
        let mut constraints = Self::merge_constraints(&self, &right);
        Self::push_constraint(
            &mut constraints,
            &right.dimension,
            &SymbolicRelationDimension::default(),
        );
        let value = self
            .numeric_value()
            .zip(*exponent)
            .map(|(value, exponent)| value.powf(exponent));
        let base_dimension = self.dimension;
        let dimension = match exponent {
            Some(exponent) if exponent.fract() == 0.0 => {
                if *exponent < f64::from(i8::MIN) || *exponent > f64::from(i8::MAX) {
                    return Ok(None);
                }
                let Some(dimension) = base_dimension.scale(
                    i8::try_from(
                        cadmpeg_core::convert::truncate_f64_to_i32(*exponent).ok_or_else(|| {
                            cadmpeg_core::CodecError::malformed(
                                "Creo numeric value cannot be represented exactly",
                            )
                        })?,
                    )
                    .map_err(|_| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value exceeds dimension range",
                        )
                    })?,
                ) else {
                    return Ok(None);
                };
                dimension
            }
            Some(_) if base_dimension.is_zero() => SymbolicRelationDimension::default(),
            Some(_) => return Ok(None),
            None if base_dimension.is_zero() => SymbolicRelationDimension::default(),
            None => return Ok(None),
        };
        Ok(Some(Self::numeric_result(dimension, value, constraints)))
    }

    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        match (&self.kind, &right.kind) {
            (DimensionProbeKind::Text(left), DimensionProbeKind::Text(right_value)) => {
                let value = match operator {
                    ComparisonOperator::Equal => left
                        .as_ref()
                        .zip(right_value.as_ref())
                        .map(|(left, right)| f64::from(left == right)),
                    ComparisonOperator::NotEqual => left
                        .as_ref()
                        .zip(right_value.as_ref())
                        .map(|(left, right)| f64::from(left != right)),
                    _ => return Ok(None),
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    Self::merge_constraints(&self, &right),
                )))
            }
            (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) => {
                let mut constraints = Self::merge_constraints(&self, &right);
                Self::push_constraint(&mut constraints, &self.dimension, &right.dimension);
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    (*left)
                        .zip(*right_value)
                        .map(|(left, right)| f64::from(operator.evaluate(left, right))),
                    constraints,
                )))
            }
            _ => Ok(None),
        }
    }

    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) =
            (&self.kind, &right.kind)
        else {
            return Ok(None);
        };
        let mut constraints = Self::merge_constraints(&self, &right);
        Self::push_constraint(
            &mut constraints,
            &self.dimension,
            &SymbolicRelationDimension::default(),
        );
        Self::push_constraint(
            &mut constraints,
            &right.dimension,
            &SymbolicRelationDimension::default(),
        );
        Ok(Some(Self::numeric_result(
            SymbolicRelationDimension::default(),
            (*left)
                .zip(*right_value)
                .map(|(left, right)| f64::from(left != 0.0 && right != 0.0)),
            constraints,
        )))
    }

    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let (DimensionProbeKind::Numeric(left), DimensionProbeKind::Numeric(right_value)) =
            (&self.kind, &right.kind)
        else {
            return Ok(None);
        };
        let mut constraints = Self::merge_constraints(&self, &right);
        Self::push_constraint(
            &mut constraints,
            &self.dimension,
            &SymbolicRelationDimension::default(),
        );
        Self::push_constraint(
            &mut constraints,
            &right.dimension,
            &SymbolicRelationDimension::default(),
        );
        Ok(Some(Self::numeric_result(
            SymbolicRelationDimension::default(),
            (*left)
                .zip(*right_value)
                .map(|(left, right)| f64::from(left != 0.0 || right != 0.0)),
            constraints,
        )))
    }

    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let DimensionProbeKind::Numeric(value) = self.kind else {
            return Ok(None);
        };
        let mut constraints = self.constraints;
        constraints.push(DimensionEquality {
            left: self.dimension,
            right: SymbolicRelationDimension::default(),
        });
        Ok(Some(Self::numeric_result(
            SymbolicRelationDimension::default(),
            value.map(|value| f64::from(value == 0.0)),
            constraints,
        )))
    }

    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        if scope.is_some() {
            return Ok(None);
        }
        let mut constraints = Self::argument_constraints(arguments);
        match (name, arguments) {
            (CreoMathFunction::Itos, [argument]) => {
                let value = match argument.numeric_value().map(f64::round) {
                    Some(0.0) => Some(String::new()),
                    Some(value) => Some(format!("{value:.0}")),
                    None => None,
                };
                Ok(Some(Self::text_result(value, constraints)))
            }
            (CreoMathFunction::Rtos, [argument, controls @ ..]) => {
                let mut values = [0.0; 2];
                for (index, control) in controls.iter().enumerate() {
                    let Some(slot) = values.get_mut(index) else {
                        return Ok(None);
                    };
                    let control = control
                        .clone()
                        .constrain_to(SymbolicRelationDimension::default());
                    for constraint in &control.constraints {
                        constraints.push(constraint.clone());
                    }
                    let Some(value) = control.numeric_value() else {
                        return Ok(None);
                    };
                    *slot = value;
                }
                let (decimals, scientific) = match controls.len() {
                    0 => (None, false),
                    1 => {
                        let Some(decimals) = relation_precision(values[0]) else {
                            return Ok(None);
                        };
                        (Some(decimals), false)
                    }
                    2 => {
                        let Some(decimals) = relation_precision(values[0]) else {
                            return Ok(None);
                        };
                        (Some(decimals), values[1] != 0.0)
                    }
                    _ => return Ok(None),
                };
                let value = match argument.numeric_value() {
                    Some(value) => format_relation_real(value, decimals, scientific),
                    None => None,
                };
                Ok(Some(Self::text_result(value, constraints)))
            }
            (CreoMathFunction::RelModelName, []) => Ok(Some(Self::text_result(
                context.model_name.map(std::borrow::ToOwned::to_owned),
                constraints,
            ))),
            (CreoMathFunction::RelModelType, []) => Ok(Some(Self::text_result(
                Some("part".to_owned()),
                constraints,
            ))),
            (CreoMathFunction::Exists, [argument]) => {
                let value = match (argument.text_value(), context.existing_symbols) {
                    (Some(name), Some(symbols)) => {
                        let mut key = name.to_string();
                        key.make_ascii_lowercase();
                        symbols.contains(&key).then_some(1.0)
                    }
                    _ => None,
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::Search, [value, needle]) => {
                let value = match value.text_value().zip(needle.text_value()) {
                    Some((value, needle)) => Some(
                        cadmpeg_core::convert::f64_from_index(
                            value
                                .find(needle)
                                .map_or(0, |byte| value[..byte].chars().count() + 1),
                        )
                        .ok_or_else(|| {
                            cadmpeg_core::CodecError::malformed(
                                "Creo numeric value cannot be represented exactly",
                            )
                        })?,
                    ),
                    None => None,
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::Extract, [value, position, length]) => {
                for control in [position, length] {
                    let control = control
                        .clone()
                        .constrain_to(SymbolicRelationDimension::default());
                    for constraint in &control.constraints {
                        constraints.push(constraint.clone());
                    }
                }
                let value =
                    match value
                        .text_value()
                        .zip(position.numeric_value())
                        .zip(length.numeric_value())
                    {
                        Some(((value, position), length)) => {
                            if !position.is_finite()
                                || !length.is_finite()
                                || position.fract() != 0.0
                                || length.fract() != 0.0
                                || position <= 0.0
                                || length < 0.0
                            {
                                return Ok(None);
                            }
                            let character_count = value.chars().count();
                            if position
                                > cadmpeg_core::convert::f64_from_index(character_count)
                                    .ok_or_else(|| {
                                        cadmpeg_core::CodecError::malformed(
                                            "Creo numeric value cannot be represented exactly",
                                        )
                                    })?
                            {
                                Some(String::new())
                            } else {
                                let start = cadmpeg_core::convert::truncate_f64_to_usize(position)
                                    .ok_or_else(|| {
                                        cadmpeg_core::CodecError::malformed(
                                            "Creo numeric value cannot be represented exactly",
                                        )
                                    })?
                                    - 1;
                                let remaining = character_count - start;
                                let count = if length
                                    >= cadmpeg_core::convert::f64_from_index(remaining).ok_or_else(
                                        || {
                                            cadmpeg_core::CodecError::malformed(
                                                "Creo numeric value cannot be represented exactly",
                                            )
                                        },
                                    )? {
                                    remaining
                                } else {
                                    cadmpeg_core::convert::truncate_f64_to_usize(length)
                                        .ok_or_else(|| {
                                            cadmpeg_core::CodecError::malformed(
                                                "Creo numeric value cannot be represented exactly",
                                            )
                                        })?
                                };
                                let start_byte = value
                                    .char_indices()
                                    .nth(start)
                                    .map_or(value.len(), |(at, _)| at);
                                let end_byte = value[start_byte..]
                                    .char_indices()
                                    .nth(count)
                                    .map_or(value.len(), |(at, _)| start_byte + at);
                                Some(value[start_byte..end_byte].to_owned())
                            }
                        }
                        None => None,
                    };
                Ok(Some(Self::text_result(value, constraints)))
            }
            (CreoMathFunction::StringLength, [value]) => {
                let value = match value.text_value() {
                    Some(value) => Some(
                        cadmpeg_core::convert::f64_from_index(value.chars().count()).ok_or_else(
                            || {
                                cadmpeg_core::CodecError::malformed(
                                    "Creo numeric value cannot be represented exactly",
                                )
                            },
                        )?,
                    ),
                    None => None,
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            (CreoMathFunction::StringStarts, [value, prefix]) => Ok(Some(Self::numeric_result(
                SymbolicRelationDimension::default(),
                value
                    .text_value()
                    .zip(prefix.text_value())
                    .map(|(value, prefix)| f64::from(value.starts_with(prefix))),
                constraints,
            ))),
            (CreoMathFunction::StringEnds, [value, suffix]) => Ok(Some(Self::numeric_result(
                SymbolicRelationDimension::default(),
                value
                    .text_value()
                    .zip(suffix.text_value())
                    .map(|(value, suffix)| f64::from(value.ends_with(suffix))),
                constraints,
            ))),
            (CreoMathFunction::StringMatch, [value, expected]) => Ok(Some(Self::numeric_result(
                SymbolicRelationDimension::default(),
                value
                    .text_value()
                    .zip(expected.text_value())
                    .map(|(value, expected)| f64::from(value == expected)),
                constraints,
            ))),
            (CreoMathFunction::StringPattern, [value, pattern]) => {
                let value = match value.text_value().zip(pattern.text_value()) {
                    Some((value, pattern)) => {
                        relation_string_pattern(value, pattern).map(f64::from)
                    }
                    None => None,
                };
                Ok(Some(Self::numeric_result(
                    SymbolicRelationDimension::default(),
                    value,
                    constraints,
                )))
            }
            _ => Self::numeric_function_checked(name, arguments, constraints),
        }
    }

    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let kind = match self.kind {
                DimensionProbeKind::Numeric(value) => {
                    DimensionProbeKind::Numeric(value.map(|v| -v))
                }
                DimensionProbeKind::Text(_) => return None,
            };
            Some(Self {
                dimension: self.dimension,
                kind,
                constraints: self.constraints,
            })
        };
        Ok(arithmetic())
    }

    fn finite(&self) -> bool {
        match &self.kind {
            DimensionProbeKind::Numeric(Some(value)) => value.is_finite(),
            DimensionProbeKind::Numeric(None) | DimensionProbeKind::Text(_) => true,
        }
    }

    fn text_len(&self) -> Option<usize> {
        self.text_value().map(str::len)
    }
}

impl ExpressionValue for CurveExpressionValue {
    fn number(value: f64) -> Option<Self> {
        cadmpeg_ir::scalar::FiniteReal::new(value).map(Self::Number)
    }

    fn string(value: String) -> Option<Self> {
        Some(Self::String(value))
    }

    fn reserved(name: &str) -> Option<Self> {
        if name.eq_ignore_ascii_case("g") {
            quantity_value(9_800.0, RelationDimension::ACCELERATION)
        } else {
            reserved_relation_scalar(name).and_then(Self::number)
        }
    }

    fn with_unit_checked(
        self,
        unit: RelationUnit,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let Self::Number(value) = self else {
                return None;
            };
            quantity_value(value.get() * unit.scale + unit.offset, unit.dimension)
        };
        Ok(arithmetic())
    }

    fn add_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(match (self, right) {
            (Self::String(mut left), Self::String(right)) => {
                left.push_str(&right);
                Some(Self::String(left))
            }
            (left, right) => quantity_additive(&left, &right, |left, right| left + right),
        })
    }

    fn subtract_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(quantity_additive(&self, &right, |left, right| left - right))
    }

    fn multiply_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let (left, left_dimension) = quantity_parts_ref(&self)?;
            let (right, right_dimension) = quantity_parts_ref(&right)?;
            quantity_value(
                left * right,
                left_dimension.combine(right_dimension, false)?,
            )
        };
        Ok(arithmetic())
    }

    fn divide_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let (left, left_dimension) = quantity_parts_ref(&self)?;
            let (right, right_dimension) = quantity_parts_ref(&right)?;
            quantity_value(left / right, left_dimension.combine(right_dimension, true)?)
        };
        Ok(arithmetic())
    }

    fn power_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(quantity_power(&self, &right))
    }

    fn compare_checked(
        self,
        right: Self,
        operator: ComparisonOperator,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let result = match (self, right) {
                (Self::Number(left), Self::Number(right)) => {
                    operator.evaluate(left.get(), right.get())
                }
                (Self::String(left), Self::String(right)) => match operator {
                    ComparisonOperator::Equal => left == right,
                    ComparisonOperator::NotEqual => left != right,
                    _ => return None,
                },
                (left, right) => {
                    let (left, left_dimension) = quantity_parts_ref(&left)?;
                    let (right, right_dimension) = quantity_parts_ref(&right)?;
                    (left_dimension == right_dimension).then_some(())?;
                    operator.evaluate(left, right)
                }
            };
            Self::number(f64::from(result))
        };
        Ok(arithmetic())
    }

    fn logical_and_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(numeric_binary(self, right, |left, right| {
            f64::from(left != 0.0 && right != 0.0)
        }))
    }

    fn logical_or_checked(self, right: Self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(numeric_binary(self, right, |left, right| {
            f64::from(left != 0.0 || right != 0.0)
        }))
    }

    fn logical_not_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        let arithmetic = || {
            let Self::Number(value) = self else {
                return None;
            };
            Self::number(f64::from(value.get() == 0.0))
        };
        Ok(arithmetic())
    }

    fn function_checked(
        name: CreoMathFunction,
        scope: Option<&str>,
        arguments: &[Self],
        context: RelationEvaluationContext<'_>,
    ) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        use CurveExpressionValue::{Number, String};
        if scope.is_some() {
            return Ok(None);
        }
        match (name, arguments) {
            (CreoMathFunction::Itos, [argument]) => {
                let Some((value, _)) = quantity_parts_ref(argument) else {
                    return Ok(None);
                };
                let rounded = value.round();
                if rounded == 0.0 {
                    return Ok(Some(String(std::string::String::new())));
                }
                Ok(Some(String(format!("{rounded:.0}"))))
            }
            (CreoMathFunction::Rtos, [argument, controls @ ..]) => {
                let Some((value, _)) = quantity_parts_ref(argument) else {
                    return Ok(None);
                };
                let (decimals, scientific) = match controls {
                    [] => (None, false),
                    [Number(decimals)] => {
                        let Some(decimals) = relation_precision(decimals.get()) else {
                            return Ok(None);
                        };
                        (Some(decimals), false)
                    }
                    [Number(decimals), Number(scientific)] => {
                        let Some(decimals) = relation_precision(decimals.get()) else {
                            return Ok(None);
                        };
                        (Some(decimals), scientific.get() != 0.0)
                    }
                    _ => return Ok(None),
                };
                Ok(format_relation_real(value, decimals, scientific).map(String))
            }
            (CreoMathFunction::RelModelName, []) => match context.model_name {
                Some(name) => Ok(Some(String(name.to_owned()))),
                None => Ok(None),
            },
            (CreoMathFunction::RelModelType, []) => Ok(Some(String("part".to_owned()))),
            (CreoMathFunction::Exists, [String(name)]) => {
                let Some(symbols) = context.existing_symbols else {
                    return Ok(None);
                };
                let mut key = name.clone();
                key.make_ascii_lowercase();
                Ok(symbols
                    .contains(&key)
                    .then_some(Number(cadmpeg_ir::scalar::FiniteReal::ONE)))
            }
            (CreoMathFunction::Search, [String(value), String(needle)]) => {
                let position = value
                    .find(needle)
                    .map_or(0, |byte| value[..byte].chars().count() + 1);
                Ok(Self::number(
                    cadmpeg_core::convert::f64_from_index(position).ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value cannot be represented exactly",
                        )
                    })?,
                ))
            }
            (CreoMathFunction::Extract, [String(value), Number(position), Number(length)]) => {
                if position.get().fract() != 0.0
                    || length.get().fract() != 0.0
                    || position.get() <= 0.0
                    || length.get() < 0.0
                {
                    return Ok(None);
                }
                let character_count = value.chars().count();
                if position.get()
                    > cadmpeg_core::convert::f64_from_index(character_count).ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value cannot be represented exactly",
                        )
                    })?
                {
                    return Ok(Some(String(std::string::String::new())));
                }
                let start = cadmpeg_core::convert::truncate_f64_to_usize(position.get())
                    .ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value cannot be represented exactly",
                        )
                    })?
                    - 1;
                let remaining = character_count - start;
                let length = if length.get()
                    >= cadmpeg_core::convert::f64_from_index(remaining).ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value cannot be represented exactly",
                        )
                    })? {
                    remaining
                } else {
                    cadmpeg_core::convert::truncate_f64_to_usize(length.get()).ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo numeric value cannot be represented exactly",
                        )
                    })?
                };
                let start_byte = value
                    .char_indices()
                    .nth(start)
                    .map_or(value.len(), |(at, _)| at);
                let end_byte = value[start_byte..]
                    .char_indices()
                    .nth(length)
                    .map_or(value.len(), |(at, _)| start_byte + at);
                Ok(Some(String(value[start_byte..end_byte].to_owned())))
            }
            (CreoMathFunction::If, [Number(condition), String(when_true), String(when_false)]) => {
                let selected = if condition.get() == 0.0 {
                    when_false
                } else {
                    when_true
                };
                Ok(Some(String(selected.to_owned())))
            }
            (CreoMathFunction::StringLength, [String(value)]) => Ok(Self::number(
                cadmpeg_core::convert::f64_from_index(value.chars().count()).ok_or_else(|| {
                    cadmpeg_core::CodecError::malformed(
                        "Creo numeric value cannot be represented exactly",
                    )
                })?,
            )),
            (CreoMathFunction::StringStarts, [String(value), String(prefix)]) => {
                Ok(Self::number(f64::from(value.starts_with(prefix))))
            }
            (CreoMathFunction::StringEnds, [String(value), String(suffix)]) => {
                Ok(Self::number(f64::from(value.ends_with(suffix))))
            }
            (CreoMathFunction::StringMatch, [String(value), String(expected)]) => {
                Ok(Self::number(f64::from(value == expected)))
            }
            (CreoMathFunction::StringPattern, [String(value), String(pattern)]) => {
                Ok(relation_string_pattern(value, pattern)
                    .and_then(|matched| Self::number(f64::from(matched))))
            }
            (CreoMathFunction::Pow, [base, Number(exponent)]) => {
                Ok(quantity_power(base, &Number(*exponent)))
            }
            _ => Ok(evaluate_creo_numeric_relation_function(name, arguments)),
        }
    }

    fn negate_checked(self) -> Result<Option<Self>, cadmpeg_core::CodecError> {
        Ok(quantity_parts_ref(&self)
            .and_then(|(value, dimension)| quantity_value(-value, dimension)))
    }

    fn finite(&self) -> bool {
        true
    }

    fn text_len(&self) -> Option<usize> {
        match self {
            Self::String(text) => Some(text.len()),
            _ => None,
        }
    }
}

fn quantity_additive(
    left: &CurveExpressionValue,
    right: &CurveExpressionValue,
    operation: impl FnOnce(f64, f64) -> f64,
) -> Option<CurveExpressionValue> {
    let (left, left_dimension) = quantity_parts_ref(left)?;
    let (right, right_dimension) = quantity_parts_ref(right)?;
    (left_dimension == right_dimension).then_some(())?;
    quantity_value(operation(left, right), left_dimension)
}

fn quantity_parts_ref(value: &CurveExpressionValue) -> Option<(f64, RelationDimension)> {
    match value {
        CurveExpressionValue::Number(value) => Some((value.get(), RelationDimension::default())),
        CurveExpressionValue::Length(value) => Some((value.get(), RelationDimension::LENGTH)),
        CurveExpressionValue::Angle(value) => Some((value.get(), RelationDimension::ANGLE)),
        CurveExpressionValue::Quantity(value) => Some((value.value(), value.dimension())),
        CurveExpressionValue::String(_) => None,
    }
}

fn quantity_value(value: f64, dimension: RelationDimension) -> Option<CurveExpressionValue> {
    let value = cadmpeg_ir::scalar::FiniteReal::new(value)?;
    Some(if dimension == RelationDimension::default() {
        CurveExpressionValue::Number(value)
    } else if dimension == RelationDimension::LENGTH {
        CurveExpressionValue::Length(value)
    } else if dimension == RelationDimension::ANGLE {
        CurveExpressionValue::Angle(value)
    } else {
        CurveExpressionValue::Quantity(CurveExpressionQuantity::new(
            value.get(),
            [
                dimension.length,
                dimension.mass,
                dimension.time,
                dimension.angle,
                dimension.temperature,
            ],
        )?)
    })
}

fn numeric_binary(
    left: CurveExpressionValue,
    right: CurveExpressionValue,
    operation: impl FnOnce(f64, f64) -> f64,
) -> Option<CurveExpressionValue> {
    match (left, right) {
        (CurveExpressionValue::Number(left), CurveExpressionValue::Number(right)) => {
            CurveExpressionValue::number(operation(left.get(), right.get()))
        }
        _ => None,
    }
}

struct ExpressionParser<'a, V> {
    source: &'a [u8],
    cursor: usize,
    values: &'a BTreeMap<String, V>,
    context: RelationEvaluationContext<'a>,
    ctx: &'a cadmpeg_core::decode::DecodeContext<'a>,
    resource_error: Option<cadmpeg_core::CodecError>,
    nesting: usize,
    text_bytes: usize,
    text_capped: bool,
}

const MAX_EXPRESSION_NESTING: usize = 128;

/// String bytes one relation expression evaluation may materialize. Every
/// literal, variable read, function result, and concatenation counts its full
/// length, so repeated concatenation cannot double a string past this bound.
const MAX_RELATION_EXPRESSION_TEXT_BYTES: usize = 4096;

/// String bytes the assigned values of one relation program may keep. Each
/// assignment keeps its own copy of its value.
const MAX_RELATION_PROGRAM_TEXT_BYTES: usize = 65_536;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ComparisonOperator {
    Equal,
    NotEqual,
    Greater,
    GreaterOrEqual,
    Less,
    LessOrEqual,
}

impl ComparisonOperator {
    fn evaluate(self, left: f64, right: f64) -> bool {
        match self {
            Self::Equal => left == right,
            Self::NotEqual => left != right,
            Self::Greater => left > right,
            Self::GreaterOrEqual => left >= right,
            Self::Less => left < right,
            Self::LessOrEqual => left <= right,
        }
    }
}

impl<V: ExpressionValue> ExpressionParser<'_, V> {
    fn admit<T>(&mut self, result: Result<T, cadmpeg_core::CodecError>) -> Option<T> {
        match result {
            Ok(value) => Some(value),
            Err(error) => {
                self.resource_error = Some(error);
                None
            }
        }
    }

    fn finite_value(value: V) -> Option<V> {
        value.finite().then_some(value)
    }

    fn admit_text(&mut self, bytes: Option<usize>) -> Option<()> {
        let Some(bytes) = bytes else {
            return Some(());
        };
        match self
            .text_bytes
            .checked_add(bytes)
            .filter(|total| *total <= MAX_RELATION_EXPRESSION_TEXT_BYTES)
        {
            Some(total) => {
                self.text_bytes = total;
                Some(())
            }
            None => {
                self.text_capped = true;
                None
            }
        }
    }

    fn whitespace(&mut self) {
        while self
            .source
            .get(self.cursor)
            .is_some_and(u8::is_ascii_whitespace)
        {
            self.cursor += 1;
        }
    }

    fn logical_or(&mut self) -> Option<V> {
        let mut value = self.logical_and()?;
        loop {
            self.whitespace();
            if self.source.get(self.cursor) != Some(&b'|') {
                return Some(value);
            }
            self.cursor += 1;
            let right = self.logical_and()?;
            let result = value.logical_or_checked(right);
            value = Self::finite_value(self.admit(result)??)?;
        }
    }

    fn logical_and(&mut self) -> Option<V> {
        let mut value = self.comparison()?;
        loop {
            self.whitespace();
            if self.source.get(self.cursor) != Some(&b'&') {
                return Some(value);
            }
            self.cursor += 1;
            let right = self.comparison()?;
            let result = value.logical_and_checked(right);
            value = Self::finite_value(self.admit(result)??)?;
        }
    }

    fn comparison(&mut self) -> Option<V> {
        let value = self.expression()?;
        self.whitespace();
        let (operator, width) = match self.source.get(self.cursor..) {
            Some([b'=', b'=', ..]) => (ComparisonOperator::Equal, 2),
            Some([b'!' | b'~', b'=', ..] | [b'<', b'>', ..]) => (ComparisonOperator::NotEqual, 2),
            Some([b'>', b'=', ..]) => (ComparisonOperator::GreaterOrEqual, 2),
            Some([b'<', b'=', ..]) => (ComparisonOperator::LessOrEqual, 2),
            Some([b'>', ..]) => (ComparisonOperator::Greater, 1),
            Some([b'<', ..]) => (ComparisonOperator::Less, 1),
            _ => return Some(value),
        };
        self.cursor += width;
        let right = self.expression()?;
        let result = value.compare_checked(right, operator);
        Self::finite_value(self.admit(result)??)
    }

    fn expression(&mut self) -> Option<V> {
        let mut value = self.term()?;
        loop {
            self.whitespace();
            match self.source.get(self.cursor) {
                Some(b'+') => {
                    self.cursor += 1;
                    let right = self.term()?;
                    if value.text_len().is_some() && right.text_len().is_some() {
                        self.admit_text(value.text_len())?;
                        self.admit_text(right.text_len())?;
                    }
                    let result = value.add_checked(right);
                    value = Self::finite_value(self.admit(result)??)?;
                }
                Some(b'-') => {
                    self.cursor += 1;
                    let right = self.term()?;
                    let result = value.subtract_checked(right);
                    value = Self::finite_value(self.admit(result)??)?;
                }
                _ => return Some(value),
            }
        }
    }

    fn term(&mut self) -> Option<V> {
        let mut value = self.unary()?;
        loop {
            self.whitespace();
            match self.source.get(self.cursor) {
                Some(b'*') => {
                    self.cursor += 1;
                    let right = self.unary()?;
                    let result = value.multiply_checked(right);
                    value = Self::finite_value(self.admit(result)??)?;
                }
                Some(b'/') => {
                    self.cursor += 1;
                    let right = self.unary()?;
                    let result = value.divide_checked(right);
                    value = Self::finite_value(self.admit(result)??)?;
                }
                _ => return Some(value),
            }
        }
    }

    fn unary(&mut self) -> Option<V> {
        self.whitespace();
        let start = self.cursor;
        loop {
            match self.source.get(self.cursor) {
                Some(b'+') => self.cursor += 1,
                Some(b'-' | b'!' | b'~') => self.cursor += 1,
                _ => break,
            }
            self.whitespace();
        }
        let end = self.cursor;
        let mut value = self.power()?;
        for index in (start..end).rev() {
            let operator = self.source[index];
            value = match operator {
                b'-' => {
                    let result = value.negate_checked();
                    Self::finite_value(self.admit(result)??)?
                }
                b'!' | b'~' => {
                    let result = value.logical_not_checked();
                    Self::finite_value(self.admit(result)??)?
                }
                _ => value,
            };
        }
        Some(value)
    }

    fn power(&mut self) -> Option<V> {
        let value = self.primary()?;
        self.whitespace();
        if self.source.get(self.cursor) != Some(&b'^') {
            return Some(value);
        }
        (self.nesting < MAX_EXPRESSION_NESTING).then_some(())?;
        let _depth = self.admit(self.ctx.enter_nested("creo relation exponent depth"))?;
        self.cursor += 1;
        self.nesting += 1;
        let exponent = self.unary()?;
        self.nesting -= 1;
        let result = value.power_checked(exponent);
        Self::finite_value(self.admit(result)??)
    }

    fn primary(&mut self) -> Option<V> {
        self.whitespace();
        let mut value = match self.source.get(self.cursor)? {
            b'(' => {
                (self.nesting < MAX_EXPRESSION_NESTING).then_some(())?;
                let _depth = self.admit(self.ctx.enter_nested("creo relation group depth"))?;
                self.cursor += 1;
                self.nesting += 1;
                let value = self.logical_or()?;
                self.nesting -= 1;
                self.whitespace();
                (self.source.get(self.cursor) == Some(&b')')).then(|| {
                    self.cursor += 1;
                    value
                })
            }
            byte if byte.is_ascii_digit() || *byte == b'.' => self.number(),
            b'\'' | b'"' => self.string(),
            byte if byte.is_ascii_alphabetic() || *byte == b'_' => self.identifier_or_function(),
            _ => None,
        }?;
        self.whitespace();
        if self.source.get(self.cursor) == Some(&b'[') {
            let unit_start = self.cursor + 1;
            let unit_length = self.source[unit_start..]
                .iter()
                .position(|byte| *byte == b']')?;
            let unit_end = unit_start + unit_length;
            let unit = std::str::from_utf8(&self.source[unit_start..unit_end]).ok()?;
            let unit = self.admit(relation_unit(self.ctx, unit))??;
            let result = value.with_unit_checked(unit);
            value = Self::finite_value(self.admit(result)??)?;
            self.cursor = unit_end + 1;
        }
        Self::finite_value(value)
    }

    fn string(&mut self) -> Option<V> {
        let delimiter = *self.source.get(self.cursor)?;
        self.cursor += 1;
        let start = self.cursor;
        while self
            .source
            .get(self.cursor)
            .is_some_and(|byte| *byte != delimiter)
        {
            self.cursor += 1;
        }
        (self.source.get(self.cursor) == Some(&delimiter)).then_some(())?;
        let source = std::str::from_utf8(&self.source[start..self.cursor]).ok()?;
        self.admit_text(Some(source.len()))?;
        let value = self.admit(Ok(source.to_owned()))?;
        self.cursor += 1;
        V::string(value)
    }

    fn number(&mut self) -> Option<V> {
        let start = self.cursor;
        while self
            .source
            .get(self.cursor)
            .is_some_and(|byte| byte.is_ascii_digit() || *byte == b'.')
        {
            self.cursor += 1;
        }
        if self
            .source
            .get(self.cursor)
            .is_some_and(|byte| matches!(byte, b'e' | b'E'))
        {
            self.cursor += 1;
            if self
                .source
                .get(self.cursor)
                .is_some_and(|byte| matches!(byte, b'+' | b'-'))
            {
                self.cursor += 1;
            }
            while self.source.get(self.cursor).is_some_and(u8::is_ascii_digit) {
                self.cursor += 1;
            }
        }
        let value = std::str::from_utf8(&self.source[start..self.cursor])
            .ok()?
            .parse()
            .ok()?;
        V::number(value)
    }

    fn identifier_or_function(&mut self) -> Option<V> {
        let start = self.cursor;
        self.cursor = expression_identifier_end(self.source, start)?;
        let name = std::str::from_utf8(&self.source[start..self.cursor]).ok()?;
        self.whitespace();
        if self.source.get(self.cursor) != Some(&b'(') {
            if let Some(value) = V::reserved(name) {
                return Some(value);
            }
            let mut key = name.to_owned();
            key.make_ascii_lowercase();
            let value = self.values.get(&key)?;
            self.admit_text(value.text_len())?;
            return Some(value.clone());
        }
        (self.nesting < MAX_EXPRESSION_NESTING).then_some(())?;
        let (function, scope) = creo_relation_function(name)?;
        let _depth = self.admit(self.ctx.enter_nested("creo relation function depth"))?;
        self.cursor += 1;
        self.nesting += 1;
        self.whitespace();
        let mut arguments = Vec::new();
        if self.source.get(self.cursor) != Some(&b')') {
            loop {
                let argument = self.logical_or()?;
                arguments.push(argument);
                self.whitespace();
                if self.source.get(self.cursor) != Some(&b',') {
                    break;
                }
                self.cursor += 1;
            }
        }
        self.whitespace();
        (self.source.get(self.cursor) == Some(&b')')).then_some(())?;
        self.cursor += 1;
        self.nesting -= 1;
        let result = V::function_checked(function, scope, &arguments, self.context);
        let value = self.admit(result)??;
        self.admit_text(value.text_len())?;
        Some(value)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CreoMathFunction {
    Sin,
    Cos,
    Tan,
    Asin,
    Acos,
    Atan,
    Atan2,
    Sinh,
    Cosh,
    Tanh,
    Sign,
    Mod,
    If,
    Bound,
    Dead,
    Near,
    Min,
    Max,
    Log,
    Ln,
    Exp,
    Pow,
    Sqrt,
    Abs,
    Ceil,
    Floor,
    DblInTol,
    Itos,
    Rtos,
    RelModelName,
    RelModelType,
    Exists,
    Search,
    Extract,
    StringLength,
    StringStarts,
    StringEnds,
    StringMatch,
    StringPattern,
    ContextDependent,
}

fn creo_math_function(name: &str) -> Option<CreoMathFunction> {
    const FUNCTIONS: &[(&str, CreoMathFunction)] = &[
        ("sin", CreoMathFunction::Sin),
        ("cos", CreoMathFunction::Cos),
        ("tan", CreoMathFunction::Tan),
        ("asin", CreoMathFunction::Asin),
        ("acos", CreoMathFunction::Acos),
        ("atan", CreoMathFunction::Atan),
        ("atan2", CreoMathFunction::Atan2),
        ("sinh", CreoMathFunction::Sinh),
        ("cosh", CreoMathFunction::Cosh),
        ("tanh", CreoMathFunction::Tanh),
        ("sign", CreoMathFunction::Sign),
        ("mod", CreoMathFunction::Mod),
        ("if", CreoMathFunction::If),
        ("bound", CreoMathFunction::Bound),
        ("dead", CreoMathFunction::Dead),
        ("near", CreoMathFunction::Near),
        ("min", CreoMathFunction::Min),
        ("max", CreoMathFunction::Max),
        ("log", CreoMathFunction::Log),
        ("ln", CreoMathFunction::Ln),
        ("exp", CreoMathFunction::Exp),
        ("pow", CreoMathFunction::Pow),
        ("sqrt", CreoMathFunction::Sqrt),
        ("abs", CreoMathFunction::Abs),
        ("ceil", CreoMathFunction::Ceil),
        ("floor", CreoMathFunction::Floor),
        ("dbl_in_tol", CreoMathFunction::DblInTol),
        ("itos", CreoMathFunction::Itos),
        ("rtos", CreoMathFunction::Rtos),
        ("rel_model_name", CreoMathFunction::RelModelName),
        ("rel_model_type", CreoMathFunction::RelModelType),
        ("exists", CreoMathFunction::Exists),
        ("search", CreoMathFunction::Search),
        ("extract", CreoMathFunction::Extract),
        ("string_length", CreoMathFunction::StringLength),
        ("string_starts", CreoMathFunction::StringStarts),
        ("string_ends", CreoMathFunction::StringEnds),
        ("string_match", CreoMathFunction::StringMatch),
        ("string_pattern", CreoMathFunction::StringPattern),
    ];
    const CONTEXT_DEPENDENT: &[&str] = &[
        "cable_len",
        "cable_thick",
        "cbl_logical_file",
        "eang",
        "elen",
        "edistk",
        "ecoordx",
        "ecoordy",
        "evalgraph",
        "trajpar_of_pnt",
        "massprop_param",
        "material_param",
        "mp_mass",
        "mp_assigned_mass",
        "mp_surf_area",
        "mp_volume",
        "mp_cg_x",
        "mp_cg_y",
        "mp_cg_z",
        "has_value",
        "match_value",
        "average",
        "value_by_argument",
        "weighted_average",
        "value",
        "count_rows",
    ];
    FUNCTIONS
        .iter()
        .find_map(|(spelling, function)| name.eq_ignore_ascii_case(spelling).then_some(*function))
        .or_else(|| {
            CONTEXT_DEPENDENT
                .iter()
                .any(|spelling| name.eq_ignore_ascii_case(spelling))
                .then_some(CreoMathFunction::ContextDependent)
        })
}

fn creo_relation_function(name: &str) -> Option<(CreoMathFunction, Option<&str>)> {
    if let Some((function, scope)) = name.split_once(':') {
        (function.eq_ignore_ascii_case("rel_model_name")
            && !scope.is_empty()
            && scope.bytes().all(|byte| byte.is_ascii_digit()))
        .then_some((CreoMathFunction::RelModelName, Some(scope)))
    } else {
        creo_math_function(name).map(|function| (function, None))
    }
}

fn evaluate_creo_math_function(name: CreoMathFunction, arguments: &[f64]) -> Option<f64> {
    let value = match (name, arguments) {
        (CreoMathFunction::Sin, [x]) => x.to_radians().sin(),
        (CreoMathFunction::Cos, [x]) => x.to_radians().cos(),
        (CreoMathFunction::Tan, [x]) => {
            let principal_degrees = x.rem_euclid(180.0);
            (principal_degrees != 90.0).then_some(())?;
            x.to_radians().tan()
        }
        (CreoMathFunction::Asin, [x]) => x.asin().to_degrees(),
        (CreoMathFunction::Acos, [x]) => x.acos().to_degrees(),
        (CreoMathFunction::Atan, [x]) => x.atan().to_degrees(),
        (CreoMathFunction::Atan2, [y, x]) if *x != 0.0 || *y != 0.0 => y.atan2(*x).to_degrees(),
        (CreoMathFunction::Sinh, [x]) => x.sinh(),
        (CreoMathFunction::Cosh, [x]) => x.cosh(),
        (CreoMathFunction::Tanh, [x]) => x.tanh(),
        (CreoMathFunction::Sign, [x, y]) => {
            if *y < 0.0 {
                -x.abs()
            } else {
                x.abs()
            }
        }
        (CreoMathFunction::Mod, [x, y]) if *y != 0.0 => x % y,
        (CreoMathFunction::If, [condition, when_true, when_false]) => {
            if *condition == 0.0 {
                *when_false
            } else {
                *when_true
            }
        }
        (CreoMathFunction::Bound, [x, lower, upper]) if lower < upper => x.clamp(*lower, *upper),
        (CreoMathFunction::Dead, [x, lower, upper]) if lower <= upper => {
            if x < lower {
                x - lower
            } else if x > upper {
                x - upper
            } else {
                0.0
            }
        }
        (CreoMathFunction::Near, [x, y, delta]) if *delta >= 0.0 => {
            f64::from(u8::from((x - y).abs() <= *delta))
        }
        (name @ (CreoMathFunction::Min | CreoMathFunction::Max), [x, y]) => {
            if extremum_selects_left(name, *x, *y)? {
                *x
            } else {
                *y
            }
        }
        (CreoMathFunction::Log, [x]) => x.log10(),
        (CreoMathFunction::Ln, [x]) => x.ln(),
        (CreoMathFunction::Exp, [x]) => x.exp(),
        (CreoMathFunction::Pow, [base, exponent]) => base.powf(*exponent),
        (CreoMathFunction::Sqrt, [x]) => x.sqrt(),
        (CreoMathFunction::Abs, [x]) => x.abs(),
        (CreoMathFunction::Ceil, [x]) => relation_round(*x, 0.0, true)?,
        (CreoMathFunction::Ceil, [x, decimal_places]) => relation_round(*x, *decimal_places, true)?,
        (CreoMathFunction::Floor, [x]) => relation_round(*x, 0.0, false)?,
        (CreoMathFunction::Floor, [x, decimal_places]) => {
            relation_round(*x, *decimal_places, false)?
        }
        (CreoMathFunction::DblInTol, [first, second, tolerance]) if *tolerance >= 0.0 => {
            f64::from(u8::from((first - second).abs() <= *tolerance))
        }
        _ => return None,
    };
    value.is_finite().then_some(value)
}

fn relation_round(value: f64, decimal_places: f64, upward: bool) -> Option<f64> {
    (value.is_finite() && decimal_places.is_finite()).then_some(())?;
    let decimal_places = decimal_places.trunc();
    if decimal_places > 8.0 {
        return Some(value);
    }
    (decimal_places >= f64::from(i32::MIN)).then_some(())?;
    let scale = 10_f64.powi(cadmpeg_core::convert::truncate_f64_to_i32(decimal_places)?);
    (scale.is_finite() && scale > 0.0).then_some(())?;
    let scaled = (value
        + if upward {
            -EPS_RELATION_ROUND
        } else {
            EPS_RELATION_ROUND
        })
        * scale;
    if !scaled.is_finite() {
        return Some(value);
    }
    let rounded = if upward {
        scaled.ceil()
    } else {
        scaled.floor()
    } / scale;
    rounded.is_finite().then_some(rounded)
}

fn extremum_selects_left(name: CreoMathFunction, left: f64, right: f64) -> Option<bool> {
    match name {
        CreoMathFunction::Min => Some(left < right),
        CreoMathFunction::Max => Some(left > right),
        _ => None,
    }
}

fn quantity_power(
    value: &CurveExpressionValue,
    right: &CurveExpressionValue,
) -> Option<CurveExpressionValue> {
    let CurveExpressionValue::Number(exponent) = right else {
        return None;
    };
    let (value, dimension) = quantity_parts_ref(value)?;
    let exponent = exponent.get();
    if dimension == RelationDimension::default() {
        return CurveExpressionValue::number(value.powf(exponent));
    }
    let integer = exponent.trunc();
    (integer == exponent).then_some(())?;
    let exponent =
        i8::try_from(i16::try_from(cadmpeg_core::convert::truncate_f64_to_i32(integer)?).ok()?)
            .ok()?;
    quantity_value(value.powi(i32::from(exponent)), dimension.scale(exponent)?)
}

fn evaluate_creo_numeric_relation_function(
    name: CreoMathFunction,
    arguments: &[CurveExpressionValue],
) -> Option<CurveExpressionValue> {
    use CurveExpressionValue::{Angle, Number, String};
    let value = match (name, arguments) {
        (
            name @ (CreoMathFunction::Sin | CreoMathFunction::Cos | CreoMathFunction::Tan),
            [Angle(value)],
        ) => CurveExpressionValue::number(evaluate_creo_math_function(name, &[value.get()])?)?,
        (
            name @ (CreoMathFunction::Asin | CreoMathFunction::Acos | CreoMathFunction::Atan),
            [Number(value)],
        ) => {
            cadmpeg_ir::scalar::FiniteReal::new(evaluate_creo_math_function(name, &[value.get()])?)
                .map(Angle)?
        }
        (CreoMathFunction::Atan2, [left, right]) => {
            let (left, left_dimension) = quantity_parts_ref(left)?;
            let (right, right_dimension) = quantity_parts_ref(right)?;
            (left_dimension == right_dimension).then_some(())?;
            cadmpeg_ir::scalar::FiniteReal::new(evaluate_creo_math_function(
                CreoMathFunction::Atan2,
                &[left, right],
            )?)
            .map(Angle)?
        }
        (CreoMathFunction::If, [Number(condition), when_true, when_false]) => {
            match (when_true, when_false) {
                (String(_), String(_)) => {}
                (when_true, when_false) => {
                    let (_, true_dimension) = quantity_parts_ref(when_true)?;
                    let (_, false_dimension) = quantity_parts_ref(when_false)?;
                    (true_dimension == false_dimension).then_some(())?;
                }
            }
            let selected = if condition.get() == 0.0 {
                when_false
            } else {
                when_true
            };
            let (value, dimension) = quantity_parts_ref(selected)?;
            quantity_value(value, dimension)?
        }
        (CreoMathFunction::Sign, [value, sign]) => {
            let (value, dimension) = quantity_parts_ref(value)?;
            let (sign, _) = quantity_parts_ref(sign)?;
            quantity_value(
                if sign < 0.0 {
                    -value.abs()
                } else {
                    value.abs()
                },
                dimension,
            )?
        }
        (CreoMathFunction::Mod, [left, right]) => {
            let (left, left_dimension) = quantity_parts_ref(left)?;
            let (right, right_dimension) = quantity_parts_ref(right)?;
            (left_dimension == right_dimension && right != 0.0).then_some(())?;
            quantity_value(left % right, left_dimension)?
        }
        (CreoMathFunction::Bound, [value, lower, upper]) => {
            let (value, value_dimension) = quantity_parts_ref(value)?;
            let (lower, lower_dimension) = quantity_parts_ref(lower)?;
            let (upper, upper_dimension) = quantity_parts_ref(upper)?;
            (value_dimension == lower_dimension
                && value_dimension == upper_dimension
                && lower < upper)
                .then_some(())?;
            quantity_value(
                if value < lower {
                    lower
                } else if value > upper {
                    upper
                } else {
                    value
                },
                value_dimension,
            )?
        }
        (CreoMathFunction::Dead, [value, lower, upper]) => {
            let (value, value_dimension) = quantity_parts_ref(value)?;
            let (lower, lower_dimension) = quantity_parts_ref(lower)?;
            let (upper, upper_dimension) = quantity_parts_ref(upper)?;
            (value_dimension == lower_dimension
                && value_dimension == upper_dimension
                && lower <= upper)
                .then_some(())?;
            let value = if value < lower {
                value - lower
            } else if value > upper {
                value - upper
            } else {
                0.0
            };
            quantity_value(value, value_dimension)?
        }
        (CreoMathFunction::Pow, [base, Number(exponent)]) => {
            quantity_power(base, &Number(*exponent))?
        }
        (CreoMathFunction::Sqrt, [argument]) => {
            let (value, dimension) = quantity_parts_ref(argument)?;
            (value >= 0.0).then_some(())?;
            quantity_value(value.sqrt(), dimension.root(2)?)?
        }
        (CreoMathFunction::Abs, [argument]) => {
            let (value, dimension) = quantity_parts_ref(argument)?;
            quantity_value(value.abs(), dimension)?
        }
        (name @ (CreoMathFunction::Ceil | CreoMathFunction::Floor), [argument]) => {
            let (value, dimension) = quantity_parts_ref(argument)?;
            quantity_value(
                relation_round(value, 0.0, matches!(name, CreoMathFunction::Ceil))?,
                dimension,
            )?
        }
        (
            name @ (CreoMathFunction::Ceil | CreoMathFunction::Floor),
            [argument, Number(decimal_places)],
        ) => {
            let (value, dimension) = quantity_parts_ref(argument)?;
            quantity_value(
                relation_round(
                    value,
                    decimal_places.get(),
                    matches!(name, CreoMathFunction::Ceil),
                )?,
                dimension,
            )?
        }
        (name @ (CreoMathFunction::Min | CreoMathFunction::Max), [left, right]) => {
            let (left_value, left_dimension) = quantity_parts_ref(left)?;
            let (right_value, right_dimension) = quantity_parts_ref(right)?;
            (left_dimension == right_dimension).then_some(())?;
            if extremum_selects_left(name, left_value, right_value)? {
                left.clone()
            } else {
                right.clone()
            }
        }
        (CreoMathFunction::Near | CreoMathFunction::DblInTol, [left, right, tolerance]) => {
            let (left, left_dimension) = quantity_parts_ref(left)?;
            let (right, right_dimension) = quantity_parts_ref(right)?;
            let (tolerance, tolerance_dimension) = quantity_parts_ref(tolerance)?;
            (left_dimension == right_dimension
                && left_dimension == tolerance_dimension
                && tolerance >= 0.0)
                .then_some(())?;
            CurveExpressionValue::number(f64::from((left - right).abs() <= tolerance))?
        }
        _ => {
            let mut numbers = [0.0; 3];
            for (index, argument) in arguments.iter().enumerate() {
                let slot = numbers.get_mut(index)?;
                let Number(value) = argument else {
                    return None;
                };
                *slot = value.get();
            }
            CurveExpressionValue::number(evaluate_creo_math_function(
                name,
                &numbers[..arguments.len()],
            )?)?
        }
    };
    Some(value)
}

const RELATION_REGEX_SIZE_LIMIT: usize = 1 << 20;

fn relation_string_pattern(value: &str, pattern: &str) -> Option<bool> {
    let expression = format!(r"\A(?:{pattern})\z");
    let compiled = regex::RegexBuilder::new(&expression)
        .size_limit(RELATION_REGEX_SIZE_LIMIT)
        .dfa_size_limit(RELATION_REGEX_SIZE_LIMIT)
        .build();
    let Ok(compiled) = compiled else {
        return None;
    };
    Some(compiled.is_match(value))
}

const MAX_RELATION_STRING_PRECISION: f64 = 128.0;

fn relation_precision(value: f64) -> Option<usize> {
    (value.is_finite()
        && value.fract() == 0.0
        && (0.0..=MAX_RELATION_STRING_PRECISION).contains(&value))
    .then(|| cadmpeg_core::convert::truncate_f64_to_usize(value))
    .flatten()
}

fn format_relation_real(value: f64, decimals: Option<usize>, scientific: bool) -> Option<String> {
    if !value.is_finite() {
        return None;
    }
    if value == 0.0 {
        return Some(String::new());
    }
    let Some(decimals) = decimals else {
        return Some(format!("{value}"));
    };
    if !scientific {
        return Some(format!("{value:.decimals$}"));
    }
    let formatted = format!("{value:.decimals$e}");
    let (mantissa, exponent) = formatted.split_once('e')?;
    let Ok(exponent) = exponent.parse::<i32>() else {
        return None;
    };
    Some(format!(
        "{mantissa}e{}{magnitude:02}",
        if exponent < 0 { "-" } else { "" },
        magnitude = exponent.unsigned_abs()
    ))
}

/// Evaluates one relation expression. Sets `text_capped` when the expression
/// has no value because it reached [`MAX_RELATION_EXPRESSION_TEXT_BYTES`].
fn parse_capped_relation_expression<V: ExpressionValue>(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    expression: &str,
    values: &BTreeMap<String, V>,
    context: RelationEvaluationContext<'_>,
    text_capped: &mut bool,
) -> Result<Option<V>, cadmpeg_core::CodecError> {
    let mut parser = ExpressionParser {
        source: expression.as_bytes(),
        cursor: 0,
        values,
        context,
        ctx,
        resource_error: None,
        nesting: 0,
        text_bytes: 0,
        text_capped: false,
    };
    let value = parser.logical_or();
    if let Some(error) = parser.resource_error {
        return Err(error);
    }
    parser.whitespace();
    let value = value.filter(|value| parser.cursor == parser.source.len() && value.finite());
    *text_capped |= parser.text_capped && value.is_none();
    Ok(value)
}

/// Evaluates one relation expression without reporting
/// [`MAX_RELATION_EXPRESSION_TEXT_BYTES`]. Production callers use value types
/// that carry no text, which have no value the cap could drop.
fn parse_relation_expression<V: ExpressionValue>(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    expression: &str,
    values: &BTreeMap<String, V>,
    context: RelationEvaluationContext<'_>,
) -> Result<Option<V>, cadmpeg_core::CodecError> {
    parse_capped_relation_expression(ctx, expression, values, context, &mut false)
}

fn apply_declared_relation_unit(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    value: CurveExpressionValue,
    declared_unit: Option<&str>,
) -> Result<Option<CurveExpressionValue>, cadmpeg_core::CodecError> {
    let Some(declared_unit) = declared_unit else {
        return Ok(Some(value));
    };
    let Some(unit) = relation_unit(ctx, declared_unit)? else {
        return Ok(None);
    };
    Ok(match (value, unit.dimension) {
        (CurveExpressionValue::Number(value), _) => {
            quantity_value(value.get() * unit.scale + unit.offset, unit.dimension)
        }
        (value @ CurveExpressionValue::Length(_), RelationDimension::LENGTH)
        | (value @ CurveExpressionValue::Angle(_), RelationDimension::ANGLE) => Some(value),
        (CurveExpressionValue::Quantity(value), dimension) if value.dimension() == dimension => {
            Some(CurveExpressionValue::Quantity(value))
        }
        _ => None,
    })
}

fn infer_solve_variable_dimensions(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    block: &CurveExpressionSolveBlock,
    values: &BTreeMap<String, CurveExpressionValue>,
    known_dimensions: &[Option<RelationDimension>],
    context: RelationEvaluationContext<'_>,
    work_caps: &mut BTreeSet<&'static str>,
) -> Result<Option<Vec<RelationDimension>>, cadmpeg_core::CodecError> {
    if known_dimensions.len() != block.unknowns.len() {
        return Ok(None);
    }
    let mut variable_keys = Vec::new();
    for unknown in &block.unknowns {
        let mut key = unknown.name.clone();
        key.make_ascii_lowercase();
        if variable_keys.contains(&key) {
            return Ok(None);
        }
        variable_keys.push(key);
    }

    let mut probe_values = BTreeMap::new();
    for (name, value) in values {
        let probe = match value {
            CurveExpressionValue::String(value) => {
                DimensionProbeValue::text(Some(value.to_owned()))
            }
            _ => match DimensionProbeValue::from_relation_value(value) {
                Some(probe) => probe,
                None => continue,
            },
        };
        probe_values.insert(name.to_owned(), probe);
    }
    for (key, dimension) in variable_keys.iter().zip(known_dimensions) {
        let value = match dimension {
            Some(dimension) => DimensionProbeValue {
                dimension: SymbolicRelationDimension::from_relation_dimension(*dimension),
                kind: DimensionProbeKind::Numeric(None),
                constraints: Vec::new(),
            },
            None => DimensionProbeValue::variable(key),
        };
        probe_values.insert(key.to_owned(), value);
    }

    let mut constraints = Vec::new();
    let mut text_capped = false;
    for equation in &block.equations {
        let Some(left) = parse_capped_relation_expression::<DimensionProbeValue>(
            ctx,
            &equation.left,
            &probe_values,
            context,
            &mut text_capped,
        )?
        else {
            if text_capped {
                work_caps.insert("MAX_RELATION_EXPRESSION_TEXT_BYTES");
            }
            return Ok(None);
        };
        let Some(right) = parse_capped_relation_expression::<DimensionProbeValue>(
            ctx,
            &equation.right,
            &probe_values,
            context,
            &mut text_capped,
        )?
        else {
            if text_capped {
                work_caps.insert("MAX_RELATION_EXPRESSION_TEXT_BYTES");
            }
            return Ok(None);
        };
        for constraint in left.constraints.iter().chain(&right.constraints) {
            constraints.push(constraint.clone());
        }
        constraints.push(DimensionEquality {
            left: left.dimension,
            right: right.dimension,
        });
    }

    let mut axis_rows: [Vec<AffineEquationRow>; 5] =
        std::array::from_fn(|_| Vec::<AffineEquationRow>::new());
    let mut axis_variable_keys: [Vec<String>; 5] = std::array::from_fn(|_| Vec::new());
    for (axis, keys) in axis_variable_keys.iter_mut().enumerate() {
        for variable in &variable_keys {
            keys.push(dimension_variable_key(variable, axis));
        }
    }
    for equality in constraints {
        for (axis, rows) in axis_rows.iter_mut().enumerate() {
            let left = equality.left.axes[axis].clone();
            let right = equality.right.axes[axis].clone();
            let Some(difference) = left.combine(right, true) else {
                return Ok(None);
            };
            let mut coefficients = ctx.alloc_filled(
                axis_variable_keys[axis].len(),
                0.0,
                "creo dimension equation coefficients",
            )?;
            for (coefficient, variable) in coefficients.iter_mut().zip(&axis_variable_keys[axis]) {
                *coefficient = difference
                    .variables
                    .get(variable)
                    .copied()
                    .unwrap_or_default()
                    .as_f64()
                    .ok_or_else(|| {
                        cadmpeg_core::CodecError::malformed(
                            "Creo dimension coefficient cannot be represented exactly",
                        )
                    })?;
            }
            let rhs = -difference.constant.as_f64().ok_or_else(|| {
                cadmpeg_core::CodecError::malformed(
                    "Creo dimension constant cannot be represented exactly",
                )
            })?;
            if coefficients.iter().any(|coefficient| *coefficient != 0.0) || rhs != 0.0 {
                rows.push(AffineEquationRow { coefficients, rhs });
            }
        }
    }

    let axis_len = variable_keys.len();
    let alloc_axis = || ctx.alloc_filled(axis_len, 0i8, "creo_solve_dimension_components");
    let mut components: [Vec<i8>; 5] = [
        alloc_axis()?,
        alloc_axis()?,
        alloc_axis()?,
        alloc_axis()?,
        alloc_axis()?,
    ];
    for (index, dimension) in known_dimensions.iter().enumerate() {
        if let Some(dimension) = dimension {
            components[0][index] = dimension.length;
            components[1][index] = dimension.mass;
            components[2][index] = dimension.time;
            components[3][index] = dimension.angle;
            components[4][index] = dimension.temperature;
        }
    }
    let mut required_columns = BTreeSet::new();
    for (index, dimension) in known_dimensions.iter().enumerate() {
        if dimension.is_none() {
            required_columns.insert(index);
        }
    }
    for (axis, rows) in axis_rows.iter_mut().enumerate() {
        let Some(solution) =
            solve_dimension_axis(ctx, rows, variable_keys.len(), &required_columns)?
        else {
            return Ok(None);
        };
        for (index, value) in solution.into_iter().enumerate() {
            if known_dimensions[index].is_some() {
                continue;
            }
            let rounded = value.round();
            if !value.is_finite()
                || (value - rounded).abs() > EPS_DIMENSION_SOLUTION
                || rounded < f64::from(i8::MIN)
                || rounded > f64::from(i8::MAX)
            {
                return Ok(None);
            }
            components[axis][index] = i8::try_from(
                cadmpeg_core::convert::truncate_f64_to_i32(rounded).ok_or_else(|| {
                    cadmpeg_core::CodecError::malformed(
                        "Creo numeric value cannot be represented exactly",
                    )
                })?,
            )
            .map_err(|_| {
                cadmpeg_core::CodecError::malformed("Creo numeric value exceeds dimension range")
            })?;
        }
    }
    let mut dimensions = ctx.alloc_filled(
        variable_keys.len(),
        RelationDimension::default(),
        "creo inferred variable dimensions",
    )?;
    for (index, dimension) in dimensions.iter_mut().enumerate() {
        *dimension = RelationDimension {
            length: components[0][index],
            mass: components[1][index],
            time: components[2][index],
            angle: components[3][index],
            temperature: components[4][index],
        };
    }
    Ok(Some(dimensions))
}

fn solve_dimension_axis(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    rows: &mut [AffineEquationRow],
    variable_count: usize,
    required_columns: &BTreeSet<usize>,
) -> Result<Option<Vec<f64>>, cadmpeg_core::CodecError> {
    let mut pivot_row = 0;
    let mut pivot_rows = Vec::new();
    let coefficient_tolerance = EPS_LINEAR_SYSTEM_COEFFICIENT;
    for column in 0..variable_count {
        let Some(selected) = (pivot_row..rows.len()).max_by(|&first, &second| {
            rows[first].coefficients[column]
                .abs()
                .total_cmp(&rows[second].coefficients[column].abs())
        }) else {
            break;
        };
        let divisor = rows[selected].coefficients[column];
        if divisor.abs() <= coefficient_tolerance {
            continue;
        }
        rows.swap(pivot_row, selected);
        for coefficient in &mut rows[pivot_row].coefficients {
            *coefficient /= divisor;
        }
        rows[pivot_row].rhs /= divisor;
        eliminate_pivot_column(rows, pivot_row, column, coefficient_tolerance);
        pivot_rows.push((column, pivot_row));
        pivot_row += 1;
    }
    let residual_tolerance =
        EPS_LINEAR_SYSTEM_RESIDUAL * rows.iter().map(|row| row.rhs.abs()).fold(1.0, f64::max);
    if !rows.iter().all(|row| {
        let has_coefficients = row
            .coefficients
            .iter()
            .any(|coefficient| coefficient.abs() > coefficient_tolerance);
        has_coefficients || row.rhs.abs() <= residual_tolerance
    }) {
        return Ok(None);
    }
    if !required_columns
        .iter()
        .all(|required| pivot_rows.iter().any(|(column, _)| column == required))
    {
        return Ok(None);
    }
    let mut solution = ctx.alloc_filled(variable_count, 0.0, "creo_solve_dimension_axis")?;
    for (column, row) in pivot_rows {
        solution[column] = rows[row].rhs;
    }
    Ok(Some(solution))
}

fn solve_affine_expression_block(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    block: &CurveExpressionSolveBlock,
    values: &BTreeMap<String, CurveExpressionValue>,
    variable_dimensions: &[RelationDimension],
    context: RelationEvaluationContext<'_>,
) -> Result<Option<Vec<CurveExpressionValue>>, cadmpeg_core::CodecError> {
    if variable_dimensions.len() != block.unknowns.len() {
        return Ok(None);
    }
    let mut variable_keys = Vec::new();
    for unknown in &block.unknowns {
        let mut key = unknown.name.clone();
        key.make_ascii_lowercase();
        variable_keys.push(key);
    }
    let mut affine_values = BTreeMap::new();
    for (name, value) in values {
        let Some((value, dimension)) = quantity_parts_ref(value) else {
            continue;
        };
        affine_values.insert(
            name.to_owned(),
            SimultaneousAffineValue::constant(value, dimension),
        );
    }
    for (variable, dimension) in variable_keys.iter().zip(variable_dimensions) {
        let mut coefficients = BTreeMap::new();
        coefficients.insert(variable.to_owned(), 1.0);
        affine_values.insert(
            variable.to_owned(),
            SimultaneousAffineValue {
                dimension: *dimension,
                constant: 0.0,
                coefficients,
            },
        );
    }
    let mut rows = Vec::new();
    for equation in &block.equations {
        let Some(left) = parse_relation_expression::<SimultaneousAffineValue>(
            ctx,
            &equation.left,
            &affine_values,
            context,
        )?
        else {
            return Ok(None);
        };
        let Some(right) = parse_relation_expression::<SimultaneousAffineValue>(
            ctx,
            &equation.right,
            &affine_values,
            context,
        )?
        else {
            return Ok(None);
        };
        let Some(difference) = left.combine(right, true) else {
            return Ok(None);
        };
        let mut coefficients = ctx.alloc_filled(
            variable_keys.len(),
            0.0,
            "creo affine equation coefficients",
        )?;
        for (coefficient, variable) in coefficients.iter_mut().zip(&variable_keys) {
            *coefficient = difference
                .coefficients
                .get(variable)
                .copied()
                .unwrap_or(0.0);
        }
        rows.push(AffineEquationRow {
            coefficients,
            rhs: -difference.constant,
        });
    }
    let Some(solution) = solve_unique_affine_system(ctx, &mut rows, variable_keys.len())? else {
        return Ok(None);
    };
    let mut values = Vec::new();
    for (value, dimension) in solution.into_iter().zip(variable_dimensions) {
        let Some(value) = quantity_value(value, *dimension) else {
            return Ok(None);
        };
        values.push(value);
    }
    Ok(Some(values))
}

const MAX_NONLINEAR_SOLVE_VARIABLES: usize = 8;
const MAX_NONLINEAR_SOLVE_ITERATIONS: usize = 64;
const MAX_NONLINEAR_SOLVE_LINE_SEARCH_STEPS: usize = 16;
const NONLINEAR_SOLVE_RESIDUAL_TOLERANCE: f64 = 1.0e-8;
const NONLINEAR_SOLVE_DERIVATIVE_STEP: f64 = 1.0e-6;
const NONLINEAR_SOLVE_SOLUTION_TOLERANCE: f64 = 1.0e-7;
const NONLINEAR_SOLVE_STEP_TOLERANCE: f64 = 1.0e-12;

#[derive(Debug, Clone, Copy)]
struct SolveResidual {
    value: f64,
    scale: f64,
    dimension: RelationDimension,
}

fn solve_nonlinear_expression_block(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    block: &CurveExpressionSolveBlock,
    values: &BTreeMap<String, CurveExpressionValue>,
    known_dimensions: &[Option<RelationDimension>],
    initial_values: &[Option<CurveExpressionValue>],
    context: RelationEvaluationContext<'_>,
    work_caps: &mut BTreeSet<&'static str>,
) -> Result<Option<Vec<CurveExpressionValue>>, cadmpeg_core::CodecError> {
    if !nonlinear_equations_are_smooth(block) {
        return Ok(None);
    }
    let Some(variable_dimensions) =
        infer_solve_variable_dimensions(ctx, block, values, known_dimensions, context, work_caps)?
    else {
        return Ok(None);
    };
    let variable_count = block.unknowns.len();
    if variable_count == 0 || block.equations.len() < variable_count {
        return Ok(None);
    }
    if variable_count > MAX_NONLINEAR_SOLVE_VARIABLES {
        work_caps.insert("MAX_NONLINEAR_SOLVE_VARIABLES");
        return Ok(None);
    }
    let Some(seeds) = nonlinear_initial_guesses(ctx, initial_values, &variable_dimensions)? else {
        return Ok(None);
    };
    let mut seeds = seeds.into_iter();
    let Some(initial_seed) = seeds.next() else {
        return Ok(None);
    };
    let Some(solution) = refine_nonlinear_solution(
        ctx,
        block,
        values,
        &variable_dimensions,
        &initial_seed,
        context,
        work_caps,
    )?
    else {
        return Ok(None);
    };
    for seed in seeds {
        let Some(candidate) = refine_nonlinear_solution(
            ctx,
            block,
            values,
            &variable_dimensions,
            &seed,
            context,
            work_caps,
        )?
        else {
            continue;
        };
        if !nonlinear_solutions_close(&solution, &candidate) {
            return Ok(None);
        }
    }
    let mut solved = Vec::new();
    for (value, dimension) in solution.into_iter().zip(variable_dimensions) {
        let Some(value) = quantity_value(value, dimension) else {
            return Ok(None);
        };
        solved.push(value);
    }
    Ok(Some(solved))
}

fn nonlinear_equations_are_smooth(block: &CurveExpressionSolveBlock) -> bool {
    block.equations.iter().all(|equation| {
        [equation.left.as_str(), equation.right.as_str()]
            .into_iter()
            .all(nonlinear_expression_is_smooth)
    })
}

fn nonlinear_expression_is_smooth(expression: &str) -> bool {
    let bytes = expression.as_bytes();
    let mut cursor = 0;
    while cursor < bytes.len() {
        if matches!(bytes[cursor], b'\'' | b'"') {
            let delimiter = bytes[cursor];
            cursor += 1;
            while bytes.get(cursor).is_some_and(|byte| *byte != delimiter) {
                cursor += 1;
            }
            if bytes.get(cursor) != Some(&delimiter) {
                return false;
            }
            cursor += 1;
            continue;
        }
        if matches!(
            bytes[cursor],
            b'=' | b'!' | b'~' | b'<' | b'>' | b'&' | b'|'
        ) {
            return false;
        }
        if bytes[cursor] == b'_' || bytes[cursor].is_ascii_alphabetic() {
            let start = cursor;
            let Some(end) = expression_identifier_end(bytes, start) else {
                return false;
            };
            cursor = end;
            let mut following = cursor;
            while bytes.get(following).is_some_and(u8::is_ascii_whitespace) {
                following += 1;
            }
            if bytes.get(following) == Some(&b'(') {
                let name = &expression[start..end];
                let smooth = [
                    "sin", "cos", "tan", "asin", "acos", "atan", "atan2", "sinh", "cosh", "tanh",
                    "log", "ln", "exp", "pow", "sqrt",
                ]
                .into_iter()
                .any(|candidate| name.eq_ignore_ascii_case(candidate));
                if !smooth {
                    return false;
                }
            }
            continue;
        }
        cursor += 1;
    }
    true
}

fn nonlinear_initial_guesses(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    initial_values: &[Option<CurveExpressionValue>],
    variable_dimensions: &[RelationDimension],
) -> Result<Option<Vec<Vec<f64>>>, cadmpeg_core::CodecError> {
    let variable_count = variable_dimensions.len();
    let mut seeds = Vec::new();
    let mut add_seed = |seed: Vec<f64>| -> Result<(), cadmpeg_core::CodecError> {
        if seed.iter().all(|value| value.is_finite()) && !seeds.iter().any(|known| known == &seed) {
            seeds.push(seed);
        }
        Ok(())
    };
    if initial_values.len() != variable_count {
        return Ok(None);
    }
    let mut initial = ctx.alloc_filled(variable_count, 0.0, "creo solve initial seed")?;
    for ((slot, value), dimension) in initial
        .iter_mut()
        .zip(initial_values)
        .zip(variable_dimensions)
    {
        let Some((number, value_dimension)) = value.as_ref().and_then(quantity_parts_ref) else {
            return Ok(None);
        };
        if value_dimension != *dimension {
            return Ok(None);
        }
        *slot = number;
    }
    add_seed(initial)?;
    add_seed(ctx.alloc_filled(variable_count, 0.0, "creo_solve_seed_zero")?)?;
    for magnitude in [0.01, 0.1, 1.0, 10.0, 100.0] {
        add_seed(ctx.alloc_filled(variable_count, magnitude, "creo_solve_seed_magnitude")?)?;
        add_seed(ctx.alloc_filled(variable_count, -magnitude, "creo_solve_seed_magnitude")?)?;
    }
    for index in 0..variable_count {
        for magnitude in [0.1, 1.0, 10.0] {
            let mut positive = ctx.alloc_filled(variable_count, 0.0, "creo_solve_seed_axis")?;
            positive[index] = magnitude;
            add_seed(positive)?;
            let mut negative = ctx.alloc_filled(variable_count, 0.0, "creo_solve_seed_axis")?;
            negative[index] = -magnitude;
            add_seed(negative)?;
        }
    }
    Ok(Some(seeds))
}

fn refine_nonlinear_solution(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    block: &CurveExpressionSolveBlock,
    values: &BTreeMap<String, CurveExpressionValue>,
    variable_dimensions: &[RelationDimension],
    seed: &[f64],
    context: RelationEvaluationContext<'_>,
    work_caps: &mut BTreeSet<&'static str>,
) -> Result<Option<Vec<f64>>, cadmpeg_core::CodecError> {
    let variable_count = variable_dimensions.len();
    let mut point = ctx.alloc_filled(seed.len(), 0.0, "creo nonlinear initial point")?;
    point.copy_from_slice(seed);
    let Some(mut residuals) = evaluate_nonlinear_residuals(
        ctx,
        block,
        values,
        variable_dimensions,
        &point,
        context,
        work_caps,
    )?
    else {
        return Ok(None);
    };
    for _ in 0..MAX_NONLINEAR_SOLVE_ITERATIONS {
        if nonlinear_residuals_converged(&residuals) {
            let Some(mut rank_rows) =
                nonlinear_jacobian_rows(ctx, variable_count, &point, &residuals, |probe| {
                    evaluate_nonlinear_residuals(
                        ctx,
                        block,
                        values,
                        variable_dimensions,
                        probe,
                        context,
                        work_caps,
                    )
                })?
            else {
                return Ok(None);
            };
            if solve_unique_affine_system(ctx, &mut rank_rows, variable_count)?.is_none() {
                return Ok(None);
            }
            return Ok(Some(point));
        }
        let Some(mut rows) =
            nonlinear_jacobian_rows(ctx, variable_count, &point, &residuals, |probe| {
                evaluate_nonlinear_residuals(
                    ctx,
                    block,
                    values,
                    variable_dimensions,
                    probe,
                    context,
                    work_caps,
                )
            })?
        else {
            return Ok(None);
        };
        for (row, residual) in rows.iter_mut().zip(&residuals) {
            row.rhs = -residual.value;
        }
        let Some(delta) = solve_unique_affine_system(ctx, &mut rows, variable_count)? else {
            return Ok(None);
        };
        let maximum_delta = delta.iter().map(|value| value.abs()).fold(0.0, f64::max);
        let point_scale = point.iter().map(|value| value.abs()).fold(1.0, f64::max);
        if !maximum_delta.is_finite() || maximum_delta > 1e12 * point_scale {
            return Ok(None);
        }
        let base_norm = nonlinear_residual_norm(&residuals, &residuals);
        let mut accepted = None;
        let mut scale = 1.0;
        for _ in 0..MAX_NONLINEAR_SOLVE_LINE_SEARCH_STEPS {
            let mut candidate =
                ctx.alloc_filled(point.len(), 0.0, "creo nonlinear line-search point")?;
            for ((slot, value), change) in candidate.iter_mut().zip(&point).zip(&delta) {
                *slot = value + scale * change;
            }
            if candidate.iter().all(|value| value.is_finite()) {
                if let Some(candidate_residuals) = evaluate_nonlinear_residuals(
                    ctx,
                    block,
                    values,
                    variable_dimensions,
                    &candidate,
                    context,
                    work_caps,
                )? {
                    let candidate_norm = nonlinear_residual_norm(&candidate_residuals, &residuals);
                    if nonlinear_residuals_converged(&candidate_residuals)
                        || candidate_norm < base_norm
                    {
                        accepted = Some((candidate, candidate_residuals));
                        break;
                    }
                }
            }
            scale *= 0.5;
        }
        // A line search that finds no improving step leaves the block unsolved.
        let Some((candidate, candidate_residuals)) = accepted else {
            work_caps.insert("MAX_NONLINEAR_SOLVE_LINE_SEARCH_STEPS");
            return Ok(None);
        };
        point = candidate;
        residuals = candidate_residuals;
        if maximum_delta * scale <= NONLINEAR_SOLVE_STEP_TOLERANCE * point_scale
            && !nonlinear_residuals_converged(&residuals)
        {
            return Ok(None);
        }
    }
    // A block that has not converged at the iteration ceiling stays unsolved.
    if !nonlinear_residuals_converged(&residuals) {
        work_caps.insert("MAX_NONLINEAR_SOLVE_ITERATIONS");
        return Ok(None);
    }
    let Some(mut rank_rows) =
        nonlinear_jacobian_rows(ctx, variable_count, &point, &residuals, |probe| {
            evaluate_nonlinear_residuals(
                ctx,
                block,
                values,
                variable_dimensions,
                probe,
                context,
                work_caps,
            )
        })?
    else {
        return Ok(None);
    };
    if solve_unique_affine_system(ctx, &mut rank_rows, variable_count)?.is_none() {
        return Ok(None);
    }
    Ok(Some(point))
}

/// Central-difference Jacobian rows of `residuals` at `point`, probing the
/// residuals through `evaluate`.
fn nonlinear_jacobian_rows(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    variable_count: usize,
    point: &[f64],
    residuals: &[SolveResidual],
    mut evaluate: impl FnMut(&[f64]) -> Result<Option<Vec<SolveResidual>>, cadmpeg_core::CodecError>,
) -> Result<Option<Vec<AffineEquationRow>>, cadmpeg_core::CodecError> {
    let mut rows = Vec::new();
    for (row_index, residual) in residuals.iter().enumerate() {
        let mut coefficients = Vec::new();
        for column in 0..variable_count {
            let step = NONLINEAR_SOLVE_DERIVATIVE_STEP * point[column].abs().max(1.0);
            let mut plus = ctx.alloc_filled(point.len(), 0.0, "creo nonlinear positive probe")?;
            let mut minus = ctx.alloc_filled(point.len(), 0.0, "creo nonlinear negative probe")?;
            plus.copy_from_slice(point);
            minus.copy_from_slice(point);
            plus[column] += step;
            minus[column] -= step;
            let Some(plus_residuals) = evaluate(&plus)? else {
                return Ok(None);
            };
            let Some(minus_residuals) = evaluate(&minus)? else {
                return Ok(None);
            };
            let Some(plus_residual) = plus_residuals.get(row_index) else {
                return Ok(None);
            };
            let Some(minus_residual) = minus_residuals.get(row_index) else {
                return Ok(None);
            };
            if plus_residual.dimension != residual.dimension
                || minus_residual.dimension != residual.dimension
            {
                return Ok(None);
            }
            let derivative = (plus_residual.value - minus_residual.value) / (2.0 * step);
            if !derivative.is_finite() {
                return Ok(None);
            }
            coefficients.push(derivative);
        }
        rows.push(AffineEquationRow {
            coefficients,
            rhs: 0.0,
        });
    }
    Ok(Some(rows))
}

fn evaluate_nonlinear_residuals(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    block: &CurveExpressionSolveBlock,
    values: &BTreeMap<String, CurveExpressionValue>,
    variable_dimensions: &[RelationDimension],
    point: &[f64],
    context: RelationEvaluationContext<'_>,
    work_caps: &mut BTreeSet<&'static str>,
) -> Result<Option<Vec<SolveResidual>>, cadmpeg_core::CodecError> {
    if variable_dimensions.len() != block.unknowns.len() || point.len() != variable_dimensions.len()
    {
        return Ok(None);
    }
    let mut evaluation_values = BTreeMap::new();
    for (name, value) in values {
        evaluation_values.insert(name.to_owned(), copy_expression_value(value));
    }
    for ((variable, dimension), value) in block
        .unknowns
        .iter()
        .map(|unknown| &unknown.name)
        .zip(variable_dimensions)
        .zip(point)
    {
        if !value.is_finite() {
            return Ok(None);
        }
        let mut key = variable.to_owned();
        key.make_ascii_lowercase();
        let Some(value) = quantity_value(*value, *dimension) else {
            return Ok(None);
        };
        evaluation_values.insert(key, value);
    }
    let mut residuals = Vec::new();
    let mut text_capped = false;
    for equation in &block.equations {
        let Some(left) = parse_capped_relation_expression::<CurveExpressionValue>(
            ctx,
            &equation.left,
            &evaluation_values,
            context,
            &mut text_capped,
        )?
        else {
            if text_capped {
                work_caps.insert("MAX_RELATION_EXPRESSION_TEXT_BYTES");
            }
            return Ok(None);
        };
        let Some(right) = parse_capped_relation_expression::<CurveExpressionValue>(
            ctx,
            &equation.right,
            &evaluation_values,
            context,
            &mut text_capped,
        )?
        else {
            if text_capped {
                work_caps.insert("MAX_RELATION_EXPRESSION_TEXT_BYTES");
            }
            return Ok(None);
        };
        let Some((left, left_dimension)) = quantity_parts_ref(&left) else {
            return Ok(None);
        };
        let Some((right, right_dimension)) = quantity_parts_ref(&right) else {
            return Ok(None);
        };
        if left_dimension != right_dimension {
            return Ok(None);
        }
        let value = left - right;
        let scale = left.abs().max(right.abs()).max(1.0);
        if !value.is_finite() || !scale.is_finite() {
            return Ok(None);
        }
        residuals.push(SolveResidual {
            value,
            scale,
            dimension: left_dimension,
        });
    }
    Ok(Some(residuals))
}

fn nonlinear_residual_norm(residuals: &[SolveResidual], reference: &[SolveResidual]) -> f64 {
    residuals
        .iter()
        .zip(reference)
        .map(|(residual, reference)| (residual.value / reference.scale).abs())
        .fold(0.0, f64::max)
}

fn nonlinear_residuals_converged(residuals: &[SolveResidual]) -> bool {
    residuals
        .iter()
        .all(|residual| residual.value.abs() <= NONLINEAR_SOLVE_RESIDUAL_TOLERANCE * residual.scale)
}

fn nonlinear_solutions_close(left: &[f64], right: &[f64]) -> bool {
    left.len() == right.len()
        && left.iter().zip(right).all(|(left, right)| {
            (left - right).abs()
                <= NONLINEAR_SOLVE_SOLUTION_TOLERANCE * left.abs().max(right.abs()).max(1.0)
        })
}

struct AffineEquationRow {
    coefficients: Vec<f64>,
    rhs: f64,
}

fn eliminate_pivot_column(
    rows: &mut [AffineEquationRow],
    pivot_row: usize,
    column: usize,
    coefficient_tolerance: f64,
) {
    let (before, pivot_and_after) = rows.split_at_mut(pivot_row);
    let Some((pivot, after)) = pivot_and_after.split_first_mut() else {
        return;
    };
    for row in before.iter_mut().chain(after.iter_mut()) {
        let factor = row.coefficients[column];
        if factor.abs() <= coefficient_tolerance {
            continue;
        }
        for (coefficient, pivot_coefficient) in row.coefficients.iter_mut().zip(&pivot.coefficients)
        {
            *coefficient -= factor * pivot_coefficient;
            if coefficient.abs() <= coefficient_tolerance {
                *coefficient = 0.0;
            }
        }
        row.rhs -= factor * pivot.rhs;
    }
}

fn solve_unique_affine_system(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    rows: &mut [AffineEquationRow],
    variable_count: usize,
) -> Result<Option<Vec<f64>>, cadmpeg_core::CodecError> {
    if variable_count == 0 || rows.len() < variable_count {
        return Ok(None);
    }
    for row in rows.iter_mut() {
        let scale = row
            .coefficients
            .iter()
            .map(|value| value.abs())
            .fold(0.0, f64::max);
        if scale > 0.0 {
            for coefficient in &mut row.coefficients {
                *coefficient /= scale;
            }
            row.rhs /= scale;
        }
    }
    let rhs_scale = rows.iter().map(|row| row.rhs.abs()).fold(1.0, f64::max);
    let coefficient_tolerance = EPS_LINEAR_SYSTEM_COEFFICIENT;
    let residual_tolerance = EPS_LINEAR_SYSTEM_RESIDUAL * rhs_scale;
    for (pivot_row, column) in (0..variable_count).enumerate() {
        let Some(selected) = (pivot_row..rows.len()).max_by(|&first, &second| {
            rows[first].coefficients[column]
                .abs()
                .total_cmp(&rows[second].coefficients[column].abs())
        }) else {
            return Ok(None);
        };
        let divisor = rows[selected].coefficients[column];
        if divisor.abs() <= coefficient_tolerance {
            return Ok(None);
        }
        rows.swap(pivot_row, selected);
        for coefficient in &mut rows[pivot_row].coefficients {
            *coefficient /= divisor;
        }
        rows[pivot_row].rhs /= divisor;
        eliminate_pivot_column(rows, pivot_row, column, coefficient_tolerance);
    }
    if !rows.iter().skip(variable_count).all(|row| {
        row.coefficients
            .iter()
            .all(|coefficient| coefficient.abs() <= coefficient_tolerance)
            && row.rhs.abs() <= residual_tolerance
    }) {
        return Ok(None);
    }
    let mut solution = ctx.alloc_filled(variable_count, 0.0, "creo affine unique solution")?;
    for (slot, row) in solution.iter_mut().zip(rows.iter()) {
        *slot = row.rhs;
    }
    Ok(solution
        .iter()
        .all(|value| value.is_finite())
        .then_some(solution))
}

fn evaluate_affine_program(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    record: &CurveExpressionRecord,
) -> Result<BTreeMap<String, AffineValue>, cadmpeg_core::CodecError> {
    let mut values = BTreeMap::new();
    values.insert(
        "t".to_owned(),
        AffineValue {
            constant: 0.0,
            linear: 1.0,
        },
    );
    let mut defined_symbols = BTreeSet::new();
    defined_symbols.insert("t".to_owned());
    for assignment in &record.assignments {
        let Some((name, declared_unit)) = assignment.parameter_target() else {
            continue;
        };
        let mut key = name.to_owned();
        key.make_ascii_lowercase();
        let declaration_is_valid = declared_unit.is_none() || !defined_symbols.contains(&key);
        if !defined_symbols.contains(&key) {
            defined_symbols.insert(key.clone());
        }
        match assignment.activation {
            CurveExpressionActivation::Active => {
                let value = if declaration_is_valid {
                    parse_relation_expression::<crate::curve::AffineValue>(
                        ctx,
                        &assignment.expression,
                        &values,
                        RelationEvaluationContext::default(),
                    )?
                    .map(|value| match declared_unit {
                        Some(unit) => match relation_unit(ctx, unit)? {
                            Some(unit) => value.with_unit_checked(unit),
                            None => Ok(None),
                        },
                        None => Ok(Some(value)),
                    })
                    .transpose()?
                    .flatten()
                } else {
                    None
                };
                if let Some(value) = value {
                    values.insert(key, value);
                } else {
                    values.remove(&key);
                }
            }
            CurveExpressionActivation::Inactive => {}
            CurveExpressionActivation::Conditional => {
                values.remove(&key);
            }
        }
    }
    Ok(values)
}

/// Recognize an exact cylindrical helix program expressed by the conventional
/// Creo outputs `r`, `theta` (degrees), and `z` over `t` in `[0, 1]`.
pub(crate) fn expression_helix(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    record: &CurveExpressionRecord,
) -> Result<Option<CurveExpressionHelix>, cadmpeg_core::CodecError> {
    if !record.prohibited_constructs.is_empty()
        || !record.solve_blocks.is_empty()
        || record.unresolved_solve_control
    {
        return Ok(None);
    }
    for output in ["r", "theta", "z"] {
        if !record.assignments.iter().any(|assignment| {
            assignment
                .parameter_target()
                .is_some_and(|(name, _)| name.eq_ignore_ascii_case(output))
        }) {
            return Ok(None);
        }
    }
    let values = evaluate_affine_program(ctx, record)?;
    Ok((|| {
        let radius = values.get("r")?;
        let theta = values.get("theta")?;
        let z = values.get("z")?;
        if radius.linear != 0.0 {
            return None;
        }
        let angular_travel = theta.linear;
        CurveExpressionHelix::new(
            radius.constant,
            z.linear,
            z.constant,
            angular_travel.abs() / 360.0,
            theta.constant.to_radians(),
            angular_travel < 0.0,
        )
    })())
}

/// Decode positional `crv_array` rows whose terminal suffix has one
/// syntactically valid boundary. Callers that have decoded the enclosing
/// `srf_array` should use [`topology_rows_with_face_ids`] so an ambiguous
/// reference boundary can be resolved by its face roles.
#[cfg(test)]
fn topology_rows(payload: &[u8]) -> Vec<CurveTopologyRow> {
    topology_rows_with_face_ids(payload, None)
}

/// Decode standard topology rows using the enclosing `srf_array` identifier
/// set to resolve variable-width reference boundaries.
pub(crate) fn topology_rows_with_face_ids(
    payload: &[u8],
    face_ids: Option<&BTreeSet<u32>>,
) -> Vec<CurveTopologyRow> {
    let mut rows = Vec::new();
    for row in framed_rows_with_face_ids(payload, face_ids) {
        if let Some(parsed) = parse_topology_row(
            &payload[row.start..row.end],
            row.start,
            row.suffix_start,
            row.suffix,
        ) {
            rows.push(parsed);
        }
    }
    rows.as_mut_slice().sort_by_key(|left| left.offset);
    rows.dedup_by_key(|row| row.offset);
    rows
}

/// Decode a complete DEPDB `crv_array\0 f2 f8 <count>` cross-section array.
/// Any malformed row or count mismatch withholds the entire array.
pub(crate) fn depdb_cross_section_rows(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    payload: &[u8],
) -> Result<Vec<DepdbCurveRow>, cadmpeg_core::CodecError> {
    let Some(array) = find(payload, b"crv_array\0", 0) else {
        return Ok(Vec::new());
    };
    let header = array + b"crv_array\0".len();
    if payload.get(header..header + 2) != Some(&[0xf2, psb::token::ARRAY_OPEN]) {
        return Ok(Vec::new());
    }
    let (count, after_count) = compact_int(payload, header + 2);
    if after_count == header + 2 {
        return Ok(Vec::new());
    }
    let Ok(count) = usize::try_from(count) else {
        return Ok(Vec::new());
    };
    if count == 0 || prototypes(payload).len() != 1 {
        return Ok(Vec::new());
    }
    let Some(topology) = find(payload, b"topol_ref_data\0", after_count) else {
        return Ok(Vec::new());
    };
    let mut cursor = topology + b"topol_ref_data\0".len();
    let positional_count = count - 1;
    // Each row consumes at least one payload byte past the topology cursor
    // before its terminator, so the row count cannot exceed the unread bytes.
    if bounded_len(
        cadmpeg_core::decode::u64_from_index(positional_count),
        1,
        payload.get(cursor..).map_or(0, <[u8]>::len),
    )
    .is_none()
    {
        return Ok(Vec::new());
    }
    let mut rows = Vec::new();
    let mut boundaries = Vec::new();
    for (marker, length) in [
        (b"\xe1\xe3".as_slice(), 2),
        (b"\xe1\xf5\x05\xf6\xe3", 5),
        (b"\xe1\xe0", 1),
    ] {
        let mut search = cursor;
        while let Some(offset) = find(payload, marker, search) {
            boundaries.push((offset, length));
            search = offset + marker.len();
        }
    }
    // This close is owned by the end of the supplied cross-section payload;
    // an interior image does not establish a curve-row boundary.
    let section_terminal = b"\xe1\xf4\x04";
    if let Some(before_close) = payload.strip_suffix(section_terminal) {
        boundaries.push((before_close.len(), section_terminal.len()));
    }
    boundaries.sort_unstable_by(Ord::cmp);
    boundaries.dedup();
    while rows.len() < positional_count {
        let first_candidate = boundaries.partition_point(|(end, _)| *end < cursor);
        let mut selected = None;
        for (end, length) in boundaries[first_candidate..].iter().copied() {
            if let Some(row) = parse_depdb_curve_segment(ctx, &payload[cursor..end], cursor)? {
                selected = Some((row, end, length));
                break;
            }
        }
        let Some((row, terminator, length)) = selected else {
            return Ok(Vec::new());
        };
        rows.push(row);
        cursor = terminator + length;
    }
    if rows.len() == positional_count {
        Ok(rows)
    } else {
        Ok(Vec::new())
    }
}

fn cross_section_suffix_fields(segment: &[u8], start: usize) -> Option<[u32; 6]> {
    let mut fields = [0; 6];
    let mut cursor = start;
    for field in &mut fields {
        let (value, next) = psb::reference_id(segment, cursor).ok()?;
        *field = value;
        cursor = next;
    }
    (cursor == segment.len() && fields[0] == 0 && fields[2] == 0 && fields[5] == 0)
        .then_some(fields)
}

fn parse_depdb_curve_segment(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    segment: &[u8],
    absolute_offset: usize,
) -> Result<Option<DepdbCurveRow>, cadmpeg_core::CodecError> {
    let mut suffix_candidate = None;
    for suffix_length in 6..=9 {
        let Some(start) = segment.len().checked_sub(suffix_length) else {
            continue;
        };
        let Some(fields) = cross_section_suffix_fields(segment, start) else {
            continue;
        };
        if suffix_candidate.is_some() {
            return Ok(None);
        }
        suffix_candidate = Some((start, fields));
    }
    let Some((suffix_start, suffix)) = suffix_candidate else {
        return Ok(None);
    };
    let mut prefix_candidate: Option<(usize, TopologyPrefix)> = None;
    for start in 0..suffix_start {
        let Some(prefix) = topology_prefix_fields(segment, start) else {
            continue;
        };
        if prefix.end > suffix_start {
            continue;
        }
        match prefix_candidate {
            None => prefix_candidate = Some((start, prefix)),
            Some((_, known)) if known.end == prefix.end => {}
            Some(_) => return Ok(None),
        }
    }
    let Some((row_start, prefix)) = prefix_candidate else {
        return Ok(None);
    };
    let source_body = &segment[prefix.end..suffix_start];
    let mut body = ctx.alloc_filled(source_body.len(), 0, "creo cross-section body bytes")?;
    body.copy_from_slice(source_body);
    // Prefix and pointer ownership do not establish the body's internal
    // scalar grammar. Do not resynchronize into unowned coordinate images.
    let opaque_spans = if body.is_empty() {
        Vec::new()
    } else {
        let mut raw = ctx.alloc_filled(body.len(), 0, "creo cross-section opaque bytes")?;
        raw.copy_from_slice(&body);
        ctx.alloc_filled(
            1,
            CurveParameterOpaqueSpan { raw, offset: 0 },
            "creo cross-section opaque body",
        )?
    };
    Ok(Some(DepdbCurveRow {
        id: prefix.id,
        type_byte: prefix.type_byte,
        feature_id: prefix.feature_id,
        directions: prefix.directions,
        suffix: DepdbCurveSuffix {
            section_plane: suffix[1],
            next_curve: suffix[3],
            reference_surface: suffix[4],
        },
        body,
        scalar_tokens: Vec::new(),
        references: Vec::new(),
        opaque_spans,
        offset: absolute_offset + row_start,
    }))
}

#[derive(Debug, Clone, Copy)]
struct FramedRow {
    namespace_start: usize,
    start: usize,
    end: usize,
    suffix_start: usize,
    suffix: [u32; 4],
    reference_geometry: [u32; 2],
    counted_body: bool,
    bare_matrix_body: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct TopologySuffixCandidate {
    start: usize,
    faces: [Option<NonZeroU32>; 2],
    next_edges: [u32; 2],
    reference_geometry: [u32; 2],
}

impl TopologySuffixCandidate {
    fn stored_references(self) -> [u32; 4] {
        let [f0, f1] = self.faces.map(stored_face_reference);
        let [e0, e1] = self.next_edges;
        [f0, f1, e0, e1]
    }
}

#[derive(Debug, Clone, Copy)]
struct TopologyPrefix {
    id: u32,
    type_byte: u8,
    feature_id: u32,
    directions: [u8; 2],
    end: usize,
}

fn row_terminator(payload: &[u8], start: usize, end: usize) -> Option<(usize, usize)> {
    let short = find_in(payload, b"\xe1\xe3", start, end).map(|offset| (offset, 2));
    let long_search_end = match short {
        Some((offset, _)) => offset.checked_add(b"\xe1\xf5\x05\xf6\xe3".len())?.min(end),
        None => end,
    };
    let long =
        find_in(payload, b"\xe1\xf5\x05\xf6\xe3", start, long_search_end).map(|offset| (offset, 5));
    match (short, long) {
        (Some(left), Some(right)) => Some(if left.0 < right.0 { left } else { right }),
        (Some(value), None) | (None, Some(value)) => Some(value),
        (None, None) => None,
    }
}

const CURVE_NAMESPACE_BOUNDARIES: [&[u8]; 4] = [
    b"crv_array\0",
    b"lo_array\0",
    b"qlt_array\0",
    b"srf_array\0",
];

fn curve_namespace_end(payload: &[u8], start: usize) -> usize {
    CURVE_NAMESPACE_BOUNDARIES
        .iter()
        .filter_map(|label| find(payload, label, start))
        .min()
        .unwrap_or(payload.len())
}

fn framed_rows_with_face_ids(payload: &[u8], face_ids: Option<&BTreeSet<u32>>) -> Vec<FramedRow> {
    let mut result = Vec::new();
    let mut arrays = Vec::new();
    let mut search = 0;
    while let Some(array) = find(payload, b"crv_array\0", search) {
        arrays.push(array + b"crv_array\0".len());
        search = array + b"crv_array\0".len();
    }
    if arrays.is_empty() {
        arrays.push(0);
    }
    for (index, &namespace_start) in arrays.iter().enumerate() {
        let namespace_end = arrays.get(index + 1).map_or_else(
            || curve_namespace_end(payload, namespace_start),
            |next| next - b"crv_array\0".len(),
        );
        let Some(label) = find_in(payload, b"topol_ref_data\0", namespace_start, namespace_end)
        else {
            continue;
        };
        let mut cursor = label + b"topol_ref_data\0".len();
        let mut boundary_anchored = false;
        let mut segments = Vec::new();
        while let Some((terminator, length)) = row_terminator(payload, cursor, namespace_end) {
            segments.push((cursor, terminator, boundary_anchored));
            cursor = terminator + length;
            boundary_anchored = true;
        }
        if cursor < namespace_end {
            segments.push((cursor, namespace_end, boundary_anchored));
        }
        let known_face_ids = if let Some(face_ids) = face_ids {
            let mut known = BTreeSet::new();
            for id in face_ids {
                known.insert(*id);
            }
            for &(start, end, _) in &segments {
                let Some(suffix) = unique_topology_suffix_in_segment(&payload[start..end]) else {
                    continue;
                };
                for id in suffix.faces.into_iter().flatten().map(NonZeroU32::get) {
                    known.insert(id);
                }
            }
            Some(known)
        } else {
            None
        };
        let mut matrix_shapes = BTreeMap::new();
        if let Some((key, count)) =
            named_curve_matrix_shape(payload, namespace_start, label, namespace_end)
        {
            matrix_shapes.insert(key, count);
        }
        for &(start, end, boundary_anchored) in &segments {
            if boundary_anchored {
                if let Some(prefix) = topology_prefix_fields(&payload[start..end], 0) {
                    if payload.get(start + prefix.end) == Some(&0xfc) {
                        matrix_shapes.retain(|&(owner, kind, _), _| {
                            owner != prefix.feature_id || kind != prefix.type_byte
                        });
                    }
                }
            }
            let legacy = framed_segment_with_face_ids(
                payload,
                namespace_start,
                (start, end),
                boundary_anchored,
                face_ids,
                known_face_ids.as_ref(),
            );
            let declared = declared_bare_curve_frame(
                payload,
                namespace_start,
                (start, end),
                boundary_anchored,
                &matrix_shapes,
            );
            let row = match (legacy, declared) {
                (Some(existing), Some(declared))
                    if existing.start == declared.start
                        && existing.end == declared.end
                        && existing.suffix_start == declared.suffix_start =>
                {
                    Some(existing)
                }
                (_, Some(declared)) => Some(declared),
                (existing, None) => existing,
            };
            if let Some(row) = row {
                update_curve_matrix_shape(payload, row, end, &mut matrix_shapes);
                result.push(row);
            }
        }
        loop {
            let mut added = Vec::new();
            let mut neighbors = BTreeMap::<u32, Option<CurveTopologyRow>>::new();
            let mut incoming = BTreeMap::<(NonZeroU32, u32), usize>::new();
            for row in result
                .iter()
                .filter(|row| row.namespace_start == namespace_start)
            {
                let Some(topology) = payload.get(row.start..row.end).and_then(|bytes| {
                    parse_topology_row(bytes, row.start, row.suffix_start, row.suffix)
                }) else {
                    continue;
                };
                for side in 0..2 {
                    if let Some(face) = topology.faces[side] {
                        *incoming
                            .entry((face, topology.next_edges[side]))
                            .or_default() += 1;
                    }
                }
                match neighbors.entry(topology.id) {
                    std::collections::btree_map::Entry::Occupied(mut entry) => {
                        entry.insert(None);
                    }
                    std::collections::btree_map::Entry::Vacant(entry) => {
                        entry.insert(Some(topology));
                    }
                }
            }
            for &(start, end, anchored) in &segments {
                if !anchored || result.iter().any(|row| row.start == start) {
                    continue;
                }
                if let Some(row) = framed_segment_with_topology(
                    payload,
                    namespace_start,
                    (start, end),
                    &neighbors,
                    &incoming,
                ) {
                    added.push(row);
                }
            }
            if added.is_empty() {
                break;
            }
            result.extend(added);
        }
    }
    result.as_mut_slice().sort_by_key(|left| left.start);
    result.dedup_by_key(|row| row.start);
    result
}

type CurveMatrixKey = (u32, u8, u32);

fn scalar_matrix_end(bytes: &[u8], mut cursor: usize, rows: u32) -> Option<usize> {
    let remaining = bytes.len().checked_sub(cursor)?;
    let slots = bounded_len(u64::from(rows), 4, remaining)?.checked_mul(4)?;
    for _ in 0..slots {
        let width = match bytes.get(cursor)? {
            0x18 => 1,
            0x28 | 0x2d | 0x41 | 0x46 => 8,
            0x4b..=0xdf => 7,
            _ => return None,
        };
        let next = cursor.checked_add(width)?;
        bytes.get(cursor..next)?;
        cursor = next;
    }
    Some(cursor)
}

fn curve_parameter_class(linkage: &[u8]) -> Option<u32> {
    let mut result = None;
    for width in 1..=2 {
        let Some(start) = linkage.len().checked_sub(width) else {
            continue;
        };
        let Some((class, end)) = generic_compact_at(linkage, start) else {
            continue;
        };
        if end != linkage.len() {
            continue;
        }
        let before = &linkage[..start];
        let complete = before.is_empty()
            || before == [0xf7, 0x16]
            || before.strip_prefix(&[0xf7, 0x27]).is_some_and(|reference| {
                reference == [0xf6]
                    || generic_compact_at(reference, 0)
                        .is_some_and(|(_, end)| end == reference.len())
            })
            || generic_compact_at(before, 0).is_some_and(|(_, end)| end == before.len());
        if complete {
            if result.is_some() {
                return None;
            }
            result = Some(class);
        }
    }
    result
}

fn named_curve_matrix_shape(
    payload: &[u8],
    start: usize,
    topology_label: usize,
    namespace_end: usize,
) -> Option<(CurveMatrixKey, u32)> {
    let integer = |label: &[u8]| {
        let at = unique_find_in(payload, label, start, topology_label)? + label.len();
        generic_compact_at(payload, at).map(|(value, _)| value)
    };
    let owner = integer(b"\xe0\x01feat_id\0")?;
    let kind = integer(b"\xe0\x01type\0")?;
    (owner != 0 && kind == 8).then_some(())?;
    let points = unique_find_in(payload, b"\xe0\x02crv_pnt_arr\0", start, topology_label)?
        + b"\xe0\x02crv_pnt_arr\0".len();
    (payload.get(points) == Some(&0xf9)).then_some(())?;
    let (count, cursor) = generic_compact_at(payload, points + 1)?;
    let (columns, cursor) = generic_compact_at(payload, cursor)?;
    (count >= 2 && columns == 4).then_some(())?;
    let matrix_end = scalar_matrix_end(payload.get(..topology_label)?, cursor, count)?;
    (payload.get(matrix_end..matrix_end + b"\xe0\x01crv_hdr_geom_ptr[0]\0".len())
        == Some(b"\xe0\x01crv_hdr_geom_ptr[0]\0"))
    .then_some(())?;
    let close = topology_label + b"topol_ref_data\0".len();
    (payload.get(close) == Some(&0xe3)).then_some(())?;
    let entry_end = [b"\xe1\xf2\xe3".as_slice(), b"\xe1\xf5\x05\xf6\xf2\xe3"]
        .into_iter()
        .filter_map(|footer| find_in(payload, footer, close + 1, namespace_end))
        .min()?;
    let class = curve_parameter_class(payload.get(close + 1..entry_end)?)?;
    Some(((owner, 8, class), count))
}

fn update_curve_matrix_shape(
    payload: &[u8],
    row: FramedRow,
    segment_end: usize,
    shapes: &mut BTreeMap<CurveMatrixKey, u32>,
) {
    let bytes = &payload[row.start..row.end];
    let Some(prefix) = topology_prefix(bytes, 0, row.suffix_start) else {
        return;
    };
    if prefix.type_byte != 8 || prefix.feature_id == 0 {
        return;
    }
    let Some(class) = curve_parameter_class(&payload[row.end..segment_end]) else {
        return;
    };
    let body = &bytes[prefix.end..row.suffix_start];
    if body.first() != Some(&0xfc) {
        return;
    }
    let key = (prefix.feature_id, prefix.type_byte, class);
    shapes.remove(&key);
    let Some((count, cursor)) = generic_compact_at(body, 1) else {
        return;
    };
    if count >= 2 && count != 5 && scalar_matrix_end(body, cursor, count) == Some(body.len()) {
        shapes.insert(key, count);
    }
}

fn declared_bare_curve_frame(
    payload: &[u8],
    namespace_start: usize,
    bounds: (usize, usize),
    boundary_anchored: bool,
    shapes: &BTreeMap<CurveMatrixKey, u32>,
) -> Option<FramedRow> {
    let (start, end) = bounds;
    let segment = payload.get(start..end)?;
    let mut result = None;
    for (row_start, _) in segment.iter().enumerate().filter(|(at, _)| {
        (boundary_anchored && *at == 0)
            || (*at >= 3 && segment.get(at - 3..*at) == Some(&[0xe1, 0xf2, 0xe3]))
            || (*at >= 6 && segment.get(at - 6..*at) == Some(&[0xe1, 0xf5, 0x05, 0xf6, 0xf2, 0xe3]))
    }) {
        let Some(prefix) = topology_prefix_fields(segment, row_start) else {
            continue;
        };
        if prefix.type_byte != 8 || segment.get(prefix.end) == Some(&0xfc) {
            continue;
        }
        for close in prefix.end..segment.len() {
            if segment[close] != 0xe3 {
                continue;
            }
            let Some(class) = curve_parameter_class(&segment[close + 1..]) else {
                continue;
            };
            let Some(&count) = shapes.get(&(prefix.feature_id, prefix.type_byte, class)) else {
                continue;
            };
            let Some(suffix_start) = scalar_matrix_end(segment, prefix.end, count) else {
                continue;
            };
            let Some(candidates) = topology_suffix_candidates(&segment[row_start..=close]) else {
                continue;
            };
            for candidate in candidates.into_iter().flatten() {
                if row_start + candidate.start != suffix_start {
                    continue;
                }
                if result.is_some() {
                    return None;
                }
                result = Some(FramedRow {
                    namespace_start,
                    start: start + row_start,
                    end: start + close + 1,
                    suffix_start: candidate.start,
                    suffix: candidate.stored_references(),
                    reference_geometry: candidate.reference_geometry,
                    counted_body: false,
                    bare_matrix_body: true,
                });
            }
        }
    }
    result
}

fn framed_segment_with_topology(
    payload: &[u8],
    namespace_start: usize,
    (start, end): (usize, usize),
    neighbors: &BTreeMap<u32, Option<CurveTopologyRow>>,
    incoming: &BTreeMap<(NonZeroU32, u32), usize>,
) -> Option<FramedRow> {
    let segment = payload.get(start..end)?;
    let prefix = topology_prefix_fields(segment, 0)?;
    if neighbors.contains_key(&prefix.id) {
        return None;
    }
    let mut matching = Vec::new();
    for close in segment
        .iter()
        .enumerate()
        .filter_map(|(offset, byte)| (*byte == psb::token::COMPOUND_CLOSE).then_some(offset))
    {
        let row_end = close + 1;
        if !complete_curve_row_linkage(&segment[row_end..]) {
            continue;
        }
        let Some(suffixes) = topology_suffix_candidates(&segment[..row_end]) else {
            continue;
        };
        for suffix in suffixes.into_iter().flatten() {
            if suffix.start < prefix.end {
                continue;
            }
            let valid = (0..2).all(|side| {
                let Some(face) = suffix.faces[side] else {
                    return false;
                };
                let target = suffix.next_edges[side];
                let unique_target = neighbors
                    .get(&target)
                    .and_then(Option::as_ref)
                    .is_some_and(|row| row.faces.contains(&Some(face)));
                unique_target && incoming.get(&(face, prefix.id)) == Some(&1)
            });
            if valid {
                matching.push(FramedRow {
                    namespace_start,
                    start,
                    end: start + row_end,
                    suffix_start: suffix.start,
                    suffix: suffix.stored_references(),
                    reference_geometry: suffix.reference_geometry,
                    counted_body: false,
                    bare_matrix_body: false,
                });
            }
        }
    }
    let [row] = matching.as_slice() else {
        return None;
    };
    Some(*row)
}

fn framed_segment_with_face_ids(
    payload: &[u8],
    namespace_start: usize,
    bounds: (usize, usize),
    boundary_anchored: bool,
    materialized_face_ids: Option<&BTreeSet<u32>>,
    known_face_ids: Option<&BTreeSet<u32>>,
) -> Option<FramedRow> {
    let (start, end) = bounds;

    let segment = payload.get(start..end)?;
    let mut prefixes = Vec::new();
    for row_start in 0..segment.len() {
        if let Some(prefix) = topology_prefix_fields(segment, row_start) {
            prefixes.push((row_start, prefix.end));
        }
    }
    prefixes.sort_unstable_by_key(|left| left.1);
    let closes = segment
        .iter()
        .enumerate()
        .filter(|(_, byte)| **byte == psb::token::COMPOUND_CLOSE)
        .map(|(offset, _)| offset)
        .rev();
    for close in closes {
        let row_end = close + 1;
        if !complete_curve_row_linkage(&segment[row_end..]) {
            continue;
        }
        let Some((candidate, counted_body)) = topology_suffix_with_face_ids(
            &segment[..row_end],
            materialized_face_ids,
            known_face_ids,
        ) else {
            continue;
        };
        let suffix_start = candidate.start;
        let suffix = candidate.stored_references();
        let reference_geometry = candidate.reference_geometry;
        if boundary_anchored
            && topology_prefix_fields(segment, 0).is_some_and(|prefix| prefix.end <= suffix_start)
        {
            return Some(FramedRow {
                namespace_start,
                start,
                end: start + row_end,
                suffix_start,
                suffix,
                reference_geometry,
                counted_body,
                bare_matrix_body: false,
            });
        }
        let eligible = prefixes.partition_point(|(_, prefix_end)| *prefix_end <= suffix_start);
        if eligible == 1 {
            return Some(FramedRow {
                namespace_start,
                start: start + prefixes[0].0,
                end: start + row_end,
                suffix_start: suffix_start - prefixes[0].0,
                suffix,
                reference_geometry,
                counted_body,
                bare_matrix_body: false,
            });
        }
    }
    None
}

fn generic_compact_at(bytes: &[u8], offset: usize) -> Option<(u32, usize)> {
    (*bytes.get(offset)? <= 0xbf).then_some(())?;
    let (value, next) = compact_int(bytes, offset);
    (next > offset).then_some((value, next))
}

/// Validate the array-item linkage between a curve row's compound close and
/// its row terminator. The linkage has an optional entity link, an optional
/// counted link list, and up to four terminal compact links. The final row may
/// append the enclosing array close before the next namespace boundary.
fn complete_curve_row_linkage(bytes: &[u8]) -> bool {
    let bytes = bytes
        .strip_suffix(&[0xe1, 0xf5, 0x05, 0xf6, 0xe0, 0x00])
        .or_else(|| bytes.strip_suffix(&[0xe1, 0xe0, 0x00]))
        .unwrap_or(bytes);
    let mut cursor = 0;
    if bytes.get(cursor) == Some(&psb::token::ENTITY_REF) {
        let Some((_, next)) = generic_compact_at(bytes, cursor + 1) else {
            return false;
        };
        cursor = next;
    }
    if bytes.get(cursor) == Some(&psb::token::ARRAY_OPEN) {
        let Some((count, next)) = generic_compact_at(bytes, cursor + 1) else {
            return false;
        };
        let Some(remaining) = bytes.len().checked_sub(next) else {
            return false;
        };
        let Some(count) = bounded_len(count.into(), 1, remaining) else {
            return false;
        };
        cursor = next;
        for _ in 0..count {
            let Some((_, next)) = generic_compact_at(bytes, cursor) else {
                return false;
            };
            cursor = next;
        }
    }
    let mut terminal_count = 0;
    while cursor < bytes.len() {
        let Some((_, next)) = generic_compact_at(bytes, cursor) else {
            return false;
        };
        cursor = next;
        terminal_count += 1;
    }
    terminal_count <= 4
}

#[derive(Debug)]
struct CurveScalarLane {
    scalar_tokens: Vec<CurveParameterScalar>,
    references: Vec<CurveParameterReference>,
    opaque_spans: Vec<CurveParameterOpaqueSpan>,
}

fn curve_scalar_lane(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    body: &[u8],
    type_byte: u8,
    cache: &scalar::ScalarCache,
) -> Result<CurveScalarLane, cadmpeg_core::CodecError> {
    if matches!(type_byte, 0x00 | 0x01 | 0x06 | 0x08) {
        if let Some(frame) = scalar::decode_pcurve_scalar_frame(body, cache)
            .or_else(|| scalar::sheet_frames::pcurve(body, cache).and_then(Result::ok))
        {
            let mut scalar_tokens = ctx.alloc_filled(
                frame.token_count,
                CurveParameterScalar {
                    value: 0.0,
                    raw: Vec::new(),
                    offset: 0,
                },
                "creo pcurve scalar tokens",
            )?;
            for (record, token) in scalar_tokens
                .iter_mut()
                .zip(frame.tokens.into_iter().flatten())
            {
                record.value = token.value;
                record.raw = body[token.offset..token.end].to_vec();
                record.offset = token.offset;
            }
            return Ok(CurveScalarLane {
                scalar_tokens,
                references: Vec::new(),
                opaque_spans: Vec::new(),
            });
        }
    }
    let mut scalars = Vec::new();
    let mut references = Vec::new();
    let mut claimed = ctx.alloc_filled(body.len(), false, "creo curve scalar claims")?;
    let mut cursor = 0;
    while cursor < body.len() {
        if body[cursor] == psb::token::ENTITY_REF {
            if let Ok((reference, next)) = reference_id(body, cursor + 1) {
                references.push(CurveParameterReference {
                    entity_id: reference,
                    offset: cursor,
                    length: next - cursor,
                });
                claimed[cursor..next].fill(true);
                cursor = next;
                continue;
            }
        }
        if body[cursor] == 0x18
            && cursor + 1 == body.len()
            && matches!(type_byte, 0x00 | 0x01 | 0x06 | 0x08)
            && scalars.len() < 8
        {
            let raw = body[cursor..=cursor].to_vec();
            scalars.push(CurveParameterScalar {
                value: 0.0,
                raw,
                offset: cursor,
            });
            claimed[cursor] = true;
            cursor += 1;
            continue;
        }
        let decoded = if matches!(type_byte, 0x00 | 0x01 | 0x06 | 0x08) {
            scalar::decode_in_pcurve_lane(body, cursor, cache)
        } else {
            scalar::decode_in_row_lane(body, cursor, cache)
        };
        if let Some((value, next)) = decoded {
            let raw = body[cursor..next].to_vec();
            scalars.push(CurveParameterScalar {
                value,
                raw,
                offset: cursor,
            });
            claimed[cursor..next].fill(true);
            cursor = next;
        } else {
            cursor += 1;
        }
    }
    let opaque_spans = curve_opaque_spans(body, &claimed);
    Ok(CurveScalarLane {
        scalar_tokens: scalars,
        references,
        opaque_spans,
    })
}

fn curve_opaque_spans(body: &[u8], claimed: &[bool]) -> Vec<CurveParameterOpaqueSpan> {
    let mut opaque_spans = Vec::new();
    let mut cursor = 0;
    while cursor < body.len() {
        if claimed[cursor] {
            cursor += 1;
            continue;
        }
        let start = cursor;
        while cursor < body.len() && !claimed[cursor] {
            cursor += 1;
        }
        let raw = body[start..cursor].to_vec();
        opaque_spans.push(CurveParameterOpaqueSpan { raw, offset: start });
    }
    opaque_spans
}

/// Decode analytic bodies from positional curve rows with one valid terminal
/// topology suffix. Use [`parameter_records_with_face_ids`] when the enclosing
/// `srf_array` identifiers are available.
#[cfg(test)]
fn parameter_records(payload: &[u8]) -> Vec<CurveParameterRecord> {
    crate::decode::with_service_context(|ctx| parameter_records_with_face_ids(ctx, payload, None))
        .expect("test curve parameter records")
}

/// Decode analytic bodies using the enclosing `srf_array` identifier set to
/// resolve variable-width reference boundaries.
pub(crate) fn parameter_records_with_face_ids(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    payload: &[u8],
    face_ids: Option<&BTreeSet<u32>>,
) -> Result<Vec<CurveParameterRecord>, cadmpeg_core::CodecError> {
    let cache = scalar::ScalarCache::from_section_checked(payload);
    let mut records = Vec::new();
    for framed in framed_rows_with_face_ids(payload, face_ids) {
        let row = &payload[framed.start..framed.end];
        let (curve_id, after_id) = compact_int(row, 0);
        let Some(&type_byte) = row.get(after_id) else {
            continue;
        };
        let (_, after_feature) = compact_int(row, after_id + 1);
        let body_start = after_feature + 2;
        let Some(close) = row.len().checked_sub(1) else {
            continue;
        };
        if row.get(close) != Some(&psb::token::COMPOUND_CLOSE) || body_start > close {
            continue;
        }
        let suffix_start = framed.suffix_start;
        if suffix_start < body_start {
            continue;
        }
        let body = row[body_start..suffix_start].to_vec();
        let CurveScalarLane {
            scalar_tokens,
            references,
            opaque_spans,
        } = if framed.bare_matrix_body || framed.counted_body {
            CurveScalarLane {
                scalar_tokens: Vec::new(),
                references: Vec::new(),
                opaque_spans: vec![CurveParameterOpaqueSpan {
                    offset: 0,
                    raw: body.clone(),
                }],
            }
        } else {
            curve_scalar_lane(ctx, &body, type_byte, &cache)?
        };
        records.push(CurveParameterRecord {
            curve_id,
            type_byte,
            body,
            scalar_tokens,
            references,
            opaque_spans,
            reference_geometry: framed.reference_geometry,
            offset: framed.start,
            body_offset: framed.start + body_start,
            suffix_offset: framed.start + suffix_start,
            count_framed: framed.counted_body,
        });
    }
    for frame in two_chart_scalar_frames(payload, face_ids, &cache, &mut Vec::new()) {
        if let Some(record) = records
            .iter_mut()
            .find(|record| record.offset == frame.offset)
        {
            if let Some(lane) = two_chart_scalar_lane(ctx, &frame, &cache)? {
                record.scalar_tokens = lane.scalar_tokens;
                record.references = lane.references;
                record.opaque_spans = lane.opaque_spans;
            }
        }
    }
    Ok(records)
}

fn claimed_pcurve_values(record: &CurveParameterRecord, require_held: bool) -> Option<[f64; 8]> {
    const HELD_SCALAR_CLOSE: u8 = 0x1e;

    record.references.is_empty().then_some(())?;
    let mut tokens = record.scalar_tokens.iter().peekable();
    let mut values = [0.0; 8];
    let mut value_count = 0;
    let mut cursor = 0;
    let mut held = false;
    while cursor < record.body.len() {
        if record
            .body
            .get(cursor..cursor + scalar::HELD_PCURVE_OPEN.len())
            == Some(scalar::HELD_PCURVE_OPEN)
        {
            held = true;
            cursor += scalar::HELD_PCURVE_OPEN.len();
            let token = tokens.next().filter(|token| token.offset == cursor)?;
            (!token.raw.is_empty()
                && record.body.get(cursor..cursor + token.raw.len()) == Some(token.raw.as_slice()))
            .then_some(())?;
            *values.get_mut(value_count)? = token.value;
            value_count += 1;
            cursor += token.raw.len();
            (record.body.get(cursor) == Some(&HELD_SCALAR_CLOSE)).then_some(())?;
            cursor += 1;
            continue;
        }
        if let Some(token) = tokens.peek().filter(|token| token.offset == cursor) {
            (!token.raw.is_empty()
                && record.body.get(cursor..cursor + token.raw.len()) == Some(token.raw.as_slice()))
            .then_some(())?;
            *values.get_mut(value_count)? = token.value;
            value_count += 1;
            cursor += token.raw.len();
            tokens.next();
        } else if record.body[cursor] == 0x12 {
            *values.get_mut(value_count)? = 0.0;
            value_count += 1;
            cursor += 1;
        } else {
            return None;
        }
    }
    tokens.next().is_none().then_some(())?;
    (value_count == values.len()
        && values.iter().all(|value| value.is_finite())
        && (!require_held || held))
        .then_some(values)
}

fn complete_pcurve_values(record: &CurveParameterRecord) -> Option<[f64; 8]> {
    record.references.is_empty().then_some(())?;
    scalar::decode_pcurve_scalar_frame(&record.body, &scalar::ScalarCache::default())
        .or_else(|| {
            scalar::sheet_frames::pcurve(&record.body, &scalar::ScalarCache::default())
                .and_then(Result::ok)
        })
        .map(|frame| frame.values)
        .or_else(|| claimed_pcurve_values(record, true))
}

/// Interpret complete eight-slot parameter lanes for pcurve-family rows.
pub(crate) fn pcurve_endpoints(
    parameters: &[CurveParameterRecord],
    topology: &[CurveTopologyRow],
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
) -> Vec<PcurveEndpoints> {
    let mut result = Vec::new();
    for record in crate::identity::uniquely_identified_rows(parameters, |record| record.curve_id) {
        if !matches!(record.type_byte, 0x00 | 0x01 | 0x06 | 0x08) {
            continue;
        }
        let Some(values) = complete_pcurve_values(record) else {
            if let Some(Err(reason)) =
                scalar::sheet_frames::pcurve(&record.body, &scalar::ScalarCache::default())
            {
                losses.push(
                    crate::loss::CreoLossCode::AngularEndpointLiteralUnresolved.note(format!(
                        "Curve {} at payload byte {}: {reason}; its endpoint body remains native",
                        record.curve_id, record.offset,
                    )),
                );
                continue;
            }
            if claimed_pcurve_values(record, false).is_some() {
                losses.push(crate::loss::CreoLossCode::PcurveScalarFrameUnresolved.note(format!(
                    "Curve {} at byte {} has no complete positional pcurve scalar frame; its bytes remain native",
                    record.curve_id, record.offset
                )));
            }
            continue;
        };
        let mut matching = topology.iter().filter(|row| row.id == record.curve_id);
        let Some(topology) = matching.next() else {
            continue;
        };
        if matching.next().is_some() || topology.type_byte != record.type_byte {
            continue;
        }
        result.push(PcurveEndpoints {
            curve_id: record.curve_id,
            faces: topology.faces,
            face_0_endpoints: [[values[0], values[1]], [values[4], values[5]]],
            face_1_endpoints: [[values[2], values[3]], [values[6], values[7]]],
            offset: record.offset,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

#[derive(Clone, Copy)]
enum TwoChartScalarMode {
    Legacy,
    Angular,
    RevolutionEndpoint,
}

fn two_chart_scalar_run(
    body: &[u8],
    cursor: usize,
    slot: usize,
    previous: Option<f64>,
    cache: &scalar::ScalarCache,
    mode: TwoChartScalarMode,
) -> Option<(f64, usize, usize)> {
    if matches!(
        mode,
        TwoChartScalarMode::Legacy | TwoChartScalarMode::Angular
    ) {
        if let Some((value, end)) = scalar::pcurve_chart_coordinate(body, cursor) {
            return Some((value, 1, end));
        }
    }
    match mode {
        TwoChartScalarMode::Angular => return scalar::sweep::run(body, cursor, previous, cache),
        TwoChartScalarMode::RevolutionEndpoint => {
            return scalar::decode_stateful_scalar_run(
                body,
                cursor,
                previous,
                cache,
                scalar::StatefulScalarKind::RevolutionEndpoint,
            )
        }
        TwoChartScalarMode::Legacy => {}
    }
    if slot.is_multiple_of(4) && body.get(cursor) == Some(&0x53) {
        let (value, end) = scalar::ieee7_with_prefix(body, cursor, 0x3f, 0xc5)?;
        return Some((value, 1, end));
    }
    if slot.is_multiple_of(2) && body.get(cursor) == Some(&0x32) {
        let (value, end) = scalar::decode_two_chart_first_coordinate(body, cursor, cache)?;
        return value.is_finite().then_some((value, 1, end));
    }
    if !slot.is_multiple_of(2) && matches!(body.get(cursor), Some(0x4f | 0x50 | 0x57)) {
        let (value, end) = scalar::decode_two_chart_second_coordinate(body, cursor)?;
        return value.is_finite().then_some((value, 1, end));
    }
    scalar::decode_stateful_scalar_run(
        body,
        cursor,
        previous,
        cache,
        scalar::StatefulScalarKind::LegacyTwoChart,
    )
}

fn two_chart_sample_count(
    body: &[u8],
    start: usize,
    count: u32,
    cache: &scalar::ScalarCache,
) -> Option<(usize, usize, TwoChartScalarMode)> {
    if count == 2 {
        let endpoint_body = body.get(start..)?;
        if let Some(frame) =
            scalar::decode_pcurve_scalar_frame(endpoint_body, cache).filter(|frame| {
                frame
                    .tokens
                    .iter()
                    .flatten()
                    .any(|token| endpoint_body.get(token.offset) == Some(&0x19))
            })
        {
            return Some((2, frame.token_count, TwoChartScalarMode::RevolutionEndpoint));
        }
    }
    two_chart_angular_sample_count(body, start, count, cache)
}

fn two_chart_angular_sample_count(
    body: &[u8],
    start: usize,
    count: u32,
    cache: &scalar::ScalarCache,
) -> Option<(usize, usize, TwoChartScalarMode)> {
    [TwoChartScalarMode::Legacy, TwoChartScalarMode::Angular]
        .into_iter()
        .find_map(|mode| {
            let mut cursor = start;
            let mut previous = None;
            let mut slots = 0usize;
            let mut token_count = 0usize;
            let mut angle = false;
            while cursor < body.len() {
                angle |=
                    scalar::sweep::angle(*body.get(cursor)?).is_some_and(|_| body[cursor] != 0x12);
                let (value, repeat, end) =
                    two_chart_scalar_run(body, cursor, slots, previous, cache, mode)?;
                slots = slots.checked_add(repeat)?;
                token_count = token_count.checked_add(1)?;
                previous = Some(value);
                cursor = end;
            }
            let sample_count = bounded_len(u64::from(count), 4, slots)?;
            (sample_count >= 2
                && sample_count.checked_mul(4)? == slots
                && (!matches!(mode, TwoChartScalarMode::Angular) || angle))
                .then_some((sample_count, token_count, mode))
        })
}

struct TwoChartScalarFrame<'a> {
    curve_id: u32,
    faces: [u32; 2],
    body: &'a [u8],
    start: usize,
    sample_count: usize,
    token_count: usize,
    mode: TwoChartScalarMode,
    offset: usize,
}

fn two_chart_scalar_frames<'a>(
    payload: &'a [u8],
    face_ids: Option<&BTreeSet<u32>>,
    cache: &scalar::ScalarCache,
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
) -> Vec<TwoChartScalarFrame<'a>> {
    let framed = framed_rows_with_face_ids(payload, face_ids);
    let mut canonical_counts = BTreeMap::<(usize, u32, u8), BTreeSet<u32>>::new();
    for row in &framed {
        let bytes = &payload[row.start..row.end];
        let Some(prefix) = topology_prefix(bytes, 0, row.suffix_start) else {
            continue;
        };
        let body = &bytes[prefix.end..row.suffix_start];
        if body.first() != Some(&0xfc) || body.get(1) == Some(&0x05) {
            continue;
        }
        let (count, start) = compact_int(body, 1);
        if prefix.feature_id != 0
            && start > 1
            && two_chart_sample_count(body, start, count, cache).is_some()
        {
            canonical_counts
                .entry((row.namespace_start, prefix.feature_id, prefix.type_byte))
                .or_default()
                .insert(count);
        }
    }
    let mut result = Vec::new();
    for row in framed {
        if row.bare_matrix_body {
            continue;
        }
        let bytes = &payload[row.start..row.end];
        let Some(prefix) = topology_prefix(bytes, 0, row.suffix_start) else {
            continue;
        };
        let body = &bytes[prefix.end..row.suffix_start];
        let decoded = if body.first() == Some(&0xfc) {
            if body.get(1) == Some(&0x05) {
                continue;
            }
            let (count, start) = compact_int(body, 1);
            (start > 1).then_some(()).and_then(|()| {
                two_chart_sample_count(body, start, count, cache).map(|count| (start, count))
            })
        } else {
            let Some(counts) =
                canonical_counts.get(&(row.namespace_start, prefix.feature_id, prefix.type_byte))
            else {
                continue;
            };
            let mut candidates = counts
                .iter()
                .filter_map(|count| two_chart_sample_count(body, 0, *count, cache));
            let first = candidates.next();
            if candidates.next().is_some() {
                None
            } else {
                first.map(|count| (0, count))
            }
        };
        let Some((start, (sample_count, token_count, mode))) = decoded else {
            if body.first() == Some(&0xfc) {
                losses.push(crate::loss::CreoLossCode::TwoChartScalarFrameUnresolved.note(format!(
                "Curve {} sampled pcurve at byte {} has no unique complete scalar frame; its bytes remain native",
                prefix.id, row.start
            )));
            }
            continue;
        };
        result.push(TwoChartScalarFrame {
            curve_id: prefix.id,
            faces: [row.suffix[0], row.suffix[1]],
            body,
            start,
            sample_count,
            token_count,
            mode,
            offset: row.start,
        });
    }
    result
}

fn two_chart_scalar_lane(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    frame: &TwoChartScalarFrame<'_>,
    cache: &scalar::ScalarCache,
) -> Result<Option<CurveScalarLane>, cadmpeg_core::CodecError> {
    let Some(scalar_count) = frame.sample_count.checked_mul(4) else {
        return Ok(None);
    };
    let mut tokens = ctx.alloc_filled(
        frame.token_count,
        CurveParameterScalar {
            value: 0.0,
            raw: Vec::new(),
            offset: 0,
        },
        "creo sampled pcurve scalar tokens",
    )?;
    let mut cursor = frame.start;
    let mut slot = 0usize;
    let mut previous = None;
    let mut token_count = 0;
    while cursor < frame.body.len() {
        let Some((value, repeat, end)) =
            two_chart_scalar_run(frame.body, cursor, slot, previous, cache, frame.mode)
        else {
            return Ok(None);
        };
        let Some(token) = tokens.get_mut(token_count) else {
            return Ok(None);
        };
        *token = CurveParameterScalar {
            value,
            raw: frame.body[cursor..end].to_vec(),
            offset: cursor,
        };
        let Some(next_slot) = slot.checked_add(repeat) else {
            return Ok(None);
        };
        slot = next_slot;
        cursor = end;
        previous = Some(value);
        token_count += 1;
    }
    if slot != scalar_count || token_count != tokens.len() {
        return Ok(None);
    }
    let opaque_spans = if frame.start == 0 {
        Vec::new()
    } else {
        vec![CurveParameterOpaqueSpan {
            raw: frame.body[..frame.start].to_vec(),
            offset: 0,
        }]
    };
    Ok(Some(CurveScalarLane {
        scalar_tokens: tokens,
        references: Vec::new(),
        opaque_spans,
    }))
}

#[cfg(test)]
pub(crate) fn two_chart_pcurve_samples(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    payload: &[u8],
    face_ids: Option<&BTreeSet<u32>>,
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
) -> Result<Vec<TwoChartPcurveSamples>, cadmpeg_core::CodecError> {
    two_chart_pcurve_samples_with_modes(ctx, payload, face_ids, losses).map(|(samples, _)| samples)
}

pub(crate) fn two_chart_pcurve_samples_with_modes(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    payload: &[u8],
    face_ids: Option<&BTreeSet<u32>>,
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
) -> Result<(Vec<TwoChartPcurveSamples>, BTreeSet<u32>), cadmpeg_core::CodecError> {
    let cache = scalar::ScalarCache::from_section_checked(payload);
    let mut result = Vec::new();
    let mut angular_ids = BTreeSet::new();
    for frame in two_chart_scalar_frames(payload, face_ids, &cache, losses) {
        let mut samples =
            ctx.alloc_filled(frame.sample_count, [[0.0; 2]; 2], "creo two-chart samples")?;
        let mut cursor = frame.start;
        let mut previous = None;
        let mut repeated = 0usize;
        let mut value = 0.0;
        let mut complete = true;
        for (slot, target) in samples
            .iter_mut()
            .flat_map(|sample| sample.iter_mut().flatten())
            .enumerate()
        {
            if repeated == 0 {
                let Some((decoded, repeat, end)) =
                    two_chart_scalar_run(frame.body, cursor, slot, previous, &cache, frame.mode)
                else {
                    complete = false;
                    break;
                };
                value = decoded;
                repeated = repeat;
                cursor = end;
                previous = Some(value);
            }
            *target = value;
            repeated -= 1;
        }
        if !complete || cursor != frame.body.len() || repeated != 0 {
            continue;
        }
        if matches!(frame.mode, TwoChartScalarMode::Angular) {
            angular_ids.insert(frame.curve_id);
        }
        result.push(TwoChartPcurveSamples {
            curve_id: frame.curve_id,
            faces: frame.faces,
            samples,
            offset: frame.offset,
        });
    }
    for topology in prototype_topology(payload) {
        let [Some(first_face), Some(second_face)] = topology.faces else {
            continue;
        };
        let faces = [first_face.get(), second_face.get()];
        let namespace_end = find(
            payload,
            b"crv_array\0",
            topology.offset + b"crv_array\0".len(),
        )
        .unwrap_or(payload.len());
        let prototype_end = find_in(payload, b"topol_ref_data\0", topology.offset, namespace_end)
            .unwrap_or(namespace_end);
        let Some(points_label) =
            unique_find_in(payload, b"crv_pnt_arr\0", topology.offset, prototype_end)
        else {
            continue;
        };
        let Some(field_header) = points_label.checked_sub(2) else {
            continue;
        };
        if payload.get(field_header..points_label) != Some(&[0xe0, 0x02]) {
            continue;
        }
        let header = points_label + b"crv_pnt_arr\0".len();
        if payload.get(header) != Some(&psb::token::SCALAR_BODY) {
            continue;
        }
        let Ok((count, next)) = reference_id(payload, header + 1) else {
            continue;
        };
        let Ok((width, array_start)) = reference_id(payload, next) else {
            continue;
        };
        if width != 4 {
            continue;
        }
        let Some(next_label) = unique_find_in(
            payload,
            b"crv_hdr_geom_ptr[0]\0",
            array_start,
            prototype_end,
        ) else {
            continue;
        };
        let Some(array_end) = next_label.checked_sub(2) else {
            continue;
        };
        if payload.get(array_end..next_label) != Some(&[0xe0, 0x01]) {
            continue;
        }
        let Some(body) = payload.get(array_start..array_end) else {
            continue;
        };
        let decoded = two_chart_angular_sample_count(body, 0, count, &cache);
        let Some((sample_count, token_count, TwoChartScalarMode::Angular)) = decoded else {
            if decoded.is_none() && count != 2 {
                losses.push(crate::loss::CreoLossCode::TwoChartScalarFrameUnresolved.note(format!("Curve {} named sampled pcurve at byte {points_label} has no complete angular scalar frame; its bytes remain native", topology.curve_id)));
            }
            continue;
        };
        let frame = TwoChartScalarFrame {
            curve_id: topology.curve_id,
            faces,
            body,
            start: 0,
            sample_count,
            token_count,
            mode: TwoChartScalarMode::Angular,
            offset: topology.offset,
        };
        let mut samples = ctx.alloc_filled(
            sample_count,
            [[0.0; 2]; 2],
            "creo named angular pcurve samples",
        )?;
        let mut cursor = 0;
        let mut previous = None;
        let mut remaining = 0;
        let mut value = 0.0;
        let mut complete = true;
        for target in samples
            .iter_mut()
            .flat_map(|sample| sample.iter_mut().flatten())
        {
            if remaining == 0 {
                let Some((decoded, repeat, end)) =
                    scalar::sweep::run(frame.body, cursor, previous, &cache)
                else {
                    complete = false;
                    break;
                };
                value = decoded;
                remaining = repeat;
                cursor = end;
                previous = Some(value);
            }
            *target = value;
            remaining -= 1;
        }
        if complete && cursor == body.len() && remaining == 0 {
            angular_ids.insert(topology.curve_id);
            result.push(TwoChartPcurveSamples {
                curve_id: topology.curve_id,
                faces,
                samples,
                offset: topology.offset,
            });
            losses.push(crate::loss::CreoLossCode::PcurveSampleCoordinatesDropped.note(format!("Curve {} named array at byte {points_label} supplies {sample_count} paired boundary samples; its individual UV sample array is omitted from the IR",topology.curve_id)));
        }
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    let mut counts = BTreeMap::new();
    for record in &result {
        *counts.entry(record.curve_id).or_insert(0usize) += 1;
    }
    result.retain(|record| counts.get(&record.curve_id) == Some(&1));
    angular_ids.retain(|id| counts.get(id) == Some(&1));
    Ok((result, angular_ids))
}

fn complete_fc02_short_pcurve_values(record: &CurveParameterRecord) -> Option<[[f64; 2]; 2]> {
    const ZERO_MARKER: &[u8] = &[0x18];
    const ONE_MARKER: &[u8] = &[0xe4];
    const TWO_MARKER: &[u8] = &[0x29, 0xff, 0xff];

    (record.body.get(..2) == Some(&[0xfc, 0x02])).then_some(())?;
    record.references.is_empty().then_some(())?;
    let tokens: &[CurveParameterScalar; 7] = record.scalar_tokens.as_slice().try_into().ok()?;
    let [prefix, terminal] = record.opaque_spans.as_slice() else {
        return None;
    };
    (prefix.offset == 0
        && prefix.raw == [0xfc, 0x02]
        && terminal.raw.first() == Some(&0x34)
        && terminal.raw.len() == 3)
        .then_some(())?;
    let mut cursor = prefix.raw.len();
    for token in tokens {
        (token.offset == cursor
            && !token.raw.is_empty()
            && record.body.get(cursor..cursor + token.raw.len()) == Some(token.raw.as_slice()))
        .then_some(())?;
        cursor += token.raw.len();
    }
    (terminal.offset == cursor && terminal.offset + terminal.raw.len() == record.body.len())
        .then_some(())?;
    let values = tokens.each_ref().map(|token| token.value);
    (values.iter().all(|value| value.is_finite())
        && values[2] == 0.0
        && values[3] == 1.0
        && tokens[2].raw.as_slice() == ZERO_MARKER
        && tokens[3].raw.as_slice() == ONE_MARKER
        && tokens[6].raw.as_slice() == TWO_MARKER)
        .then_some(())?;
    Some([[values[0], values[1]], [values[4], values[5]]])
}

/// Decode complete one-sided endpoint paths from the short fc 02 body.
///
/// A path is admitted only when the body has one unique topology row, a
/// complete seven-scalar lane, and the bounded terminal operand. Other fc 02
/// bodies remain native parameter records until their grammar is settled.
pub(crate) fn fc02_short_pcurve_endpoints(
    parameters: &[CurveParameterRecord],
    topology: &[CurveTopologyRow],
) -> Vec<Fc02ShortPcurveEndpoints> {
    let mut result = Vec::new();
    for record in crate::identity::uniquely_identified_rows(parameters, |record| record.curve_id) {
        let Some(face_0_endpoints) = complete_fc02_short_pcurve_values(record) else {
            continue;
        };
        let mut matching = topology.iter().filter(|row| row.id == record.curve_id);
        let Some(topology) = matching.next() else {
            continue;
        };
        if matching.next().is_some() || topology.type_byte != record.type_byte {
            continue;
        }
        result.push(Fc02ShortPcurveEndpoints {
            curve_id: record.curve_id,
            faces: topology.faces.map(stored_face_reference),
            face_0_endpoints,
            offset: record.offset,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

/// Decode exact world-coordinate tokens from FC-prefixed dense curve bodies.
pub(crate) fn fc_coordinates(parameters: &[CurveParameterRecord]) -> Vec<FcCurveCoordinates> {
    let mut result = Vec::new();
    for record in crate::identity::uniquely_identified_rows(parameters, |record| record.curve_id) {
        let Some((&0xfc, tail)) = record.body.split_first() else {
            continue;
        };
        let Some((&subtype, lane)) = tail.split_first() else {
            continue;
        };
        let mut tokens = Vec::new();
        let mut cursor = 0;
        while cursor < lane.len() {
            if matches!(lane[cursor], 0x46 | 0x2d) {
                if let Some((value, next)) = scalar::decode(lane, cursor) {
                    tokens.push(FcCurveCoordinateToken {
                        value_mm: value,
                        raw: (lane[cursor..next].to_vec()).into(),
                        offset: cursor + 2,
                    });
                    cursor = next;
                    continue;
                }
            }
            cursor += 1;
        }
        if tokens.len() >= 4 {
            let mut opaque_spans = Vec::new();
            let mut unclaimed = 0;
            for token in &tokens {
                if unclaimed < token.offset {
                    opaque_spans.push(FcCurveOpaqueSpan {
                        raw: (record.body[unclaimed..token.offset].to_vec()).into(),
                        offset: unclaimed,
                    });
                }
                unclaimed = token.offset + token.raw.len();
            }
            if unclaimed < record.body.len() {
                opaque_spans.push(FcCurveOpaqueSpan {
                    raw: (record.body[unclaimed..].to_vec()).into(),
                    offset: unclaimed,
                });
            }
            let mut values_mm = Vec::new();
            values_mm.extend(tokens.iter().map(|token| token.value_mm));
            let body = record.body.clone();
            result.push(FcCurveCoordinates {
                curve_id: record.curve_id,
                subtype,
                body,
                values_mm,
                tokens,
                opaque_spans,
                offset: record.offset,
            });
        }
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

fn fc05_scalar(body: &[u8], offset: usize) -> Option<(f64, usize)> {
    let prefix = *body.get(offset)?;
    if prefix == 0x18 {
        return Some((0.0, offset + 1));
    }
    if let Some(decoded) = scalar::decode_positive_dict(body, offset) {
        return Some(decoded);
    }
    if let Some(decoded) = scalar::decode(body, offset) {
        return Some(decoded);
    }
    if matches!(prefix, 0xe0..=0xe3 | 0xf7 | 0xf8) || offset + 7 > body.len() {
        return None;
    }
    if let Some(head) = scalar::positive_dict_head(prefix) {
        return scalar::ieee7_dict(body, offset, head);
    }
    // wrapping-exception: DICT prefix remapping reconstructs the low IEEE byte modulo 256
    let byte_1 = prefix.wrapping_sub(0x8b);
    scalar::ieee7_with_prefix(
        body,
        offset,
        if byte_1 >= 0x80 { 0x3f } else { 0x40 },
        byte_1,
    )
}

/// Validate FC05 point lanes against their exact circle identity.
pub(crate) fn fc05_circles(parameters: &[CurveParameterRecord]) -> Vec<Fc05Circle> {
    let mut circles = Vec::new();
    for record in crate::identity::uniquely_identified_rows(parameters, |record| record.curve_id) {
        if record.body.get(..2) != Some(&[0xfc, 0x05]) {
            continue;
        }
        let mut points = Vec::new();
        let mut cursor = 2;
        while cursor < record.body.len() {
            if !matches!(record.body[cursor], 0x46 | 0x2d) {
                break;
            }
            let Some((x, next)) = fc05_scalar(&record.body, cursor) else {
                break;
            };
            let Some((z, next)) = fc05_scalar(&record.body, next) else {
                break;
            };
            let parameter_start = next;
            let Some((decoded_parameter, decoded_next)) = fc05_scalar(&record.body, next) else {
                break;
            };
            let (parameter, next) = if matches!(record.body.get(decoded_next), Some(0x46 | 0x2d)) {
                (Some(decoded_parameter), decoded_next)
            } else {
                let following = (parameter_start + 1..(parameter_start + 9).min(record.body.len()))
                    .find(|offset| matches!(record.body[*offset], 0x46 | 0x2d));
                let Some(following) = following else {
                    break;
                };
                (None, following)
            };
            let Some((ordinate, next)) = fc05_scalar(&record.body, next) else {
                break;
            };
            points.push((x, z, parameter, ordinate));
            cursor = next;
        }
        if cursor != record.body.len() && record.body.get(cursor..) != Some(&[0xff]) {
            continue;
        }
        if points.len() < 4 {
            continue;
        }
        let ordinate = points[0].3;
        if points
            .iter()
            .any(|point| (point.3 - ordinate).abs() > EPS_ORDINATE_AGREEMENT)
        {
            continue;
        }
        let first = points[0];
        let middle = points[points.len() / 2];
        let last = points[points.len() - 1];
        let middle_delta = [middle.0 - first.0, middle.1 - first.1];
        let last_delta = [last.0 - first.0, last.1 - first.1];
        let scale = middle_delta
            .into_iter()
            .chain(last_delta)
            .map(f64::abs)
            .fold(0.0, f64::max);
        if !scale.is_finite() || scale == 0.0 {
            continue;
        }
        let middle_delta = middle_delta.map(|value| value / scale);
        let last_delta = last_delta.map(|value| value / scale);
        let determinant = middle_delta[0].mul_add(last_delta[1], -middle_delta[1] * last_delta[0]);
        if determinant.abs() <= 64.0 * f64::EPSILON {
            continue;
        }
        // Fit in a translated chart so subtracting squared world positions
        // cannot erase a small circle's radius.
        let middle_squared =
            middle_delta[0].mul_add(middle_delta[0], middle_delta[1] * middle_delta[1]);
        let last_squared = last_delta[0].mul_add(last_delta[0], last_delta[1] * last_delta[1]);
        let center_u = 0.5 * middle_squared.mul_add(last_delta[1], -middle_delta[1] * last_squared)
            / determinant;
        let center_v = 0.5 * middle_delta[0].mul_add(last_squared, -middle_squared * last_delta[0])
            / determinant;
        let center_x = center_u.mul_add(scale, first.0);
        let center_z = center_v.mul_add(scale, first.1);
        let radius = (first.0 - center_x).hypot(first.1 - center_z);
        if ![center_x, center_z, radius].into_iter().all(f64::is_finite) || radius <= 0.0 {
            continue;
        }
        let max_residual = points
            .iter()
            .map(|point| ((point.0 - center_x).hypot(point.1 - center_z) - radius).abs())
            .fold(0.0, f64::max);
        if max_residual > EPS_CIRCLE_RESIDUAL * radius {
            continue;
        }
        let angle_0 = (first.1 - center_z).atan2(first.0 - center_x);
        let parameter_0 = first.2;
        let wrapped_distance = |left: f64, right: f64| {
            let difference = left - right;
            difference
                .is_finite()
                .then(|| difference.rem_euclid(std::f64::consts::TAU))
                .map_or(f64::INFINITY, |wrapped| {
                    wrapped.min(std::f64::consts::TAU - wrapped)
                })
        };
        let sign_matches = |sign: f64| {
            points.iter().all(|point| {
                let (Some(parameter), Some(parameter_0)) = (point.2, parameter_0) else {
                    return false;
                };
                let angle = (point.1 - center_z).atan2(point.0 - center_x);
                let expected = angle_0 + sign * (parameter - parameter_0);
                wrapped_distance(angle, expected) <= EPS_ANGLE_AGREEMENT
            })
        };
        let positive = sign_matches(1.0);
        let negative = sign_matches(-1.0);
        let angle_parameter = match (positive, negative, parameter_0) {
            (true, false, Some(parameter_0)) | (false, true, Some(parameter_0)) => {
                let sense = if positive {
                    ParameterSense::Increasing
                } else {
                    ParameterSense::Decreasing
                };
                let reference_angle = angle_0 - f64::from(sense.as_i8()) * parameter_0;
                Fc05AngleParameterRelation::Consistent {
                    sense,
                    reference_direction_row_frame: [reference_angle.cos(), reference_angle.sin()],
                }
            }
            _ => Fc05AngleParameterRelation::Inconsistent,
        };
        let Some((sample_direction_row_frame, _)) =
            cadmpeg_ir::units::HypotDirection2::normalized_with_length([
                first.0 - center_x,
                first.1 - center_z,
            ])
        else {
            continue;
        };
        circles.push(Fc05Circle {
            curve_id: record.curve_id,
            center_row_frame: [center_x, center_z],
            radius_mm: radius,
            sample_direction_row_frame,
            angle_parameter,
            cap_ordinate_row_frame: Some(ordinate),
            point_count: points.len(),
            max_residual,
            offset: record.offset,
        });
    }
    circles.as_mut_slice().sort_by_key(|left| left.offset);
    circles
}

/// Bind validated `fc 05` circles to typed cylinder/plane face pairs and retain
/// only groups that agree on radius and center at two distinct cap ordinates.
pub(crate) fn fc05_cylinder_cap_pairs(
    circles: &[Fc05Circle],
    topology: &[CurveTopologyRow],
    surfaces: &[crate::surface::SurfaceRow],
) -> Vec<Fc05CylinderCapPair> {
    use std::collections::BTreeMap;

    let mut faces = BTreeMap::<u32, [Option<NonZeroU32>; 2]>::new();
    for row in crate::identity::uniquely_identified_rows(topology, |row| row.id) {
        faces.insert(row.id, row.faces);
    }
    let mut circle_counts = BTreeMap::<u32, usize>::new();
    for circle in circles {
        match circle_counts.entry(circle.curve_id) {
            std::collections::btree_map::Entry::Occupied(mut entry) => *entry.get_mut() += 1,
            std::collections::btree_map::Entry::Vacant(entry) => {
                entry.insert(1);
            }
        }
    }
    let mut groups = BTreeMap::<u32, Vec<(&Fc05Circle, u32, f64)>>::new();
    for circle in circles {
        if circle_counts.get(&circle.curve_id) != Some(&1) {
            continue;
        }
        let Some(adjacent) = faces.get(&circle.curve_id) else {
            continue;
        };
        let mut cylinders = adjacent
            .iter()
            .flatten()
            .map(|face| face.get())
            .filter(|face| {
                crate::surface::unique_surface_row(surfaces, *face)
                    .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Cylinder)
            });
        let mut planes = adjacent
            .iter()
            .flatten()
            .map(|face| face.get())
            .filter(|face| {
                crate::surface::unique_surface_row(surfaces, *face)
                    .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Plane)
            });
        let (Some(cylinder), None, Some(plane), None, Some(ordinate)) = (
            cylinders.next(),
            cylinders.next(),
            planes.next(),
            planes.next(),
            circle.cap_ordinate_row_frame,
        ) else {
            continue;
        };
        let group = match groups.entry(cylinder) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        group.push((circle, plane, ordinate));
    }

    let mut result = Vec::new();
    for (surface_id, mut group) in groups {
        group.as_mut_slice().sort_by_key(|(left, _, _)| left.offset);
        let first = group[0].0;
        let Fc05AngleParameterRelation::Consistent {
            sense: parameter_sense,
            reference_direction_row_frame,
        } = first.angle_parameter
        else {
            continue;
        };
        let tolerance = EPS_RADIUS_AGREEMENT * first.radius_mm;
        if !group.iter().all(|(circle, _, _)| {
            let Fc05AngleParameterRelation::Consistent {
                sense,
                reference_direction_row_frame: direction,
            } = circle.angle_parameter
            else {
                return false;
            };
            (circle.radius_mm - first.radius_mm).abs() <= tolerance
                && (circle.center_row_frame[0] - first.center_row_frame[0]).abs() <= tolerance
                && (circle.center_row_frame[1] - first.center_row_frame[1]).abs() <= tolerance
                && sense == parameter_sense
                && (direction[0] - reference_direction_row_frame[0]).abs() <= EPS_RADIUS_AGREEMENT
                && (direction[1] - reference_direction_row_frame[1]).abs() <= EPS_RADIUS_AGREEMENT
        }) {
            continue;
        }
        let mut ordinates = Vec::new();
        for ordinate in group.iter().map(|(_, _, ordinate)| *ordinate) {
            if ordinates
                .iter()
                .all(|existing: &f64| (*existing - ordinate).abs() > tolerance)
            {
                ordinates.push(ordinate);
            }
        }
        if ordinates.len() < 2 {
            continue;
        }
        let mut cap_edges = Vec::new();
        cap_edges.extend(group.iter().map(|(circle, plane, ordinate)| Fc05CapEdge {
            curve_id: circle.curve_id,
            cap_plane_id: *plane,
            cap_ordinate_row_frame: *ordinate,
        }));
        result.push(Fc05CylinderCapPair {
            surface_id,
            cap_edges,
            center_row_frame: first.center_row_frame,
            radius_mm: first.radius_mm,
            reference_direction_row_frame,
            parameter_sense,
            cap_ordinates_row_frame: ordinates,
            offset: first.offset,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

/// Decode labeled `crv_pnt_arr f9 02 04` prototype pcurve endpoints.
pub(crate) fn prototype_pcurve_endpoints(
    payload: &[u8],
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
) -> Vec<PrototypePcurveEndpoints> {
    let cache = scalar::ScalarCache::from_section_checked(payload);
    let mut result = Vec::new();
    let mut search = 0;
    while let Some(namespace) = find(payload, b"crv_array\0", search) {
        let start = namespace + b"crv_array\0".len();
        let end = find(payload, b"crv_array\0", start).unwrap_or(payload.len());
        search = start;
        let Some(id_label) = find_in(payload, b"crv_id\0", start, end) else {
            continue;
        };
        let id_start = id_label + b"crv_id\0".len();
        let (curve_id, after_id) = compact_int(payload, id_start);
        if after_id == id_start {
            continue;
        }
        let prototype_end = find_in(payload, b"topol_ref_data\0", after_id, end).unwrap_or(end);
        let Some(points_label) = unique_find_in(payload, b"crv_pnt_arr\0", after_id, prototype_end)
        else {
            continue;
        };
        let header = points_label + b"crv_pnt_arr\0".len();
        if payload.get(header..header + 3) != Some(&[psb::token::SCALAR_BODY, 0x02, 0x04]) {
            continue;
        }
        let array_start = header + 3;
        let frame =
            scalar::decode_pcurve_scalar_frame_prefix(&payload[array_start..prototype_end], &cache)
                .filter(|(_, end)| {
                    array_start + end == prototype_end
                        || payload.get(array_start + end) == Some(&0xe0)
                });
        let Some((frame, _)) = frame else {
            losses.push(crate::loss::CreoLossCode::PcurveScalarFrameUnresolved.note(format!(
                "Curve {curve_id} named pcurve at byte {points_label} has no complete bounded scalar frame; its bytes remain native"
            )));
            continue;
        };
        let values = frame.values;
        result.push(PrototypePcurveEndpoints {
            curve_id,
            face_0_endpoints: [[values[0], values[1]], [values[4], values[5]]],
            face_1_endpoints: [[values[2], values[3]], [values[6], values[7]]],
            offset: points_label,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

/// Decode the four labeled topology pointers of each curve prototype.
pub(crate) fn prototype_topology(payload: &[u8]) -> Vec<CurvePrototypeTopology> {
    let mut result = Vec::new();
    let mut search = 0;
    while let Some(namespace) = find(payload, b"crv_array\0", search) {
        let start = namespace + b"crv_array\0".len();
        let end = find(payload, b"crv_array\0", start).unwrap_or(payload.len());
        search = start;
        let Some(id_label) = find_in(payload, b"crv_id\0", start, end) else {
            continue;
        };
        let id_start = id_label + b"crv_id\0".len();
        let Ok((curve_id, _)) = reference_id(payload, id_start) else {
            continue;
        };
        let prototype_end = find_in(payload, b"topol_ref_data\0", id_start, end).unwrap_or(end);
        let reference = |label: &[u8]| {
            let at = unique_find_in(payload, label, id_start, prototype_end)? + label.len();
            reference_id(payload, at).ok().map(|(value, _)| value)
        };
        let Some(face_0) = reference(b"crv_hdr_geom_ptr[0]\0") else {
            continue;
        };
        let Some(face_1) = reference(b"crv_hdr_geom_ptr[1]\0") else {
            continue;
        };
        let Some(next_0) = reference(b"next_crv_hdr_ptr[0]\0") else {
            continue;
        };
        let Some(next_1) = reference(b"next_crv_hdr_ptr[1]\0") else {
            continue;
        };
        result.push(CurvePrototypeTopology {
            curve_id,
            faces: [face_0, face_1].map(NonZeroU32::new),
            next_edges: [next_0, next_1],
            offset: namespace,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

/// Bind complete prototype UV endpoints to labeled prototype topology.
pub(crate) fn bind_prototype_pcurves(
    pcurves: &[PrototypePcurveEndpoints],
    topology: &[CurvePrototypeTopology],
) -> Vec<BoundPrototypePcurve> {
    let mut pcurve_counts = BTreeMap::new();
    for pcurve in pcurves {
        let count = match pcurve_counts.entry(pcurve.curve_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(0usize),
        };
        *count += 1;
    }
    let mut topology_counts = BTreeMap::new();
    for row in topology {
        let count = match topology_counts.entry(row.curve_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(0usize),
        };
        *count += 1;
    }
    let mut result = Vec::new();
    for pcurve in pcurves
        .iter()
        .filter(|pcurve| pcurve_counts.get(&pcurve.curve_id) == Some(&1))
        .filter(|pcurve| topology_counts.get(&pcurve.curve_id) == Some(&1))
    {
        let topology = topology
            .iter()
            .find(|topology| topology.curve_id == pcurve.curve_id);
        let Some(topology) = topology else {
            continue;
        };
        result.push(BoundPrototypePcurve {
            curve_id: pcurve.curve_id,
            faces: topology.faces,
            face_0_endpoints: pcurve.face_0_endpoints,
            face_1_endpoints: pcurve.face_1_endpoints,
            offset: pcurve.offset,
        });
    }
    result.as_mut_slice().sort_by_key(|left| left.offset);
    result
}

/// The stored face identifier of a bounded half-edge side; `0` is unbounded.
fn stored_face_reference(face: Option<NonZeroU32>) -> u32 {
    face.map_or(0, NonZeroU32::get)
}

fn parse_topology_row(
    row: &[u8],
    absolute_offset: usize,
    suffix_start: usize,
    [f0, f1, e0, e1]: [u32; 4],
) -> Option<CurveTopologyRow> {
    let prefix = topology_prefix(row, 0, suffix_start)?;
    Some(CurveTopologyRow {
        id: prefix.id,
        type_byte: prefix.type_byte,
        feature_id: prefix.feature_id,
        directions: prefix.directions,
        faces: [f0, f1].map(NonZeroU32::new),
        next_edges: [e0, e1],
        offset: absolute_offset,
    })
}

fn topology_prefix(row: &[u8], start: usize, suffix_start: usize) -> Option<TopologyPrefix> {
    let fields = topology_prefix_fields(row, start)?;
    (fields.end <= suffix_start).then_some(fields)
}

fn topology_prefix_fields(row: &[u8], start: usize) -> Option<TopologyPrefix> {
    let (id, after_id) = compact_int(row, start);
    (after_id > start).then_some(())?;
    let type_byte = *row.get(after_id)?;
    let (feature_id, after_feature) = compact_int(row, after_id + 1);
    (after_feature > after_id + 1).then_some(())?;
    let directions = [*row.get(after_feature)?, *row.get(after_feature + 1)?];
    directions
        .iter()
        .all(|direction| matches!(direction, 0x01 | 0xf6))
        .then_some(TopologyPrefix {
            id,
            type_byte,
            feature_id,
            directions,
            end: after_feature + 2,
        })
}

fn topology_suffix_with_face_ids(
    row: &[u8],
    materialized_face_ids: Option<&BTreeSet<u32>>,
    known_face_ids: Option<&BTreeSet<u32>>,
) -> Option<(TopologySuffixCandidate, bool)> {
    let candidates = topology_suffix_candidates(row)?;
    let mut initial = candidates.iter().flatten().copied();
    if let (Some(candidate), None) = (initial.next(), initial.next()) {
        return Some((candidate, false));
    }
    let legacy = topology_suffix_by_face_ids(&candidates, materialized_face_ids, known_face_ids);
    let cache = scalar::ScalarCache::default();
    let mut complete_counts = candidates.iter().flatten().filter(|candidate| {
        let Some(prefix) = topology_prefix(row, 0, candidate.start) else {
            return false;
        };
        let body = &row[prefix.end..candidate.start];
        if body.first() != Some(&0xfc) {
            return false;
        }
        let (count, start) = compact_int(body, 1);
        start > 1 && two_chart_sample_count(body, start, count, &cache).is_some()
    });
    match (complete_counts.next(), complete_counts.next()) {
        (Some(candidate), None) => return Some((*candidate, legacy != Some(*candidate))),
        (Some(_), Some(_)) => return None,
        _ => {}
    }
    legacy.map(|candidate| (candidate, false))
}

fn topology_suffix_by_face_ids(
    candidates: &[Option<TopologySuffixCandidate>],
    materialized_face_ids: Option<&BTreeSet<u32>>,
    known_face_ids: Option<&BTreeSet<u32>>,
) -> Option<TopologySuffixCandidate> {
    if let Some(ids) = materialized_face_ids.filter(|ids| !ids.is_empty()) {
        let mut role_matches = candidates
            .iter()
            .flatten()
            .filter(|candidate| {
                candidate
                    .faces
                    .iter()
                    .flatten()
                    .all(|id| ids.contains(&id.get()))
            })
            .copied();
        match (role_matches.next(), role_matches.next()) {
            (Some(candidate), None) => return Some(candidate),
            (None, None) => {}
            _ => return None,
        }
    }
    let ids = known_face_ids.filter(|ids| !ids.is_empty())?;
    let mut role_matches = candidates.iter().flatten().copied().filter(|candidate| {
        candidate
            .faces
            .iter()
            .flatten()
            .all(|id| ids.contains(&id.get()))
    });
    let candidate = role_matches.next()?;
    role_matches.next().is_none().then_some(candidate)
}

fn unique_topology_suffix_in_segment(segment: &[u8]) -> Option<TopologySuffixCandidate> {
    let closes = segment
        .windows(3)
        .enumerate()
        .filter(|(_, bytes)| *bytes == [0, 0, psb::token::COMPOUND_CLOSE])
        .map(|(offset, _)| offset);
    for close in closes.rev() {
        let row_end = close + 3;
        let Some(candidates) = topology_suffix_candidates(&segment[..row_end]) else {
            continue;
        };
        let mut unique = candidates.into_iter().flatten();
        if let (Some(candidate), None) = (unique.next(), unique.next()) {
            return Some(candidate);
        }
    }
    None
}

fn topology_suffix_candidates(row: &[u8]) -> Option<[Option<TopologySuffixCandidate>; 24]> {
    let close = row.len().checked_sub(1)?;
    (row.get(close) == Some(&psb::token::COMPOUND_CLOSE)).then_some(())?;
    let mut reference_geometry_candidates = [None; 3];
    let mut reference_count = 0;
    if close.checked_sub(2).and_then(|start| row.get(start..close)) == Some(&[0, 0]) {
        reference_geometry_candidates[0] = Some((close - 2, [0, 0]));
        reference_count = 1;
    } else {
        for length in 2..=4 {
            let Some(start) = close.checked_sub(length) else {
                continue;
            };
            let Some((first, next)) = generic_compact_at(row, start) else {
                continue;
            };
            let Some((second, end)) = generic_compact_at(row, next) else {
                continue;
            };
            if end == close {
                reference_geometry_candidates[reference_count] = Some((start, [first, second]));
                reference_count += 1;
            }
        }
    }
    let mut candidates = [None; 24];
    let mut candidate_count = 0;
    for (reference_geometry_start, reference_geometry) in reference_geometry_candidates
        .into_iter()
        .take(reference_count)
        .flatten()
    {
        for length in 4..=11 {
            let Some(start) = reference_geometry_start.checked_sub(length) else {
                continue;
            };
            let Ok((f0, p1)) = reference_id(row, start) else {
                continue;
            };
            let Ok((f1, p2)) = reference_id(row, p1) else {
                continue;
            };
            let Ok((e0, p3)) = reference_id(row, p2) else {
                continue;
            };
            let Ok((e1, end)) = reference_id(row, p3) else {
                continue;
            };
            if end == reference_geometry_start {
                candidates[candidate_count] = Some(TopologySuffixCandidate {
                    start,
                    faces: [f0, f1].map(NonZeroU32::new),
                    next_edges: [e0, e1],
                    reference_geometry,
                });
                candidate_count += 1;
            }
        }
    }
    Some(candidates)
}

fn unique_find_in(data: &[u8], needle: &[u8], from: usize, end: usize) -> Option<usize> {
    let offset = find_in(data, needle, from, end)?;
    find_in(data, needle, offset.checked_add(1)?, end)
        .is_none()
        .then_some(offset)
}

#[cfg(test)]
mod tests;
