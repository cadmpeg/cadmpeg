// SPDX-License-Identifier: Apache-2.0

use super::feature_row_for_aggregate;

#[test]
fn scan_bytes_retains_one_section() {
    let bytes = crate::test_support::build_prt("c", &[("VisibGeom", b"payload".to_vec())]);
    let service =
        crate::decode::with_service_context(|ctx| crate::container::scan_bytes(ctx, bytes.clone()))
            .expect("scan the container");
    assert_eq!(service.framing.sections.len(), 1);
}

#[test]
fn scanned_section_succeeds_under_service_policy() {
    let data = b"\n#Body\nabc";
    let sections = super::super::scan_sections(data, 0).expect("section is admitted");
    assert_eq!(sections.len(), 1);
    assert_eq!(sections[0].section.raw_name, "Body");
}

fn one_toc_section(marker_name: &str, entry_name: &str) -> Vec<u8> {
    let mut data = format!("{:<80}\n", "#UGC_TOC 2 1 81 17").into_bytes();
    let section = format!("#{marker_name}\nabc");
    let offset = 2 * 81;
    data.extend_from_slice(
        format!(
            "{:<80}\n",
            format!("{entry_name} {offset:x} {:x} 0", section.len())
        )
        .as_bytes(),
    );
    assert_eq!(data.len(), offset);
    data.extend_from_slice(section.as_bytes());
    data
}

#[test]
fn toc_section_succeeds_under_service_policy() {
    let data = one_toc_section("ModelView#1", "ModelView 1");
    let mut losses = Vec::new();
    let sections = super::super::toc_sections(&data, 0, &mut losses);
    assert_eq!(sections.len(), 1);
    assert_eq!(sections[0].section.raw_name, "ModelView#1");
    assert!(losses.is_empty());
}

fn one_legacy_toc_section() -> Vec<u8> {
    let mut data = b"#Pro/ENGINEER  TM  Version H-01-21\n@Toc 52 0\n0 52 ->\n\
        @entry 53 10\n1 53 [1]\n"
        .to_vec();
    let section = b"#BasicData\nabc";
    let row_tail = format!(" {:08x} 0 983####\n", section.len());
    let relative_offset = data.len() + b"2 53 BasicData ".len() + 8 + row_tail.len();
    data.extend_from_slice(format!("2 53 BasicData {relative_offset:08x}{row_tail}").as_bytes());
    data.extend_from_slice(section);
    data
}

#[test]
fn legacy_toc_section_succeeds_under_service_policy() {
    let data = one_legacy_toc_section();
    let sections = super::super::legacy_toc_sections(&data, 0);
    assert_eq!(sections.len(), 1);
    assert_eq!(sections[0].section.raw_name, "BasicData");
}

#[test]
fn legacy_schema_and_release_succeed_under_service_policy() {
    let data = b"#UGC:2 PART 1\n#-END_OF_UGC_HEADER\n#P_OBJECT 6\n\
        #END_OF_P_OBJECT\n#Pro/ENGINEER  TM  Version H-01-21\n";
    let framing = super::super::legacy_ascii_framing(data)
        .expect("legacy framing is admitted")
        .expect("complete legacy framing");
    assert_eq!(framing.schema, "6");
    assert_eq!(framing.product_release.as_deref(), Some("H-01-21"));
}

fn one_compressed_section() -> Vec<u8> {
    let mut data = b"#SolidPrimdata\n".to_vec();
    data.extend_from_slice(&[0x1f, 0x9d, 0x10, 0x41, 0x84, 0x0c, 0x01]);
    data
}

#[test]
fn damaged_compressed_section_does_not_discard_an_independent_expansion() {
    let mut bytes = b"#SolidPrimdata\n".to_vec();
    bytes.extend_from_slice(&[0x1f, 0x9d, 0x10, 0x41, 0x58, 0x02]);
    let split = bytes.len();
    bytes.extend(one_compressed_section());
    let sections = [
        super::super::Section::scan("SolidPrimdata".into(), 0, split, Some(5), &bytes)
            .expect("bad section extent"),
        super::super::Section::scan("SolidPrimdata".into(), split, bytes.len(), Some(3), &bytes)
            .expect("good section extent"),
    ];
    let mut losses = Vec::new();
    let expanded = crate::decode::with_service_context(|ctx| {
        super::super::expanded_sections(ctx, &bytes, &sections, &mut losses)
    })
    .expect("independent section is readable");
    assert_eq!(expanded.len(), 1);
    assert_eq!(expanded[0].data, b"ABC");
    assert_eq!(losses.len(), 1);
    assert!(losses[0].message.contains("undefined code"));
    assert!(losses[0].message.contains("source bytes retained"));
}

#[test]
fn compressed_section_recovery_propagates_resource_limits() {
    use cadmpeg_core::decode::{DecodeArena, DecodeContext, DecodePolicy, ResourceDimension};
    let bytes = one_compressed_section();
    let section =
        super::super::Section::scan("SolidPrimdata".into(), 0, bytes.len(), Some(3), &bytes)
            .expect("section");
    let arena = DecodeArena::new();
    let mut policy = DecodePolicy::service();
    policy.limits.max_decompressed_bytes_total = 2;
    let (ctx, _) = DecodeContext::from_root_bytes(&bytes, &arena, &policy).expect("root");
    let mut losses = Vec::new();
    let error = super::super::expanded_sections(&ctx, &bytes, &[section], &mut losses)
        .expect_err("resource refusal");
    assert!(
        matches!(error, cadmpeg_core::CodecError::ResourceLimit(refusal) if refusal.dimension == ResourceDimension::DecompressedBytes)
    );
    assert!(losses.is_empty());
}

#[test]
fn compressed_section_above_the_per_expansion_allowance_is_skipped_with_a_loss() {
    use cadmpeg_core::decode::{DecodeArena, DecodeContext, DecodePolicy};
    let mut bytes = b"#SolidPrimdata\n".to_vec();
    bytes.extend_from_slice(&[0x1f, 0x9d, 0x10, 0x41, 0x58, 0x02]);
    let split = bytes.len();
    bytes.extend(one_compressed_section());
    let arena = DecodeArena::new();
    let mut policy = DecodePolicy::service();
    policy.limits.max_decompressed_bytes_per_expand = 4;
    let (ctx, _) = DecodeContext::from_root_bytes(&bytes, &arena, &policy).expect("root");
    let sections = [
        super::super::Section::scan("SolidPrimdata".into(), 0, split, Some(5), &bytes)
            .expect("oversized section extent"),
        super::super::Section::scan("SolidPrimdata".into(), split, bytes.len(), Some(3), &bytes)
            .expect("good section extent"),
    ];
    let mut losses = Vec::new();
    let expanded = super::super::expanded_sections(&ctx, &bytes, &sections, &mut losses)
        .expect("the oversized section does not refuse the decode");
    assert_eq!(expanded.len(), 1);
    assert_eq!(expanded[0].data, b"ABC");
    assert_eq!(losses.len(), 1);
    assert_eq!(losses[0].section_offset, 0);
    assert!(losses[0]
        .message
        .contains("declared expansion of 5 bytes exceeds the 4-byte per-expansion allowance"));
    assert!(ctx.resource_refusal().is_none());
}

#[test]
fn toc_headers_without_a_line_break_end_the_scan() {
    let mut data = b"#UGC:2 PART 1\n".to_vec();
    data.extend(b"#UGC_TOC".repeat(200_000));
    let mut losses = Vec::new();
    assert!(super::super::toc_sections(&data, 0, &mut losses).is_empty());
    assert!(losses.is_empty());
}

#[test]
fn overlapping_toc_row_tables_stop_at_the_input_length_with_one_loss() {
    let header = b"#UGC_TOC a 99999999 1\n";
    let data = header.repeat(2);
    let mut losses = Vec::new();
    assert!(super::super::toc_sections(&data, 0, &mut losses).is_empty());
    assert_eq!(losses.len(), 1);
    assert_eq!(
        losses[0].code,
        crate::loss::CreoLossCode::TocScanCapped.kind()
    );
    assert!(losses[0]
        .message
        .contains(&format!("the TOC header at offset {} ", header.len())));
}

#[test]
fn toc_delimited_headers_need_a_directory_listing() {
    let mut data = b"#UGC_TOC 2 1 0 0\nListed 0 0 0\nOther 0 0 0\n".to_vec();
    let body_start = data.len();
    data.extend_from_slice(b"\xf1#Listed\nabc\xf1#Unlisted\ndef\xf1#Other\nghi");
    let sections = super::super::scan_sections(&data, body_start).expect("sections");
    let names = sections
        .iter()
        .map(|section| section.section.raw_name.as_str())
        .collect::<Vec<_>>();
    assert_eq!(names, ["Listed", "Other"]);
}

#[test]
fn many_unlisted_toc_delimited_headers_after_a_large_directory_finish() {
    let mut data = Vec::new();
    for index in 0..20_000 {
        data.extend_from_slice(format!("\nEntry{index:05} 0 0 0").as_bytes());
    }
    data.push(b'\n');
    let body_start = data.len();
    data.extend(b"\xf1#ab\n".repeat(40_000));
    data.extend_from_slice(b"\xf1#Entry19999\nlast");
    let sections = super::super::scan_sections(&data, body_start).expect("sections");
    assert_eq!(sections.len(), 1);
    assert_eq!(sections[0].section.raw_name, "Entry19999");
}

#[test]
fn expanded_section_record_succeeds_under_service_policy() {
    let data = one_compressed_section();
    let section =
        super::super::Section::scan("SolidPrimdata".to_string(), 0, data.len(), Some(3), &data)
            .expect("bounded compressed section");
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&data, &arena, &policy)
        .expect("compressed input is admitted");
    let expanded = super::super::expanded_sections(
        &ctx,
        &data,
        std::slice::from_ref(&section),
        &mut Vec::new(),
    )
    .expect("expanded section is admitted");
    assert_eq!(expanded.len(), 1);
    assert_eq!(expanded[0].name, "SolidPrimdata");
    assert_eq!(expanded[0].data, b"ABC");
}

#[test]
fn native_model_name_succeeds_under_service_policy() {
    let data = b"#BasicData\nmodel_name\0widget\0";
    let section = super::super::Section::scan("BasicData".to_string(), 0, data.len(), None, data)
        .expect("bounded native name section");
    let name =
        super::super::native_model_name(std::slice::from_ref(&section)).expect("one native name");
    assert_eq!(name.0, "widget");
}

#[test]
fn legacy_scope_ranges_start_at_object_offset() {
    let data = b"0123456789";
    let framing = super::super::LegacyAsciiFraming {
        schema: "6".to_string(),
        product_release: None,
        banner_offset: 0,
        object_offset: 5,
        persistence: crate::legacy::Persistence::default(),
    };
    assert_eq!(
        super::super::legacy_scope_ranges(data, &framing, &[]),
        vec![5..10]
    );
}

#[test]
fn section_owner_ranges_cover_feature_row_body() {
    let row = feature_row_for_aggregate(b"xx");
    assert_eq!(
        super::super::section_owner_ranges(&[], std::slice::from_ref(&row))
            .expect("one owner range"),
        vec![(100, 102)]
    );
}

#[test]
fn complete_legacy_directory_admits_more_than_4096_entries() {
    let count = 4097;
    let mut bytes = format!(
        "#Pro/ENGINEER  TM  Version H-01-21\n@Toc 52 0\n0 52 ->\n@entry 53 10\n1 53 [{count}]\n"
    )
    .into_bytes();
    let row_len = "2 53 BasicData 00000000 0000000e 0 983####\n".len();
    let first_offset = bytes.len() + count * row_len;
    for index in 0..count {
        let offset = first_offset + index * 14;
        bytes.extend_from_slice(
            format!("2 53 BasicData {offset:08x} 0000000e 0 983####\n").as_bytes(),
        );
    }
    for _ in 0..count {
        bytes.extend_from_slice(b"#BasicData\nabc");
    }
    {
        let sections = super::super::legacy_toc_sections(&bytes, 0);
        assert_eq!(sections.len(), count);
    };
}
