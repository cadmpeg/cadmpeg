// SPDX-License-Identifier: Apache-2.0
//! Analytic pcurve carrier transfer and native pcurve helpers.

use crate::vecmath::normalize;
use crate::vecmath::unit_length;
use std::collections::{BTreeMap, BTreeSet};
use std::num::NonZeroU32;

use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    pcurve::{PcurveGeometry, PcurveNurbs},
    Curve, CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, Surface, SurfaceGeometry,
};
use cadmpeg_ir::ids::CurveId;
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::scalar::PositiveLength;
use cadmpeg_ir::units::OrthonormalFrame3;
use cadmpeg_ir::{AnnotationBuilder, Exactness, SourceObjectAssociation};

use crate::container::ContainerScan;

use super::super::native::annotate;
use super::super::surfaces::intersection_resolve::curve_contains_points;

use super::carriers::placed_carriers;
use super::edges::{
    nurbs_control_extent, nurbs_intrinsic_parameter_range, orient_periodic_conic_edge_carrier,
    periodic_conic_edge_parameter_range, point_pair_alignments,
};
use super::equations::{CarrierEquation, PlaneEquation};
use super::planes::point_on_carrier;
use super::vertices::{finite_model_point, model_points_agree};
use crate::vecmath::{cross, dot};

macro_rules! require_some {
    ($value:expr) => {
        match $value {
            Some(value) => value,
            None => return Ok(None),
        }
    };
}

const EPS_AGREE: f64 = 1.0e-9;
const EPS_ORTHO: f64 = 1.0e-10;
const EPS_NEAR_ZERO: f64 = 1.0e-12;
const PCURVE_MISMATCH_SAMPLE_LIMIT: usize = 4;
const PCURVE_CARRIER_PARALLEL_EPS_SQUARED: f64 = 1e-18;
const PCURVE_CARRIER_SAMPLE_PARAMETERS: [f64; 5] = [0.0, 0.25, 0.5, 0.75, 1.0];
/// Surface identity namespaces a native face identifier selects, in the
/// order a lookup tries them.
const MODEL_SURFACE_PREFIXES: [&str; 3] = [
    "creo:visibgeom:surface#",
    "creo:novisgeom:surface#",
    "creo:actdatums:surface#",
];

fn unique_model_surface(surfaces: &[Surface], face_id: u32) -> Option<&Surface> {
    for prefix in MODEL_SURFACE_PREFIXES {
        let mut matches = surfaces.iter().filter(|surface| {
            crate::identity::matches_numbered_identity(surface.id.as_str(), prefix, face_id)
        });
        let Some(surface) = matches.next() else {
            continue;
        };
        return matches.next().is_none().then_some(surface);
    }
    None
}

/// Model surfaces keyed by the native face identifier and namespace that
/// their canonical identity names.
///
/// [`ModelSurfaceIndex::unique`] returns what `unique_model_surface` returns
/// for the indexed slice. A pass that looks up a surface for every pcurve
/// path builds one index instead of scanning every surface per path.
pub(in crate::decode) struct ModelSurfaceIndex<'a> {
    surfaces: &'a [Surface],
    positions: ModelSurfacePositions,
}

impl<'a> ModelSurfaceIndex<'a> {
    pub(in crate::decode) fn new(surfaces: &'a [Surface]) -> Self {
        Self {
            surfaces,
            positions: ModelSurfacePositions::new(surfaces),
        }
    }

    /// Return the only surface in the first namespace that names `face_id`.
    pub(in crate::decode) fn unique(&self, face_id: u32) -> Option<&'a Surface> {
        (0..MODEL_SURFACE_PREFIXES.len())
            .find_map(|namespace| self.positions.positions.get(&(face_id, namespace)))
            .copied()
            .flatten()
            .map(|position| &self.surfaces[position])
    }

    /// Return the surfaces whose canonical identity is `prefix` followed by
    /// `face_id`, or `None` when no surface carries it.
    pub(in crate::decode) fn named(
        &self,
        prefix: &str,
        face_id: u32,
    ) -> Option<NamedSurfaces<&'a Surface>> {
        self.positions
            .named(prefix, face_id)
            .map(|named| named.map(|position| &self.surfaces[position]))
    }

    /// Release the surface borrow, keeping the positions.
    pub(in crate::decode) fn into_positions(self) -> ModelSurfacePositions {
        self.positions
    }
}

/// Positions of model surfaces keyed like [`ModelSurfaceIndex`].
///
/// It borrows nothing, so a pass that appends to the model while it looks
/// surfaces up keeps one and records each surface it appends.
pub(in crate::decode) struct ModelSurfacePositions {
    /// `None` marks an identity that two or more surfaces carry.
    positions: BTreeMap<(u32, usize), Option<usize>>,
}

impl ModelSurfacePositions {
    pub(in crate::decode) fn new(surfaces: &[Surface]) -> Self {
        let mut indexed = Self {
            positions: BTreeMap::new(),
        };
        for position in 0..surfaces.len() {
            indexed.admit(surfaces, position);
        }
        indexed
    }

    /// Index the surface at `position`, which must not be indexed yet.
    pub(in crate::decode) fn admit(&mut self, surfaces: &[Surface], position: usize) {
        let id = surfaces[position].id.as_str();
        for (namespace, prefix) in MODEL_SURFACE_PREFIXES.into_iter().enumerate() {
            let Some(face_id) = crate::identity::numbered_identity(id, prefix) else {
                continue;
            };
            match self.positions.entry((face_id, namespace)) {
                std::collections::btree_map::Entry::Occupied(mut entry) => {
                    entry.insert(None);
                }
                std::collections::btree_map::Entry::Vacant(entry) => {
                    entry.insert(Some(position));
                }
            }
        }
    }

    /// Return the positions of the surfaces whose canonical identity is
    /// `prefix` followed by `face_id`, or `None` when no surface carries it.
    pub(in crate::decode) fn named(
        &self,
        prefix: &str,
        face_id: u32,
    ) -> Option<NamedSurfaces<usize>> {
        let namespace = MODEL_SURFACE_PREFIXES
            .iter()
            .position(|candidate| *candidate == prefix)?;
        Some(match self.positions.get(&(face_id, namespace))? {
            Some(position) => NamedSurfaces::Unique(*position),
            None => NamedSurfaces::Duplicate,
        })
    }
}

/// The model surfaces that carry one canonical identity.
#[derive(Debug, Clone, Copy)]
pub(in crate::decode) enum NamedSurfaces<T> {
    Unique(T),
    Duplicate,
}

impl<T> NamedSurfaces<T> {
    pub(in crate::decode) fn unique(self) -> Option<T> {
        match self {
            Self::Unique(surface) => Some(surface),
            Self::Duplicate => None,
        }
    }

    fn map<U>(self, f: impl FnOnce(T) -> U) -> NamedSurfaces<U> {
        match self {
            Self::Unique(surface) => NamedSurfaces::Unique(f(surface)),
            Self::Duplicate => NamedSurfaces::Duplicate,
        }
    }
}

pub(in crate::decode) fn unresolved_plane_chart_ids(scan: &ContainerScan) -> BTreeSet<u32> {
    scan.planes
        .local_systems
        .iter()
        .filter(|system| !system.has_complete_frame())
        .map(|system| system.surface_id)
        .collect()
}

pub(in crate::decode) fn unresolved_pcurve_chart_losses(
    scan: &ContainerScan,
) -> Vec<cadmpeg_ir::report::loss::LossNote> {
    let referenced: BTreeSet<u32> = scan
        .curves
        .pcurves
        .iter()
        .flat_map(|pcurve| pcurve.faces)
        .chain(
            scan.curves
                .bound_prototype_pcurves
                .iter()
                .flat_map(|pcurve| pcurve.faces),
        )
        .flatten()
        .map(NonZeroU32::get)
        .chain(
            scan.curves
                .two_chart_pcurves
                .iter()
                .flat_map(|pcurve| pcurve.faces),
        )
        .collect();
    unresolved_plane_chart_ids(scan)
        .intersection(&referenced)
        .map(|face| {
            crate::loss::CreoLossCode::PcurveChartUnresolved.note(format!(
                "Plane {face} has an unresolved parameter chart; its pcurve coordinates remain native"
            ))
        })
        .collect()
}

fn topology_ignored_surface_ids(scan: &ContainerScan) -> BTreeSet<u32> {
    let mut ignored = unresolved_plane_chart_ids(scan);
    if matches!(
        scan.framing.layout,
        crate::container::Layout::LegacyAscii(_)
    ) {
        ignored.extend(
            scan.surfaces
                .rows
                .iter()
                .filter(|row| row.kind == crate::surface::SurfaceKind::Spline)
                .map(|row| row.id),
        );
    }
    ignored
}

pub(in crate::decode) fn canonicalized_pcurve_endpoints(
    scan: &ContainerScan,
    faces: [Option<NonZeroU32>; 2],
    face_0_endpoints: [[f64; 2]; 2],
    face_1_endpoints: [[f64; 2]; 2],
) -> [[[f64; 2]; 2]; 2] {
    let endpoint_sets = [face_0_endpoints, face_1_endpoints];
    std::array::from_fn(|side| {
        faces[side].map_or(endpoint_sets[side], |face| {
            crate::legacy_geometry::canonicalize_legacy_cone_pcurve_endpoints(
                &scan.surfaces.legacy_carriers,
                face.get(),
                endpoint_sets[side],
            )
        })
    })
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub(in crate::decode) enum TwoChartEndpointSets {
    Both([[[f64; 2]; 2]; 2]),
    First([[f64; 2]; 2]),
    Second([[f64; 2]; 2]),
}

impl TwoChartEndpointSets {
    /// The endpoint path for each face.
    pub(in crate::decode) fn paths(self) -> [Option<[[f64; 2]; 2]>; 2] {
        match self {
            Self::Both(paths) => paths.map(Some),
            Self::First(path) => [Some(path), None],
            Self::Second(path) => [None, Some(path)],
        }
    }

    fn complete(self) -> bool {
        matches!(self, Self::Both(_))
    }
}

#[derive(Debug)]
enum TwoChartMapping {
    NoSamples,
    Withheld,
    Mapped {
        endpoint_sets: Option<TwoChartEndpointSets>,
        missing_surface_paths: usize,
        unevaluable_paths: usize,
        surface_mismatch: bool,
    },
}

fn map_two_chart_endpoint_sets(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    model_surfaces: &ModelSurfaceIndex<'_>,
    pcurve: &crate::curve::TwoChartPcurveSamples,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<TwoChartMapping, cadmpeg_core::CodecError> {
    if scan.surfaces.withholds_curve_charts(pcurve.curve_id) {
        return Ok(TwoChartMapping::Withheld);
    }
    let (Some(first), Some(last)) = (pcurve.samples.first(), pcurve.samples.last()) else {
        return Ok(TwoChartMapping::NoSamples);
    };
    let unresolved = unresolved_plane_chart_ids(scan);
    let surfaces = pcurve.faces.map(|face_id| {
        (!unresolved.contains(&face_id))
            .then(|| model_surfaces.unique(face_id))
            .flatten()
    });
    let mut mapped = surfaces.map(|surface| surface.is_some());
    let missing_surface_paths = usize::from(!mapped[0]) + usize::from(!mapped[1]);
    let mut unevaluable_paths = 0;
    let mut mismatch = false;
    // A sample that leaves the finite range is a mapped sample; it agrees
    // with no sample on the other chart.
    for sample in &pcurve.samples {
        let mut points: [Option<Result<FinitePoint3, Point3>>; 2] = [None, None];
        for face_index in 0..2 {
            if !mapped[face_index] {
                continue;
            }
            let Some(surface) = surfaces[face_index] else {
                continue;
            };
            points[face_index] = match cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(
                    ctx,
                    source_carriers.surface_geometry(surface),
                    sample[face_index][0],
                    sample[face_index][1],
                ),
            )? {
                Ok(point) => Some(Ok(point)),
                Err(failure) => failure.non_finite()?.map(Err),
            };
            if points[face_index].is_none() {
                mapped[face_index] = false;
                unevaluable_paths += 1;
            }
        }
        if let [Some(first), Some(second)] = &points {
            mismatch |= match (first, second) {
                (Ok(first), Ok(second)) => !model_points_agree(*first, *second),
                _ => true,
            };
        }
    }
    let canonical = canonicalized_pcurve_endpoints(
        scan,
        pcurve.faces.map(NonZeroU32::new),
        [first[0], last[0]],
        [first[1], last[1]],
    );
    let endpoint_sets = std::array::from_fn(|index| mapped[index].then_some(canonical[index]));
    let mut endpoint_sets = match endpoint_sets {
        [Some(first), Some(second)] => Some(TwoChartEndpointSets::Both([first, second])),
        [Some(first), None] => Some(TwoChartEndpointSets::First(first)),
        [None, Some(second)] => Some(TwoChartEndpointSets::Second(second)),
        [None, None] => None,
    };
    if scan
        .curves
        .angular_two_chart_curve_ids
        .contains(&pcurve.curve_id)
        && !crate::decode::sweep::surfaces::admit_angular_constraints(
            ctx,
            scan,
            pcurve,
            model_surfaces.surfaces,
            source_carriers,
            None,
        )?
    {
        endpoint_sets = None;
    }
    let surface_mismatch = mapped[0] && mapped[1] && mismatch;
    Ok(TwoChartMapping::Mapped {
        endpoint_sets,
        missing_surface_paths,
        unevaluable_paths,
        surface_mismatch,
    })
}

pub(in crate::decode) fn mapped_two_chart_endpoint_sets(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    model_surfaces: &ModelSurfaceIndex<'_>,
    pcurve: &crate::curve::TwoChartPcurveSamples,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<Option<TwoChartEndpointSets>, cadmpeg_core::CodecError> {
    Ok(
        match map_two_chart_endpoint_sets(ctx, scan, model_surfaces, pcurve, source_carriers)? {
            TwoChartMapping::Mapped {
                endpoint_sets,
                surface_mismatch: false,
                ..
            } => endpoint_sets,
            TwoChartMapping::NoSamples
            | TwoChartMapping::Withheld
            | TwoChartMapping::Mapped {
                surface_mismatch: true,
                ..
            } => None,
        },
    )
}

#[cfg(test)]
pub(in crate::decode) fn mapped_pcurve_endpoints(
    ir: &CadIr,
    faces: [u32; 2],
    endpoint_sets: [[[f64; 2]; 2]; 2],
) -> Result<Option<[[f64; 3]; 2]>, cadmpeg_core::CodecError> {
    let mapped = crate::decode::with_service_context(|ctx| {
        map_pcurve_paths(
            ctx,
            &ModelSurfaceIndex::new(&ir.geometry.surfaces),
            faces.into_iter().map(NonZeroU32::new).zip(endpoint_sets),
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
    })?;
    Ok(pcurve_endpoint_evidence_from_mapped(&mapped.mapped, false).map(|evidence| evidence.points))
}

#[derive(Debug, Clone, Copy)]
pub(in crate::decode) struct PcurveEndpointEvidence {
    pub(super) points: [[f64; 3]; 2],
    pub(in crate::decode) complete: bool,
    /// The endpoints came from a complete native grammar that is allowed to
    /// override an inconsistent inferred analytic intersection at a vertex.
    pub(super) authoritative: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub(in crate::decode) struct PcurveMismatchDetail {
    pub(in crate::decode) curve_id: u32,
    pub(in crate::decode) faces: [u32; 2],
    pub(in crate::decode) same_order_error: f64,
    pub(in crate::decode) reverse_order_error: f64,
}

#[derive(Debug, Default, Clone, PartialEq)]
pub(in crate::decode) struct PcurveEndpointDiagnostics {
    pub(in crate::decode) records: usize,
    pub(in crate::decode) inactive_paths: usize,
    pub(in crate::decode) inactive_records: usize,
    pub(in crate::decode) partial_records: usize,
    pub(in crate::decode) topology_mismatch_records: usize,
    pub(in crate::decode) missing_surfaces: usize,
    pub(in crate::decode) unevaluable_paths: usize,
    pub(in crate::decode) mapped_paths: usize,
    pub(in crate::decode) unmapped_records: usize,
    pub(in crate::decode) inconsistent_records: usize,
    pub(in crate::decode) accepted_records: usize,
    pub(in crate::decode) complete_records: usize,
    pub(in crate::decode) conflicting_curves: usize,
    pub(in crate::decode) evidence: usize,
    pub(in crate::decode) complete_evidence: usize,
    pub(in crate::decode) two_chart_records: usize,
    pub(in crate::decode) two_chart_complete_records: usize,
    pub(in crate::decode) two_chart_partial_records: usize,
    pub(in crate::decode) two_chart_missing_surface_paths: usize,
    pub(in crate::decode) two_chart_unevaluable_paths: usize,
    pub(in crate::decode) two_chart_surface_mismatch_records: usize,
    pub(in crate::decode) two_chart_no_sample_records: usize,
    pub(in crate::decode) two_chart_unmapped_records: usize,
    pub(in crate::decode) carrier_validated_paths: usize,
    pub(in crate::decode) carrier_rejected_paths: usize,
    pub(in crate::decode) carrier_unknown_missing_surface_paths: usize,
    pub(in crate::decode) carrier_unknown_missing_carrier_paths: usize,
    pub(in crate::decode) carrier_unknown_unsupported_pair_paths: usize,
    pub(in crate::decode) carrier_unknown_parallel_plane_paths: usize,
    pub(in crate::decode) carrier_unknown_unsupported_path_paths: usize,
    pub(in crate::decode) carrier_rejected_records: usize,
    pub(in crate::decode) mismatch_samples: Vec<PcurveMismatchDetail>,
}

impl PcurveEndpointDiagnostics {
    /// Returns the total number of path outcomes.
    pub(in crate::decode) fn paths(&self) -> usize {
        self.mapped_paths + self.missing_surfaces + self.unevaluable_paths
    }

    /// Returns the number of records with at least one mapped chart.
    pub(in crate::decode) fn two_chart_mapped_records(&self) -> usize {
        self.two_chart_complete_records + self.two_chart_partial_records
    }

    /// Returns the number of paths without a carrier decision.
    pub(in crate::decode) fn carrier_unknown_paths(&self) -> usize {
        self.carrier_unknown_missing_surface_paths
            + self.carrier_unknown_missing_carrier_paths
            + self.carrier_unknown_unsupported_pair_paths
            + self.carrier_unknown_parallel_plane_paths
            + self.carrier_unknown_unsupported_path_paths
    }
}

#[derive(Debug, Default)]
struct PcurvePathActivity {
    active_paths: BTreeSet<(Option<std::num::NonZeroU32>, u32)>,
    topology_faces: BTreeMap<u32, [Option<std::num::NonZeroU32>; 2]>,
    prototype_faces: BTreeMap<u32, [Option<std::num::NonZeroU32>; 2]>,
}

impl PcurvePathActivity {
    fn from_scan(scan: &ContainerScan) -> Self {
        let mut active_paths = BTreeSet::new();
        for loop_ in &scan.topology.loops {
            for half_edge in loop_.half_edges() {
                let key = (loop_.face_id(), half_edge.curve_id);
                active_paths.insert(key);
            }
        }
        let mut topology_faces = BTreeMap::new();
        for row in
            crate::identity::uniquely_identified_rows(&scan.curves.topology_rows, |row| row.id)
        {
            topology_faces.insert(row.id, row.faces);
        }
        let mut prototype_counts = BTreeMap::<u32, usize>::new();
        for row in &scan.curves.prototype_topology {
            match prototype_counts.entry(row.curve_id) {
                std::collections::btree_map::Entry::Occupied(mut entry) => *entry.get_mut() += 1,
                std::collections::btree_map::Entry::Vacant(entry) => {
                    entry.insert(1);
                }
            }
        }
        let mut prototype_faces = BTreeMap::new();
        for row in &scan.curves.prototype_topology {
            if prototype_counts.get(&row.curve_id) == Some(&1) {
                prototype_faces.insert(row.curve_id, row.faces);
            }
        }
        Self {
            active_paths,
            topology_faces,
            prototype_faces,
        }
    }

    fn selected_paths(
        &self,
        curve_id: u32,
        faces: [Option<NonZeroU32>; 2],
        prototype: bool,
    ) -> Option<[bool; 2]> {
        let topology_faces = if prototype {
            &self.prototype_faces
        } else {
            &self.topology_faces
        };
        (topology_faces.get(&curve_id) == Some(&faces)).then_some([
            self.active_paths.contains(&(faces[0], curve_id)),
            self.active_paths.contains(&(faces[1], curve_id)),
        ])
    }
}

#[derive(Debug, Clone, Copy)]
struct MappedPcurvePath {
    face_id: u32,
    endpoints: [[f64; 3]; 2],
}

type IndexedPcurvePath = (usize, (Option<NonZeroU32>, [[f64; 2]; 2]));
type SupportConePlaneWitness = ([[f64; 2]; 2], PlaneEquation);

struct MappedPcurvePaths {
    mapped: Vec<MappedPcurvePath>,
    missing_surfaces: usize,
    unevaluable_paths: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PcurveCarrierUnknownReason {
    MissingSurface,
    MissingCarrier,
    UnsupportedPair,
    ParallelPlanePair,
    UnsupportedPath,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PcurveCarrierStatus {
    Validated,
    Rejected,
    Unknown(PcurveCarrierUnknownReason),
}

fn pcurve_plane_carrier_status(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    face_carrier: CarrierEquation,
    other_carrier: CarrierEquation,
    endpoints: [[f64; 2]; 2],
) -> Result<PcurveCarrierStatus, cadmpeg_core::CodecError> {
    let (CarrierEquation::Plane(face_plane), CarrierEquation::Plane(other_plane)) =
        (face_carrier, other_carrier)
    else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::UnsupportedPair,
        ));
    };
    if dot(
        cross(face_plane.normal, other_plane.normal),
        cross(face_plane.normal, other_plane.normal),
    ) <= PCURVE_CARRIER_PARALLEL_EPS_SQUARED
    {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::ParallelPlanePair,
        ));
    }
    if !matches!(
        surface,
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_))
    ) || linear_pcurve_carrier(ctx, surface, endpoints)?.is_none()
    {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::UnsupportedPath,
        ));
    }
    for fraction in PCURVE_CARRIER_SAMPLE_PARAMETERS {
        let uv = [
            endpoints[0][0].mul_add(1.0 - fraction, endpoints[1][0] * fraction),
            endpoints[0][1].mul_add(1.0 - fraction, endpoints[1][1] * fraction),
        ];
        let Some(point) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv[0], uv[1]),
            )?)?
        else {
            return Ok(PcurveCarrierStatus::Rejected);
        };
        let point = [point.x, point.y, point.z];
        if !point_on_carrier(point, face_carrier) || !point_on_carrier(point, other_carrier) {
            return Ok(PcurveCarrierStatus::Rejected);
        }
    }
    Ok(PcurveCarrierStatus::Validated)
}

fn pcurve_path_carrier_status(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    model_surfaces: &ModelSurfaceIndex<'_>,
    carriers: &BTreeMap<u32, CarrierEquation>,
    faces: [Option<NonZeroU32>; 2],
    face_index: usize,
    endpoints: [[f64; 2]; 2],
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<PcurveCarrierStatus, cadmpeg_core::CodecError> {
    let face_id = faces[face_index];
    let other_id = faces[1 - face_index];
    let Some(surface) = face_id.and_then(|id| model_surfaces.unique(id.get())) else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingSurface,
        ));
    };
    let Some(face_carrier) = face_id.and_then(|id| carriers.get(&id.get())).copied() else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingCarrier,
        ));
    };
    let Some(other_carrier) = other_id.and_then(|id| carriers.get(&id.get())).copied() else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingCarrier,
        ));
    };
    pcurve_plane_carrier_status(
        ctx,
        source_carriers.surface_geometry(surface),
        face_carrier,
        other_carrier,
        endpoints,
    )
}

fn pcurve_endpoint_carrier_status(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    model_surfaces: &ModelSurfaceIndex<'_>,
    carriers: &BTreeMap<u32, CarrierEquation>,
    faces: [Option<NonZeroU32>; 2],
    face_index: usize,
    endpoints: [[f64; 2]; 2],
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<PcurveCarrierStatus, cadmpeg_core::CodecError> {
    let face_id = faces[face_index];
    let other_id = faces[1 - face_index];
    let Some(surface) = face_id.and_then(|id| model_surfaces.unique(id.get())) else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingSurface,
        ));
    };
    let Some(face_carrier) = face_id.and_then(|id| carriers.get(&id.get())).copied() else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingCarrier,
        ));
    };
    let Some(other_carrier) = other_id.and_then(|id| carriers.get(&id.get())).copied() else {
        return Ok(PcurveCarrierStatus::Unknown(
            PcurveCarrierUnknownReason::MissingCarrier,
        ));
    };
    let mut valid = true;
    for uv in endpoints {
        if !valid {
            break;
        }
        let Some(point) = cadmpeg_ir::eval::finite_or_refusal(
            cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
                ctx,
                source_carriers.surface_geometry(surface),
                uv[0],
                uv[1],
            ))?,
        )?
        else {
            valid = false;
            break;
        };
        let point = [point.x, point.y, point.z];
        valid = point_on_carrier(point, face_carrier) && point_on_carrier(point, other_carrier);
    }
    Ok(if valid {
        PcurveCarrierStatus::Validated
    } else {
        PcurveCarrierStatus::Rejected
    })
}

/// Mirrors an apex cone through its apex: the same shape a cone surface record carries, so it
/// takes its half angle as a [`crate::surface::ApexConeHalfAngle`].
///
/// The frame is not examined. A `ConeSurface` holds an
/// [`cadmpeg_ir::units::OrthonormalFrame3`], whose only admission is
/// [`cadmpeg_ir::units::OrthonormalFrame3::new`]: both directions are unit length and
/// perpendicular within the analytic frame tolerance, so every component is finite.
/// [`cadmpeg_ir::units::OrthonormalFrame3::reverse_axis`] negates components and keeps that
/// guarantee, and `ConeSurface::new` moves the frame across without a new admission.
fn mirrored_support_apex_cone(geometry: &SurfaceGeometry) -> Option<SurfaceGeometry> {
    let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)) = geometry else {
        return None;
    };
    let radius = cone_surface.radius().get();
    let ratio = cone_surface.ratio().get();
    let half_angle = cone_surface.half_angle().get();
    if radius != 0.0
        || (ratio - 1.0).abs() > EPS_NEAR_ZERO
        || crate::surface::ApexConeHalfAngle::new(half_angle).is_none()
    {
        return None;
    }
    let origin = cone_surface.origin().negated();
    let mut frame = *cone_surface.frame();
    frame.reverse_axis();
    Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
        cadmpeg_ir::geometry::analytic::ConeSurface::new(
            origin,
            frame,
            cone_surface.radius(),
            cone_surface.ratio(),
            cone_surface.half_angle(),
        ),
    )))
}

fn support_cone_witness_matches(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    geometry: &SurfaceGeometry,
    endpoints: [[f64; 2]; 2],
    plane: PlaneEquation,
) -> Result<bool, cadmpeg_core::CodecError> {
    for uv in endpoints {
        let Some(point) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(ctx, geometry, uv[0], uv[1]),
            )?)?
        else {
            return Ok(false);
        };
        if !point_on_carrier([point.x, point.y, point.z], CarrierEquation::Plane(plane)) {
            return Ok(false);
        }
    }
    Ok(true)
}

fn collect_support_cone_plane_witness(
    witnesses: &mut BTreeMap<u32, Vec<SupportConePlaneWitness>>,
    planes: &BTreeMap<u32, PlaneEquation>,
    faces: [Option<NonZeroU32>; 2],
    endpoint_sets: [Option<[[f64; 2]; 2]>; 2],
) {
    let [Some(first), Some(second)] = faces else {
        return;
    };
    let faces = [first.get(), second.get()];
    for face_index in 0..2 {
        let Some(endpoints) = endpoint_sets[face_index] else {
            continue;
        };
        let Some(plane) = planes.get(&faces[1 - face_index]).copied() else {
            continue;
        };
        match witnesses.entry(faces[face_index]) {
            std::collections::btree_map::Entry::Occupied(mut entry) => {
                entry.get_mut().push((endpoints, plane));
            }
            std::collections::btree_map::Entry::Vacant(entry) => {
                let values = vec![(endpoints, plane)];
                entry.insert(values);
            }
        }
    }
}

fn unique_model_surface_mut(surfaces: &mut [Surface], face_id: u32) -> Option<&mut Surface> {
    for prefix in MODEL_SURFACE_PREFIXES {
        let mut matches = surfaces.iter().enumerate().filter_map(|(index, surface)| {
            crate::identity::matches_numbered_identity(surface.id.as_str(), prefix, face_id)
                .then_some(index)
        });
        let Some(index) = matches.next() else {
            continue;
        };
        if matches.next().is_some() {
            return None;
        }
        return surfaces.get_mut(index);
    }
    None
}

/// Reconcile the signed frame of a radius-zero support cone from a pcurve
/// endpoint and an independently placed adjacent plane.
pub(in crate::decode) fn reconcile_support_apex_cone_parameter_branches(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder,
    source_carriers: &mut crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<usize, cadmpeg_core::CodecError> {
    let planes = super::planes::placed_planes(scan)?;
    if planes.is_empty() {
        return Ok(0);
    }
    let mut witnesses = BTreeMap::<u32, Vec<SupportConePlaneWitness>>::new();
    for pcurve in &scan.curves.pcurves {
        let endpoint_sets = canonicalized_pcurve_endpoints(
            scan,
            pcurve.faces,
            pcurve.face_0_endpoints,
            pcurve.face_1_endpoints,
        );
        collect_support_cone_plane_witness(
            &mut witnesses,
            &planes,
            pcurve.faces,
            endpoint_sets.map(Some),
        );
    }
    for pcurve in &scan.curves.bound_prototype_pcurves {
        let endpoint_sets = canonicalized_pcurve_endpoints(
            scan,
            pcurve.faces,
            pcurve.face_0_endpoints,
            pcurve.face_1_endpoints,
        );
        collect_support_cone_plane_witness(
            &mut witnesses,
            &planes,
            pcurve.faces,
            endpoint_sets.map(Some),
        );
    }
    let model_surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
    for pcurve in &scan.curves.two_chart_pcurves {
        let faces = pcurve.faces.map(NonZeroU32::new);
        let mapping =
            map_two_chart_endpoint_sets(ctx, scan, &model_surfaces, pcurve, source_carriers)?;
        let TwoChartMapping::Mapped {
            endpoint_sets: Some(endpoint_sets),
            ..
        } = mapping
        else {
            continue;
        };
        collect_support_cone_plane_witness(&mut witnesses, &planes, faces, endpoint_sets.paths());
    }

    let mut reconciled = 0;
    for (face_id, face_witnesses) in witnesses {
        let Some(surface) = unique_model_surface_mut(&mut ir.geometry.surfaces, face_id) else {
            continue;
        };
        let source_geometry = source_carriers.surface_geometry(surface);
        let Some(mirrored) = mirrored_support_apex_cone(source_geometry) else {
            continue;
        };
        let mut current_matches = true;
        for (endpoints, plane) in &face_witnesses {
            if !support_cone_witness_matches(ctx, source_geometry, *endpoints, *plane)? {
                current_matches = false;
                break;
            }
        }
        let mut mirrored_matches = true;
        for (endpoints, plane) in &face_witnesses {
            if !support_cone_witness_matches(ctx, &mirrored, *endpoints, *plane)? {
                mirrored_matches = false;
                break;
            }
        }
        if current_matches || !mirrored_matches {
            continue;
        }
        source_carriers.replace_surface_geometry(ctx, surface, mirrored)?;
        reconciled += 1;
        if let Some(row) = crate::surface::unique_surface_row(&scan.surfaces.rows, face_id) {
            annotate(
                annotations,
                &surface.id,
                "VisibGeom",
                cadmpeg_core::decode::u64_from_index(row.offset),
                "support_apex_cone_pcurve_branch",
                Exactness::Derived,
            )?;
        }
    }
    Ok(reconciled)
}

fn map_pcurve_paths(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    model_surfaces: &ModelSurfaceIndex<'_>,
    paths: impl IntoIterator<Item = (Option<NonZeroU32>, [[f64; 2]; 2])>,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<MappedPcurvePaths, cadmpeg_core::CodecError> {
    let mut result = MappedPcurvePaths {
        mapped: Vec::new(),
        missing_surfaces: 0,
        unevaluable_paths: 0,
    };
    for (face_id, endpoints) in paths {
        let Some(face_id) = face_id else {
            result.missing_surfaces += 1;
            continue;
        };
        let face_id = face_id.get();
        let Some(surface) = model_surfaces.unique(face_id) else {
            result.missing_surfaces += 1;
            continue;
        };
        // A non-finite endpoint is a mapped endpoint; the path comparisons
        // read it as a mismatch.
        let [first, second] = endpoints.map(|uv| -> Result<_, cadmpeg_core::CodecError> {
            let point = match cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(
                    ctx,
                    source_carriers.surface_geometry(surface),
                    uv[0],
                    uv[1],
                ),
            )? {
                Ok(point) => point.get(),
                Err(failure) => match failure.non_finite()? {
                    Some(point) => point,
                    None => return Ok(None),
                },
            };
            Ok(Some([point.x, point.y, point.z]))
        });
        let [Some(first), Some(second)] = [first?, second?] else {
            result.unevaluable_paths += 1;
            continue;
        };
        result.mapped.push(MappedPcurvePath {
            face_id,
            endpoints: [first, second],
        });
    }
    Ok(result)
}

fn pcurve_endpoint_evidence_from_mapped(
    mapped: &[MappedPcurvePath],
    authoritative: bool,
) -> Option<PcurveEndpointEvidence> {
    let first = mapped.first()?.endpoints;
    // An endpoint outside the finite range agrees with no endpoint, so a
    // path that reaches one forms no evidence.
    let admitted = first.map(finite_model_point);
    mapped
        .iter()
        .all(|candidate| {
            admitted
                .into_iter()
                .zip(candidate.endpoints)
                .all(|(first, candidate)| {
                    first
                        .zip(finite_model_point(candidate))
                        .is_some_and(|(first, candidate)| model_points_agree(first, candidate))
                })
        })
        .then_some(PcurveEndpointEvidence {
            points: first,
            complete: mapped.len() == 2,
            authoritative,
        })
}

fn point_coordinate_error(first: [f64; 3], second: [f64; 3]) -> f64 {
    first
        .into_iter()
        .zip(second)
        .map(|(first, second)| {
            let error = (first - second).abs();
            if error.is_finite() {
                error
            } else {
                f64::INFINITY
            }
        })
        .fold(0.0, f64::max)
}

fn endpoint_pair_error(first: [[f64; 3]; 2], second: [[f64; 3]; 2], reverse: bool) -> f64 {
    if reverse {
        point_coordinate_error(first[0], second[1]).max(point_coordinate_error(first[1], second[0]))
    } else {
        point_coordinate_error(first[0], second[0]).max(point_coordinate_error(first[1], second[1]))
    }
}

fn pcurve_mismatch_detail(
    curve_id: u32,
    mapped: &[MappedPcurvePath],
) -> Option<PcurveMismatchDetail> {
    let first = mapped.first()?.endpoints;
    let second = mapped.get(1)?;
    (mapped.len() > 1).then(|| PcurveMismatchDetail {
        curve_id,
        faces: [mapped[0].face_id, second.face_id],
        same_order_error: mapped
            .iter()
            .skip(1)
            .map(|candidate| endpoint_pair_error(first, candidate.endpoints, false))
            .fold(0.0, f64::max),
        reverse_order_error: mapped
            .iter()
            .skip(1)
            .map(|candidate| endpoint_pair_error(first, candidate.endpoints, true))
            .fold(0.0, f64::max),
    })
}

pub(in crate::decode) fn pcurve_edge_endpoint_evidence(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<BTreeMap<u32, PcurveEndpointEvidence>, cadmpeg_core::CodecError> {
    Ok(pcurve_edge_endpoint_evidence_with_diagnostics(ctx, scan, ir, source_carriers)?.0)
}

fn pcurve_edge_endpoint_evidence_with_diagnostics(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<
    (
        BTreeMap<u32, PcurveEndpointEvidence>,
        PcurveEndpointDiagnostics,
    ),
    cadmpeg_core::CodecError,
> {
    let carriers = placed_carriers(ctx, scan, ir, source_carriers)?;
    pcurve_edge_endpoint_evidence_with_carriers(ctx, scan, ir, &carriers, source_carriers)
}

pub(super) fn pcurve_edge_endpoint_evidence_with_carriers(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &CadIr,
    carriers: &BTreeMap<u32, CarrierEquation>,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<
    (
        BTreeMap<u32, PcurveEndpointEvidence>,
        PcurveEndpointDiagnostics,
    ),
    cadmpeg_core::CodecError,
> {
    let ignored_surface_ids = topology_ignored_surface_ids(scan);
    let path_activity = PcurvePathActivity::from_scan(scan);
    let model_surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
    let mut candidates = BTreeMap::<u32, Vec<PcurveEndpointEvidence>>::new();
    let mut diagnostics = PcurveEndpointDiagnostics::default();
    let mut process_paths = |curve_id: u32,
                             faces: [Option<NonZeroU32>; 2],
                             paths: Vec<IndexedPcurvePath>,
                             authoritative: bool,
                             endpoint_carrier_proof: bool|
     -> Result<(), cadmpeg_core::CodecError> {
        if scan.surfaces.withholds_curve_charts(curve_id) {
            diagnostics.unmapped_records += 1;
            return Ok(());
        }
        let mut mapped_paths = Vec::new();
        let mut carrier_mapped_paths = Vec::new();
        let mut carrier_proof_available = false;
        for (face_index, (face_id, endpoints)) in paths {
            let mapped = map_pcurve_paths(
                ctx,
                &model_surfaces,
                [(face_id, endpoints)],
                source_carriers,
            )?;
            diagnostics.missing_surfaces += mapped.missing_surfaces;
            diagnostics.unevaluable_paths += mapped.unevaluable_paths;
            diagnostics.mapped_paths += mapped.mapped.len();
            mapped_paths.extend(mapped.mapped.iter().copied());
            let carrier_status = if endpoint_carrier_proof {
                pcurve_endpoint_carrier_status(
                    ctx,
                    &model_surfaces,
                    carriers,
                    faces,
                    face_index,
                    endpoints,
                    source_carriers,
                )?
            } else {
                pcurve_path_carrier_status(
                    ctx,
                    &model_surfaces,
                    carriers,
                    faces,
                    face_index,
                    endpoints,
                    source_carriers,
                )?
            };
            match carrier_status {
                PcurveCarrierStatus::Validated => {
                    carrier_proof_available = true;
                    diagnostics.carrier_validated_paths += 1;
                    carrier_mapped_paths.extend(mapped.mapped);
                }
                PcurveCarrierStatus::Rejected => {
                    carrier_proof_available = true;
                    diagnostics.carrier_rejected_paths += 1;
                }
                PcurveCarrierStatus::Unknown(reason) => match reason {
                    PcurveCarrierUnknownReason::MissingSurface => {
                        diagnostics.carrier_unknown_missing_surface_paths += 1;
                    }
                    PcurveCarrierUnknownReason::MissingCarrier => {
                        diagnostics.carrier_unknown_missing_carrier_paths += 1;
                    }
                    PcurveCarrierUnknownReason::UnsupportedPair => {
                        diagnostics.carrier_unknown_unsupported_pair_paths += 1;
                    }
                    PcurveCarrierUnknownReason::ParallelPlanePair => {
                        diagnostics.carrier_unknown_parallel_plane_paths += 1;
                    }
                    PcurveCarrierUnknownReason::UnsupportedPath => {
                        diagnostics.carrier_unknown_unsupported_path_paths += 1;
                    }
                },
            }
        }
        let selected_paths = if carrier_proof_available {
            carrier_mapped_paths
        } else {
            mapped_paths
        };
        if carrier_proof_available && selected_paths.is_empty() {
            diagnostics.carrier_rejected_records += 1;
        }
        match pcurve_endpoint_evidence_from_mapped(&selected_paths, authoritative) {
            Some(evidence) => {
                diagnostics.accepted_records += 1;
                diagnostics.complete_records += usize::from(evidence.complete);
                match candidates.entry(curve_id) {
                    std::collections::btree_map::Entry::Occupied(mut entry) => {
                        entry.get_mut().push(evidence);
                    }
                    std::collections::btree_map::Entry::Vacant(entry) => {
                        let entries = vec![evidence];
                        entry.insert(entries);
                    }
                }
            }
            None if selected_paths.is_empty() && !carrier_proof_available => {
                diagnostics.unmapped_records += 1;
            }
            None => {
                diagnostics.inconsistent_records += 1;
                if diagnostics.mismatch_samples.len() < PCURVE_MISMATCH_SAMPLE_LIMIT {
                    if let Some(detail) = pcurve_mismatch_detail(curve_id, &selected_paths) {
                        diagnostics.mismatch_samples.push(detail);
                    }
                }
            }
        }
        Ok(())
    };
    for (curve_id, faces, first, second, prototype) in scan
        .curves
        .pcurves
        .iter()
        .map(|pcurve| {
            let [first, second] = canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            );
            (pcurve.curve_id, pcurve.faces, first, second, false)
        })
        .chain(scan.curves.bound_prototype_pcurves.iter().map(|pcurve| {
            let [first, second] = canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            );
            (pcurve.curve_id, pcurve.faces, first, second, true)
        }))
    {
        diagnostics.records += 1;
        if let Some(active) = path_activity.selected_paths(curve_id, faces, prototype) {
            let active_count = active.into_iter().filter(|is_active| *is_active).count();
            diagnostics.inactive_paths += 2 - active_count;
            match active_count {
                0 => diagnostics.inactive_records += 1,
                1 => diagnostics.partial_records += 1,
                _ => {}
            }
        } else {
            diagnostics.topology_mismatch_records += 1;
        }
        let mut paths = Vec::new();
        for path in
            faces
                .into_iter()
                .zip([first, second])
                .enumerate()
                .filter(|(_, (face_id, _))| {
                    face_id.is_none_or(|id| !ignored_surface_ids.contains(&id.get()))
                })
        {
            paths.push(path);
        }
        process_paths(curve_id, faces, paths, false, false)?;
    }
    for pcurve in &scan.curves.two_chart_pcurves {
        let faces = pcurve.faces.map(NonZeroU32::new);
        diagnostics.records += 1;
        diagnostics.two_chart_records += 1;
        let mapping =
            map_two_chart_endpoint_sets(ctx, scan, &model_surfaces, pcurve, source_carriers)?;
        let (endpoint_sets, surface_mismatch) = match mapping {
            TwoChartMapping::Withheld => (None, false),
            TwoChartMapping::NoSamples => {
                diagnostics.two_chart_no_sample_records += 1;
                (None, false)
            }
            TwoChartMapping::Mapped {
                endpoint_sets,
                missing_surface_paths,
                unevaluable_paths,
                surface_mismatch,
            } => {
                diagnostics.two_chart_missing_surface_paths += missing_surface_paths;
                diagnostics.two_chart_unevaluable_paths += unevaluable_paths;
                diagnostics.two_chart_surface_mismatch_records += usize::from(surface_mismatch);
                (endpoint_sets, surface_mismatch)
            }
        };
        let Some(endpoint_sets) = endpoint_sets else {
            diagnostics.two_chart_unmapped_records += 1;
            process_paths(pcurve.curve_id, faces, Vec::new(), true, false)?;
            continue;
        };
        if endpoint_sets.complete() {
            diagnostics.two_chart_complete_records += 1;
        } else {
            diagnostics.two_chart_partial_records += 1;
        }
        if let Some(active) = path_activity.selected_paths(pcurve.curve_id, faces, false) {
            let active_count = active.into_iter().filter(|is_active| *is_active).count();
            diagnostics.inactive_paths += 2 - active_count;
            match active_count {
                0 => diagnostics.inactive_records += 1,
                1 => diagnostics.partial_records += 1,
                _ => {}
            }
        } else {
            diagnostics.topology_mismatch_records += 1;
        }
        let mut paths = Vec::new();
        for path in faces
            .into_iter()
            .zip(endpoint_sets.paths())
            .enumerate()
            .filter_map(|(index, (face_id, endpoints))| {
                face_id
                    .is_none_or(|id| !ignored_surface_ids.contains(&id.get()))
                    .then_some((index, (face_id, endpoints?)))
            })
        {
            paths.push(path);
        }
        process_paths(
            pcurve.curve_id,
            faces,
            paths,
            endpoint_sets.complete(),
            surface_mismatch,
        )?;
    }
    let short_pcurves = crate::curve::fc02_short_pcurve_endpoints(
        &scan.curves.parameters,
        &scan.curves.topology_rows,
    );
    for pcurve in short_pcurves {
        let faces = pcurve.faces.map(NonZeroU32::new);
        diagnostics.records += 1;
        if let Some(active) = path_activity.selected_paths(pcurve.curve_id, faces, false) {
            diagnostics.inactive_paths += usize::from(!active[0]);
            diagnostics.inactive_records += usize::from(!active[0]);
        } else {
            diagnostics.topology_mismatch_records += 1;
        }
        let [face_0_endpoints, _] = canonicalized_pcurve_endpoints(
            scan,
            faces,
            pcurve.face_0_endpoints,
            pcurve.face_0_endpoints,
        );
        let mut paths = Vec::new();
        if faces[0].is_none_or(|id| !ignored_surface_ids.contains(&id.get())) {
            paths.push((0, (faces[0], face_0_endpoints)));
        }
        process_paths(pcurve.curve_id, faces, paths, true, false)?;
    }
    let mut evidence = BTreeMap::new();
    for (curve_id, candidates) in candidates {
        let Some(first) = candidates.first().copied() else {
            continue;
        };
        // An endpoint outside the finite range agrees with no endpoint.
        let admitted = first.points.map(finite_model_point);
        if candidates.iter().all(|candidate| {
            admitted
                .into_iter()
                .zip(candidate.points)
                .all(|(first, candidate)| {
                    first
                        .zip(finite_model_point(candidate))
                        .is_some_and(|(first, candidate)| model_points_agree(first, candidate))
                })
        }) {
            evidence.insert(
                curve_id,
                PcurveEndpointEvidence {
                    points: first.points,
                    complete: candidates.iter().any(|candidate| candidate.complete),
                    authoritative: candidates.iter().all(|candidate| candidate.authoritative),
                },
            );
        } else {
            diagnostics.conflicting_curves += 1;
        }
    }
    diagnostics.evidence = evidence.len();
    diagnostics.complete_evidence = evidence.values().filter(|value| value.complete).count();
    Ok((evidence, diagnostics))
}

fn pcurve_edge_endpoints(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<BTreeMap<u32, [[f64; 3]; 2]>, cadmpeg_core::CodecError> {
    let mut endpoints = BTreeMap::new();
    for (curve_id, evidence) in pcurve_edge_endpoint_evidence(ctx, scan, ir, source_carriers)? {
        endpoints.insert(curve_id, evidence.points);
    }
    Ok(endpoints)
}

/// Keep the surface frame, with the reference reversed when `sign` is
/// negative: a negative ring or local radius places the circle start on the
/// opposite side of the axis.
fn signed_reference_frame(mut frame: OrthonormalFrame3, sign: f64) -> OrthonormalFrame3 {
    if sign.is_sign_negative() {
        frame.reverse_reference();
    }
    frame
}

pub(in crate::decode) fn linear_pcurve_carrier(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    endpoints: [[f64; 2]; 2],
) -> Result<Option<CurveGeometry>, cadmpeg_core::CodecError> {
    let scaled_vector = |vector: Vector3, scale: f64| {
        Vector3::new(vector.x * scale, vector.y * scale, vector.z * scale)
    };
    let offset_point = |point: Point3, vector: Vector3, scale: f64| {
        Point3::new(
            point.x + vector.x * scale,
            point.y + vector.y * scale,
            point.z + vector.z * scale,
        )
    };
    let [start, end] = endpoints;
    if start == end {
        return Ok(None);
    }
    Ok(match surface {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_)) => {
            let [first, second] = endpoints.map(|uv| {
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv[0], uv[1]),
                )?)
                .map(|point| point.map(|point| [point.x, point.y, point.z]))
            });
            let [Some(first), Some(second)] = [first?, second?] else {
                return Ok(None);
            };
            let direction = require_some!(normalize(std::array::from_fn(
                |axis| second[axis] - first[axis]
            )));
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(
                require_some!(cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                    Point3::from(first),
                    Vector3::from(direction),
                )
                .ok()),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface))
            if { start[0] == end[0] } =>
        {
            let origin = cylinder_surface.origin().get();
            let axis = cylinder_surface.frame().axis().as_raw();
            let ref_direction = cylinder_surface.frame().reference().as_raw();
            let radius = cylinder_surface.radius().get();
            let transverse = cross(
                [axis.x, axis.y, axis.z],
                [ref_direction.x, ref_direction.y, ref_direction.z],
            );
            let reference = [ref_direction.x, ref_direction.y, ref_direction.z];
            let radial: [f64; 3] = std::array::from_fn(|coordinate| {
                start[0].cos() * reference[coordinate] + start[0].sin() * transverse[coordinate]
            });
            let point = [
                origin.x + radius * radial[0] + start[1] * axis.x,
                origin.y + radius * radial[1] + start[1] * axis.y,
                origin.z + radius * radial[2] + start[1] * axis.z,
            ];
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(
                cadmpeg_ir::geometry::analytic::LineCurve::new(
                    require_some!(cadmpeg_ir::features::FinitePoint3::new(Point3::from(point))),
                    cylinder_surface.frame().axis().to_unit_length(),
                ),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface))
            if start[1] == end[1] =>
        {
            let origin = cylinder_surface.origin().get();
            let axis = cylinder_surface.frame().axis().as_raw();
            let center = require_some!(FinitePoint3::new(offset_point(origin, *axis, start[1])));
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::new(
                    center,
                    *cylinder_surface.frame(),
                    cylinder_surface.radius(),
                ),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(_)) if { start[0] == end[0] } => {
            let [first, second] = endpoints.map(|uv| {
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv[0], uv[1]),
                )?)
                .map(|point| point.map(|point| [point.x, point.y, point.z]))
            });
            let [Some(first), Some(second)] = [first?, second?] else {
                return Ok(None);
            };
            let direction = require_some!(normalize(std::array::from_fn(
                |axis| second[axis] - first[axis]
            )));
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(
                require_some!(cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                    Point3::from(first),
                    Vector3::from(direction),
                )
                .ok()),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface))
            if { start[1] == end[1] } =>
        {
            let origin = cone_surface.origin().get();
            let axis = cone_surface.frame().axis().as_raw();
            let ref_direction = cone_surface.frame().reference().as_raw();
            let radius = cone_surface.radius().get();
            let ratio = cone_surface.ratio().get();
            let half_angle = cone_surface.half_angle().get();
            let local_radius = radius + start[1] * half_angle.tan();
            let first_radius = local_radius.abs();
            let second_radius = (local_radius * ratio).abs();
            if !first_radius.is_finite() || !second_radius.is_finite() {
                return Ok(None);
            }
            let center = offset_point(origin, *axis, start[1]);
            if (first_radius - second_radius).abs()
                <= EPS_NEAR_ZERO * first_radius.max(second_radius).max(1.0)
            {
                (first_radius > 0.0).then_some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                    cadmpeg_ir::geometry::analytic::CircleCurve::new(
                        require_some!(FinitePoint3::new(center)),
                        signed_reference_frame(*cone_surface.frame(), local_radius),
                        require_some!(PositiveLength::new(first_radius)),
                    ),
                )))
            } else {
                let transverse = cross(
                    [axis.x, axis.y, axis.z],
                    [ref_direction.x, ref_direction.y, ref_direction.z],
                );
                let transverse = Vector3::from(transverse);
                let (major_direction, major_radius, minor_radius) = if first_radius > second_radius
                {
                    (
                        scaled_vector(*ref_direction, local_radius.signum()),
                        first_radius,
                        second_radius,
                    )
                } else {
                    (
                        scaled_vector(transverse, (local_radius * ratio).signum()),
                        second_radius,
                        first_radius,
                    )
                };
                (minor_radius > 0.0).then_some(CurveGeometry::Solved(SolvedCurveGeometry::Ellipse(
                    require_some!(cadmpeg_ir::geometry::analytic::EllipseCurve::try_new(
                        center,
                        *axis,
                        major_direction,
                        major_radius,
                        minor_radius,
                    )
                    .ok()),
                )))
            }
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(sphere_surface))
            if start[1] == end[1] =>
        {
            let center = sphere_surface.center().get();
            let axis = sphere_surface.frame().axis().as_raw();
            let radius = sphere_surface.radius().get();
            require_some!((radius > 0.0).then_some(()));
            let ring = radius * start[1].cos();
            (ring.abs() > 0.0).then_some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::new(
                    require_some!(FinitePoint3::new(offset_point(
                        center,
                        *axis,
                        radius * start[1].sin()
                    ))),
                    signed_reference_frame(*sphere_surface.frame(), ring),
                    require_some!(PositiveLength::new(ring.abs())),
                ),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(sphere_surface))
            if start[0] == end[0] =>
        {
            let axis = sphere_surface.frame().axis().as_raw();
            let ref_direction = sphere_surface.frame().reference().as_raw();
            let radius = require_some!(PositiveLength::try_from(sphere_surface.radius()).ok());
            let transverse = cross(
                [axis.x, axis.y, axis.z],
                [ref_direction.x, ref_direction.y, ref_direction.z],
            );
            let radial = Vector3::new(
                start[0].cos() * ref_direction.x + start[0].sin() * transverse[0],
                start[0].cos() * ref_direction.y + start[0].sin() * transverse[1],
                start[0].cos() * ref_direction.z + start[0].sin() * transverse[2],
            );
            let normal = cross([radial.x, radial.y, radial.z], [axis.x, axis.y, axis.z]);
            let frame = require_some!(OrthonormalFrame3::new(Vector3::from(normal), radial));
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::new(
                    sphere_surface.center(),
                    frame,
                    radius,
                ),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface))
            if start[1] == end[1] =>
        {
            let center = torus_surface.center().get();
            let axis = torus_surface.frame().axis().as_raw();
            let major_radius = torus_surface.major_radius().get();
            let minor_radius = torus_surface.minor_radius().get();
            require_some!((minor_radius > 0.0).then_some(()));
            let ring = major_radius + minor_radius * start[1].cos();
            (ring.abs() > 0.0).then_some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::new(
                    require_some!(FinitePoint3::new(offset_point(
                        center,
                        *axis,
                        minor_radius * start[1].sin()
                    ))),
                    signed_reference_frame(*torus_surface.frame(), ring),
                    require_some!(PositiveLength::new(ring.abs())),
                ),
            )))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface))
            if start[0] == end[0] =>
        {
            let center = torus_surface.center().get();
            let axis = torus_surface.frame().axis().as_raw();
            let ref_direction = torus_surface.frame().reference().as_raw();
            let major_radius = torus_surface.major_radius().get();
            let minor_radius =
                require_some!(PositiveLength::try_from(torus_surface.minor_radius()).ok());
            let transverse = cross(
                [axis.x, axis.y, axis.z],
                [ref_direction.x, ref_direction.y, ref_direction.z],
            );
            let radial = Vector3::new(
                start[0].cos() * ref_direction.x + start[0].sin() * transverse[0],
                start[0].cos() * ref_direction.y + start[0].sin() * transverse[1],
                start[0].cos() * ref_direction.z + start[0].sin() * transverse[2],
            );
            let normal = cross([radial.x, radial.y, radial.z], [axis.x, axis.y, axis.z]);
            let center = require_some!(FinitePoint3::new(offset_point(
                center,
                radial,
                major_radius
            )));
            let frame = require_some!(OrthonormalFrame3::new(Vector3::from(normal), radial));
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::new(center, frame, minor_radius),
            )))
        }
        _ => None,
    })
}

fn cap_adjacent_cylinder_ruling(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    surfaces: &ModelSurfaceIndex<'_>,
    pcurve: &crate::curve::TwoChartPcurveSamples,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<Option<(CurveGeometry, usize)>, cadmpeg_core::CodecError> {
    if !scan
        .surfaces
        .withheld_cap_curve_ids
        .contains(&pcurve.curve_id)
        || scan
            .surfaces
            .withheld_cone_origin_curve_ids
            .contains(&pcurve.curve_id)
        || pcurve.samples.len() != 2
    {
        return Ok(None);
    }
    let withheld = pcurve
        .faces
        .map(|face| scan.surfaces.withheld_cap_surface_ids.contains(&face));
    let side = match withheld {
        [true, false] => 1,
        [false, true] => 0,
        _ => return Ok(None),
    };
    let [start, end] = [pcurve.samples[0][side], pcurve.samples[1][side]];
    if start[0] != end[0] || (start[1] == 0.0) == (end[1] == 0.0) {
        return Ok(None);
    }
    let Some(surface) = surfaces.unique(pcurve.faces[side]) else {
        return Ok(None);
    };
    let geometry = source_carriers.surface_geometry(surface);
    if !matches!(
        geometry,
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(_))
    ) {
        return Ok(None);
    }
    Ok(
        linear_pcurve_carrier(ctx, geometry, [[start[0], 0.0], [start[0], 1.0]])?
            .map(|line| (line, usize::from(start[1] != 0.0))),
    )
}

pub(super) fn cap_ruling_zero_stations(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<BTreeMap<u32, (usize, [f64; 3])>, cadmpeg_core::CodecError> {
    let mut stations = BTreeMap::new();
    if scan.surfaces.withheld_cap_curve_ids.is_empty() {
        return Ok(stations);
    }
    let surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
    for pcurve in crate::identity::uniquely_identified_rows(&scan.curves.two_chart_pcurves, |row| {
        row.curve_id
    }) {
        let Some((CurveGeometry::Solved(SolvedCurveGeometry::Line(line)), endpoint)) =
            cap_adjacent_cylinder_ruling(ctx, scan, &surfaces, pcurve, source_carriers)?
        else {
            continue;
        };
        stations.insert(pcurve.curve_id, (endpoint, line.origin().get().into()));
    }
    Ok(stations)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SampledCarrierMatch {
    Agrees,
    Disagrees,
    Unevaluable,
}

impl SampledCarrierMatch {
    fn loss_code(self) -> Option<crate::loss::CreoLossCode> {
        match self {
            Self::Agrees => None,
            Self::Disagrees => Some(crate::loss::CreoLossCode::SampledPcurveCarrierUnresolved),
            Self::Unevaluable => Some(crate::loss::CreoLossCode::SampledPcurveEvaluationUnresolved),
        }
    }
}

fn sampled_pcurve_carrier_matches(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    carrier: &CurveGeometry,
    samples: &crate::curve::TwoChartPcurveSamples,
    face_index: usize,
) -> Result<SampledCarrierMatch, cadmpeg_core::CodecError> {
    for sample in &samples.samples {
        let [u, v] = sample[face_index];
        let Some(point) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(ctx, surface, u, v),
            )?)?
        else {
            return Ok(SampledCarrierMatch::Unevaluable);
        };
        if !curve_contains_points(carrier, [[point.x, point.y, point.z]; 2]) {
            return Ok(SampledCarrierMatch::Disagrees);
        }
    }
    Ok(SampledCarrierMatch::Agrees)
}

pub(in crate::decode) fn transfer_analytic_pcurve_carriers(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder,
    losses: &mut Vec<cadmpeg_ir::report::loss::LossNote>,
    source_carriers: &mut crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<BTreeSet<CurveId>, cadmpeg_core::CodecError> {
    for pcurve in &scan.curves.two_chart_pcurves {
        if scan
            .curves
            .angular_two_chart_curve_ids
            .contains(&pcurve.curve_id)
        {
            crate::decode::sweep::surfaces::admit_angular_constraints(
                ctx,
                scan,
                pcurve,
                &ir.geometry.surfaces,
                source_carriers,
                Some(losses),
            )?;
        }
    }
    let reconciled_endpoints = pcurve_edge_endpoints(ctx, scan, ir, source_carriers)?;
    let ignored_surface_ids = topology_ignored_surface_ids(scan);
    let mut candidates = BTreeMap::<u32, Vec<(CurveGeometry, usize)>>::new();
    let mut evaluable_path_counts = BTreeMap::<u32, usize>::new();
    {
        let model_surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
        let mut curved_paths = Vec::new();
        let mut retain_path = |curve_id: u32,
                               face_id: Option<NonZeroU32>,
                               endpoints: [[f64; 2]; 2],
                               offset: usize,
                               sampled: Option<(&crate::curve::TwoChartPcurveSamples, usize)>|
         -> Result<bool, cadmpeg_core::CodecError> {
            if scan.surfaces.withholds_curve_charts(curve_id) {
                return Ok(false);
            }
            let Some(face_id) = face_id.map(NonZeroU32::get) else {
                return Ok(false);
            };
            if ignored_surface_ids.contains(&face_id) {
                return Ok(false);
            }
            let Some(surface) = model_surfaces.unique(face_id) else {
                return Ok(false);
            };
            let geometry = source_carriers.surface_geometry(surface);
            // A path whose endpoint evaluates to a non-finite point is
            // evaluable; only an endpoint with no value is not.
            let mut evaluable = true;
            for uv in endpoints {
                match cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, geometry, uv[0], uv[1]),
                )? {
                    Err(cadmpeg_ir::eval::EvaluationFailure::ResourceLimit(limit)) => {
                        return Err(limit.into())
                    }
                    Err(
                        cadmpeg_ir::eval::EvaluationFailure::NoValue
                        | cadmpeg_ir::eval::EvaluationFailure::WorkExhausted,
                    ) => {
                        evaluable = false;
                        break;
                    }
                    Ok(_) | Err(cadmpeg_ir::eval::EvaluationFailure::NonFinite(_)) => {}
                }
            }
            if evaluable {
                match evaluable_path_counts.entry(curve_id) {
                    std::collections::btree_map::Entry::Occupied(mut entry) => {
                        *entry.get_mut() += 1;
                    }
                    std::collections::btree_map::Entry::Vacant(entry) => {
                        entry.insert(1);
                    }
                }
            }
            if let Some(carrier) = linear_pcurve_carrier(ctx, geometry, endpoints)? {
                if let Some((samples, face_index)) = sampled {
                    let agreement = sampled_pcurve_carrier_matches(
                        ctx, geometry, &carrier, samples, face_index,
                    )?;
                    if agreement == SampledCarrierMatch::Disagrees {
                        return Ok(true);
                    }
                    let reason = match agreement {
                        SampledCarrierMatch::Agrees => "agrees with its analytic candidate",
                        SampledCarrierMatch::Disagrees => {
                            "has samples outside its analytic candidate"
                        }
                        SampledCarrierMatch::Unevaluable => {
                            "has samples that cannot be evaluated on its surface"
                        }
                    };
                    if let Some(code) = agreement.loss_code() {
                        losses.push(code.note(format!(
                            "Curve {curve_id} chart on face {face_id} {reason}; its sampled path remains native"
                        )));
                        return Ok(false);
                    }
                }
                match candidates.entry(curve_id) {
                    std::collections::btree_map::Entry::Occupied(mut entry) => {
                        entry.get_mut().push((carrier, offset));
                    }
                    std::collections::btree_map::Entry::Vacant(entry) => {
                        let values = vec![(carrier, offset)];
                        entry.insert(values);
                    }
                }
            }
            Ok(false)
        };
        for pcurve in &scan.curves.pcurves {
            let endpoint_sets = canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            );
            for (face_id, endpoints) in pcurve.faces.into_iter().zip(endpoint_sets) {
                retain_path(pcurve.curve_id, face_id, endpoints, pcurve.offset, None)?;
            }
        }
        for pcurve in &scan.curves.bound_prototype_pcurves {
            let endpoint_sets = canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            );
            for (face_id, endpoints) in pcurve.faces.into_iter().zip(endpoint_sets) {
                retain_path(pcurve.curve_id, face_id, endpoints, pcurve.offset, None)?;
            }
        }
        for pcurve in &scan.curves.two_chart_pcurves {
            let faces = pcurve.faces.map(NonZeroU32::new);
            let Some(endpoint_sets) = mapped_two_chart_endpoint_sets(
                ctx,
                scan,
                &model_surfaces,
                pcurve,
                source_carriers,
            )?
            else {
                continue;
            };
            for (face_index, (face_id, endpoints)) in
                faces.into_iter().zip(endpoint_sets.paths()).enumerate()
            {
                if let Some(endpoints) = endpoints {
                    let curved = retain_path(
                        pcurve.curve_id,
                        face_id,
                        endpoints,
                        pcurve.offset,
                        Some((pcurve, face_index)),
                    )?;
                    if let (true, Some(face_id)) = (curved, face_id) {
                        curved_paths.push((pcurve.curve_id, face_id.get(), pcurve, face_index));
                    }
                }
            }
        }
        for pcurve in crate::curve::fc02_short_pcurve_endpoints(
            &scan.curves.parameters,
            &scan.curves.topology_rows,
        ) {
            let faces = pcurve.faces.map(NonZeroU32::new);
            let [face_0_endpoints, _] = canonicalized_pcurve_endpoints(
                scan,
                faces,
                pcurve.face_0_endpoints,
                pcurve.face_0_endpoints,
            );
            retain_path(
                pcurve.curve_id,
                faces[0],
                face_0_endpoints,
                pcurve.offset,
                None,
            )?;
        }
        for (curve_id, face_id, samples, face_index) in curved_paths {
            let other_carrier = candidates
                .get(&curve_id)
                .and_then(|values| values.first())
                .map(|(carrier, _)| carrier.clone());
            if let (Some(carrier), Some(surface)) = (other_carrier, model_surfaces.unique(face_id))
            {
                let geometry = source_carriers.surface_geometry(surface);
                if sampled_pcurve_carrier_matches(ctx, geometry, &carrier, samples, face_index)?
                    == SampledCarrierMatch::Agrees
                {
                    if let Some(values) = candidates.get_mut(&curve_id) {
                        values.push((carrier, samples.offset));
                    }
                    continue;
                }
            }
            losses.push(crate::loss::CreoLossCode::SampledPcurveCarrierUnresolved.note(format!(
                "Curve {curve_id} chart on face {face_id} has samples outside its analytic candidate; its sampled path remains native"
            )));
        }
    }
    let mut cap_ruling_ids = BTreeSet::new();
    if !scan.surfaces.withheld_cap_curve_ids.is_empty() {
        let surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
        for pcurve in
            crate::identity::uniquely_identified_rows(&scan.curves.two_chart_pcurves, |row| {
                row.curve_id
            })
        {
            let Some((geometry, _)) =
                cap_adjacent_cylinder_ruling(ctx, scan, &surfaces, pcurve, source_carriers)?
            else {
                continue;
            };
            if candidates.contains_key(&pcurve.curve_id) {
                continue;
            }
            candidates.insert(pcurve.curve_id, vec![(geometry, pcurve.offset)]);
            evaluable_path_counts.insert(pcurve.curve_id, 1);
            cap_ruling_ids.insert(pcurve.curve_id);
        }
    }
    let mut transferred = BTreeSet::new();
    for (curve_id, candidates) in candidates {
        if evaluable_path_counts.get(&curve_id).copied() != Some(candidates.len()) {
            continue;
        }
        let points = reconciled_endpoints.get(&curve_id).copied();
        if points.is_none() && !cap_ruling_ids.contains(&curve_id) {
            continue;
        }
        let Some((geometry, offset)) = candidates.first() else {
            continue;
        };
        if points.is_some_and(|points| !curve_contains_points(geometry, points)) {
            continue;
        }
        let mut compatible = true;
        for (candidate, _) in &candidates {
            if points.is_some_and(|points| !curve_contains_points(candidate, points)) {
                compatible = false;
                break;
            }
            for parameter in [0.0, 0.25, 0.5, 0.75, 1.0] {
                let point =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::curve_point(ctx, candidate, parameter),
                    )?)?;
                if !point.is_some_and(|point| {
                    curve_contains_points(geometry, [[point.x, point.y, point.z]; 2])
                }) {
                    compatible = false;
                    break;
                }
            }
            if !compatible {
                break;
            }
        }
        if !compatible {
            continue;
        }
        let offset = candidates
            .iter()
            .map(|(_, offset)| *offset)
            .min()
            .unwrap_or(*offset);
        let id = crate::identity::compose_checked::<CurveId>(
            &crate::identity::VISIBGEOM_CURVE,
            curve_id,
        )?;
        if ir.geometry.curves.iter().any(|curve| curve.id == id) {
            continue;
        }
        annotate(
            annotations,
            &id,
            "VisibGeom",
            cadmpeg_core::decode::u64_from_index(offset),
            "analytic_pcurve_carrier",
            Exactness::Derived,
        )?;
        ctx.charge_entities(1, "admit Creo model curves")?;
        source_carriers.admit_curve(
            ctx,
            ir,
            Curve {
                parameter_range: None,
                id: id.clone(),
                geometry: geometry.clone(),
                source_object: Some(SourceObjectAssociation {
                    geometry_role: None,
                    format: cadmpeg_ir::CodecFormat::Creo,
                    object_id: crate::identity::source_object_id_checked(format_args!(
                        "VisibGeom:{curve_id}"
                    ))?,
                    name: None,
                    color: None,
                    visible: None,
                    layer: None,
                    instance_path: Vec::new(),
                }),
                native_ref: None,
            },
        )?;
        transferred.insert(id);
    }
    transferred.extend(crate::decode::sweep::surfaces::transfer_hole_generators(
        ctx,
        scan,
        ir,
        annotations,
        losses,
        source_carriers,
        &reconciled_endpoints,
    )?);
    for record in scan
        .curves
        .parameters
        .iter()
        .filter(|record| record.count_framed)
    {
        let id = crate::identity::compose_checked::<CurveId>(
            &crate::identity::VISIBGEOM_CURVE,
            record.curve_id,
        )?;
        if transferred.contains(&id) {
            losses.push(
                crate::loss::CreoLossCode::CountFramedCurveCarrierUnverified.note(format!(
                    "Curve {} at byte {} has a row that only a sample count frames; its carrier \
                     takes its placement from its incident surface charts alone",
                    record.curve_id, record.offset
                )),
            );
        }
    }
    Ok(transferred)
}

type PcurveVertexConstraint = ([u32; 2], [[f64; 3]; 2]);

pub(in crate::decode) fn directed_pcurve_points(
    directions: [u8; 2],
    points: [[f64; 3]; 2],
) -> Option<[[f64; 3]; 2]> {
    match directions {
        [0x01, 0xf6] => Some(points),
        [0xf6, 0x01] => Some([points[1], points[0]]),
        _ => None,
    }
}

#[cfg(test)]
pub(in crate::decode) fn solve_pcurve_vertex_domains(
    constraints: &[PcurveVertexConstraint],
    fixed_points: &BTreeMap<u32, [f64; 3]>,
    analytic_domains: &BTreeMap<u32, Vec<[f64; 3]>>,
    incident_curves: &BTreeMap<u32, Vec<&CurveGeometry>>,
) -> BTreeMap<u32, [f64; 3]> {
    solve_pcurve_vertex_domains_with_authoritative_points(
        constraints,
        fixed_points,
        analytic_domains,
        incident_curves,
        &BTreeMap::new(),
    )
}

/// Solve endpoint domains while preserving exact native one-sided witnesses.
///
/// An authoritative point is emitted only by a parser for a complete native
/// grammar. Such a point is still checked against fixed carrier solutions and
/// other pcurve constraints by the caller, but an inferred analytic
/// intersection or carrier curve must not erase it merely because that
/// inferred geometry is inconsistent.
pub(super) fn solve_pcurve_vertex_domains_with_authoritative_points(
    constraints: &[PcurveVertexConstraint],
    fixed_points: &BTreeMap<u32, [f64; 3]>,
    analytic_domains: &BTreeMap<u32, Vec<[f64; 3]>>,
    incident_curves: &BTreeMap<u32, Vec<&CurveGeometry>>,
    authoritative_points: &BTreeMap<u32, [f64; 3]>,
) -> BTreeMap<u32, [f64; 3]> {
    // A point outside the finite range agrees with no point.
    let agree = |first: [f64; 3], second: [f64; 3]| {
        finite_model_point(first)
            .zip(finite_model_point(second))
            .is_some_and(|(first, second)| model_points_agree(first, second))
    };
    let mut domains = BTreeMap::<u32, Vec<[f64; 3]>>::new();
    for (vertices, points) in constraints {
        if vertices[0] == vertices[1] {
            match domains.entry(vertices[0]) {
                std::collections::btree_map::Entry::Vacant(entry) => {
                    let mut domain = Vec::new();
                    if agree(points[0], points[1]) {
                        domain.push(points[0]);
                    }
                    entry.insert(domain);
                }
                std::collections::btree_map::Entry::Occupied(mut entry) => {
                    let domain = entry.get_mut();
                    if agree(points[0], points[1]) {
                        domain.retain(|candidate| agree(*candidate, points[0]));
                    } else {
                        domain.clear();
                    }
                }
            }
            continue;
        }
        for vertex in vertices {
            let domain = match domains.entry(*vertex) {
                std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
                std::collections::btree_map::Entry::Vacant(entry) => {
                    let mut domain = Vec::new();
                    domain.extend_from_slice(points);
                    entry.insert(domain)
                }
            };
            domain.retain(|candidate| points.iter().any(|point| agree(*candidate, *point)));
        }
    }
    for (vertex, candidates) in analytic_domains {
        if authoritative_points.contains_key(vertex) {
            continue;
        }
        match domains.entry(*vertex) {
            std::collections::btree_map::Entry::Vacant(entry) => {
                let mut domain = Vec::new();
                domain.extend_from_slice(candidates);
                entry.insert(domain);
            }
            std::collections::btree_map::Entry::Occupied(mut entry) => {
                entry
                    .get_mut()
                    .retain(|point| candidates.iter().any(|candidate| agree(*point, *candidate)));
            }
        }
    }
    for (vertex, point) in fixed_points {
        match domains.entry(*vertex) {
            std::collections::btree_map::Entry::Vacant(entry) => {
                let domain = vec![*point];
                entry.insert(domain);
            }
            std::collections::btree_map::Entry::Occupied(mut entry) => {
                entry
                    .get_mut()
                    .retain(|candidate| agree(*candidate, *point));
            }
        }
    }
    for (vertex, curves) in incident_curves {
        if authoritative_points.contains_key(vertex) {
            continue;
        }
        if let Some(domain) = domains.get_mut(vertex) {
            domain.retain(|candidate| {
                curves
                    .iter()
                    .all(|curve| curve_contains_points(curve, [*candidate, *candidate]))
            });
        }
    }
    let compatible = |first: [f64; 3], second: [f64; 3], points: [[f64; 3]; 2]| {
        (agree(first, points[0]) && agree(second, points[1]))
            || (agree(first, points[1]) && agree(second, points[0]))
    };
    loop {
        let mut changed = false;
        for (vertices, points) in constraints {
            if vertices[0] == vertices[1] {
                continue;
            }
            let (retained_first, retained_second, first_len, second_len) = {
                let first = domains.get(&vertices[0]).map_or(&[][..], Vec::as_slice);
                let second = domains.get(&vertices[1]).map_or(&[][..], Vec::as_slice);
                let mut retained_first = Vec::new();
                for candidate in first {
                    if second
                        .iter()
                        .any(|other| compatible(*candidate, *other, *points))
                    {
                        retained_first.push(*candidate);
                    }
                }
                let mut retained_second = Vec::new();
                for candidate in second {
                    if first
                        .iter()
                        .any(|other| compatible(*other, *candidate, *points))
                    {
                        retained_second.push(*candidate);
                    }
                }
                (retained_first, retained_second, first.len(), second.len())
            };
            changed |= retained_first.len() != first_len || retained_second.len() != second_len;
            domains.insert(vertices[0], retained_first);
            domains.insert(vertices[1], retained_second);
        }
        if !changed {
            break;
        }
    }
    let mut solved = BTreeMap::new();
    for (vertex, mut domain) in domains {
        domain.dedup_by(|first, second| agree(*first, *second));
        let [point] = domain.as_slice() else {
            continue;
        };
        solved.insert(vertex, *point);
    }
    solved
}

pub(super) fn native_pcurve_midpoint(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    endpoints: [[f64; 2]; 2],
    edge_points: [[f64; 3]; 2],
) -> Result<Option<[f64; 3]>, cadmpeg_core::CodecError> {
    // A point outside the finite range, mapped or on the edge, aligns with
    // no point.
    let [first, second] = endpoints.map(|uv| {
        cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
            ctx, surface, uv[0], uv[1],
        ))
    });
    let ([Some(first), Some(second)], [Some(start), Some(end)]) = (
        [
            cadmpeg_ir::eval::finite_or_refusal(first?)?,
            cadmpeg_ir::eval::finite_or_refusal(second?)?,
        ],
        edge_points.map(finite_model_point),
    ) else {
        return Ok(None);
    };
    require_some!(point_pair_alignments([first, second], [start, end])
        .into_iter()
        .any(|matches| matches)
        .then_some(()));
    // A midpoint outside the finite range is returned as the evaluation
    // reached it.
    let point =
        match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
            ctx,
            surface,
            f64::midpoint(endpoints[0][0], endpoints[1][0]),
            f64::midpoint(endpoints[0][1], endpoints[1][1]),
        ))? {
            Ok(point) => point.get(),
            Err(failure) => require_some!(failure.non_finite()?),
        };
    Ok(Some(<[f64; 3]>::from(point)))
}

pub(in crate::decode) type NativePcurveCandidates =
    BTreeMap<(u32, u32), Vec<([[f64; 2]; 2], usize)>>;

pub(in crate::decode) fn bounded_cylinder_circle_parameter_range(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan<'_>,
    geometry: &mut CurveGeometry,
    faces: [u32; 2],
    surfaces: &[Surface],
    points: [[f64; 3]; 2],
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<Option<[f64; 2]>, cadmpeg_core::CodecError> {
    if !matches!(geometry.solved(), Some(SolvedCurveGeometry::Circle(_)))
        || !curve_contains_points(geometry, points)
    {
        return Ok(None);
    }
    let mut selected: Option<[f64; 2]> = None;
    for face in faces {
        let Some(record) =
            crate::surface::unique_surface_parameter(&scan.surfaces.parameters, face)
        else {
            continue;
        };
        if record.kind() != crate::surface::SurfaceKind::Cylinder {
            continue;
        }
        let Some(surface) = unique_model_surface(surfaces, face)
            .map(|surface| source_carriers.surface_geometry(surface))
        else {
            continue;
        };
        let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder)) = surface else {
            continue;
        };
        if super::pcurve_geometry::surface_of_revolution_parallel_pcurve(surface, geometry)
            .is_none()
        {
            continue;
        }
        let origin = <[f64; 3]>::from(cylinder.origin().get());
        let axis = <[f64; 3]>::from(*cylinder.frame().axis().as_raw());
        let u = <[f64; 3]>::from(*cylinder.frame().reference().as_raw());
        let v = cross(axis, u);
        let radius = cylinder.radius().get();
        let Some(frame) =
            crate::surface::PositionalCylinderFrame::new(origin, axis, u, radius, None)
        else {
            continue;
        };
        let Some([angular, axial]) =
            crate::surface::cylinder_frame_readers::rotation_cylinder_parameter_bounds(
                &record.body,
                frame,
            )
        else {
            continue;
        };
        let scale = points
            .into_iter()
            .flatten()
            .chain(origin)
            .map(f64::abs)
            .fold(radius.max(1.0), f64::max);
        let tolerance = EPS_AGREE * scale;
        let parameter = |point: [f64; 3]| -> Option<[f64; 2]> {
            let relative = std::array::from_fn(|i| point[i] - origin[i]);
            let theta = dot(relative, v).atan2(dot(relative, u));
            let height = dot(relative, axis);
            (theta >= angular[0] - EPS_ORTHO
                && theta <= angular[1] + EPS_ORTHO
                && height >= axial[0].min(axial[1]) - tolerance
                && height <= axial[0].max(axial[1]) + tolerance)
                .then_some([theta.clamp(angular[0], angular[1]), height])
        };
        let [Some(first), Some(second)] = points.map(parameter) else {
            return Ok(None);
        };
        if (first[1] - second[1]).abs() > tolerance {
            return Ok(None);
        }
        let angle = f64::midpoint(first[0], second[0]);
        let height = f64::midpoint(first[1], second[1]);
        let interior = std::array::from_fn(|i| {
            origin[i] + radius * (u[i] * angle.cos() + v[i] * angle.sin()) + axis[i] * height
        });
        let Some(candidate) = periodic_conic_edge_parameter_range(ctx, geometry, points, interior)?
        else {
            return Ok(None);
        };
        let first = require_some!(cadmpeg_ir::eval::finite_or_refusal(
            cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::curve_point(
                ctx,
                geometry,
                candidate[0],
            ))?
        )?);
        let first = require_some!(finite_model_point([first.x, first.y, first.z]));
        let [Some(start), Some(end)] = points.map(finite_model_point) else {
            return Ok(None);
        };
        let candidate = match [
            model_points_agree(first, start),
            model_points_agree(first, end),
        ] {
            [true, false] => candidate,
            [false, true] => [candidate[1], candidate[0]],
            _ => return Ok(None),
        };
        if selected.is_some_and(|selected| {
            selected
                .into_iter()
                .zip(candidate)
                .any(|(a, b)| (a - b).abs() > EPS_AGREE)
        }) {
            return Ok(None);
        }
        selected = Some(candidate);
    }
    if let Some([first, second]) = selected {
        let Some(SolvedCurveGeometry::Circle(circle)) = geometry.solved() else {
            return Ok(None);
        };
        let center = <[f64; 3]>::from(circle.center().get());
        let axis = <[f64; 3]>::from(*circle.frame().axis().as_raw());
        let direction = if second > first { 1.0 } else { -1.0 };
        let Some(reference) = normalize(std::array::from_fn(|i| points[0][i] - center[i])) else {
            return Ok(None);
        };
        let Ok(oriented) = cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
            circle.center().get(),
            Vector3::from(axis.map(|value| direction * value)),
            Vector3::from(reference),
            circle.radius().get(),
        ) else {
            return Ok(None);
        };
        *geometry = CurveGeometry::Solved(SolvedCurveGeometry::Circle(oriented));
        return Ok(Some([0.0, (second - first).abs()]));
    }
    Ok(selected)
}

pub(in crate::decode) fn pcurve_backed_periodic_conic_parameter_range(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    geometry: &mut CurveGeometry,
    incidence: (u32, [u32; 2]),
    candidates: &NativePcurveCandidates,
    surfaces: &[Surface],
    points: [[f64; 3]; 2],
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> Result<Option<[f64; 2]>, cadmpeg_core::CodecError> {
    let (curve_id, faces) = incidence;

    let mut selected = None;
    for face_id in faces {
        let Some(surface) = unique_model_surface(surfaces, face_id)
            .map(|surface| source_carriers.surface_geometry(surface))
        else {
            continue;
        };
        for (endpoints, _) in candidates.get(&(curve_id, face_id)).into_iter().flatten() {
            let Some(interior) = native_pcurve_midpoint(ctx, surface, *endpoints, points)? else {
                continue;
            };
            let candidate = require_some!(periodic_conic_edge_parameter_range(
                ctx, geometry, points, interior
            )?);
            if selected.is_some_and(|selected: [f64; 2]| {
                candidate
                    .into_iter()
                    .zip(selected)
                    .any(|(candidate, selected)| (candidate - selected).abs() > EPS_AGREE)
            }) {
                return Ok(None);
            }
            selected = Some(candidate);
        }
    }
    let Some(selected) = selected else {
        return Ok(None);
    };
    orient_periodic_conic_edge_carrier(ctx, geometry, selected, points)
}

fn oriented_native_pcurve_endpoints(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    endpoints: [[f64; 2]; 2],
    traversal: [[f64; 3]; 2],
) -> Result<Option<[[f64; 2]; 2]>, cadmpeg_core::CodecError> {
    // A point outside the finite range, mapped or traversed, aligns with no
    // point.
    let [first, second] = endpoints.map(|uv| {
        cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
            ctx, surface, uv[0], uv[1],
        ))
    });
    let mapped = [
        cadmpeg_ir::eval::finite_or_refusal(first?)?,
        cadmpeg_ir::eval::finite_or_refusal(second?)?,
    ];
    let ([Some(first), Some(second)], [Some(start), Some(end)]) =
        (mapped, traversal.map(finite_model_point))
    else {
        return Ok(None);
    };
    Ok(match point_pair_alignments([first, second], [start, end]) {
        [true, false] => Some(endpoints),
        [false, true] => Some([endpoints[1], endpoints[0]]),
        _ => None,
    })
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub(in crate::decode) struct OrientedNativePcurve {
    pub(in crate::decode) endpoints: [[f64; 2]; 2],
    pub(in crate::decode) offset: usize,
}

pub(in crate::decode) fn unique_oriented_native_pcurve(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    candidates: &[([[f64; 2]; 2], usize)],
    traversal: [[f64; 3]; 2],
) -> Result<Option<OrientedNativePcurve>, cadmpeg_core::CodecError> {
    let mut selected: Option<OrientedNativePcurve> = None;
    for (endpoints, offset) in candidates {
        let Some(oriented) = oriented_native_pcurve_endpoints(ctx, surface, *endpoints, traversal)?
        else {
            continue;
        };
        if let Some(previous) = selected.as_mut() {
            if oriented != previous.endpoints {
                return Ok(None);
            }
            previous.offset = previous.offset.min(*offset);
        } else {
            selected = Some(OrientedNativePcurve {
                endpoints: oriented,
                offset: *offset,
            });
        }
    }
    Ok(selected)
}

pub(in crate::decode) fn planar_curve_pcurve(
    surface: &SurfaceGeometry,
    geometry: &CurveGeometry,
    record: &dyn std::fmt::Display,
    refusal: &mut crate::lane_refusal::LaneRefusals,
) -> Option<PcurveGeometry> {
    (|| -> Option<PcurveGeometry> {
        let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)) = surface else {
            return None;
        };
        let origin = plane_surface.origin().get();
        let origin = [origin.x, origin.y, origin.z];
        let normal = unit_length(*plane_surface.frame().axis());
        let u_axis = unit_length(*plane_surface.frame().reference());
        (dot(normal, u_axis).abs() <= EPS_ORTHO).then_some(())?;
        let v_axis = normalize(cross(normal, u_axis))?;
        let project_point = |point: [f64; 3], tolerance: f64| {
            let relative: [f64; 3] = std::array::from_fn(|index| point[index] - origin[index]);
            (dot(relative, normal).abs() <= tolerance)
                .then_some(Point2::new(dot(relative, u_axis), dot(relative, v_axis)))
        };
        let project_direction = |direction: [f64; 3]| {
            let length = dot(direction, direction).sqrt();
            (length.is_finite()
                && length > 0.0
                && dot(direction, normal).abs() <= EPS_ORTHO * length)
                .then_some(Point2::new(dot(direction, u_axis), dot(direction, v_axis)))
        };
        let conic_frame = |center: [f64; 3], frame: &OrthonormalFrame3, scale: f64| {
            let axis = unit_length(*frame.axis());
            let x_axis = unit_length(*frame.reference());
            ((dot(axis, normal).abs() - 1.0).abs() <= EPS_ORTHO
                && dot(axis, x_axis).abs() <= EPS_ORTHO)
                .then_some(())?;
            let y_axis = normalize(cross(axis, x_axis))?;
            Some((
                project_point(center, EPS_AGREE * scale.max(1.0))?,
                project_direction(x_axis)?,
                project_direction(y_axis)?,
            ))
        };

        match geometry {
            CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve)) => {
                let origin = line_curve.origin().get();
                let direction = *line_curve.direction().as_raw();
                let direction = [direction.x, direction.y, direction.z];
                Some(PcurveGeometry::Line(
                    cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                        project_point([origin.x, origin.y, origin.z], EPS_AGREE)?,
                        project_direction(direction)?,
                    )
                    .ok()?,
                ))
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)) => {
                let center = circle_curve.center().get();
                let radius = circle_curve.radius().get();
                let (center, x_axis, y_axis) =
                    conic_frame([center.x, center.y, center.z], circle_curve.frame(), radius)?;
                Some(PcurveGeometry::Circle(
                    cadmpeg_ir::geometry::pcurve::CirclePcurve::try_new(
                        center, x_axis, y_axis, radius,
                    )
                    .ok()?,
                ))
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Ellipse(ellipse_curve)) => {
                let center = ellipse_curve.center().get();
                let major_radius = ellipse_curve.major_radius().get();
                let minor_radius = ellipse_curve.minor_radius().get();
                let (center, x_axis, y_axis) = conic_frame(
                    [center.x, center.y, center.z],
                    ellipse_curve.frame(),
                    major_radius.max(minor_radius),
                )?;
                Some(PcurveGeometry::Ellipse(
                    cadmpeg_ir::geometry::pcurve::EllipsePcurve::try_new(
                        center,
                        x_axis,
                        y_axis,
                        major_radius,
                        minor_radius,
                    )
                    .ok()?,
                ))
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Parabola(parabola_curve)) => {
                let vertex = parabola_curve.vertex().get();
                let focal_distance = parabola_curve.focal_distance().get();
                let (vertex, x_axis, y_axis) = conic_frame(
                    [vertex.x, vertex.y, vertex.z],
                    parabola_curve.frame(),
                    focal_distance,
                )?;
                Some(PcurveGeometry::Parabola(
                    cadmpeg_ir::geometry::pcurve::ParabolaPcurve::try_new(
                        vertex,
                        x_axis,
                        y_axis,
                        focal_distance,
                    )
                    .ok()?,
                ))
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Hyperbola(hyperbola_curve)) => {
                let center = hyperbola_curve.center().get();
                let major_radius = hyperbola_curve.major_radius().get();
                let minor_radius = hyperbola_curve.minor_radius().get();
                let (center, x_axis, y_axis) = conic_frame(
                    [center.x, center.y, center.z],
                    hyperbola_curve.frame(),
                    major_radius.max(minor_radius),
                )?;
                Some(PcurveGeometry::Hyperbola(
                    cadmpeg_ir::geometry::pcurve::HyperbolaPcurve::try_new(
                        center,
                        x_axis,
                        y_axis,
                        major_radius,
                        minor_radius,
                    )
                    .ok()?,
                ))
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs)) => {
                nurbs_intrinsic_parameter_range(nurbs)?;
                let tolerance = EPS_AGREE * nurbs_control_extent(nurbs);
                let poles = match nurbs.pole_rows() {
                    cadmpeg_ir::geometry::nurbs::NurbsPoles3::Polynomial { points } => {
                        let mut projected = Vec::new();
                        for point in points {
                            let point = point.get();
                            let projected_point =
                                project_point([point.x, point.y, point.z], tolerance)?;
                            let Some(projected_point) =
                                cadmpeg_ir::units::FinitePoint2::new(projected_point)
                            else {
                                refusal.note(
                                    format_args!("creo planar-curve pcurve record for {record}"),
                                    &cadmpeg_ir::geometry::nurbs::NurbsError::Structure(
                                        "control_points contains a non-finite point".to_owned(),
                                    ),
                                );
                                return None;
                            };
                            projected.push(projected_point);
                        }
                        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial {
                            points: projected,
                        }
                    }
                    cadmpeg_ir::geometry::nurbs::NurbsPoles3::Rational { points } => {
                        let mut projected = Vec::new();
                        for pole in points {
                            let point = pole.point.get();
                            let projected_point =
                                project_point([point.x, point.y, point.z], tolerance)?;
                            let Some(projected_point) =
                                cadmpeg_ir::units::FinitePoint2::new(projected_point)
                            else {
                                refusal.note(
                                    format_args!("creo planar-curve pcurve record for {record}"),
                                    &cadmpeg_ir::geometry::nurbs::NurbsError::Structure(
                                        "control_points contains a non-finite point".to_owned(),
                                    ),
                                );
                                return None;
                            };
                            projected.push(cadmpeg_ir::geometry::pcurve::WeightedPole2 {
                                point: projected_point,
                                weight: pole.weight,
                            });
                        }
                        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Rational {
                            points: projected,
                        }
                    }
                };
                let knots = nurbs.knots().clone();
                match PcurveNurbs::new(nurbs.degree(), knots, poles, nurbs.periodic()) {
                    Ok(nurbs) => Some(PcurveGeometry::Nurbs { nurbs }),
                    Err(error) => {
                        refusal.note(
                            format_args!("creo planar-curve pcurve record for {record}"),
                            &error,
                        );
                        None
                    }
                }
            }
            _ => None,
        }
    })()
}

#[cfg(test)]
mod native_tests;
#[cfg(test)]
mod withheld_chart_tests;

#[cfg(test)]
mod tests {
    use super::super::equations::{CarrierEquation, PlaneEquation};
    use super::{
        map_two_chart_endpoint_sets, mapped_pcurve_endpoints, mapped_two_chart_endpoint_sets,
        mirrored_support_apex_cone, pcurve_edge_endpoint_evidence_with_carriers,
        pcurve_edge_endpoint_evidence_with_diagnostics, pcurve_mismatch_detail,
        pcurve_plane_carrier_status, point_coordinate_error, support_cone_witness_matches,
        topology_ignored_surface_ids, transfer_analytic_pcurve_carriers, unique_model_surface,
        MappedPcurvePath, ModelSurfaceIndex, PcurveCarrierStatus, PcurveCarrierUnknownReason,
        TwoChartEndpointSets, TwoChartMapping,
    };
    use cadmpeg_ir::document::CadIr;
    use cadmpeg_ir::geometry::nurbs::NurbsSurface;
    use cadmpeg_ir::geometry::{
        CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, Surface, SurfaceGeometry,
    };
    use cadmpeg_ir::ids::{CurveId, SurfaceId};
    use cadmpeg_ir::math::{Point3, Vector3};
    use std::collections::BTreeMap;
    use std::collections::BTreeSet;

    #[test]
    fn legacy_spline_topology_filter_is_layout_scoped() {
        let rows = vec![
            crate::surface::SurfaceRow {
                id: 7,
                kind: crate::surface::SurfaceKind::Spline,
                feature_id: 0,
                reversed: false,
                boundary_type: crate::surface::BoundaryType::Code00,
                next_surface: 0,
                offset: 0,
            },
            crate::surface::SurfaceRow {
                id: 8,
                kind: crate::surface::SurfaceKind::Plane,
                feature_id: 0,
                reversed: false,
                boundary_type: crate::surface::BoundaryType::Code00,
                next_surface: 0,
                offset: 0,
            },
        ];

        let mut scan = crate::test_support::empty_container_scan();
        scan.framing.layout = crate::test_support::legacy_layout();
        scan.surfaces.rows = rows;
        assert_eq!(topology_ignored_surface_ids(&scan), BTreeSet::from([7]),);
        scan.framing.layout = crate::container::Layout::Nd;
        assert!(topology_ignored_surface_ids(&scan).is_empty());
    }

    fn one_plane_pcurve_fixture() -> (crate::container::ContainerScan<'static>, CadIr) {
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves.pcurves.push(crate::curve::PcurveEndpoints {
            curve_id: 7,
            faces: [std::num::NonZeroU32::new(10), None],
            face_0_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            face_1_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            offset: 0,
        });
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint("creo:visibgeom:surface#10".to_string()).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
        (scan, ir)
    }

    #[test]
    fn unresolved_plane_chart_keeps_envelope_geometry_out_of_endpoint_evidence() {
        let (mut scan, ir) = one_plane_pcurve_fixture();
        let carriers = crate::decode::source_carriers::SourceUnitCarriers::default();
        let before = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(ctx, &scan, &ir, &carriers)
        })
        .expect("map complete chart");
        assert!(before.0.contains_key(&7));
        scan.planes
            .local_systems
            .push(crate::surface::PlaneLocalSystem {
                surface_id: 10,
                body: vec![0],
                slots: [None; 12],
                layout: None,
                classification: crate::surface::LocalSystemClassification::Unclassified,
                row_offset: 0,
                offset: 0,
            });
        assert_eq!(topology_ignored_surface_ids(&scan), BTreeSet::from([10]));
        let losses = super::unresolved_pcurve_chart_losses(&scan);
        assert_eq!(losses.len(), 1);
        assert_eq!(
            losses[0].code,
            crate::loss::CreoLossCode::PcurveChartUnresolved.kind()
        );
        let after = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(ctx, &scan, &ir, &carriers)
        })
        .expect("retain unresolved chart");
        assert!(after.0.is_empty());
        let samples = crate::curve::TwoChartPcurveSamples {
            curve_id: 7,
            faces: [10, 11],
            samples: vec![[[1.0, 2.0]; 2], [[3.0, 4.0]; 2]],
            offset: 0,
        };
        let mapped = crate::decode::with_service_context(|ctx| {
            mapped_two_chart_endpoint_sets(
                ctx,
                &scan,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                &samples,
                &carriers,
            )
        })
        .expect("retain unresolved sampled chart");
        assert!(mapped.is_none());
        assert_eq!(ir.geometry.surfaces.len(), 1);
    }

    #[test]
    fn support_cone_witness_preserves_service_result() {
        let planes = BTreeMap::from([(
            2,
            PlaneEquation {
                origin: [0.0, 0.0, 0.0],
                normal: [0.0, 0.0, 1.0],
            },
        )]);
        let mut witnesses = BTreeMap::new();
        super::collect_support_cone_plane_witness(
            &mut witnesses,
            &planes,
            [std::num::NonZeroU32::new(1), std::num::NonZeroU32::new(2)],
            [Some([[1.0, 2.0], [3.0, 4.0]]), None],
        );
        let witness = witnesses.get(&1).expect("face witness");
        assert_eq!(witness.len(), 1);
        assert_eq!(witness[0].0, [[1.0, 2.0], [3.0, 4.0]]);
        assert_eq!(witness[0].1.origin, planes[&2].origin);
        assert_eq!(witness[0].1.normal, planes[&2].normal);
    }

    #[test]
    fn pcurve_evidence_preserves_one_plane_path() {
        let (scan, ir) = one_plane_pcurve_fixture();
        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_carriers(
                ctx,
                &scan,
                &ir,
                &BTreeMap::new(),
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(
            evidence.get(&7).map(|entry| entry.points),
            Some([[1.0, 2.0, 0.0], [3.0, 4.0, 0.0]])
        );
        assert_eq!(diagnostics.accepted_records, 1);
    }

    #[test]
    fn sampled_pcurve_carrier_requires_every_stored_point() {
        let (mut scan, mut ir) = one_plane_pcurve_fixture();
        scan.curves.pcurves.clear();
        scan.curves
            .two_chart_pcurves
            .push(crate::curve::TwoChartPcurveSamples {
                curve_id: 7,
                faces: [10, 11],
                samples: vec![[[0.0, 0.0]; 2], [[1.0, 1.0]; 2], [[2.0, 0.0]; 2]],
                offset: 0,
            });
        let mut annotations = cadmpeg_ir::AnnotationBuilder::new();
        let mut source_carriers = crate::decode::source_carriers::SourceUnitCarriers::default();
        let mut losses = Vec::new();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut losses,
                &mut source_carriers,
            )
        })
        .expect("inspect every sampled point");
        assert!(transferred.is_empty());
        assert!(ir.geometry.curves.is_empty());
        assert_eq!(scan.curves.two_chart_pcurves[0].samples.len(), 3);
        assert_eq!(losses.len(), 1);
        assert_eq!(
            losses[0].code,
            crate::loss::CreoLossCode::SampledPcurveCarrierUnresolved.kind()
        );
        scan.curves.two_chart_pcurves[0].samples[1] = [[1.0, 0.0]; 2];
        losses.clear();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut losses,
                &mut source_carriers,
            )
        })
        .expect("admit the agreeing sampled line");
        assert_eq!(transferred.len(), 1);
        assert!(losses.is_empty());
    }

    #[test]
    fn curved_plane_chart_samples_support_the_cylinder_chart_circle() {
        let radius = 2.0;
        let angles = [
            0.0,
            std::f64::consts::FRAC_PI_4,
            std::f64::consts::FRAC_PI_2,
        ];
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .two_chart_pcurves
            .push(crate::curve::TwoChartPcurveSamples {
                curve_id: 7,
                faces: [10, 11],
                samples: angles
                    .map(|angle| [[angle, 0.0], [radius * angle.cos(), radius * angle.sin()]])
                    .to_vec(),
                offset: 0,
            });
        let surface = |id: u32, geometry: SolvedSurfaceGeometry| Surface {
            id: SurfaceId::mint(format!("creo:visibgeom:surface#{id}")).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(geometry),
            source_object: None,
            native_ref: None,
        };
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(surface(
            10,
            SolvedSurfaceGeometry::Cylinder(
                cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                    radius,
                )
                .expect("valid CylinderSurface fixture"),
            ),
        ));
        ir.geometry.surfaces.push(surface(
            11,
            SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            ),
        ));
        let transfer = |ir: &CadIr| {
            let mut ir = ir.clone();
            let mut losses = Vec::new();
            let transferred = crate::decode::with_service_context(|ctx| {
                transfer_analytic_pcurve_carriers(
                    ctx,
                    &scan,
                    &mut ir,
                    &mut cadmpeg_ir::AnnotationBuilder::new(),
                    &mut losses,
                    &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
                )
            })
            .expect("transfer the sampled carriers");
            let sampled_losses = losses
                .iter()
                .filter(|loss| {
                    loss.code == crate::loss::CreoLossCode::SampledPcurveCarrierUnresolved.kind()
                })
                .count();
            (transferred.len(), ir, sampled_losses)
        };

        let (transferred, ir_after, sampled_losses) = transfer(&ir);
        assert_eq!((transferred, sampled_losses), (1, 0));
        assert!(matches!(
            &ir_after.geometry.curves[0].geometry,
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle))
                if circle.radius().get() == radius
        ));

        ir.geometry.surfaces.remove(0);
        let (transferred, _, sampled_losses) = transfer(&ir);
        assert_eq!((transferred, sampled_losses), (0, 1));
    }

    #[test]
    fn sampled_carrier_evaluation_refusal_has_a_distinct_loss() {
        let (_, ir) = one_plane_pcurve_fixture();
        let samples = crate::curve::TwoChartPcurveSamples {
            curve_id: 7,
            faces: [10, 11],
            samples: vec![[[0.0, 0.0]; 2]],
            offset: 0,
        };
        let unknown = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
        let outcome = crate::decode::with_service_context(|ctx| {
            let carrier = super::linear_pcurve_carrier(
                ctx,
                &ir.geometry.surfaces[0].geometry,
                [[0.0, 0.0], [1.0, 0.0]],
            )?
            .expect("line on a plane");
            super::sampled_pcurve_carrier_matches(ctx, &unknown, &carrier, &samples, 0)
        })
        .expect("evaluation refusal retains the samples");
        assert_eq!(outcome, super::SampledCarrierMatch::Unevaluable);
        let loss = outcome
            .loss_code()
            .expect("evaluation refusal loss")
            .note("unevaluable surface");
        assert_eq!(
            loss.code,
            crate::loss::CreoLossCode::SampledPcurveEvaluationUnresolved.kind()
        );
        assert_ne!(
            loss.code,
            crate::loss::CreoLossCode::SampledPcurveCarrierUnresolved.kind()
        );
        assert_eq!(samples.samples.len(), 1);
    }

    #[test]
    fn analytic_pcurve_transfer_preserves_service_curve() {
        let (scan, mut ir) = one_plane_pcurve_fixture();
        let mut annotations = cadmpeg_ir::AnnotationBuilder::new();
        let mut source_carriers = crate::decode::source_carriers::SourceUnitCarriers::default();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut Vec::new(),
                &mut source_carriers,
            )
        })
        .expect("transfer the analytic pcurve carriers");
        assert_eq!(transferred.len(), 1);
        assert_eq!(ir.geometry.curves.len(), 1);
    }

    #[test]
    fn mapped_pcurve_endpoints_reject_duplicate_face_surfaces() {
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.extend([
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#7".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#7".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 1.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
        ]);

        assert!(mapped_pcurve_endpoints(
            &ir,
            [7, 7],
            [[[0.0, 0.0], [1.0, 0.0]], [[0.0, 0.0], [1.0, 0.0]]],
        )
        .expect("evaluator allocation succeeds")
        .is_none());
    }

    #[test]
    fn placed_plane_pcurve_mapping_uses_source_origin() {
        let id = SurfaceId::mint("creo:visibgeom:surface#7").expect("identity grammar");
        let plane = |x| {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(x, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            ))
        };
        let mut source_carriers = crate::decode::source_carriers::SourceUnitCarriers::default();
        source_carriers.record_surface(&Surface {
            id: id.clone(),
            geometry: plane(1.0),
            source_object: None,
            native_ref: None,
        });
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(Surface {
            id,
            geometry: plane(25.4),
            source_object: None,
            native_ref: None,
        });

        let mapped = crate::decode::with_service_context(|ctx| {
            super::map_pcurve_paths(
                ctx,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                [(std::num::NonZeroU32::new(7), [[0.0, 0.0], [1.0, 0.0]])],
                &source_carriers,
            )
        })
        .expect("map the pcurve paths");
        assert_eq!(mapped.missing_surfaces, 0);
        assert_eq!(mapped.unevaluable_paths, 0);
        assert_eq!(mapped.mapped.len(), 1);
        assert_eq!(
            mapped.mapped[0].endpoints,
            [[1.0, 0.0, 0.0], [2.0, 0.0, 0.0]]
        );
    }

    #[test]
    fn two_chart_samples_validate_every_point_and_extend_a_nurbs_boundary_span() {
        let evaluation_arena = cadmpeg_core::decode::DecodeArena::new();
        let evaluation_policy = cadmpeg_core::decode::DecodePolicy::service();
        let (evaluation_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &evaluation_arena,
            &evaluation_policy,
        )
        .expect("evaluation root");

        let scan = crate::test_support::empty_container_scan();
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.extend([
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#7".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                    NurbsSurface::from_lanes(
                        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(
                            1,
                            vec![0.0, 0.0, 1.0, 1.0],
                            false,
                        ),
                        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(
                            1,
                            vec![0.0, 0.0, 1.0, 1.0],
                            false,
                        ),
                        cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(
                            vec![
                                vec![Point3::new(0.0, 0.0, 0.0), Point3::new(0.0, 1.0, 0.0)],
                                vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 1.0, 0.0)],
                            ],
                            None,
                        ),
                        false,
                    )
                    .expect("valid test surface"),
                )),
                source_object: None,
                native_ref: None,
            },
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#8".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
        ]);
        let model_surfaces = ModelSurfaceIndex::new(&ir.geometry.surfaces);
        let mut pcurve = crate::curve::TwoChartPcurveSamples {
            curve_id: 9,
            faces: [7, 8],
            samples: vec![
                [[-0.01, 0.25], [-0.01, 0.25]],
                [[0.5, 0.5], [0.5, 0.5]],
                [[1.01, 0.75], [1.01, 0.75]],
            ],
            offset: 0,
        };

        assert_eq!(
            mapped_two_chart_endpoint_sets(
                &evaluation_ctx,
                &scan,
                &model_surfaces,
                &pcurve,
                &crate::decode::source_carriers::SourceUnitCarriers::default()
            )
            .expect("compute the mapped two chart endpoint sets"),
            Some(TwoChartEndpointSets::Both([
                [[-0.01, 0.25], [1.01, 0.75]],
                [[-0.01, 0.25], [1.01, 0.75]],
            ]))
        );

        pcurve.samples[1][1][0] = 0.6;
        let mapping = map_two_chart_endpoint_sets(
            &evaluation_ctx,
            &scan,
            &model_surfaces,
            &pcurve,
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
        .expect("map two chart endpoint sets");
        assert!(matches!(
            mapping,
            TwoChartMapping::Mapped {
                surface_mismatch: true,
                endpoint_sets: Some(_),
                ..
            }
        ));
        assert!(mapped_two_chart_endpoint_sets(
            &evaluation_ctx,
            &scan,
            &model_surfaces,
            &pcurve,
            &crate::decode::source_carriers::SourceUnitCarriers::default()
        )
        .expect("compute the mapped two chart endpoint sets")
        .is_none());

        pcurve.samples[1][1][0] = 0.5;
    }

    #[test]
    fn two_chart_endpoint_carrier_proof_ignores_interior_disagreement() {
        const EPS_EXPECTED_POINT: f64 = 1.0e-12;
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .two_chart_pcurves
            .push(crate::curve::TwoChartPcurveSamples {
                curve_id: 17,
                faces: [1, 2],
                samples: vec![
                    [[0.0, 0.5], [0.0, -0.5]],
                    [[std::f64::consts::FRAC_PI_2, 0.5], [1.0, 0.0]],
                    [[std::f64::consts::PI, 0.5], [0.0, 0.5]],
                ],
                offset: 0,
            });
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.extend([
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#1".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
                    cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                        Point3::new(-1.0, 0.0, 0.0),
                        Vector3::new(1.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, -1.0),
                        0.0,
                        1.0,
                        std::f64::consts::FRAC_PI_4,
                    )
                    .expect("valid ConeSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#2".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(-0.5, 0.0, 0.0),
                        Vector3::new(1.0, 0.0, 0.0),
                        Vector3::new(0.0, 1.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
        ]);
        let carriers = BTreeMap::from([
            (
                1,
                CarrierEquation::Cone(
                    super::super::equations::ConeEquation::new(
                        [-1.0, 0.0, 0.0],
                        [1.0, 0.0, 0.0],
                        [0.0, 0.0, -1.0],
                        0.0,
                        1.0,
                        std::f64::consts::FRAC_PI_4,
                    )
                    .expect("valid test cone"),
                ),
            ),
            (
                2,
                CarrierEquation::Plane(PlaneEquation {
                    origin: [-0.5, 0.0, 0.0],
                    normal: [1.0, 0.0, 0.0],
                }),
            ),
        ]);
        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_carriers(
                ctx,
                &scan,
                &ir,
                &carriers,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");

        assert_eq!(diagnostics.two_chart_surface_mismatch_records, 1);
        assert_eq!(diagnostics.carrier_validated_paths, 2);
        assert_eq!(diagnostics.accepted_records, 1);
        let evidence = evidence.get(&17).expect("two-chart endpoint evidence");
        assert!(evidence.complete);
        assert!(
            point_coordinate_error(evidence.points[0], [-0.5, 0.0, -0.5]) <= EPS_EXPECTED_POINT
        );
        assert!(point_coordinate_error(evidence.points[1], [-0.5, 0.0, 0.5]) <= EPS_EXPECTED_POINT);
    }

    #[test]
    fn pcurve_mismatch_diagnostics_measure_both_endpoint_orders() {
        const EPS_TEST_ERROR: f64 = 1.0e-12;
        let mapped = vec![
            MappedPcurvePath {
                face_id: 7,
                endpoints: [[0.0, 0.0, 0.0], [2.0, 0.0, 0.0]],
            },
            MappedPcurvePath {
                face_id: 8,
                endpoints: [[1.0, 0.0, 0.0], [3.0, 0.0, 0.0]],
            },
        ];

        let detail = pcurve_mismatch_detail(11, &mapped).expect("two mapped paths");
        assert_eq!(detail.curve_id, 11);
        assert_eq!(detail.faces, [7, 8]);
        assert!((detail.same_order_error - 1.0).abs() < EPS_TEST_ERROR);
        assert!((detail.reverse_order_error - 3.0).abs() < EPS_TEST_ERROR);
    }

    #[test]
    fn pcurve_diagnostics_count_inactive_face_paths() {
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .topology_rows
            .push(crate::curve::CurveTopologyRow {
                id: 7,
                type_byte: 0,
                feature_id: 0,
                directions: [0x01, 0xf6],
                faces: [std::num::NonZeroU32::new(10), std::num::NonZeroU32::new(11)],
                next_edges: [7, 7],
                offset: 0,
            });
        scan.curves.pcurves.push(crate::curve::PcurveEndpoints {
            curve_id: 7,
            faces: [10, 11].map(std::num::NonZeroU32::new),
            face_0_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            face_1_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            offset: 0,
        });
        scan.topology.loops.push(crate::test_support::closed_loop(
            std::num::NonZeroU32::new(10),
            vec![crate::topology::HalfEdgeId {
                curve_id: 7,
                side: crate::topology::Side::Zero,
            }],
        ));
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.extend([
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#10".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#11".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
        ]);

        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(
                ctx,
                &scan,
                &ir,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(
            evidence.get(&7).map(|value| (value.points, value.complete)),
            Some(([[1.0, 2.0, 0.0], [3.0, 4.0, 0.0]], true))
        );
        assert_eq!(diagnostics.records, 1);
        assert_eq!(diagnostics.paths(), 2);
        assert_eq!(diagnostics.inactive_paths, 1);
        assert_eq!(diagnostics.inactive_records, 0);
        assert_eq!(diagnostics.partial_records, 1);
        assert_eq!(diagnostics.topology_mismatch_records, 0);
        assert_eq!(diagnostics.accepted_records, 1);
        assert_eq!(diagnostics.complete_records, 1);
    }

    #[test]
    fn short_fc02_path_supplies_one_sided_endpoint_evidence() {
        let token_specs = [
            (-14.5, vec![0x48, 0x45, 0x00]),
            (0.75, vec![0x2a, 0xe8, 0x00]),
            (0.0, vec![0x18]),
            (1.0, vec![0xe4]),
            (-12.5, vec![0x48, 0x41, 0x00]),
            (0.75, vec![0x2a, 0xe8, 0x00]),
            (
                f64::from_bits(0x3fff_ffff_ffff_ffff),
                vec![0x29, 0xff, 0xff],
            ),
        ];
        let mut body = vec![0xfc, 0x02];
        let mut scalar_tokens = Vec::new();
        for (value, raw) in token_specs {
            let offset = body.len();
            body.extend_from_slice(&raw);
            scalar_tokens.push(crate::curve::CurveParameterScalar { value, raw, offset });
        }
        body.extend_from_slice(&[0x34, 0xb0, 0x00]);
        let record = crate::curve::CurveParameterRecord {
            curve_id: 846,
            type_byte: 0,
            scalar_tokens,
            reference_geometry: [0, 0],
            opaque_spans: vec![
                crate::curve::CurveParameterOpaqueSpan {
                    raw: vec![0xfc, 0x02],
                    offset: 0,
                },
                crate::curve::CurveParameterOpaqueSpan {
                    raw: vec![0x34, 0xb0, 0x00],
                    offset: body.len() - 3,
                },
            ],
            body,
            references: Vec::new(),
            offset: 100,
            body_offset: 100,
            suffix_offset: 122,
            count_framed: false,
        };
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves.parameters.push(record);
        scan.curves
            .topology_rows
            .push(crate::curve::CurveTopologyRow {
                id: 846,
                type_byte: 0,
                feature_id: 57,
                directions: [0x01, 0xf6],
                faces: [
                    std::num::NonZeroU32::new(43),
                    std::num::NonZeroU32::new(163),
                ],
                next_edges: [841, 164],
                offset: 100,
            });
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint("creo:visibgeom:surface#43".to_string()).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 1.0, 0.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });

        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(
                ctx,
                &scan,
                &ir,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(
            evidence
                .get(&846)
                .map(|value| (value.points, value.complete)),
            Some(([[-14.5, 0.0, -0.75], [-12.5, 0.0, -0.75]], false,))
        );
        assert_eq!(diagnostics.records, 1);
        assert_eq!(diagnostics.paths(), 1);
        assert_eq!(diagnostics.mapped_paths, 1);
        assert_eq!(diagnostics.accepted_records, 1);
        assert_eq!(diagnostics.evidence, 1);
        assert_eq!(diagnostics.complete_records, 0);

        let mut annotations = cadmpeg_ir::AnnotationBuilder::new();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut Vec::new(),
                &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("valid source object identity");
        assert_eq!(
            transferred,
            BTreeSet::from([
                CurveId::mint("creo:visibgeom:curve#846".to_string()).expect("identity grammar")
            ])
        );
        assert!(ir.geometry.curves.iter().any(|curve| {
            curve.id
                == CurveId::mint("creo:visibgeom:curve#846".to_string()).expect("identity grammar")
                && matches!(
                    curve.geometry,
                    CurveGeometry::Solved(SolvedCurveGeometry::Line(_))
                )
        }));
    }

    #[test]
    fn pcurve_plane_carrier_status_requires_a_unique_join() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        ));
        let face_carrier = CarrierEquation::Plane(PlaneEquation {
            origin: [0.0, 0.0, 0.0],
            normal: [0.0, 0.0, 1.0],
        });
        let crossing_carrier = CarrierEquation::Plane(PlaneEquation {
            origin: [0.0, 0.0, 0.0],
            normal: [1.0, 0.0, 0.0],
        });
        assert_eq!(
            ({
                let arena = cadmpeg_core::decode::DecodeArena::new();
                let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                    &[],
                    &arena,
                    &cadmpeg_core::decode::DecodePolicy::service(),
                )
                .expect("root");
                pcurve_plane_carrier_status(
                    &ctx,
                    &surface,
                    face_carrier,
                    crossing_carrier,
                    [[0.0, 0.0], [0.0, 1.0]],
                )
            })
            .expect("compute the pcurve plane carrier status"),
            PcurveCarrierStatus::Validated,
        );
        assert_eq!(
            ({
                let arena = cadmpeg_core::decode::DecodeArena::new();
                let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                    &[],
                    &arena,
                    &cadmpeg_core::decode::DecodePolicy::service(),
                )
                .expect("root");
                pcurve_plane_carrier_status(
                    &ctx,
                    &surface,
                    face_carrier,
                    crossing_carrier,
                    [[0.0, 0.0], [1.0, 0.0]],
                )
            })
            .expect("compute the pcurve plane carrier status"),
            PcurveCarrierStatus::Rejected,
        );
        assert_eq!(
            ({
                let arena = cadmpeg_core::decode::DecodeArena::new();
                let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                    &[],
                    &arena,
                    &cadmpeg_core::decode::DecodePolicy::service(),
                )
                .expect("root");
                pcurve_plane_carrier_status(
                    &ctx,
                    &surface,
                    face_carrier,
                    CarrierEquation::Plane(PlaneEquation {
                        origin: [0.0, 0.0, 1.0],
                        normal: [0.0, 0.0, 1.0],
                    }),
                    [[0.0, 0.0], [0.0, 1.0]],
                )
            })
            .expect("compute the pcurve plane carrier status"),
            PcurveCarrierStatus::Unknown(PcurveCarrierUnknownReason::ParallelPlanePair),
        );
    }

    #[test]
    fn pcurve_carrier_join_keeps_one_valid_face_path() {
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .topology_rows
            .push(crate::curve::CurveTopologyRow {
                id: 7,
                type_byte: 0,
                feature_id: 0,
                directions: [0x01, 0xf6],
                faces: [std::num::NonZeroU32::new(10), std::num::NonZeroU32::new(11)],
                next_edges: [7, 7],
                offset: 0,
            });
        scan.curves.pcurves.push(crate::curve::PcurveEndpoints {
            curve_id: 7,
            faces: [10, 11].map(std::num::NonZeroU32::new),
            face_0_endpoints: [[0.0, 0.0], [0.0, 1.0]],
            face_1_endpoints: [[0.0, 0.0], [0.0, 1.0]],
            offset: 0,
        });
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.extend([
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#10".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
            Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#11".to_string())
                    .expect("identity grammar"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(1.0, 0.0, 0.0),
                        Vector3::new(0.0, 1.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
                source_object: None,
                native_ref: None,
            },
        ]);

        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(
                ctx,
                &scan,
                &ir,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(
            evidence.get(&7).map(|value| (value.points, value.complete)),
            Some(([[0.0, 0.0, 0.0], [0.0, 1.0, 0.0]], false)),
        );
        assert_eq!(diagnostics.carrier_validated_paths, 1);
        assert_eq!(diagnostics.carrier_rejected_paths, 1);
        assert_eq!(diagnostics.carrier_rejected_records, 0);
        assert_eq!(diagnostics.accepted_records, 1);
    }

    #[test]
    fn support_apex_cone_mirror_is_selected_by_plane_endpoint_witness() {
        let current = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(1.0, 0.0, 0.0),
                Vector3::new(-1.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, -1.0),
                0.0,
                1.0,
                std::f64::consts::FRAC_PI_4,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let mirrored = mirrored_support_apex_cone(&current).expect("support cone mirror");
        let plane = PlaneEquation {
            origin: [-0.5, 0.0, 0.0],
            normal: [1.0, 0.0, 0.0],
        };
        let perpendicular_plane = PlaneEquation {
            origin: [0.0, 0.0, 0.5],
            normal: [0.0, 0.0, 1.0],
        };
        let endpoints = [[0.0, 0.5], [std::f64::consts::PI, 0.5]];

        assert!(!({
            let arena = cadmpeg_core::decode::DecodeArena::new();
            let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                &[],
                &arena,
                &cadmpeg_core::decode::DecodePolicy::service(),
            )
            .expect("root");
            support_cone_witness_matches(&ctx, &current, endpoints, plane)
        })
        .expect("check support cone witness matches"));
        assert!(({
            let arena = cadmpeg_core::decode::DecodeArena::new();
            let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                &[],
                &arena,
                &cadmpeg_core::decode::DecodePolicy::service(),
            )
            .expect("root");
            support_cone_witness_matches(&ctx, &mirrored, endpoints, plane)
        })
        .expect("check support cone witness matches"));
        let perpendicular_endpoints = [[std::f64::consts::PI, 0.5]; 2];
        assert!(({
            let arena = cadmpeg_core::decode::DecodeArena::new();
            let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                &[],
                &arena,
                &cadmpeg_core::decode::DecodePolicy::service(),
            )
            .expect("root");
            support_cone_witness_matches(
                &ctx,
                &current,
                perpendicular_endpoints,
                perpendicular_plane,
            )
        })
        .expect("check support cone witness matches"));
        assert!(({
            let arena = cadmpeg_core::decode::DecodeArena::new();
            let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
                &[],
                &arena,
                &cadmpeg_core::decode::DecodePolicy::service(),
            )
            .expect("root");
            support_cone_witness_matches(
                &ctx,
                &mirrored,
                perpendicular_endpoints,
                perpendicular_plane,
            )
        })
        .expect("check support cone witness matches"));
    }

    #[test]
    fn a_zero_half_angle_apex_cone_is_not_a_support_apex_cone() {
        let degenerate = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(1.0, 0.0, 0.0),
                Vector3::new(-1.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, -1.0),
                0.0,
                1.0,
                0.0,
            )
            .expect("valid ConeSurface fixture"),
        ));

        assert!(mirrored_support_apex_cone(&degenerate).is_none());
    }

    #[test]
    fn an_apex_cone_mirrors_on_every_frame_the_ir_admits() {
        // `OrthonormalFrame3` admits a unit length and an orthogonality within 1e-9. This axis
        // is 5e-10 long of unit and this reference is 5e-10 out of square with it, so both sit
        // inside that admission and outside the 1e-10 the module applies to native record
        // directions.
        let slack = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(1.0, 0.0, 0.0),
                Vector3::new(-1.0 - 5.0e-10, 0.0, 0.0),
                Vector3::new(5.0e-10, 0.0, -1.0 - 5.0e-10),
                0.0,
                1.0,
                std::f64::consts::FRAC_PI_4,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let expected = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(-1.0, 0.0, 0.0),
                Vector3::new(1.0 + 5.0e-10, 0.0, 0.0),
                Vector3::new(5.0e-10, 0.0, -1.0 - 5.0e-10),
                0.0,
                1.0,
                std::f64::consts::FRAC_PI_4,
            )
            .expect("valid ConeSurface fixture"),
        ));

        assert_eq!(mirrored_support_apex_cone(&slack), Some(expected));
    }

    /// A plane whose origin is the largest finite x coordinate: the pcurve
    /// point u = MAX lifts to a point without a finite x, and u = -MAX lifts
    /// onto the plane x = 0.
    fn overflowing_plane_surface(face_id: u32) -> Surface {
        Surface {
            id: SurfaceId::mint(format!("creo:visibgeom:surface#{face_id}"))
                .expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(f64::MAX, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        }
    }

    fn unit_plane_surface(face_id: u32) -> Surface {
        Surface {
            id: SurfaceId::mint(format!("creo:visibgeom:surface#{face_id}"))
                .expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        }
    }

    #[test]
    fn a_two_chart_path_with_an_overflowing_sample_is_mapped_and_mismatched() {
        let evaluation_arena = cadmpeg_core::decode::DecodeArena::new();
        let evaluation_policy = cadmpeg_core::decode::DecodePolicy::service();
        let (evaluation_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &evaluation_arena,
            &evaluation_policy,
        )
        .expect("evaluation root");

        let scan = crate::test_support::empty_container_scan();
        let mut ir = CadIr::empty();
        ir.geometry
            .surfaces
            .extend([overflowing_plane_surface(7), unit_plane_surface(8)]);
        let pcurve = crate::curve::TwoChartPcurveSamples {
            curve_id: 9,
            faces: [7, 8],
            samples: vec![
                [[f64::MAX, 0.0], [0.0, 0.0]],
                [[-f64::MAX, 1.0], [0.0, 1.0]],
            ],
            offset: 0,
        };
        assert!(matches!(
            map_two_chart_endpoint_sets(
                &evaluation_ctx,
                &scan,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                &pcurve,
                &crate::decode::source_carriers::SourceUnitCarriers::default()
            )
            .expect("map two chart endpoint sets"),
            TwoChartMapping::Mapped {
                endpoint_sets: Some(TwoChartEndpointSets::Both(_)),
                missing_surface_paths: 0,
                unevaluable_paths: 0,
                surface_mismatch: true,
            }
        ));
    }

    #[test]
    fn model_surface_index_selects_the_surface_a_scan_selects() {
        let surface = |id: &str| Surface {
            id: SurfaceId::mint(id.to_string()).expect("identity grammar"),
            ..unit_plane_surface(1)
        };
        let surfaces = [
            surface("creo:visibgeom:surface#7"),
            surface("creo:visibgeom:surface#7"),
            surface("creo:novisgeom:surface#7"),
            surface("creo:novisgeom:surface#8"),
            surface("creo:actdatums:surface#8"),
            surface("creo:actdatums:surface#9"),
            surface("creo:visibgeom:surface#05"),
            surface("creo:visibgeom:surface#+5"),
            surface("creo:visibgeom:surface#10"),
            surface("creo:visibgeom:surface#010"),
            surface("creo:visibgeom:curve#11"),
            surface("creo:visibgeom:surface#4294967295"),
            surface("creo:visibgeom:surface#4294967296"),
        ];
        let index = ModelSurfaceIndex::new(&surfaces);
        let selected = |face_id| index.unique(face_id).map(std::ptr::from_ref);

        assert_eq!(selected(7), None);
        assert_eq!(selected(8), Some(std::ptr::from_ref(&surfaces[3])));
        assert_eq!(selected(9), Some(std::ptr::from_ref(&surfaces[5])));
        assert_eq!(selected(5), None);
        assert_eq!(selected(10), Some(std::ptr::from_ref(&surfaces[8])));
        assert_eq!(selected(11), None);
        assert_eq!(selected(u32::MAX), Some(std::ptr::from_ref(&surfaces[11])));
        for face_id in (0..=12).chain([u32::MAX]) {
            assert_eq!(
                selected(face_id),
                unique_model_surface(&surfaces, face_id).map(std::ptr::from_ref),
                "face {face_id}"
            );
        }
    }

    #[test]
    fn a_pcurve_path_with_an_overflowing_endpoint_is_mapped() {
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(overflowing_plane_surface(7));
        let mapped = crate::decode::with_service_context(|ctx| {
            super::map_pcurve_paths(
                ctx,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                [(
                    std::num::NonZeroU32::new(7),
                    [[f64::MAX, 0.0], [-f64::MAX, 5.0]],
                )],
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("map the pcurve paths");
        assert_eq!(mapped.unevaluable_paths, 0);
        assert_eq!(mapped.mapped.len(), 1);
        assert!(mapped.mapped[0].endpoints[0][0].is_nan());
        assert_eq!(mapped.mapped[0].endpoints[1], [0.0, 5.0, 0.0]);
    }

    #[test]
    fn a_pcurve_path_with_an_overflowing_endpoint_withholds_the_curve_carrier() {
        // Face 11's path lifts one endpoint to a point without a finite x. It
        // is a mapped path that no endpoint evidence agrees with, and an
        // evaluable path without a line carrier, so the curve keeps no carrier.
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .topology_rows
            .push(crate::curve::CurveTopologyRow {
                id: 7,
                type_byte: 0,
                feature_id: 0,
                directions: [0x01, 0xf6],
                faces: [std::num::NonZeroU32::new(10), std::num::NonZeroU32::new(11)],
                next_edges: [7, 7],
                offset: 0,
            });
        scan.curves.pcurves.push(crate::curve::PcurveEndpoints {
            curve_id: 7,
            faces: [10, 11].map(std::num::NonZeroU32::new),
            face_0_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            face_1_endpoints: [[f64::MAX, 2.0], [-f64::MAX, 4.0]],
            offset: 0,
        });
        scan.topology.loops.push(crate::test_support::closed_loop(
            std::num::NonZeroU32::new(10),
            vec![crate::topology::HalfEdgeId {
                curve_id: 7,
                side: crate::topology::Side::Zero,
            }],
        ));
        let mut ir = CadIr::empty();
        ir.geometry
            .surfaces
            .extend([unit_plane_surface(10), overflowing_plane_surface(11)]);
        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(
                ctx,
                &scan,
                &ir,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(diagnostics.mapped_paths, 2);
        assert_eq!(diagnostics.unevaluable_paths, 0);
        assert!(!evidence.contains_key(&7));
        let mut annotations = cadmpeg_ir::AnnotationBuilder::new();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut Vec::new(),
                &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("valid source object identity");
        assert!(transferred.is_empty(), "{transferred:?}");
        assert!(ir.geometry.curves.is_empty());

        let mut finite = CadIr::empty();
        finite
            .geometry
            .surfaces
            .extend([unit_plane_surface(10), unit_plane_surface(11)]);
        scan.curves.pcurves[0].face_1_endpoints = [[1.0, 2.0], [3.0, 4.0]];
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut finite,
                &mut annotations,
                &mut Vec::new(),
                &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("valid source object identity");
        assert_eq!(
            transferred,
            BTreeSet::from([
                CurveId::mint("creo:visibgeom:curve#7".to_string()).expect("identity grammar")
            ])
        );
    }

    #[test]
    fn a_native_pcurve_with_an_overflowing_endpoint_has_no_midpoint_and_no_orientation() {
        let evaluation_arena = cadmpeg_core::decode::DecodeArena::new();
        let evaluation_policy = cadmpeg_core::decode::DecodePolicy::service();
        let (evaluation_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &evaluation_arena,
            &evaluation_policy,
        )
        .expect("evaluation root");

        // The endpoint u = MAX reaches x = +inf on the plane through
        // (MAX, 0, 0). A point outside the finite range aligns with no edge
        // point, so neither pairing aligns.
        let surface = overflowing_plane_surface(7).geometry;
        let endpoints = [[f64::MAX, 0.0], [-f64::MAX, 5.0]];
        assert_eq!(
            super::native_pcurve_midpoint(
                &evaluation_ctx,
                &surface,
                endpoints,
                [[9.0, 9.0, 9.0], [0.0, 5.0, 0.0]]
            )
            .expect("compute the native pcurve midpoint"),
            None
        );
        assert_eq!(
            super::oriented_native_pcurve_endpoints(
                &evaluation_ctx,
                &surface,
                endpoints,
                [[9.0, 9.0, 9.0], [0.0, 5.0, 0.0]],
            )
            .expect("compute the oriented native pcurve endpoints"),
            None
        );
    }

    /// A plane through the origin placed by a transform that adds the largest
    /// finite x coordinate: the pcurve point u = MAX lifts to a point without
    /// a finite x, and u = -MAX lifts onto the plane x = 0.
    fn overflowing_placed_plane_surface(face_id: u32) -> Surface {
        let SurfaceGeometry::Solved(plane) = unit_plane_surface(face_id).geometry else {
            panic!("the plane fixture is solved");
        };
        Surface {
            id: SurfaceId::mint(format!("creo:visibgeom:surface#{face_id}"))
                .expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Transformed(
                cadmpeg_ir::geometry::PlacedSurface::try_new(
                    Box::new(plane),
                    cadmpeg_ir::transform::Transform::affine([
                        [1.0, 0.0, 0.0, f64::MAX],
                        [0.0, 1.0, 0.0, 0.0],
                        [0.0, 0.0, 1.0, 0.0],
                    ])
                    .expect("affine transform"),
                )
                .expect("valid PlacedSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        }
    }

    #[test]
    fn a_two_chart_path_with_an_overflowing_placed_sample_is_a_surface_mismatch() {
        let evaluation_arena = cadmpeg_core::decode::DecodeArena::new();
        let evaluation_policy = cadmpeg_core::decode::DecodePolicy::service();
        let (evaluation_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &evaluation_arena,
            &evaluation_policy,
        )
        .expect("evaluation root");

        // The placed sample reaches x = +inf. It is a mapped sample on both
        // charts, and a point outside the finite range agrees with no point,
        // so the charts do not agree.
        let scan = crate::test_support::empty_container_scan();
        let mut ir = CadIr::empty();
        ir.geometry
            .surfaces
            .extend([overflowing_placed_plane_surface(7), unit_plane_surface(8)]);
        let pcurve = crate::curve::TwoChartPcurveSamples {
            curve_id: 9,
            faces: [7, 8],
            samples: vec![
                [[f64::MAX, 0.0], [0.0, 0.0]],
                [[-f64::MAX, 1.0], [0.0, 1.0]],
            ],
            offset: 0,
        };
        assert!(matches!(
            map_two_chart_endpoint_sets(
                &evaluation_ctx,
                &scan,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                &pcurve,
                &crate::decode::source_carriers::SourceUnitCarriers::default()
            )
            .expect("map two chart endpoint sets"),
            TwoChartMapping::Mapped {
                endpoint_sets: Some(TwoChartEndpointSets::Both(_)),
                missing_surface_paths: 0,
                unevaluable_paths: 0,
                surface_mismatch: true,
            }
        ));
    }

    #[test]
    fn a_pcurve_path_with_an_overflowing_placed_endpoint_is_mapped() {
        let mut ir = CadIr::empty();
        ir.geometry
            .surfaces
            .push(overflowing_placed_plane_surface(7));
        let mapped = crate::decode::with_service_context(|ctx| {
            super::map_pcurve_paths(
                ctx,
                &ModelSurfaceIndex::new(&ir.geometry.surfaces),
                [(
                    std::num::NonZeroU32::new(7),
                    [[f64::MAX, 0.0], [-f64::MAX, 5.0]],
                )],
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("map the pcurve paths");
        assert_eq!(mapped.unevaluable_paths, 0);
        assert_eq!(mapped.mapped.len(), 1);
        assert_eq!(mapped.mapped[0].endpoints[0], [f64::INFINITY, 0.0, 0.0]);
        assert_eq!(mapped.mapped[0].endpoints[1], [0.0, 5.0, 0.0]);
    }

    #[test]
    fn a_pcurve_path_with_an_overflowing_placed_endpoint_withholds_the_curve_carrier() {
        // Face 11's path lifts one endpoint to a point without a finite x. It
        // is a mapped path that no endpoint evidence agrees with, and an
        // evaluable path without a line carrier, so the curve keeps no carrier.
        let mut scan = crate::test_support::empty_container_scan();
        scan.curves
            .topology_rows
            .push(crate::curve::CurveTopologyRow {
                id: 7,
                type_byte: 0,
                feature_id: 0,
                directions: [0x01, 0xf6],
                faces: [std::num::NonZeroU32::new(10), std::num::NonZeroU32::new(11)],
                next_edges: [7, 7],
                offset: 0,
            });
        scan.curves.pcurves.push(crate::curve::PcurveEndpoints {
            curve_id: 7,
            faces: [10, 11].map(std::num::NonZeroU32::new),
            face_0_endpoints: [[1.0, 2.0], [3.0, 4.0]],
            face_1_endpoints: [[f64::MAX, 2.0], [-f64::MAX, 4.0]],
            offset: 0,
        });
        scan.topology.loops.push(crate::test_support::closed_loop(
            std::num::NonZeroU32::new(10),
            vec![crate::topology::HalfEdgeId {
                curve_id: 7,
                side: crate::topology::Side::Zero,
            }],
        ));
        let mut ir = CadIr::empty();
        ir.geometry
            .surfaces
            .extend([unit_plane_surface(10), overflowing_placed_plane_surface(11)]);
        let (evidence, diagnostics) = crate::decode::with_service_context(|ctx| {
            pcurve_edge_endpoint_evidence_with_diagnostics(
                ctx,
                &scan,
                &ir,
                &crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("resolve the pcurve edge endpoint evidence");
        assert_eq!(diagnostics.mapped_paths, 2);
        assert_eq!(diagnostics.unevaluable_paths, 0);
        assert!(!evidence.contains_key(&7));
        let mut annotations = cadmpeg_ir::AnnotationBuilder::new();
        let transferred = crate::decode::with_service_context(|ctx| {
            transfer_analytic_pcurve_carriers(
                ctx,
                &scan,
                &mut ir,
                &mut annotations,
                &mut Vec::new(),
                &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
            )
        })
        .expect("valid source object identity");
        assert!(transferred.is_empty(), "{transferred:?}");
        assert!(ir.geometry.curves.is_empty());
    }

    #[test]
    fn a_native_pcurve_with_an_overflowing_placed_endpoint_has_no_midpoint_and_no_orientation() {
        let evaluation_arena = cadmpeg_core::decode::DecodeArena::new();
        let evaluation_policy = cadmpeg_core::decode::DecodePolicy::service();
        let (evaluation_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &evaluation_arena,
            &evaluation_policy,
        )
        .expect("evaluation root");

        // The placed endpoint reaches x = +inf. A point outside the finite
        // range aligns with no edge point, so neither pairing aligns: no
        // midpoint is read, and no orientation is found.
        let surface = overflowing_placed_plane_surface(7).geometry;
        let endpoints = [[f64::MAX, 0.0], [-f64::MAX, 5.0]];
        assert_eq!(
            super::native_pcurve_midpoint(
                &evaluation_ctx,
                &surface,
                endpoints,
                [[9.0, 9.0, 9.0], [0.0, 5.0, 0.0]]
            )
            .expect("compute the native pcurve midpoint"),
            None
        );
        assert_eq!(
            super::oriented_native_pcurve_endpoints(
                &evaluation_ctx,
                &surface,
                endpoints,
                [[9.0, 9.0, 9.0], [0.0, 5.0, 0.0]],
            )
            .expect("compute the oriented native pcurve endpoints"),
            None
        );
    }
    #[test]
    fn bounded_cylinder_envelope_selects_the_circle_interval() {
        for axial_upper in [4.0_f64, std::f64::consts::FRAC_PI_2] {
            let mut payload = vec![10, 0x24, 4, 1, 0, 0, 0x18, 0xe4, 0x12];
            if axial_upper == std::f64::consts::FRAC_PI_2 {
                payload.push(0xe4);
            } else {
                payload.push(0x2d);
                payload.extend_from_slice(&axial_upper.to_be_bytes()[1..]);
            }
            for value in [0.0_f64, 0.0, 0.0, 2.0, 2.0, axial_upper] {
                if value == 0.0 {
                    payload.push(0x18);
                } else {
                    payload.push(if value.to_be_bytes()[0] == 0x3f {
                        0x28
                    } else {
                        0x2d
                    });
                    payload.extend_from_slice(&value.to_be_bytes()[1..]);
                }
            }
            payload.push(0xe3);
            let mut scan = crate::test_support::empty_container_scan();
            scan.surfaces.parameters = crate::decode::with_service_context(|ctx| {
                crate::surface::parameter_records(ctx, &payload)
            })
            .expect("synthetic envelope");
            assert_eq!(scan.surfaces.parameters.len(), 1);
            let surfaces = [Surface {
                id: SurfaceId::mint("creo:visibgeom:surface#10").expect("surface identity"),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
                    cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                        2.0,
                    )
                    .expect("cylinder frame"),
                )),
                source_object: None,
                native_ref: None,
            }];
            let circle = CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, -1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                    2.0,
                )
                .expect("opposite circle axis"),
            ));
            let range = |points| {
                let mut geometry = circle.clone();
                let selected = crate::decode::with_service_context(|ctx| {
                    super::bounded_cylinder_circle_parameter_range(
                        ctx,
                        &scan,
                        &mut geometry,
                        [10, 0],
                        &surfaces,
                        points,
                        &crate::decode::source_carriers::SourceUnitCarriers::default(),
                    )
                })
                .expect("bounded circle interval");
                (selected, geometry)
            };
            for points in [
                [[2.0, 0.0, 0.0], [0.0, 2.0, 0.0]],
                [[0.0, 2.0, 0.0], [2.0, 0.0, 0.0]],
            ] {
                let (selected, geometry) = range(points);
                let selected = selected.expect("quarter-turn witness");
                assert!(selected[0].abs() < 1.0e-12);
                assert!((selected[1] - std::f64::consts::FRAC_PI_2).abs() < 1.0e-12);
                cadmpeg_ir::topology::EdgeCarrier::new(
                    Some(CurveId::mint("creo:visibgeom:curve#7").expect("curve identity")),
                    Some(selected),
                )
                .expect("ordered interval with a curve");
                let plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("end plane"),
                ));
                let projected = super::planar_curve_pcurve(
                    &plane,
                    &geometry,
                    &"bounded circle",
                    &mut crate::lane_refusal::LaneRefusals::new(),
                )
                .expect("complete circular pcurve");
                assert!(matches!(
                    projected,
                    cadmpeg_ir::geometry::pcurve::PcurveGeometry::Circle(_)
                ));
                for (parameter, expected) in selected.into_iter().zip(points) {
                    let point = cadmpeg_ir::eval::decode::curve_point(
                        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                        &geometry,
                        parameter,
                    )
                    .expect("circle endpoint");
                    assert!([point.x, point.y, point.z]
                        .into_iter()
                        .zip(expected)
                        .all(|(a, b)| (a - b).abs() < 1.0e-12));
                }
            }
            assert!(range([[2.0, 0.0, 0.0], [0.0, -2.0, 0.0]]).0.is_none());
        }
    }
}

#[cfg(test)]
mod evaluation_tests;
