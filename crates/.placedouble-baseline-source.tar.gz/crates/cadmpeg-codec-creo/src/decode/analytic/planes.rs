// SPDX-License-Identifier: Apache-2.0
//! Carrier point tests, plane reconciliation, and placed planes.

use crate::axis::{Axis, Sign};
use crate::feature::schema::SchemaClass;
use crate::vecmath::normalize;
use crate::vecmath::unit_length;
use std::collections::{BTreeMap, BTreeSet};
use std::num::NonZeroU32;

use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve, CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, SurfaceGeometry,
};

use crate::container::ContainerScan;
use crate::curve::CurveTopologyRow;

use super::super::holes::placement::plane_envelope_corners;
use super::super::surfaces::intersection_resolve::intersect_plane_with_carrier_components;
use super::super::surfaces::{fc05_cap_pair_model_frame, fc05_model_frame};

use super::edges::{nurbs_intrinsic_parameter_range, nurbs_points, nurbs_weights_positive};
use super::equations::{
    intersect_plane_with_two_quadrics, intersect_two_planes_with_quadric,
    intersect_two_planes_with_torus, solve_planes, CarrierEquation, PlaneEquation, SphereEquation,
};
use super::vertices::{finite_model_point, model_points_agree};
use crate::vecmath::{cross, dot, local_system_lanes};

const EPS_ON_CARRIER: f64 = 1.0e-7;
const EPS_POINT_UNIQUE: f64 = 1.0e-7;
const EPS_AGREE: f64 = 1.0e-9;
const EPS_ORTHO: f64 = 1.0e-10;
const EPS_NEAR_ZERO: f64 = 1.0e-12;
const EPS_STORED_FRAME_NONZERO: f64 = 1.0e-6;
const EPS_STORED_FRAME_RELATIVE: f64 = 1.0e-9;
const EPS_FC05_TANGENT_AXIS: f64 = 1.0e-10;
const EPS_FC05_TANGENT_RESIDUAL: f64 = 1.0e-9;
const EPS_FC05_CAP_AXIS: f64 = 1.0e-9;

pub(in crate::decode) fn point_on_carrier(point: [f64; 3], carrier: CarrierEquation) -> bool {
    match carrier {
        CarrierEquation::Plane(plane) => {
            let residual = dot(plane.normal, point) - dot(plane.normal, plane.origin);
            residual.abs() <= EPS_ON_CARRIER
        }
        CarrierEquation::Cylinder(cylinder) => {
            let Some(axis) = normalize(cylinder.axis) else {
                return false;
            };
            let relative = std::array::from_fn(|index| point[index] - cylinder.origin[index]);
            let axial = dot(relative, axis);
            let radial: [f64; 3] =
                std::array::from_fn(|index| relative[index] - axial * axis[index]);
            (radial[0].hypot(radial[1]).hypot(radial[2]) - cylinder.radius).abs()
                <= EPS_ON_CARRIER * cylinder.radius
        }
        CarrierEquation::Cone(cone) => {
            let (Some(axis), Some(x_axis)) =
                (normalize(cone.axis()), normalize(cone.ref_direction()))
            else {
                return false;
            };
            if dot(axis, x_axis).abs() > EPS_ORTHO {
                return false;
            }
            let y_axis = cross(axis, x_axis);
            let relative = std::array::from_fn(|index| point[index] - cone.origin()[index]);
            let axial = dot(relative, axis);
            let radius = cone.radius() + axial * cone.half_angle().tan();
            let radial_x = dot(relative, x_axis);
            let radial_y = dot(relative, y_axis) / cone.ratio();
            (radial_x.hypot(radial_y) - radius.abs()).abs() <= EPS_ON_CARRIER * radius.abs()
        }
        CarrierEquation::Sphere(sphere) => {
            let relative: [f64; 3] =
                std::array::from_fn(|index| point[index] - sphere.center[index]);
            (relative[0].hypot(relative[1]).hypot(relative[2]) - sphere.radius).abs()
                <= EPS_ON_CARRIER * sphere.radius
        }
        CarrierEquation::Torus(torus) => {
            let Some(axis) = normalize(torus.axis) else {
                return false;
            };
            let relative = std::array::from_fn(|index| point[index] - torus.center[index]);
            let axial = dot(relative, axis);
            let radial: [f64; 3] =
                std::array::from_fn(|index| relative[index] - axial * axis[index]);
            let tube_distance =
                (radial[0].hypot(radial[1]).hypot(radial[2]) - torus.major_radius).hypot(axial);
            (tube_distance - torus.minor_radius).abs()
                <= EPS_ON_CARRIER * torus.minor_radius.max(torus.major_radius)
        }
    }
}

fn tangent_sphere_point(first: SphereEquation, second: SphereEquation) -> Option<[f64; 3]> {
    let delta: [f64; 3] = std::array::from_fn(|index| second.center[index] - first.center[index]);
    let distance = delta[0].hypot(delta[1]).hypot(delta[2]);
    if !distance.is_finite() || distance == 0.0 || first.radius <= 0.0 || second.radius <= 0.0 {
        return None;
    }
    let scale = first.radius.max(second.radius).max(distance);
    let first_radius = first.radius / scale;
    let second_radius = second.radius / scale;
    let separation = distance / scale;
    let external = first_radius + second_radius;
    let internal = (first_radius - second_radius).abs();
    let external_tangent = (separation - external).abs() <= EPS_AGREE * external.max(separation);
    let internal_tangent = (separation - internal).abs() <= EPS_AGREE * internal.max(separation);
    if !external_tangent && !internal_tangent {
        return None;
    }
    let signed_radius = if !external_tangent && second.radius > first.radius {
        -first.radius
    } else {
        first.radius
    };
    let point = std::array::from_fn(|index| {
        first.center[index] + signed_radius * (delta[index] / distance)
    });
    point.iter().all(|value| value.is_finite()).then_some(point)
}

fn tangent_plane_sphere_point(plane: PlaneEquation, sphere: SphereEquation) -> Option<[f64; 3]> {
    let normal = normalize(plane.normal)?;
    let signed_distance = dot(
        normal,
        std::array::from_fn(|index| sphere.center[index] - plane.origin[index]),
    );
    let scale = sphere.radius;
    if !signed_distance.is_finite()
        || sphere.radius <= 0.0
        || (signed_distance.abs() - sphere.radius).abs() > EPS_AGREE * scale
    {
        return None;
    }
    Some(std::array::from_fn(|index| {
        sphere.center[index] - signed_distance * normal[index]
    }))
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub(super) struct CarrierSolveDiagnostics {
    pub(super) pair_intersections: usize,
    pub(super) triple_intersections: usize,
    pub(super) valid_candidates: usize,
    pub(super) unique_solutions: usize,
}

pub(super) fn solve_carriers_with_diagnostics(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    carriers: &[CarrierEquation],
) -> Result<(Option<[f64; 3]>, CarrierSolveDiagnostics), cadmpeg_core::CodecError> {
    let mut candidates = Vec::new();
    let mut diagnostics = CarrierSolveDiagnostics::default();
    for first in 0..carriers.len() {
        for second in first + 1..carriers.len() {
            let candidate_start = candidates.len();
            match (carriers[first], carriers[second]) {
                (CarrierEquation::Plane(plane), CarrierEquation::Sphere(sphere))
                | (CarrierEquation::Sphere(sphere), CarrierEquation::Plane(plane)) => {
                    if let Some(point) = tangent_plane_sphere_point(plane, sphere) {
                        candidates.push(point);
                    }
                }
                (CarrierEquation::Sphere(first), CarrierEquation::Sphere(second)) => {
                    if let Some(point) = tangent_sphere_point(first, second) {
                        candidates.push(point);
                    }
                }
                _ => {}
            }
            diagnostics.pair_intersections += candidates.len() - candidate_start;
        }
    }
    for first in 0..carriers.len() {
        for second in first + 1..carriers.len() {
            for third in second + 1..carriers.len() {
                let candidate_start = candidates.len();
                let triple = [carriers[first], carriers[second], carriers[third]];
                let mut planes = Vec::new();
                let mut cylinders = Vec::new();
                let mut cones = Vec::new();
                let mut spheres = Vec::new();
                let mut tori = Vec::new();
                for carrier in triple {
                    match carrier {
                        CarrierEquation::Plane(plane) => {
                            planes.push(plane);
                        }
                        CarrierEquation::Cylinder(cylinder) => {
                            cylinders.push(cylinder);
                        }
                        CarrierEquation::Cone(cone) => {
                            cones.push(cone);
                        }
                        CarrierEquation::Sphere(sphere) => {
                            spheres.push(sphere);
                        }
                        CarrierEquation::Torus(torus) => {
                            tori.push(torus);
                        }
                    }
                }
                if planes.len() == 3 {
                    if let Some(point) = solve_planes(&planes) {
                        candidates.push(point);
                    }
                } else if planes.len() == 1
                    && tori.is_empty()
                    && cylinders.len() + cones.len() + spheres.len() == 2
                {
                    let reduced = if let [first, second] = cones.as_slice() {
                        intersect_plane_with_carrier_components(
                            planes[0],
                            CarrierEquation::Cone(*first),
                            CarrierEquation::Cone(*second),
                        )
                    } else {
                        Vec::new()
                    };
                    if reduced.is_empty() {
                        let mut quadrics = cylinders
                            .iter()
                            .copied()
                            .map(CarrierEquation::Cylinder)
                            .chain(cones.iter().copied().map(CarrierEquation::Cone))
                            .chain(spheres.iter().copied().map(CarrierEquation::Sphere));
                        let Some(first_quadric) = quadrics.next() else {
                            continue;
                        };
                        let Some(second_quadric) = quadrics.next() else {
                            continue;
                        };
                        let intersections = intersect_plane_with_two_quadrics(
                            ctx,
                            planes[0],
                            first_quadric,
                            second_quadric,
                        )?;
                        candidates.extend(intersections);
                    } else {
                        candidates.extend(reduced);
                    }
                } else if let ([first, second], []) = (planes.as_slice(), tori.as_slice()) {
                    let intersections =
                        match (cylinders.as_slice(), cones.as_slice(), spheres.as_slice()) {
                            ([cylinder], [], []) => intersect_two_planes_with_quadric(
                                *first,
                                *second,
                                CarrierEquation::Cylinder(*cylinder),
                            ),
                            ([], [cone], []) => intersect_two_planes_with_quadric(
                                *first,
                                *second,
                                CarrierEquation::Cone(*cone),
                            ),
                            ([], [], [sphere]) => intersect_two_planes_with_quadric(
                                *first,
                                *second,
                                CarrierEquation::Sphere(*sphere),
                            ),
                            _ => Vec::new(),
                        };
                    candidates.extend(intersections);
                } else if let ([first, second], [torus]) = (planes.as_slice(), tori.as_slice()) {
                    if cylinders.is_empty() && cones.is_empty() && spheres.is_empty() {
                        let intersections =
                            intersect_two_planes_with_torus(ctx, *first, *second, *torus)?;
                        candidates.extend(intersections);
                    }
                } else if let ([plane], [cylinder], [torus]) =
                    (planes.as_slice(), cylinders.as_slice(), tori.as_slice())
                {
                    if cones.is_empty() && spheres.is_empty() {
                        let intersections = intersect_plane_with_carrier_components(
                            *plane,
                            CarrierEquation::Cylinder(*cylinder),
                            CarrierEquation::Torus(*torus),
                        );
                        candidates.extend(intersections);
                    }
                } else if let ([plane], [cone], [sphere]) =
                    (planes.as_slice(), cones.as_slice(), spheres.as_slice())
                {
                    if cylinders.is_empty() && tori.is_empty() {
                        let intersections = intersect_plane_with_carrier_components(
                            *plane,
                            CarrierEquation::Cone(*cone),
                            CarrierEquation::Sphere(*sphere),
                        );
                        candidates.extend(intersections);
                    }
                } else if let ([plane], [cone], [torus]) =
                    (planes.as_slice(), cones.as_slice(), tori.as_slice())
                {
                    if cylinders.is_empty() && spheres.is_empty() {
                        let intersections = intersect_plane_with_carrier_components(
                            *plane,
                            CarrierEquation::Cone(*cone),
                            CarrierEquation::Torus(*torus),
                        );
                        candidates.extend(intersections);
                    }
                } else if let ([plane], [sphere], [torus]) =
                    (planes.as_slice(), spheres.as_slice(), tori.as_slice())
                {
                    if cylinders.is_empty() && cones.is_empty() {
                        let intersections = intersect_plane_with_carrier_components(
                            *plane,
                            CarrierEquation::Sphere(*sphere),
                            CarrierEquation::Torus(*torus),
                        );
                        candidates.extend(intersections);
                    }
                } else if let ([plane], [first, second]) = (planes.as_slice(), tori.as_slice()) {
                    if cylinders.is_empty() && cones.is_empty() && spheres.is_empty() {
                        let intersections = intersect_plane_with_carrier_components(
                            *plane,
                            CarrierEquation::Torus(*first),
                            CarrierEquation::Torus(*second),
                        );
                        candidates.extend(intersections);
                    }
                }
                diagnostics.triple_intersections += candidates.len() - candidate_start;
            }
        }
    }
    candidates.retain(|point| {
        carriers
            .iter()
            .all(|carrier| point_on_carrier(*point, *carrier))
    });
    diagnostics.valid_candidates = candidates.len();
    let mut unique = Vec::<[f64; 3]>::new();
    for candidate in candidates {
        if !unique.iter().any(|known| {
            known
                .iter()
                .zip(candidate)
                .all(|(left, right)| (left - right).abs() <= EPS_POINT_UNIQUE)
        }) {
            unique.push(candidate);
        }
    }
    diagnostics.unique_solutions = unique.len();
    let point = match unique.as_slice() {
        [point] => Some(*point),
        _ => None,
    };
    Ok((point, diagnostics))
}

#[cfg(test)]
pub(in crate::decode) fn solve_carriers(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    carriers: &[CarrierEquation],
) -> Result<Option<[f64; 3]>, cadmpeg_core::CodecError> {
    Ok(solve_carriers_with_diagnostics(ctx, carriers)?.0)
}

pub(in crate::decode) fn is_axis_aligned(vector: [f64; 3]) -> bool {
    vector
        .iter()
        .filter(|value| value.abs() > EPS_AGREE)
        .count()
        == 1
}

pub(in crate::decode) fn canonical_plane(plane: PlaneEquation) -> Option<PlaneEquation> {
    let mut normal = normalize(plane.normal)?;
    let mut distance = dot(normal, plane.origin);
    if !distance.is_finite() {
        return None;
    }
    let sign = normal
        .iter()
        .find(|coordinate| coordinate.abs() > EPS_NEAR_ZERO)?
        .signum();
    if sign < 0.0 {
        normal = normal.map(|coordinate| -coordinate);
        distance = -distance;
    }
    Some(PlaneEquation {
        origin: normal.map(|coordinate| coordinate * distance),
        normal,
    })
}

pub(super) fn agreed_plane(candidates: &[PlaneEquation]) -> Option<PlaneEquation> {
    agreed_plane_iter(candidates.iter().copied())
}

fn agreed_plane_iter(mut planes: impl Iterator<Item = PlaneEquation>) -> Option<PlaneEquation> {
    let first = canonical_plane(planes.next()?)?;
    let first_distance = dot(first.normal, first.origin);
    planes
        .all(|plane| {
            canonical_plane(plane).is_some_and(|plane| {
                let distance = dot(plane.normal, plane.origin);
                let scale = first_distance.abs().max(distance.abs()).max(1.0);
                first
                    .normal
                    .iter()
                    .zip(plane.normal)
                    .all(|(left, right)| (left - right).abs() <= EPS_AGREE)
                    && (first_distance - distance).abs() <= EPS_AGREE * scale
            })
        })
        .then_some(first)
}

pub(in crate::decode) fn reconciled_model_plane(
    local_planes: &BTreeMap<u32, PlaneEquation>,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
    surface_id: u32,
) -> Option<PlaneEquation> {
    let mut model_surfaces = ir.geometry.surfaces.iter().filter(|surface| {
        crate::identity::matches_numbered_identity(
            surface.id.as_str(),
            "creo:visibgeom:surface#",
            surface_id,
        )
    });
    let first = model_surfaces.next();
    let second = model_surfaces.next();
    let model_plane = match (first, second) {
        (None, None) => None,
        (Some(surface), None) => match source_carriers.surface_geometry(surface) {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)) => {
                let origin = plane_surface.origin().get();
                let normal = plane_surface.frame().axis().as_raw();
                Some(PlaneEquation {
                    origin: [origin.x, origin.y, origin.z],
                    normal: [normal.x, normal.y, normal.z],
                })
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { .. }) => None,
            _ => return None,
        },
        _ => return None,
    };
    match (local_planes.get(&surface_id).copied(), model_plane) {
        (Some(local), Some(model)) => agreed_plane(&[local, model]),
        (Some(local), None) => Some(local),
        (None, Some(model)) => Some(model),
        (None, None) => None,
    }
}

#[derive(Clone, Copy)]
struct PlaneCandidate {
    pub(in crate::decode) equation: PlaneEquation,
    pub(in crate::decode) chart: Option<PlaneChart>,
    pub(in crate::decode) offset: usize,
}

#[derive(Clone, Copy)]
struct PlaneChart {
    pub(in crate::decode) origin: [f64; 3],
    pub(in crate::decode) normal: [f64; 3],
    pub(in crate::decode) u_axis: [f64; 3],
}

fn agreed_plane_surface(candidates: &[PlaneCandidate]) -> Option<(PlaneEquation, [f64; 3], usize)> {
    agreed_plane_iter(candidates.iter().map(|candidate| candidate.equation))?;
    let mut charts = candidates.iter().filter_map(|candidate| {
        let chart = candidate.chart?;
        let normal = normalize(chart.normal)?;
        let u_axis = normalize(chart.u_axis)?;
        (dot(normal, u_axis).abs() <= EPS_AGREE).then_some((
            chart.origin,
            normal,
            u_axis,
            candidate.offset,
        ))
    });
    let representative = charts.clone().min_by_key(|(_, _, _, offset)| *offset)?;
    charts
        .all(|(origin, normal, u_axis, _)| {
            representative.0.iter().zip(origin).all(|(left, right)| {
                (left - right).abs() <= EPS_AGREE * left.abs().max(right.abs()).max(1.0)
            }) && representative
                .1
                .iter()
                .zip(normal)
                .all(|(left, right)| (left - right).abs() <= EPS_AGREE)
                && representative
                    .2
                    .iter()
                    .zip(u_axis)
                    .all(|(left, right)| (left - right).abs() <= EPS_AGREE)
        })
        .then_some((
            PlaneEquation {
                origin: representative.0,
                normal: representative.1,
            },
            representative.2,
            representative.3,
        ))
}

fn stored_parameter_normal_candidate(
    frame: &crate::surface::PlaneLocalSystem,
    mirror_z: bool,
    mirror_origin_z: bool,
) -> Option<PlaneCandidate> {
    let [mut u_axis, second, mut normal, mut origin] = local_system_lanes(frame.complete_slots()?);
    if second.iter().any(|value| *value != 0.0) {
        return None;
    }
    if mirror_z {
        u_axis[2] = -u_axis[2];
        normal[2] = -normal[2];
    }
    if mirror_origin_z {
        origin[2] = -origin[2];
    }
    let u_magnitude = dot(u_axis, u_axis).sqrt();
    let normal_magnitude = dot(normal, normal).sqrt();
    let scale = u_magnitude.max(normal_magnitude).max(1.0);
    if !u_magnitude.is_finite()
        || !normal_magnitude.is_finite()
        || u_magnitude <= EPS_STORED_FRAME_NONZERO
        || normal_magnitude <= EPS_STORED_FRAME_NONZERO
        || (u_magnitude - normal_magnitude).abs() > EPS_STORED_FRAME_RELATIVE * scale
        || dot(u_axis, normal).abs() > EPS_STORED_FRAME_RELATIVE * u_magnitude * normal_magnitude
    {
        return None;
    }
    u_axis = u_axis.map(|value| value / u_magnitude);
    normal = normal.map(|value| value / normal_magnitude);
    Some(PlaneCandidate {
        equation: PlaneEquation { origin, normal },
        chart: Some(PlaneChart {
            origin,
            normal,
            u_axis,
        }),
        offset: frame.offset,
    })
}

fn stored_parameter_origin_sign_candidates(base: PlaneCandidate) -> ([PlaneCandidate; 8], usize) {
    let mut nonzero_axes = [0; 3];
    let mut axis_count = 0;
    for (axis, value) in base.equation.origin.into_iter().enumerate() {
        if value.abs() > EPS_STORED_FRAME_NONZERO
            && base.equation.normal[axis].abs() > EPS_STORED_FRAME_NONZERO
        {
            nonzero_axes[axis_count] = axis;
            axis_count += 1;
        }
    }
    let mut candidates = [base; 8];
    if axis_count == 0 {
        return (candidates, 1);
    }
    let mut count = 0;
    for mask in 0..(1usize << axis_count) {
        let mut candidate = base;
        for (bit, axis) in nonzero_axes[..axis_count].iter().copied().enumerate() {
            if mask & (1usize << bit) == 0 {
                continue;
            }
            candidate.equation.origin[axis] = -candidate.equation.origin[axis];
            if let Some(chart) = &mut candidate.chart {
                chart.origin[axis] = -chart.origin[axis];
            }
        }
        if candidate
            .equation
            .origin
            .iter()
            .all(|value| value.is_finite())
        {
            candidates[count] = candidate;
            count += 1;
        }
    }
    (candidates, count)
}

fn stored_parameter_normal_candidates_with_origin_branches(
    frame: &crate::surface::PlaneLocalSystem,
    include_origin_z_branches: bool,
) -> Option<([PlaneCandidate; 4], usize)> {
    if frame.classification == crate::surface::LocalSystemClassification::Simple
        || frame.layout != Some(crate::scalar::PlaneSupportFrameLayout::DirectNormalTriples)
    {
        return None;
    }
    let slots = frame.complete_slots()?;
    if slots[3..6].iter().any(|value| *value != 0.0) {
        return None;
    }
    let first = stored_parameter_normal_candidate(frame, false, false)?;
    let mut candidates = [first; 4];
    let mut count = 0;
    let origin_branches: &[bool] = if include_origin_z_branches {
        &[false, true]
    } else {
        &[false]
    };
    for mirror_z in [false, true] {
        for mirror_origin_z in origin_branches {
            let candidate = stored_parameter_normal_candidate(frame, mirror_z, *mirror_origin_z)?;
            if !candidates[..count]
                .iter()
                .any(|known| plane_candidates_equivalent(*known, candidate))
            {
                candidates[count] = candidate;
                count += 1;
            }
        }
    }
    (count > 1).then_some((candidates, count))
}

fn stored_parameter_normal_candidates(
    frame: &crate::surface::PlaneLocalSystem,
) -> Option<([PlaneCandidate; 4], usize)> {
    stored_parameter_normal_candidates_with_origin_branches(frame, false)
}

fn coordinate_vectors_agree(first: [f64; 3], second: [f64; 3]) -> bool {
    first.into_iter().zip(second).all(|(first, second)| {
        (first - second).abs() <= EPS_AGREE * first.abs().max(second.abs()).max(1.0)
    })
}

fn plane_candidates_equivalent(first: PlaneCandidate, second: PlaneCandidate) -> bool {
    agreed_plane(&[first.equation, second.equation]).is_some()
        && match (first.chart, second.chart) {
            (Some(first), Some(second)) => {
                coordinate_vectors_agree(first.origin, second.origin)
                    && coordinate_vectors_agree(first.normal, second.normal)
                    && coordinate_vectors_agree(first.u_axis, second.u_axis)
            }
            (None, None) => true,
            _ => false,
        }
}

fn plane_chart_point(candidate: PlaneCandidate, uv: [f64; 2]) -> Option<FinitePoint3> {
    let chart = candidate.chart?;
    let normal = normalize(chart.normal)?;
    let u_axis = normalize(chart.u_axis)?;
    (dot(normal, u_axis).abs() <= EPS_ORTHO).then_some(())?;
    let v_axis = cross(normal, u_axis);
    finite_model_point(std::array::from_fn(|axis| {
        chart.origin[axis] + uv[0] * u_axis[axis] + uv[1] * v_axis[axis]
    }))
}

fn pcurve_candidate_endpoint_witness(
    candidate: PlaneCandidate,
    adjacent: PlaneCandidate,
    endpoints: [[f64; 2]; 2],
) -> bool {
    if candidate.chart.is_none() {
        return false;
    }
    let Some(adjacent_normal) = normalize(adjacent.equation.normal) else {
        return false;
    };
    let Some(candidate_normal) = normalize(candidate.equation.normal) else {
        return false;
    };
    let cross_normals = cross(candidate_normal, adjacent_normal);
    if dot(cross_normals, cross_normals) <= EPS_ORTHO * EPS_ORTHO {
        return false;
    }
    let [Some(first), Some(second)] = endpoints.map(|uv| plane_chart_point(candidate, uv)) else {
        return false;
    };
    if model_points_agree(first, second) {
        return false;
    }
    [first, second].into_iter().all(|point| {
        point_on_carrier(
            <[f64; 3]>::from(point.get()),
            CarrierEquation::Plane(adjacent.equation),
        )
    })
}

fn pcurve_candidates_agree(
    first: PlaneCandidate,
    second: PlaneCandidate,
    endpoint_sets: [[[f64; 2]; 2]; 2],
) -> bool {
    pcurve_candidate_endpoint_witness(first, second, endpoint_sets[0])
        || pcurve_candidate_endpoint_witness(second, first, endpoint_sets[1])
}

#[derive(Clone, Copy)]
struct PlaneBranchConstraint {
    faces: [u32; 2],
    endpoint_sets: [[[f64; 2]; 2]; 2],
}

fn stored_frame_branch_constraints(
    scan: &ContainerScan,
    domains: &BTreeMap<u32, Vec<PlaneCandidate>>,
) -> Result<Vec<PlaneBranchConstraint>, cadmpeg_core::CodecError> {
    let mut constraints = Vec::new();
    let mut add = |faces: [Option<NonZeroU32>; 2],
                   endpoint_sets: [[[f64; 2]; 2]; 2]|
     -> Result<(), cadmpeg_core::CodecError> {
        let [Some(first), Some(second)] = faces else {
            return Ok(());
        };
        let faces = [first.get(), second.get()];
        if faces[0] == faces[1] {
            return Ok(());
        }
        let (Some(first), Some(second)) = (domains.get(&faces[0]), domains.get(&faces[1])) else {
            return Ok(());
        };
        let compatible = first
            .iter()
            .filter(|first| {
                second
                    .iter()
                    .any(|second| pcurve_candidates_agree(**first, *second, endpoint_sets))
            })
            .count();
        if compatible != 0 {
            constraints.push(PlaneBranchConstraint {
                faces,
                endpoint_sets,
            });
        }
        Ok(())
    };
    for pcurve in &scan.curves.pcurves {
        add(
            pcurve.faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            ),
        )?;
    }
    for pcurve in &scan.curves.bound_prototype_pcurves {
        add(
            pcurve.faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            ),
        )?;
    }
    for pcurve in scan.curves.legacy_two_chart_paths() {
        let faces = pcurve.faces.map(NonZeroU32::new);
        let (Some(first), Some(last)) = (pcurve.samples.first(), pcurve.samples.last()) else {
            continue;
        };
        add(
            faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                faces,
                [first[0], last[0]],
                [first[1], last[1]],
            ),
        )?;
    }
    Ok(constraints)
}

fn fc05_cylinder_branch_witnesses(
    scan: &ContainerScan,
) -> BTreeMap<u32, Vec<super::equations::CylinderEquation>> {
    let mut cylinder_frames = BTreeMap::new();
    for pair in &scan.curves.fc05_cylinder_cap_pairs {
        let Some(frame) = fc05_cap_pair_model_frame(scan, pair) else {
            continue;
        };
        let legacy = super::equations::CylinderEquation {
            origin: frame.origin,
            axis: frame.unit_vector(),
            ref_direction: frame.ref_direction,
            radius: pair.radius_mm,
        };
        let witness = fc05_cylinder_model_witness(scan, pair.surface_id, legacy);
        cylinder_frames.insert(pair.surface_id, witness);
    }

    for circle in &scan.curves.fc05_circles {
        let Some(topology) = scan
            .curves
            .topology_rows
            .iter()
            .find(|row| row.id == circle.curve_id)
        else {
            continue;
        };
        let mut planes = topology
            .bounded_face_ids()
            .filter(|face| {
                crate::surface::unique_surface_row(&scan.surfaces.rows, *face)
                    .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Plane)
            })
            .filter_map(|face| {
                crate::surface::unique_outline_plane(&scan.planes.outlines, face)
                    .map(|plane| (face, plane))
            });
        let mut cylinders = topology.bounded_face_ids().filter(|face| {
            crate::surface::unique_surface_row(&scan.surfaces.rows, *face)
                .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Cylinder)
        });
        let (Some((_, cap)), None, Some(cylinder_id), None) = (
            planes.next(),
            planes.next(),
            cylinders.next(),
            cylinders.next(),
        ) else {
            continue;
        };
        let Some(axis_index) = Axis::ALL
            .into_iter()
            .find(|axis| cap.normal()[axis.index()].abs() > 1.0 - EPS_FC05_CAP_AXIS)
        else {
            continue;
        };
        let (reference, axis_sign) = match circle.angle_parameter {
            crate::curve::Fc05AngleParameterRelation::Inconsistent => (
                circle.sample_direction_row_frame.get(),
                Sign::of_component(cap.normal()[axis_index.index()]),
            ),
            crate::curve::Fc05AngleParameterRelation::Consistent {
                sense,
                reference_direction_row_frame,
            } => (reference_direction_row_frame, Sign::from(sense).reversed()),
        };
        let (origin, axis, ref_direction) = fc05_model_frame(
            axis_index,
            cap.origin[axis_index.index()],
            circle.center_row_frame,
            reference,
            axis_sign,
        );
        if cylinder_frames.contains_key(&cylinder_id) {
            continue;
        }
        let legacy = super::equations::CylinderEquation {
            origin,
            axis,
            ref_direction,
            radius: circle.radius_mm,
        };
        let witness = fc05_cylinder_model_witness(scan, cylinder_id, legacy);
        cylinder_frames.insert(cylinder_id, witness);
    }

    let mut witnesses = BTreeMap::<u32, Vec<super::equations::CylinderEquation>>::new();
    for topology in &scan.curves.topology_rows {
        let Some((cylinder_id, plane_id)) = topology.bounded_face_ids().find_map(|first| {
            let second = topology
                .bounded_face_ids()
                .find(|candidate| *candidate != first)?;
            if cylinder_frames.contains_key(&first)
                && crate::surface::unique_surface_row(&scan.surfaces.rows, second)
                    .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Plane)
            {
                Some((first, second))
            } else if cylinder_frames.contains_key(&second)
                && crate::surface::unique_surface_row(&scan.surfaces.rows, first)
                    .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Plane)
            {
                Some((second, first))
            } else {
                None
            }
        }) else {
            continue;
        };
        let Some(cylinder) = cylinder_frames.get(&cylinder_id).copied() else {
            continue;
        };
        let entries = match witnesses.entry(plane_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        if !entries.iter().any(|known| {
            known.origin == cylinder.origin
                && known.axis == cylinder.axis
                && known.radius.to_bits() == cylinder.radius.to_bits()
        }) {
            entries.push(cylinder);
        }
    }
    witnesses
}

/// Select an FC05 cylinder frame only when reference geometry improves the
/// independent stored-plane tangency score. A validated cap pair remains the
/// primary frame source; this witness does not turn an ID match into geometry.
pub(in crate::decode) fn fc05_cylinder_model_witness(
    scan: &ContainerScan,
    cylinder_id: u32,
    legacy: super::equations::CylinderEquation,
) -> super::equations::CylinderEquation {
    let Some(reference) = fc05_reference_cylinder(scan, cylinder_id, legacy) else {
        return legacy;
    };
    if fc05_tangent_plane_score(scan, cylinder_id, reference)
        > fc05_tangent_plane_score(scan, cylinder_id, legacy)
    {
        reference
    } else {
        legacy
    }
}

fn fc05_reference_cylinder(
    scan: &ContainerScan,
    cylinder_id: u32,
    legacy: super::equations::CylinderEquation,
) -> Option<super::equations::CylinderEquation> {
    let mut curve_ids = BTreeSet::new();
    for curve_id in
        scan.curves
            .fc05_circles
            .iter()
            .filter(|circle| {
                scan.curves.topology_rows.iter().any(|topology| {
                    topology.id == circle.curve_id && topology.bounds_face(cylinder_id)
                })
            })
            .map(|circle| circle.curve_id)
    {
        curve_ids.insert(curve_id);
    }
    let mut circles = Vec::new();
    for curve_id in &curve_ids {
        for circle in scan
            .references
            .circles
            .iter()
            .filter(|circle| circle.entity_id == *curve_id)
        {
            circles.push(circle);
        }
    }
    let frame = fc05_reference_circle_frame(&circles)?;
    if (frame.radius().get() - legacy.radius).abs() > EPS_FC05_TANGENT_RESIDUAL
        || dot(frame.frame().axis(), legacy.axis).abs() < 1.0 - EPS_FC05_TANGENT_AXIS
    {
        return None;
    }
    let mut reference_origin = frame.frame().origin();
    if let Some(axis_index) = (0..3).find(|axis| legacy.axis[*axis].abs() > 1.0 - EPS_FC05_CAP_AXIS)
    {
        reference_origin[axis_index] = legacy.origin[axis_index];
    }
    Some(super::equations::CylinderEquation {
        origin: reference_origin,
        axis: legacy.axis,
        ref_direction: legacy.ref_direction,
        radius: legacy.radius,
    })
}

pub(in crate::decode) fn fc05_cylinder_resolved_plane_witness(
    scan: &ContainerScan,
    cylinder_id: u32,
    legacy: super::equations::CylinderEquation,
    ir: &CadIr,
    source_carriers: &crate::decode::source_carriers::SourceUnitCarriers,
) -> super::equations::CylinderEquation {
    let Some(reference) = fc05_reference_cylinder(scan, cylinder_id, legacy) else {
        return legacy;
    };
    let mut plane_ids = BTreeSet::new();
    for row in scan
        .curves
        .topology_rows
        .iter()
        .filter(|row| row.bounds_face(cylinder_id))
    {
        plane_ids.extend(row.bounded_face_ids().filter(|face| *face != cylinder_id));
    }
    let mut scores = [0usize; 2];
    let local_planes = BTreeMap::new();
    for face in plane_ids {
        let Some(equation) = reconciled_model_plane(&local_planes, ir, source_carriers, face)
        else {
            continue;
        };
        let candidate = PlaneCandidate {
            equation,
            chart: None,
            offset: 0,
        };
        for (score, cylinder) in scores.iter_mut().zip([legacy, reference]) {
            *score += usize::from(plane_candidate_is_fc05_tangent(candidate, cylinder));
        }
    }
    match scores[1].cmp(&scores[0]) {
        std::cmp::Ordering::Greater => reference,
        std::cmp::Ordering::Less => legacy,
        std::cmp::Ordering::Equal => fc05_cylinder_model_witness(scan, cylinder_id, legacy),
    }
}

fn fc05_reference_circle_frame(
    circles: &[&crate::reference::ReferenceCircle],
) -> Option<crate::surface::PositionalCylinderFrame> {
    if let Some(frame) =
        super::super::surfaces::cylinders::reference_circle_pair_cylinder_frame(circles)
    {
        return Some(frame);
    }
    let [circle] = circles else {
        return None;
    };
    if !circle.center_stored() {
        return None;
    }
    let radius = circle.radius().get();
    let axis = crate::vecmath::unit_length(circle.axis());
    let start: [f64; 3] = circle.start().get().into();
    let end: [f64; 3] = circle.end().get().into();
    let center: [f64; 3] = circle.center().get().into();
    let radial = std::array::from_fn(|index| start[index] - center[index]);
    let end_radial = std::array::from_fn(|index| end[index] - center[index]);
    let radial_length = dot(radial, radial).sqrt();
    let end_radial_length = dot(end_radial, end_radial).sqrt();
    let scale = center
        .into_iter()
        .chain(start)
        .chain(end)
        .map(f64::abs)
        .fold(radius.max(1.0), f64::max);
    if !radial_length.is_finite()
        || !end_radial_length.is_finite()
        || (radial_length - radius).abs() > EPS_FC05_TANGENT_RESIDUAL * scale
        || (end_radial_length - radius).abs() > EPS_FC05_TANGENT_RESIDUAL * scale
        || dot(axis, radial).abs() > EPS_FC05_TANGENT_RESIDUAL * scale
        || dot(axis, end_radial).abs() > EPS_FC05_TANGENT_RESIDUAL * scale
    {
        return None;
    }
    crate::surface::PositionalCylinderFrame::new(
        center,
        axis,
        radial.map(|value| value / radial_length),
        radius,
        None,
    )
}

fn fc05_tangent_plane_score(
    scan: &ContainerScan,
    cylinder_id: u32,
    cylinder: super::equations::CylinderEquation,
) -> usize {
    let mut plane_ids = BTreeSet::new();
    for plane_id in scan
        .curves
        .topology_rows
        .iter()
        .filter(|topology| topology.bounds_face(cylinder_id))
        .flat_map(CurveTopologyRow::bounded_face_ids)
        .filter(|face_id| *face_id != cylinder_id)
        .filter(|face_id| {
            crate::surface::unique_surface_row(&scan.surfaces.rows, *face_id)
                .is_some_and(|row| row.kind == crate::surface::SurfaceKind::Plane)
        })
    {
        plane_ids.insert(plane_id);
    }
    plane_ids
        .into_iter()
        .filter(|plane_id| {
            scan.planes
                .local_systems
                .iter()
                .filter(|frame| frame.surface_id == *plane_id)
                .filter_map(stored_parameter_normal_candidates)
                .flat_map(|(candidates, count)| candidates.into_iter().take(count))
                .any(|candidate| plane_candidate_is_fc05_tangent(candidate, cylinder))
        })
        .count()
}

fn plane_candidate_is_fc05_tangent(
    candidate: PlaneCandidate,
    cylinder: super::equations::CylinderEquation,
) -> bool {
    let Some(normal) = normalize(candidate.equation.normal) else {
        return false;
    };
    let Some(axis) = normalize(cylinder.axis) else {
        return false;
    };
    if dot(normal, axis).abs() > EPS_FC05_TANGENT_AXIS {
        return false;
    }
    let relative =
        std::array::from_fn(|index| cylinder.origin[index] - candidate.equation.origin[index]);
    let signed_distance = dot(normal, relative);
    (signed_distance.abs() - cylinder.radius).abs() <= EPS_FC05_TANGENT_RESIDUAL * cylinder.radius
}

fn plane_candidate_pcurve_lies_on_carrier(
    candidate: PlaneCandidate,
    endpoints: [[f64; 2]; 2],
    carrier: CarrierEquation,
) -> bool {
    let [Some(first), Some(second)] = endpoints.map(|uv| plane_chart_point(candidate, uv)) else {
        return false;
    };
    !model_points_agree(first, second)
        && [first, second]
            .into_iter()
            .all(|point| point_on_carrier(<[f64; 3]>::from(point.get()), carrier))
}

fn native_positional_cylinder_carriers(scan: &ContainerScan) -> BTreeMap<u32, CarrierEquation> {
    let parameters =
        crate::decode::uniqueness::UniqueById::new(&scan.surfaces.parameters, |record| {
            record.surface_id
        });
    let mut carriers = BTreeMap::new();
    for row in crate::identity::uniquely_identified_rows(&scan.surfaces.rows, |row| row.id) {
        if row.kind != crate::surface::SurfaceKind::Cylinder {
            continue;
        }
        let Some(frame) = parameters
            .get(row.id)
            .and_then(crate::surface::SurfaceParameterRecord::positional_cylinder_frame)
        else {
            continue;
        };
        carriers.insert(
            row.id,
            CarrierEquation::Cylinder(super::equations::CylinderEquation {
                origin: frame.frame().origin(),
                axis: frame.frame().axis(),
                ref_direction: frame.frame().ref_direction(),
                radius: frame.radius().get(),
            }),
        );
    }
    carriers
}

fn select_stored_frame_carrier_pcurve_branches(
    scan: &ContainerScan,
    variable_domains: &BTreeMap<u32, Vec<PlaneCandidate>>,
    domains: &mut BTreeMap<u32, Vec<PlaneCandidate>>,
) -> Result<(), cadmpeg_core::CodecError> {
    let carriers = native_positional_cylinder_carriers(scan);
    let mut apply = |faces: [Option<NonZeroU32>; 2],
                     endpoint_sets: [[[f64; 2]; 2]; 2]|
     -> Result<(), cadmpeg_core::CodecError> {
        let [Some(first), Some(second)] = faces else {
            return Ok(());
        };
        let faces = [first.get(), second.get()];
        for face_index in 0..2 {
            let plane_id = faces[face_index];
            let Some(options) = variable_domains.get(&plane_id) else {
                continue;
            };
            let Some(carrier) = carriers.get(&faces[1 - face_index]).copied() else {
                continue;
            };
            let mut retained = options.iter().copied().filter(|candidate| {
                plane_candidate_pcurve_lies_on_carrier(
                    *candidate,
                    endpoint_sets[face_index],
                    carrier,
                )
            });
            if let (Some(candidate), None) = (retained.next(), retained.next()) {
                let selected = vec![candidate];
                domains.insert(plane_id, selected);
            }
        }
        Ok(())
    };
    for pcurve in &scan.curves.pcurves {
        apply(
            pcurve.faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            ),
        )?;
    }
    for pcurve in &scan.curves.bound_prototype_pcurves {
        apply(
            pcurve.faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                pcurve.faces,
                pcurve.face_0_endpoints,
                pcurve.face_1_endpoints,
            ),
        )?;
    }
    for pcurve in scan.curves.legacy_two_chart_paths() {
        let faces = pcurve.faces.map(NonZeroU32::new);
        let (Some(first), Some(last)) = (pcurve.samples.first(), pcurve.samples.last()) else {
            continue;
        };
        apply(
            faces,
            super::pcurves::canonicalized_pcurve_endpoints(
                scan,
                faces,
                [first[0], last[0]],
                [first[1], last[1]],
            ),
        )?;
    }
    Ok(())
}

fn select_stored_frame_branches(
    scan: &ContainerScan,
    candidates: &mut BTreeMap<u32, Vec<PlaneCandidate>>,
    held_planes: &BTreeMap<u32, PlaneEquation>,
) -> Result<(), cadmpeg_core::CodecError> {
    let cylinder_witnesses = fc05_cylinder_branch_witnesses(scan);
    let mut variable_domains = BTreeMap::<u32, Vec<PlaneCandidate>>::new();
    let mut origin_domains = BTreeMap::<u32, Vec<PlaneCandidate>>::new();
    for frame in &scan.planes.local_systems {
        let Some((options, option_count)) = stored_parameter_normal_candidates(frame) else {
            continue;
        };
        if cylinder_witnesses.contains_key(&frame.surface_id) {
            if let Some((origin_options, origin_count)) =
                stored_parameter_normal_candidates_with_origin_branches(frame, true)
            {
                let known = match origin_domains.entry(frame.surface_id) {
                    std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
                    std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
                };
                for option in origin_options.into_iter().take(origin_count) {
                    if held_planes
                        .get(&frame.surface_id)
                        .is_some_and(|held| agreed_plane(&[option.equation, *held]).is_none())
                    {
                        continue;
                    }
                    if !known
                        .iter()
                        .any(|candidate| plane_candidates_equivalent(*candidate, option))
                    {
                        known.push(option);
                    }
                }
            }
        }
        let known = match variable_domains.entry(frame.surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        for option in options.into_iter().take(option_count) {
            if held_planes
                .get(&frame.surface_id)
                .is_some_and(|held| agreed_plane(&[option.equation, *held]).is_none())
            {
                continue;
            }
            if !known
                .iter()
                .any(|candidate| plane_candidates_equivalent(*candidate, option))
            {
                known.push(option);
            }
        }
    }
    for (surface_id, options) in origin_domains {
        let Some(witnesses) = cylinder_witnesses.get(&surface_id) else {
            continue;
        };
        let mut retained = options.into_iter().filter(|candidate| {
            witnesses
                .iter()
                .copied()
                .any(|cylinder| plane_candidate_is_fc05_tangent(*candidate, cylinder))
        });
        if let (Some(candidate), None) = (retained.next(), retained.next()) {
            let selected = vec![candidate];
            variable_domains.insert(surface_id, selected);
        }
    }
    if variable_domains.is_empty() {
        return Ok(());
    }

    let mut domains = BTreeMap::new();
    for (surface_id, options) in &variable_domains {
        let mut copied = Vec::new();
        copied.extend_from_slice(options);
        domains.insert(*surface_id, copied);
    }
    select_stored_frame_carrier_pcurve_branches(scan, &variable_domains, &mut domains)?;
    for (surface_id, options) in &variable_domains {
        let Some(witnesses) = cylinder_witnesses.get(surface_id) else {
            continue;
        };
        let mut retained = options.iter().copied().filter(|candidate| {
            witnesses
                .iter()
                .copied()
                .any(|cylinder| plane_candidate_is_fc05_tangent(*candidate, cylinder))
        });
        if let (Some(candidate), None) = (retained.next(), retained.next()) {
            let selected = vec![candidate];
            domains.insert(*surface_id, selected);
        }
    }
    for (surface_id, known) in candidates.iter() {
        let fixed = if known.len() == 1 {
            known
                .first()
                .copied()
                .filter(|candidate| candidate.chart.is_some())
        } else {
            agreed_plane_surface(known).map(|(equation, u_axis, offset)| PlaneCandidate {
                equation,
                chart: Some(PlaneChart {
                    origin: equation.origin,
                    normal: equation.normal,
                    u_axis,
                }),
                offset,
            })
        };
        if let Some(fixed) = fixed {
            if !domains.contains_key(surface_id) {
                let selected = vec![fixed];
                domains.insert(*surface_id, selected);
            }
        }
    }
    let constraints = stored_frame_branch_constraints(scan, &domains)?;

    let mut filtered = domains;
    loop {
        let mut changed = false;
        for constraint in &constraints {
            let Some(first) = filtered.get(&constraint.faces[0]) else {
                continue;
            };
            let Some(second) = filtered.get(&constraint.faces[1]) else {
                continue;
            };
            if variable_domains.contains_key(&constraint.faces[0]) {
                let mut retained = Vec::new();
                for candidate in first {
                    if second.iter().any(|other| {
                        pcurve_candidates_agree(*candidate, *other, constraint.endpoint_sets)
                    }) {
                        retained.push(*candidate);
                    }
                }
                if retained.is_empty() {
                    continue;
                }
                changed |= retained.len() != filtered[&constraint.faces[0]].len();
                filtered.insert(constraint.faces[0], retained);
            }
            if variable_domains.contains_key(&constraint.faces[1]) {
                let Some(first) = filtered.get(&constraint.faces[0]) else {
                    continue;
                };
                let Some(second) = filtered.get(&constraint.faces[1]) else {
                    continue;
                };
                let mut retained = Vec::new();
                for candidate in second {
                    if first.iter().any(|other| {
                        pcurve_candidates_agree(*other, *candidate, constraint.endpoint_sets)
                    }) {
                        retained.push(*candidate);
                    }
                }
                if retained.is_empty() {
                    continue;
                }
                changed |= retained.len() != filtered[&constraint.faces[1]].len();
                filtered.insert(constraint.faces[1], retained);
            }
        }
        if !changed {
            break;
        }
    }
    for surface_id in variable_domains.keys().copied() {
        let Some([candidate]) = filtered.get(&surface_id).map(Vec::as_slice) else {
            continue;
        };
        let selected = vec![*candidate];
        candidates.insert(surface_id, selected);
    }
    Ok(())
}

fn round_edge_endpoint_plane_score(
    candidate: PlaneCandidate,
    envelopes: &[crate::surface::Type24RoundEdgeEnvelope],
) -> usize {
    envelopes
        .iter()
        .filter(|envelope| {
            envelope.vertices.into_iter().any(|point| {
                let scale = point
                    .into_iter()
                    .chain(candidate.equation.origin)
                    .map(f64::abs)
                    .fold(1.0, f64::max);
                (dot(candidate.equation.normal, point)
                    - dot(candidate.equation.normal, candidate.equation.origin))
                .abs()
                    <= EPS_ON_CARRIER * scale
            })
        })
        .count()
}

fn unique_round_edge_origin_candidate(
    candidates: &[PlaneCandidate],
    envelopes: &[crate::surface::Type24RoundEdgeEnvelope],
) -> Option<PlaneCandidate> {
    let mut best = None;
    let mut maximum = 0;
    let mut tied = false;
    for candidate in candidates.iter().copied() {
        let score = round_edge_endpoint_plane_score(candidate, envelopes);
        if score > maximum {
            maximum = score;
            best = Some(candidate);
            tied = false;
        } else if score == maximum && score > 0 {
            tied = true;
        }
    }
    if maximum > 0 && !tied {
        best
    } else {
        None
    }
}

fn round_edge_envelopes_for_plane(
    scan: &ContainerScan,
    plane_id: u32,
    schema_classes: &crate::decode::sketch_transfer::recipe::FeatureSchemaClasses,
    parameters: &crate::decode::uniqueness::UniqueById<crate::surface::SurfaceParameterRecord>,
) -> Vec<crate::surface::Type24RoundEdgeEnvelope> {
    let mut rows = BTreeMap::new();
    for row in crate::identity::uniquely_identified_rows(&scan.surfaces.rows, |row| row.id) {
        rows.insert(row.id, row);
    }
    let mut envelopes = Vec::new();
    for topology in
        crate::identity::uniquely_identified_rows(&scan.curves.topology_rows, |row| row.id)
    {
        let envelope = (|| {
            let cylinder_id = topology.bounded_face_ids().find(|face_id| {
                *face_id != plane_id
                    && rows.get(face_id).is_some_and(|row| {
                        row.kind == crate::surface::SurfaceKind::Cylinder
                            && schema_classes.get(row.feature_id) == Some(SchemaClass::Round)
                    })
            })?;
            if !topology.bounds_face(plane_id) {
                return None;
            }
            let record = parameters.get(cylinder_id)?;
            record.type24_round_edge_envelope()
        })();
        if let Some(envelope) = envelope {
            envelopes.push(envelope);
        }
    }
    envelopes
}

fn select_round_edge_origin_branches(
    scan: &ContainerScan,
    candidates: &mut BTreeMap<u32, Vec<PlaneCandidate>>,
) {
    let schema_classes = crate::decode::sketch_transfer::recipe::FeatureSchemaClasses::new(scan);
    let parameters =
        crate::decode::uniqueness::UniqueById::new(&scan.surfaces.parameters, |record| {
            record.surface_id
        });
    for frame in &scan.planes.local_systems {
        let decoded_frame = frame.frame();
        if frame.classification != crate::surface::LocalSystemClassification::Simple {
            continue;
        }
        let Some(existing) = candidates.get(&frame.surface_id) else {
            continue;
        };
        let (Some(origin), Some(normal), Some(u_axis)) = (
            decoded_frame.origin,
            decoded_frame.normal(),
            decoded_frame.u_axis(),
        ) else {
            continue;
        };
        let base = PlaneCandidate {
            equation: PlaneEquation { origin, normal },
            chart: Some(PlaneChart {
                origin,
                normal,
                u_axis,
            }),
            offset: frame.offset,
        };
        if existing.len() != 1 || !plane_candidates_equivalent(existing[0], base) {
            continue;
        }
        let envelopes =
            round_edge_envelopes_for_plane(scan, frame.surface_id, &schema_classes, &parameters);
        let (options, count) = stored_parameter_origin_sign_candidates(base);
        let Some(selected) = unique_round_edge_origin_candidate(&options[..count], &envelopes)
        else {
            continue;
        };
        if let Some(existing) = candidates.get_mut(&frame.surface_id) {
            existing[0] = selected;
        }
    }
}

fn plane_candidates(
    scan: &ContainerScan,
) -> Result<BTreeMap<u32, Vec<PlaneCandidate>>, cadmpeg_core::CodecError> {
    let mut matrix_frame_ids = BTreeSet::new();
    for id in scan
        .planes
        .local_systems
        .iter()
        .filter(|frame| crate::surface::uses_matrix_column_frame(frame))
        .map(|frame| frame.surface_id)
    {
        matrix_frame_ids.insert(id);
    }
    let mut held_plane_groups = BTreeMap::<u32, Vec<PlaneEquation>>::new();
    for (surface_id, plane) in scan
        .planes
        .envelopes
        .iter()
        .filter_map(|envelope| Some((envelope.surface_id, held_coordinate_plane(envelope)?)))
    {
        let planes = match held_plane_groups.entry(surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        planes.push(plane);
    }
    let mut held_planes = BTreeMap::new();
    for (surface_id, planes) in held_plane_groups {
        if let Some(plane) = agreed_plane(&planes) {
            held_planes.insert(surface_id, plane);
        }
    }
    let mut frame_bound_outlines = BTreeMap::<u32, Vec<crate::surface::OutlinePlane>>::new();
    for outline in scan.planes.envelopes.iter().filter_map(|record| {
        crate::surface::frame_bound_outline_plane(record, &scan.planes.local_systems)
    }) {
        let outlines = match frame_bound_outlines.entry(outline.surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        outlines.push(outline);
    }
    let mut candidates = BTreeMap::<u32, Vec<PlaneCandidate>>::new();
    for frame in &scan.planes.local_systems {
        let decoded_frame = frame.frame();
        let (Some(origin), Some(normal)) = (decoded_frame.origin, decoded_frame.normal()) else {
            continue;
        };
        let Some(u_axis) = decoded_frame.u_axis() else {
            continue;
        };
        let frame_candidate = PlaneCandidate {
            equation: PlaneEquation { origin, normal },
            chart: Some(PlaneChart {
                origin,
                normal,
                u_axis,
            }),
            offset: frame.offset,
        };
        let candidate = frame_bound_outlines
            .get(&frame.surface_id)
            .and_then(|outlines| {
                let [outline] = outlines.as_slice() else {
                    return None;
                };
                frame_bound_outline_plane_candidate(frame, outline)
            })
            .or_else(|| {
                held_planes
                    .get(&frame.surface_id)
                    .filter(|held| agreed_plane(&[frame_candidate.equation, **held]).is_none())
                    .and_then(|held| envelope_reconciled_plane_candidate(frame, *held))
            })
            .unwrap_or(frame_candidate);
        let options = match candidates.entry(frame.surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        options.push(candidate);
    }
    let mut local_chart_ids = BTreeSet::new();
    for id in scan
        .planes
        .local_systems
        .iter()
        .filter(|frame| {
            let decoded_frame = frame.frame();
            decoded_frame.origin.is_some()
                && decoded_frame.normal.is_some()
                && decoded_frame.u_axis.is_some()
        })
        .map(|frame| frame.surface_id)
    {
        local_chart_ids.insert(id);
    }
    for outline in &scan.planes.outlines {
        if matrix_frame_ids.contains(&outline.surface_id) {
            continue;
        }
        let candidate = PlaneCandidate {
            equation: PlaneEquation {
                origin: outline.origin,
                normal: outline.normal(),
            },
            chart: (!local_chart_ids.contains(&outline.surface_id)).then_some(PlaneChart {
                origin: outline.origin,
                normal: outline.normal(),
                u_axis: outline.u_axis(),
            }),
            offset: outline.offset,
        };
        let options = match candidates.entry(outline.surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        options.push(candidate);
    }
    for envelope in &scan.planes.envelopes {
        if matrix_frame_ids.contains(&envelope.surface_id) {
            continue;
        }
        let Some(equation) = held_coordinate_plane(envelope) else {
            continue;
        };
        let candidate = PlaneCandidate {
            equation,
            chart: None,
            offset: envelope.offset,
        };
        let options = match candidates.entry(envelope.surface_id) {
            std::collections::btree_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::btree_map::Entry::Vacant(entry) => entry.insert(Vec::new()),
        };
        options.push(candidate);
    }
    for plane in &scan.planes.positional_frames {
        if candidates.contains_key(&plane.surface_id) {
            continue;
        }
        let options = vec![PlaneCandidate {
            equation: PlaneEquation {
                origin: plane.origin,
                normal: plane.normal(),
            },
            chart: Some(PlaneChart {
                origin: plane.origin,
                normal: plane.normal(),
                u_axis: plane.u_axis(),
            }),
            offset: plane.offset,
        }];
        candidates.insert(plane.surface_id, options);
    }
    select_stored_frame_branches(scan, &mut candidates, &held_planes)?;
    select_round_edge_origin_branches(scan, &mut candidates);
    candidates.retain(|id, _| {
        scan.surfaces
            .rows
            .iter()
            .filter(|row| row.id == *id)
            .take(2)
            .count()
            < 2
    });
    Ok(candidates)
}

fn frame_bound_outline_plane_candidate(
    frame: &crate::surface::PlaneLocalSystem,
    outline: &crate::surface::OutlinePlane,
) -> Option<PlaneCandidate> {
    (frame.surface_id == outline.surface_id).then_some(())?;
    let decoded_frame = frame.frame();
    let frame_normal = decoded_frame.normal()?;
    let frame_u_axis = decoded_frame.u_axis()?;
    let outline_normal = outline.normal();
    let outline_u_axis = outline.u_axis();
    (dot(frame_normal, outline_normal) >= 1.0 - EPS_AGREE).then_some(())?;
    (dot(frame_u_axis, outline_u_axis) >= 1.0 - EPS_AGREE).then_some(())?;
    let frame_origin = decoded_frame.origin?;
    let displacement = dot(outline_normal, outline.origin) - dot(outline_normal, frame_origin);
    let chart_origin =
        std::array::from_fn(|axis| displacement.mul_add(outline_normal[axis], frame_origin[axis]));
    Some(PlaneCandidate {
        equation: PlaneEquation {
            origin: outline.origin,
            normal: outline_normal,
        },
        chart: Some(PlaneChart {
            origin: chart_origin,
            normal: frame_normal,
            u_axis: frame_u_axis,
        }),
        offset: frame.offset,
    })
}

fn envelope_reconciled_plane_candidate(
    frame: &crate::surface::PlaneLocalSystem,
    equation: PlaneEquation,
) -> Option<PlaneCandidate> {
    let decoded_frame = frame.frame();
    let origin = decoded_frame.origin?;
    let normal = normalize(equation.normal)?;
    let origin_scale = origin
        .iter()
        .chain(equation.origin.iter())
        .map(|value| value.abs())
        .fold(1.0, f64::max);
    ((dot(normal, origin) - dot(normal, equation.origin)).abs() <= EPS_AGREE * origin_scale)
        .then_some(())?;
    let slots = frame.complete_slots()?;
    let supports = [
        <[f64; 3]>::try_from(&slots[0..3]).ok()?,
        <[f64; 3]>::try_from(&slots[3..6]).ok()?,
        <[f64; 3]>::try_from(&slots[6..9]).ok()?,
    ];
    let support_scale = supports
        .iter()
        .flatten()
        .map(|value| value.abs())
        .fold(1.0, f64::max);
    let mut nonzero = supports.into_iter().filter_map(|support| {
        let magnitude = dot(support, support).sqrt();
        (magnitude > EPS_AGREE * support_scale).then_some((support, magnitude))
    });
    let (Some(first), Some(second), None) = (nonzero.next(), nonzero.next(), nonzero.next()) else {
        return None;
    };
    let role = |(support, magnitude): ([f64; 3], f64)| {
        let alignment = dot(support, normal).abs() / magnitude;
        if alignment <= EPS_AGREE {
            Some((false, support.map(|value| value / magnitude)))
        } else if (alignment - 1.0).abs() <= EPS_AGREE {
            Some((true, support.map(|value| value / magnitude)))
        } else {
            None
        }
    };
    let (first_parallel, first_direction) = role(first)?;
    let (second_parallel, second_direction) = role(second)?;
    (first_parallel != second_parallel).then_some(())?;
    let u_axis = if first_parallel {
        second_direction
    } else {
        first_direction
    };
    Some(PlaneCandidate {
        equation,
        chart: Some(PlaneChart {
            origin,
            normal,
            u_axis,
        }),
        offset: frame.offset,
    })
}

fn held_coordinate_plane(envelope: &crate::surface::PlaneEnvelopeRecord) -> Option<PlaneEquation> {
    let corners = plane_envelope_corners(&envelope.envelope)?;
    let mut held = envelope
        .corner_coordinate_equal
        .iter()
        .enumerate()
        .filter_map(|(axis, equal)| (*equal == Some(true)).then_some(axis));
    let (Some(axis), None) = (held.next(), held.next()) else {
        return None;
    };
    envelope
        .corner_coordinate_equal
        .iter()
        .enumerate()
        .all(|(candidate, equal)| candidate == axis || *equal == Some(false))
        .then_some(())?;
    let mut normal = [0.0; 3];
    normal[axis] = 1.0;
    Some(PlaneEquation {
        origin: corners[0],
        normal,
    })
}

pub(in crate::decode) fn placed_planes(
    scan: &ContainerScan,
) -> Result<BTreeMap<u32, PlaneEquation>, cadmpeg_core::CodecError> {
    let mut placed = BTreeMap::new();
    for (id, candidates) in plane_candidates(scan)? {
        if let Some(plane) =
            agreed_plane_iter(candidates.iter().map(|candidate| candidate.equation))
        {
            placed.insert(id, plane);
        }
    }
    Ok(placed)
}

#[derive(Debug)]
pub(in crate::decode) struct PlacedPlaneSurface {
    pub(in crate::decode) plane: PlaneEquation,
    pub(in crate::decode) u_axis: [f64; 3],
    pub(in crate::decode) offset: usize,
}

pub(in crate::decode) fn placed_plane_surfaces(
    scan: &ContainerScan,
) -> Result<BTreeMap<u32, PlacedPlaneSurface>, cadmpeg_core::CodecError> {
    let mut placed = BTreeMap::new();
    for (id, candidates) in plane_candidates(scan)? {
        if let Some(surface) = agreed_plane_surface(&candidates) {
            let (plane, u_axis, offset) = surface;
            placed.insert(
                id,
                PlacedPlaneSurface {
                    plane,
                    u_axis,
                    offset,
                },
            );
        }
    }
    Ok(placed)
}

pub(super) fn topology_bound_plane(
    input_points: impl IntoIterator<Item = [f64; 3]>,
) -> Option<PlaneEquation> {
    let mut points = Vec::new();
    for point in input_points {
        points.push(point);
    }
    points.as_mut_slice().sort_by(|left, right| {
        left.iter()
            .zip(right)
            .find_map(|(left, right)| {
                let ordering = left.total_cmp(right);
                (ordering != std::cmp::Ordering::Equal).then_some(ordering)
            })
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    // A point outside the finite range agrees with no point.
    points.dedup_by(|left, right| {
        finite_model_point(*left)
            .zip(finite_model_point(*right))
            .is_some_and(|(left, right)| model_points_agree(left, right))
    });
    let &origin = points.first()?;
    let scale = points
        .iter()
        .flatten()
        .map(|value| value.abs())
        .fold(1.0, f64::max);
    let mut normal = None;
    'candidate: for first in 1..points.len() {
        for second in first + 1..points.len() {
            let first_direction = std::array::from_fn(|axis| points[first][axis] - origin[axis]);
            let second_direction = std::array::from_fn(|axis| points[second][axis] - origin[axis]);
            let Some(candidate) = normalize(cross(first_direction, second_direction)) else {
                continue;
            };
            normal = Some(candidate);
            break 'candidate;
        }
    }
    let mut normal = normal?;
    let leading = normal
        .iter()
        .find(|coordinate| coordinate.abs() > EPS_NEAR_ZERO)?;
    if *leading < 0.0 {
        normal = normal.map(|coordinate| -coordinate);
    }
    points
        .iter()
        .all(|point| {
            let displacement = std::array::from_fn(|axis| point[axis] - origin[axis]);
            dot(displacement, normal).abs() <= EPS_AGREE * scale
        })
        .then_some(PlaneEquation { origin, normal })
}

pub(super) fn analytic_curve_plane(geometry: &CurveGeometry) -> Option<PlaneEquation> {
    let (origin, normal) = match geometry {
        CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)) => {
            let center = circle_curve.center().get();
            (
                [center.x, center.y, center.z],
                unit_length(*circle_curve.frame().axis()),
            )
        }
        CurveGeometry::Solved(SolvedCurveGeometry::Ellipse(ellipse_curve)) => {
            let center = ellipse_curve.center().get();
            (
                [center.x, center.y, center.z],
                unit_length(*ellipse_curve.frame().axis()),
            )
        }
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs)) => {
            valid_positive_nurbs_curve(nurbs)?;
            let plane =
                topology_bound_plane(nurbs_points(nurbs).map(|point| [point.x, point.y, point.z]))?;
            (plane.origin, plane.normal)
        }
        _ => return None,
    };
    Some(PlaneEquation { origin, normal })
}

#[derive(Debug, Clone, Copy)]
pub(in crate::decode::analytic) struct BoundaryLine {
    pub(in crate::decode) origin: [f64; 3],
    pub(in crate::decode) direction: [f64; 3],
}

pub(super) fn analytic_boundary_line(geometry: &CurveGeometry) -> Option<BoundaryLine> {
    let (origin, direction) = match geometry {
        CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve)) => {
            let origin = line_curve.origin().get();
            (
                [origin.x, origin.y, origin.z],
                unit_length(line_curve.direction()),
            )
        }
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs)) => {
            (nurbs.degree() == 1 && !nurbs.periodic()).then_some(())?;
            valid_positive_nurbs_curve(nurbs)?;
            let first = nurbs.pole_rows().point_at(0)?;
            let last = nurbs
                .pole_rows()
                .point_at(nurbs.pole_count().checked_sub(1)?)?;
            let origin = [first.x, first.y, first.z];
            let direction = normalize([last.x - first.x, last.y - first.y, last.z - first.z])?;
            let scale = nurbs_points(nurbs)
                .flat_map(|point| [point.x, point.y, point.z])
                .map(f64::abs)
                .fold(1.0, f64::max);
            nurbs_points(nurbs)
                .map(|point| {
                    let relative = [
                        point.x - origin[0],
                        point.y - origin[1],
                        point.z - origin[2],
                    ];
                    let residual = cross(relative, direction);
                    dot(residual, residual).sqrt()
                })
                .all(|residual| residual <= EPS_AGREE * scale)
                .then_some(())?;
            (origin, direction)
        }
        _ => return None,
    };
    Some(BoundaryLine { origin, direction })
}

pub(in crate::decode) fn valid_positive_nurbs_curve(nurbs: &NurbsCurve) -> Option<()> {
    nurbs_intrinsic_parameter_range(nurbs)?;
    nurbs_weights_positive(nurbs).then_some(())
}

fn topology_bound_line_plane(lines: &[BoundaryLine]) -> Option<PlaneEquation> {
    let mut candidate = None;
    'pairs: for first in 0..lines.len() {
        for second in first + 1..lines.len() {
            let direction_cross = cross(lines[first].direction, lines[second].direction);
            let displacement =
                std::array::from_fn(|axis| lines[second].origin[axis] - lines[first].origin[axis]);
            let normal = normalize(direction_cross)
                .or_else(|| normalize(cross(lines[first].direction, displacement)));
            if let Some(normal) = normal {
                candidate = Some(PlaneEquation {
                    origin: lines[first].origin,
                    normal,
                });
                break 'pairs;
            }
        }
    }
    let candidate = candidate?;
    let canonical = agreed_plane(&[candidate])?;
    lines
        .iter()
        .all(|line| {
            point_on_carrier(line.origin, CarrierEquation::Plane(canonical))
                && dot(line.direction, canonical.normal).abs() <= EPS_AGREE
        })
        .then_some(canonical)
}

pub(super) fn agreed_topology_bound_plane(
    points: impl IntoIterator<Item = [f64; 3]>,
    curve_planes: impl IntoIterator<Item = PlaneEquation>,
    lines: impl IntoIterator<Item = BoundaryLine>,
) -> Option<PlaneEquation> {
    let mut admitted_points = Vec::new();
    for point in points {
        admitted_points.push(point);
    }
    let mut admitted_lines = Vec::new();
    for line in lines {
        admitted_lines.push(line);
    }
    let mut candidates = Vec::new();
    for candidate in topology_bound_plane(admitted_points.iter().copied())
        .into_iter()
        .chain(curve_planes)
        .chain(topology_bound_line_plane(&admitted_lines))
    {
        candidates.push(candidate);
    }
    let plane = agreed_plane(&candidates)?;
    let points_agree = admitted_points
        .iter()
        .all(|point| point_on_carrier(*point, CarrierEquation::Plane(plane)));
    let lines_agree = admitted_lines.iter().all(|line| {
        point_on_carrier(line.origin, CarrierEquation::Plane(plane))
            && dot(line.direction, plane.normal).abs() <= EPS_AGREE
    });
    (points_agree && lines_agree).then_some(plane)
}

#[cfg(test)]
mod reconciliation_tests;

#[cfg(test)]
mod solver_tests;
