// SPDX-License-Identifier: Apache-2.0

use std::collections::{BTreeMap, BTreeSet};

use super::super::equations::{CarrierEquation, PlaneEquation};
use super::{
    existing_plane_agrees_with_topology, placed_carriers, topology_bound_face_points,
    transfer_topology_bound_planes,
};
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::geometry::{
    Curve, CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, Surface, SurfaceGeometry,
};
use cadmpeg_ir::ids::{CurveId, SurfaceId};
use cadmpeg_ir::math::{Point3, Vector3};

mod orientations;

fn carrier_surface(id: u32, geometry: SurfaceGeometry) -> Surface {
    Surface {
        id: SurfaceId::mint(format!("creo:visibgeom:surface#{id}")).expect("identity grammar"),
        geometry,
        source_object: None,
        native_ref: None,
    }
}

fn cylinder_surface(id: u32, radius: f64) -> Surface {
    carrier_surface(
        id,
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                radius,
            )
            .expect("valid CylinderSurface fixture"),
        )),
    )
}

fn carrier_row(id: u32, kind: crate::surface::SurfaceKind) -> crate::surface::SurfaceRow {
    crate::surface::SurfaceRow {
        id,
        kind,
        feature_id: 1,
        reversed: false,
        boundary_type: crate::surface::BoundaryType::Code01,
        next_surface: 0,
        offset: 0,
    }
}

#[test]
fn topology_bound_face_points_match_a_per_face_scan() {
    let solved_vertices = BTreeMap::from([
        (0, [0.0, 0.0, 0.0]),
        (1, [1.0, 0.0, 0.0]),
        (2, [2.0, 0.0, 0.0]),
        (3, [3.0, 0.0, 0.0]),
        (5, [5.0, 0.0, 0.0]),
    ]);
    let vertex = |id| std::num::NonZeroU32::new(id).expect("one-based vertex fixture");
    let vertex_faces = BTreeMap::from([
        (vertex(1), BTreeSet::from([5, 6])),
        (vertex(2), BTreeSet::from([6])),
        (vertex(3), BTreeSet::from([0, 5, 7])),
        (vertex(4), BTreeSet::from([5])),
    ]);
    let points = topology_bound_face_points(&solved_vertices, &vertex_faces);
    for face_id in 0..=8 {
        let mut scanned = Vec::new();
        for (vertex_id, point) in &solved_vertices {
            if std::num::NonZeroU32::new(*vertex_id)
                .and_then(|id| vertex_faces.get(&id))
                .is_some_and(|faces| faces.contains(&face_id))
            {
                scanned.push(*point);
            }
        }
        assert_eq!(
            points.get(&face_id).cloned().unwrap_or_default(),
            scanned,
            "{face_id}"
        );
    }
}

#[test]
fn native_surface_lookups_match_the_identity_matcher_scan() {
    use super::super::super::surfaces::NativeSurfaceNamespaces;
    use super::super::pcurves::{ModelSurfaceIndex, ModelSurfacePositions, NamedSurfaces};
    use crate::surface::SurfaceKind;

    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .extend([1, 2, 2, 5].map(|id| carrier_row(id, SurfaceKind::Plane)));
    scan.surfaces
        .nonvisible_rows
        .extend([2, 3, 4].map(|id| carrier_row(id, SurfaceKind::Plane)));
    for id in [4, 6] {
        scan.planes
            .datum_cylinders
            .push(crate::datum::DatumCylinder {
                id,
                feature_id: 1,
                reversed: false,
                frame: crate::surface::PositionalCylinderFrame::new(
                    [0.0, 0.0, 0.0],
                    [0.0, 0.0, 1.0],
                    [1.0, 0.0, 0.0],
                    1.0,
                    None,
                )
                .expect("valid positional cylinder frame"),
                offset_in_payload: 0,
            });
    }
    let mut ir = CadIr::empty();
    for id in [
        "creo:visibgeom:surface#1",
        "creo:visibgeom:surface#2",
        "creo:novisgeom:surface#2",
        "creo:visibgeom:surface#02",
        "creo:novisgeom:surface#3",
        "creo:novisgeom:surface#4",
        "creo:actdatums:surface#4",
        "creo:visibgeom:surface#5",
        "creo:visibgeom:surface#5",
        "creo:actdatums:surface#6",
        "creo:visibgeom:surface#6",
        "creo:visibgeom:surface#7",
        "creo:novisgeom:surface#8",
    ] {
        let mut surface = cylinder_surface(0, 1.0);
        surface.id = SurfaceId::mint(id.to_owned()).expect("identity grammar");
        ir.geometry.surfaces.push(surface);
    }
    let namespaces = NativeSurfaceNamespaces::new(&scan);
    let scanned = |surfaces: &[Surface], id: u32| {
        let prefix = namespaces.prefix(id);
        let mut matches = surfaces.iter().enumerate().filter(|(_, surface)| {
            crate::identity::matches_numbered_identity(surface.id.as_str(), prefix, id)
        });
        match (matches.next(), matches.next()) {
            (None, _) => None,
            (Some((position, _)), None) => Some(Some(position)),
            (Some(_), Some(_)) => Some(None),
        }
    };
    let as_option = |named: NamedSurfaces<usize>| match named {
        NamedSurfaces::Unique(position) => Some(position),
        NamedSurfaces::Duplicate => None,
    };
    let index = ModelSurfaceIndex::new(&ir.geometry.surfaces);
    for id in 0..=9 {
        let indexed = index
            .named(namespaces.prefix(id), id)
            .map(|named| match named {
                NamedSurfaces::Unique(surface) => ir
                    .geometry
                    .surfaces
                    .iter()
                    .position(|candidate| std::ptr::eq(candidate, surface)),
                NamedSurfaces::Duplicate => None,
            });
        assert_eq!(indexed, scanned(&ir.geometry.surfaces, id), "{id}");
    }

    let mut positions = ModelSurfacePositions::new(&ir.geometry.surfaces[..3]);
    for appended in 3..=ir.geometry.surfaces.len() {
        let surfaces = &ir.geometry.surfaces[..appended];
        for id in 0..=9 {
            assert_eq!(
                positions.named(namespaces.prefix(id), id).map(as_option),
                scanned(surfaces, id),
                "{id} after {appended} surfaces"
            );
        }
        if appended < ir.geometry.surfaces.len() {
            positions.admit(&ir.geometry.surfaces, appended);
        }
    }
}

#[test]
fn topology_bound_face_points_collect_face_vertices() {
    let solved_vertices = BTreeMap::from([(1, [2.0, 3.0, 4.0])]);
    let vertex_faces = BTreeMap::from([(
        std::num::NonZeroU32::new(1).expect("one-based vertex fixture"),
        BTreeSet::from([5]),
    )]);
    let points = topology_bound_face_points(&solved_vertices, &vertex_faces);
    assert_eq!(points, BTreeMap::from([(5, vec![[2.0, 3.0, 4.0]])]));
}

fn topology_plane() -> PlaneEquation {
    PlaneEquation {
        origin: [0.0, 0.0, 4.0],
        normal: [0.0, 0.0, 1.0],
    }
}

#[test]
fn existing_plane_carrier_accepts_reversed_normal() {
    let existing = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 4.0),
            Vector3::new(0.0, 0.0, -1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));

    assert_eq!(
        existing_plane_agrees_with_topology(&existing, topology_plane()),
        Some(true)
    );
}

#[test]
fn existing_plane_carrier_rejects_offset_conflict() {
    let existing = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 5.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));

    assert_eq!(
        existing_plane_agrees_with_topology(&existing, topology_plane()),
        Some(false)
    );
}

#[test]
fn existing_unknown_carrier_does_not_compete_with_topology() {
    let existing = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });

    assert_eq!(
        existing_plane_agrees_with_topology(&existing, topology_plane()),
        None
    );
}

#[test]
fn existing_non_plane_carrier_conflicts_with_topology() {
    let existing = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(
        cadmpeg_ir::geometry::analytic::SphereSurface::try_new(
            Point3::new(0.0, 0.0, 4.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            2.0,
        )
        .expect("valid SphereSurface fixture"),
    ));

    assert_eq!(
        existing_plane_agrees_with_topology(&existing, topology_plane()),
        Some(false)
    );
}

#[test]
fn placed_carriers_reject_duplicate_model_surface_ids() {
    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .push(carrier_row(7, crate::surface::SurfaceKind::Cylinder));
    let mut ir = CadIr::empty();
    ir.geometry
        .surfaces
        .extend([cylinder_surface(7, 2.0), cylinder_surface(7, 3.0)]);

    assert!(!crate::decode::with_service_context(|ctx| placed_carriers(
        ctx,
        &scan,
        &ir,
        &crate::decode::source_carriers::SourceUnitCarriers::default()
    ))
    .expect("resolve the placed carriers")
    .contains_key(&7));
}

#[test]
fn placed_carriers_prefers_unique_positional_cylinder_frame() {
    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .push(carrier_row(7, crate::surface::SurfaceKind::Cylinder));
    scan.surfaces
        .parameters
        .push(crate::surface::SurfaceParameterRecord {
            surface_id: 7,
            body: Vec::new(),
            scalar_tokens: Vec::new(),
            opaque_spans: Vec::new(),
            scalar_frames: Vec::new(),
            carrier: crate::surface::SurfaceParameterCarrier::Resolved(
                crate::surface::InlineSurfaceCarrier::Cylinder {
                    frame: crate::surface::PositionalCylinderFrame::new(
                        [-12.5, 4.0, 0.0],
                        [0.0, 1.0, 0.0],
                        [1.0, 0.0, 0.0],
                        0.75,
                        Some(34.0),
                    )
                    .expect("valid positional cylinder frame"),
                    split_bounds: None,
                },
            ),
            boundary: crate::surface::SurfaceBodyBoundary::CompoundClose,
            offset: 0,
            type26_minor_radius: crate::surface::InlineType26MinorRadius::Absent,
            body_offset: 0,
        });
    let mut ir = CadIr::empty();
    ir.geometry.surfaces.push(cylinder_surface(7, 0.75));
    ir.geometry.surfaces[0].geometry = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
        cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
            Point3::new(0.0, 0.0, 12.5),
            Vector3::new(0.0, -1.0, 0.0),
            Vector3::new(0.0, 0.0, -1.0),
            0.75,
        )
        .expect("valid CylinderSurface fixture"),
    ));

    let carriers = crate::decode::with_service_context(|ctx| {
        placed_carriers(
            ctx,
            &scan,
            &ir,
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
    })
    .expect("resolve the placed carriers");
    assert!(matches!(
        carriers.get(&7),
        Some(CarrierEquation::Cylinder(cylinder))
            if cylinder.origin == [-12.5, 4.0, 0.0]
                && cylinder.axis == [0.0, 1.0, 0.0]
                && cylinder.ref_direction == [1.0, 0.0, 0.0]
                && cylinder.radius == 0.75
    ));
}

#[test]
fn placed_carriers_keeps_non_inline_class913_model_carrier() {
    let mut scan = crate::test_support::empty_container_scan();
    scan.features.rows.push(crate::feature::rows::FeatureRow {
        feature_id: 913,
        root_schema_class: Some(crate::feature::schema::SchemaClass::Round),
        stream_offset: 0,
        body: vec![0; 2].try_into().expect("row body"),
        body_offset: 0,
        offset: 0,
    });
    let mut row = carrier_row(7, crate::surface::SurfaceKind::Cylinder);
    row.feature_id = 913;
    scan.surfaces.rows.push(row);
    scan.surfaces
        .parameters
        .push(crate::surface::SurfaceParameterRecord {
            surface_id: 7,
            body: Vec::new(),
            scalar_tokens: Vec::new(),
            opaque_spans: Vec::new(),
            scalar_frames: Vec::new(),
            carrier: crate::surface::SurfaceParameterCarrier::Resolved(
                crate::surface::InlineSurfaceCarrier::Cylinder {
                    frame: crate::surface::PositionalCylinderFrame::new(
                        [-30.0, 6.5, -14.0],
                        [
                            std::f64::consts::FRAC_1_SQRT_2,
                            0.0,
                            std::f64::consts::FRAC_1_SQRT_2,
                        ],
                        [0.0, -1.0, 0.0],
                        0.8,
                        Some(0.282_842_712_474_619),
                    )
                    .expect("valid positional cylinder frame"),
                    split_bounds: None,
                },
            ),
            boundary: crate::surface::SurfaceBodyBoundary::CompoundClose,
            offset: 0,
            type26_minor_radius: crate::surface::InlineType26MinorRadius::Absent,
            body_offset: 0,
        });
    let mut ir = CadIr::empty();
    ir.geometry.surfaces.push(cylinder_surface(7, 0.2));

    let carriers = crate::decode::with_service_context(|ctx| {
        placed_carriers(
            ctx,
            &scan,
            &ir,
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
    })
    .expect("resolve the placed carriers");
    assert!(matches!(
        carriers.get(&7),
        Some(CarrierEquation::Cylinder(cylinder)) if cylinder.origin == [0.0, 0.0, 0.0]
            && cylinder.axis == [0.0, 0.0, 1.0]
            && cylinder.radius == 0.2
    ));
}

#[test]
fn duplicate_model_surface_ids_remove_native_carrier() {
    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .push(carrier_row(7, crate::surface::SurfaceKind::Plane));
    scan.planes
        .positional_frames
        .push(crate::surface::OutlinePlane {
            surface_id: 7,
            origin: [0.0, 0.0, 0.0],
            normal: cadmpeg_ir::units::UnitVector3::Z_AXIS,
            u_axis: cadmpeg_ir::units::UnitVector3::X_AXIS,
            offset: 0,
        });
    let mut ir = CadIr::empty();
    ir.geometry.surfaces.extend([
        carrier_surface(
            7,
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
        ),
        carrier_surface(
            7,
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 1.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
        ),
    ]);

    assert!(!crate::decode::with_service_context(|ctx| placed_carriers(
        ctx,
        &scan,
        &ir,
        &crate::decode::source_carriers::SourceUnitCarriers::default()
    ))
    .expect("resolve the placed carriers")
    .contains_key(&7));
}

#[test]
fn placed_carriers_admits_unique_rowless_model_surface() {
    let scan = crate::test_support::empty_container_scan();
    let mut ir = CadIr::empty();
    ir.geometry.surfaces.push(cylinder_surface(7, 2.0));

    let carriers = crate::decode::with_service_context(|ctx| {
        placed_carriers(
            ctx,
            &scan,
            &ir,
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
    })
    .expect("resolve the placed carriers");
    assert!(matches!(
        carriers.get(&7),
        Some(CarrierEquation::Cylinder(cylinder)) if cylinder.radius == 2.0
    ));
}

#[test]
fn placed_carriers_resolve_each_row_namespace_once() {
    // Selecting the row namespace again for every candidate surface would
    // visit about ROWS * ROWS * ROWS / 2 = 4e9 surface rows here.
    const ROWS: u32 = 2_000;
    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .extend((1..=ROWS).map(|id| carrier_row(id, crate::surface::SurfaceKind::Cylinder)));
    let mut ir = CadIr::empty();
    ir.geometry
        .surfaces
        .extend((1..=ROWS).map(|id| cylinder_surface(id, f64::from(id))));

    let carriers = crate::decode::with_service_context(|ctx| {
        placed_carriers(
            ctx,
            &scan,
            &ir,
            &crate::decode::source_carriers::SourceUnitCarriers::default(),
        )
    })
    .expect("resolve the placed carriers");
    assert_eq!(carriers.len(), 2_000);
    assert!((1..=ROWS).all(|id| matches!(
        carriers.get(&id),
        Some(CarrierEquation::Cylinder(cylinder)) if cylinder.radius == f64::from(id)
    )));
}

#[test]
fn placed_carriers_rejects_duplicate_rowless_model_surface_ids() {
    let scan = crate::test_support::empty_container_scan();
    let mut ir = CadIr::empty();
    ir.geometry
        .surfaces
        .extend([cylinder_surface(7, 2.0), cylinder_surface(7, 3.0)]);

    assert!(!crate::decode::with_service_context(|ctx| placed_carriers(
        ctx,
        &scan,
        &ir,
        &crate::decode::source_carriers::SourceUnitCarriers::default()
    ))
    .expect("resolve the placed carriers")
    .contains_key(&7));
}

#[test]
fn loop_classifier_rejects_inner_edge_crossing_concave_outer() {
    let outer = crate::test_support::closed_loop(
        std::num::NonZeroU32::new(5),
        (0..8)
            .map(|index| crate::topology::HalfEdgeId {
                curve_id: 10 + index,
                side: crate::topology::Side::Zero,
            })
            .collect(),
    );
    let inner = crate::test_support::closed_loop(
        std::num::NonZeroU32::new(5),
        (0..3)
            .map(|index| crate::topology::HalfEdgeId {
                curve_id: 20 + index,
                side: crate::topology::Side::Zero,
            })
            .collect(),
    );
    let vertices = [
        (1, [0.0, 0.0, 0.0]),
        (2, [6.0, 0.0, 0.0]),
        (3, [6.0, 1.0, 0.0]),
        (4, [2.0, 1.0, 0.0]),
        (5, [2.0, 5.0, 0.0]),
        (6, [6.0, 5.0, 0.0]),
        (7, [6.0, 6.0, 0.0]),
        (8, [0.0, 6.0, 0.0]),
        (9, [1.0, 0.5, 0.0]),
        (10, [5.0, 0.5, 0.0]),
        (11, [5.0, 5.5, 0.0]),
    ];
    let bindings = outer
        .half_edges()
        .iter()
        .copied()
        .zip(1..=8)
        .chain(inner.half_edges().iter().copied().zip(9..=11))
        .map(
            |(half_edge, start_vertex_id)| crate::topology::HalfEdgeVertexIncidence {
                half_edge,
                start_vertex_id: std::num::NonZeroU32::new(start_vertex_id)
                    .expect("one-based vertex fixture"),
                end_vertex_id: None,
            },
        )
        .collect::<Vec<_>>();
    let incidence = bindings
        .iter()
        .map(|binding| (binding.half_edge, binding))
        .collect::<BTreeMap<_, _>>();
    let solved_vertices = vertices.into_iter().collect::<BTreeMap<_, _>>();

    assert!(super::ordered_planar_face_loops(
        vec![&outer, &inner],
        PlaneEquation {
            origin: [0.0, 0.0, 0.0],
            normal: [0.0, 0.0, 1.0],
        },
        &incidence,
        &solved_vertices
    )
    .is_none());
}

#[test]
fn parameter_loop_classifier_orders_unique_outer() {
    let outer = crate::test_support::closed_loop(
        std::num::NonZeroU32::new(5),
        (0..4)
            .map(|index| crate::topology::HalfEdgeId {
                curve_id: 10 + index,
                side: crate::topology::Side::Zero,
            })
            .collect(),
    );
    let inner = crate::test_support::closed_loop(
        std::num::NonZeroU32::new(5),
        (0..4)
            .map(|index| crate::topology::HalfEdgeId {
                curve_id: 20 + index,
                side: crate::topology::Side::Zero,
            })
            .collect(),
    );
    let outer_polygon = vec![[-2.0, -2.0], [2.0, -2.0], [2.0, 2.0], [-2.0, 2.0]];
    let inner_polygon = vec![[-1.0, -1.0], [1.0, -1.0], [1.0, 1.0], [-1.0, 1.0]];

    let ordered = {
        super::ordered_parameter_face_loops(
            vec![&inner, &outer],
            &[inner_polygon.clone(), outer_polygon.clone()],
        )
    }
    .expect("order the parameter face loops");
    assert_eq!(ordered[0].half_edges()[0].curve_id, 10);
    assert_eq!(ordered[1].half_edges()[0].curve_id, 20);

    assert!(super::ordered_parameter_face_loops(
        vec![&outer, &inner],
        &[
            outer_polygon,
            vec![[3.0, 3.0], [4.0, 3.0], [4.0, 4.0], [3.0, 4.0]]
        ]
    )
    .is_none());
}

#[test]
fn topology_bound_plane_rejects_duplicate_model_curve_ids() {
    let mut scan = crate::test_support::empty_container_scan();
    scan.surfaces
        .rows
        .push(carrier_row(5, crate::surface::SurfaceKind::Plane));
    scan.curves
        .topology_rows
        .push(crate::curve::CurveTopologyRow {
            id: 11,
            type_byte: 0,
            feature_id: 1,
            directions: [0; 2],
            faces: [std::num::NonZeroU32::new(5), None],
            next_edges: [11, 0],
            offset: 20,
        });
    scan.topology.loops.push(crate::test_support::closed_loop(
        std::num::NonZeroU32::new(5),
        vec![crate::topology::HalfEdgeId {
            curve_id: 11,
            side: crate::topology::Side::Zero,
        }],
    ));

    let curve = Curve {
        parameter_range: None,
        id: CurveId::mint("creo:visibgeom:curve#11".to_string()).expect("identity grammar"),
        geometry: CurveGeometry::Solved(SolvedCurveGeometry::Circle(
            cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                Point3::new(2.0, 3.0, 4.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                5.0,
            )
            .expect("valid CircleCurve fixture"),
        )),
        source_object: None,
        native_ref: None,
    };
    let mut ir = CadIr::empty();
    ir.geometry.curves.extend([curve.clone(), curve]);

    assert_eq!(
        crate::decode::with_service_context(|ctx| transfer_topology_bound_planes(
            ctx,
            &scan,
            &mut ir,
            &mut cadmpeg_ir::annotations::AnnotationBuilder::new(),
            &std::collections::BTreeSet::new(),
            &mut crate::decode::source_carriers::SourceUnitCarriers::default(),
        ))
        .expect("valid source object identity"),
        0
    );
    assert!(ir.geometry.surfaces.is_empty());
}

#[test]
fn a_geometry_section_holds_every_offset_up_to_its_end_and_none_past_it() {
    let mut scan = crate::test_support::empty_container_scan();
    let section =
        crate::container::Section::scan("VisibGeom".to_string(), 16, 48, None, &[0u8; 48])
            .expect("section extent")
            .section;
    let end = section.end();
    scan.framing.sections.push(section);

    // The last byte the section states is inside it; the byte one past its end
    // is not, and no other section states it either.
    let record =
        |offset| super::geometry_section_record(&scan, offset).expect("section identity is minted");
    assert!(record(end - 1).is_some());
    assert!(record(end).is_none());
    assert!(record(15).is_none());
    assert!(record(16).is_some());
}

mod predicates;
