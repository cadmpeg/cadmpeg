// SPDX-License-Identifier: Apache-2.0
//! Decode source attribute chains into typed attribute values, colors, names,
//! and transforms.

use crate::ids::{brep_id, IdFormat};
use crate::nurbs::reader::LEN_TO_MM;
use crate::sab::{Record, Token};
use cadmpeg_ir::attributes::{AttributeTarget, AttributeValue, SourceAttribute};
use cadmpeg_ir::ids::{AttributeId, Identity, IdentityComponent, UnknownId};
use cadmpeg_ir::topology::Color;
use std::collections::{hash_map::RandomState, HashMap, HashSet};

/// Follow `entity`'s attribute chain, emitting each record not yet in
/// `emitted` as a [`SourceAttribute`] bound to `target`.
pub fn collect_attributes(
    entity: &Record,
    target: &AttributeTarget,
    by_index: &HashMap<i64, &Record, RandomState>,
    emitted: &mut HashSet<i64, RandomState>,
    out: &mut Vec<SourceAttribute>,
    format: IdFormat,
) -> Result<(), cadmpeg_core::CodecError> {
    let mut current = entity.ref_at(0);
    let mut chain = HashSet::new();
    while let Some(index) = current {
        if !chain.insert(index) {
            break;
        }
        let Some(record) = by_index.get(&index) else {
            break;
        };
        if emitted.insert(index) {
            out.push(source_attribute(record, target.clone(), format)?);
        }
        current = attribute_next(record);
    }
    Ok(())
}

fn is_integer(token: Option<&Token>) -> bool {
    matches!(
        token,
        Some(Token::Char(_) | Token::Short(_) | Token::Long(_) | Token::Enum(_) | Token::Int64(_))
    )
}

#[derive(Clone, Copy)]
enum AttributeBase {
    Current,
    Legacy,
    Compact,
}

impl AttributeBase {
    fn next(self) -> usize {
        match self {
            Self::Current => 2,
            Self::Legacy => 1,
            Self::Compact => 0,
        }
    }

    fn owner(self) -> Option<usize> {
        match self {
            Self::Current => Some(4),
            Self::Legacy => Some(3),
            Self::Compact => None,
        }
    }

    fn payload(self) -> usize {
        match self {
            Self::Current => 5,
            Self::Legacy => 4,
            Self::Compact => 1,
        }
    }
}

fn attribute_base(record: &Record) -> Option<AttributeBase> {
    let current = matches!(
        (
            record.chunk(0),
            record.chunk(2),
            record.chunk(3),
            record.chunk(4),
        ),
        (
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
        )
    ) && is_integer(record.chunk(1));
    if current {
        return Some(AttributeBase::Current);
    }
    let legacy = matches!(
        (
            record.chunk(0),
            record.chunk(1),
            record.chunk(2),
            record.chunk(3),
        ),
        (
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
            Some(Token::Ref(_)),
        )
    );
    if legacy {
        return Some(AttributeBase::Legacy);
    }
    matches!(record.chunk(0), Some(Token::Ref(_))).then_some(AttributeBase::Compact)
}

/// The next record in an attribute chain.
///
/// A current ASM attribute starts with `reserved, marker, next, previous,
/// owner`; a legacy attribute omits `marker`. Source-less streams written by
/// older cadmpeg versions used a compact record whose first field was `next`;
/// retain read compatibility with all three forms.
pub fn attribute_next(record: &Record) -> Option<i64> {
    record.ref_at(attribute_base(record)?.next())
}

/// The topology or parent-attribute owner of a current or legacy attribute.
pub fn attribute_owner(record: &Record) -> Option<i64> {
    record.ref_at(attribute_base(record)?.owner()?)
}

/// The numeric record-index key of an attribute id
/// (`<format>:brep:attribute#<index>`), used to key records derived from that
/// attribute.
pub fn attribute_key(attribute: &SourceAttribute) -> &str {
    attribute
        .id
        .as_str()
        .rsplit('#')
        .next()
        .unwrap_or(attribute.id.as_str())
}

/// Serialize one attribute record's value chunks as a [`SourceAttribute`]
/// bound to `target`. A NaN or infinite number refuses the record.
pub fn source_attribute(
    record: &Record,
    target: AttributeTarget,
    format: IdFormat,
) -> Result<SourceAttribute, cadmpeg_core::CodecError> {
    // Chunks, not raw tokens: the serialized value list is defined over the
    // value tokens, and a payload identifier names an embedded construction
    // rather than carrying an attribute value.
    let mut values = Vec::new();
    for token in record.chunks() {
        let value = attribute_value(token, format).ok_or_else(|| {
            cadmpeg_core::CodecError::malformed(format_args!(
                "attribute record {} ({}) holds a non-finite number",
                record.index, record.name
            ))
        })?;
        values.push(value);
    }
    Ok(SourceAttribute {
        id: brep_id!(format, AttributeId, "attribute", record.index),
        target: target.into(),
        name: record.name.clone(),
        values,
    })
}

/// The attribute value one token carries, or `None` for a number that is not
/// finite.
fn attribute_value(token: &Token, format: IdFormat) -> Option<AttributeValue> {
    Some(match token {
        Token::Char(value) => AttributeValue::Integer(i64::from(*value)),
        Token::Short(value) => AttributeValue::Integer(i64::from(*value)),
        Token::Long(value) | Token::Enum(value) | Token::Int64(value) => {
            AttributeValue::Integer(*value)
        }
        Token::Float(value) => AttributeValue::float(f64::from(*value))?,
        Token::Double(value) => AttributeValue::float(*value)?,
        Token::Str(value) => AttributeValue::String(value.to_owned()),
        Token::True => AttributeValue::Boolean(true),
        Token::False => AttributeValue::Boolean(false),
        Token::Ref(value) => {
            AttributeValue::Reference(brep_id!(format, Identity, "entity", value).into_string())
        }
        Token::SubtypeOpen => AttributeValue::String("subtype_open".into()),
        Token::SubtypeClose => AttributeValue::String("subtype_close".into()),
        Token::Position(value) | Token::Vector3(value) => AttributeValue::vector(*value)?,
        Token::Vector2(value) => AttributeValue::vector(*value)?,
        Token::Ident(value) | Token::SubIdent(value) => AttributeValue::String(value.to_owned()),
    })
}

/// Decode a native transform record into an IR affine transform, scaling the
/// translation into millimetres.
pub fn decode_transform(
    record: &Record,
    header_scale: f64,
) -> Option<cadmpeg_ir::transform::Transform> {
    let mut vectors = record.tokens.iter().filter_map(|token| match token {
        Token::Position(value) | Token::Vector3(value) => Some(*value),
        _ => None,
    });
    let scale = record
        .tokens
        .iter()
        .filter_map(|token| match token {
            Token::Double(value) => Some(*value),
            _ => None,
        })
        .next_back()?;
    let (Some(x), Some(y), Some(z), Some(translation), None) = (
        vectors.next(),
        vectors.next(),
        vectors.next(),
        vectors.next(),
        vectors.next(),
    ) else {
        return None;
    };
    // The attribute stores a homogeneous scale in the `w` slot. Only the
    // unscaled spelling maps to an affine transform.
    if scale != 1.0 {
        return None;
    }
    cadmpeg_ir::transform::Transform::affine([
        [x[0], y[0], z[0], translation[0] * header_scale * LEN_TO_MM],
        [x[1], y[1], z[1], translation[1] * header_scale * LEN_TO_MM],
        [x[2], y[2], z[2], translation[2] * header_scale * LEN_TO_MM],
    ])
}

/// Storage form and payload-field location of an exact direct-color attribute.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DirectColorCarrier {
    /// Three normalized f64 channel fields.
    NormalizedRgb {
        /// Payload-field indices of red, green, and blue.
        fields: [usize; 3],
    },
    /// One Autodesk method-and-color packed integer field.
    AutodeskTrueColor {
        /// Payload-field index of the packed integer.
        field: usize,
    },
    /// One decimal-text packed RGB field.
    DecimalRgb {
        /// Payload-field index of the decimal text.
        field: usize,
    },
}

/// A decoded exact direct-color attribute and the carrier that supplied it.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DirectAttributeColor {
    /// Opaque neutral RGB color.
    pub color: Color,
    /// Native payload form and field location.
    pub carrier: DirectColorCarrier,
}

fn packed_u32(value: i64) -> Option<u32> {
    u32::try_from(value)
        .ok()
        .or_else(|| i32::try_from(value).ok().map(i32::cast_unsigned))
}

fn packed_rgb(packed: u32) -> Option<Color> {
    let red = u8::try_from((packed >> 16) & 0xff).ok()?;
    let green = u8::try_from((packed >> 8) & 0xff).ok()?;
    let blue = u8::try_from(packed & 0xff).ok()?;
    Some(Color::from_rgba8(red, green, blue, 255))
}

/// Decode one well-formed exact direct-color attribute.
///
/// Palette, material-library, inherited truecolor, and malformed records do
/// not define a neutral RGB color.
fn direct_attribute_color(record: &Record) -> Option<DirectAttributeColor> {
    let payload = attribute_base(record)?.payload();
    match record.name.as_str() {
        "rgb_color-st-attrib" => {
            let mut channels = record.chunks().enumerate().skip(payload).filter_map(
                |(field, token)| match token {
                    Token::Double(value) => Some((field, *value)),
                    _ => None,
                },
            );
            let channels = [
                channels.next(),
                channels.next(),
                channels.next(),
                channels.next(),
                channels.next(),
            ];
            let [(r_field, r), (g_field, g), (b_field, b)] = match channels {
                [Some(red), Some(green), Some(blue), None, None] => [red, green, blue],
                [Some(red), Some(green), Some(blue), Some((_, 1.0)), None] => [red, green, blue],
                _ => return None,
            };
            if ![r, g, b]
                .into_iter()
                .all(|value| (0.0..=1.0).contains(&value))
            {
                return None;
            }
            Some(DirectAttributeColor {
                color: Color::new(r, g, b, 1.0)?,
                carrier: DirectColorCarrier::NormalizedRgb {
                    fields: [r_field, g_field, b_field],
                },
            })
        }
        "truecolor-adesk-attrib" => {
            let (field, packed) = record
                .chunks()
                .enumerate()
                .skip(payload)
                .filter_map(|(field, token)| match token {
                    Token::Int64(value) | Token::Long(value) => Some((field, *value)),
                    _ => None,
                })
                .last()?;
            let packed = packed_u32(packed)?;
            // AcCmColor stores its color method in the high byte. Only
            // kByColor carries self-contained RGB channels.
            if packed >> 24 != 0xc2 {
                return None;
            }
            Some(DirectAttributeColor {
                color: packed_rgb(packed)?,
                carrier: DirectColorCarrier::AutodeskTrueColor { field },
            })
        }
        "entatt_color-bt-attrib" => {
            let (field, text) = record
                .chunks()
                .enumerate()
                .skip(payload)
                .filter_map(|(field, token)| match token {
                    Token::Str(value) => Some((field, value.as_str())),
                    _ => None,
                })
                .last()?;
            if text.is_empty() || !text.bytes().all(|byte| byte.is_ascii_digit()) {
                return None;
            }
            let packed = text
                .parse::<u32>()
                .ok()
                .filter(|value| *value <= 0xff_ffff)?;
            Some(DirectAttributeColor {
                color: packed_rgb(packed)?,
                carrier: DirectColorCarrier::DecimalRgb { field },
            })
        }
        _ => None,
    }
}

/// The first well-formed exact direct-color carrier on an attribute chain.
pub fn attribute_chain_color_carrier<'a>(
    entity: &Record,
    max_steps: usize,
    mut by_index: impl FnMut(i64) -> Option<&'a Record>,
) -> Option<(&'a Record, DirectAttributeColor)> {
    let mut current = entity.ref_at(0)?;
    for _ in 0..max_steps {
        let record = by_index(current)?;
        if let Some(color) = direct_attribute_color(record) {
            return Some((record, color));
        }
        current = attribute_next(record)?;
    }
    None
}

/// The first well-formed exact direct color on `entity`'s attribute chain.
pub fn attribute_chain_color(
    entity: &Record,
    by_index: &HashMap<i64, &Record, RandomState>,
) -> Option<Color> {
    attribute_chain_color_carrier(entity, by_index.len(), |index| {
        by_index.get(&index).copied()
    })
    .map(|(_, decoded)| decoded.color)
}

/// The first non-empty name attribute on `entity`'s attribute chain.
pub fn attribute_chain_name(
    entity: &Record,
    by_index: &HashMap<i64, &Record, RandomState>,
) -> Option<String> {
    attribute_chain_name_text(entity, by_index).map(str::to_owned)
}

/// The first non-empty name attribute on `entity`'s attribute chain, borrowed
/// from the record that holds it.
pub(crate) fn attribute_chain_name_text<'a>(
    entity: &Record,
    by_index: &HashMap<i64, &'a Record, RandomState>,
) -> Option<&'a str> {
    let mut current = entity.ref_at(0)?;
    for _ in 0..by_index.len() {
        let record: &'a Record = by_index.get(&current)?;
        if record.name == "string_attrib-name_attrib-gen-attrib" {
            let mut values = record.tokens.iter().filter_map(|token| match token {
                Token::Str(value) => Some(value.as_str()),
                _ => None,
            });
            let mut previous = None;
            let mut last = None;
            for value in &mut values {
                previous = last;
                last = Some(value);
            }
            if let (Some("name"), Some(value)) = (previous, last) {
                if !value.is_empty() {
                    return Some(value);
                }
            }
        }
        let next = attribute_next(record)?;
        current = next;
    }
    None
}

/// The `UnknownId` for a preserved carrier record. Shared by the passthrough
/// `UnknownRecord` and any `SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown)` that links to it, so the
/// reference resolves under validation.
pub fn unknown_record_id(
    rec: &Record,
    format: IdFormat,
) -> Result<UnknownId, cadmpeg_core::CodecError> {
    // The record-table index remains its identity when the source name has
    // no leading component. Keep the source spelling in the retained bytes.
    let head = if rec.head().is_empty() {
        "untyped-record"
    } else {
        rec.head()
    };
    let name = head.to_owned();
    let kind = IdentityComponent::try_new(name).map_err(|error| {
        cadmpeg_core::CodecError::malformed(format_args!(
            "invalid ASM source identity component: {error}"
        ))
    })?;
    Ok(UnknownId::from(format.try_brep_identity(&kind, rec.index)?))
}

#[cfg(test)]
mod tests {
    use super::decode_transform;
    use crate::sab::{Record, Token};

    fn transform_record(scale: f64, x: [f64; 3]) -> Record {
        Record {
            index: 0,
            name: "transform".into(),
            tokens: std::sync::Arc::from([
                Token::Vector3(x),
                Token::Vector3([0.0, 1.0, 0.0]),
                Token::Vector3([0.0, 0.0, 1.0]),
                Token::Position([0.0, 0.0, 0.0]),
                Token::Double(scale),
            ]),
            offset: 0,
            len: 0,
        }
    }

    #[test]
    fn transform_decode_propagates_affine_constructor_rejection() {
        let identity = transform_record(1.0, [1.0, 0.0, 0.0]);
        assert_eq!(
            decode_transform(&identity, 1.0),
            Some(cadmpeg_ir::transform::Transform::identity())
        );
        for scale in [0.0, 2.0, f64::NAN, f64::INFINITY] {
            assert!(decode_transform(&transform_record(scale, [1.0, 0.0, 0.0]), 1.0).is_none());
        }
        assert!(decode_transform(&transform_record(1.0, [f64::NAN, 0.0, 0.0]), 1.0).is_none());
        assert!(decode_transform(&identity, f64::INFINITY).is_none());
    }
}
