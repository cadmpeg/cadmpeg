// SPDX-License-Identifier: Apache-2.0
//! Procedural spline-surface embedded types and their `_spl_sur` decoders.

use crate::kernel_header::RefWidth;
use crate::nurbs::blend::{
    compact_rb_blend_spl_sur, cyl_spl_sur, full_rb_blend_spl_sur, rolling_ball_side,
    var_blend_spl_sur, vertex_blend_spl_sur, SupportCaches,
};
use crate::nurbs::core::{curve_block, surface_block};
use crate::nurbs::pcurve::{decode_pcurve_block_with_end, pcurve_block_with_end};
use crate::nurbs::proc_curve::{
    embedded_base_curve_resolving_refs, embedded_support, embedded_surface,
    embedded_surface_with_ranges, optional_embedded_surface_with_bounds, optional_helix_revision,
    EmbeddedSupport,
};
use crate::nurbs::reader::{normalized, take_native_ident, Nullable, LEN_TO_MM};
use crate::nurbs::toks::{self, Cur, SubtypeTable};
use crate::sab::Token;
use cadmpeg_core::decode::bounded_len;
use cadmpeg_ir::geometry::{
    nurbs::{NurbsCurve, NurbsSurface},
    pcurve::PcurveNurbs,
    BlendCrossSection, CurveGeometry, RevisionCacheForm, RevisionSurfaceParameterization,
    RollingBallSide, RollingBallSupportCurve, SolvedCurveGeometry, SurfaceGeometry,
    VariableBlendCache,
};
use cadmpeg_ir::math::{Point3, Vector3};
use cadmpeg_ir::scalar::PositiveI64;
use cadmpeg_ir::units::UnitVector3;
use std::num::NonZeroI64;

macro_rules! propagate_resource {
    ($result:expr) => {
        match $result {
            Ok(value) => value,
            Err(error) => return Some(Err(error)),
        }
    };
}

/// The legacy and revision offset surface layouts.
pub enum EmbeddedOffsetLayout {
    /// A legacy offset with its required sense pair.
    Legacy {
        /// The U sense enum.
        u_sense: i64,
        /// The V sense enum.
        v_sense: i64,
        /// The conditional extension flags.
        extension: cadmpeg_ir::geometry::LegacyExtensionFlags,
    },
    /// A revision offset with its four orientation flags.
    Revision(Box<cadmpeg_ir::geometry::RevisionSurfaceForm<[bool; 4]>>),
}

/// A decoded native procedural definition with layout-owned cache tolerance.
pub struct DecodedProceduralSurface {
    definition: DecodedProceduralSurfaceDefinition,
    cache: ProceduralSurfaceCache,
}

pub(crate) enum ProceduralSurfaceCache {
    Legacy(Option<f64>),
    Revision,
}

impl DecodedProceduralSurface {
    pub(super) fn legacy(
        definition: DecodedProceduralSurfaceDefinition,
        cache_fit_tolerance: Option<f64>,
    ) -> Self {
        Self {
            definition,
            cache: ProceduralSurfaceCache::Legacy(cache_fit_tolerance),
        }
    }

    pub(super) fn revision(definition: DecodedProceduralSurfaceDefinition) -> Self {
        Self {
            definition,
            cache: ProceduralSurfaceCache::Revision,
        }
    }

    /// Borrow the native construction definition.
    pub fn definition(&self) -> &DecodedProceduralSurfaceDefinition {
        &self.definition
    }

    /// Return the tolerance stored outside a legacy construction.
    #[cfg(test)]
    pub(crate) fn legacy_cache_fit_tolerance(&self) -> Option<f64> {
        match self.cache {
            ProceduralSurfaceCache::Legacy(tolerance) => tolerance,
            ProceduralSurfaceCache::Revision => None,
        }
    }

    /// Return the effective fit tolerance of the solved surface cache.
    pub(crate) fn cache_fit_tolerance(&self) -> Option<f64> {
        match self.cache {
            ProceduralSurfaceCache::Legacy(tolerance) => tolerance,
            ProceduralSurfaceCache::Revision => self.definition.revision_cache_fit_tolerance(),
        }
    }

    pub(crate) fn into_parts(self) -> (DecodedProceduralSurfaceDefinition, ProceduralSurfaceCache) {
        (self.definition, self.cache)
    }
}

/// Native T-spline fields before surface admission.
pub struct EmbeddedTSplineSurface {
    /// Native U and V ranges.
    pub parameter_ranges: [[f64; 2]; 2],
    /// Native type integer.
    pub type_code: i64,
    /// Native program or reference and its resolution result.
    pub subtransform: EmbeddedTSplineSubtransform,
    /// Native trailing integer.
    pub trailing_value: i64,
    /// Native discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// Native discontinuity flag.
    pub discontinuity_flag: bool,
    /// Revision layout fields, when present.
    pub revision_form: Option<cadmpeg_ir::geometry::RevisionSurfaceForm>,
}

/// Parsed T-spline subtransform before reference and program admission.
pub enum EmbeddedTSplineSubtransform {
    /// Inline native program strings.
    Inline {
        /// Topology program.
        program: String,
        /// Native separator flag.
        separator: Option<bool>,
        /// Companion values program.
        values: String,
    },
    /// Native reference with its optional resolved target.
    Reference {
        /// Native table index.
        index: i64,
        /// Target when the reference chain resolves to an admitted inline program.
        resolved: Option<cadmpeg_ir::geometry::InlineTSplineSubtransform>,
    },
}

/// Source-native procedural semantics before embedded geometry is assigned IR ids.
pub enum DecodedProceduralSurfaceDefinition {
    /// Exact NURBS construction and retained native parameter fields.
    Exact {
        /// Complete legacy or revision-gated exact-spline layout.
        spline: cadmpeg_ir::geometry::ExactSpline,
    },
    /// Native compound surface with ordered scalar/component pairs.
    Compound {
        /// Ordered embedded surfaces paired with native construction scalars.
        components: Vec<cadmpeg_ir::geometry::CompoundComponent<SurfaceGeometry>>,
    },
    /// Exact rectangular restriction of an embedded support surface.
    SubSurface {
        /// Embedded support surface.
        support: SurfaceGeometry,
        /// Ordered U and V parameter intervals.
        parameter_ranges: [[f64; 2]; 2],
    },
    /// Native taper family with shared carriers and subtype tail.
    Taper {
        /// Embedded base surface.
        support: SurfaceGeometry,
        /// Embedded reference curve.
        reference: NurbsCurve,
        /// Embedded UV curve, absent for `nullbs`.
        pcurve: Option<PcurveNurbs>,
        /// Native taper parameter.
        parameter: f64,
        /// Subtype-specific tail.
        taper: cadmpeg_ir::geometry::TaperSurfaceKind,
        /// Revision-gated form fields.
        revision_form: Option<cadmpeg_ir::geometry::RevisionSurfaceForm>,
    },
    /// Native loft construction graph with embedded carriers.
    Loft(EmbeddedLoft),
    /// Native compound-loft graph with embedded carriers.
    CompoundLoft(Box<EmbeddedCompoundLoft>),
    /// Revision-gated compound-loft graph with embedded carriers.
    RevisionCompoundLoft(Box<EmbeddedRevisionCompoundLoft>),
    /// Native scaled compound-loft graph with embedded carriers.
    ScaledCompoundLoft(Box<EmbeddedScaledCompoundLoft>),
    /// Native skinned surface graph with embedded carriers.
    Skin(Box<EmbeddedSkinSurface>),
    /// Native recursive law-surface graph.
    Law(Box<EmbeddedLawSurface>),
    /// Native curve-network surface graph with embedded carriers.
    Net(Box<EmbeddedNetSurface>),
    /// Native sweep surface graph with embedded carriers.
    Sweep(Box<EmbeddedSweepSurface>),
    /// Native T-spline wrapper and subtransform program.
    TSpline(Box<EmbeddedTSplineSurface>),
    /// Native circular or linear helix surface.
    Helix(Box<cadmpeg_ir::geometry::HelixSurfaceConstruction>),
    /// Native deformable surface with embedded support.
    Deformable(Box<EmbeddedDeformableSurface>),
    /// Native G2 blend construction with embedded carriers.
    G2Blend(Box<EmbeddedG2Blend>),
    /// Revision-gated G2 blend in the variable-blend side layout.
    RevisionG2Blend(Box<EmbeddedRevisionG2Blend>),
    /// Ruled interpolation between two ordered profile curves.
    Ruled {
        /// First embedded profile.
        first: NurbsCurve,
        /// Second embedded profile.
        second: NurbsCurve,
    },
    /// Translational sum of two curves around a stored origin.
    Sum {
        /// First embedded curve.
        first: CurveGeometry,
        /// Second embedded curve.
        second: CurveGeometry,
        /// Native model-space origin.
        basepoint: Vector3,
        /// Revision-gated form fields.
        revision_form: Option<cadmpeg_ir::geometry::RevisionSurfaceForm>,
    },
    /// Revolution of an embedded profile around an axis.
    Revolution {
        /// Embedded profile curve.
        directrix: CurveGeometry,
        /// Point on the axis in model space.
        axis_origin: Point3,
        /// Unit axis direction.
        axis_direction: UnitVector3,
        /// Angular interval from the solved surface cache.
        angular_interval: [f64; 2],
        /// Native profile parameter interval.
        parameter_interval: [f64; 2],
        /// Revision-gated form fields.
        revision_form: Option<cadmpeg_ir::geometry::RevisionSurfaceForm>,
    },
    /// Signed offset from an embedded support surface.
    Offset {
        /// Embedded support surface.
        support: SurfaceGeometry,
        /// Signed model-space distance.
        distance: f64,
        /// The legacy or revision offset fields.
        layout: EmbeddedOffsetLayout,
    },
    /// Translation of an embedded directrix along a length-bearing direction.
    Extrusion {
        /// Embedded directrix cache.
        directrix: NurbsCurve,
        /// Stored directrix parameter interval.
        parameter_interval: [f64; 2],
        /// Length-bearing sweep direction.
        direction: Vector3,
        /// Native model-space position following the direction.
        native_position: Point3,
        /// Revision-gated form fields.
        revision_form: Option<cadmpeg_ir::geometry::RevisionSurfaceForm>,
    },
    /// Rolling-ball blend with embedded support and spine caches.
    Blend {
        /// Embedded support caches in side order.
        supports: Box<[Option<SurfaceGeometry>; 2]>,
        /// Embedded center/spine curve.
        spine: Option<NurbsCurve>,
        /// Signed radius offsets at the spine start and end, in
        /// millimetres. Equal offsets state a constant radius.
        radius_offsets: [f64; 2],
        /// Blend cross-section family.
        cross_section: BlendCrossSection,
        /// Complete native construction graph when the full layout decoded.
        native: Option<Box<EmbeddedRollingBall>>,
    },
    /// Variable-radius blend with a complete embedded construction graph.
    VariableBlend(Box<EmbeddedVariableBlend>),
    /// Vertex-blend patch with complete embedded boundary graphs.
    VertexBlend(Box<EmbeddedVertexBlend>),
}

impl DecodedProceduralSurfaceDefinition {
    fn revision_cache_fit_tolerance(&self) -> Option<f64> {
        match self {
            Self::Exact { spline } => match spline {
                cadmpeg_ir::geometry::ExactSpline::Revision { form, .. } => form
                    .cache
                    .fit_tolerance()
                    .map(cadmpeg_ir::geometry::FitTolerance::get),
                cadmpeg_ir::geometry::ExactSpline::Legacy { .. } => None,
            },
            Self::Taper { revision_form, .. }
            | Self::Extrusion { revision_form, .. }
            | Self::Revolution { revision_form, .. }
            | Self::Sum { revision_form, .. } => revision_form
                .as_ref()
                .and_then(|form| form.cache.fit_tolerance())
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::Offset { layout, .. } => match layout {
                EmbeddedOffsetLayout::Revision(form) => form
                    .cache
                    .fit_tolerance()
                    .map(cadmpeg_ir::geometry::FitTolerance::get),
                EmbeddedOffsetLayout::Legacy { .. } => None,
            },
            Self::Loft(construction) => match &construction.layout {
                EmbeddedLoftLayout::Revision(form, _) => form
                    .cache
                    .fit_tolerance()
                    .map(cadmpeg_ir::geometry::FitTolerance::get),
                EmbeddedLoftLayout::Legacy { .. } => None,
            },
            Self::RevisionCompoundLoft(construction) => construction
                .cache
                .fit_tolerance()
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::RevisionG2Blend(construction) => construction
                .cache
                .fit_tolerance()
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::Sweep(construction) => match &construction.layout {
                EmbeddedSweepSurfaceLayout::Revision { form, .. } => form
                    .cache
                    .fit_tolerance()
                    .map(cadmpeg_ir::geometry::FitTolerance::get),
                EmbeddedSweepSurfaceLayout::Legacy { .. } => None,
            },
            Self::TSpline(construction) => construction
                .revision_form
                .as_ref()
                .and_then(|form| form.cache.fit_tolerance())
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::Deformable(construction) => match &construction.layout {
                EmbeddedDeformableSurfaceLayout::Revision(form) => form
                    .cache
                    .fit_tolerance()
                    .map(cadmpeg_ir::geometry::FitTolerance::get),
                EmbeddedDeformableSurfaceLayout::Legacy { .. } => None,
            },
            Self::Blend { native, .. } => native
                .as_ref()
                .and_then(|construction| construction.cache.fit_tolerance())
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::VariableBlend(construction) => construction
                .cache
                .fit_tolerance()
                .map(cadmpeg_ir::geometry::FitTolerance::get),
            Self::Compound { .. }
            | Self::SubSurface { .. }
            | Self::CompoundLoft(_)
            | Self::ScaledCompoundLoft(_)
            | Self::Skin(_)
            | Self::Law(_)
            | Self::Net(_)
            | Self::Helix(_)
            | Self::G2Blend(_)
            | Self::Ruled { .. }
            | Self::VertexBlend(_) => None,
        }
    }
}

/// Embedded revision-gated G2 blend before stable IR ids are assigned.
pub struct EmbeddedRevisionG2Blend {
    /// The revision integer that gates the layout.
    pub revision: PositiveI64,
    /// Two leading parameters serialized before the sides.
    pub leading_parameters: [f64; 2],
    /// Two ordered embedded support sides.
    pub sides: Box<[RollingBallSide<SurfaceGeometry, CurveGeometry, PcurveNurbs>; 2]>,
    /// The embedded center curve.
    pub center: CurveGeometry,
    /// Optional parameter bounds of the center curve.
    pub center_range: [Option<f64>; 2],
    /// Two blend radii in document length units.
    pub radii: [f64; 2],
    /// The integer-valued optional-radius selector serialized after the radii.
    pub radius_selector: cadmpeg_ir::geometry::RollingBallRadiusSelector<PositiveI64>,
    /// Support-side parameter interval `(T0, T1)`.
    pub u_range: [Option<f64>; 2],
    /// Second interval; `None` marks an unbounded end.
    pub v_range: [Option<f64>; 2],
    /// Approximation-current flag (`1` when the cache is current).
    pub shape_prefix: i64,
    /// Requested fit tolerance.
    pub shape_parameter: f64,
    /// Achieved fit tolerance in document length units, read as stored. The
    /// reader does not compare it with `shape_parameter`.
    pub shape_length: f64,
    /// Signed integer immediately before the shared tail's enum, taking the
    /// values `-1` and `1`.
    pub shape_tail: i64,
    /// Approximation-cache form selected by the shared tail enum.
    pub cache: RevisionCacheForm,
    /// Six discontinuity arrays of the shared tail.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub tail_flag: bool,
    /// Three integers closing the shared tail.
    pub tail_extensions: [i64; 3],
}

/// The optional third support side of a rolling-ball blend.
pub struct EmbeddedRollingBallThirdSide {
    /// The leading identifier of the third side.
    pub label: String,
    /// The embedded support surface.
    pub surface: SurfaceGeometry,
    /// The embedded support curve.
    pub curve: NurbsCurve,
    /// The embedded NURBS parameter curve on the support surface.
    pub pcurve: Option<PcurveNurbs>,
    /// The support direction vector.
    pub direction: Vector3,
    /// A second embedded parameter curve, when serialized.
    pub secondary_pcurve: Option<PcurveNurbs>,
    /// The extension integer serialized after the secondary pcurve.
    pub extension: i64,
    /// A third embedded parameter curve, when serialized.
    pub tertiary_pcurve: Option<PcurveNurbs>,
    /// The boolean closing the third side.
    pub flag: bool,
}

/// Embedded native variable blend before stable IR ids are assigned.
pub struct EmbeddedVariableBlend {
    /// The blend subtype the record name selects.
    pub subtype: cadmpeg_ir::geometry::VariableBlendSurfaceSubtype,
    /// The revision integer that gates the layout.
    pub revision: PositiveI64,
    /// Two ordered embedded support sides.
    pub sides: Box<[RollingBallSide<SurfaceGeometry, CurveGeometry, PcurveNurbs>; 2]>,
    /// The embedded slice curve.
    pub slice: CurveGeometry,
    /// Optional parameter bounds of the slice curve.
    pub slice_range: [Option<f64>; 2],
    /// Two side offsets in document length units.
    pub offsets: [f64; 2],
    /// Structurally selected radius-law payloads.
    pub radii: cadmpeg_ir::geometry::VariableBlendRadii,
    /// The cross-section law, when serialized.
    pub cross_section: Option<cadmpeg_ir::geometry::VariableBlendCrossSection>,
    /// Support-side parameter interval `(T0, T1)`.
    pub u_range: [f64; 2],
    /// Second interval `(T lo, F)`: a lower bound with an unbounded-above
    /// marker decoding to `[Some(lo), None]`.
    pub v_lower: Option<f64>,
    /// Requested fit tolerance.
    pub shape_parameter: f64,
    /// Achieved fit tolerance in document length units, read as stored. The
    /// reader does not compare it with `shape_parameter`.
    pub shape_length: f64,
    /// Signed integer immediately before the shared tail's enum, taking the
    /// values `-1` and `1`.
    pub shape_tail: i64,
    /// Approximation-cache form selected by the shared tail enum.
    pub cache: VariableBlendCache,
    /// Six discontinuity arrays of the shared tail.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub tail_flag: bool,
    /// Three integers closing the shared tail.
    pub tail_extensions: [i64; 3],
    /// A second embedded curve serialized after the tail, when present.
    pub secondary_curve: Option<RollingBallSupportCurve<CurveGeometry>>,
    /// The convexity enum of the blend.
    pub convexity: cadmpeg_ir::geometry::VariableBlendConvexity,
    /// The render-mode enum of the blend.
    pub render_mode: cadmpeg_ir::geometry::VariableBlendRenderMode,
    /// Optional parameter bounds of the post curve.
    pub post_range: [Option<f64>; 2],
    /// An embedded curve closing the record, when present.
    pub post_curve: Option<NurbsCurve>,
    /// An embedded parameter curve closing the record, when present.
    pub post_pcurve: Option<PcurveNurbs>,
}

/// The geometry form of one vertex-blend boundary.
pub enum EmbeddedVertexBlendBoundaryGeometry {
    /// A circular boundary carried by an embedded curve.
    Circle {
        /// The embedded boundary curve.
        curve: CurveGeometry,
        /// Optional endpoint bounds of the boundary curve.
        curve_endpoints: [Option<f64>; 2],
        /// Twist payload selected by the native circle form.
        twists: cadmpeg_ir::geometry::VertexBlendTwists,
        /// Two parameters closing the circle form.
        parameters: [f64; 2],
        /// The sense boolean of the boundary.
        sense: bool,
    },
    /// A degenerate boundary collapsed to one location.
    Degenerate {
        /// The collapsed boundary location.
        location: Point3,
        /// Two boundary normals.
        normals: [Vector3; 2],
    },
    /// A boundary carried by a parameter curve on a support surface.
    Pcurve {
        /// The embedded support surface.
        surface: SurfaceGeometry,
        /// Optional UV bounds of the support surface.
        support_bounds: [Option<f64>; 4],
        /// The embedded NURBS parameter curve.
        pcurve: Option<PcurveNurbs>,
        /// The sense boolean of the boundary.
        sense: bool,
        /// The fit tolerance of the boundary approximation.
        fit_tolerance: cadmpeg_ir::geometry::FitTolerance,
    },
    /// A planar boundary carried by a normal and an embedded curve.
    Plane {
        /// The plane normal.
        normal: Vector3,
        /// Two parameters serialized after the normal.
        parameters: [f64; 2],
        /// The embedded boundary curve.
        curve: CurveGeometry,
        /// Optional endpoint bounds of the boundary curve.
        curve_endpoints: [Option<f64>; 2],
    },
}

/// One boundary of an embedded vertex blend.
pub struct EmbeddedVertexBlendBoundary {
    /// The boundary-type boolean.
    pub boundary_type: bool,
    /// The vector serialized after the boundary type.
    pub magic: Vector3,
    /// The U-smoothing boolean.
    pub u_smoothing: bool,
    /// The V-smoothing boolean.
    pub v_smoothing: bool,
    /// The fullness value of the boundary.
    pub fullness: f64,
    /// The geometry form of the boundary.
    pub geometry: EmbeddedVertexBlendBoundaryGeometry,
}

/// Embedded native vertex blend before stable IR ids are assigned.
pub struct EmbeddedVertexBlend {
    /// The revision integer that gates the layout, when serialized.
    pub revision: Option<PositiveI64>,
    /// The embedded boundary graphs, in stream order.
    pub boundaries: Vec<EmbeddedVertexBlendBoundary>,
    /// The approximation grid size.
    pub grid_size: i64,
    /// The fit tolerance of the patch approximation.
    pub fit_tolerance: cadmpeg_ir::geometry::FitTolerance,
}

/// Embedded native rolling-ball graph before stable IR ids are assigned.
pub struct EmbeddedRollingBall {
    /// The revision integer that gates the layout.
    pub revision: PositiveI64,
    /// Two ordered embedded support sides.
    pub sides: Box<[RollingBallSide<SurfaceGeometry, CurveGeometry, PcurveNurbs>; 2]>,
    /// The embedded slice curve.
    pub slice: CurveGeometry,
    /// Optional parameter bounds of the slice curve.
    pub slice_range: [Option<f64>; 2],
    /// Two side offsets in document length units.
    pub offsets: [f64; 2],
    /// The radius selector of the blend.
    pub radius_selector: Option<f64>,
    /// Support-side parameter interval `(T0, T1)`.
    pub u_range: [Option<f64>; 2],
    /// Second interval; `None` marks an unbounded end.
    pub v_range: [Option<f64>; 2],
    /// Approximation-current flag (`1` when the cache is current).
    pub shape_prefix: i64,
    /// Two parameters serialized after the shape prefix.
    pub parameters: [f64; 2],
    /// The integer closing the shape block.
    pub tail: i64,
    /// Approximation-cache form selected by the shared tail enum.
    pub cache: RevisionCacheForm,
    /// Six discontinuity arrays of the shared tail.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub tail_flag: bool,
    /// The optional third support side.
    pub third: Option<Box<EmbeddedRollingBallThirdSide>>,
    /// Three integers closing the shared tail.
    pub tail_extensions: [i64; 3],
}

/// One embedded support side of a G2 blend.
pub struct EmbeddedG2Side {
    /// The leading identifier of the side.
    pub label: String,
    /// The embedded support surface.
    pub surface: SurfaceGeometry,
    /// The embedded support curve.
    pub curve: NurbsCurve,
    /// Two embedded NURBS parameter curves on the support surface.
    pub pcurves: [Option<PcurveNurbs>; 2],
    /// The support direction vector.
    pub direction: Vector3,
}

/// The shape block serialized after a G2 blend's first side.
pub enum EmbeddedG2FirstShape {
    /// The full form: an optional surface cache and tolerance.
    Full(Option<(NurbsSurface, cadmpeg_ir::geometry::FitTolerance)>),
    /// The reduced form: nine coefficients and a tolerance.
    None {
        /// Nine shape coefficients.
        coefficients: [f64; 9],
        /// The fit tolerance.
        tolerance: cadmpeg_ir::geometry::FitTolerance,
        /// The bridge token serialized after the tolerance, when present.
        extension: Option<cadmpeg_ir::geometry::LoftBridgeToken>,
        /// The embedded parameter curve closing the block, when present.
        pcurve: Option<PcurveNurbs>,
    },
}

/// Embedded native G2 blend graph before stable IR ids are assigned.
pub struct EmbeddedG2Blend {
    /// The first embedded support side.
    pub first: EmbeddedG2Side,
    /// The singularity integer serialized after the first side.
    pub singularity: i64,
    /// The shape block of the first side.
    pub first_shape: EmbeddedG2FirstShape,
    /// The second embedded support side.
    pub second: EmbeddedG2Side,
    /// The exact surface of the second side.
    pub second_exact_surface: NurbsSurface,
    /// The embedded center curve.
    pub center_curve: NurbsCurve,
    /// Two parameters of the center curve.
    pub center_parameters: [f64; 2],
    /// The integer serialized after the center parameters.
    pub center_flag: i64,
    /// Two UV parameter intervals.
    pub parameter_ranges: [[f64; 2]; 2],
    /// Four parameters closing the record body.
    pub trailing_parameters: [f64; 4],
    /// Three discontinuity arrays.
    pub discontinuities: [Vec<f64>; 3],
}

pub(super) fn decode_nullable_embedded_pcurve(
    bytes: &[u8],
    position: &mut usize,
    int_width: RefWidth,
) -> Option<Nullable<PcurveNurbs>> {
    let saved = *position;
    if take_native_ident(bytes, position).as_deref() == Some("nullbs") {
        return Some(Nullable::Null);
    }
    *position = saved;
    let (pcurve, end) = decode_pcurve_block_with_end(bytes, *position, int_width)?;
    *position = end;
    Some(Nullable::Value(pcurve))
}

/// Decode a `nullbs`-or-2D-block pcurve slot. Token-space counterpart of
/// [`decode_nullable_embedded_pcurve`].
pub(super) fn nullable_embedded_pcurve(cur: &mut Cur<'_>) -> Option<Nullable<PcurveNurbs>> {
    let saved = cur.pos();
    if cur.take_ident() == Some("nullbs") {
        return Some(Nullable::Null);
    }
    cur.set_pos(saved);
    let (pcurve, end) = pcurve_block_with_end(cur.toks(), cur.pos())?;
    cur.set_pos(end);
    Some(Nullable::Value(pcurve))
}

pub(super) fn g2_side(cur: &mut Cur<'_>) -> Option<EmbeddedG2Side> {
    let label = cur.take_str()?.to_owned();
    let EmbeddedSupport { surface, chart, .. } = embedded_support(cur)?;
    let (curve, curve_end) = curve_block(cur.toks(), cur.pos())?;
    cur.set_pos(curve_end);
    // The first pcurve is the contact track in the support chart, as the
    // primary pcurve of a rolling-ball side is.
    let mut first = nullable_embedded_pcurve(cur)?.value();
    if let Some(pcurve) = &mut first {
        chart.normalize(pcurve)?;
    }
    let direction = cur.take_vector3()?;
    let second = nullable_embedded_pcurve(cur)?.value();
    Some(EmbeddedG2Side {
        label,
        surface,
        curve,
        pcurves: [first, second],
        direction: Vector3::new(direction[0], direction[1], direction[2]),
    })
}

fn bridge_token(cur: &mut Cur<'_>) -> Option<cadmpeg_ir::geometry::LoftBridgeToken> {
    use cadmpeg_ir::geometry::LoftBridgeToken;
    match cur.peek()? {
        Token::True | Token::False => Some(LoftBridgeToken::Boolean(cur.take_bool()?)),
        Token::Long(_) => Some(LoftBridgeToken::Integer(cur.take_long()?)),
        Token::Double(_) => Some(LoftBridgeToken::Double(cur.take_f64()?)),
        Token::Enum(_) => Some(LoftBridgeToken::Enum(cur.take_enum()?)),
        Token::Str(_) => Some(LoftBridgeToken::Text(cur.take_str()?.to_owned())),
        _ => None,
    }
}

fn optional_trailing_cache_tolerance(cur: &mut Cur<'_>) -> Option<Nullable<f64>> {
    if cur.at_scope_end() {
        Some(Nullable::Null)
    } else {
        let tolerance = cur.take_f64()? * LEN_TO_MM;
        cur.at_scope_end().then_some(Nullable::Value(tolerance))
    }
}

fn g2_blend_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["g2_blend_spl_sur", "g2blnsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated layout: revision integer, two scalars, two sides in
        // the variable-blend side layout, center curve with endpoints, two
        // radii, radius selector, optional U/V bounds, shape prologue,
        // shared tail, and three trailing integers. The modern name uses this
        // layout.
        (name == "g2_blend_spl_sur").then_some(())?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let leading_parameters = [cur.take_f64()?, cur.take_f64()?];
        let first = match rolling_ball_side(ctx, &mut cur, resolver)? {
            Ok(side) => side,
            Err(limit) => return Some(Err(limit)),
        };
        let second = match rolling_ball_side(ctx, &mut cur, resolver)? {
            Ok(side) => side,
            Err(limit) => return Some(Err(limit)),
        };
        let sides = Box::new([first, second]);
        let table = resolver?;
        let center = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let center_range = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let radii = [cur.take_f64()? * LEN_TO_MM, cur.take_f64()? * LEN_TO_MM];
        let radius_selector = match cur.take_enum()? {
            -1 => cadmpeg_ir::geometry::RollingBallRadiusSelector::None {},
            value => cadmpeg_ir::geometry::RollingBallRadiusSelector::Value {
                value: PositiveI64::new(value)?,
            },
        };
        let u_range = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let v_range = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let shape_prefix = cur.take_long()?;
        let shape_parameter = cur.take_f64()?;
        let shape_length = cur.take_f64()? * LEN_TO_MM;
        let shape_tail = cur.take_long()?;
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        let tail_extensions = [cur.take_long()?, cur.take_long()?, cur.take_long()?];
        cur.at_scope_end().then_some(())?;
        return Some(Ok(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::RevisionG2Blend(Box::new(
                EmbeddedRevisionG2Blend {
                    revision,
                    leading_parameters,
                    sides,
                    center: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(center)),
                    center_range,
                    radii,
                    radius_selector,
                    u_range,
                    v_range,
                    shape_prefix,
                    shape_parameter,
                    shape_length,
                    shape_tail,
                    cache: cache.into_form()?,
                    discontinuities,
                    tail_flag,
                    tail_extensions,
                },
            )),
        )));
    }
    let first = g2_side(&mut cur)?;
    let singularity = cur.take_enum()?;
    let first_shape = if cur.peek().is_some_and(Token::is_payload_ident) {
        let saved = cur.pos();
        if cur.take_ident() == Some("nullbs") {
            EmbeddedG2FirstShape::Full(None)
        } else {
            cur.set_pos(saved);
            let (surface, surface_end) = surface_block(span, cur.pos())?;
            cur.set_pos(surface_end);
            EmbeddedG2FirstShape::Full(Some((
                surface,
                cadmpeg_ir::geometry::FitTolerance::try_new(cur.take_f64()? * LEN_TO_MM).ok()?,
            )))
        }
    } else {
        let mut coefficients = [0.0; 9];
        for coefficient in &mut coefficients {
            *coefficient = cur.take_f64()?;
        }
        let tolerance =
            cadmpeg_ir::geometry::FitTolerance::try_new(cur.take_f64()? * LEN_TO_MM).ok()?;
        let extension = if matches!(cur.peek(), Some(token)
            if matches!(token, Token::Str(_)) || token.is_payload_ident())
        {
            None
        } else {
            bridge_token(&mut cur)
        };
        let pcurve = nullable_embedded_pcurve(&mut cur)?.value();
        EmbeddedG2FirstShape::None {
            coefficients,
            tolerance,
            extension,
            pcurve,
        }
    };
    let second = g2_side(&mut cur)?;
    let (second_exact, second_exact_end) = surface_block(span, cur.pos())?;
    cur.set_pos(second_exact_end);
    let (center, center_end) = curve_block(span, cur.pos())?;
    cur.set_pos(center_end);
    let center_parameters = [cur.take_f64()?, cur.take_f64()?];
    let center_flag = cur.take_long()?;
    let parameter_ranges = [
        [cur.take_f64()?, cur.take_f64()?],
        [cur.take_f64()?, cur.take_f64()?],
    ];
    let mut trailing_parameters = [0.0; 4];
    for parameter in &mut trailing_parameters {
        *parameter = cur.take_f64()?;
    }
    let (_, cache_end) = surface_block(span, cur.pos())?;
    let cache_fit_tolerance = match span.get(cache_end) {
        Some(Token::Double(value)) => Some(*value * LEN_TO_MM),
        _ => None,
    };
    cur.set_pos(cache_end + usize::from(cache_fit_tolerance.is_some()));
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::G2Blend(Box::new(EmbeddedG2Blend {
            first,
            singularity,
            first_shape,
            second,
            second_exact_surface: second_exact,
            center_curve: center,
            center_parameters,
            center_flag,
            parameter_ranges,
            trailing_parameters,
            discontinuities,
        })),
        cache_fit_tolerance,
    )))
}

/// Constraint fields carried by a classic loft profile.
pub struct ClassicLoftProfileData {
    /// Native member type code.
    pub type_code: i64,
    /// The embedded support surface.
    pub surface: SurfaceGeometry,
    /// The nullable support pcurve.
    pub pcurve: Option<PcurveNurbs>,
    /// The boolean preceding the subdata.
    pub first_flag: bool,
    /// The ASM extension integer.
    pub asm_extension: i64,
    /// Constraint subdata.
    pub subdata: cadmpeg_ir::geometry::LoftSubdata,
    /// The optional direction vector.
    pub direction: Option<Vector3>,
}

/// The layout-selected data following a loft profile curve.
pub enum LoftProfileData {
    /// Classic layout with a required support, first flag, and ASM extension.
    Classic(ClassicLoftProfileData),
    /// Revision-gated nonzero member with a nullable bounded support.
    RevisionSupport {
        /// The profile curve endpoint bounds.
        endpoints: [Option<f64>; 2],
        /// The nonzero native member code.
        type_code: std::num::NonZeroI64,
        /// The nullable support surface.
        surface: Option<SurfaceGeometry>,
        /// Optional support bounds.
        support_bounds: [Option<f64>; 4],
        /// The nullable support pcurve.
        pcurve: Option<PcurveNurbs>,
        /// The boolean preceding the subdata.
        first_flag: bool,
        /// The stream-version-gated ASM extension.
        asm_extension: Option<i64>,
        /// Constraint subdata.
        subdata: cadmpeg_ir::geometry::LoftSubdata,
        /// The optional direction vector.
        direction: Option<Vector3>,
    },
    /// Revision-gated zero member with two nullable pcurve slots.
    RevisionPcurvePair {
        /// The profile curve endpoint bounds.
        endpoints: [Option<f64>; 2],
        /// The first pcurve slot.
        pcurve: Option<PcurveNurbs>,
        /// The second pcurve slot.
        secondary_pcurve: Option<PcurveNurbs>,
        /// The stream-version-gated ASM extension.
        asm_extension: Option<i64>,
        /// Constraint subdata.
        subdata: cadmpeg_ir::geometry::LoftSubdata,
        /// The optional direction vector.
        direction: Option<Vector3>,
    },
}

impl LoftProfileData {
    /// The endpoint bounds carried by revision profiles.
    pub fn endpoints(&self) -> Option<[Option<f64>; 2]> {
        match self {
            Self::Classic(_) => None,
            Self::RevisionSupport { endpoints, .. }
            | Self::RevisionPcurvePair { endpoints, .. } => Some(*endpoints),
        }
    }
}

/// One profile curve with its layout-specific constraint data.
pub struct EmbeddedLoftProfileMember<D = LoftProfileData> {
    /// The embedded profile curve.
    pub curve: NurbsCurve,
    /// The support data selected by the parent layout.
    pub data: D,
}

/// A revision loft path curve with its endpoint bounds.
pub struct EmbeddedRevisionLoftPathCurve {
    /// The embedded path curve.
    pub geometry: NurbsCurve,
    /// The endpoint bounds.
    pub endpoints: [Option<f64>; 2],
}

/// The legacy and revision loft path layouts.
pub enum EmbeddedLoftPathLayout {
    /// The required legacy path curve.
    Legacy(NurbsCurve),
    /// The optional revision path with its endpoint bounds.
    Revision(Option<EmbeddedRevisionLoftPathCurve>),
}

/// The path block of an embedded loft section.
pub struct EmbeddedLoftPath {
    /// The native path layout.
    pub layout: EmbeddedLoftPathLayout,
    /// Auxiliary embedded curves, in stream order.
    pub auxiliaries: Vec<NurbsCurve>,
    /// The integer closing the path block.
    pub flag: i64,
}

/// Embedded revision-gated compound loft before stable IR ids are assigned.
pub struct EmbeddedRevisionCompoundLoft {
    /// The revision integer that gates the layout.
    pub revision: PositiveI64,
    /// Approximation-cache form selected by the shared tail enum.
    pub cache: RevisionCacheForm,
    /// Six discontinuity arrays of the shared tail.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub tail_flag: bool,
    /// The base profile members, in stream order.
    pub base_profile: Vec<EmbeddedLoftProfileMember>,
    /// The base path block.
    pub base_path: EmbeddedLoftPath,
    /// The section entries, in stream order.
    pub entries: Vec<EmbeddedLoftSectionEntry>,
    /// Two booleans serialized after the entries.
    pub flags: [bool; 2],
    /// Two booleans serialized after the kind.
    pub kind_flags: [bool; 2],
    /// The loft direction selected after the kind flags.
    pub direction: EmbeddedCompoundLoftDirection,
    /// Trailing bounds and their dependent curve.
    pub tail: cadmpeg_ir::geometry::RevisionCompoundLoftTail<NurbsCurve>,
}

/// One section entry of an embedded loft.
pub struct EmbeddedLoftSectionEntry {
    /// The section parameter.
    pub parameter: f64,
    /// The profile members of the section, in stream order.
    pub profile: Vec<EmbeddedLoftProfileMember>,
    /// The path block of the section.
    pub path: EmbeddedLoftPath,
}

/// Embedded native loft graph before its carriers receive stable IR ids.
pub struct EmbeddedLoft {
    /// The two section lists, in stream order.
    pub sections: [Vec<EmbeddedLoftSectionEntry>; 2],
    /// The native loft layout.
    pub layout: EmbeddedLoftLayout,
}

/// The legacy and revision loft fields.
pub enum EmbeddedLoftLayout {
    /// The legacy loft fields.
    Legacy {
        /// The ordered parameter ranges.
        ranges: [[f64; 2]; 2],
        /// The closure enums.
        closures: [i64; 2],
        /// The singularity enums.
        singularities: [i64; 2],
        /// The loft mode.
        mode: i64,
        /// The bridge tokens in stream order.
        bridge: Vec<cadmpeg_ir::geometry::LoftBridgeToken>,
    },
    /// The revision form and optional interval bounds.
    Revision(
        Box<cadmpeg_ir::geometry::LoftRevisionForm>,
        [[Option<f64>; 2]; 2],
    ),
}

/// One scale block of an embedded compound loft.
pub struct EmbeddedCompoundLoftScale {
    /// The profile members of the block, in stream order.
    pub members: Vec<EmbeddedLoftProfileMember<ClassicLoftProfileData>>,
    /// The embedded path curve.
    pub path: NurbsCurve,
    /// Auxiliary embedded curves, in stream order.
    pub auxiliaries: Vec<NurbsCurve>,
    /// Two integers closing the block.
    pub tail: [i64; 2],
}

/// The direction carrier of a compound loft tail.
pub enum EmbeddedCompoundLoftDirection {
    /// A direction vector.
    Vector(Vector3),
    /// An embedded direction curve.
    Curve {
        /// Exact nonzero selector serialized before the curve.
        selector: NonZeroI64,
        /// Embedded direction curve.
        curve: NurbsCurve,
    },
}

/// The kind-discriminated tail of an embedded compound loft.
pub enum EmbeddedCompoundLoftTail {
    /// The kind-6 tail: one scale block and a ranged curve.
    Six {
        /// Two booleans opening the tail.
        flags: [bool; 2],
        /// The scale block of the tail.
        scale: Box<EmbeddedCompoundLoftScale>,
        /// The integer selector serialized after the scale block.
        selector: i64,
        /// The tail direction vector.
        direction: Vector3,
        /// Two parameter-range doubles.
        parameter_range: [f64; 2],
        /// The embedded curve closing the tail.
        curve: NurbsCurve,
    },
    /// The kind-7 tail: two flagged scale blocks.
    Seven {
        /// The boolean before the first scale block.
        first_flag: bool,
        /// The first scale block, when serialized.
        first_scale: Option<Box<EmbeddedCompoundLoftScale>>,
        /// The boolean before the second scale block.
        second_flag: bool,
        /// The second scale block.
        second_scale: Box<EmbeddedCompoundLoftScale>,
        /// The integer selector serialized after the scale blocks.
        selector: i64,
        /// The tail direction vector.
        direction: Vector3,
        /// Two booleans closing the tail.
        trailing_flags: [bool; 2],
    },
    /// The kind-0 tail: a direction carrier without scale blocks.
    Zero {
        /// Two booleans opening the tail.
        flags: [bool; 2],
        /// The direction carrier of the tail.
        direction: EmbeddedCompoundLoftDirection,
        /// Two booleans closing the tail.
        trailing_flags: [bool; 2],
    },
}

/// Embedded native compound loft before stable IR ids are assigned.
pub struct EmbeddedCompoundLoft {
    /// Four ordered optional scale blocks.
    pub scales: Box<[Option<EmbeddedCompoundLoftScale>; 4]>,
    /// A fifth scale block, when serialized.
    pub fifth_scale: Option<Box<EmbeddedCompoundLoftScale>>,
    /// Two booleans serialized after the scale blocks.
    pub flags: [bool; 2],
    /// The kind-discriminated tail.
    pub tail: EmbeddedCompoundLoftTail,
}

/// The shape block of an embedded scaled compound loft.
pub enum EmbeddedScaledCompoundLoftShape {
    /// The full form carries no extra fields.
    Full,
    /// The reduced form: parameter ranges and arrays in place of a cache.
    None {
        /// Two UV parameter intervals.
        parameter_ranges: [[f64; 2]; 2],
        /// Two parameter arrays.
        parameters: [Vec<f64>; 2],
    },
}

/// The branch-discriminated tail of an embedded scaled compound loft.
pub enum EmbeddedScaledCompoundLoftBranch {
    /// The extended branch closed by a direction vector.
    ExtendedVector {
        /// The first scale block, when serialized.
        first_scale: Option<Box<EmbeddedCompoundLoftScale>>,
        /// The second scale block.
        second_scale: Box<EmbeddedCompoundLoftScale>,
        /// The integer selector serialized after the scale blocks.
        selector: i64,
        /// The branch direction vector.
        direction: Vector3,
    },
    /// The extended branch closed by an embedded curve.
    ExtendedCurve {
        /// The scale block, when serialized.
        scale: Option<Box<EmbeddedCompoundLoftScale>>,
        /// The boolean serialized after the scale block.
        flag: bool,
        /// The singularity integer of the branch.
        singularity: i64,
        /// The embedded curve closing the branch.
        curve: NurbsCurve,
    },
    /// The direct branch: a flag, selector, and direction carrier.
    Direct {
        /// The boolean opening the branch.
        flag: bool,
        /// The direction carrier of the branch.
        direction: EmbeddedCompoundLoftDirection,
    },
}

/// Embedded native scaled compound loft before stable IR ids are assigned.
pub struct EmbeddedScaledCompoundLoft {
    /// The singularity integer opening the record body.
    pub singularity: i64,
    /// The shape block of the loft.
    pub shape: EmbeddedScaledCompoundLoftShape,
    /// Six discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub discontinuity_flag: bool,
    /// Three ordered optional scale blocks.
    pub scales: Box<[Option<EmbeddedCompoundLoftScale>; 3]>,
    /// Two booleans serialized after the scale blocks.
    pub flags: [bool; 2],
    /// The integer selector serialized after the flags.
    pub selector: i64,
    /// The branch-discriminated tail.
    pub branch: EmbeddedScaledCompoundLoftBranch,
    /// Two booleans serialized after the branch.
    pub trailing_flags: [bool; 2],
    /// The kind integer of the closing tail.
    pub tail_kind: i64,
    /// Two direction vectors of the closing tail.
    pub tail_directions: [Vector3; 2],
    /// The singularity integer of the closing tail.
    pub tail_singularity: i64,
    /// The embedded curve closing the record.
    pub tail_curve: NurbsCurve,
}

/// One law-expression operand of an embedded law formula.
pub enum EmbeddedLawExpression {
    /// A null operand.
    Null,
    /// A serializer-preserved textual law expression.
    Text(cadmpeg_core::text::NonBlankString),
    /// An integer operand.
    Integer(i64),
    /// A double operand.
    Double(f64),
    /// A point operand.
    Point(Point3),
    /// A vector operand.
    Vector(Vector3),
    /// A transform operand of thirteen scalars and three enums.
    Transform {
        /// Thirteen transform scalars.
        scalars: [f64; 13],
        /// Three transform enums.
        enums: [i64; 3],
    },
    /// A vector-form transform operand.
    TransformVec {
        /// Four transform vectors.
        vectors: [Vector3; 4],
        /// The transform scale.
        scale: f64,
        /// Three transform booleans.
        flags: [bool; 3],
    },
    /// An edge operand carrying an embedded curve.
    Edge {
        /// The embedded edge curve.
        curve: NurbsCurve,
        /// Optional endpoint bounds of the edge curve.
        endpoints: Option<[Option<f64>; 2]>,
        /// Two parameters closing the operand.
        parameters: [f64; 2],
    },
    /// A spline operand carrying raw knot and control arrays.
    Spline {
        /// The native identifier of the spline.
        native_id: i64,
        /// The raw knot array.
        knots: Vec<f64>,
        /// The raw control array.
        controls: Vec<f64>,
        /// The point closing the operand.
        point: Point3,
    },
    /// An algebraic operand applying an operator to nested operands.
    Algebraic {
        /// The operator name.
        operator: String,
        /// The nested operands, in stream order.
        operands: Vec<EmbeddedLawExpression>,
    },
}

/// One structurally valid law formula before stable IR ids are assigned.
pub enum EmbeddedLawFormula {
    /// The zero-payload native `null_law` form.
    Null,
    /// A checked non-sentinel name and its operands.
    Named {
        /// The formula name.
        name: cadmpeg_core::text::NonBlankString,
        /// The formula operands, in stream order.
        variables: Vec<EmbeddedLawExpression>,
    },
}

impl EmbeddedLawFormula {
    /// Native formula name.
    #[cfg(test)]
    pub(super) fn name(&self) -> &str {
        match self {
            Self::Null => "null_law",
            Self::Named { name, .. } => name.as_str(),
        }
    }

    /// Formula operands, empty for the null form.
    #[cfg(test)]
    fn variables(&self) -> &[EmbeddedLawExpression] {
        match self {
            Self::Null => &[],
            Self::Named { variables, .. } => variables,
        }
    }
}

/// Embedded native law surface before stable IR ids are assigned.
pub struct EmbeddedLawSurface {
    /// Two UV parameter intervals, when serialized.
    pub parameter_ranges: Option<[[f64; 2]; 2]>,
    /// The law formula that drives the surface.
    pub primary: EmbeddedLawFormula,
    /// Additional law formulas serialized after the primary.
    pub additional: Vec<EmbeddedLawFormula>,
    /// Neutral tail fields of the record.
    pub tail: cadmpeg_ir::geometry::LawSurfaceTail,
    /// Six discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
}

/// The layout-discriminated body of an embedded skin surface.
pub enum EmbeddedSkinSurfaceLayout {
    /// The profile-list form.
    Profiles {
        /// The profile members, in stream order.
        profiles: Vec<EmbeddedLoftProfileMember<ClassicLoftProfileData>>,
        /// The embedded path curve.
        path: NurbsCurve,
        /// Two integers closing the form.
        tail: [i64; 2],
    },
    /// The compact two-curve form.
    Compact {
        /// Native compact-layout inner integer.
        inner_count: i64,
        /// The first embedded curve.
        curve: NurbsCurve,
        /// Neutral subdata fields of the first curve.
        subdata: cadmpeg_ir::geometry::LoftSubdata,
        /// The integer serialized after the first curve.
        first_tail: i64,
        /// The second embedded curve.
        secondary_curve: NurbsCurve,
        /// The integer serialized after the second curve.
        second_tail: i64,
    },
}

/// Embedded native skin surface before stable IR ids are assigned.
pub struct EmbeddedSkinSurface {
    /// The first integer of the record body.
    pub surface_boolean: i64,
    /// The surface-normal integer.
    pub surface_normal: i64,
    /// The surface-direction integer.
    pub surface_direction: i64,
    /// The profile count.
    pub count: i64,
    /// The parameter serialized after the count.
    pub parameter: f64,
    /// The layout-discriminated body.
    pub layout: EmbeddedSkinSurfaceLayout,
    /// The skin direction vector.
    pub direction: Vector3,
    /// The parameter serialized after the direction.
    pub trailing_parameter: f64,
    /// The law formula of the skin.
    pub formula: EmbeddedLawFormula,
    /// The embedded parameter curve of the skin.
    pub parameter_curve: NurbsCurve,
    /// Six discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub discontinuity_flag: bool,
}

/// Embedded native net surface before stable IR ids are assigned.
pub struct EmbeddedNetSurface {
    /// The two section lists, in stream order.
    pub sections: Box<[Vec<EmbeddedLoftSectionEntry>; 2]>,
    /// Twelve frame parameters.
    pub frame_parameters: [f64; 12],
    /// The integer serialized after the frame parameters.
    pub flag: i64,
    /// Four direction vectors.
    pub directions: [Vector3; 4],
    /// Four law formulas, in stream order.
    pub formulas: Box<[EmbeddedLawFormula; 4]>,
    /// Six discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub discontinuity_flag: bool,
}

/// Shared profile, frame, and path of an explicit or law-driven sweep.
pub struct SweepProfile {
    /// The embedded profile curve.
    pub profile: NurbsCurve,
    /// The mode integer of the sweep.
    pub mode: i64,
    /// Two parameter bounds of the profile curve.
    pub profile_range: [f64; 2],
    /// The profile frame point and vector, when serialized.
    pub profile_frame: Option<(Point3, Vector3)>,
    /// The sweep origin point.
    pub origin: Point3,
    /// Three direction vectors.
    pub directions: [Vector3; 3],
    /// The embedded path curve.
    pub path: NurbsCurve,
    /// Two parameter bounds of the path curve.
    pub path_range: [f64; 2],
    /// The parameter serialized after the path range.
    pub path_parameter: f64,
}

/// The layout-discriminated body of an embedded sweep surface.
pub enum LegacySweepLayout {
    /// The profile-first form: profile, spine, and a formula triple.
    ProfileFirst {
        /// The embedded profile curve.
        profile: Box<NurbsCurve>,
        /// The embedded spine curve.
        spine: Box<NurbsCurve>,
        /// The secondary kind integer.
        secondary_kind: i64,
        /// Five direction vectors.
        directions: [Vector3; 5],
        /// The sweep origin point.
        origin: Point3,
        /// Four parameters closing the form.
        parameters: [f64; 4],
        /// Three law formulas, in stream order.
        formulas: Box<[EmbeddedLawFormula; 3]>,
    },
    /// An explicit or law-driven sweep with a shared profile and path.
    Sweep {
        /// Shared profile and path fields.
        profile: Box<SweepProfile>,
        /// The fields selected by the sweep form.
        tail: SweepTail,
    },
}

/// Form-specific fields following the shared sweep profile.
pub enum SweepTail {
    /// A formula or law tail shared with revision sweeps.
    LawOrFormula(SweepLawOrFormula),
    /// The explicit form closed by a guide curve.
    Guide {
        /// The boolean serialized before the path.
        trajectory_flag: bool,
        /// Two booleans serialized before the guide curve.
        guide_flags: [bool; 2],
        /// The embedded guide curve.
        guide_curve: NurbsCurve,
        /// Two parameter bounds of the guide curve.
        guide_range: [f64; 2],
        /// Two mode integers of the guide.
        guide_modes: [i64; 2],
        /// Six parameters of the guide.
        guide_parameters: [f64; 6],
        /// Three booleans closing the form.
        trailing_flags: [bool; 3],
    },
    /// The explicit form closed by a support surface.
    Surface {
        /// The boolean serialized before the path.
        trajectory_flag: bool,
        /// The singularity integer of the form.
        singularity: i64,
        /// The embedded support surface.
        support_surface: SurfaceGeometry,
        /// An auxiliary embedded curve, when serialized.
        auxiliary_curve: Option<NurbsCurve>,
        /// The boolean serialized after the support surface.
        support_flag: bool,
        /// The legacy boolean closing the form, when serialized.
        legacy_flag: Option<bool>,
    },
}

/// The tails admitted by both legacy and revision sweeps.
pub enum SweepLawOrFormula {
    /// The explicit form closed by one law formula.
    Formula {
        /// The boolean serialized before the path.
        trajectory_flag: bool,
        /// The boolean serialized before the formula.
        formula_flag: bool,
        /// The law formula closing the form.
        formula: EmbeddedLawFormula,
        /// The boolean closing the form.
        trailing_flag: bool,
    },
    /// The law-driven form with two law expressions and one formula.
    Law {
        /// The first law expression.
        first_law: Box<EmbeddedLawExpression>,
        /// The mode integer of the first law.
        first_mode: i64,
        /// Two parameter bounds of the first law.
        first_range: [f64; 2],
        /// The law direction vector.
        law_direction: Vector3,
        /// The mode integer serialized before the path.
        path_mode: i64,
        /// The boolean serialized before the path.
        path_flag: bool,
        /// The boolean serialized before the second law.
        second_law_flag: bool,
        /// The second law expression.
        second_law: Box<EmbeddedLawExpression>,
        /// The mode integer serialized before the formula.
        formula_mode: i64,
        /// The law formula closing the form.
        formula: EmbeddedLawFormula,
        /// The boolean closing the form.
        trailing_flag: bool,
    },
}

/// The legacy and revision sweep layouts.
pub enum EmbeddedSweepSurfaceLayout {
    /// A legacy sweep with its native kind.
    Legacy {
        /// The primary kind integer.
        primary_kind: i64,
        /// The legacy construction fields.
        layout: LegacySweepLayout,
    },
    /// A revision sweep with a profile and a law or formula tail.
    Revision {
        /// The revision form fields.
        form: cadmpeg_ir::geometry::SweepRevisionForm,
        /// The profile and path fields.
        profile: Box<SweepProfile>,
        /// The law or formula tail.
        tail: SweepLawOrFormula,
    },
}

/// Embedded native sweep surface before stable IR ids are assigned.
pub struct EmbeddedSweepSurface {
    /// The native construction layout.
    pub layout: EmbeddedSweepSurfaceLayout,
    /// Six discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// The boolean serialized after the discontinuity arrays.
    pub discontinuity_flag: bool,
}

/// Embedded native deformable surface before stable support ids are assigned.
pub struct EmbeddedDeformableSurface {
    /// The embedded support surface.
    pub support: SurfaceGeometry,
    /// The native tail layout.
    pub layout: EmbeddedDeformableSurfaceLayout,
    /// The mode-discriminated payload.
    pub data: EmbeddedDeformableSurfaceData,
}

/// The legacy and revision deformable surface tails.
pub enum EmbeddedDeformableSurfaceLayout {
    /// The legacy discontinuity data.
    Legacy {
        /// The six discontinuity arrays.
        discontinuities: [Vec<f64>; 6],
        /// The flag following the arrays.
        discontinuity_flag: bool,
    },
    /// The revision form that owns the discontinuity data.
    Revision(Box<cadmpeg_ir::geometry::RevisionSurfaceForm>),
}

/// The mode-discriminated payload of an embedded deformable surface.
pub enum EmbeddedDeformableSurfaceData {
    /// A payload fully resolved to neutral IR fields.
    Resolved(cadmpeg_ir::geometry::DeformableSurfaceData),
    /// The surface-curve payload: an embedded surface, curve, and frame.
    SurfaceCurve {
        /// The embedded payload surface.
        surface: SurfaceGeometry,
        /// The native identifier of the payload.
        native_id: i64,
        /// The boolean serialized after the native identifier.
        flag: bool,
        /// The parameter serialized after the flag.
        first_parameter: f64,
        /// The integer selector of the payload.
        selector: i64,
        /// The parameter serialized after the selector.
        second_parameter: f64,
        /// The embedded payload curve.
        curve: NurbsCurve,
        /// Four frame vectors.
        vectors: [Vector3; 4],
        /// The parameter serialized after the frame vectors.
        frame_parameter: f64,
        /// Three booleans serialized after the frame parameter.
        flags: [bool; 3],
        /// Counted list of parameter triples.
        parameter_triples: Vec<[f64; 3]>,
    },
    /// The full payload: a leading frame, surface, curve, and vector frames.
    Full {
        /// Four ordered leading frame vectors.
        leading_vectors: [Vector3; 4],
        /// The parameter serialized after the leading vectors.
        leading_parameter: f64,
        /// Three booleans serialized after the leading parameter.
        leading_flags: [bool; 3],
        /// The integer selector of the payload.
        selector: i64,
        /// The embedded payload surface.
        surface: SurfaceGeometry,
        /// The native identifier of the payload.
        native_id: i64,
        /// The boolean serialized after the native identifier.
        flag: bool,
        /// The parameter serialized after the flag.
        first_parameter: f64,
        /// The version integer, when serialized.
        version_value: Option<i64>,
        /// The parameter serialized after the version value.
        second_parameter: f64,
        /// The embedded payload curve.
        curve: NurbsCurve,
        /// Two deformation vector frames.
        frames: Box<[cadmpeg_ir::geometry::DeformableVectorFrame; 2]>,
        /// The integer closing the payload.
        trailing_value: i64,
    },
}

fn compound_loft_scale(cur: &mut Cur<'_>) -> Option<Nullable<EmbeddedCompoundLoftScale>> {
    if matches!(cur.peek(), Some(Token::True | Token::False)) {
        return Some(Nullable::Null);
    }
    let count = usize::try_from(cur.take_long()?).ok()?;
    if count > 100_000 {
        return None;
    }
    let mut members = Vec::new();
    for _ in 0..count {
        let type_code = cur.take_long()?;
        let (curve, curve_end) = curve_block(cur.toks(), cur.pos())?;
        cur.set_pos(curve_end);
        let data = loft_profile_data(cur, type_code)?;
        members.push(EmbeddedLoftProfileMember { curve, data });
    }
    let (path, path_end) = curve_block(cur.toks(), cur.pos())?;
    cur.set_pos(path_end);
    let auxiliary_count = usize::try_from(cur.take_long()?).ok()?;
    if auxiliary_count > 100_000 {
        return None;
    }
    let mut auxiliaries = Vec::new();
    for _ in 0..auxiliary_count {
        let (curve, curve_end) = curve_block(cur.toks(), cur.pos())?;
        cur.set_pos(curve_end);
        auxiliaries.push(curve);
    }
    let tail = [cur.take_long()?, cur.take_long()?];
    Some(Nullable::Value(EmbeddedCompoundLoftScale {
        members,
        path,
        auxiliaries,
        tail,
    }))
}

/// Exact rational quadratic NURBS of a full native ellipse.
pub(super) fn ellipse_to_nurbs(
    center: [f64; 3],
    normal: [f64; 3],
    major: [f64; 3],
    ratio: f64,
) -> Option<NurbsCurve> {
    let length = major[0].hypot(major[1]).hypot(major[2]);
    (length.is_finite() && length > 0.0).then_some(())?;
    let minor_direction = [
        normal[1] * major[2] - normal[2] * major[1],
        normal[2] * major[0] - normal[0] * major[2],
        normal[0] * major[1] - normal[1] * major[0],
    ];
    let minor_length = minor_direction[0]
        .hypot(minor_direction[1])
        .hypot(minor_direction[2]);
    (minor_length.is_finite() && minor_length > 0.0).then_some(())?;
    let minor_scale = ratio * length / minor_length;
    let minor = [
        minor_direction[0] * minor_scale,
        minor_direction[1] * minor_scale,
        minor_direction[2] * minor_scale,
    ];
    let at = |mj: f64, mn: f64| {
        Point3::new(
            (center[0] + mj * major[0] + mn * minor[0]) * LEN_TO_MM,
            (center[1] + mj * major[1] + mn * minor[1]) * LEN_TO_MM,
            (center[2] + mj * major[2] + mn * minor[2]) * LEN_TO_MM,
        )
    };
    // The rational quadratic circle states each pole with its own weight, so
    // the carrier reads rows and there is no pole lane and weight lane to pair.
    let corner = cadmpeg_ir::scalar::NonZeroReal::FRAC_1_SQRT_2;
    let full = cadmpeg_ir::scalar::NonZeroReal::ONE;
    let pole = |point, weight| cadmpeg_ir::geometry::nurbs::WeightedPole3 { point, weight };
    NurbsCurve::new(
        2,
        vec![
            0.0, 0.0, 0.0, 0.25, 0.25, 0.5, 0.5, 0.75, 0.75, 1.0, 1.0, 1.0,
        ],
        cadmpeg_ir::geometry::nurbs::NurbsPoles3::Rational {
            points: vec![
                pole(at(1.0, 0.0), full),
                pole(at(1.0, 1.0), corner),
                pole(at(0.0, 1.0), full),
                pole(at(-1.0, 1.0), corner),
                pole(at(-1.0, 0.0), full),
                pole(at(-1.0, -1.0), corner),
                pole(at(0.0, -1.0), full),
                pole(at(1.0, -1.0), corner),
                pole(at(1.0, 0.0), full),
            ],
        },
        false,
    )
    .ok()
}

/// The highest stream save format version whose revision-gated loft profile
/// members omit the ASM integer between the member payload and its constraint
/// subdata. Save format 22300 through 22600 streams omit it; save format 23200
/// streams carry it.
const LOFT_ASM_EXTENSION_ABSENT_THROUGH: u32 = 22600;

/// Whether a revision-gated loft profile member in this stream carries the ASM
/// integer. The stream save format selects this gate. The record serializer
/// revision remains a separate field; one revision can carry the integer in a
/// later stream and omit it in an earlier stream.
fn revision_loft_carries_asm_extension(table: &SubtypeTable) -> bool {
    table
        .save_format_version()
        .is_none_or(|version| version > LOFT_ASM_EXTENSION_ABSENT_THROUGH)
}

/// Revision-gated loft profile data: the type-selected member payload, an
/// optional ASM integer, and constraint subdata with trailing row pairs.
fn revision_loft_profile_data(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    table: &SubtypeTable,
    type_code: i64,
    asm_extension_present: bool,
    endpoints: [Option<f64>; 2],
) -> Option<Result<LoftProfileData, cadmpeg_core::CodecError>> {
    let tail = |cur: &mut Cur<'_>| {
        let asm_extension = if asm_extension_present {
            Some(cur.take_long()?)
        } else {
            None
        };
        let subdata = loft_subdata_form(cur, true)?;
        let direction = if cur.take_bool()? {
            let value = cur.take_vector3()?;
            Some(Vector3::new(value[0], value[1], value[2]))
        } else {
            None
        };
        Some(Ok((asm_extension, subdata, direction)))
    };
    match std::num::NonZeroI64::new(type_code) {
        Some(type_code) => {
            let crate::nurbs::proc_curve::EmbeddedSurfaceWithBounds {
                surface,
                chart,
                bounds: support_bounds,
                ..
            } = match optional_embedded_surface_with_bounds(ctx, cur, table)? {
                Ok(surface) => surface,
                Err(error) => return Some(Err(error)),
            };
            let mut pcurve = nullable_embedded_pcurve(cur)?.value();
            if let Some(pcurve) = &mut pcurve {
                chart.normalize(pcurve)?;
            }
            let first_flag = cur.take_bool()?;
            let (asm_extension, subdata, direction) = propagate_resource!(tail(cur)?);
            Some(Ok(LoftProfileData::RevisionSupport {
                endpoints,
                type_code,
                surface: surface.into_surface(),
                support_bounds,
                pcurve,
                first_flag,
                asm_extension,
                subdata,
                direction,
            }))
        }
        None => {
            let pcurve = nullable_embedded_pcurve(cur)?.value();
            let secondary_pcurve = nullable_embedded_pcurve(cur)?.value();
            let (asm_extension, subdata, direction) = propagate_resource!(tail(cur)?);
            Some(Ok(LoftProfileData::RevisionPcurvePair {
                endpoints,
                pcurve,
                secondary_pcurve,
                asm_extension,
                subdata,
                direction,
            }))
        }
    }
}

fn revision_loft_section(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    table: &SubtypeTable,
    asm_extension_present: bool,
) -> Option<Result<Vec<EmbeddedLoftSectionEntry>, cadmpeg_core::CodecError>> {
    let count = usize::try_from(cur.take_long()?).ok()?;
    // Each entry consumes at least one double token for its parameter.
    let count = bounded_len(
        cadmpeg_core::decode::u64_from_index(count),
        1,
        cur.rest().len(),
    )?;
    let mut entries = Vec::new();
    for _ in 0..count {
        let parameter = cur.take_f64()?;
        let member_count = usize::try_from(cur.take_long()?).ok()?;
        // Each member consumes at least its type-code token.
        let member_count = bounded_len(
            cadmpeg_core::decode::u64_from_index(member_count),
            1,
            cur.rest().len(),
        )?;
        let mut profile = Vec::new();
        for _ in 0..member_count {
            let type_code = cur.take_long()?;
            let curve = embedded_base_curve_resolving_refs(cur, table)?;
            let endpoints = [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ];
            let data = match revision_loft_profile_data(
                ctx,
                cur,
                table,
                type_code,
                asm_extension_present,
                endpoints,
            )? {
                Ok(data) => data,
                Err(error) => return Some(Err(error)),
            };
            profile.push(EmbeddedLoftProfileMember { curve, data });
        }
        let saved = cur.pos();
        let path_curve = if cur.take_ident() == Some("null_curve") {
            None
        } else {
            cur.set_pos(saved);
            let curve = embedded_base_curve_resolving_refs(cur, table)?;
            let endpoints = [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ];
            Some(EmbeddedRevisionLoftPathCurve {
                geometry: curve,
                endpoints,
            })
        };
        let auxiliary_count = usize::try_from(cur.take_long()?).ok()?;
        // Each auxiliary consumes at least its curve-block marker token.
        let auxiliary_count = bounded_len(
            cadmpeg_core::decode::u64_from_index(auxiliary_count),
            1,
            cur.rest().len(),
        )?;
        let mut auxiliaries = Vec::new();
        for _ in 0..auxiliary_count {
            let (auxiliary, auxiliary_end) = curve_block(cur.toks(), cur.pos())?;
            cur.set_pos(auxiliary_end);
            auxiliaries.push(auxiliary);
        }
        let flag = cur.take_long()?;
        entries.push(EmbeddedLoftSectionEntry {
            parameter,
            profile,
            path: EmbeddedLoftPath {
                layout: EmbeddedLoftPathLayout::Revision(path_curve),
                auxiliaries,
                flag,
            },
        });
    }
    Some(Ok(entries))
}

fn loft_subdata(cur: &mut Cur<'_>) -> Option<cadmpeg_ir::geometry::LoftSubdata> {
    loft_subdata_form(cur, false)
}

fn loft_subdata_form(
    cur: &mut Cur<'_>,
    revision: bool,
) -> Option<cadmpeg_ir::geometry::LoftSubdata> {
    use cadmpeg_ir::geometry::{LoftSubdata, LoftSubdataRow};
    let type_code = cur.take_long()?;
    let row_count = cur.take_long()?;
    let column_count = cur.take_long()?;
    let rows_to_read = if type_code == 211 {
        1
    } else {
        usize::try_from(row_count).ok()?
    };
    let columns_to_read = if type_code == 211 {
        0
    } else {
        usize::try_from(column_count).ok()?
    };
    // Each row has one parameter pair, its column pairs, and a revision pair.
    let pairs_per_row = 1usize
        .checked_add(columns_to_read)?
        .checked_add(usize::from(revision && type_code != 211))?;
    let tokens_per_row = pairs_per_row.checked_mul(2)?;
    let rows_to_read = bounded_len(
        cadmpeg_core::decode::u64_from_index(rows_to_read),
        tokens_per_row,
        cur.rest().len(),
    )?;
    let mut rows = Vec::new();
    for _ in 0..rows_to_read {
        let parameters = [cur.take_f64()?, cur.take_f64()?];
        let mut columns = Vec::new();
        if type_code != 211 {
            columns = Vec::new();
            for _ in 0..columns_to_read {
                columns.push([cur.take_f64()?, cur.take_f64()?]);
            }
        }
        let extra = if revision && type_code != 211 {
            Some([cur.take_f64()?, cur.take_f64()?])
        } else {
            None
        };
        rows.push(LoftSubdataRow {
            parameters,
            columns,
            extra,
        });
    }
    if type_code == 211 {
        let [row] = rows.as_slice() else {
            return None;
        };
        Some(LoftSubdata::type_211(
            [row_count, column_count],
            row.parameters,
        ))
    } else {
        LoftSubdata::table(type_code, rows)
    }
}

pub(super) fn loft_profile_data(
    cur: &mut Cur<'_>,
    type_code: i64,
) -> Option<ClassicLoftProfileData> {
    let EmbeddedSupport { surface, chart, .. } = embedded_support(cur)?;
    let saved = cur.pos();
    let pcurve = if cur.take_ident() == Some("nullbs") {
        None
    } else {
        cur.set_pos(saved);
        let (mut pcurve, end) = pcurve_block_with_end(cur.toks(), cur.pos())?;
        cur.set_pos(end);
        chart.normalize(&mut pcurve)?;
        Some(pcurve)
    };
    let first_flag = cur.take_bool()?;
    let asm_extension = cur.take_long()?;
    let subdata = loft_subdata(cur)?;
    let direction = if cur.take_bool()? {
        let value = cur.take_vector3()?;
        Some(Vector3::new(value[0], value[1], value[2]))
    } else {
        None
    };
    Some(ClassicLoftProfileData {
        type_code,
        surface,
        pcurve,
        first_flag,
        asm_extension,
        subdata,
        direction,
    })
}

fn loft_section(cur: &mut Cur<'_>) -> Option<Vec<EmbeddedLoftSectionEntry>> {
    let count = usize::try_from(cur.take_long()?).ok()?;
    // Each entry consumes at least one double token for its parameter.
    let count = bounded_len(
        cadmpeg_core::decode::u64_from_index(count),
        1,
        cur.rest().len(),
    )?;
    let mut entries = Vec::new();
    for _ in 0..count {
        let parameter = cur.take_f64()?;
        let member_count = usize::try_from(cur.take_long()?).ok()?;
        // Each member consumes at least its type-code token.
        let member_count = bounded_len(
            cadmpeg_core::decode::u64_from_index(member_count),
            1,
            cur.rest().len(),
        )?;
        let mut profile = Vec::new();
        for _ in 0..member_count {
            let type_code = cur.take_long()?;
            let (curve, curve_end) = curve_block(cur.toks(), cur.pos())?;
            cur.set_pos(curve_end);
            let data = loft_profile_data(cur, type_code)?;
            profile.push(EmbeddedLoftProfileMember {
                curve,
                data: LoftProfileData::Classic(data),
            });
        }
        let (curve, curve_end) = curve_block(cur.toks(), cur.pos())?;
        cur.set_pos(curve_end);
        let auxiliary_count = usize::try_from(cur.take_long()?).ok()?;
        // Each auxiliary consumes at least its curve-block marker token.
        let auxiliary_count = bounded_len(
            cadmpeg_core::decode::u64_from_index(auxiliary_count),
            1,
            cur.rest().len(),
        )?;
        let mut auxiliaries = Vec::new();
        for _ in 0..auxiliary_count {
            let (auxiliary, auxiliary_end) = curve_block(cur.toks(), cur.pos())?;
            cur.set_pos(auxiliary_end);
            auxiliaries.push(auxiliary);
        }
        let flag = cur.take_long()?;
        entries.push(EmbeddedLoftSectionEntry {
            parameter,
            profile,
            path: EmbeddedLoftPath {
                layout: EmbeddedLoftPathLayout::Legacy(curve),
                auxiliaries,
                flag,
            },
        });
    }
    Some(entries)
}

fn revision_loft(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    span: &[Token],
    position: usize,
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let table = resolver?;
    let mut cur = Cur::at(span, position);
    let revision = PositiveI64::new(cur.take_long()?)?;
    let asm_extension_present = revision_loft_carries_asm_extension(table);
    let sections = [
        match revision_loft_section(ctx, &mut cur, table, asm_extension_present)? {
            Ok(section) => section,
            Err(error) => return Some(Err(error)),
        },
        match revision_loft_section(ctx, &mut cur, table, asm_extension_present)? {
            Ok(section) => section,
            Err(error) => return Some(Err(error)),
        },
    ];
    let wrap_ranges = [
        [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ],
        [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ],
    ];
    let mut flags = [false; 4];
    for flag in &mut flags {
        *flag = cur.take_bool()?;
    }
    let ints = [cur.take_long()?, cur.take_long()?];
    let RevisionSurfaceTail {
        cache,
        discontinuities,
        tail_flag,
    } = revision_surface_tail(&mut cur)?;
    cur.at_scope_end().then_some(())?;
    Some(Ok(DecodedProceduralSurface::revision(
        DecodedProceduralSurfaceDefinition::Loft(EmbeddedLoft {
            sections,
            layout: EmbeddedLoftLayout::Revision(
                Box::new(cadmpeg_ir::geometry::LoftRevisionForm {
                    revision,
                    flags,
                    ints,
                    cache: cache.into_form()?,
                    discontinuities,
                    tail_flag,
                }),
                wrap_ranges,
            ),
        }),
    )))
}

fn loft_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    use cadmpeg_ir::geometry::LoftBridgeToken;
    let names = ["loft_spl_sur", "loftsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    // The modern name uses the revision-gated layout.
    if matches!(cur.peek(), Some(Token::Long(_))) && name == "loft_spl_sur" {
        if let Some(decoded) = revision_loft(ctx, span, cur.pos(), resolver) {
            return Some(decoded);
        }
    }
    let sections = [loft_section(&mut cur)?, loft_section(&mut cur)?];
    let parameter_ranges = [
        [cur.take_f64()?, cur.take_f64()?],
        [cur.take_f64()?, cur.take_f64()?],
    ];
    let closures = [cur.take_enum()?, cur.take_enum()?];
    let singularities = [cur.take_enum()?, cur.take_enum()?];
    let mode = cur.take_long()?;
    let mut bridge = Vec::new();
    while toks::marker_at(span, cur.pos()).is_none() {
        match cur.peek()? {
            Token::True | Token::False => {
                bridge.push(LoftBridgeToken::Boolean(cur.take_bool()?));
            }
            Token::Long(_) => bridge.push(LoftBridgeToken::Integer(cur.take_long()?)),
            Token::Double(_) => bridge.push(LoftBridgeToken::Double(cur.take_f64()?)),
            Token::Enum(_) => bridge.push(LoftBridgeToken::Enum(cur.take_enum()?)),
            Token::Str(_) => {
                let value = cur.take_str()?;
                let value = value.to_owned();
                bridge.push(LoftBridgeToken::Text(value));
            }
            _ => return None,
        }
    }
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = optional_trailing_cache_tolerance(&mut cur)?.value();
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Loft(EmbeddedLoft {
            sections,
            layout: EmbeddedLoftLayout::Legacy {
                ranges: parameter_ranges,
                closures,
                singularities,
                mode,
                bridge,
            },
        }),
        cache_fit_tolerance,
    )))
}

/// One revision-gated compound-loft scale block: counted profile members,
/// nullable path curve with optional endpoints, counted auxiliary BS3
/// curves, and one tail integer.
fn revision_cl_scale(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    table: &SubtypeTable,
    asm_extension_present: bool,
) -> Option<Result<(Vec<EmbeddedLoftProfileMember>, EmbeddedLoftPath), cadmpeg_core::CodecError>> {
    let member_count = usize::try_from(cur.take_long()?).ok()?;
    // Each member consumes at least its type-code token.
    let member_count = bounded_len(
        cadmpeg_core::decode::u64_from_index(member_count),
        1,
        cur.rest().len(),
    )?;
    let mut profile = Vec::new();
    for _ in 0..member_count {
        let type_code = cur.take_long()?;
        let curve = embedded_base_curve_resolving_refs(cur, table)?;
        let endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let data = match revision_loft_profile_data(
            ctx,
            cur,
            table,
            type_code,
            asm_extension_present,
            endpoints,
        )? {
            Ok(data) => data,
            Err(error) => return Some(Err(error)),
        };
        profile.push(EmbeddedLoftProfileMember { curve, data });
    }
    let saved = cur.pos();
    let path_curve = if cur.take_ident() == Some("null_curve") {
        None
    } else {
        cur.set_pos(saved);
        let curve = embedded_base_curve_resolving_refs(cur, table)?;
        let endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        Some(EmbeddedRevisionLoftPathCurve {
            geometry: curve,
            endpoints,
        })
    };
    let auxiliary_count = usize::try_from(cur.take_long()?).ok()?;
    // Each auxiliary consumes at least its curve-block marker token.
    let auxiliary_count = bounded_len(
        cadmpeg_core::decode::u64_from_index(auxiliary_count),
        1,
        cur.rest().len(),
    )?;
    let mut auxiliaries = Vec::new();
    for _ in 0..auxiliary_count {
        let (auxiliary, auxiliary_end) = curve_block(cur.toks(), cur.pos())?;
        cur.set_pos(auxiliary_end);
        auxiliaries.push(auxiliary);
    }
    let flag = cur.take_long()?;
    Some(Ok((
        profile,
        EmbeddedLoftPath {
            layout: EmbeddedLoftPathLayout::Revision(path_curve),
            auxiliaries,
            flag,
        },
    )))
}

fn revision_compound_loft(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    span: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let table = resolver?;
    let mut cur = Cur::at(span, 2);
    let revision = PositiveI64::new(cur.take_long()?)?;
    let RevisionSurfaceTail {
        cache,
        discontinuities,
        tail_flag,
    } = revision_surface_tail(&mut cur)?;
    let asm_extension_present = revision_loft_carries_asm_extension(table);
    let (base_profile, base_path) =
        match revision_cl_scale(ctx, &mut cur, table, asm_extension_present)? {
            Ok(scale) => scale,
            Err(error) => return Some(Err(error)),
        };
    let entry_count = usize::try_from(cur.take_long()?).ok()?;
    // Each entry consumes at least its member-count token.
    let entry_count = bounded_len(
        cadmpeg_core::decode::u64_from_index(entry_count),
        1,
        cur.rest().len(),
    )?;
    let mut entries = Vec::new();
    for _ in 0..entry_count {
        let (profile, path) = match revision_cl_scale(ctx, &mut cur, table, asm_extension_present)?
        {
            Ok(scale) => scale,
            Err(error) => return Some(Err(error)),
        };
        let parameter = cur.take_f64()?;
        entries.push(EmbeddedLoftSectionEntry {
            parameter,
            profile,
            path,
        });
    }
    let flags = [cur.take_bool()?, cur.take_bool()?];
    let kind = cur.take_long()?;
    // The revision layout defines the kind-zero payload.
    (kind == 0).then_some(())?;
    let kind_flags = [cur.take_bool()?, cur.take_bool()?];
    let selector = cur.take_long()?;
    let direction = if selector == 0 {
        let value = cur.take_vector3()?;
        EmbeddedCompoundLoftDirection::Vector(Vector3::new(value[0], value[1], value[2]))
    } else {
        let (curve, curve_end) = curve_block(span, cur.pos())?;
        cur.set_pos(curve_end);
        EmbeddedCompoundLoftDirection::Curve {
            selector: NonZeroI64::new(selector)?,
            curve,
        }
    };
    let interval = [
        cur.take_optional_range_value()?.value(),
        cur.take_optional_range_value()?.value(),
    ];
    let tail = match interval {
        [None, None] => cadmpeg_ir::geometry::RevisionCompoundLoftTail::Unbounded {},
        [Some(value), None] => {
            cadmpeg_ir::geometry::RevisionCompoundLoftTail::LowerBound { lower: value }
        }
        [None, Some(value)] => {
            cadmpeg_ir::geometry::RevisionCompoundLoftTail::UpperBound { upper: value }
        }
        [Some(lower), Some(upper)] => {
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            cadmpeg_ir::geometry::RevisionCompoundLoftTail::Curve {
                interval: [lower, upper],
                curve,
            }
        }
    };
    cur.at_scope_end().then_some(())?;
    Some(Ok(DecodedProceduralSurface::revision(
        DecodedProceduralSurfaceDefinition::RevisionCompoundLoft(Box::new(
            EmbeddedRevisionCompoundLoft {
                revision,
                cache: cache.into_form()?,
                discontinuities,
                tail_flag,
                base_profile,
                base_path,
                entries,
                flags,
                kind_flags,
                direction,
                tail,
            },
        )),
    )))
}

fn compound_loft_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let (start, _) = toks::find_owned_subtype_marker(toks, &["cl_loft_spl_sur"])?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        return revision_compound_loft(ctx, span, resolver);
    }
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
    let scales = Box::new([
        compound_loft_scale(&mut cur)?.value(),
        compound_loft_scale(&mut cur)?.value(),
        compound_loft_scale(&mut cur)?.value(),
        compound_loft_scale(&mut cur)?.value(),
    ]);
    let fifth_scale = if matches!(cur.peek(), Some(Token::Long(_))) {
        compound_loft_scale(&mut cur)?.value().map(Box::new)
    } else {
        None
    };
    let flags = [cur.take_bool()?, cur.take_bool()?];
    let kind = cur.take_long()?;
    let tail = match kind {
        6 => {
            let tail_flags = [cur.take_bool()?, cur.take_bool()?];
            let scale = Box::new(compound_loft_scale(&mut cur)?.value()?);
            let selector = cur.take_long()?;
            let direction = cur.take_vector3()?;
            let parameter_range = [cur.take_range_value()?, cur.take_range_value()?];
            let (curve, _) = curve_block(span, cur.pos())?;
            EmbeddedCompoundLoftTail::Six {
                flags: tail_flags,
                scale,
                selector,
                direction: Vector3::new(direction[0], direction[1], direction[2]),
                parameter_range,
                curve,
            }
        }
        7 => {
            let first_flag = cur.take_bool()?;
            let first_scale = compound_loft_scale(&mut cur)?.value().map(Box::new);
            let second_flag = cur.take_bool()?;
            let second_scale = Box::new(compound_loft_scale(&mut cur)?.value()?);
            let selector = cur.take_long()?;
            let direction = cur.take_vector3()?;
            let trailing_flags = [cur.take_bool()?, cur.take_bool()?];
            EmbeddedCompoundLoftTail::Seven {
                first_flag,
                first_scale,
                second_flag,
                second_scale,
                selector,
                direction: Vector3::new(direction[0], direction[1], direction[2]),
                trailing_flags,
            }
        }
        0 => {
            let tail_flags = [cur.take_bool()?, cur.take_bool()?];
            let selector = cur.take_long()?;
            let direction = if selector == 0 {
                let value = cur.take_vector3()?;
                EmbeddedCompoundLoftDirection::Vector(Vector3::new(value[0], value[1], value[2]))
            } else {
                let (curve, curve_end) = curve_block(span, cur.pos())?;
                cur.set_pos(curve_end);
                EmbeddedCompoundLoftDirection::Curve {
                    selector: NonZeroI64::new(selector)?,
                    curve,
                }
            };
            let trailing_flags = [cur.take_bool()?, cur.take_bool()?];
            EmbeddedCompoundLoftTail::Zero {
                flags: tail_flags,
                direction,
                trailing_flags,
            }
        }
        _ => return None,
    };
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::CompoundLoft(Box::new(EmbeddedCompoundLoft {
            scales,
            fifth_scale,
            flags,
            tail,
        })),
        cache_fit_tolerance,
    )))
}

fn scaled_compound_loft_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    let names = ["scaled_cloft_spl_sur", "sclclftsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let singularity = cur.take_enum()?;
    let (shape, cache_fit_tolerance) = if cur.peek().is_some_and(Token::is_payload_ident) {
        let (_, cache_end) = surface_block(span, cur.pos())?;
        cur.set_pos(cache_end);
        let tolerance = cur.take_f64()? * LEN_TO_MM;
        (EmbeddedScaledCompoundLoftShape::Full, Some(tolerance))
    } else {
        let parameter_ranges = [
            [cur.take_range_value()?, cur.take_range_value()?],
            [cur.take_range_value()?, cur.take_range_value()?],
        ];
        let parameters = [cur.take_float_array()?, cur.take_float_array()?];
        (
            EmbeddedScaledCompoundLoftShape::None {
                parameter_ranges,
                parameters,
            },
            None,
        )
    };
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    let discontinuity_flag = cur.take_bool()?;
    let scales = Box::new([
        compound_loft_scale(&mut cur)?.value(),
        compound_loft_scale(&mut cur)?.value(),
        compound_loft_scale(&mut cur)?.value(),
    ]);
    let flags = [cur.take_bool()?, cur.take_bool()?];
    let selector = cur.take_long()?;
    let extended = cur.take_bool()?;
    let branch = if extended {
        let first_scale = compound_loft_scale(&mut cur)?.value().map(Box::new);
        if cur.take_bool()? {
            let second_scale = Box::new(compound_loft_scale(&mut cur)?.value()?);
            let selector = cur.take_long()?;
            let direction = cur.take_vector3()?;
            EmbeddedScaledCompoundLoftBranch::ExtendedVector {
                first_scale,
                second_scale,
                selector,
                direction: Vector3::new(direction[0], direction[1], direction[2]),
            }
        } else {
            let flag = cur.take_bool()?;
            let singularity = cur.take_enum()?;
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            EmbeddedScaledCompoundLoftBranch::ExtendedCurve {
                scale: first_scale,
                flag,
                singularity,
                curve,
            }
        }
    } else {
        let flag = cur.take_bool()?;
        let selector = cur.take_long()?;
        let direction = if selector == 0 {
            let direction = cur.take_vector3()?;
            EmbeddedCompoundLoftDirection::Vector(Vector3::new(
                direction[0],
                direction[1],
                direction[2],
            ))
        } else {
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            EmbeddedCompoundLoftDirection::Curve {
                selector: NonZeroI64::new(selector)?,
                curve,
            }
        };
        EmbeddedScaledCompoundLoftBranch::Direct { flag, direction }
    };
    let trailing_flags = [cur.take_bool()?, cur.take_bool()?];
    let tail_kind = cur.take_long()?;
    let first = cur.take_vector3()?;
    let second = cur.take_vector3()?;
    let tail_singularity = cur.take_enum()?;
    let (tail_curve, _) = curve_block(span, cur.pos())?;
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::ScaledCompoundLoft(Box::new(
            EmbeddedScaledCompoundLoft {
                singularity,
                shape,
                discontinuities,
                discontinuity_flag,
                scales,
                flags,
                selector,
                branch,
                trailing_flags,
                tail_kind,
                tail_directions: [
                    Vector3::new(first[0], first[1], first[2]),
                    Vector3::new(second[0], second[1], second[2]),
                ],
                tail_singularity,
                tail_curve,
            },
        )),
        cache_fit_tolerance,
    ))
}

/// Decode one recursive law expression.
pub(super) fn law_expression(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    depth: usize,
) -> Option<Result<EmbeddedLawExpression, cadmpeg_core::CodecError>> {
    law_expression_resolving(ctx, cur, depth, None)
}

/// Decode a law slot of the sweep layout. Older sweep records use the
/// recursive law grammar, while revision-gated records may store the whole
/// expression as one serializer string. The text form is scoped to sweep
/// law slots so an unknown operator in another law grammar remains a refusal.
fn sweep_law_expression(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
) -> Option<Result<EmbeddedLawExpression, cadmpeg_core::CodecError>> {
    if matches!(cur.peek(), Some(Token::Str(_))) {
        let source = cur.take_str()?;
        source
            .chars()
            .any(|character| !character.is_whitespace())
            .then_some(())?;
        let copied = source.to_owned();
        return Some(Ok(EmbeddedLawExpression::Text(
            cadmpeg_core::text::NonBlankString::new(copied)?,
        )));
    }
    law_expression(ctx, cur, 0)
}

fn law_expression_resolving(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    depth: usize,
    resolver: Option<&SubtypeTable>,
) -> Option<Result<EmbeddedLawExpression, cadmpeg_core::CodecError>> {
    let _depth_guard = propagate_resource!(ctx.enter_nested("ASM law expression"));
    if depth > 64 {
        return None;
    }
    match cur.peek()? {
        Token::Long(_) => {
            return Some(Ok(EmbeddedLawExpression::Integer(cur.take_long()?)));
        }
        Token::Double(_) => return Some(Ok(EmbeddedLawExpression::Double(cur.take_f64()?))),
        Token::Position(_) => {
            let value = cur.take_position()?;
            return Some(Ok(EmbeddedLawExpression::Point(Point3::new(
                value[0] * LEN_TO_MM,
                value[1] * LEN_TO_MM,
                value[2] * LEN_TO_MM,
            ))));
        }
        Token::Vector3(_) => {
            let value = cur.take_vector3()?;
            return Some(Ok(EmbeddedLawExpression::Vector(Vector3::new(
                value[0], value[1], value[2],
            ))));
        }
        _ => {}
    }
    let operator = cur.take_str()?;
    match operator {
        "null_law" => Some(Ok(EmbeddedLawExpression::Null)),
        "TRANS" => {
            if matches!(cur.peek(), Some(Token::Vector3(_))) {
                let mut vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
                for vector in &mut vectors {
                    let value = cur.take_vector3()?;
                    *vector = Vector3::new(value[0], value[1], value[2]);
                }
                let scale = cur.take_f64()?;
                let flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
                return Some(Ok(EmbeddedLawExpression::TransformVec {
                    vectors,
                    scale,
                    flags,
                }));
            }
            let mut scalars = [0.0; 13];
            for scalar in &mut scalars {
                *scalar = cur.take_f64()?;
            }
            let enums = [cur.take_enum()?, cur.take_enum()?, cur.take_enum()?];
            Some(Ok(EmbeddedLawExpression::Transform { scalars, enums }))
        }
        "EDGE" => {
            let (curve, endpoints) = if let Some(decoded) = curve_block(cur.toks(), cur.pos()) {
                let (curve, end) = decoded;
                cur.set_pos(end);
                let endpoints = matches!(cur.peek(), Some(Token::True | Token::False))
                    .then(|| {
                        Some([
                            cur.take_optional_range_value()?.value(),
                            cur.take_optional_range_value()?.value(),
                        ])
                    })
                    .flatten();
                (curve, endpoints)
            } else {
                let table = resolver?;
                let curve = embedded_base_curve_resolving_refs(cur, table)?;
                let endpoints = Some([
                    cur.take_optional_range_value()?.value(),
                    cur.take_optional_range_value()?.value(),
                ]);
                (curve, endpoints)
            };
            let parameters = [cur.take_f64()?, cur.take_f64()?];
            Some(Ok(EmbeddedLawExpression::Edge {
                curve,
                endpoints,
                parameters,
            }))
        }
        "SPLINE_LAW" => {
            let native_id = cur.take_long()?;
            let knots = cur.take_float_array()?;
            let controls = cur.take_float_array()?;
            let point = cur.take_position()?;
            Some(Ok(EmbeddedLawExpression::Spline {
                native_id,
                knots,
                controls,
                point: Point3::new(
                    point[0] * LEN_TO_MM,
                    point[1] * LEN_TO_MM,
                    point[2] * LEN_TO_MM,
                ),
            }))
        }
        _ => {
            let arity = match operator {
                "COS" | "SIN" | "TAN" | "COT" | "SEC" | "CSC" | "COSH" | "SINH" | "TANH"
                | "COTH" | "SECH" | "CSCH" | "ARCCOS" | "ARCSIN" | "ARCTAN" | "ARCOT"
                | "ARCSEC" | "ARCCSC" | "ARCCOSH" | "ARCSINH" | "ARCTANH" | "ARCOTH"
                | "ARCSECH" | "ARCCSCH" | "ABS" | "EXP" | "LN" | "LOG" | "SIGN" | "SIZE"
                | "SET" | "SQRT" | "NORM" | "NOT" => 1,
                "CROSS" | "DOT" | "DCUR" | "O" | "ROTATE" | "TERM" => 2,
                "VEC" | "DSURF" => 3,
                _ => return None,
            };
            let mut operands = Vec::new();
            for _ in 0..arity {
                operands.push(propagate_resource!(law_expression_resolving(
                    ctx,
                    cur,
                    depth + 1,
                    resolver
                )?));
            }
            let operator = operator.to_owned();
            Some(Ok(EmbeddedLawExpression::Algebraic { operator, operands }))
        }
    }
}

/// Decode one named law formula and its counted variables.
pub(super) fn law_formula(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
) -> Option<Result<EmbeddedLawFormula, cadmpeg_core::CodecError>> {
    law_formula_resolving(ctx, cur, None)
}

fn law_formula_resolving(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    cur: &mut Cur<'_>,
    resolver: Option<&SubtypeTable>,
) -> Option<Result<EmbeddedLawFormula, cadmpeg_core::CodecError>> {
    let name = cur.take_str()?.to_owned();
    if name == "null_law" {
        return Some(Ok(EmbeddedLawFormula::Null));
    }
    let count = usize::try_from(cur.take_long()?).ok()?;
    if count > 100_000 {
        return None;
    }
    let mut variables = Vec::new();
    for _ in 0..count {
        variables.push(propagate_resource!(law_expression_resolving(
            ctx, cur, 0, resolver
        )?));
    }
    Some(Ok(EmbeddedLawFormula::Named {
        name: cadmpeg_core::text::NonBlankString::new(name)?,
        variables,
    }))
}

fn skin_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["skin_spl_sur", "skinsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let surface_boolean = cur.take_enum()?;
    let surface_normal = cur.take_enum()?;
    let surface_direction = cur.take_enum()?;
    let count = cur.take_long()?;
    let parameter = cur.take_f64()?;
    let inner_count = cur.take_long()?;
    let layout = if cur.peek().is_some_and(Token::is_payload_ident) {
        let (curve, curve_end) = curve_block(span, cur.pos())?;
        cur.set_pos(curve_end);
        let subdata = loft_subdata(&mut cur)?;
        let first_tail = cur.take_long()?;
        let (secondary_curve, secondary_end) = curve_block(span, cur.pos())?;
        cur.set_pos(secondary_end);
        let second_tail = cur.take_long()?;
        EmbeddedSkinSurfaceLayout::Compact {
            inner_count,
            curve,
            subdata,
            first_tail,
            secondary_curve,
            second_tail,
        }
    } else {
        let profile_count = usize::try_from(inner_count).ok()?;
        if profile_count > 100_000 {
            return None;
        }
        let mut profiles = Vec::new();
        for _ in 0..profile_count {
            let type_code = cur.take_long()?;
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            let data = loft_profile_data(&mut cur, type_code)?;
            profiles.push(EmbeddedLoftProfileMember { curve, data });
        }
        let (path, path_end) = curve_block(span, cur.pos())?;
        cur.set_pos(path_end);
        let tail = [cur.take_long()?, cur.take_long()?];
        EmbeddedSkinSurfaceLayout::Profiles {
            profiles,
            path,
            tail,
        }
    };
    let direction = cur.take_vector3()?;
    let trailing_parameter = cur.take_f64()?;
    let formula = propagate_resource!(law_formula(ctx, &mut cur)?);
    let (parameter_curve, parameter_curve_end) = curve_block(span, cur.pos())?;
    cur.set_pos(parameter_curve_end);
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    let discontinuity_flag = cur.take_bool()?;
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Skin(Box::new(EmbeddedSkinSurface {
            surface_boolean,
            surface_normal,
            surface_direction,
            count,
            parameter,
            layout,
            direction: Vector3::new(direction[0], direction[1], direction[2]),
            trailing_parameter,
            formula,
            parameter_curve,
            discontinuities,
            discontinuity_flag,
        })),
        cache_fit_tolerance,
    )))
}

pub(super) fn law_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["law_spl_sur", "lawsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let parameter_ranges = if matches!(cur.peek(), Some(Token::Double(_))) {
        Some([
            [cur.take_f64()?, cur.take_f64()?],
            [cur.take_f64()?, cur.take_f64()?],
        ])
    } else {
        None
    };
    let primary = propagate_resource!(law_formula(ctx, &mut cur)?);
    let count = usize::try_from(cur.take_long()?).ok()?;
    if count > 100_000 {
        return None;
    }
    let mut additional = Vec::new();
    for _ in 0..count {
        additional.push(propagate_resource!(law_formula(ctx, &mut cur)?));
    }
    let selector = if parameter_ranges.is_some()
        && toks::marker_at(span, cur.pos()) == Some(crate::nurbs::reader::BsplineMarker::Nubs)
    {
        0
    } else {
        cur.take_enum()?
    };
    let (tail, cache_fit_tolerance) = match selector {
        0 => {
            let (_, cache_end) = surface_block(span, cur.pos())?;
            cur.set_pos(cache_end);
            let fit_tolerance = cur.take_f64()? * LEN_TO_MM;
            (
                cadmpeg_ir::geometry::LawSurfaceTail::Full {
                    cache: cadmpeg_ir::geometry::LegacyCache::try_new(fit_tolerance).ok()?,
                },
                Some(fit_tolerance),
            )
        }
        1 => {
            let parameters = [cur.take_float_array()?, cur.take_float_array()?];
            let fit_tolerance =
                cadmpeg_ir::geometry::FitTolerance::try_new(cur.take_f64()? * LEN_TO_MM).ok()?;
            let closures = [cur.take_enum()?, cur.take_enum()?];
            let singularities = [cur.take_enum()?, cur.take_enum()?];
            (
                cadmpeg_ir::geometry::LawSurfaceTail::Summary {
                    parameters,
                    fit_tolerance,
                    closures,
                    singularities,
                },
                None,
            )
        }
        2 => {
            let parameter_ranges = [
                [cur.take_f64()?, cur.take_f64()?],
                [cur.take_f64()?, cur.take_f64()?],
            ];
            let closures = [cur.take_enum()?, cur.take_enum()?];
            let singularities = [cur.take_enum()?, cur.take_enum()?];
            (
                cadmpeg_ir::geometry::LawSurfaceTail::None {
                    parameter_ranges,
                    closures,
                    singularities,
                },
                None,
            )
        }
        3 => (cadmpeg_ir::geometry::LawSurfaceTail::Historical {}, None),
        4 => (cadmpeg_ir::geometry::LawSurfaceTail::Optimal {}, None),
        _ => return None,
    };
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Law(Box::new(EmbeddedLawSurface {
            parameter_ranges,
            primary,
            additional,
            tail,
            discontinuities,
        })),
        cache_fit_tolerance,
    )))
}

pub(super) fn sub_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    let names = ["sub_spl_sur", "subsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let parameter_ranges = [
        [cur.take_f64()?, cur.take_f64()?],
        [cur.take_f64()?, cur.take_f64()?],
    ];
    let support = embedded_surface(&mut cur)?;
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::SubSurface {
            support,
            parameter_ranges,
        },
        None,
    ))
}

fn net_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["net_spl_sur", "netsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let sections = Box::new([loft_section(&mut cur)?, loft_section(&mut cur)?]);
    let mut frame_parameters = [0.0; 12];
    for parameter in &mut frame_parameters {
        *parameter = cur.take_f64()?;
    }
    let flag = cur.take_long()?;
    let mut directions = [Vector3::new(0.0, 0.0, 0.0); 4];
    for direction in &mut directions {
        let value = cur.take_vector3()?;
        *direction = Vector3::new(value[0], value[1], value[2]);
    }
    let formulas = [
        propagate_resource!(law_formula(ctx, &mut cur)?),
        propagate_resource!(law_formula(ctx, &mut cur)?),
        propagate_resource!(law_formula(ctx, &mut cur)?),
        propagate_resource!(law_formula(ctx, &mut cur)?),
    ];
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    let discontinuity_flag = cur.take_bool()?;
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Net(Box::new(EmbeddedNetSurface {
            sections,
            frame_parameters,
            flag,
            directions,
            formulas: Box::new(formulas),
            discontinuities,
            discontinuity_flag,
        })),
        cache_fit_tolerance,
    )))
}

fn sweep_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["sweep_spl_sur", "sweep_sur", "sweepsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // The revision-gated layout belongs to `sweep_sur`.
        (name == "sweep_sur").then_some(())?;
        return revision_sweep_sur(ctx, span, cur.pos(), resolver?);
    }
    let primary_kind = cur.take_enum()?;
    let layout = if cur.peek().is_some_and(Token::is_payload_ident) {
        let (profile, profile_end) = curve_block(span, cur.pos())?;
        cur.set_pos(profile_end);
        let (spine, spine_end) = curve_block(span, cur.pos())?;
        cur.set_pos(spine_end);
        let secondary_kind = cur.take_enum()?;
        let mut directions = [Vector3::new(0.0, 0.0, 0.0); 5];
        for direction in &mut directions {
            let value = cur.take_vector3()?;
            *direction = Vector3::new(value[0], value[1], value[2]);
        }
        let origin = cur.take_position()?;
        let mut parameters = [0.0; 4];
        for parameter in &mut parameters {
            *parameter = cur.take_f64()?;
        }
        let formulas = [
            propagate_resource!(law_formula(ctx, &mut cur)?),
            propagate_resource!(law_formula(ctx, &mut cur)?),
            propagate_resource!(law_formula(ctx, &mut cur)?),
        ];
        LegacySweepLayout::ProfileFirst {
            profile: Box::new(profile),
            spine: Box::new(spine),
            secondary_kind,
            directions,
            origin: Point3::new(
                origin[0] * LEN_TO_MM,
                origin[1] * LEN_TO_MM,
                origin[2] * LEN_TO_MM,
            ),
            parameters,
            formulas: Box::new(formulas),
        }
    } else {
        let mode = cur.take_long()?;
        let (profile, profile_end) = curve_block(span, cur.pos())?;
        cur.set_pos(profile_end);
        let profile_range = [cur.take_f64()?, cur.take_f64()?];
        let profile_frame = if cur.take_bool()? {
            let point = cur.take_position()?;
            let vector = cur.take_vector3()?;
            Some((
                Point3::new(
                    point[0] * LEN_TO_MM,
                    point[1] * LEN_TO_MM,
                    point[2] * LEN_TO_MM,
                ),
                Vector3::new(vector[0], vector[1], vector[2]),
            ))
        } else {
            None
        };
        let point = cur.take_position()?;
        let origin = Point3::new(
            point[0] * LEN_TO_MM,
            point[1] * LEN_TO_MM,
            point[2] * LEN_TO_MM,
        );
        let mut directions = [Vector3::new(0.0, 0.0, 0.0); 3];
        for direction in &mut directions {
            let value = cur.take_vector3()?;
            *direction = Vector3::new(value[0], value[1], value[2]);
        }
        if matches!(cur.peek(), Some(Token::Long(_))) {
            let branch = cur.take_long()?;
            let trajectory_flag = cur.take_bool()?;
            let (path, path_end) = curve_block(span, cur.pos())?;
            cur.set_pos(path_end);
            let path_range = [cur.take_f64()? * LEN_TO_MM, cur.take_f64()? * LEN_TO_MM];
            let path_parameter = cur.take_f64()?;
            let profile = SweepProfile {
                profile,
                mode,
                profile_range,
                profile_frame,
                origin,
                directions,
                path,
                path_range,
                path_parameter,
            };
            let tail = match branch {
                1 => {
                    let formula_flag = cur.take_bool()?;
                    let formula = propagate_resource!(law_formula(ctx, &mut cur)?);
                    let trailing_flag = cur.take_bool()?;
                    SweepTail::LawOrFormula(SweepLawOrFormula::Formula {
                        trajectory_flag,
                        formula_flag,
                        formula,
                        trailing_flag,
                    })
                }
                2 => {
                    let guide_flags = [cur.take_bool()?, cur.take_bool()?];
                    let (guide_curve, guide_end) = curve_block(span, cur.pos())?;
                    cur.set_pos(guide_end);
                    let guide_range = [cur.take_f64()?, cur.take_f64()?];
                    let guide_modes = [cur.take_long()?, cur.take_long()?];
                    let mut guide_parameters = [0.0; 6];
                    for parameter in &mut guide_parameters {
                        *parameter = cur.take_f64()?;
                    }
                    let trailing_flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
                    SweepTail::Guide {
                        trajectory_flag,
                        guide_flags,
                        guide_curve,
                        guide_range,
                        guide_modes,
                        guide_parameters,
                        trailing_flags,
                    }
                }
                3 => {
                    let singularity = cur.take_enum()?;
                    let support_surface = embedded_surface(&mut cur)?;
                    let auxiliary_curve = if cur.take_bool()? {
                        let (curve, curve_end) = curve_block(span, cur.pos())?;
                        cur.set_pos(curve_end);
                        Some(curve)
                    } else {
                        None
                    };
                    let support_flag = cur.take_bool()?;
                    let legacy_flag = matches!(cur.peek(), Some(Token::True | Token::False))
                        .then(|| cur.take_bool())
                        .flatten();
                    SweepTail::Surface {
                        trajectory_flag,
                        singularity,
                        support_surface,
                        auxiliary_curve,
                        support_flag,
                        legacy_flag,
                    }
                }
                _ => return None,
            };
            LegacySweepLayout::Sweep {
                profile: Box::new(profile),
                tail,
            }
        } else {
            let first_law = propagate_resource!(sweep_law_expression(ctx, &mut cur)?);
            let first_mode = cur.take_long()?;
            let first_range = [cur.take_f64()?, cur.take_f64()?];
            let vector = cur.take_vector3()?;
            let law_direction = Vector3::new(vector[0], vector[1], vector[2]);
            let path_mode = cur.take_long()?;
            let path_flag = cur.take_bool()?;
            let (path, path_end) = curve_block(span, cur.pos())?;
            cur.set_pos(path_end);
            let path_range = [cur.take_f64()?, cur.take_f64()?];
            let path_parameter = cur.take_f64()?;
            let second_law_flag = cur.take_bool()?;
            let second_law = propagate_resource!(sweep_law_expression(ctx, &mut cur)?);
            let formula_mode = cur.take_long()?;
            let formula = propagate_resource!(law_formula(ctx, &mut cur)?);
            let trailing_flag = cur.take_bool()?;
            LegacySweepLayout::Sweep {
                profile: Box::new(SweepProfile {
                    profile,
                    mode,
                    profile_range,
                    profile_frame,
                    origin,
                    directions,
                    path,
                    path_range,
                    path_parameter,
                }),
                tail: SweepTail::LawOrFormula(SweepLawOrFormula::Law {
                    first_law: Box::new(first_law),
                    first_mode,
                    first_range,
                    law_direction,
                    path_mode,
                    path_flag,
                    second_law_flag,
                    second_law: Box::new(second_law),
                    formula_mode,
                    formula,
                    trailing_flag,
                }),
            }
        }
    };
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    let discontinuity_flag = cur.take_bool()?;
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Sweep(Box::new(EmbeddedSweepSurface {
            layout: EmbeddedSweepSurfaceLayout::Legacy {
                primary_kind,
                layout,
            },
            discontinuities,
            discontinuity_flag,
        })),
        cache_fit_tolerance,
    )))
}

/// Revision-gated `sweep_sur` layouts.
fn revision_sweep_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    span: &[Token],
    position: usize,
    table: &SubtypeTable,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let mut cur = Cur::at(span, position);
    let revision = PositiveI64::new(cur.take_long()?)?;
    let primary_flag = cur.take_bool()?;
    let mode = cur.take_long()?;
    let profile = embedded_base_curve_resolving_refs(&mut cur, table)?;
    let profile_endpoints = [
        cur.take_optional_range_value()?.value(),
        cur.take_optional_range_value()?.value(),
    ];
    let profile_range = [
        cur.take_optional_range_value()?.value()?,
        cur.take_optional_range_value()?.value()?,
    ];
    let profile_frame = if cur.take_bool()? {
        let point = cur.take_position()?;
        let vector = cur.take_vector3()?;
        Some((
            Point3::new(
                point[0] * LEN_TO_MM,
                point[1] * LEN_TO_MM,
                point[2] * LEN_TO_MM,
            ),
            Vector3::new(vector[0], vector[1], vector[2]),
        ))
    } else {
        None
    };
    let point = cur.take_position()?;
    let origin = Point3::new(
        point[0] * LEN_TO_MM,
        point[1] * LEN_TO_MM,
        point[2] * LEN_TO_MM,
    );
    let mut directions = [Vector3::new(0.0, 0.0, 0.0); 3];
    for direction in &mut directions {
        let value = cur.take_vector3()?;
        *direction = Vector3::new(value[0], value[1], value[2]);
    }
    let (profile, tail, path_endpoints) = if matches!(cur.peek(), Some(Token::Str(_))) {
        let first_law = propagate_resource!(sweep_law_expression(ctx, &mut cur)?);
        let first_mode = cur.take_long()?;
        let first_range = [
            cur.take_optional_range_value()?.value()?,
            cur.take_optional_range_value()?.value()?,
        ];
        let law_direction = cur.take_vector3()?;
        let path_mode = cur.take_long()?;
        let path_flag = cur.take_bool()?;
        let path = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let path_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let path_range = [
            cur.take_optional_range_value()?.value()? * LEN_TO_MM,
            cur.take_optional_range_value()?.value()? * LEN_TO_MM,
        ];
        let path_parameter = cur.take_f64()?;
        let second_law_flag = cur.take_bool()?;
        let second_law = propagate_resource!(sweep_law_expression(ctx, &mut cur)?);
        let formula_mode = cur.take_long()?;
        let formula = propagate_resource!(law_formula_resolving(ctx, &mut cur, Some(table))?);
        let trailing_flag = cur.take_bool()?;
        let law_direction = Vector3::new(law_direction[0], law_direction[1], law_direction[2]);
        (
            SweepProfile {
                profile,
                mode,
                profile_range,
                profile_frame,
                origin,
                directions,
                path,
                path_range,
                path_parameter,
            },
            SweepLawOrFormula::Law {
                first_law: Box::new(first_law),
                first_mode,
                first_range,
                law_direction,
                path_mode,
                path_flag,
                second_law_flag,
                second_law: Box::new(second_law),
                formula_mode,
                formula,
                trailing_flag,
            },
            path_endpoints,
        )
    } else {
        (cur.take_long()? == 1).then_some(())?;
        let trajectory_flag = cur.take_bool()?;
        let path = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let path_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let path_range = [
            cur.take_optional_range_value()?.value()? * LEN_TO_MM,
            cur.take_optional_range_value()?.value()? * LEN_TO_MM,
        ];
        let path_parameter = cur.take_f64()?;
        let formula_flag = cur.take_bool()?;
        let formula = propagate_resource!(law_formula_resolving(ctx, &mut cur, Some(table))?);
        let trailing_flag = cur.take_bool()?;
        (
            SweepProfile {
                profile,
                mode,
                profile_range,
                profile_frame,
                origin,
                directions,
                path,
                path_range,
                path_parameter,
            },
            SweepLawOrFormula::Formula {
                trajectory_flag,
                formula_flag,
                formula,
                trailing_flag,
            },
            path_endpoints,
        )
    };
    let RevisionSurfaceTail {
        cache,
        discontinuities,
        tail_flag: discontinuity_flag,
    } = revision_surface_tail(&mut cur)?;
    cur.at_scope_end().then_some(())?;
    Some(Ok(DecodedProceduralSurface::revision(
        DecodedProceduralSurfaceDefinition::Sweep(Box::new(EmbeddedSweepSurface {
            layout: EmbeddedSweepSurfaceLayout::Revision {
                form: cadmpeg_ir::geometry::SweepRevisionForm {
                    revision,
                    primary_flag,
                    profile_endpoints,
                    path_endpoints,
                    cache: cache.into_form()?,
                },
                profile: Box::new(profile),
                tail,
            },
            discontinuities,
            discontinuity_flag,
        })),
    )))
}

fn taper_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    use cadmpeg_ir::geometry::TaperSurfaceKind;
    let names: &[(&str, u8)] = &[
        ("taper_spl_sur", 0),
        ("ortho_spl_sur", 1),
        ("orthosur", 1),
        ("edge_tpr_spl_sur", 2),
        ("shadow_tpr_spl_sur", 3),
        ("shadowtapersur", 3),
        ("ruled_tpr_spl_sur", 4),
        ("ruledtapersur", 4),
        ("swept_tpr_spl_sur", 5),
        ("swepttapersur", 5),
    ];
    let candidates: Vec<&str> = names.iter().map(|(name, _)| *name).collect();
    let (start, name) = toks::find_owned_subtype_marker(toks, &candidates)?;
    let kind = names
        .iter()
        .find_map(|(candidate, kind)| (*candidate == name).then_some(*kind))?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated form, stored by the orthogonal subtype's modern name.
        (name == "ortho_spl_sur").then_some(())?;
        let table = resolver?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let crate::nurbs::proc_curve::EmbeddedSurfaceWithBounds {
            surface: support,
            chart,
            bounds: support_bounds,
            ..
        } = match optional_embedded_surface_with_bounds(ctx, &mut cur, table)? {
            Ok(support) => support,
            Err(error) => return Some(Err(error)),
        };
        let support = support.into_surface()?;
        let reference = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let reference_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let mut pcurve = nullable_embedded_pcurve(&mut cur)?.value();
        if let Some(pcurve) = &mut pcurve {
            chart.normalize(pcurve)?;
        }
        let parameter = cur.take_f64()?;
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        // The single trailing logical after the shared tail is the record's own
        // orthogonal-sense field, positionally matching the text form's single
        // boolean. `tail_flag` above is the shared-tail illegal-region flag.
        let sense = cur.take_bool()?;
        cur.at_scope_end().then_some(())?;
        return Some(Ok(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Taper {
                support,
                reference,
                pcurve,
                parameter,
                taper: TaperSurfaceKind::Orthogonal { sense },
                revision_form: Some(cadmpeg_ir::geometry::RevisionSurfaceForm {
                    revision,
                    support_bounds,
                    reference_endpoints,
                    second_endpoints: [None; 2],
                    flags: Vec::new(),
                    cache: cache.into_form()?,
                    discontinuities,
                    tail_flag,
                    trailing_flags: Vec::new(),
                }),
            },
        )));
    }
    let EmbeddedSupport {
        surface: support,
        chart,
        ..
    } = embedded_support(&mut cur)?;
    let (reference, reference_end) = curve_block(span, cur.pos())?;
    cur.set_pos(reference_end);
    let saved = cur.pos();
    let pcurve = if cur.take_ident() == Some("nullbs") {
        None
    } else {
        cur.set_pos(saved);
        let (mut pcurve, end) = pcurve_block_with_end(span, cur.pos())?;
        cur.set_pos(end);
        chart.normalize(&mut pcurve)?;
        Some(pcurve)
    };
    let parameter = cur.take_f64()?;
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = if matches!(cur.peek(), Some(Token::Double(_))) {
        Some(cur.take_f64()? * LEN_TO_MM)
    } else {
        None
    };
    let take_draft = |cur: &mut Cur<'_>| {
        let draft = cur.take_vector3()?;
        Some(Vector3::new(draft[0], draft[1], draft[2]))
    };
    let taper = match kind {
        0 => TaperSurfaceKind::Standard {},
        1 => TaperSurfaceKind::Orthogonal {
            sense: cur.take_bool()?,
        },
        2 => TaperSurfaceKind::Edge {
            draft: take_draft(&mut cur)?,
        },
        3 => TaperSurfaceKind::Shadow {
            draft: take_draft(&mut cur)?,
            sine: cur.take_f64()?,
            cosine: cur.take_f64()?,
        },
        4 => TaperSurfaceKind::Ruled {
            draft: take_draft(&mut cur)?,
            sine: cur.take_f64()?,
            cosine: cur.take_f64()?,
            factor: cur.take_f64()?,
        },
        5 => TaperSurfaceKind::Swept {
            draft: take_draft(&mut cur)?,
            sine: cur.take_f64()?,
            cosine: cur.take_f64()?,
        },
        _ => return None,
    };
    cur.at_scope_end().then_some(())?;
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Taper {
            support,
            reference,
            pcurve,
            parameter,
            taper,
            revision_form: None,
        },
        cache_fit_tolerance,
    )))
}

fn comp_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    let (start, _) = toks::find_owned_subtype_marker(toks, &["comp_spl_sur"])?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = if matches!(cur.peek(), Some(Token::Double(_))) {
        Some(cur.take_f64()? * LEN_TO_MM)
    } else {
        None
    };
    let parameters = cur.take_float_array()?;
    let mut components = Vec::new();
    for parameter in parameters {
        components.push(cadmpeg_ir::geometry::CompoundComponent {
            parameter,
            component: embedded_surface(&mut cur)?,
        });
    }
    cur.at_scope_end().then_some(())?;
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Compound { components },
        cache_fit_tolerance,
    ))
}

/// Approximation data carried by a revision surface tail.
pub enum RevisionSurfaceCache {
    /// Solved surface cache tolerance and U/V knot domains.
    Solved {
        /// Fit tolerance of the solved surface.
        fit_tolerance: f64,
        /// U and V knot domains.
        domains: [[f64; 2]; 2],
    },
    /// Parameter intervals and closure/singularity enums.
    Parameterized(RevisionSurfaceParameterization),
}

impl RevisionSurfaceCache {
    /// Convert cache metadata to its neutral representation.
    pub(super) fn into_form(self) -> Option<RevisionCacheForm> {
        Some(match self {
            Self::Solved { fit_tolerance, .. } => RevisionCacheForm::SolvedCache {
                fit_tolerance: cadmpeg_ir::geometry::FitTolerance::try_new(fit_tolerance).ok()?,
            },
            Self::Parameterized(parameters) => RevisionCacheForm::Parameterization(parameters),
        })
    }
}

/// The shared revision-gated surface tail, decoded.
pub struct RevisionSurfaceTail {
    /// Approximation-cache form and its payload.
    pub cache: RevisionSurfaceCache,
    /// Six ordered discontinuity arrays.
    pub discontinuities: [Vec<f64>; 6],
    /// Boolean terminating the tail.
    pub tail_flag: bool,
}

/// Parse the shared revision-gated surface tail (GC-08).
///
/// Form `0` carries the solved NURBS surface and fit tolerance. Form `2` carries
/// U/V intervals in the optional bool-gated form, four closure and singularity
/// enums, six discontinuity arrays, and a terminating boolean. The decoder
/// retains the containing record in native form for other values.
pub fn revision_surface_tail(cur: &mut Cur<'_>) -> Option<RevisionSurfaceTail> {
    let enumeration = cur.take_enum()?;
    let cache = match enumeration {
        0 => {
            let (cache, cache_end) = surface_block(cur.toks(), cur.pos())?;
            cur.set_pos(cache_end);
            let domains = [
                [*cache.u_knots().first()?, *cache.u_knots().last()?],
                [*cache.v_knots().first()?, *cache.v_knots().last()?],
            ];
            RevisionSurfaceCache::Solved {
                fit_tolerance: cur.take_f64()? * LEN_TO_MM,
                domains,
            }
        }
        2 => {
            let u_interval = [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ];
            let v_interval = [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ];
            RevisionSurfaceCache::Parameterized(RevisionSurfaceParameterization {
                u_interval,
                v_interval,
                u_closure: cur.take_enum()?,
                v_closure: cur.take_enum()?,
                u_singularity: cur.take_enum()?,
                v_singularity: cur.take_enum()?,
            })
        }
        _ => return None,
    };
    let discontinuities = [
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
        cur.take_float_array()?,
    ];
    let tail_flag = cur.take_bool()?;
    Some(RevisionSurfaceTail {
        cache,
        discontinuities,
        tail_flag,
    })
}

fn off_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let names = ["off_spl_sur", "offsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let modern = name == "off_spl_sur";
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // The modern name uses the revision-gated layout.
        modern.then_some(())?;
        let table = resolver?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let crate::nurbs::proc_curve::EmbeddedSurfaceWithBounds {
            surface: support,
            bounds: support_bounds,
            ..
        } = match optional_embedded_surface_with_bounds(ctx, &mut cur, table)? {
            Ok(support) => support,
            Err(error) => return Some(Err(error)),
        };
        let support = support.into_surface()?;
        let distance = cur.take_f64()? * LEN_TO_MM;
        // Four booleans carry the record orientation pair and the ASM extension
        // pair. The first repeats the support sense and orients the offset
        // displacement. The second leaves the point set unchanged. The revision
        // form reads these positions where the earlier form reads U/V sense
        // enums.
        let mut flags = Vec::new();
        for _ in 0..4 {
            flags.push(cur.take_bool()?);
        }
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        cur.at_scope_end().then_some(())?;
        return Some(Ok(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Offset {
                support,
                distance,
                layout: EmbeddedOffsetLayout::Revision(Box::new(
                    cadmpeg_ir::geometry::RevisionSurfaceForm {
                        revision,
                        support_bounds,
                        reference_endpoints: [None; 2],
                        second_endpoints: [None; 2],
                        flags: flags.try_into().ok()?,
                        cache: cache.into_form()?,
                        discontinuities,
                        tail_flag,
                        trailing_flags: Vec::new(),
                    },
                )),
            },
        )));
    }
    let support = embedded_surface(&mut cur)?;
    let distance = cur.take_f64()? * LEN_TO_MM;
    let u_sense = cur.take_enum()?;
    let v_sense = cur.take_enum()?;
    let extension_flags = if modern {
        let first = cur.take_bool()?;
        if first {
            cadmpeg_ir::geometry::LegacyExtensionFlags::Enabled {
                secondary: cur.take_bool()?,
                tertiary: matches!(cur.peek(), Some(Token::True | Token::False))
                    .then(|| cur.take_bool())
                    .flatten(),
            }
        } else {
            cadmpeg_ir::geometry::LegacyExtensionFlags::Disabled {}
        }
    } else {
        cadmpeg_ir::geometry::LegacyExtensionFlags::Absent {}
    };
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = optional_trailing_cache_tolerance(&mut cur)?.value();
    Some(Ok(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Offset {
            support,
            distance,
            layout: EmbeddedOffsetLayout::Legacy {
                u_sense,
                v_sense,
                extension: extension_flags,
            },
        },
        cache_fit_tolerance,
    )))
}

fn rot_spl_sur(
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<DecodedProceduralSurface> {
    let names = ["rot_spl_sur", "rotsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated layout: revision integer, profile curve with two
        // optional endpoints, axis origin and direction, shared tail. The
        // modern name uses this layout.
        (name == "rot_spl_sur").then_some(())?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let table = resolver?;
        let profile = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let profile_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let origin = cur.take_position()?;
        let axis = cur.take_vector3()?;
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        cur.at_scope_end().then_some(())?;
        let angular_interval = match &cache {
            RevisionSurfaceCache::Solved { domains, .. } => domains[1],
            RevisionSurfaceCache::Parameterized(_) => return None,
        };
        let parameter_interval = [
            profile_endpoints[0].unwrap_or(*profile.knots().first()?),
            profile_endpoints[1].unwrap_or(*profile.knots().last()?),
        ];
        return Some(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Revolution {
                directrix: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(profile)),
                axis_origin: Point3::new(
                    origin[0] * LEN_TO_MM,
                    origin[1] * LEN_TO_MM,
                    origin[2] * LEN_TO_MM,
                ),
                axis_direction: UnitVector3::normalized_nonzero(
                    cadmpeg_ir::features::FiniteVector3::new(Vector3::from(axis))?,
                )?,
                angular_interval,
                parameter_interval,
                revision_form: Some(cadmpeg_ir::geometry::RevisionSurfaceForm {
                    revision,
                    support_bounds: [None; 4],
                    reference_endpoints: profile_endpoints,
                    second_endpoints: [None; 2],
                    flags: Vec::new(),
                    cache: cache.into_form()?,
                    discontinuities,
                    tail_flag,
                    trailing_flags: Vec::new(),
                }),
            },
        ));
    }
    let (directrix, directrix_end) = curve_block(span, cur.pos())?;
    cur.set_pos(directrix_end);
    let parameter_interval = [*directrix.knots().first()?, *directrix.knots().last()?];
    let origin = cur.take_position()?;
    let axis_origin = Point3::new(
        origin[0] * LEN_TO_MM,
        origin[1] * LEN_TO_MM,
        origin[2] * LEN_TO_MM,
    );
    let axis = cur.take_vector3()?;
    let axis_direction = UnitVector3::normalized_nonzero(
        cadmpeg_ir::features::FiniteVector3::new(Vector3::from(axis))?,
    )?;
    let (cache, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let angular_interval = [*cache.v_knots().first()?, *cache.v_knots().last()?];
    let cache_fit_tolerance = optional_trailing_cache_tolerance(&mut cur)?.value();
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Revolution {
            directrix: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(directrix)),
            axis_origin,
            axis_direction,
            angular_interval,
            parameter_interval,
            revision_form: None,
        },
        cache_fit_tolerance,
    ))
}

fn sum_spl_sur(
    toks: &[Token],
    resolver: Option<&SubtypeTable>,
) -> Option<DecodedProceduralSurface> {
    let names = ["sum_spl_sur", "sumsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated layout: revision integer, two curves each with two
        // optional endpoints, model-space origin, shared tail. The modern name
        // uses this layout.
        (name == "sum_spl_sur").then_some(())?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let table = resolver?;
        let first = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let first_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let second = embedded_base_curve_resolving_refs(&mut cur, table)?;
        let second_endpoints = [
            cur.take_optional_range_value()?.value(),
            cur.take_optional_range_value()?.value(),
        ];
        let origin = cur.take_position()?;
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        cur.at_scope_end().then_some(())?;
        return Some(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Sum {
                first: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(first)),
                second: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(second)),
                basepoint: Vector3::new(
                    origin[0] * LEN_TO_MM,
                    origin[1] * LEN_TO_MM,
                    origin[2] * LEN_TO_MM,
                ),
                revision_form: Some(cadmpeg_ir::geometry::RevisionSurfaceForm {
                    revision,
                    support_bounds: [None; 4],
                    reference_endpoints: first_endpoints,
                    second_endpoints,
                    flags: Vec::new(),
                    cache: cache.into_form()?,
                    discontinuities,
                    tail_flag,
                    trailing_flags: Vec::new(),
                }),
            },
        ));
    }
    let (first, first_end) = curve_block(span, cur.pos())?;
    cur.set_pos(first_end);
    let (second, second_end) = curve_block(span, cur.pos())?;
    cur.set_pos(second_end);
    let origin = cur.take_position()?;
    let basepoint = Vector3::new(
        origin[0] * LEN_TO_MM,
        origin[1] * LEN_TO_MM,
        origin[2] * LEN_TO_MM,
    );
    let cache_fit_tolerance = if cur.at_scope_end() {
        None
    } else {
        let (_, cache_end) = surface_block(span, cur.pos())?;
        cur.set_pos(cache_end);
        optional_trailing_cache_tolerance(&mut cur)?.value()
    };
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Sum {
            first: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(first)),
            second: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(second)),
            basepoint,
            revision_form: None,
        },
        cache_fit_tolerance,
    ))
}

fn ruled_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    let names = ["rule_sur", "rulesur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let (first, first_end) = curve_block(span, cur.pos())?;
    cur.set_pos(first_end);
    let (second, second_end) = curve_block(span, cur.pos())?;
    cur.set_pos(second_end);
    let cache_fit_tolerance = if cur.at_scope_end() {
        None
    } else {
        let (_, cache_end) = surface_block(span, cur.pos())?;
        cur.set_pos(cache_end);
        optional_trailing_cache_tolerance(&mut cur)?.value()
    };
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Ruled { first, second },
        cache_fit_tolerance,
    ))
}

fn exact_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    let names = ["exact_spl_sur", "exactsur"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated layout: revision integer, shared tail, four optional
        // parameter values, and the extension as an enum. The modern name uses
        // this layout.
        (name == "exact_spl_sur").then_some(())?;
        let revision = PositiveI64::new(cur.take_long()?)?;
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        // The two unextended parameter intervals, each an ordered [lo, hi] pair
        // of optional bounds. This subtype serializes them U-then-V; loft wrap
        // ranges sharing `RevisionRanges` serialize V-then-U. Store the
        // intervals by position and use the specification's labels.
        let unextended_ranges = [
            [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ],
            [
                cur.take_optional_range_value()?.value(),
                cur.take_optional_range_value()?.value(),
            ],
        ];
        let extension = cur.take_enum()?;
        cur.at_scope_end().then_some(())?;
        return Some(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Exact {
                spline: cadmpeg_ir::geometry::ExactSpline::Revision {
                    intervals: unextended_ranges,
                    extension,
                    form: Box::new(cadmpeg_ir::geometry::RevisionSurfaceForm {
                        revision,
                        support_bounds: [None; 4],
                        reference_endpoints: [None; 2],
                        second_endpoints: [None; 2],
                        flags: Vec::new(),
                        cache: cache.into_form()?,
                        discontinuities,
                        tail_flag,
                        trailing_flags: Vec::new(),
                    }),
                },
            },
        ));
    }
    let (_, cache_end) = surface_block(span, cur.pos())?;
    cur.set_pos(cache_end);
    let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
    let parameter_ranges = [
        [cur.take_range_value()?, cur.take_range_value()?],
        [cur.take_range_value()?, cur.take_range_value()?],
    ];
    let extension = cur.take_long()?;
    cur.at_scope_end().then_some(())?;
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Exact {
            spline: cadmpeg_ir::geometry::ExactSpline::Legacy {
                ranges: parameter_ranges,
                extension,
                cache: None,
            },
        },
        cache_fit_tolerance,
    ))
}

fn t_spl_sur(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    table: &SubtypeTable,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    enum Layout {
        Legacy {
            cache_fit_tolerance: f64,
            discontinuities: [Vec<f64>; 6],
            discontinuity_flag: bool,
            parameter_ranges: [[f64; 2]; 2],
        },
        Revision(Box<cadmpeg_ir::geometry::RevisionSurfaceForm>),
    }

    let (start, _) = toks::find_owned_subtype_marker(toks, &["t_spl_sur"])?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let (layout, type_code);
    if matches!(cur.peek(), Some(Token::Long(_))) {
        // Revision-gated layout: revision integer, shared tail, four optional
        // parameter values, the type code as an enum, then the nested
        // subtransform scope and trailing integer.
        let revision = PositiveI64::new(cur.take_long()?)?;
        let RevisionSurfaceTail {
            cache,
            discontinuities: tail_discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        let mut bounds = [None; 4];
        for bound in &mut bounds {
            *bound = cur.take_optional_range_value()?.value();
        }
        type_code = cur.take_enum()?;
        layout = Layout::Revision(Box::new(cadmpeg_ir::geometry::RevisionSurfaceForm {
            revision,
            support_bounds: bounds,
            reference_endpoints: [None; 2],
            second_endpoints: [None; 2],
            flags: Vec::new(),
            cache: cache.into_form()?,
            discontinuities: tail_discontinuities,
            tail_flag,
            trailing_flags: Vec::new(),
        }));
    } else {
        let (_, cache_end) = surface_block(span, cur.pos())?;
        cur.set_pos(cache_end);
        let cache_fit_tolerance = cur.take_f64()? * LEN_TO_MM;
        let discontinuities = [
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
        ];
        let discontinuity_flag = cur.take_bool()?;
        let parameter_ranges = [
            [cur.take_f64()? * LEN_TO_MM, cur.take_f64()? * LEN_TO_MM],
            [cur.take_f64()? * LEN_TO_MM, cur.take_f64()? * LEN_TO_MM],
        ];
        type_code = cur.take_long()?;
        layout = Layout::Legacy {
            cache_fit_tolerance,
            discontinuities,
            discontinuity_flag,
            parameter_ranges,
        };
    }
    if !matches!(cur.peek(), Some(Token::SubtypeOpen)) {
        return None;
    }
    cur.bump();
    let mut subtransform = propagate_resource!(t_spline_subtransform(&mut cur)?);
    if let EmbeddedTSplineSubtransform::Reference { index, resolved } = &mut subtransform {
        *resolved = propagate_resource!(usize::try_from(*index)
            .ok()
            .and_then(|index| resolve_t_spline_subtransform(
                ctx,
                index,
                table,
                &mut std::collections::HashSet::new()
            ))
            .transpose());
    }
    if !matches!(cur.peek(), Some(Token::SubtypeClose)) {
        return None;
    }
    cur.bump();
    let trailing_value = cur.take_long()?;
    cur.at_scope_end().then_some(())?;
    let parameter_ranges = match &layout {
        Layout::Legacy {
            parameter_ranges, ..
        } => *parameter_ranges,
        Layout::Revision(form) => {
            let bounds = form.support_bounds;
            [
                [bounds[0].unwrap_or(0.0), bounds[1].unwrap_or(0.0)],
                [bounds[2].unwrap_or(0.0), bounds[3].unwrap_or(0.0)],
            ]
        }
    };
    if parameter_ranges
        .iter()
        .any(|range| cadmpeg_ir::topology::ParameterInterval::new(*range).is_err())
    {
        // Leave the construction untyped; face admission keeps its independent
        // solved cache and retains the complete native record.
        return None;
    }
    Some(Ok(match layout {
        Layout::Legacy {
            cache_fit_tolerance,
            discontinuities,
            discontinuity_flag,
            parameter_ranges,
        } => DecodedProceduralSurface::legacy(
            DecodedProceduralSurfaceDefinition::TSpline(Box::new(EmbeddedTSplineSurface {
                parameter_ranges,
                type_code,
                subtransform,
                trailing_value,
                discontinuities,
                discontinuity_flag,
                revision_form: None,
            })),
            Some(cache_fit_tolerance),
        ),
        Layout::Revision(form) => DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::TSpline(Box::new(EmbeddedTSplineSurface {
                parameter_ranges,
                type_code,
                subtransform,
                trailing_value,
                discontinuities: copy_revision_discontinuities(&form.discontinuities),
                discontinuity_flag: form.tail_flag,
                revision_form: Some(*form),
            })),
        ),
    }))
}

pub(crate) fn copy_revision_discontinuities(source: &[Vec<f64>; 6]) -> [Vec<f64>; 6] {
    [
        source[0].clone(),
        source[1].clone(),
        source[2].clone(),
        source[3].clone(),
        source[4].clone(),
        source[5].clone(),
    ]
}

fn deformable_surface_frame(
    cur: &mut Cur<'_>,
) -> Option<cadmpeg_ir::geometry::DeformableSurfaceFrame> {
    let mut leading_vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
    for vector in &mut leading_vectors {
        let value = cur.take_vector3()?;
        *vector = Vector3::new(value[0], value[1], value[2]);
    }
    let leading_parameter = cur.take_f64()?;
    let leading_flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
    let mut secondary_vectors = [Vector3::new(0.0, 0.0, 0.0); 3];
    for vector in &mut secondary_vectors {
        let value = cur.take_vector3()?;
        *vector = Vector3::new(value[0], value[1], value[2]);
    }
    let secondary_parameter = cur.take_f64()?;
    let secondary_flags = [cur.take_bool()?, cur.take_bool()?];
    let point = cur.take_position()?;
    let trailing_flags = [
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
    ];
    Some(cadmpeg_ir::geometry::DeformableSurfaceFrame {
        leading_vectors,
        leading_parameter,
        leading_flags,
        secondary_vectors,
        secondary_parameter,
        secondary_flags,
        point: Point3::new(
            point[0] * LEN_TO_MM,
            point[1] * LEN_TO_MM,
            point[2] * LEN_TO_MM,
        ),
        trailing_flags,
    })
}

fn deformable_vector_frame(
    cur: &mut Cur<'_>,
) -> Option<cadmpeg_ir::geometry::DeformableVectorFrame> {
    let mut vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
    for vector in &mut vectors {
        let value = cur.take_vector3()?;
        *vector = Vector3::new(value[0], value[1], value[2]);
    }
    Some(cadmpeg_ir::geometry::DeformableVectorFrame {
        vectors,
        parameter: cur.take_f64()?,
        flags: [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?],
    })
}

fn revision_deformable_mode3(
    cur: &mut Cur<'_>,
) -> Option<cadmpeg_ir::geometry::DeformableSurfaceData> {
    let mut leading_vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
    for vector in &mut leading_vectors {
        let value = cur.take_vector3()?;
        *vector = Vector3::new(value[0], value[1], value[2]);
    }
    let leading_parameter = cur.take_f64()?;
    let leading_flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
    let point = cur.take_position()?;
    let trailing_point = Point3::new(
        point[0] * LEN_TO_MM,
        point[1] * LEN_TO_MM,
        point[2] * LEN_TO_MM,
    );
    let mut trailing_vectors = [Vector3::new(0.0, 0.0, 0.0); 2];
    for vector in &mut trailing_vectors {
        let value = cur.take_vector3()?;
        *vector = Vector3::new(value[0], value[1], value[2]);
    }
    let frame_parameter = cur.take_f64()?;
    let frame_flags = [cur.take_bool()?, cur.take_bool()?];
    let parameters = [cur.take_f64()?, cur.take_f64()?, cur.take_f64()?];
    let trailing_flags = [
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
        cur.take_bool()?,
    ];
    let trailing_parameter = cur.take_f64()?;
    let trailing_value = cur.take_long()?;
    Some(cadmpeg_ir::geometry::DeformableSurfaceData::RevisionMode3 {
        leading_vectors,
        leading_parameter,
        leading_flags,
        trailing_point,
        trailing_vectors,
        frame_parameter,
        frame_flags,
        parameters,
        trailing_flags,
        trailing_parameter,
        trailing_value,
    })
}

fn defm_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    use cadmpeg_ir::geometry::DeformableSurfaceData;
    let names = ["defm_spl_sur", "defmsur"];
    let (start, _) = toks::find_owned_subtype_marker(toks, &names)?;
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let (support, revision_form_head) = if matches!(cur.peek(), Some(Token::Long(_))) {
        let revision = PositiveI64::new(cur.take_long()?)?;
        (revision.get() == 22_506).then_some(())?;
        let crate::nurbs::proc_curve::EmbeddedSupport {
            surface: support,
            ranges,
            ..
        } = embedded_surface_with_ranges(&mut cur)?;
        let support_bounds = [ranges[0][0], ranges[0][1], ranges[1][0], ranges[1][1]];
        (support, Some((revision, support_bounds)))
    } else {
        (embedded_surface(&mut cur)?, None)
    };
    let mode = cur.take_long()?;
    let data = match mode {
        1 => {
            let frame = Box::new(deformable_surface_frame(&mut cur)?);
            let count = usize::try_from(cur.take_long()?).ok()?;
            let mut parameter_triples = Vec::new();
            for _ in 0..count {
                parameter_triples.push([cur.take_f64()?, cur.take_f64()?, cur.take_f64()?]);
            }
            EmbeddedDeformableSurfaceData::Resolved(DeformableSurfaceData::Plain {
                frame,
                parameter_triples,
            })
        }
        3 if revision_form_head.is_some() => {
            EmbeddedDeformableSurfaceData::Resolved(revision_deformable_mode3(&mut cur)?)
        }
        3 => EmbeddedDeformableSurfaceData::Resolved(DeformableSurfaceData::Guided {
            frame: Box::new(deformable_surface_frame(&mut cur)?),
            selector: cur.take_long()?,
            guide_parameter: cur.take_f64()?,
        }),
        5 => {
            let surface = embedded_surface(&mut cur)?;
            let native_id = cur.take_long()?;
            let flag = cur.take_bool()?;
            let first_parameter = cur.take_f64()?;
            let selector = cur.take_long()?;
            let second_parameter = cur.take_f64()?;
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            let mut vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
            for vector in &mut vectors {
                let value = cur.take_vector3()?;
                *vector = Vector3::new(value[0], value[1], value[2]);
            }
            let frame_parameter = cur.take_f64()?;
            let flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
            let count = usize::try_from(cur.take_long()?).ok()?;
            let mut parameter_triples = Vec::new();
            for _ in 0..count {
                parameter_triples.push([cur.take_f64()?, cur.take_f64()?, cur.take_f64()?]);
            }
            EmbeddedDeformableSurfaceData::SurfaceCurve {
                surface,
                native_id,
                flag,
                first_parameter,
                selector,
                second_parameter,
                curve,
                vectors,
                frame_parameter,
                flags,
                parameter_triples,
            }
        }
        6 => {
            let mut leading_vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
            for vector in &mut leading_vectors {
                let value = cur.take_vector3()?;
                *vector = Vector3::new(value[0], value[1], value[2]);
            }
            let leading_parameter = cur.take_f64()?;
            let leading_flags = [cur.take_bool()?, cur.take_bool()?, cur.take_bool()?];
            let selector = cur.take_long()?;
            let surface = embedded_surface(&mut cur)?;
            let native_id = cur.take_long()?;
            let flag = cur.take_bool()?;
            let first_parameter = cur.take_f64()?;
            let version_value = matches!(cur.peek(), Some(Token::Long(_)))
                .then(|| cur.take_long())
                .flatten();
            let second_parameter = cur.take_f64()?;
            let (curve, curve_end) = curve_block(span, cur.pos())?;
            cur.set_pos(curve_end);
            let frames = Box::new([
                deformable_vector_frame(&mut cur)?,
                deformable_vector_frame(&mut cur)?,
            ]);
            EmbeddedDeformableSurfaceData::Full {
                leading_vectors,
                leading_parameter,
                leading_flags,
                selector,
                surface,
                native_id,
                flag,
                first_parameter,
                version_value,
                second_parameter,
                curve,
                frames,
                trailing_value: cur.take_long()?,
            }
        }
        8 => {
            let mut vectors = [Vector3::new(0.0, 0.0, 0.0); 4];
            for vector in &mut vectors {
                let value = cur.take_vector3()?;
                *vector = Vector3::new(value[0], value[1], value[2]);
            }
            EmbeddedDeformableSurfaceData::Resolved(DeformableSurfaceData::Minimal {
                vectors,
                selector: cur.take_long()?,
            })
        }
        _ => return None,
    };
    if let Some((revision, support_bounds)) = revision_form_head {
        let RevisionSurfaceTail {
            cache,
            discontinuities,
            tail_flag,
        } = revision_surface_tail(&mut cur)?;
        cur.at_scope_end().then_some(())?;
        Some(DecodedProceduralSurface::revision(
            DecodedProceduralSurfaceDefinition::Deformable(Box::new(EmbeddedDeformableSurface {
                support,
                layout: EmbeddedDeformableSurfaceLayout::Revision(Box::new(
                    cadmpeg_ir::geometry::RevisionSurfaceForm {
                        revision,
                        support_bounds,
                        reference_endpoints: [None; 2],
                        second_endpoints: [None; 2],
                        flags: Vec::new(),
                        cache: cache.into_form()?,
                        discontinuities,
                        tail_flag,
                        trailing_flags: Vec::new(),
                    },
                )),
                data,
            })),
        ))
    } else {
        let (_, cache_end) = surface_block(span, cur.pos())?;
        cur.set_pos(cache_end);
        let cache_fit_tolerance = Some(cur.take_f64()? * LEN_TO_MM);
        let discontinuities = [
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
            cur.take_float_array()?,
        ];
        let discontinuity_flag = cur.take_bool()?;
        Some(DecodedProceduralSurface::legacy(
            DecodedProceduralSurfaceDefinition::Deformable(Box::new(EmbeddedDeformableSurface {
                support,
                layout: EmbeddedDeformableSurfaceLayout::Legacy {
                    discontinuities,
                    discontinuity_flag,
                },
                data,
            })),
            cache_fit_tolerance,
        ))
    }
}

pub(super) fn helix_spl_sur(toks: &[Token]) -> Option<DecodedProceduralSurface> {
    use cadmpeg_ir::geometry::HelixSurfaceProfile;

    let names = ["helix_spl_circ", "helix_spl_line"];
    let (start, name) = toks::find_owned_subtype_marker(toks, &names)?;
    let circular = name == "helix_spl_circ";
    let span = toks::subtype_span(toks, start)?.tokens();
    let mut cur = Cur::at(span, 2);
    let current_layout = optional_helix_revision(&mut cur)?;
    let angle_range = [cur.take_range_value()?, cur.take_range_value()?];
    let dimension_range = [cur.take_range_value()?, cur.take_range_value()?];
    let length = circular.then(|| cur.take_f64()).flatten();
    let path_angle_range = [cur.take_range_value()?, cur.take_range_value()?];
    let center = cur.take_position()?;
    let take_frame_vector = |cur: &mut Cur<'_>| {
        if current_layout {
            cur.take_vector3()
        } else {
            cur.take_position()
        }
    };
    let major = take_frame_vector(&mut cur)?;
    let minor = take_frame_vector(&mut cur)?;
    let pitch = take_frame_vector(&mut cur)?;
    let apex_factor = cur.take_f64()?;
    let axis = normalized(cur.take_vector3()?)?;
    for sentinel in ["null_surface", "null_surface", "nullbs", "nullbs"] {
        if cur.take_ident()? != sentinel {
            return None;
        }
    }
    let path = cadmpeg_ir::geometry::HelixPathConstruction::try_with_unit_axis(
        path_angle_range,
        cadmpeg_ir::geometry::HelixFrame {
            center: Point3::new(
                center[0] * LEN_TO_MM,
                center[1] * LEN_TO_MM,
                center[2] * LEN_TO_MM,
            ),
            major: Vector3::new(
                major[0] * LEN_TO_MM,
                major[1] * LEN_TO_MM,
                major[2] * LEN_TO_MM,
            ),
            minor: Vector3::new(
                minor[0] * LEN_TO_MM,
                minor[1] * LEN_TO_MM,
                minor[2] * LEN_TO_MM,
            ),
            pitch: Vector3::new(
                pitch[0] * LEN_TO_MM,
                pitch[1] * LEN_TO_MM,
                pitch[2] * LEN_TO_MM,
            ),
            axis,
        },
        apex_factor,
    )
    .ok()?;
    let profile = if let Some(length) = length {
        HelixSurfaceProfile::Circle(
            cadmpeg_ir::geometry::HelixCircleProfile::try_new(length, cur.take_f64()? * LEN_TO_MM)
                .ok()?,
        )
    } else {
        let direction = take_frame_vector(&mut cur)?;
        HelixSurfaceProfile::Line(
            cadmpeg_ir::geometry::HelixLineProfile::try_new(Vector3::new(
                direction[0],
                direction[1],
                direction[2] * LEN_TO_MM,
            ))
            .ok()?,
        )
    };
    Some(DecodedProceduralSurface::legacy(
        DecodedProceduralSurfaceDefinition::Helix(Box::new(
            cadmpeg_ir::geometry::HelixSurfaceConstruction::try_new(
                angle_range,
                dimension_range,
                path,
                profile,
            )
            .ok()?,
        )),
        None,
    ))
}

fn t_spline_subtransform(
    cur: &mut Cur<'_>,
) -> Option<Result<EmbeddedTSplineSubtransform, cadmpeg_core::CodecError>> {
    match cur.take_ident()? {
        "t_spl_subtrans_object" => {
            let program_text = cur.take_str()?;
            let program = program_text.to_owned();
            let separator = if matches!(cur.peek(), Some(Token::Str(_))) {
                None
            } else {
                Some(cur.take_bool()?)
            };
            let values_text = cur.take_str()?;
            let values = values_text.to_owned();
            Some(Ok(EmbeddedTSplineSubtransform::Inline {
                program,
                separator,
                values,
            }))
        }
        "ref" => Some(Ok(EmbeddedTSplineSubtransform::Reference {
            index: cur.take_long()?,
            resolved: None,
        })),
        _ => None,
    }
}

fn resolve_t_spline_subtransform(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    index: usize,
    table: &SubtypeTable,
    seen: &mut std::collections::HashSet<usize>,
) -> Option<Result<cadmpeg_ir::geometry::InlineTSplineSubtransform, cadmpeg_core::CodecError>> {
    let _depth = propagate_resource!(ctx.enter_nested("resolve ASM t spline subtransform"));
    if seen.contains(&index) {
        return None;
    }
    seen.insert(index);
    let span = table.span(index)?.tokens();
    let start = usize::from(matches!(span.first(), Some(Token::SubtypeOpen)));
    let decoded = propagate_resource!(t_spline_subtransform(&mut Cur::at(span, start))?);
    match decoded {
        EmbeddedTSplineSubtransform::Inline {
            program,
            separator,
            values,
        } => cadmpeg_ir::geometry::InlineTSplineSubtransform::try_new(program, separator, values)
            .ok()
            .map(Ok),
        EmbeddedTSplineSubtransform::Reference { index, .. } => {
            resolve_t_spline_subtransform(ctx, usize::try_from(index).ok()?, table, seen)
        }
    }
}

/// Decode a native procedural definition, following nested subtype-table references.
pub fn procedural_surface_resolving_refs(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    table: &SubtypeTable,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    procedural_resolving_refs(ctx, toks, table, &mut std::collections::HashSet::new())
}

fn procedural_resolving_refs(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    toks: &[Token],
    table: &SubtypeTable,
    seen: &mut std::collections::HashSet<usize>,
) -> Option<Result<DecodedProceduralSurface, cadmpeg_core::CodecError>> {
    let _depth = propagate_resource!(ctx.enter_nested("resolve ASM procedural surface reference"));
    if let Some(decoded) = defm_spl_sur(toks)
        .map(Ok)
        .or_else(|| helix_spl_sur(toks).map(Ok))
        .or_else(|| t_spl_sur(ctx, toks, table))
        .or_else(|| exact_spl_sur(toks).map(Ok))
        .or_else(|| comp_spl_sur(toks).map(Ok))
        .or_else(|| taper_spl_sur(ctx, toks, Some(table)))
        .or_else(|| loft_spl_sur(ctx, toks, Some(table)))
        .or_else(|| compound_loft_spl_sur(ctx, toks, Some(table)))
        .or_else(|| scaled_compound_loft_spl_sur(toks).map(Ok))
        .or_else(|| sub_spl_sur(toks).map(Ok))
        .or_else(|| law_spl_sur(ctx, toks))
        .or_else(|| skin_spl_sur(ctx, toks))
        .or_else(|| net_spl_sur(ctx, toks))
        .or_else(|| sweep_spl_sur(ctx, toks, Some(table)))
        .or_else(|| g2_blend_spl_sur(ctx, toks, Some(table)))
        .or_else(|| ruled_spl_sur(toks).map(Ok))
        .or_else(|| sum_spl_sur(toks, Some(table)).map(Ok))
        .or_else(|| rot_spl_sur(toks, Some(table)).map(Ok))
        .or_else(|| off_spl_sur(ctx, toks, Some(table)))
        .or_else(|| cyl_spl_sur(toks, Some(table)).map(Ok))
        .or_else(|| {
            var_blend_spl_sur(ctx, toks, Some(table), SupportCaches::Resolve)
                .and_then(|result| result.map(|parsed| parsed.surface).transpose())
        })
        .or_else(|| vertex_blend_spl_sur(ctx, toks, Some(table)))
        .or_else(|| full_rb_blend_spl_sur(ctx, toks, table))
        .or_else(|| compact_rb_blend_spl_sur(toks).map(Ok))
    {
        return Some(decoded);
    }
    // Follow references for records whose own construction is absent. A record
    // with an undecoded construction keeps its native data; its references
    // belong to that construction's supports.
    if toks::owned_subtype_defs(toks)?
        .iter()
        .any(|(_, name)| *name != "ref")
    {
        return None;
    }
    for index in toks::subtype_refs(toks) {
        if seen.contains(&index) {
            continue;
        }
        // The doc states what the index means. `docs/formats/asm.md`: "A named
        // `ref N` scope or compact `0x0F LONG N 0x10` scope nested inside a
        // surface, curve, or pcurve body indexes a per-file subtype table, not
        // a byte offset. Each subtype definition -- a `0x0F` opening followed
        // by a `0x0d`/`0x0e` name token other than `ref` -- contributes one
        // table entry in stream order." An index at or beyond the table's
        // length therefore names no definition the stream states. What the
        // decoder does about it is the decoder's decision: the search refuses
        // the stream rather than skipping the reference and reading the one
        // behind it.
        let target = table.span(index)?.tokens();
        seen.insert(index);
        if let Some(decoded) = procedural_resolving_refs(ctx, target, table, seen) {
            return Some(decoded);
        }
    }
    None
}

#[cfg(test)]
mod reference_allocation_tests {}

#[cfg(test)]
mod loft_count_tests {
    use super::loft_subdata_form;
    use crate::nurbs::toks::Cur;
    use crate::sab::Token;

    #[test]
    fn huge_column_count_without_pairs_is_refused_before_reservation() {
        let tokens = [
            Token::Long(212),
            Token::Long(1),
            Token::Long(i64::MAX),
            Token::Double(0.0),
            Token::Double(1.0),
        ];
        assert!(loft_subdata_form(&mut Cur::at(&tokens, 0), false).is_none());
    }
}

#[cfg(test)]
mod sweep_law_tests {
    use super::{
        law_expression, law_formula_resolving, sweep_law_expression, EmbeddedLawExpression,
    };
    use crate::nurbs::toks::Cur;
    use crate::sab::Token;
    use cadmpeg_ir::math::Vector3;

    #[test]
    fn sweep_text_law_consumes_one_serializer_token() {
        let resource_arena = cadmpeg_core::decode::DecodeArena::new();
        let (resource_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &resource_arena,
            &cadmpeg_core::decode::DecodePolicy::default(),
        )
        .expect("test decode context");
        let tokens = [Token::Str("0.008726867790758789*X".into()), Token::Long(21)];
        let mut cur = Cur::at(&tokens, 0);

        let law = sweep_law_expression(&resource_ctx, &mut cur)
            .transpose()
            .expect("decode the sweep law expression")
            .expect("text law");

        let EmbeddedLawExpression::Text(value) = law else {
            panic!("expected text law");
        };
        assert_eq!(value, "0.008726867790758789*X");
        assert_eq!(cur.take_long(), Some(21));
        assert_eq!(cur.pos(), tokens.len());
    }

    #[test]
    fn composition_law_consumes_two_recursive_operands() {
        let resource_arena = cadmpeg_core::decode::DecodeArena::new();
        let (resource_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &resource_arena,
            &cadmpeg_core::decode::DecodePolicy::default(),
        )
        .expect("test decode context");
        let tokens = [
            Token::Str("O".into()),
            Token::Str("ABS".into()),
            Token::Double(-2.5),
            Token::Str("SIN".into()),
            Token::Double(0.25),
        ];
        let mut cur = Cur::at(&tokens, 0);

        let law = law_expression(&resource_ctx, &mut cur, 0)
            .transpose()
            .expect("decode the law expression")
            .expect("composition law");

        assert!(matches!(
            law,
            EmbeddedLawExpression::Algebraic { operator, operands }
                if operator == "O"
                    && matches!(operands.as_slice(), [
                        EmbeddedLawExpression::Algebraic { operator: left, operands: left_operands },
                        EmbeddedLawExpression::Algebraic { operator: right, operands: right_operands },
                    ] if left == "ABS"
                        && matches!(left_operands.as_slice(), [EmbeddedLawExpression::Double(value)] if *value == -2.5)
                        && right == "SIN"
                        && matches!(right_operands.as_slice(), [EmbeddedLawExpression::Double(value)] if *value == 0.25))
        ));
        assert_eq!(cur.pos(), tokens.len());
    }

    #[test]
    fn rail_formula_decodes_counted_vector_transform_binding() {
        let resource_arena = cadmpeg_core::decode::DecodeArena::new();
        let (resource_ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            &[],
            &resource_arena,
            &cadmpeg_core::decode::DecodePolicy::default(),
        )
        .expect("test decode context");
        let vectors = [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [2.0, 3.0, 4.0],
        ];
        let mut tokens = vec![
            Token::Str("ROTATE(DOMAIN(VEC(1,0,0),0,0.8),TRANS1)".into()),
            Token::Long(1),
            Token::Str("TRANS".into()),
        ];
        tokens.extend(vectors.into_iter().map(Token::Vector3));
        tokens.extend([Token::Double(1.5), Token::True, Token::False, Token::True]);
        let mut cur = Cur::at(&tokens, 0);

        let formula = law_formula_resolving(&resource_ctx, &mut cur, None)
            .transpose()
            .expect("decode the law formula")
            .expect("rail formula");

        assert_eq!(formula.name(), "ROTATE(DOMAIN(VEC(1,0,0),0,0.8),TRANS1)");
        let [EmbeddedLawExpression::TransformVec {
            vectors: actual_vectors,
            scale,
            flags,
        }] = formula.variables()
        else {
            panic!("expected one vector transform binding");
        };
        assert_eq!(
            *actual_vectors,
            vectors.map(|value| Vector3::new(value[0], value[1], value[2]))
        );
        assert_eq!(*scale, 1.5);
        assert_eq!(*flags, [true, false, true]);
        assert_eq!(cur.pos(), tokens.len());
    }
}

#[cfg(test)]
mod tail_selector_tests {
    use super::{revision_surface_tail, RevisionSurfaceCache};
    use crate::kernel_header::RefWidth;
    use crate::nurbs::toks::{self, Cur};

    /// A four-byte enum field.
    fn push_enum(span: &mut Vec<u8>, value: i32) {
        span.push(0x15);
        span.extend_from_slice(&value.to_le_bytes());
    }

    /// A four-byte counted float array of `count` zeros.
    fn push_float_array(span: &mut Vec<u8>, count: i32) {
        span.push(0x04);
        span.extend_from_slice(&count.to_le_bytes());
        for _ in 0..count {
            span.push(0x06);
            span.extend_from_slice(&0.0f64.to_le_bytes());
        }
    }

    /// A shared revision-gated surface tail whose opening enum selects an
    /// undefined cache form. The helper rejects the form and retains the
    /// containing record verbatim.
    #[test]
    fn undefined_tail_form_is_rejected_for_verbatim_retention() {
        // Enum with value 1, followed by a value that could otherwise open a
        // solved cache block's fields.
        let mut span = Vec::new();
        push_enum(&mut span, 1);
        span.push(0x06);
        span.extend_from_slice(&0.0f64.to_le_bytes());
        let toks =
            toks::lex_test_span(&span, RefWidth::Four).expect("valid single-record byte fixture");
        let mut cur = Cur::at(&toks, 0);
        assert!(revision_surface_tail(&mut cur).is_none());
    }

    /// Tail form `2` stores no cache and no fit tolerance: the U parameter
    /// interval, the V parameter interval, then U closure, V closure, U
    /// singularity, and V singularity.
    #[test]
    fn parameterized_tail_form_decodes_intervals_then_closure_enums() {
        let mut span = Vec::new();
        push_enum(&mut span, 2);
        // U interval: present lower bound, absent upper bound.
        span.push(0x0a);
        span.push(0x06);
        span.extend_from_slice(&0.25f64.to_le_bytes());
        span.push(0x0b);
        // V interval: both bounds present.
        for value in [(-1.5f64), 3.5] {
            span.push(0x0a);
            span.push(0x06);
            span.extend_from_slice(&value.to_le_bytes());
        }
        for value in [1, 0, 2, 3] {
            push_enum(&mut span, value);
        }
        push_float_array(&mut span, 1);
        for _ in 0..5 {
            push_float_array(&mut span, 0);
        }
        span.push(0x0b);

        let toks =
            toks::lex_test_span(&span, RefWidth::Four).expect("valid single-record byte fixture");
        let mut cur = Cur::at(&toks, 0);
        let tail = revision_surface_tail(&mut cur).expect("parameterized tail");
        assert_eq!(cur.pos(), toks.len());
        let RevisionSurfaceCache::Parameterized(parameterization) = tail.cache else {
            panic!("parameterization");
        };
        assert_eq!(parameterization.u_interval, [Some(0.25), None]);
        assert_eq!(parameterization.v_interval, [Some(-1.5), Some(3.5)]);
        assert_eq!(parameterization.u_closure, 1);
        assert_eq!(parameterization.v_closure, 0);
        assert_eq!(parameterization.u_singularity, 2);
        assert_eq!(parameterization.v_singularity, 3);
        assert_eq!(tail.discontinuities[0], [0.0]);
        assert!(tail.discontinuities[1..].iter().all(Vec::is_empty));
        assert!(!tail.tail_flag);
    }
}

#[cfg(test)]
mod ellipse_tests {
    #[test]
    fn numerical_followup_ellipse_accepts_extreme_finite_radii() {
        for radius in [1.0, 1e200, 1e-200] {
            let curve =
                super::ellipse_to_nurbs([0.; 3], [0., 0., 1.], [radius, 0., 0.], 0.5).unwrap();
            let poles = curve.control_points();
            assert_eq!(poles[0].x, radius * super::LEN_TO_MM);
            assert_eq!(poles[2].y, 0.5 * radius * super::LEN_TO_MM);
        }
    }
}
