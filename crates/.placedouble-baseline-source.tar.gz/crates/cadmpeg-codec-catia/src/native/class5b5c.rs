// SPDX-License-Identifier: Apache-2.0
//! Native class-0x5b/0x5c frames and their byte-string wire projection.

use cadmpeg_ir::native::bytes::NativeBytes;

use cadmpeg_core::decode::u64_from_index;

use crate::wire::records::{ConsolidatedFrameFlag, ConsolidatedFrameWidth, ConsolidatedRawFrame};
use serde::{Deserialize, Serialize};

/// Record class of a consolidated B-family class-`0x5b` or class-`0x5c` frame.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum CatiaClass5b5c {
    /// Class `0x5b`.
    Class5b,
    /// Class `0x5c`.
    Class5c,
}

impl From<CatiaClass5b5c> for u8 {
    fn from(value: CatiaClass5b5c) -> Self {
        match value {
            CatiaClass5b5c::Class5b => 0x5b,
            CatiaClass5b5c::Class5c => 0x5c,
        }
    }
}

impl TryFrom<u8> for CatiaClass5b5c {
    type Error = String;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0x5b => Ok(Self::Class5b),
            0x5c => Ok(Self::Class5c),
            other => Err(format!("class {other:#x} is not 0x5b or 0x5c")),
        }
    }
}

/// Complete consolidated class-`0x5b` or class-`0x5c` source-local control record.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(try_from = "Class5b5cWire")]
pub(crate) struct CatiaConsolidatedClass5b5cRecord {
    /// Stable native-record identity.
    pub(super) id: String,
    /// Complete framed record.
    pub(super) frame: ConsolidatedRawFrame<u64>,
    /// Zero-based bounded record-source ordinal.
    pub(super) source_index: u64,
    /// Logical offset within the bounded record source.
    pub(super) source_offset: u64,
    /// Record class.
    pub(super) class: CatiaClass5b5c,
}

impl CatiaConsolidatedClass5b5cRecord {
    fn byte_len(&self) -> u64 {
        4 + u64::from(u8::from(self.frame.width())) + u64_from_index(self.frame.payload.len())
    }
}

#[derive(Serialize, Deserialize)]
struct Class5b5cWire {
    id: String,
    byte_offset: u64,
    source_index: u64,
    source_offset: u64,
    byte_len: u64,
    width: ConsolidatedFrameWidth,
    flag: ConsolidatedFrameFlag,
    class: CatiaClass5b5c,
    header_token: u32,
    payload: NativeBytes<Vec<u8>>,
}

#[derive(Serialize)]
struct Class5b5cWireRef<'a> {
    id: &'a str,
    byte_offset: u64,
    source_index: u64,
    source_offset: u64,
    byte_len: u64,
    width: ConsolidatedFrameWidth,
    flag: ConsolidatedFrameFlag,
    class: CatiaClass5b5c,
    header_token: u32,
    payload: NativeBytes<&'a [u8]>,
}

impl Serialize for CatiaConsolidatedClass5b5cRecord {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        Class5b5cWireRef {
            id: &self.id,
            byte_offset: self.frame.pos,
            source_index: self.source_index,
            source_offset: self.source_offset,
            byte_len: self.byte_len(),
            width: self.frame.width(),
            flag: self.frame.flag,
            class: self.class,
            header_token: self.frame.header_token(),
            payload: (&self.frame.payload).into(),
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaConsolidatedClass5b5cRecord> for Class5b5cWire {
    fn from(record: CatiaConsolidatedClass5b5cRecord) -> Self {
        Self {
            byte_len: record.byte_len(),
            id: record.id,
            byte_offset: record.frame.pos,
            source_index: record.source_index,
            source_offset: record.source_offset,
            width: record.frame.width(),
            flag: record.frame.flag,
            class: record.class,
            header_token: record.frame.header_token(),
            payload: (record.frame.payload),
        }
    }
}

impl TryFrom<Class5b5cWire> for CatiaConsolidatedClass5b5cRecord {
    type Error = String;
    fn try_from(wire: Class5b5cWire) -> Result<Self, Self::Error> {
        let record = Self {
            id: wire.id,
            frame: ConsolidatedRawFrame::new(
                wire.byte_offset,
                wire.width,
                wire.flag,
                wire.header_token,
                wire.payload.into_inner(),
            )?,
            source_index: wire.source_index,
            source_offset: wire.source_offset,
            class: wire.class,
        };
        if wire.byte_len != record.byte_len() {
            return Err("class-0x5b/0x5c byte_len differs from the complete frame".to_owned());
        }
        Ok(record)
    }
}

#[cfg(test)]
mod tests {
    use super::{CatiaClass5b5c, CatiaConsolidatedClass5b5cRecord, Class5b5cWire};
    use crate::wire::records::ConsolidatedFrameFlag;
    use crate::wire::records::ConsolidatedFrameWidth;
    use crate::wire::records::ConsolidatedRawFrame;

    #[test]
    fn class5b5c_borrowed_wire_preserves_json_bytes() {
        let native = crate::native::CatiaNative::decode(
            &crate::test_support::test_b2::b2_class5b5c_stream(),
        );
        for record in &native.consolidated_class5b5c_records {
            let owned: Class5b5cWire = record.clone().into();
            assert_eq!(
                serde_json::to_vec(record).expect("borrowed control JSON"),
                serde_json::to_vec(&owned).expect("owned control JSON")
            );
        }
        assert!(!native.consolidated_class5b5c_records.is_empty());
    }

    #[test]
    fn class5b5c_retained_limit_refuses_json_record() {
        let native = crate::native::CatiaNative::decode(
            &crate::test_support::test_b2::b2_class5b5c_stream(),
        );
        let record: &CatiaConsolidatedClass5b5cRecord = native
            .consolidated_class5b5c_records
            .first()
            .expect("control record");
        let arena_name = "consolidated_class5b5c_records";
        let json_len = serde_json::to_vec(record).expect("control JSON").len();
        let limit = u64::try_from(json_len - 1).expect("small JSON");
        let refused = crate::test_support::with_retained_limit(limit, |ctx| {
            let mut namespace = cadmpeg_ir::NativeNamespace::default();
            namespace.set_arena(ctx, arena_name, std::slice::from_ref(record))
        });
        let error = refused.expect_err("record exceeds retained-byte limit");
        assert!(error.to_string().contains("RetainedBytes"), "{error}");
        crate::test_support::with_service_context(|ctx| {
            let mut namespace = cadmpeg_ir::NativeNamespace::default();
            namespace
                .set_arena(ctx, arena_name, std::slice::from_ref(record))
                .expect("store the native arena");
        });
    }
    #[test]
    fn frame_wire_preserves_byte_payload_and_checks_derived_length() {
        let record = CatiaConsolidatedClass5b5cRecord {
            id: "catia:consolidated:class5b5c-record#0".to_owned(),
            frame: ConsolidatedRawFrame::new(
                42,
                ConsolidatedFrameWidth::Two,
                ConsolidatedFrameFlag::Flag03,
                5,
                vec![0, 0, 0],
            )
            .expect("checked fixture frame"),
            source_index: 0,
            source_offset: 42,
            class: CatiaClass5b5c::Class5b,
        };
        let mut wire = serde_json::to_value(&record).expect("serialize raw frame");
        assert_eq!(wire["byte_offset"], serde_json::json!(42));
        assert_eq!(wire["byte_len"], serde_json::json!(9));
        assert_eq!(wire["payload"], serde_json::json!("000000"));
        assert_eq!(
            serde_json::from_value::<CatiaConsolidatedClass5b5cRecord>(wire.clone())
                .expect("load raw frame"),
            record
        );
        wire["byte_len"] = serde_json::json!(8);
        assert!(
            serde_json::from_value::<CatiaConsolidatedClass5b5cRecord>(wire)
                .expect_err("reject truncated declared frame")
                .to_string()
                .contains("byte_len differs")
        );
    }
}
