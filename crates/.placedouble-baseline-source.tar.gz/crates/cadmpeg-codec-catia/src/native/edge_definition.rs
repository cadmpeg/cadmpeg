// SPDX-License-Identifier: Apache-2.0
//! Native edge-definition wire projection from its class and raw payload.

use cadmpeg_ir::native::bytes::NativeBytes;

use crate::families::consolidated::records::{
    consolidated_edge_definition_data, ConsolidatedEdgeDefinitionClass,
    ConsolidatedEdgeDefinitionData,
};
use crate::wire::records::{ConsolidatedFrameFlag, ConsolidatedFrameWidth, ConsolidatedRawFrame};
use serde::{Deserialize, Serialize};

/// Exact class-specific edge-definition frame owned by one consolidated edge node.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "EdgeDefinitionWire")]
pub(crate) struct CatiaConsolidatedEdgeDefinition {
    /// Complete raw frame.
    frame: ConsolidatedRawFrame<u64>,
    /// Edge-definition class in `0x23..=0x25`.
    class: ConsolidatedEdgeDefinitionClass,
    /// Class-specific data admitted during binary decode or wire validation.
    data: Option<ConsolidatedEdgeDefinitionData>,
}

#[derive(Serialize, Deserialize)]
struct EdgeDefinitionWire {
    byte_offset: u64,
    width: ConsolidatedFrameWidth,
    flag: ConsolidatedFrameFlag,
    class: ConsolidatedEdgeDefinitionClass,
    header_token: u32,
    payload: NativeBytes<Vec<u8>>,
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "deserialize_data"
    )]
    data: Option<ConsolidatedEdgeDefinitionData>,
}

#[derive(Serialize)]
struct EdgeDefinitionWireRef<'a> {
    byte_offset: u64,
    width: ConsolidatedFrameWidth,
    flag: ConsolidatedFrameFlag,
    class: ConsolidatedEdgeDefinitionClass,
    header_token: u32,
    payload: NativeBytes<&'a [u8]>,
    #[serde(skip_serializing_if = "Option::is_none")]
    data: Option<&'a ConsolidatedEdgeDefinitionData>,
}

impl Serialize for CatiaConsolidatedEdgeDefinition {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        EdgeDefinitionWireRef {
            byte_offset: self.frame.pos,
            width: self.frame.width(),
            flag: self.frame.flag,
            class: self.class,
            header_token: self.frame.header_token(),
            payload: (&self.frame.payload).into(),
            data: self.data(),
        }
        .serialize(serializer)
    }
}

impl CatiaConsolidatedEdgeDefinition {
    pub(crate) fn from_source(
        definition: crate::families::consolidated::records::ConsolidatedEdgeDefinition,
    ) -> Self {
        let frame = definition.frame.into();
        let data = data_from_frame(definition.class, &frame);
        Self {
            frame,
            class: definition.class,
            data,
        }
    }

    pub(crate) fn data(&self) -> Option<&ConsolidatedEdgeDefinitionData> {
        self.data.as_ref()
    }
    pub(crate) fn frame(&self) -> &ConsolidatedRawFrame<u64> {
        &self.frame
    }
    pub(crate) fn class(&self) -> ConsolidatedEdgeDefinitionClass {
        self.class
    }
}

#[cfg(test)]
impl From<CatiaConsolidatedEdgeDefinition> for EdgeDefinitionWire {
    fn from(value: CatiaConsolidatedEdgeDefinition) -> Self {
        Self {
            byte_offset: value.frame.pos,
            width: value.frame.width(),
            flag: value.frame.flag,
            class: value.class,
            header_token: value.frame.header_token(),
            payload: (value.frame.payload),
            data: value.data,
        }
    }
}

impl TryFrom<EdgeDefinitionWire> for CatiaConsolidatedEdgeDefinition {
    type Error = String;
    fn try_from(wire: EdgeDefinitionWire) -> Result<Self, Self::Error> {
        let data = wire.data;
        let value = Self {
            frame: ConsolidatedRawFrame::new(
                wire.byte_offset,
                wire.width,
                wire.flag,
                wire.header_token,
                wire.payload.into_inner(),
            )?,
            class: wire.class,
            data,
        };
        let derived = data_from_frame(value.class, &value.frame);
        if serde_json::to_vec(&value.data).map_err(|error| error.to_string())?
            != serde_json::to_vec(&derived).map_err(|error| error.to_string())?
        {
            return Err("edge-definition data differs from its class and payload".to_owned());
        }
        Ok(value)
    }
}

fn data_from_frame(
    class: ConsolidatedEdgeDefinitionClass,
    frame: &ConsolidatedRawFrame<u64>,
) -> Option<ConsolidatedEdgeDefinitionData> {
    if class == ConsolidatedEdgeDefinitionClass::Class25
        && frame.flag != ConsolidatedFrameFlag::Flag03
    {
        return None;
    }
    consolidated_edge_definition_data(class.into(), &frame.payload)
}

#[cfg(test)]
mod tests {
    use super::{CatiaConsolidatedEdgeDefinition, EdgeDefinitionWire};
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionClass;
    use crate::wire::records::ConsolidatedFrameFlag;
    use crate::wire::records::ConsolidatedFrameWidth;
    use crate::wire::records::ConsolidatedRawFrame;

    fn edge_definition() -> CatiaConsolidatedEdgeDefinition {
        CatiaConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                12,
                ConsolidatedFrameWidth::One,
                ConsolidatedFrameFlag::Flag03,
                5,
                vec![0x81, 0x05, 0x0f, 0x87],
            )
            .expect("checked fixture frame"),
            class: ConsolidatedEdgeDefinitionClass::Class24,
            data: Some(
                crate::families::consolidated::records::ConsolidatedEdgeDefinitionData::Compact24 {
                    operand: 1,
                },
            ),
        }
    }

    #[test]
    fn native_edge_definition_access_borrows_the_admitted_value() {
        let source = crate::families::consolidated::records::ConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                12,
                ConsolidatedFrameWidth::One,
                ConsolidatedFrameFlag::Flag03,
                5,
                vec![0x81, 0x05, 0x0f, 0x87],
            )
            .expect("checked frame"),
            class: ConsolidatedEdgeDefinitionClass::Class24,
        };
        let value = CatiaConsolidatedEdgeDefinition::from_source(source);
        let data = value.data().expect("compact data");
        assert!(std::ptr::eq(data, value.data().expect("same data")));
        assert_eq!(
            data,
            &crate::families::consolidated::records::ConsolidatedEdgeDefinitionData::Compact24 {
                operand: 1
            }
        );
    }

    #[test]
    fn edge_definition_borrowed_wire_preserves_json_bytes() {
        let value = edge_definition();
        let owned: EdgeDefinitionWire = value.clone().into();
        assert_eq!(
            serde_json::to_vec(&value).expect("borrowed definition JSON"),
            serde_json::to_vec(&owned).expect("owned definition JSON")
        );
    }

    #[test]
    fn edge_definition_retained_limit_refuses_json_record() {
        #[derive(serde::Serialize)]
        struct Record<'a> {
            id: &'static str,
            #[serde(flatten)]
            definition: &'a CatiaConsolidatedEdgeDefinition,
        }
        let value = edge_definition();

        let record = Record {
            id: "catia:test:definition#0",
            definition: &value,
        };
        let arena_name = "edge_definitions";
        let json_len = serde_json::to_vec(&record).expect("definition JSON").len();
        let limit = u64::try_from(json_len - 1).expect("small JSON");
        let refused = crate::test_support::with_retained_limit(limit, |ctx| {
            let mut namespace = cadmpeg_ir::NativeNamespace::default();
            namespace.set_arena(ctx, arena_name, std::slice::from_ref(&record))
        });
        let error = refused.expect_err("record exceeds retained-byte limit");
        assert!(error.to_string().contains("RetainedBytes"), "{error}");
        crate::test_support::with_service_context(|ctx| {
            let mut namespace = cadmpeg_ir::NativeNamespace::default();
            namespace
                .set_arena(ctx, arena_name, std::slice::from_ref(&record))
                .expect("store the native arena");
        });
    }

    #[test]
    fn native_edge_definition_parse_admits_complete_projection() {
        const MAP_ACCURACY: f64 = 1.0e-6;
        let mut payload = vec![0x82, 0x05, 0xe7, 0x0a, 0x87, 0x0d];
        for value in [1.0_f64, 2.0, MAP_ACCURACY, 1.0, 2.0, 1.0, 0.0, MAP_ACCURACY] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        let source = crate::families::consolidated::records::ConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                12,
                ConsolidatedFrameWidth::One,
                ConsolidatedFrameFlag::Flag03,
                5,
                payload,
            )
            .expect("checked map frame"),
            class: ConsolidatedEdgeDefinitionClass::Class25,
        };
        let service = crate::test_support::with_service_context(|_ctx| {
            CatiaConsolidatedEdgeDefinition::from_source(source.clone())
        });
        assert!(service.data().is_some());
    }

    #[test]
    fn native_edge_definition_scalar_lane_decodes() {
        const MAP_ACCURACY: f64 = 1.0e-6;
        let mut payload = vec![0x82, 0x05, 0xe7, 0x0a, 0x87, 0x0d];
        for value in [1.0_f64, 2.0, MAP_ACCURACY, 1.0, 2.0, 1.0, 0.0, MAP_ACCURACY] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        assert!(
            crate::families::consolidated::records::consolidated_edge_definition_data(
                0x25, &payload,
            )
            .is_some()
        );
    }

    #[test]
    fn wire_data_is_derived_and_conflicts_are_rejected() {
        let value = CatiaConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                12,
                ConsolidatedFrameWidth::try_from(1).expect("one-byte width"),
                ConsolidatedFrameFlag::try_from(3).expect("frame flag"),
                5,
                vec![0x81, 0x05, 0x0f, 0x87],
            )
            .expect("checked fixture frame"),
            class: ConsolidatedEdgeDefinitionClass::Class24,
            data: Some(
                crate::families::consolidated::records::ConsolidatedEdgeDefinitionData::Compact24 {
                    operand: 1,
                },
            ),
        };
        let mut wire = serde_json::to_value(&value).expect("serialize definition");
        assert_eq!(wire["class"], serde_json::json!(0x24));
        assert_eq!(
            wire["data"],
            serde_json::json!({"kind": "compact24", "operand": 1})
        );
        assert_eq!(
            serde_json::from_value::<CatiaConsolidatedEdgeDefinition>(wire.clone())
                .expect("load derived data"),
            value
        );
        wire["data"]["operand"] = serde_json::json!(2);
        assert!(
            serde_json::from_value::<CatiaConsolidatedEdgeDefinition>(wire)
                .expect_err("reject conflicting data")
                .to_string()
                .contains("data differs")
        );
    }
    #[test]
    fn native_affine23_wire_rejects_data_that_differs_from_the_frame() {
        const MAP_TOLERANCE: f64 = 1.0e-12;
        let mut payload = vec![0x82, 0x05, 0x09, 0x0a, 0x87, 0x0d];
        for value in [
            4.0_f64,
            8.0,
            MAP_TOLERANCE,
            1.0,
            3.0,
            2.0,
            2.0,
            MAP_TOLERANCE,
        ] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        let source = crate::families::consolidated::records::ConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                12,
                ConsolidatedFrameWidth::One,
                ConsolidatedFrameFlag::Flag03,
                5,
                payload,
            )
            .expect("checked map frame"),
            class: ConsolidatedEdgeDefinitionClass::Class23,
        };
        let value = crate::test_support::with_service_context(|_ctx| {
            CatiaConsolidatedEdgeDefinition::from_source(source)
        });
        let wire = serde_json::to_value(&value).expect("serialize affine map");
        assert_eq!(wire["data"]["kind"], "affine23");
        assert_eq!(wire["data"]["target_range"], serde_json::json!([4.0, 8.0]));
        assert_eq!(
            serde_json::from_value::<CatiaConsolidatedEdgeDefinition>(wire.clone())
                .expect("load affine map"),
            value
        );
        for (field, replacement) in [
            ("offset", serde_json::json!(3.0)),
            ("scale", serde_json::json!(3.0)),
            ("slots", serde_json::json!([2, 1])),
        ] {
            let mut contradictory = wire.clone();
            contradictory["data"][field] = replacement;
            assert!(
                serde_json::from_value::<CatiaConsolidatedEdgeDefinition>(contradictory).is_err()
            );
        }
    }
}

// Each optional key below names itself in whatever it refuses.
cadmpeg_core::named_optional_field!(deserialize_data, ConsolidatedEdgeDefinitionData, "data");
