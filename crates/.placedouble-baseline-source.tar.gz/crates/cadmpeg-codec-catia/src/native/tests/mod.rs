// SPDX-License-Identifier: Apache-2.0
//! Native-namespace tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

mod consolidated;
mod constraint;
mod cylinder_headers;
mod design;
mod entity;
mod entity_suffix;
mod entity_suffix_framing;
mod formula_relation;
mod four_reference_edges;
mod inventory;
mod legacy_value_names;
mod load;
mod relation_expression;
mod relation_program;
mod wire_projection;
mod zero_entity_records;

mod rolling_ball_continuations;
