// SPDX-License-Identifier: Apache-2.0
//! Native-namespace tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_core::decode::u64_from_index;

use cadmpeg_test_support::wire;

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::Annotations;

use crate::test_support::test_bytes::be32;
use crate::test_support::test_container::standard_catpart;
use crate::test_support::test_formula::{
    standard_catpart_with_definition_chain_value, standard_catpart_with_definition_value,
    standard_catpart_with_formula_relation, standard_catpart_with_parameter_value,
    standard_catpart_with_two_definition_chain_values,
    standard_catpart_with_unassigned_definition_chain_value,
};
use crate::test_support::test_object_graph::{
    catalog_stream, entity_backed_object_graph, entity_table_record_with_definition_and_value,
    entity_table_record_with_value, inline_object_graph_record, object_graph_from_records,
    object_graph_record, standard_catpart_with_crossing_entity_value_packet,
    standard_catpart_with_entity_value_schema_selection,
    standard_catpart_with_numeric_entity_value_pair,
    standard_catpart_with_repeated_reference_schema_selection,
};
use crate::CatiaCodec;

#[test]
fn inline_entity_and_object_records_pair_by_extent_and_cardinality() {
    let mut entity = vec![0x7c, 0x05, 12, 0, 0, 0, 0x03, 0xea];
    entity.extend_from_slice(&1_u32.to_le_bytes());
    let graph_offset = entity.len() + 1;
    entity.push(0xde);
    entity.extend(object_graph_from_records(&[inline_object_graph_record(&[
        0x00, 0x90, 0x81, 0x81, 0x00,
    ])]));

    let native = crate::native::CatiaNative::decode(&entity);
    let graph = native
        .object_graphs
        .iter()
        .find(|graph| graph.byte_offset == u64_from_index(graph_offset))
        .expect("entity-paired graph");
    assert_eq!(graph.records.len(), 1);
    assert_eq!(graph.records[0].entity_id(), Some(1));
    let record = native
        .entity_records
        .iter()
        .find(|record| record.object_graph == graph.id)
        .expect("paired inline entity");
    assert_eq!(record.inline_body(), Some(&[0x03, 0xea, 1, 0, 0, 0][..]));
    assert_eq!(record.object_record, graph.records[0].id);
}

#[test]
fn native_namespace_retains_and_validates_definition_schema_selections() {
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])];
    let mut bytes =
        entity_table_record_with_definition_and_value(1, &[0, 0, 0x32, 4, 0, 0, 0], &[]);
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));
    bytes.extend(catalog_stream(&[
        "CATCatalogManager",
        "catalogManager",
        "catalogLinks",
        "",
        "Sketch",
    ]));

    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(
        native.entity_records[0].definition_schema_selections,
        [crate::native::CatiaDefinitionSchemaSelection {
            offset: 2,
            ordinal: 4,
            entry: Some(native.catalogs[0].entries[4].id.clone()),
            name: Some("Sketch".to_string()),
        }]
    );

    let mut malformed = native;
    malformed.entity_records[0].definition_schema_selections[0].name = Some("Pad".to_string());
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed definition-schema view");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_namespace_retains_and_validates_repeated_reference_suffixes() {
    let payload = [
        0xb0, 0x83, 0x81, 0xbc, 0x81, 0xbe, 0x81, 0xb1, 0x83, 0x81, 0xbc, 0x81, 0xbe, 0xd1, 0x80,
        0xfe,
    ];
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &payload)];
    let native = crate::native::CatiaNative::decode(&entity_backed_object_graph(&records, &[1]));
    let suffix = native.object_graphs[0].records[0]
        .repeated_reference_suffix()
        .expect("repeated reference suffix");
    assert_eq!(suffix.schema_preamble, None);
    assert_eq!(suffix.repeated_references, [60, 62]);
    assert_eq!(suffix.terminal_reference, 49);

    let error = load_tampered_object_record(&native, |record| {
        record["repeated_reference_suffix"]["terminal_reference"] = serde_json::json!(50);
    });
    assert!(error.contains("repeated_reference_suffix"), "{error}");
}

/// Store `native`, rewrite its first object record with `tamper`, and return
/// the message of the load failure the rewritten namespace produces.
fn load_tampered_object_record(
    native: &crate::native::CatiaNative,
    tamper: impl FnOnce(&mut serde_json::Value),
) -> String {
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store object records");
    let arena = namespace
        .arenas_mut()
        .get_mut("object_graph_records")
        .expect("object-record arena");
    let mut record = serde_json::to_value(&arena[0]).unwrap();
    tamper(&mut record);
    arena[0] = serde_json::from_value(record).unwrap();
    match crate::native::CatiaNative::load(&namespace) {
        Ok(_) => panic!("tampered object record loaded"),
        Err(error) => error.to_string(),
    }
}

#[test]
fn native_namespace_rejects_an_object_record_subtype_disagreeing_with_its_payload() {
    let payload = [
        0xb0, 0x83, 0x81, 0xbc, 0x81, 0xbe, 0x81, 0xb1, 0x83, 0x81, 0xbc, 0x81, 0xbe, 0xd1, 0x80,
        0xfe,
    ];
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &payload)];
    let native = crate::native::CatiaNative::decode(&entity_backed_object_graph(&records, &[1]));
    assert_eq!(
        native.object_graphs[0].records[0].subtype(),
        crate::object_graph::PayloadSubtype::AtomVector
    );

    let error = load_tampered_object_record(&native, |record| {
        record["subtype"] = serde_json::json!("Empty");
    });
    assert!(error.contains("subtype"), "{error}");
}

#[test]
fn native_namespace_resolves_and_validates_repeated_reference_schema_selections() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_repeated_reference_schema_selection(),
    );
    let selection = native.object_graphs[0].records[0]
        .repeated_reference_schema_selection
        .as_ref()
        .expect("reference schema selection");
    assert_eq!(
        selection.order,
        crate::native::CatiaRepeatedReferenceSchemaOrder::BlobThenSchema
    );
    assert_eq!(selection.ordinal, 4);
    assert_eq!(selection.offset, 67);
    assert_eq!(selection.name.as_deref(), Some("TargetSchema"));
    assert!(selection.entry.is_some());

    let mut malformed = native;
    malformed.object_graphs[0].records[0]
        .repeated_reference_schema_selection
        .as_mut()
        .expect("reference schema selection")
        .name = Some("WrongSchema".to_string());
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed reference-schema view");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_namespace_retains_and_validates_complete_entity_numeric_pairs() {
    let value = [
        0x91, 0x84, 0xe8, 0xe4, 0x07, 0x37, 0x83, 0x81, 0xe6, 0, 0, 0, 0, 0, 0, 0x12, 0x40, 0xe8,
        0xfe, 0xfe,
    ];
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])];
    let mut bytes = entity_table_record_with_value(1, &value);
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));

    let native = crate::native::CatiaNative::decode(&bytes);
    let pair = native.entity_records[0]
        .numeric_pair()
        .expect("complete numeric pair");
    assert_eq!(
        pair.slots,
        [
            crate::entity_table::NumericPairSlot::Binary64 {
                bits: 4.5_f64.to_bits(),
                offset: 8,
            },
            crate::entity_table::NumericPairSlot::ZeroLiteral { offset: 17 },
        ]
    );

    let mut wire = serde_json::to_value(&native.entity_records[0]).unwrap();
    wire["numeric_pair"]["slots"][0] =
        serde_json::to_value(crate::entity_table::NumericPairSlot::ZeroLiteral { offset: 8 })
            .unwrap();
    assert!(
        serde_json::from_value::<crate::native::entity_record::CatiaEntityRecord>(wire).is_err()
    );
}

#[test]
fn decode_reports_complete_numeric_entity_value_pairs_separately_from_packets() {
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_numeric_entity_value_pair()),
            &DecodeOptions::default(),
        )
        .expect("decode complete numeric entity-value pair");

    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NUMERIC_ENTITY_VALUE_PAIR_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NUMERIC_ENTITY_VALUE_PACKET_COUNT.as_str()
        ),
        0
    );
    assert!(decoded.report().losses.iter().any(|loss| {
        loss.message
            .contains("1 complete numeric entity-value pair(s)")
            && loss
                .message
                .contains("0 embedded numeric entity-value packet(s)")
    }));
}

#[test]
fn native_namespace_retains_and_validates_complete_entity_reference_signatures() {
    let value = [
        0x32, 3, 0, 0, 0, 0x82, 0xe8, 0xe0, 0x0a, 0x37, 0x85, 0x81, b'2', b'(', b'E', b')', 0xfe,
        0x32, 4, 0, 0, 0, 0x82, 0xe9, 0xe0, 0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe,
    ];
    let records = [
        object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe]),
        object_graph_record(&[0x04, 0x01, 0x82, 0x81], &[0xfe]),
        object_graph_record(&[0x04, 0x01, 0x83, 0x81], &[0xfe]),
    ];
    let mut bytes = entity_table_record_with_value(1, &value);
    bytes.extend(entity_table_record_with_value(2, &value));
    bytes.extend(entity_table_record_with_definition_and_value(
        3,
        &[0x01],
        &[0xfe],
    ));
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));

    let native = crate::native::CatiaNative::decode(&bytes);
    let signature = native.entity_records[0]
        .reference_signature
        .as_ref()
        .expect("complete reference signature");
    assert_eq!(signature.production.first_reference(), 3);
    assert_eq!(signature.first_entity.entity_id(), 3);
    assert_eq!(
        signature.first_entity.entity(),
        Some(native.entity_records[2].id.as_str())
    );
    assert!(!signature.first_entity.is_null());
    assert_eq!(signature.production.second_reference(), 4);
    assert_eq!(signature.second_entity.entity_id(), 4);
    assert!(signature.second_entity.entity().is_none());
    assert!(signature.second_entity.is_null());
    assert_eq!(signature.production.second_reference_offset(), 17);
    assert_eq!(signature.production.signature(), "2(E)");
    assert_eq!(signature.production.signature_offset(), 12);
    let [cohort] = native.reference_signature_cohorts.as_slice() else {
        panic!("one reference-signature cohort");
    };
    let graph_key = cohort
        .parent
        .split_once('#')
        .expect("object graph identity")
        .1;
    assert_eq!(
        cohort.id,
        format!("catia:outer:reference-signature-cohort#{graph_key}:00000000")
    );
    assert_eq!(cohort.ordinal, 0);
    assert_eq!(cohort.first_reference(), 3);
    assert_eq!(cohort.second_reference(), 4);
    assert!(cohort.schema_selection.is_none());
    assert_eq!(
        cohort.members,
        [
            native.entity_records[0].id.clone(),
            native.entity_records[1].id.clone()
        ]
    );

    let mut file = standard_catpart();
    file.splice(16..16, bytes.clone());
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode reference-signature incidences");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_COUNT.as_str()
        ),
        2
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_PREFIX_ATOM_2_COUNT.as_str()
        ),
        2
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_PREFIX_ATOM_35_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_COHORT_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_MULTI_MEMBER_REFERENCE_SIGNATURE_COHORT_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_COHORT_MEMBER_COUNT.as_str()
        ),
        2
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_SCHEMA_SELECTED_REFERENCE_SIGNATURE_COHORT_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_INSTRUCTION_COUNT.as_str()
        ),
        8
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_REFERENCE_SIGNATURE_TOKEN_COUNT.as_str()
        ),
        8
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RESOLVED_REFERENCE_SIGNATURE_ENTITY_COUNT.as_str()
        ),
        2
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NULL_REFERENCE_SIGNATURE_ENTITY_COUNT.as_str()
        ),
        2
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_UNRESOLVED_REFERENCE_SIGNATURE_ENTITY_COUNT.as_str()
        ),
        0
    );

    let mut malformed = native;
    let second_entity = malformed.entity_records[0]
        .reference_signature
        .as_ref()
        .expect("complete reference signature")
        .second_entity
        .clone();
    let next_entity_id = second_entity.entity_id() + 1;
    malformed.entity_records[0]
        .reference_signature
        .as_mut()
        .expect("complete reference signature")
        .second_entity = second_entity.with_entity_id(next_entity_id);
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed reference-signature view");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed = crate::native::CatiaNative::decode(&bytes);
    malformed.reference_signature_cohorts[0].members.clear();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed reference-signature cohort");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    crate::native::CatiaNative::decode(&bytes)
        .store(&mut namespace)
        .expect("store reference-signature cohort");
    let mut cohorts: Vec<serde_json::Value> =
        namespace.arena_as("reference_signature_cohorts").unwrap();
    cohorts[0]["second_reference"] = serde_json::json!(6);
    namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "reference_signature_cohorts",
            &cohorts,
        )
        .unwrap();
    let error = crate::native::CatiaNative::load(&namespace)
        .expect_err("cohort second_reference not following its first");
    assert!(error.to_string().contains("second_reference"), "{error}");
}

#[test]
fn native_namespace_tokenizes_and_validates_complete_entity_values() {
    let mut value = vec![0x32, 4, 0, 0, 0, 0x87, 0xe6];
    value.extend_from_slice(&12.5_f64.to_bits().to_le_bytes());
    value.extend_from_slice(&[0x87, 0xe8, 0xfe]);
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])];
    let mut bytes = entity_table_record_with_value(1, &value);
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));

    let native = crate::native::CatiaNative::decode(&bytes);
    let fields = native.entity_records[0].value_fields();
    assert_eq!(
        fields,
        [
            crate::value_block::ValueField::SchemaSelector {
                ordinal: 4,
                offset: 0,
            },
            crate::value_block::ValueField::Binary64 {
                bits: 12.5_f64.to_bits(),
                offset: 5,
            },
            crate::value_block::ValueField::Marker {
                code: 0xe8,
                offset: 15,
            },
            crate::value_block::ValueField::Terminator { offset: 17 },
        ]
    );
}

#[test]
fn native_namespace_resolves_and_validates_entity_value_schema_selections() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_entity_value_schema_selection());
    let selection = &native.entity_records[0].value_schema_selections[0];
    assert_eq!(selection.ordinal, 4);
    assert_eq!(selection.offset, 0);
    assert_eq!(selection.name, "TargetValue");
    assert!(!selection.entry.is_empty());
    assert_eq!(
        selection.encoded_value,
        [
            crate::value_block::ValueField::Binary64 {
                bits: 12.5_f64.to_bits(),
                offset: 5,
            },
            crate::value_block::ValueField::Opcode {
                code: 0xe8,
                offset: 15,
            },
            crate::value_block::ValueField::Atom {
                value: 3851,
                width: 2,
                offset: 16,
            },
            crate::value_block::ValueField::Separator { offset: 18 },
            crate::value_block::ValueField::Terminator { offset: 19 },
            crate::value_block::ValueField::Terminator { offset: 20 },
        ]
    );
    assert_eq!(
        selection.packets,
        [crate::entity_table::EntityValuePacket::Compact {
            offset: 15,
            value_selector: 0x0ae0,
        }]
    );

    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed entity-value schema view");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };

    let mut wrong_name = native.clone();
    wrong_name.entity_records[0].value_schema_selections[0].name = "WrongValue".to_string();
    assert_rejected(wrong_name);

    let mut wrong_packet = native;
    let crate::entity_table::EntityValuePacket::Compact { value_selector, .. } =
        &mut wrong_packet.entity_records[0].value_schema_selections[0].packets[0]
    else {
        panic!("compact value packet");
    };
    *value_selector += 1;
    assert_rejected(wrong_packet);
}

#[test]
fn native_namespace_types_and_validates_named_parameter_values() {
    use crate::native::{
        CatiaEntityEvaluation, CatiaEntityEvaluationEncoding, CatiaEntitySuffixPayload,
        CatiaEntitySuffixTrailer, CatiaEntitySuffixValue,
    };

    let scalar = 35.0_f64.to_bits();
    let mut scalar_suffix = vec![0x85, 0x96, 0x82, 0x6a, 0xe6];
    scalar_suffix.extend_from_slice(&scalar.to_le_bytes());
    scalar_suffix.extend_from_slice(&[0x81, 0x52]);
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_parameter_value(&scalar_suffix));
    let parameter = native.entity_records[0]
        .parameter_value()
        .expect("complete named parameter value");
    assert_eq!(parameter.name.value, "Thickness");
    assert_eq!(parameter.binding.value, "#1_ /2");
    assert_eq!(
        parameter.evaluation,
        CatiaEntityEvaluation::Scalar { bits: scalar }
    );
    assert_eq!(
        native.entity_records[0].suffix_value().cloned(),
        Some(CatiaEntitySuffixValue {
            prefix_atoms: [5, 22, 2],
            prefix_atom_widths: [1, 1, 1].into(),
            prefix_code: 0x6a,
            payload: CatiaEntitySuffixPayload::Evaluation {
                opcode_offset: 4,
                evaluation: CatiaEntityEvaluation::Scalar { bits: scalar },
                encoding: CatiaEntityEvaluationEncoding::Direct,
            },
            trailer: CatiaEntitySuffixTrailer::Token8152,
        })
    );
    assert_eq!(parameter.evaluation_opcode_offset, 4);

    let unit = crate::native::CatiaNative::decode(&standard_catpart_with_parameter_value(&[
        0x85, 0x96, 0x82, 0x6a, 0xe7, 0x81, 0x52,
    ]));
    assert_eq!(
        unit.entity_records[0]
            .parameter_value()
            .expect("complete unit-literal parameter")
            .evaluation,
        CatiaEntityEvaluation::UnitLiteral
    );

    let mut malformed_offset = native.clone();
    malformed_offset.entity_records[0]
        .parameter_value_mut()
        .expect("complete named parameter value")
        .evaluation_opcode_offset += 1;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed_offset
        .store(&mut namespace)
        .expect("store malformed named parameter offset");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed = native;
    malformed.entity_records[0]
        .parameter_value_mut()
        .expect("complete named parameter value")
        .name
        .value = "changed".to_string();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed parameter value");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_namespace_binds_two_definition_value_chains() {
    use crate::native::{
        CatiaDefinitionChainValue, CatiaEntityEvaluation, CatiaEntitySchemaValue,
        CatiaEntitySuffixSchemaValue,
    };

    let bits = 12.5_f64.to_bits();
    let mut suffix = vec![0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0xe6];
    suffix.extend_from_slice(&bits.to_le_bytes());
    suffix.extend_from_slice(&[0x81, 0x49]);
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_definition_chain_value(&suffix)),
            &DecodeOptions::default(),
        )
        .expect("decode definition-chain evaluation");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_EVALUATION_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_STRUCTURALLY_OWNED_DEFINITION_CHAIN_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_DEFINITION_CHAIN_VALUE_OWNER_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_EVALUATED_DEFINITION_CHAIN_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_UNSET_DEFINITION_CHAIN_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_STRUCTURALLY_OWNED_DEFINITION_CHAIN_EVALUATION_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_DEFINITION_CHAIN_EVALUATION_OWNER_COUNT.as_str()
        ),
        0
    );
    let mut native = crate::native::CatiaNative::load(
        decoded.ir().native.namespace("catia").expect("namespace"),
    )
    .expect("load definition-chain evaluation");
    assert_eq!(
        native.entity_records[0].definition_chain_value(),
        Some(&CatiaDefinitionChainValue {
            selector: CatiaEntitySchemaValue {
                offset: native.entity_records[0].definition_schema_selections[0].offset,
                ordinal: native.entity_records[0].definition_schema_selections[0].ordinal,
                entry: native.catalogs[0].entries[4].id.clone(),
                value: "FeatureFEDGE".to_string(),
            },
            role: CatiaEntitySchemaValue {
                offset: native.entity_records[0].definition_schema_selections[1].offset,
                ordinal: native.entity_records[0].definition_schema_selections[1].ordinal,
                entry: native.catalogs[0].entries[5].id.clone(),
                value: "Real".to_string(),
            },
            value: CatiaEntitySuffixSchemaValue::Evaluation {
                opcode_offset: 8,
                evaluation: CatiaEntityEvaluation::Scalar { bits },
            },
        })
    );
    assert_eq!(
        native.design_objects[0].definition_chain_values,
        [native.entity_records[0].id.clone()]
    );

    let mut malformed_ownership = native.clone();
    malformed_ownership.design_objects[0]
        .definition_chain_values
        .clear();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed_ownership
        .store(&mut namespace)
        .expect("store malformed definition-chain ownership");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    native.entity_records[0]
        .definition_chain_value_mut()
        .expect("definition-chain evaluation")
        .role
        .value = "changed".to_string();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store malformed definition-chain evaluation");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let wrong_selector =
        crate::native::CatiaNative::decode(&standard_catpart_with_definition_chain_value(&[
            0x84, 0x88, 0x82, 0x32, 5, 0, 0, 0, 0xe7,
        ]));
    assert!(wrong_selector.entity_records[0]
        .definition_chain_value()
        .is_none());

    let atom = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_definition_chain_value(&[
                0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0x87,
            ])),
            &DecodeOptions::default(),
        )
        .expect("decode definition-chain atom");
    assert_eq!(
        wire::coverage_count(
            atom.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            atom.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_ATOM_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            atom.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_EVALUATION_COUNT.as_str()
        ),
        0
    );
    let atom_native =
        crate::native::CatiaNative::load(atom.ir().native.namespace("catia").expect("namespace"))
            .expect("load definition-chain atom");
    assert_eq!(
        atom_native.entity_records[0]
            .definition_chain_value()
            .map(|value| &value.value),
        Some(&CatiaEntitySuffixSchemaValue::Atom { value: 7 })
    );

    for (payload, coverage) in [
        (0xe8, "decoded_definition_chain_evaluation_count"),
        (0x37, "decoded_definition_chain_separator_count"),
    ] {
        let decoded = CatiaCodec
            .decode(
                &mut Cursor::new(standard_catpart_with_definition_chain_value(&[
                    0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, payload,
                ])),
                &DecodeOptions::default(),
            )
            .expect("decode definition-chain state");
        assert_eq!(
            wire::coverage(decoded.report())
                .get(coverage)
                .copied()
                .unwrap_or(0),
            1
        );
    }

    let nested = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_definition_chain_value(&[
                0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0x32, 5, 0, 0, 0,
            ])),
            &DecodeOptions::default(),
        )
        .expect("decode nested definition-chain selector");
    assert_eq!(
        wire::coverage_count(
            nested.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_SCHEMA_SELECTOR_COUNT.as_str()
        ),
        1
    );
    let nested_native =
        crate::native::CatiaNative::load(nested.ir().native.namespace("catia").expect("namespace"))
            .expect("load nested definition-chain selector");
    assert_eq!(
        nested_native.entity_records[0]
            .definition_chain_value()
            .map(|value| &value.value),
        Some(&CatiaEntitySuffixSchemaValue::SchemaSelector {
            offset: 8,
            ordinal: 5,
            resolution: Some(crate::native::CatiaDesignClass {
                entry: nested_native.catalogs[0].entries[5].id.clone(),
                name: "Real".to_string(),
            }),
        })
    );
}

#[test]
fn definition_chain_values_transfer_only_as_explicit_formula_inputs() {
    let bits = 12.5_f64.to_bits();
    let mut suffix = vec![0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0xe6];
    suffix.extend_from_slice(&bits.to_le_bytes());
    suffix.extend_from_slice(&[0x81, 0x49]);
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_definition_chain_value(&suffix)),
            &DecodeOptions::default(),
        )
        .expect("decode standalone definition-chain value");
    assert!(decoded.ir().model.parameters.is_empty());
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_DEFINITION_CHAIN_PARAMETER_COUNT.as_str()
        ),
        0
    );

    let mut native =
        crate::native::CatiaNative::decode(&standard_catpart_with_definition_chain_value(&[
            0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0xe6, 0, 0, 0, 0, 0, 0, 0, 0,
        ]));
    let parameter_entity = native.entity_records[0].clone();
    native.entity_records[0].object_production = Some(
        crate::native::entity_record::CatiaEntityObjectProduction::RelationProgramInstance(
            crate::native::CatiaRelationProgramInstance {
                framing: crate::native::CatiaRelationProgramInstanceFraming::Lead12 {
                    context_entity: crate::native::CatiaEntityReference::Unresolved {
                        entity_id: 0,
                    },
                },
                program_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                repeated_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                reference_incidences: Vec::new(),
                relation_expression: None,
                parameter_dependencies: Vec::new(),
                inputs: Some(vec![crate::native::CatiaRelationProgramInput {
                    parameter: "#1_".to_string(),
                    value_type: "Real".to_string(),
                    entity: crate::native::CatiaEntityReference::resolved_or_unresolved(
                        parameter_entity.entity_id,
                        Some(parameter_entity.id.clone()),
                        Some("param".to_string()),
                    ),
                }]),
            },
        ),
    );
    let mut relation_ir = CadIr::empty();
    let relation_transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut relation_ir,
            &native,
            &mut Annotations::default(),
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    assert_eq!(relation_transfer.definition_chain_parameter_count, 1);
    assert_eq!(relation_transfer.relation_program_parameter_count, 1);
    let [parameter] = relation_ir.model.parameters.as_slice() else {
        panic!("expected the consumed definition-chain input");
    };
    assert_eq!(parameter.name, "Parameter#1");
    assert_eq!(parameter.properties["source_name"], "");
    assert_eq!(parameter.properties["value_type"], "Real");
    assert_eq!(
        parameter.properties["catia_definition_evaluation_opcode_offset"],
        "8"
    );
}

#[test]
fn design_objects_retain_definition_chain_values_in_field_order() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_two_definition_chain_values());
    assert_eq!(native.design_objects.len(), 1);
    assert_eq!(
        native.design_objects[0].definition_chain_values,
        native
            .entity_records
            .iter()
            .map(|entity| entity.id.clone())
            .collect::<Vec<_>>()
    );

    let mut reversed = native;
    reversed.design_objects[0].definition_chain_values.reverse();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    reversed
        .store(&mut namespace)
        .expect("store misordered definition-chain ownership");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn literal_owner_slots_remain_unassigned() {
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_unassigned_definition_chain_value()),
            &DecodeOptions::default(),
        )
        .expect("decode literal owner slot");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_DEFINITION_CHAIN_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_DEFINITION_CHAIN_VALUE_OWNER_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_UNASSIGNED_DEFINITION_CHAIN_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_UNASSIGNED_DEFINITION_CHAIN_EVALUATION_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_UNASSIGNED_OBJECT_OWNER_SLOT_COUNT.as_str()
        ),
        1
    );

    let native = crate::native::CatiaNative::load(
        decoded.ir().native.namespace("catia").expect("namespace"),
    )
    .expect("load literal owner slot");
    let record = &native.object_graphs[0].records[0];
    assert_eq!(
        record.owner,
        Some(crate::native::CatiaObjectOwner::UnassignedLiteral(66))
    );
    assert!(record.design_object.is_none());
    assert!(native.design_objects.is_empty());

    let mut malformed = native.clone();
    malformed.object_graphs[0].records[0].owner =
        Some(crate::native::CatiaObjectOwner::UnassignedLiteral(67));
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed literal owner slot");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_namespace_binds_and_validates_definition_values() {
    use crate::native::{
        CatiaDefinitionValue, CatiaEntityEvaluation, CatiaEntityEvaluationEncoding,
        CatiaEntitySchemaValue, CatiaEntitySuffixPayload,
    };

    let bits = 12.5_f64.to_bits();
    let mut suffix = vec![0xd1, 0x53, 0x96, 0x82, 0xa6, 0xe6];
    suffix.extend_from_slice(&bits.to_le_bytes());
    let definition = [0x00, 0x08, 0x32, 4, 0, 0, 0];
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_definition_value(
                &definition,
                &[0xfe],
                &suffix,
            )),
            &DecodeOptions::default(),
        )
        .expect("decode definition-bound value");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_DEFINITION_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_OWNED_DEFINITION_VALUE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_DEFINITION_VALUE_OWNER_COUNT.as_str()
        ),
        0
    );
    let mut native = crate::native::CatiaNative::load(
        decoded.ir().native.namespace("catia").expect("namespace"),
    )
    .expect("load definition-bound value");
    assert_eq!(
        native.entity_records[0].definition_value(),
        Some(&CatiaDefinitionValue {
            definition: CatiaEntitySchemaValue {
                offset: native.entity_records[0].definition_schema_selections[0].offset,
                ordinal: native.entity_records[0].definition_schema_selections[0].ordinal,
                entry: native.catalogs[0].entries[4].id.clone(),
                value: "Thickness".to_string(),
            },
            payload: CatiaEntitySuffixPayload::Evaluation {
                opcode_offset: 5,
                evaluation: CatiaEntityEvaluation::Scalar { bits },
                encoding: CatiaEntityEvaluationEncoding::Direct,
            },
            schema_selection: None,
        })
    );
    assert_eq!(
        native.design_objects[0].definition_values,
        [native.entity_records[0].id.clone()]
    );
    assert_eq!(
        native.object_graphs[0].records[0].storage_record(),
        Some(native.object_graphs[0].records[0].id.as_str())
    );
    assert_eq!(
        native.object_graphs[0].records[0].storage_design_object(),
        Some(native.design_objects[0].id.as_str())
    );

    let mut malformed_storage = native.clone();
    malformed_storage.object_graphs[0].records[0]
        .storage
        .as_mut()
        .expect("decoded storage role")
        .record = None;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed_storage
        .store(&mut namespace)
        .expect("store malformed storage link");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed_ownership = native.clone();
    malformed_ownership.design_objects[0]
        .definition_values
        .clear();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed_ownership
        .store(&mut namespace)
        .expect("store malformed definition-value ownership");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let definition_value = native.entity_records[0]
        .definition_value_mut()
        .expect("definition-bound value");
    definition_value.payload = CatiaEntitySuffixPayload::Evaluation {
        opcode_offset: 5,
        evaluation: CatiaEntityEvaluation::Unset,
        encoding: CatiaEntityEvaluationEncoding::Direct,
    };
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store malformed definition value");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let control = crate::native::CatiaNative::decode(&standard_catpart_with_definition_value(
        &definition,
        &[0xfe],
        &[0xd1, 0x67, 0x88, 0x81, 0xbd, 0xe8, 0x81, 0x49],
    ));
    assert!(matches!(
        control.entity_records[0]
            .definition_value()
            .expect("definition-bound control")
            .payload,
        CatiaEntitySuffixPayload::Evaluation {
            evaluation: crate::native::CatiaEntityEvaluation::ZeroLiteral,
            ..
        }
    ));

    let schema_selected =
        crate::native::CatiaNative::decode(&standard_catpart_with_definition_value(
            &definition,
            &[0xfe],
            &[0x84, 0x96, 0x82, 0x32, 4, 0, 0, 0, 0xe7, 0x81, 0x49],
        ));
    let definition_value = schema_selected.entity_records[0]
        .definition_value()
        .expect("definition-bound schema-selected value");
    assert!(matches!(
        definition_value.payload,
        CatiaEntitySuffixPayload::SchemaSelected { selector: 4, .. }
    ));
    assert_eq!(
        definition_value
            .schema_selection
            .as_ref()
            .expect("resolved suffix schema")
            .name,
        "Thickness"
    );

    for (definition, value) in [
        (
            vec![0x00, 0x08, 0x32, 4, 0, 0, 0, 0x32, 4, 0, 0, 0],
            vec![0xfe],
        ),
        (definition.to_vec(), vec![0x80, 0xfe]),
    ] {
        let native = crate::native::CatiaNative::decode(&standard_catpart_with_definition_value(
            &definition,
            &value,
            &suffix,
        ));
        assert_eq!(native.entity_records[0].definition_value(), None);
    }
}

#[test]
fn named_parameter_value_requires_the_complete_finite_suffix() {
    let nonfinite = f64::NAN.to_bits();
    let mut suffix = vec![0x85, 0x96, 0x82, 0x6a, 0xe6];
    suffix.extend_from_slice(&nonfinite.to_le_bytes());
    suffix.extend_from_slice(&[0x81, 0x52]);

    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_parameter_value(&suffix));
    assert!(native.entity_records[0].suffix_value().is_none());
    assert!(native.entity_records[0].parameter_value().is_none());

    let control = crate::native::CatiaNative::decode(&standard_catpart_with_parameter_value(&[
        0x85, 0x96, 0x82, 0x6a, 0xe8, 0x81, 0x52,
    ]));
    assert!(matches!(
        control.entity_records[0]
            .suffix_value()
            .as_ref()
            .expect("complete zero-literal suffix")
            .payload,
        crate::native::CatiaEntitySuffixPayload::Evaluation {
            evaluation: crate::native::CatiaEntityEvaluation::ZeroLiteral,
            ..
        }
    ));
    assert_eq!(
        control.entity_records[0]
            .parameter_value()
            .map(|value| value.evaluation.clone()),
        Some(crate::native::CatiaEntityEvaluation::ZeroLiteral)
    );
}

#[test]
fn native_retains_and_validates_typed_schema_selector_incidences() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_formula_relation(4, false));
    let expression_entity = &native.entity_records[1];
    let expression = expression_entity
        .relation_expression()
        .expect("complete relation expression");
    assert_eq!(
        (expression.expression.offset, expression.expression.ordinal),
        (
            expression_entity.value_schema_selections[1].offset,
            expression_entity.value_schema_selections[1].ordinal,
        )
    );
    let parameter_entity = &native.entity_records[2];
    let parameter = parameter_entity
        .parameter_value()
        .expect("complete named parameter");
    assert_eq!(
        (parameter.name.offset, parameter.name.ordinal),
        (
            parameter_entity.value_schema_selections[0].offset,
            parameter_entity.value_schema_selections[0].ordinal,
        )
    );
    assert_eq!(
        (parameter.binding.offset, parameter.binding.ordinal),
        (
            parameter_entity.value_schema_selections[1].offset,
            parameter_entity.value_schema_selections[1].ordinal,
        )
    );

    let mut malformed = native;
    malformed.entity_records[2]
        .parameter_value_mut()
        .expect("complete named parameter")
        .name
        .offset = u64::MAX;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut namespace)
        .expect("store malformed typed schema incidence");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn entity_value_schema_selection_excludes_a_packet_crossing_its_boundary() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_crossing_entity_value_packet());
    let packets = {
        let fields = native.entity_records[0].value_fields();
        native.entity_records[0].value_packets(&fields)
    };
    assert_eq!(packets.len(), 1);
    assert_eq!(native.entity_records[0].value_schema_selections.len(), 2);
    assert!(native.entity_records[0]
        .value_schema_selections
        .iter()
        .all(|selection| selection.packets.is_empty()));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store crossing packet fixture");
    crate::native::CatiaNative::load(&namespace).expect("validate canonical packet ownership");
}

/// The minimal `7C05` frame the parser accepts carries four empty byte
/// vectors, so `empty_nested` names a producible record rather than an
/// unreachable one.
#[test]
fn the_minimal_parsed_entity_frame_is_the_empty_nested_body() {
    let frame = entity_table_record_with_definition_and_value(1, &[], &[]);
    let mut bytes = frame.clone();
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&[object_graph_record(
        &[0x04, 0x01, 0x81, 0x81],
        &[0xfe],
    )]));

    let native = crate::native::CatiaNative::decode(&bytes);
    let [record] = native.entity_records.as_slice() else {
        panic!("one minimal entity record");
    };
    assert_eq!(
        record.body,
        crate::native::CatiaEntityRecordBody::empty_nested()
    );
    assert_eq!(record.byte_len(), 24);
    assert_eq!(
        cadmpeg_core::decode::index_from_u64(record.byte_len()).expect("fixture length fits usize"),
        frame.len()
    );
}

#[test]
fn derived_definition_schema_selections_match_decoded_record() {
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])];
    let mut bytes =
        entity_table_record_with_definition_and_value(1, &[0, 0, 0x32, 4, 0, 0, 0], &[]);
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));
    bytes.extend(catalog_stream(&[
        "CATCatalogManager",
        "catalogManager",
        "catalogLinks",
        "",
        "Sketch",
    ]));
    let native = crate::native::CatiaNative::decode(&bytes);
    let record = &native.entity_records[0];
    let selectors =
        crate::entity_table::parse_definition_schema_selectors(record.definition_prefix());
    let catalog = native.catalogs.first();
    let admitted = crate::test_support::with_service_context(|ctx| {
        super::super::definition_schema_selections(ctx, &selectors, catalog)
    })
    .expect("derive the definition schema selections");
    assert_eq!(admitted, record.definition_schema_selections);

    let entry = &catalog.expect("fixture catalog").entries[4];
    let class_text = u64::try_from(entry.id.len() + "Sketch".len()).expect("fixture text fits");
    let admitted = crate::test_support::with_retained_limit(class_text, |ctx| {
        super::super::definition_schema_selections(ctx, &selectors, catalog)
    })
    .expect("one class copy fits its own length");
    assert_eq!(admitted, record.definition_schema_selections);
    let error = crate::test_support::with_retained_limit(class_text - 1, |ctx| {
        super::super::definition_schema_selections(ctx, &selectors, catalog)
    })
    .expect_err("the class copy is charged before it is made");
    assert!(matches!(
        error,
        cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::RetainedBytes
                && limit.operation == "retain CATIA schema class text"
    ));
}

#[test]
fn entities_sharing_a_reference_signature_form_one_cohort() {
    let value = [
        0x32, 3, 0, 0, 0, 0x82, 0xe8, 0xe0, 0x0a, 0x37, 0x85, 0x81, b'2', b'(', b'E', b')', 0xfe,
        0x32, 4, 0, 0, 0, 0x82, 0xe9, 0xe0, 0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe,
    ];
    let records = [
        object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe]),
        object_graph_record(&[0x04, 0x01, 0x82, 0x81], &[0xfe]),
        object_graph_record(&[0x04, 0x01, 0x83, 0x81], &[0xfe]),
    ];
    let mut bytes = entity_table_record_with_value(1, &value);
    bytes.extend(entity_table_record_with_value(2, &value));
    bytes.extend(entity_table_record_with_definition_and_value(
        3,
        &[0x01],
        &[0xfe],
    ));
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));
    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.reference_signature_cohorts.len(), 1);
    let cohorts = super::super::derive_reference_signature_cohorts(&native.entity_records);
    assert_eq!(cohorts, native.reference_signature_cohorts);
}

#[test]
fn schema_selector_value_reads_as_one_selector_field() {
    let value = [0x32, 4, 0, 0, 0];
    let records = [object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])];
    let mut bytes = entity_table_record_with_value(1, &value);
    bytes.push(0xde);
    bytes.extend(object_graph_from_records(&records));
    let native = crate::native::CatiaNative::decode(&bytes);
    let record = &native.entity_records[0];
    let fields = record.value_fields();
    assert_eq!(
        fields,
        [crate::value_block::ValueField::SchemaSelector {
            ordinal: 4,
            offset: 0,
        }]
    );
}

#[test]
fn derived_entity_value_selections_match_decoded_record() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_entity_value_schema_selection());
    let record = &native.entity_records[0];
    let catalog = native.catalogs.first();
    let fields = record.value_fields();
    let packets = record.value_packets(&fields);
    let admitted = crate::test_support::with_service_context(|ctx| {
        super::super::entity_value_schema_selections(ctx, &fields, catalog, &packets)
    })
    .expect("derive the entity value schema selections");
    assert_eq!(admitted, record.value_schema_selections);
}

#[test]
fn entity_value_selection_packets_match_a_pairwise_window_filter() {
    use crate::entity_table::EntityValuePacket;
    use crate::value_block::ValueField;

    let catalog = super::super::CatiaCatalog {
        id: "catia:catalog#0".to_string(),
        byte_offset: 0,
        byte_len: 1,
        entries: (0..2)
            .map(|ordinal| super::super::CatiaCatalogEntry {
                id: format!("catia:catalog-entry#{ordinal}"),
                parent: "catia:catalog#0".to_string(),
                ordinal,
                byte_offset: 0,
                value: format!("Schema{ordinal}"),
            })
            .collect(),
    };
    // One field per byte. The selector at 24 names no catalog entry, so the
    // window opened at 12 runs on to the selector at 36.
    let fields = (0..48)
        .map(|offset| match offset {
            0 | 12 | 36 => ValueField::SchemaSelector { ordinal: 1, offset },
            24 => ValueField::SchemaSelector { ordinal: 9, offset },
            _ => ValueField::Opcode { code: 0xe6, offset },
        })
        .collect::<Vec<_>>();
    let mut packets = (0..48)
        .rev()
        .map(|offset| EntityValuePacket::Compact {
            offset,
            value_selector: 0,
        })
        .collect::<Vec<_>>();
    packets.extend(
        (0..48)
            .step_by(5)
            .map(|offset| EntityValuePacket::E9Scalar {
                offset,
                scalar_offset: offset + 6,
                bits: 0,
            }),
    );
    let selections = crate::test_support::with_service_context(|ctx| {
        super::super::entity_value_schema_selections(ctx, &fields, Some(&catalog), &packets)
    })
    .expect("derive the synthetic entity value schema selections");

    let windows = [(1, Some(12)), (13, Some(36)), (37, None)];
    assert_eq!(
        selections
            .iter()
            .map(|selection| selection.offset)
            .collect::<Vec<_>>(),
        [0, 12, 36]
    );
    for (selection, (start, end)) in selections.iter().zip(windows) {
        let pairwise = packets
            .iter()
            .filter(|packet| {
                packet.byte_range().is_some_and(|range| {
                    range.start >= start && end.is_none_or(|end| range.end <= end)
                })
            })
            .cloned()
            .collect::<Vec<_>>();
        assert!(!pairwise.is_empty());
        assert_eq!(selection.packets, pairwise);
    }
}

#[test]
fn derived_repeated_reference_selection_matches_decoded_record() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_repeated_reference_schema_selection(),
    );
    let record = &native.object_graphs[0].records[0];
    let preamble = crate::object_graph::repeated_reference_schema_preamble(&record.payload);
    let catalog = native.catalogs.first();
    let admitted = crate::test_support::with_service_context(|ctx| {
        super::super::repeated_reference_schema_selection(ctx, preamble.as_ref(), catalog)
    })
    .expect("derive the repeated reference schema selection");
    assert_eq!(admitted, record.repeated_reference_schema_selection);
}

#[test]
fn derived_scalar_value_production_matches_decoded_entity() {
    let scalar_suffix = [0x85, 0x96, 0x82, 0x6a, 0xe7, 0x81, 0x52];
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_parameter_value(&scalar_suffix));
    let entity = &native.entity_records[0];
    let fields = entity.value_fields();
    let incidences = super::super::EntityIncidenceIndex::new(
        &native.object_graphs[0].records,
        &entity.object_graph,
    );
    let service = crate::test_support::with_service_context(|ctx| {
        super::super::value_production(ctx, entity, &incidences, &fields)
    })
    .expect("derive the value production");
    assert_eq!(service, entity.value_production);
}

#[test]
fn definition_value_and_chain_value_decode_with_matching_production() {
    let definition = [0x00, 0x08, 0x32, 4, 0, 0, 0];
    let definition_native =
        crate::native::CatiaNative::decode(&standard_catpart_with_definition_value(
            &definition,
            &[0xfe],
            &[0xd1, 0x67, 0x88, 0x81, 0xbd, 0xe8, 0x81, 0x49],
        ));
    let definition_entity = &definition_native.entity_records[0];
    assert!(definition_entity.definition_value().is_some());

    let chain_native =
        crate::native::CatiaNative::decode(&standard_catpart_with_definition_chain_value(&[
            0x84, 0x88, 0x82, 0x32, 4, 0, 0, 0, 0x87,
        ]));
    let chain_entity = &chain_native.entity_records[0];
    assert!(chain_entity.definition_chain_value().is_some());
    let chain_fields = chain_entity.value_fields();
    let incidences = super::super::EntityIncidenceIndex::new(
        &chain_native.object_graphs[0].records,
        &chain_entity.object_graph,
    );
    let service = crate::test_support::with_service_context(|ctx| {
        super::super::value_production(ctx, chain_entity, &incidences, &chain_fields)
    })
    .expect("derive the value production");
    assert_eq!(service, chain_entity.value_production);
}
