// SPDX-License-Identifier: Apache-2.0
//! Native-namespace tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_test_support::wire;

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::Annotations;

use crate::test_support::test_formula::{
    standard_catpart_with_formula_relation, standard_catpart_with_lead54_relation_program_instance,
    standard_catpart_with_lead54_relation_program_instance_class,
    standard_catpart_with_relation_program_instance,
    standard_catpart_with_relation_program_instance_class,
};
use crate::CatiaCodec;

#[test]
fn relation_program_instance_requires_the_complete_identity_frame() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance(1, 1, 1, 2),
    );
    let instance = native.entity_records[1]
        .relation_program_instance()
        .expect("complete instance frame");
    assert!(matches!(
        instance.framing,
        crate::native::CatiaRelationProgramInstanceFraming::Lead12 { .. }
    ));
    assert_eq!(instance.program_entity.entity_id(), 1);
    assert_eq!(
        instance.program_entity.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(instance.program_entity.class_name(), Some("body"));
    assert_eq!(instance.repeated_entity.entity_id(), 1);
    assert_eq!(
        instance.repeated_entity.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(instance.repeated_entity.class_name(), Some("body"));
    assert_eq!(
        instance
            .reference_incidences
            .iter()
            .map(|incidence| incidence.reference.entity_id())
            .collect::<Vec<_>>(),
        [20, 21, 23, 25, 1, 1, 21, 27]
    );
    assert_eq!(
        instance.reference_incidences[4].reference.class_name(),
        Some("body")
    );
    assert_eq!(
        instance.reference_incidences[5].reference.class_name(),
        Some("body")
    );
    assert_eq!(
        instance
            .reference_incidences
            .iter()
            .map(|incidence| incidence.payload_offset)
            .collect::<Vec<_>>(),
        [0, 10, 40, 50, 60, 65, 75, 85]
    );
    assert_eq!(
        instance.relation_expression.as_deref(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(
        instance
            .parameter_dependencies
            .iter()
            .map(|dependency| dependency.symbol.as_str())
            .collect::<Vec<_>>(),
        ["#1_", "#2_", "#2_"]
    );
    assert_eq!(
        instance
            .parameter_dependencies
            .iter()
            .map(|dependency| dependency.source_offset)
            .collect::<Vec<_>>(),
        [19, 23, 28]
    );
    assert!(instance
        .parameter_dependencies
        .iter()
        .all(|dependency| dependency.candidates.is_empty()));
    assert!(instance.inputs.is_none());
    let context = instance
        .lead12_context_entity()
        .expect("lead-12 context entity");
    assert_eq!(context.entity_id(), 1);
    assert_eq!(context.entity(), Some(native.entity_records[0].id.as_str()));
    assert_eq!(context.class_name(), Some("body"));
    assert!(instance.output_entity().is_none());

    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance(2, 1, 3, 2),
    );
    let instance = native.entity_records[1]
        .relation_program_instance()
        .expect("resolved non-expression program");
    assert_eq!(
        instance.program_entity.entity(),
        Some(native.entity_records[1].id.as_str())
    );
    assert!(instance.relation_expression.is_none());
    let context = instance
        .lead12_context_entity()
        .expect("lead-12 context entity");
    assert_eq!(context.entity_id(), 3);
    assert!(context.entity().is_none());

    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance(3, 3, 1, 2),
    );
    let instance = native.entity_records[1]
        .relation_program_instance()
        .expect("unresolved program identity");
    assert!(instance.program_entity.entity().is_none());
    assert_eq!(instance.repeated_entity.entity_id(), 3);
    assert!(instance.repeated_entity.entity().is_none());
    assert!(instance.relation_expression.is_none());

    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance(1, 1, 1, 3),
    );
    assert!(native
        .entity_records
        .iter()
        .all(|entity| entity.relation_program_instance().is_none()));
}

#[test]
fn relation_program_output_selects_only_the_framing_specific_paramout_slot() {
    let lead12 = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance_class(1, 1, 1, 2, "paramout"),
    );
    let lead12_instance = lead12.entity_records[1]
        .relation_program_instance()
        .expect("lead-12 relation-program instance");
    assert_eq!(
        lead12_instance.output_entity(),
        lead12_instance.lead12_context_entity()
    );
    assert_eq!(
        lead12_instance
            .output_entity()
            .and_then(|output| output.class_name()),
        Some("paramout")
    );
    assert!(lead12_instance.lead54_trailing_entity().is_none());
    let lead12_decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_relation_program_instance_class(
                1, 1, 1, 2, "paramout",
            )),
            &DecodeOptions::default(),
        )
        .expect("decode lead-12 paramout relation-program instance");
    assert_eq!(
        wire::coverage_count(
            lead12_decoded.report(),
            crate::coverage::DECODED_RELATION_PROGRAM_OUTPUT_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            lead12_decoded.report(),
            crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_OUTPUT_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            lead12_decoded.report(),
            crate::coverage::DECODED_NULL_RELATION_PROGRAM_OUTPUT_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            lead12_decoded.report(),
            crate::coverage::UNRESOLVED_RELATION_PROGRAM_OUTPUT_COUNT.as_str()
        ),
        0
    );

    let lead12_body = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance_class(1, 1, 1, 2, "body"),
    );
    assert!(lead12_body.entity_records[1]
        .relation_program_instance()
        .expect("lead-12 body relation-program instance")
        .output_entity()
        .is_none());

    let lead54 = crate::native::CatiaNative::decode(
        &standard_catpart_with_lead54_relation_program_instance_class(1, 1, 1, 2, "paramout"),
    );
    let lead54_instance = lead54.entity_records[1]
        .relation_program_instance()
        .expect("lead-54 relation-program instance");
    assert_eq!(
        lead54_instance.output_entity(),
        lead54_instance.lead54_trailing_entity()
    );
    assert_eq!(
        lead54_instance
            .output_entity()
            .and_then(|output| output.class_name()),
        Some("paramout")
    );
    assert!(lead54_instance.lead12_context_entity().is_none());

    let lead54_body = crate::native::CatiaNative::decode(
        &standard_catpart_with_lead54_relation_program_instance_class(1, 1, 1, 2, "body"),
    );
    assert!(lead54_body.entity_records[1]
        .relation_program_instance()
        .expect("lead-54 body relation-program instance")
        .output_entity()
        .is_none());
}

#[test]
fn relation_program_output_entity_serializes_its_class_name() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_relation_program_instance_class(1, 1, 1, 2, "paramout"),
    );
    let wire = serde_json::to_value(super::super::CatiaEntityRecordWire::from(
        native.entity_records[1].clone(),
    ))
    .expect("serialize entity record wire");
    assert_eq!(
        wire["relation_program_instance"]["output_entity"]["class_name"],
        "paramout"
    );
}

#[test]
fn relation_program_inputs_require_complete_unique_signature_bindings() {
    let resolve =
        |signature: &crate::native::CatiaRelationTypeSignature,
         dependencies: &[crate::native::CatiaRelationParameterDependency]| {
            crate::native::resolved_relation_program_inputs(signature, dependencies)
        };
    let signature = crate::native::CatiaRelationTypeSignature {
        inputs: vec![
            crate::native::CatiaRelationTypeInput {
                parameter: "#1_".to_string(),
                input_type: "LENGTH".to_string(),
            },
            crate::native::CatiaRelationTypeInput {
                parameter: "#2_".to_string(),
                input_type: "Real".to_string(),
            },
        ],
        result_type: "Real".to_string(),
    };
    let reference = |entity_id: u32| {
        crate::native::CatiaEntityReference::resolved_or_unresolved(
            entity_id,
            Some(format!("entity-{entity_id}")),
            Some("param".to_string()),
        )
    };
    let dependency =
        |symbol: &str, candidates: Vec<_>| crate::native::CatiaRelationParameterDependency {
            source_offset: 0,
            symbol: symbol.to_string(),
            candidates,
        };
    let complete = vec![
        dependency("#1_", vec![reference(10)]),
        dependency("#1_ /2", vec![reference(10)]),
        dependency("#2_", vec![reference(11)]),
    ];
    let inputs = resolve(&signature, &complete).expect("complete ordered input bindings");
    assert_eq!(
        inputs
            .iter()
            .map(|input| (input.parameter.as_str(), input.entity.entity_id()))
            .collect::<Vec<_>>(),
        [("#1_", 10), ("#2_", 11)]
    );

    let compact_ordinal = vec![
        dependency("#1_", vec![reference(10)]),
        dependency("#1_/2", vec![reference(10)]),
        dependency("#2_", vec![reference(11)]),
    ];
    assert!(resolve(&signature, &compact_ordinal).is_some());

    let zero = crate::native::CatiaRelationTypeSignature {
        inputs: Vec::new(),
        result_type: "Real".to_string(),
    };
    assert_eq!(resolve(&zero, &[]), Some(Vec::new()));
    assert!(resolve(&signature, &[dependency("#1_", vec![reference(10)])]).is_none());
    assert!(resolve(
        &signature,
        &[
            dependency("#1_", vec![reference(10)]),
            dependency("#2_", vec![reference(10)])
        ]
    )
    .is_none());
    assert!(resolve(
        &signature,
        &[
            dependency("#1_", vec![reference(10)]),
            dependency("#1_ /2", vec![reference(12)]),
            dependency("#2_", vec![reference(11)])
        ]
    )
    .is_none());
    assert!(resolve(
        &signature,
        &[
            dependency("#1_", vec![reference(10)]),
            dependency("#1_ /ordinal", vec![reference(10)]),
            dependency("#2_", vec![reference(11)])
        ]
    )
    .is_none());
    assert!(resolve(
        &signature,
        &[
            dependency("#1_", vec![reference(10), reference(12)]),
            dependency("#2_", vec![reference(11)])
        ]
    )
    .is_none());
    assert!(resolve(
        &signature,
        &[
            dependency("#1_", vec![reference(10)]),
            dependency("#2_", vec![reference(11)]),
            dependency("#3_", vec![reference(12)])
        ]
    )
    .is_none());
}

#[test]
fn relation_input_index_matches_parameter_with_optional_ordinal() {
    let input = |parameter: &str| crate::native::CatiaRelationTypeInput {
        parameter: parameter.to_string(),
        input_type: "Real".to_string(),
    };
    let inputs = [input("#1_"), input("#12_"), input("#1_"), input("#3_ ")];
    let index = crate::native::RelationInputIndex::new(&inputs);
    let matches = |symbol: &str| {
        let dependency = crate::native::CatiaRelationParameterDependency {
            source_offset: 0,
            symbol: symbol.to_string(),
            candidates: Vec::new(),
        };
        let mut matched = index.matches(&dependency).collect::<Vec<_>>();
        matched.sort_unstable();
        matched
    };
    assert_eq!(matches("#1_"), [0, 2]);
    assert_eq!(matches("#1_  "), [0, 2]);
    assert_eq!(matches("#1_/2"), [0, 2]);
    assert_eq!(matches("#1_ \t/27"), [0, 2]);
    assert_eq!(matches("#12_ /3"), [1]);
    assert_eq!(matches("#3_ "), [3]);
    assert_eq!(matches("#3_  /4"), [3]);
    assert!(matches("#1_/").is_empty());
    assert!(matches("#1_ /2x").is_empty());
    assert!(matches("#1_x").is_empty());
    assert!(matches("#1").is_empty());
    assert!(matches("#3_").is_empty());
}

#[test]
fn complete_relation_program_inputs_transfer_typed_parameters() {
    use cadmpeg_ir::{features::ParameterValue, scalar::Length};

    let mut native =
        crate::native::CatiaNative::decode(&standard_catpart_with_formula_relation(0x63, false));
    let parameter_entity = native.entity_records[2].clone();
    native.entity_records[0].object_production = Some(
        crate::native::entity_record::CatiaEntityObjectProduction::RelationProgramInstance(
            crate::native::CatiaRelationProgramInstance {
                framing: crate::native::CatiaRelationProgramInstanceFraming::Lead12 {
                    context_entity: crate::native::CatiaEntityReference::Unresolved {
                        entity_id: 0,
                    },
                },
                program_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                repeated_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                reference_incidences: Vec::new(),
                relation_expression: None,
                parameter_dependencies: Vec::new(),
                inputs: Some(vec![crate::native::CatiaRelationProgramInput {
                    parameter: "#1_".to_string(),
                    value_type: "LENGTH".to_string(),
                    entity: crate::native::CatiaEntityReference::resolved_or_unresolved(
                        parameter_entity.entity_id,
                        Some(parameter_entity.id.clone()),
                        Some("param".to_string()),
                    ),
                }]),
            },
        ),
    );

    let mut ir = CadIr::empty();
    let mut annotations = Annotations::default();
    let transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut ir,
            &native,
            &mut annotations,
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    let [parameter] = ir.model.parameters.as_slice() else {
        panic!("one relation-program input parameter")
    };
    assert_eq!(transfer.relation_program_parameter_count, 1);
    assert_eq!(parameter.name, "Thickness");
    assert_eq!(parameter.expression, "35 mm");
    assert_eq!(
        parameter.value,
        Some(ParameterValue::Length(Length::new(35.0).unwrap()))
    );
    assert_eq!(
        parameter.properties.get("value_type").map(String::as_str),
        Some("LENGTH")
    );
    assert_eq!(
        parameter
            .properties
            .get("catia_binding")
            .map(String::as_str),
        Some("#1_ /2")
    );
    assert_eq!(parameter.native_ref, Some(parameter_entity.id.clone()));

    let mut empty_binding_native = native.clone();
    empty_binding_native.entity_records[2]
        .parameter_value_mut()
        .expect("complete input parameter")
        .binding
        .value
        .clear();
    let mut empty_binding_ir = CadIr::empty();
    let empty_binding_transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut empty_binding_ir,
            &empty_binding_native,
            &mut Annotations::default(),
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    let [empty_binding_parameter] = empty_binding_ir.model.parameters.as_slice() else {
        panic!("one empty-binding input parameter")
    };
    assert_eq!(empty_binding_transfer.relation_program_parameter_count, 1);
    assert_eq!(
        empty_binding_parameter
            .properties
            .get("catia_binding")
            .map(String::as_str),
        Some("")
    );

    let mut conflicting_native = native.clone();
    let mut conflicting_instance = conflicting_native.entity_records[0]
        .relation_program_instance()
        .cloned()
        .expect("complete relation-program instance");
    conflicting_instance
        .inputs
        .as_mut()
        .expect("complete relation-program inputs")[0]
        .value_type = "Real".to_string();
    conflicting_native.entity_records[1].object_production = Some(
        crate::native::entity_record::CatiaEntityObjectProduction::RelationProgramInstance(
            conflicting_instance,
        ),
    );
    let mut conflicting_ir = CadIr::empty();
    let conflicting_transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut conflicting_ir,
            &conflicting_native,
            &mut Annotations::default(),
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    assert_eq!(conflicting_transfer.relation_program_parameter_count, 0);
    assert!(conflicting_ir.model.parameters.is_empty());
}

#[test]
fn complete_relation_program_output_transfers_a_typed_result() {
    use cadmpeg_ir::{features::ParameterValue, scalar::Length};

    let mut native =
        crate::native::CatiaNative::decode(&standard_catpart_with_formula_relation(0x63, false));
    let expression_entity = native.entity_records[1].clone();
    let input_entity = native.entity_records[2].clone();
    let output_entity = native.entity_records[3].clone();
    native.entity_records[0].object_production = Some(
        crate::native::entity_record::CatiaEntityObjectProduction::RelationProgramInstance(
            crate::native::CatiaRelationProgramInstance {
                framing: crate::native::CatiaRelationProgramInstanceFraming::Lead12 {
                    context_entity: crate::native::CatiaEntityReference::resolved_or_unresolved(
                        output_entity.entity_id,
                        Some(output_entity.id.clone()),
                        Some("paramout".to_string()),
                    ),
                },
                program_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                repeated_entity: crate::native::CatiaEntityReference::Unresolved { entity_id: 0 },
                reference_incidences: Vec::new(),
                relation_expression: Some(expression_entity.id.clone()),
                parameter_dependencies: Vec::new(),
                inputs: Some(vec![crate::native::CatiaRelationProgramInput {
                    parameter: "#1_".to_string(),
                    value_type: "LENGTH".to_string(),
                    entity: crate::native::CatiaEntityReference::resolved_or_unresolved(
                        input_entity.entity_id,
                        Some(input_entity.id.clone()),
                        Some("param".to_string()),
                    ),
                }]),
            },
        ),
    );

    let mut ir = CadIr::empty();
    let mut annotations = Annotations::default();
    let transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut ir,
            &native,
            &mut annotations,
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    let [input, output] = ir.model.parameters.as_slice() else {
        panic!("typed relation-program input and output")
    };
    assert_eq!(transfer.relation_program_parameter_count, 1);
    assert_eq!(input.name, "Thickness");
    assert_eq!(input.expression, "35 mm");
    assert_eq!(
        input.value,
        Some(ParameterValue::Length(Length::new(35.0).unwrap()))
    );
    assert_eq!(output.name, "Result");
    assert_eq!(output.expression, "#1_ /2-2mm");
    assert_eq!(
        output.value,
        Some(ParameterValue::Length(Length::new(33.0).unwrap()))
    );
    assert_eq!(output.properties["value_type"], "LENGTH");
    assert_eq!(output.properties["catia_binding"], "#result_ /1");
    assert_eq!(
        output.dependencies.as_slice(),
        std::slice::from_ref(&input.id)
    );
    assert_eq!(output.native_ref, Some(output_entity.id));

    let mut ambiguous_native = native;
    let duplicate_program = ambiguous_native.entity_records[0]
        .relation_program_instance()
        .cloned()
        .expect("compound relation-program instance");
    ambiguous_native.entity_records[1].object_production = Some(
        crate::native::entity_record::CatiaEntityObjectProduction::RelationProgramInstance(
            duplicate_program,
        ),
    );
    let mut ambiguous_ir = CadIr::empty();
    let ambiguous_transfer = crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut ambiguous_ir,
            &ambiguous_native,
            &mut Annotations::default(),
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("valid exactness fields");
    let [ambiguous_input] = ambiguous_ir.model.parameters.as_slice() else {
        panic!("ambiguous compound output keeps its typed input")
    };
    assert_eq!(ambiguous_transfer.relation_program_parameter_count, 1);
    assert_eq!(ambiguous_input.name, "Thickness");
}

#[test]
fn lead54_relation_program_instance_requires_its_complete_identity_frame() {
    let file = standard_catpart_with_lead54_relation_program_instance(1, 1, 1, 2);
    let native = crate::native::CatiaNative::decode(&file);
    let instance = native.entity_records[1]
        .relation_program_instance()
        .expect("complete lead-54 instance frame");
    assert!(matches!(
        instance.framing,
        crate::native::CatiaRelationProgramInstanceFraming::Lead54 { .. }
    ));
    assert!(instance.lead12_context_entity().is_none());
    let trailing = instance
        .lead54_trailing_entity()
        .expect("lead-54 trailing entity");
    assert_eq!(trailing.entity_id(), 1);
    assert_eq!(
        trailing.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(trailing.class_name(), Some("body"));
    assert!(instance.output_entity().is_none());
    assert_eq!(
        instance.program_entity.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(
        instance.repeated_entity.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(
        instance
            .reference_incidences
            .iter()
            .map(|incidence| incidence.reference.entity_id())
            .collect::<Vec<_>>(),
        [5, 20, 1, 21, 5]
    );
    assert_eq!(
        instance.reference_incidences[2].reference.class_name(),
        Some("body")
    );
    assert_eq!(
        instance
            .reference_incidences
            .iter()
            .map(|incidence| incidence.payload_offset)
            .collect::<Vec<_>>(),
        [10, 35, 55, 60, 70]
    );
    assert_eq!(
        instance.relation_expression.as_deref(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(
        instance
            .parameter_dependencies
            .iter()
            .map(|dependency| dependency.symbol.as_str())
            .collect::<Vec<_>>(),
        ["#1_", "#2_", "#2_"]
    );
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode lead-54 relation-program instance");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RELATION_PROGRAM_PARAMETER_DEPENDENCY_COUNT.as_str()
        ),
        3
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_RELATION_PROGRAM_PARAMETER_DEPENDENCY_COUNT.as_str()
        ),
        3
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_TYPED_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_INPUT_INSTANCE_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_RELATION_PROGRAM_INPUT_INSTANCE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_INPUT_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_DISTINCT_RELATION_PROGRAM_INPUT_ENTITY_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_RELATION_PROGRAM_INPUT_PARAMETER_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_LEAD12_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_LEAD54_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_RESOLVED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT)
                .as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_LEAD12_RELATION_PROGRAM_PARAMOUT_CONTEXT_ENTITY_COUNT)
                .as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_OTHER_LEAD12_RELATION_PROGRAM_CONTEXT_CLASS_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNCLASSIFIED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_RESOLVED_LEAD54_RELATION_PROGRAM_TRAILING_ENTITY_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_LEAD54_RELATION_PROGRAM_TRAILING_ENTITY_COUNT.as_str()
        ),
        0
    );

    let unresolved = crate::native::CatiaNative::decode(
        &standard_catpart_with_lead54_relation_program_instance(1, 3, 3, 2),
    );
    let instance = unresolved.entity_records[1]
        .relation_program_instance()
        .expect("unresolved repeated identity");
    assert_eq!(instance.repeated_entity.entity_id(), 3);
    assert!(instance.repeated_entity.entity().is_none());
    let trailing = instance
        .lead54_trailing_entity()
        .expect("lead-54 trailing entity");
    assert_eq!(trailing.entity_id(), 3);
    assert!(trailing.entity().is_none());

    let malformed = crate::native::CatiaNative::decode(
        &standard_catpart_with_lead54_relation_program_instance(1, 1, 1, 3),
    );
    assert!(malformed
        .entity_records
        .iter()
        .all(|entity| entity.relation_program_instance().is_none()));
}

#[test]
fn decode_reports_exact_relation_program_instances() {
    for (
        program_entity_id,
        repeated_reference_entity_id,
        resolved,
        expression,
        other,
        unresolved,
        resolved_repeated,
    ) in [
        (1, 1, 1, 1, 0, 0, 1),
        (2, 1, 1, 0, 1, 0, 1),
        (3, 1, 0, 0, 0, 0, 1),
        (1, 3, 1, 1, 0, 0, 0),
    ] {
        let decoded = CatiaCodec
            .decode(
                &mut Cursor::new(standard_catpart_with_relation_program_instance(
                    program_entity_id,
                    repeated_reference_entity_id,
                    1,
                    2,
                )),
                &DecodeOptions::default(),
            )
            .expect("decode relation-program instance");
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            1
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_RELATION_PROGRAM_REFERENCE_INCIDENCE_COUNT.as_str()
            ),
            8
        );
        let resolved_reference_incidences = 1 + usize::from(repeated_reference_entity_id == 1);
        let null_reference_incidences = usize::from(repeated_reference_entity_id == 3);
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_REFERENCE_INCIDENCE_COUNT)
                    .as_str()
            ),
            resolved_reference_incidences
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_NULL_RELATION_PROGRAM_REFERENCE_INCIDENCE_COUNT.as_str()
            ),
            null_reference_incidences
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_RELATION_PROGRAM_REFERENCE_INCIDENCE_COUNT.as_str()
            ),
            8 - resolved_reference_incidences - null_reference_incidences
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_CLASSIFIED_RELATION_PROGRAM_REFERENCE_INCIDENCE_COUNT)
                    .as_str()
            ),
            resolved_reference_incidences
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_LEAD12_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            1
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_LEAD54_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            0
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_RESOLVED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT)
                    .as_str()
            ),
            1
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT.as_str()
            ),
            0
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_LEAD12_RELATION_PROGRAM_PARAMOUT_CONTEXT_ENTITY_COUNT)
                    .as_str()
            ),
            0
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_OTHER_LEAD12_RELATION_PROGRAM_CONTEXT_CLASS_COUNT)
                    .as_str()
            ),
            1
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::UNCLASSIFIED_LEAD12_RELATION_PROGRAM_CONTEXT_ENTITY_COUNT)
                    .as_str()
            ),
            0
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            resolved
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_RELATION_EXPRESSION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            expression
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_OTHER_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            other
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            unresolved,
            "program entity {program_entity_id}"
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_NULL_RELATION_PROGRAM_INSTANCE_COUNT.as_str()
            ),
            usize::from(program_entity_id == 3)
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_RESOLVED_RELATION_PROGRAM_REPEATED_REFERENCE_COUNT)
                    .as_str()
            ),
            resolved_repeated
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_RELATION_PROGRAM_REPEATED_REFERENCE_COUNT.as_str()
            ),
            usize::from(repeated_reference_entity_id > 3)
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_NULL_RELATION_PROGRAM_REPEATED_REFERENCE_COUNT.as_str()
            ),
            usize::from(repeated_reference_entity_id == 3)
        );
        let classified_program = usize::from(program_entity_id <= 2);
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_CLASSIFIED_RELATION_PROGRAM_ENTITY_COUNT.as_str()
            ),
            classified_program
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNCLASSIFIED_RELATION_PROGRAM_ENTITY_COUNT.as_str()
            ),
            1 - classified_program
        );
        let classified_repeated = usize::from(repeated_reference_entity_id == 1);
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                (crate::coverage::DECODED_CLASSIFIED_RELATION_PROGRAM_REPEATED_ENTITY_COUNT)
                    .as_str()
            ),
            classified_repeated
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNCLASSIFIED_RELATION_PROGRAM_REPEATED_ENTITY_COUNT.as_str()
            ),
            1 - classified_repeated
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_INSTANCED_RELATION_EXPRESSION_COUNT.as_str()
            ),
            expression
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_REFERENCED_RELATION_EXPRESSION_COUNT.as_str()
            ),
            expression
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_FORMULA_REFERENCED_RELATION_EXPRESSION_COUNT.as_str()
            ),
            0
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_PROGRAM_REFERENCED_RELATION_EXPRESSION_COUNT.as_str()
            ),
            expression
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_UNREFERENCED_RELATION_EXPRESSION_COUNT.as_str()
            ),
            1 - expression
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_RELATION_PROGRAM_PARAMETER_DEPENDENCY_COUNT.as_str()
            ),
            expression * 3
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::UNRESOLVED_RELATION_PROGRAM_PARAMETER_DEPENDENCY_COUNT.as_str()
            ),
            expression * 3
        );
        assert_eq!(
            wire::coverage_count(
                decoded.report(),
                crate::coverage::DECODED_FORMULA_RELATION_COUNT.as_str()
            ),
            0
        );
        assert!(decoded.ir().model.parameters.is_empty());
    }
}

#[test]
fn native_load_validates_relation_program_instances() {
    for native in [
        crate::native::CatiaNative::decode(&standard_catpart_with_relation_program_instance(
            1, 1, 1, 2,
        )),
        crate::native::CatiaNative::decode(
            &standard_catpart_with_lead54_relation_program_instance(1, 1, 1, 2),
        ),
    ] {
        let mut malformed_dependencies = native.clone();
        malformed_dependencies.entity_records[1]
            .relation_program_instance_mut()
            .expect("decoded relation-program instance")
            .parameter_dependencies[0]
            .symbol = "#999_".to_string();
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed_dependencies
            .store(&mut namespace)
            .expect("store malformed relation-program dependencies");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));

        let mut malformed_inputs = native.clone();
        malformed_inputs.entity_records[1]
            .relation_program_instance_mut()
            .expect("decoded relation-program instance")
            .inputs = Some(Vec::new());
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed_inputs
            .store(&mut namespace)
            .expect("store malformed relation-program inputs");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));

        let mut malformed_offset = native.clone();
        malformed_offset.entity_records[1]
            .relation_program_instance_mut()
            .expect("decoded relation-program instance")
            .reference_incidences[0]
            .payload_offset = u64::MAX;
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed_offset
            .store(&mut namespace)
            .expect("store malformed relation-program incidence offset");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));

        let mut malformed = native;
        let malformed_reference = malformed.entity_records[1]
            .relation_program_instance()
            .expect("decoded relation-program instance")
            .reference_incidences[0]
            .reference
            .clone()
            .with_entity_id(u32::MAX);
        malformed.entity_records[1]
            .relation_program_instance_mut()
            .expect("decoded relation-program instance")
            .reference_incidences[0]
            .reference = malformed_reference;
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed relation-program incidences");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    }
}

#[test]
fn relation_symbols_and_dependencies_bind_parameter_candidates() {
    let service_symbols = crate::native::relation_symbols("#1_ + #2_");
    assert_eq!(
        service_symbols,
        [(0, "#1_".to_string()), (6, "#2_".to_string())]
    );
    let candidate = crate::native::CatiaEntityReference::resolved_or_unresolved(
        10,
        Some("entity-10".to_string()),
        Some("param".to_string()),
    );
    let bindings = std::collections::HashMap::from([(
        "graph".to_string(),
        std::collections::HashMap::from([("#1_".to_string(), vec![candidate])]),
    )]);
    let dependencies = crate::test_support::with_service_context(|ctx| {
        crate::native::RelationDependencies::new(&bindings, usize::MAX).of(
            ctx,
            crate::native::RelationExpressionKey::ObjectRecord("expression"),
            "#1_",
            "graph",
        )
    })
    .expect("retain the relation dependencies")
    .expect("the dependencies fit the allowance");
    assert_eq!(dependencies.len(), 1);
    assert_eq!(dependencies[0].candidates[0].entity(), Some("entity-10"));
}

#[test]
fn resolved_relation_input_binds_the_dependency_entity() {
    let signature = crate::native::CatiaRelationTypeSignature {
        inputs: vec![crate::native::CatiaRelationTypeInput {
            parameter: "#1_".to_string(),
            input_type: "Real".to_string(),
        }],
        result_type: "Real".to_string(),
    };
    let dependencies = vec![crate::native::CatiaRelationParameterDependency {
        source_offset: 0,
        symbol: "#1_".to_string(),
        candidates: vec![crate::native::CatiaEntityReference::resolved_or_unresolved(
            10,
            Some("entity-10".to_string()),
            Some("param".to_string()),
        )],
    }];

    let service = crate::native::resolved_relation_program_inputs(&signature, &dependencies)
        .expect("one resolved input");
    assert_eq!(service[0].entity.entity(), Some("entity-10"));
}

#[test]
fn entity_reference_resolves_entity_and_class_name() {
    let entities =
        std::collections::HashMap::from([(("graph".to_string(), 10_u32), "entity-10".to_string())]);
    let classes =
        std::collections::HashMap::from([(("graph".to_string(), 10_u32), "param".to_string())]);
    let terminal_nulls = std::collections::HashMap::new();
    let index = crate::native::CatiaEntityReferenceIndex {
        entities: &entities,
        classes: &classes,
        terminal_nulls: &terminal_nulls,
    };
    let service =
        crate::test_support::with_service_context(|ctx| index.reference(ctx, "graph", 10))
            .expect("resolve the entity reference");
    assert_eq!(service.entity(), Some("entity-10"));
    assert_eq!(service.class_name(), Some("param"));

    let class_text = u64::try_from("param".len()).expect("fixture text fits");
    let admitted = crate::test_support::with_retained_limit(class_text, |ctx| {
        index.reference(ctx, "graph", 10)
    })
    .expect("one class copy fits its own length");
    assert_eq!(admitted, service);
    let error = crate::test_support::with_retained_limit(class_text - 1, |ctx| {
        index.reference(ctx, "graph", 10)
    })
    .expect_err("the class copy is charged before it is made");
    assert!(matches!(
        error,
        cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::RetainedBytes
                && limit.operation == "retain CATIA schema class text"
    ));
    let unresolved =
        crate::test_support::with_retained_limit(0, |ctx| index.reference(ctx, "graph", 11))
            .expect("an unresolved reference keeps no class text");
    assert_eq!(unresolved.class_name(), None);
}

#[test]
fn relation_input_index_matches_across_a_long_whitespace_run() {
    const SPACES: usize = 1 << 20;
    let input = |parameter: &str| crate::native::CatiaRelationTypeInput {
        parameter: parameter.to_string(),
        input_type: "Real".to_string(),
    };
    let inputs = [input("#1_"), input("#1_ "), input("#1_\t"), input("#2_")];
    let index = crate::native::RelationInputIndex::new(&inputs);
    let matches = |symbol: String| {
        let dependency = crate::native::CatiaRelationParameterDependency {
            source_offset: 0,
            symbol,
            candidates: Vec::new(),
        };
        let mut matched = index.matches(&dependency).collect::<Vec<_>>();
        matched.sort_unstable();
        matched
    };
    let spaces = " ".repeat(SPACES);
    assert_eq!(matches(format!("#1_{spaces}/1")), [0, 1]);
    assert_eq!(matches(format!("#1_{spaces}")), [0, 1]);
    assert_eq!(matches(format!("#1_\t{spaces}/1")), [0, 2]);
    assert!(matches(format!("#3_{spaces}/1")).is_empty());
}

#[test]
fn relation_dependencies_scan_an_expression_once_for_every_relation() {
    const RELATIONS: usize = 1024;
    let candidate = crate::native::CatiaEntityReference::resolved_or_unresolved(
        10,
        Some("entity-10".to_string()),
        Some("param".to_string()),
    );
    let bindings = std::collections::HashMap::from([(
        "graph".to_string(),
        std::collections::HashMap::from([("#1_".to_string(), vec![candidate])]),
    )]);
    let source = format!("#1_ + {}", "1".repeat(1 << 20));
    let expected = crate::test_support::with_service_context(|ctx| {
        crate::native::RelationDependencies::new(&bindings, usize::MAX).of(
            ctx,
            crate::native::RelationExpressionKey::ObjectRecord("expression"),
            &source,
            "graph",
        )
    })
    .expect("retain one relation's dependencies")
    .expect("the dependencies fit the allowance");
    assert_eq!(expected.len(), 1);
    crate::test_support::with_service_context(|ctx| {
        let mut dependencies = crate::native::RelationDependencies::new(&bindings, usize::MAX);
        for _ in 0..RELATIONS {
            let copied = dependencies
                .of(
                    ctx,
                    crate::native::RelationExpressionKey::ObjectRecord("expression"),
                    &source,
                    "graph",
                )
                .expect("retain every relation's dependencies");
            assert_eq!(copied.as_ref(), Some(&expected));
        }
    });
}

#[test]
fn relation_dependency_copies_past_the_allowance_keep_no_dependencies() {
    let candidate = crate::native::CatiaEntityReference::resolved_or_unresolved(
        10,
        Some("entity-10".to_string()),
        Some("param".to_string()),
    );
    let bindings = std::collections::HashMap::from([(
        "graph".to_string(),
        std::collections::HashMap::from([("#1_".to_string(), vec![candidate])]),
    )]);
    let copy_text = 2 * ("#1_".len() + "entity-10".len() + "param".len());
    crate::test_support::with_service_context(|ctx| {
        let mut dependencies =
            crate::native::RelationDependencies::new(&bindings, 2 * copy_text + 1);
        let key = crate::native::RelationExpressionKey::Entity("graph", 7);
        let mut copy = || {
            dependencies
                .of(ctx, key, "#1_ + #1_", "graph")
                .expect("a bounded copy is a loss, not a refusal")
                .map(|copied| copied.len())
        };
        assert_eq!([copy(), copy(), copy()], [Some(2), Some(2), None]);
        assert_eq!(dependencies.bounded_relations, 1);
    });
}

#[test]
fn each_relation_dependency_copy_charges_its_text() {
    let candidate = crate::native::CatiaEntityReference::resolved_or_unresolved(
        10,
        Some("entity-10".to_string()),
        Some("param".to_string()),
    );
    let bindings = std::collections::HashMap::from([(
        "graph".to_string(),
        std::collections::HashMap::from([("#1_".to_string(), vec![candidate])]),
    )]);
    let copy_text = 2 * ("#1_".len() + "entity-10".len() + "param".len());
    let limit = u64::try_from(copy_text).expect("fixture text fits u64");
    let error = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut dependencies = crate::native::RelationDependencies::new(&bindings, usize::MAX);
        let key = crate::native::RelationExpressionKey::Entity("graph", 7);
        dependencies
            .of(ctx, key, "#1_ + #1_", "graph")
            .expect("the first copy fits the retained limit");
        dependencies.of(ctx, key, "#1_ + #1_", "graph")
    })
    .expect_err("the second copy exceeds the retained limit");
    assert!(matches!(
        error,
        cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::RetainedBytes
                && limit.operation == "retain CATIA relation parameter dependencies"
    ));
}
