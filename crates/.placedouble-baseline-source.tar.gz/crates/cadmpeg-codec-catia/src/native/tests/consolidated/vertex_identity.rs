// SPDX-License-Identifier: Apache-2.0
//! vertex identity tests.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use super::{
    a5_native_edge_identity_stream, a5_native_edge_run_stream, a5_sphere_bound_edge_stream,
    a5_torus_bound_edge_stream, b2_chamfer_contact_stream, b2_chamfer_stream, b2_cylinder_stream,
    b2_edge_node_stream, b2_plane_carrier_stream,
};

#[test]
fn successor_relative_endpoints_do_not_share_unresolved_vertex_identities() {
    let face = [0xb2, 3, 0x5f, 4, 5, 0x82, 0x1d, 3, 5];
    let owner = [
        0xb2, 3, 0x62, 11, 5, 0x85, 5, 0x0b, 5, 0x23, 0x21, 0x84, 0x41, 0xff, 0x0f, 1,
    ];
    let vertex = [0xb2, 3, 0x5d, 2, 5, 3, 0];
    let edge = [0xb2, 3, 0x5e, 6, 5, 3, 9, 0x7b, 7, 0x0b, 0x21];
    let definition = [0xb2, 3, 0x24, 4, 5, 0x81, 0x29, 0x0f, 0x87];
    let first_use = [0xb2, 3, 6, 4, 5, 0x82, 5, 0x2d, 0x88];
    let second_use = [0xb2, 3, 6, 4, 5, 0x82, 9, 0x31, 0x84];
    let build = |edge: &[u8]| {
        let mut bytes = face.to_vec();
        bytes.extend_from_slice(&owner);
        for _ in 0..2 {
            bytes.extend_from_slice(&vertex);
            bytes.extend_from_slice(&vertex);
            bytes.extend_from_slice(edge);
            bytes.extend_from_slice(&definition);
            bytes.extend_from_slice(&first_use);
            bytes.extend_from_slice(&second_use);
        }
        bytes
    };
    let mut complete_edge = edge;
    complete_edge[7] = 5;
    let mut complete_bytes = build(&complete_edge);
    complete_bytes[face.len() - 1] = 7;
    let complete = crate::native::CatiaNative::decode(&complete_bytes);
    assert!(complete.consolidated_owner_packets[0].face_node.is_none());
    let [first, second] = complete.consolidated_edge_nodes.as_slice() else {
        panic!("two successor edges with complete endpoints");
    };
    let first_vertex = u64::try_from(face.len() + owner.len()).expect("small fixture");
    let second_vertex = first_vertex
        + u64::try_from(
            2 * vertex.len() + edge.len() + definition.len() + first_use.len() + second_use.len(),
        )
        .expect("small fixture");
    assert_eq!(
        first.endpoint_records.map(|records| records[0]),
        Some(first_vertex)
    );
    assert_eq!(
        second.endpoint_records.map(|records| records[0]),
        Some(second_vertex)
    );
    assert_ne!(
        complete.vertex_identity_ids(first)[0],
        complete.vertex_identity_ids(second)[0]
    );

    let owned_complete = crate::native::CatiaNative::decode(&build(&complete_edge));
    assert!(owned_complete.consolidated_owner_packets[0]
        .face_node
        .is_some());
    assert_eq!(owned_complete.consolidated_edge_nodes.len(), 2);
    for node in &owned_complete.consolidated_edge_nodes {
        assert!(node.endpoint_records.is_none());
        assert_eq!(owned_complete.vertex_identity_ids(node), ["", ""]);
    }

    let native = crate::native::CatiaNative::decode(&build(&edge));
    let [first, second] = native.consolidated_edge_nodes.as_slice() else {
        panic!("two owner-local successor edges");
    };
    assert_eq!(
        first.allocation.as_ref().map(|(_, ordinal)| *ordinal),
        Some(2)
    );
    assert_eq!(
        second.allocation.as_ref().map(|(_, ordinal)| *ordinal),
        Some(8)
    );
    assert_eq!([first.vertex_refs[0], second.vertex_refs[0]], [2, 2]);
    assert!(first.endpoint_records.is_none() && second.endpoint_records.is_none());
    assert_eq!(native.vertex_identity_ids(first), ["", ""]);
    assert_eq!(native.vertex_identity_ids(second), ["", ""]);
    assert!(native.consolidated_vertex_identities.is_empty());
    let wire = serde_json::to_value(&native).expect("serialize native records");
    assert_eq!(
        wire["consolidated_edge_nodes"][0]["vertices"],
        serde_json::json!(["", ""])
    );
    assert_eq!(
        wire["consolidated_edge_nodes"][1]["vertices"],
        serde_json::json!(["", ""])
    );
    assert_eq!(
        serde_json::from_value::<crate::native::CatiaNative>(wire).expect("load native records"),
        native
    );
}

#[test]
fn native_namespace_merges_shared_consolidated_vertex_identity() {
    let mut bytes = a5_native_edge_run_stream(6, 139, 142);
    bytes.extend_from_slice(&a5_native_edge_run_stream(9, 142, 151));
    let native = crate::native::CatiaNative::decode(&bytes);

    assert_eq!(native.consolidated_edge_runs.len(), 2);
    assert_eq!(native.consolidated_vertex_identities.len(), 3);
    let shared = native
        .consolidated_vertex_identities
        .iter()
        .find(|vertex| vertex.identity == 142)
        .expect("shared consolidated vertex identity");
    assert_eq!(
        shared.incident_edge_nodes,
        [
            "catia:consolidated:edge-node#0",
            "catia:consolidated:edge-node#1"
        ]
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0])[1],
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])[0]
    );
}

#[test]
fn native_vertex_identity_namespace_is_bounded_by_record_source() {
    let first = a5_native_edge_run_stream(6, 14, 15);
    let mut bytes = first.clone();
    bytes.extend_from_slice(&a5_native_edge_run_stream(9, 15, 16));
    let native = crate::native::CatiaNative::decode_with_record_ranges(
        &bytes,
        &[0..first.len(), first.len()..bytes.len()],
    );

    assert_eq!(native.consolidated_edge_runs.len(), 2);
    assert_eq!(native.consolidated_vertex_identities.len(), 4);
    assert_eq!(
        native
            .consolidated_edge_nodes
            .iter()
            .map(|node| node.source_index)
            .collect::<Vec<_>>(),
        [0, 1]
    );
    let repeated = native
        .consolidated_vertex_identities
        .iter()
        .filter(|vertex| vertex.identity == 15)
        .collect::<Vec<_>>();
    assert_eq!(repeated.len(), 2);
    assert_eq!(repeated[0].source_index, 0);
    assert_eq!(repeated[1].source_index, 1);
    assert_ne!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0])[1],
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])[0]
    );
}

#[test]
fn explicit_vertex_encodings_share_one_complete_run_identity_namespace() {
    fn replace_node(mut stream: Vec<u8>, payload: &[u8]) -> Vec<u8> {
        let node = stream
            .windows(3)
            .position(|window| window == [0xb2, 0x03, 0x5e])
            .expect("edge node frame");
        stream.truncate(node);
        stream.extend_from_slice(&[
            0xb2,
            0x03,
            0x5e,
            u8::try_from(payload.len()).expect("bounded edge payload"),
            0x05,
        ]);
        stream.extend_from_slice(payload);
        stream
    }

    let mut bytes = a5_native_edge_run_stream(6, 14, 15);
    let tagged_u16 = replace_node(
        a5_native_edge_run_stream(9, 15, 16),
        &[37, 0x0a, 15, 0, 0x0a, 16, 0, 9, 5, 0x21],
    );
    bytes.extend_from_slice(&tagged_u16);
    let selector2 = replace_node(
        a5_native_edge_run_stream(12, 16, 17),
        &[49, 4 * 16 + 2, 4 * 17 + 2, 9, 5, 0x21],
    );
    bytes.extend_from_slice(&selector2);

    let native = crate::native::CatiaNative::decode(&bytes);

    assert_eq!(native.consolidated_edge_runs.len(), 3);
    assert_eq!(native.consolidated_vertex_identities.len(), 4);
    assert_eq!(
        native.consolidated_edge_nodes[0].reference_encodings[1..3],
        [
            crate::native::CatiaAllocationReferenceEncoding::TaggedU8,
            crate::native::CatiaAllocationReferenceEncoding::TaggedU8,
        ]
    );
    assert_eq!(
        native.consolidated_edge_nodes[1].reference_encodings[1..3],
        [
            crate::native::CatiaAllocationReferenceEncoding::TaggedU16,
            crate::native::CatiaAllocationReferenceEncoding::TaggedU16,
        ]
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0])[1],
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])[0]
    );
    assert_eq!(
        native.consolidated_edge_nodes[2].reference_encodings[1..3],
        [
            crate::native::CatiaAllocationReferenceEncoding::Selector2,
            crate::native::CatiaAllocationReferenceEncoding::Selector2,
        ]
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])[1],
        native.vertex_identity_ids(&native.consolidated_edge_nodes[2])[0]
    );
}

#[test]
fn native_namespace_retains_standalone_consolidated_edge_nodes() {
    let bytes = b2_edge_node_stream();
    let native = crate::native::CatiaNative::decode(&bytes);

    assert!(native.consolidated_edge_runs.is_empty());
    let [node] = native.consolidated_edge_nodes.as_slice() else {
        panic!("one standalone consolidated edge node");
    };
    assert_eq!(u8::from(node.token.width()), 1);
    assert_eq!(u8::from(node.flag), 0x03);
    assert_eq!(node.token.value(), 5);
    assert_eq!(node.terminal_value, 8);
    assert_eq!(
        node.terminal_encoding,
        crate::native::CatiaAllocationReferenceEncoding::BackwardDistance,
    );
    assert_eq!(node.vertex_refs, [889, 895]);
    assert!(node.uses.is_none());
    assert_eq!(native.vertex_identity_ids(node), ["", ""]);
    assert!(native.consolidated_vertex_identities.is_empty());

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store standalone consolidated edge node");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace)
            .expect("load standalone consolidated edge node"),
        native
    );
}

#[test]
fn native_namespace_attaches_oriented_uses_without_pcurves() {
    let bytes = a5_native_edge_identity_stream(6, 139, 142);
    let native = crate::native::CatiaNative::decode(&bytes);

    assert!(native.consolidated_edge_runs.is_empty());
    let [node] = native.consolidated_edge_nodes.as_slice() else {
        panic!("one consolidated edge node");
    };
    let uses = node.uses.as_ref().expect("standalone edge-owned uses");
    assert_eq!(uses.references, [[4, 5], [5, 6]]);
}

#[test]
fn native_namespace_retains_resolved_consolidated_edge_supports_and_loci() {
    use crate::native::CatiaConsolidatedSupportBinding;

    let mut bytes = b2_cylinder_stream();
    for point in [
        [1.0f32, 4.0, 3.0],
        [2.0, 2.0 + 2.0 * 0.5f32.cos(), 3.0 + 2.0 * 0.5f32.sin()],
    ] {
        bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in point {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
    }
    bytes.extend_from_slice(&a5_native_edge_run_stream(6, 139, 142));

    let native = crate::native::CatiaNative::decode(&bytes);
    let [run] = native.consolidated_edge_runs.as_slice() else {
        panic!("one consolidated edge run");
    };
    assert!(run.support_bindings.iter().all(|binding| matches!(
        binding,
        Some(CatiaConsolidatedSupportBinding::Cylinder { .. })
    )));
    assert_eq!(run.shared_loci.as_ref().map(Vec::len), Some(2));
    assert_eq!(
        run.endpoint_loci,
        run.shared_loci
            .as_ref()
            .map(|loci| [loci[0], loci[loci.len() - 1]])
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store resolved CATIA edge run");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load resolved CATIA edge run"),
        native
    );

    namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "consolidated_cylinders",
            &Vec::<crate::native::CatiaConsolidatedCylinder>::new(),
        )
        .expect("remove retained cylinders");
    assert!(crate::native::CatiaNative::load(&namespace).is_err());
}

fn plane_bound_edge_stream(second_selector: u8) -> Vec<u8> {
    let plane_stream = b2_plane_carrier_stream();
    let plane_carriers = crate::families::b2::records::b2_plane_carriers(&plane_stream);
    let plane_end = plane_carriers[0].end;
    let mut bytes = plane_stream[..plane_end].to_vec();
    for point in [[10.0f32, 20.0, 0.0], [11.0, 20.0, 1.0]] {
        bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in point {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
    }
    bytes.extend_from_slice(&a5_native_edge_run_stream(6, 139, 142));
    let mut second = plane_stream[plane_carriers[2].pos..plane_carriers[2].end].to_vec();
    second[6] = second_selector;
    bytes.extend_from_slice(&second);
    bytes
}

#[test]
fn native_namespace_retains_resolved_consolidated_plane_supports() {
    use crate::native::CatiaConsolidatedSupportBinding;

    let bytes = plane_bound_edge_stream(0x40);

    let native = crate::native::CatiaNative::decode(&bytes);
    let [run] = native.consolidated_edge_runs.as_slice() else {
        panic!("one consolidated plane-bound edge run");
    };
    assert!(run
        .support_bindings
        .iter()
        .all(|binding| matches!(binding, Some(CatiaConsolidatedSupportBinding::Plane { .. }))));
    assert_eq!(run.shared_loci.as_ref().map(Vec::len), Some(2));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store plane-bound CATIA edge run");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load plane-bound CATIA edge run"),
        native
    );

    let mut invalid = native.clone();
    let unknown_offset = invalid
        .consolidated_plane_carriers
        .iter()
        .find(|carrier| carrier.payload.selector() == 0x40)
        .expect("unknown class-27 carrier")
        .byte_offset;
    invalid.consolidated_edge_runs[0].support_bindings[0] =
        Some(CatiaConsolidatedSupportBinding::Plane {
            byte_offset: unknown_offset,
        });
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid unknown plane binding");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "consolidated_plane_carriers",
            &Vec::<crate::native::CatiaConsolidatedPlaneCarrier>::new(),
        )
        .expect("remove retained plane carriers");
    assert!(crate::native::CatiaNative::load(&namespace).is_err());
}

#[test]
fn native_plane_supports_abstain_when_implicit_and_explicit_charts_match() {
    // This preserves the original two-plane byte fixture. Both charts now
    // have the same point and U/V axes, so neither is a unique support.
    let native = crate::native::CatiaNative::decode(&plane_bound_edge_stream(0xec));
    let [run] = native.consolidated_edge_runs.as_slice() else {
        panic!("one ambiguous plane-bound edge run");
    };
    assert!(run.support_bindings.iter().all(Option::is_none));
    assert!(run.shared_loci.is_none());
    assert_eq!(native.consolidated_plane_carriers.len(), 2);
}

#[test]
fn native_namespace_retains_resolved_consolidated_torus_supports() {
    use crate::native::CatiaConsolidatedSupportBinding;

    let native = crate::native::CatiaNative::decode(&a5_torus_bound_edge_stream());
    let [run] = native.consolidated_edge_runs.as_slice() else {
        panic!("one consolidated torus edge run");
    };
    assert!(run
        .support_bindings
        .iter()
        .all(|binding| matches!(binding, Some(CatiaConsolidatedSupportBinding::Torus { .. }))));
    assert_eq!(run.shared_loci.as_ref().map(Vec::len), Some(2));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store torus-bound CATIA edge run");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load torus-bound CATIA edge run"),
        native
    );

    namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "consolidated_tori",
            &Vec::<crate::native::CatiaConsolidatedTorus>::new(),
        )
        .expect("remove retained tori");
    assert!(crate::native::CatiaNative::load(&namespace).is_err());
}

#[test]
fn native_namespace_retains_resolved_consolidated_sphere_supports() {
    use crate::native::CatiaConsolidatedSupportBinding;

    let native = crate::native::CatiaNative::decode(&a5_sphere_bound_edge_stream());
    let [run] = native.consolidated_edge_runs.as_slice() else {
        panic!("one consolidated sphere edge run");
    };
    assert!(run.support_bindings.iter().all(|binding| matches!(
        binding,
        Some(CatiaConsolidatedSupportBinding::Sphere { .. })
    )));
    assert_eq!(run.shared_loci.as_ref().map(Vec::len), Some(2));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store sphere-bound CATIA edge run");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load sphere-bound CATIA edge run"),
        native
    );

    namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "consolidated_spheres",
            &Vec::<crate::native::CatiaConsolidatedSphere>::new(),
        )
        .expect("remove retained spheres");
    assert!(crate::native::CatiaNative::load(&namespace).is_err());
}

#[test]
fn chamfer_followed_by_spanning_parameter_point_terminates() {
    let bytes = b2_chamfer_contact_stream();
    let split =
        crate::test_support::test_b2::b2_cone_stream().len() + b2_chamfer_stream().len() + 6;
    let records = crate::wire::records::consolidated_records_in_range_sources(
        &bytes,
        [[0..split, split..bytes.len()]],
    );
    let faces = crate::test_support::with_service_context(|_ctx| {
        crate::native::chamfer::consolidated_chamfers(&bytes, &records, &[])
    });
    assert_eq!(faces.len(), 1);
    assert!(faces[0].parameter_points.is_empty());
}

#[test]
fn a_loaded_plane_carrier_direction_is_admitted_unit() {
    let native = crate::native::CatiaNative::decode(&b2_plane_carrier_stream());
    let direction3 = &native.consolidated_plane_carriers[1];
    let mut value = serde_json::to_value(direction3).expect("plane carrier JSON");
    assert_eq!(
        value["payload"]["direction"],
        serde_json::json!([1.0, 0.0, 0.0])
    );
    value["payload"]["direction"] = serde_json::json!([2.0, 0.0, 0.0]);
    let error = serde_json::from_value::<crate::native::CatiaConsolidatedPlaneCarrier>(value)
        .expect_err("a non-unit plane-carrier direction");
    assert!(
        error
            .to_string()
            .contains("direction is not a finite unit vector"),
        "{error}"
    );
}
