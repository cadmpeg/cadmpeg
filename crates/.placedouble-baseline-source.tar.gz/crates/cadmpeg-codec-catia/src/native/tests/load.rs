// SPDX-License-Identifier: Apache-2.0
//! Native-namespace tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_test_support::wire;

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};

use crate::test_support::test_container::{
    external_reference_segment, outer_container_catpart, standard_catpart, summary_preview_segment,
    surface_alias_stream,
};
use crate::test_support::test_formula::{
    standard_catpart_with_configuration_incidences,
    standard_catpart_with_schema_configuration_row_chain,
};
use crate::test_support::test_object_graph::{
    catalog_stream, object_graph_from_records, object_graph_record, object_graph_stream,
    standard_catpart_with_value_block,
};
use crate::CatiaCodec;

#[test]
fn alias_row_borrowed_wire_preserves_json_bytes() {
    let native = crate::native::CatiaNative::decode(&surface_alias_stream());
    let row = native.alias_rows.first().expect("alias row");
    let owned: crate::native::CatiaAliasRowWire = row.clone().into();
    assert_eq!(
        serde_json::to_vec(row).expect("borrowed alias JSON"),
        serde_json::to_vec(&owned).expect("owned alias JSON")
    );
}

#[test]
fn alias_row_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&surface_alias_stream());
    let row = native.alias_rows.first().expect("alias row");
    let arena_name = "alias_rows";
    let json_len = serde_json::to_vec(row).expect("alias JSON").len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(row))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(row))
            .expect("store the native arena");
    });
}

#[test]
fn value_schema_selection_borrowed_wire_preserves_json_bytes() {
    let native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    let selection = native.value_blocks[0]
        .schema_selections
        .first()
        .expect("selection");
    let owned: crate::native::CatiaValueSchemaSelectionWire = selection.clone().into();
    assert_eq!(
        serde_json::to_vec(selection).expect("borrowed selection JSON"),
        serde_json::to_vec(&owned).expect("owned selection JSON")
    );
}

#[test]
fn value_schema_selection_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    let selection = native.value_blocks[0]
        .schema_selections
        .first()
        .expect("selection");
    let arena_name = "value_schema_selections";
    let json_len = serde_json::to_vec(selection).expect("selection JSON").len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(selection))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(selection))
            .expect("store the native arena");
    });
}

#[test]
fn native_load_rejects_orphaned_and_ambiguously_owned_design_records() {
    let mut bytes = object_graph_stream();
    bytes.extend(catalog_stream(&[
        "CATCatalogManager",
        "catalogManager",
        "catalogLinks",
        "",
        "Sketch",
    ]));
    let native = crate::native::CatiaNative::decode(&bytes);
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA native namespace");

    for arena_name in ["catalogs", "object_graphs"] {
        let mut malformed = namespace.clone();
        malformed
            .arenas_mut()
            .get_mut(arena_name)
            .expect("owner arena")
            .clear();
        assert!(matches!(
            crate::native::CatiaNative::load(&malformed),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    }

    for arena_name in ["catalogs", "object_graphs"] {
        let mut malformed = namespace.clone();
        let arena = malformed
            .arenas_mut()
            .get_mut(arena_name)
            .expect("owner arena");
        arena.push(arena.first().expect("owner record").clone());
        assert!(matches!(
            crate::native::CatiaNative::load(&malformed),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    }

    let mut stale_design_objects = namespace.clone();
    stale_design_objects
        .arenas_mut()
        .get_mut("design_objects")
        .expect("derived design-object arena")
        .clear();
    assert!(matches!(
        crate::native::CatiaNative::load(&stale_design_objects),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_load_rejects_dangling_cross_arena_links() {
    let mut value_native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    value_native.value_blocks[0].catalog = "catia:missing-catalog".to_string();
    let mut value_namespace = cadmpeg_ir::NativeNamespace::default();
    value_native
        .store(&mut value_namespace)
        .expect("store malformed value link");
    assert!(matches!(
        crate::native::CatiaNative::load(&value_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut omitted_value_graph =
        crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    omitted_value_graph.value_blocks[0].object_graph = None;
    let mut omitted_value_namespace = cadmpeg_ir::NativeNamespace::default();
    omitted_value_graph
        .store(&mut omitted_value_namespace)
        .expect("store omitted value-block graph link");
    assert!(matches!(
        crate::native::CatiaNative::load(&omitted_value_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut external_native =
        crate::native::CatiaNative::decode(&external_reference_segment("Support.CATPart"));
    external_native.external_references[0].segment = "catia:missing-segment".to_string();
    let mut external_namespace = cadmpeg_ir::NativeNamespace::default();
    external_native
        .store(&mut external_namespace)
        .expect("store malformed external-reference link");
    assert!(matches!(
        crate::native::CatiaNative::load(&external_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut alias_native = crate::native::CatiaNative::decode(&surface_alias_stream());
    alias_native.alias_rows[0].object_graph = Some("catia:missing-graph".to_string());
    alias_native.alias_rows[0].object_record = Some("catia:missing-record".to_string());
    let mut alias_namespace = cadmpeg_ir::NativeNamespace::default();
    alias_native
        .store(&mut alias_namespace)
        .expect("store malformed alias link");
    assert!(matches!(
        crate::native::CatiaNative::load(&alias_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let graph =
        object_graph_from_records(&[object_graph_record(&[0x04, 0x01, 0x81, 0x81], &[0xfe])]);
    let mut linked_alias = surface_alias_stream();
    linked_alias[15] = 1;
    let mut linked_stream = graph;
    linked_stream.extend(linked_alias);
    let (linked_bytes, _) = outer_container_catpart(&linked_stream);
    let mut omitted_alias_links = crate::native::CatiaNative::decode(&linked_bytes);
    assert!(omitted_alias_links.alias_rows[0].object_graph.is_some());
    omitted_alias_links.alias_rows[0].object_graph = None;
    omitted_alias_links.alias_rows[0].object_record = None;
    let mut omitted_alias_namespace = cadmpeg_ir::NativeNamespace::default();
    omitted_alias_links
        .store(&mut omitted_alias_namespace)
        .expect("store omitted alias links");
    assert!(matches!(
        crate::native::CatiaNative::load(&omitted_alias_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_load_rejects_noncanonical_catalog_and_record_views() {
    let mut bytes = object_graph_stream();
    bytes.extend(catalog_stream(&[
        "CATCatalogManager",
        "catalogManager",
        "catalogLinks",
        "",
        "Sketch",
    ]));
    let native = crate::native::CatiaNative::decode(&bytes);

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store catalogs");
    let mut invalid_entry_ordinal = native.clone();
    invalid_entry_ordinal.catalogs[0].entries[0].ordinal = 1;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid_entry_ordinal
        .store(&mut namespace)
        .expect("store invalid catalog ordinal");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut invalid_record_ordinal = native.clone();
    invalid_record_ordinal.object_graphs[0].records[0].ordinal = 9;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid_record_ordinal
        .store(&mut namespace)
        .expect("store invalid record ordinal");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut invalid_design_link = native.clone();
    invalid_design_link.object_graphs[0].records[0].design_object = None;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid_design_link
        .store(&mut namespace)
        .expect("store invalid design-object link");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut invalid_references = native;
    invalid_references.object_graphs[0].records[0]
        .references
        .clear();
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid_references
        .store(&mut namespace)
        .expect("store invalid payload-reference links");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_load_rejects_noncanonical_value_block_views() {
    let native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    let mut canonical_namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut canonical_namespace)
        .expect("store canonical value selections");
    assert!(canonical_namespace
        .arenas()
        .get("value_blocks")
        .is_some_and(|blocks| blocks
            .iter()
            .all(|block| !block.fields().unwrap().contains_key("schema_selections"))));
    assert_eq!(
        canonical_namespace
            .arenas()
            .get("value_schema_selections")
            .map(Vec::len),
        Some(native.value_blocks[0].schema_selections.len())
    );
    let mut orphaned_selections: Vec<crate::native::CatiaValueSchemaSelection> =
        canonical_namespace
            .arena_as("value_schema_selections")
            .expect("load stored value selections");
    orphaned_selections[0].parent = "catia:missing-value-block".to_string();
    canonical_namespace
        .set_arena(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            "value_schema_selections",
            &orphaned_selections,
        )
        .expect("store orphaned value selection");
    assert!(matches!(
        crate::native::CatiaNative::load(&canonical_namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed value-block view");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };

    let mut invalid_wire = serde_json::to_value(&native.value_blocks[0]).unwrap();
    invalid_wire["declared_len"] = serde_json::json!(native.value_blocks[0].declared_len() + 1);
    assert!(serde_json::from_value::<crate::native::CatiaValueBlock>(invalid_wire).is_err());

    let mut invalid_payload = native.clone();
    invalid_payload.value_blocks[0].payload.push(0x80);
    assert_rejected(invalid_payload);

    let mut invalid_wire = serde_json::to_value(&native.value_blocks[0]).unwrap();
    invalid_wire["fields"] = serde_json::json!([]);
    assert!(serde_json::from_value::<crate::native::CatiaValueBlock>(invalid_wire).is_err());

    let mut invalid_selections = native;
    assert!(!invalid_selections.value_blocks[0]
        .schema_selections
        .is_empty());
    invalid_selections.value_blocks[0].schema_selections.clear();
    assert_rejected(invalid_selections);
}

#[test]
fn schema_configuration_productions_retain_exact_same_graph_incidence() {
    let file = standard_catpart_with_configuration_incidences(8, 5, 7);
    let native = crate::native::CatiaNative::decode(&file);
    let configuration = native.entity_records[0]
        .schema_configuration_record()
        .expect("complete schema-configuration production");
    assert_eq!(configuration.schema_ordinal, 8);
    assert_eq!(configuration.schema_name, "Boolean");
    assert_eq!(configuration.schema_payload_offset, 0);
    assert_eq!(configuration.entity_reference.payload_offset, 10);
    assert_eq!(configuration.entity_reference.reference.entity_id(), 5);
    assert_eq!(
        configuration.entity_reference.reference.entity(),
        Some(native.entity_records[0].id.as_str())
    );
    assert_eq!(
        configuration.entity_reference.reference.class_name(),
        Some("Configuration")
    );
    let row = native.entity_records[1]
        .schema_configuration_row_link()
        .expect("complete configrow production");
    assert_eq!(row.class_reference.entity_id(), 6);
    assert_eq!(
        row.class_reference.entity(),
        Some(native.entity_records[1].id.as_str())
    );
    assert_eq!(row.class_reference.class_name(), Some("configrow"));
    assert_eq!(row.successor_payload_offset, 5);
    assert_eq!(row.successor.entity_id(), 7);
    assert_eq!(
        row.successor.entity(),
        Some(native.entity_records[2].id.as_str())
    );
    assert_eq!(row.successor.class_name(), Some("body"));
    assert_eq!(native.schema_configuration_row_chains.len(), 1);
    let chain = &native.schema_configuration_row_chains[0];
    assert_eq!(chain.object_graph, native.entity_records[1].object_graph);
    let graph_key = chain
        .object_graph
        .split_once('#')
        .expect("object graph identity")
        .1;
    assert_eq!(
        chain.id,
        format!("catia:outer:schema-configuration-row-chain#{graph_key}:6")
    );
    assert_eq!(chain.links().len(), 1);
    assert_eq!(chain.links()[0].row, row.class_reference);
    assert_eq!(
        chain.links()[0].successor_payload_offset,
        row.successor_payload_offset
    );
    assert_eq!(
        chain
            .links()
            .iter()
            .map(|link| link.row.entity_id())
            .collect::<Vec<_>>(),
        [6]
    );
    assert_eq!(
        chain.links()[0].row.entity(),
        Some(native.entity_records[1].id.as_str())
    );
    assert_eq!(chain.successor(0), Some(&row.successor));
    assert!(native.entity_records[2]
        .schema_configuration_record()
        .is_none());
    assert!(native.entity_records[2]
        .schema_configuration_row_link()
        .is_none());

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode configuration incidences");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_SCHEMA_CONFIGURATION_RECORD_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_SCHEMA_CONFIGURATION_SELECTOR_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_RESOLVED_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_CLASSIFIED_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNCLASSIFIED_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_SCHEMA_CONFIGURATION_ROW_LINK_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RESOLVED_SCHEMA_CONFIGURATION_ROW_CLASS_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_RESOLVED_SCHEMA_CONFIGURATION_ROW_SUCCESSOR_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_COMPLETE_SCHEMA_CONFIGURATION_ROW_CHAIN_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_ORDERED_SCHEMA_CONFIGURATION_ROW_LINK_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_RESOLVED_SCHEMA_CONFIGURATION_ROW_CHAIN_TERMINAL_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (crate::coverage::DECODED_CLASSIFIED_SCHEMA_CONFIGURATION_ROW_CHAIN_TERMINAL_COUNT)
                .as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ROW_ORDER_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_CONFIGURATION_COUNT.as_str()
        ),
        0
    );
    assert!(decoded.ir().model.configurations.is_empty());
}

#[test]
fn schema_configuration_row_chain_retains_complete_source_order() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_schema_configuration_row_chain());
    assert_eq!(native.schema_configuration_row_chains.len(), 1);
    let chain = &native.schema_configuration_row_chains[0];
    assert_eq!(chain.links()[0].row.entity_id(), 5);
    assert_eq!(
        chain
            .links()
            .iter()
            .map(|link| link.row.entity_id())
            .collect::<Vec<_>>(),
        [5, 7, 9]
    );
    assert!(chain
        .links()
        .iter()
        .all(|link| link.row.class_name() == Some("configrow")));
    assert_eq!(
        chain
            .links()
            .iter()
            .map(|link| link.successor_payload_offset)
            .collect::<Vec<_>>(),
        [5, 5, 5]
    );
    assert_eq!(
        chain
            .links()
            .iter()
            .map(|link| {
                link.intervening_entities
                    .as_ref()
                    .expect("source-ordered row interval")
                    .iter()
                    .map(super::super::CatiaEntityReference::entity_id)
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>(),
        [vec![6], vec![8], vec![10]]
    );
    assert!(chain
        .links()
        .iter()
        .flat_map(|link| {
            link.intervening_entities
                .as_ref()
                .expect("source-ordered row interval")
        })
        .all(|reference| reference.class_name() == Some("body")));
    assert_eq!(chain.successor(2).unwrap().entity_id(), 11);
    assert_eq!(chain.successor(2).unwrap().class_name(), Some("body"));

    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_with_schema_configuration_row_chain()),
            &DecodeOptions::default(),
        )
        .expect("decode configuration row intervals");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_SCHEMA_CONFIGURATION_ROW_INTERVENING_ENTITY_COUNT.as_str()
        ),
        3
    );
    assert_eq!(
        wire::coverage_count(decoded.report(), crate::coverage::DECODED_SCHEMA_CONFIGURATION_ROW_INTERVENING_SCHEMA_CONFIGURATION_COUNT.as_str()),
        0
    );
}

#[test]
fn schema_configuration_productions_preserve_unresolved_identities() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_configuration_incidences(8, 15, 16),
    );
    let configuration = native.entity_records[0]
        .schema_configuration_record()
        .expect("complete schema-configuration production");
    assert_eq!(configuration.schema_name, "Boolean");
    assert!(configuration.entity_reference.reference.entity().is_none());
    let row = native.entity_records[1]
        .schema_configuration_row_link()
        .expect("complete configrow production");
    assert!(row.successor.entity().is_none());

    let mismatched_schema = crate::native::CatiaNative::decode(
        &standard_catpart_with_configuration_incidences(14, 15, 16),
    );
    assert!(mismatched_schema.entity_records[0]
        .schema_configuration_record()
        .is_none());

    let mut malformed = standard_catpart_with_configuration_incidences(8, 15, 16);
    let marker = [0x80, 250, 0, 0, 0];
    let offset = malformed
        .windows(marker.len())
        .position(|window| window == marker)
        .expect("configrow marker");
    malformed[offset + 1] = 249;
    let malformed = crate::native::CatiaNative::decode(&malformed);
    assert!(malformed
        .entity_records
        .iter()
        .all(|entity| entity.schema_configuration_row_link().is_none()));

    let cyclic_file = standard_catpart_with_configuration_incidences(8, 15, 6);
    let cyclic_native = crate::native::CatiaNative::decode(&cyclic_file);
    assert!(cyclic_native.schema_configuration_row_chains.is_empty());
    let cyclic = CatiaCodec
        .decode(&mut Cursor::new(cyclic_file), &DecodeOptions::default())
        .expect("decode cyclic configuration row");
    assert_eq!(
        wire::coverage_count(
            cyclic.report(),
            crate::coverage::DECODED_COMPLETE_SCHEMA_CONFIGURATION_ROW_CHAIN_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            cyclic.report(),
            crate::coverage::DECODED_ORDERED_SCHEMA_CONFIGURATION_ROW_LINK_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            cyclic.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ROW_ORDER_COUNT.as_str()
        ),
        1
    );

    let descending = crate::native::CatiaNative::decode(
        &standard_catpart_with_configuration_incidences(8, 15, 5),
    );
    assert_eq!(descending.schema_configuration_row_chains.len(), 1);
    assert!(descending.schema_configuration_row_chains[0].links()[0]
        .intervening_entities
        .is_none());
}

#[test]
fn schema_configuration_productions_distinguish_terminal_null_identities() {
    let file = standard_catpart_with_configuration_incidences(8, 8, 8);
    let native = crate::native::CatiaNative::decode(&file);
    let configuration = native.entity_records[0]
        .schema_configuration_record()
        .expect("complete schema-configuration production");
    assert!(configuration.entity_reference.reference.is_null());
    assert!(configuration.entity_reference.reference.entity().is_none());
    let row = native.entity_records[1]
        .schema_configuration_row_link()
        .expect("complete configrow production");
    assert!(!row.class_reference.is_null());
    assert!(row.successor.is_null());
    assert!(row.successor.entity().is_none());
    assert_eq!(native.schema_configuration_row_chains.len(), 1);
    assert!(native.schema_configuration_row_chains[0].terminal.is_null());

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode terminal-null configuration incidences");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NULL_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ENTITY_REFERENCE_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NULL_SCHEMA_CONFIGURATION_ROW_CLASS_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ROW_CLASS_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NULL_SCHEMA_CONFIGURATION_ROW_SUCCESSOR_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ROW_SUCCESSOR_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_NULL_SCHEMA_CONFIGURATION_ROW_CHAIN_TERMINAL_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_SCHEMA_CONFIGURATION_ROW_CHAIN_TERMINAL_COUNT.as_str()
        ),
        0
    );
}

#[test]
fn native_load_validates_configuration_incidences() {
    let native = crate::native::CatiaNative::decode(
        &standard_catpart_with_configuration_incidences(8, 5, 7),
    );
    let mut malformed_chain = native.clone();
    malformed_chain.schema_configuration_row_chains[0].terminal = malformed_chain
        .schema_configuration_row_chains[0]
        .terminal
        .clone()
        .with_entity_id(6);
    let mut current = cadmpeg_ir::NativeNamespace::default();
    malformed_chain
        .store(&mut current)
        .expect("store malformed configuration chain");
    assert!(matches!(
        crate::native::CatiaNative::load(&current),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed_chain_offset = native.clone();
    malformed_chain_offset.schema_configuration_row_chains[0].links_mut()[0]
        .successor_payload_offset += 1;
    let mut current = cadmpeg_ir::NativeNamespace::default();
    malformed_chain_offset
        .store(&mut current)
        .expect("store malformed configuration-chain offset");
    assert!(matches!(
        crate::native::CatiaNative::load(&current),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed_offsets = native.clone();
    let configuration = malformed_offsets.entity_records[0]
        .schema_configuration_record_mut()
        .expect("decoded schema-configuration record");
    configuration.schema_payload_offset += 1;
    configuration.entity_reference.payload_offset += 1;
    malformed_offsets.entity_records[1]
        .schema_configuration_row_link_mut()
        .expect("decoded configrow link")
        .successor_payload_offset += 1;
    let mut current = cadmpeg_ir::NativeNamespace::default();
    malformed_offsets
        .store(&mut current)
        .expect("store malformed configuration offsets");
    assert!(matches!(
        crate::native::CatiaNative::load(&current),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let interval_native =
        crate::native::CatiaNative::decode(&standard_catpart_with_schema_configuration_row_chain());
    let mut malformed_intervals = interval_native;
    malformed_intervals.schema_configuration_row_chains[0].links_mut()[0]
        .intervening_entities
        .as_mut()
        .expect("source-ordered row interval")[0] = {
        let current = malformed_intervals.schema_configuration_row_chains[0].links_mut()[0]
            .intervening_entities
            .as_ref()
            .expect("source-ordered row interval")[0]
            .clone();
        current.with_entity_id(8)
    };
    let mut current = cadmpeg_ir::NativeNamespace::default();
    malformed_intervals
        .store(&mut current)
        .expect("store malformed schema-configuration-row intervals");
    assert!(matches!(
        crate::native::CatiaNative::load(&current),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));

    let mut malformed = native;
    let malformed_successor = malformed.entity_records[1]
        .schema_configuration_row_link()
        .expect("decoded configrow link")
        .successor
        .clone()
        .with_entity_id(6);
    malformed.entity_records[1]
        .schema_configuration_row_link_mut()
        .expect("decoded configrow link")
        .successor = malformed_successor;
    let mut current = cadmpeg_ir::NativeNamespace::default();
    malformed
        .store(&mut current)
        .expect("store malformed current namespace");
    assert!(matches!(
        crate::native::CatiaNative::load(&current),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn native_load_rejects_noncanonical_graph_catalog_views() {
    let native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    assert!(native.object_graphs[0].catalog_byte_offset.is_some());
    assert!(native.object_graphs[0].catalog.is_some());
    assert!(native.object_graphs[0].records[0].class_name().is_some());
    assert!(native.object_graphs[0].records[0].class_entry().is_some());
    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed graph-catalog view");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };

    let mut missing_catalog_link = native.clone();
    missing_catalog_link.object_graphs[0].catalog_byte_offset = None;
    assert_rejected(missing_catalog_link);

    let mut missing_catalog_identity = native.clone();
    missing_catalog_identity.object_graphs[0].catalog = None;
    assert_rejected(missing_catalog_identity);

    let mut invalid_class = native.clone();
    invalid_class.object_graphs[0].records[0]
        .class
        .as_mut()
        .expect("decoded class role")
        .name = Some("WrongClass".to_string());
    assert_rejected(invalid_class);

    let mut invalid_class_entry = native;
    invalid_class_entry.object_graphs[0].records[0]
        .class
        .as_mut()
        .expect("decoded class role")
        .entry = None;
    assert_rejected(invalid_class_entry);
}

#[test]
fn native_load_rejects_invalid_source_identities_and_extents() {
    let native = crate::native::CatiaNative::decode(&standard_catpart_with_value_block());
    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed source identity");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };

    let mut invalid_catalog_extent = native.clone();
    invalid_catalog_extent.catalogs[0].byte_len += 1;
    assert_rejected(invalid_catalog_extent);

    let mut invalid_entry_offset = native.clone();
    invalid_entry_offset.catalogs[0].entries[0].byte_offset += 1;
    assert_rejected(invalid_entry_offset);

    let mut invalid_record_offset = native.clone();
    invalid_record_offset.object_graphs[0].records[0].byte_offset += 1;
    assert_rejected(invalid_record_offset);

    let mut invalid_value_id = native;
    invalid_value_id.value_blocks[0].id = "catia:outer:value-block#wrong".to_string();
    assert_rejected(invalid_value_id);

    let mut invalid_alias_id = crate::native::CatiaNative::decode(&surface_alias_stream());
    invalid_alias_id.alias_rows[0].id = "catia:outer:alias-row#wrong".to_string();
    assert_rejected(invalid_alias_id);
}

#[test]
fn native_store_paths_cover_every_declared_arena() {
    let catalogue_names = crate::native::CATIA_FAMILIES
        .iter()
        .map(|row| row.arena)
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(crate::native::CATIA_FAMILIES.len(), 54);
    assert!(catalogue_names.contains("consolidated_a_class25_maps"));
    assert!(catalogue_names.contains("consolidated_a5_charts"));
    assert!(catalogue_names.contains("consolidated_rolling_ball_continuations"));
    assert!(catalogue_names.contains("consolidated_rolling_ball_constructions"));
    assert!(catalogue_names.contains("consolidated_four_reference_edges"));
    assert!(catalogue_names.contains("e5_nurbs_limit_programs"));
    assert!(catalogue_names.contains("e5_edges"));
    assert!(catalogue_names.contains("consolidated_chamfers"));
    assert!(catalogue_names.contains("object_chamfers"));
    assert!(catalogue_names.contains("consolidated_class60_records"));
    assert!(!catalogue_names.contains("consolidated_groups"));
    assert!(!catalogue_names.contains("consolidated_embedded_cylinders"));
    assert!(!catalogue_names.contains("consolidated_cone_faces"));
    assert_eq!(
        catalogue_names,
        crate::native::CATIA_ARENA_NAMES
            .iter()
            .copied()
            .collect::<std::collections::BTreeSet<_>>()
    );

    let rich = crate::native::CatiaNative::decode(&standard_catpart());
    let mut rich_borrowed = cadmpeg_ir::NativeNamespace::default();
    rich.store(&mut rich_borrowed)
        .expect("store populated borrowed CATIA namespace");
    let mut rich_owned = cadmpeg_ir::NativeNamespace::default();
    rich.clone()
        .store_owned(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &mut rich_owned,
        )
        .expect("store populated owned CATIA namespace");
    assert_eq!(rich_borrowed, rich_owned);
    assert_eq!(
        crate::native::CatiaNative::load(&rich_borrowed).expect("reload populated namespace"),
        rich
    );

    // The declared manifest and the emitter must agree on every build, not only
    // on a debug build: a name in the manifest that `emit_all` never emits
    // makes the stored namespace incomplete.
    for name in crate::native::CATIA_ARENA_NAMES {
        assert!(
            rich_borrowed.arenas().contains_key(*name),
            "store must emit the declared arena {name}"
        );
        assert!(
            rich_owned.arenas().contains_key(*name),
            "store_owned must emit the declared arena {name}"
        );
    }
}

#[test]
fn native_validates_evaluated_value_names() {
    let mut bytes = Vec::new();
    bytes.push(0xea);
    bytes.extend(1_u32.to_le_bytes());
    bytes.push(0x81);
    bytes.extend([0x58, 0xd1, 8]);
    bytes.extend(b"\xe8\x00\x12\x01\x06Count\xfe");
    bytes.extend([0x5f, 0xd1, 9]);
    bytes.extend(b"\xe8\xc4\x17\x01\xfe\xfe");
    bytes.extend(b"\xfe\x85\x9d\x82\xfe\x8c");
    bytes.extend(b"\xde\x04\xfe\xfe\x12CATCatalogManager");

    let native = crate::native::CatiaNative::decode(&bytes);
    let value = &native.legacy_entity_runs[0].integer_values[0];
    assert_eq!(value.name.as_deref(), Some("Count"));

    let mut invalid = native.clone();
    invalid.legacy_entity_runs[0].integer_values[0].name = None;
    invalid.legacy_entity_runs[0].integer_values[0].name_field = None;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store noncanonical evaluated value name");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_load_restores_segment_source_order_and_validates_retained_views() {
    let mut bytes = Vec::new();
    for index in 0..12 {
        bytes.extend(external_reference_segment(&format!(
            "Support{index}.CATPart"
        )));
    }
    let native = crate::native::CatiaNative::decode(&bytes);
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store indexed FINJPL segments");
    let loaded =
        crate::native::CatiaNative::load(&namespace).expect("load indexed FINJPL segments");
    assert_eq!(
        loaded
            .finjpl_segments
            .iter()
            .map(|segment| segment.id.clone())
            .collect::<Vec<_>>(),
        (0..12)
            .map(|index| format!("catia:outer:finjpl#{index}"))
            .collect::<Vec<_>>()
    );
    assert!(loaded
        .finjpl_segments
        .windows(2)
        .all(|pair| pair[0].byte_offset < pair[1].byte_offset));
    assert_eq!(
        loaded
            .external_references
            .iter()
            .map(|reference| reference.id.clone())
            .collect::<Vec<_>>(),
        (0..12)
            .map(|index| format!("catia:outer:external-reference#{index}"))
            .collect::<Vec<_>>()
    );

    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed FINJPL view");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };
    let mut invalid_length = native.clone();
    invalid_length.finjpl_segments[0].byte_len += 1;
    assert_rejected(invalid_length);
    let mut invalid_family = native.clone();
    invalid_family.finjpl_segments[0].family = "other".to_string();
    assert_rejected(invalid_family);
    let mut missing_reference = native.clone();
    missing_reference.external_references.pop();
    assert_rejected(missing_reference);
    let mut invalid_target = native.clone();
    invalid_target.external_references[0].target = "Wrong.CATPart".to_string();
    assert_rejected(invalid_target);
    let mut invalid_reference_offset = native.clone();
    invalid_reference_offset.external_references[0].byte_offset += 1;
    assert_rejected(invalid_reference_offset);
    let mut invalid_type = native;
    invalid_type.finjpl_segments[0].type_word ^= 1;
    assert_rejected(invalid_type);

    let mut invalid_offset = crate::native::CatiaNative::decode(&bytes);
    invalid_offset.finjpl_segments[1].byte_offset += 1;
    assert_rejected(invalid_offset);
}

#[test]
fn native_load_derives_complete_source_ordered_preview_views() {
    let mut bytes = Vec::new();
    for _ in 0..12 {
        bytes.extend(summary_preview_segment());
    }
    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.preview_images.len(), 12);
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store indexed preview views");
    let loaded = crate::native::CatiaNative::load(&namespace).expect("load indexed preview views");
    assert_eq!(
        loaded
            .preview_images
            .iter()
            .map(|preview| preview.id.clone())
            .collect::<Vec<_>>(),
        (0..12)
            .map(|index| format!("catia:outer:preview#{index}"))
            .collect::<Vec<_>>()
    );

    let assert_rejected = |malformed: crate::native::CatiaNative| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        malformed
            .store(&mut namespace)
            .expect("store malformed preview view");
        assert!(matches!(
            crate::native::CatiaNative::load(&namespace),
            Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
        ));
    };
    let mut missing = native.clone();
    missing.preview_images.pop();
    assert_rejected(missing);
    let mut invalid_width = native.clone();
    invalid_width.preview_images[0].width += 1;
    assert_rejected(invalid_width);
    let mut invalid_data = native;
    invalid_data.preview_images[0].data[0] = 0;
    assert_rejected(invalid_data);
}

#[test]
fn arena_projection_lists_catalogs_and_their_entries() {
    let mut native = super::super::CatiaNative::default();
    native.catalogs.push(super::super::CatiaCatalog {
        id: "catia:catalog#0".to_string(),
        byte_offset: 0,
        byte_len: 1,
        entries: vec![super::super::CatiaCatalogEntry {
            id: "catia:catalog-entry#0".to_string(),
            parent: "catia:catalog#0".to_string(),
            ordinal: 0,
            byte_offset: 0,
            value: "schema".to_string(),
        }],
    });
    let service = super::super::CatiaArenaProjection::from_owned(native.clone());
    assert_eq!(service.catalogs.len(), 1);
    assert_eq!(service.catalog_entries.len(), 1);
}

#[test]
fn legacy_entity_run_reads_catalog_manager_identity() {
    let mut bytes = vec![0xea];
    bytes.extend_from_slice(&1u32.to_le_bytes());
    bytes.extend_from_slice(&[0x81, 0xfd, 0x8c]);
    bytes.extend_from_slice(b"\xde\x04\xfe\xfe\x12CATCatalogManager");
    let admitted = super::super::legacy_entity_runs(&bytes);
    assert_eq!(admitted.len(), 1);
    assert_eq!(admitted[0].identities.len(), 1);
}

#[test]
fn object_graph_fixture_projects_nonempty_records() {
    let bytes = object_graph_stream();
    let parsed = crate::object_graph::parse(&bytes).expect("fixture has an object graph");
    let admitted = super::super::projection::native_object_graph(parsed, Vec::new(), None, None);
    assert!(!admitted.0.records.is_empty());
}

#[test]
fn incoming_incidences_list_references_to_the_entity() {
    let file = standard_catpart_with_configuration_incidences(8, 5, 7);
    let native = crate::native::CatiaNative::decode(&file);
    let graph = &native.object_graphs[0];
    let index = super::super::EntityIncidenceIndex::new(&graph.records, &graph.id);
    let admitted = crate::test_support::with_service_context(|ctx| index.incidences(ctx, 5))
        .expect("list the incidences");
    assert!(!admitted.0.is_empty());

    let class_text = admitted
        .0
        .iter()
        .filter_map(|incidence| incidence.source_entity.as_ref())
        .chain(
            admitted
                .1
                .iter()
                .filter_map(|incidence| incidence.source_entity.as_ref()),
        )
        .filter_map(super::super::CatiaEntityReference::class_name)
        .map(str::len)
        .sum::<usize>();
    let class_text = u64::try_from(class_text).expect("fixture text fits");
    assert!(class_text > 0);
    let charged =
        crate::test_support::with_retained_limit(class_text, |ctx| index.incidences(ctx, 5))
            .expect("the source class copies fit their own length");
    assert_eq!(charged, admitted);
    let error =
        crate::test_support::with_retained_limit(class_text - 1, |ctx| index.incidences(ctx, 5))
            .expect_err("each source class copy is charged before it is made");
    assert!(matches!(
        error,
        cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::RetainedBytes
                && limit.operation == "retain CATIA schema class text"
    ));
}

#[test]
fn derived_configuration_row_chains_match_decoded_chains() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_schema_configuration_row_chain());
    let classes = super::super::entity_class_index(
        native.object_graphs.iter().flat_map(|graph| &graph.records),
    );
    let (_, _, entities, terminal_nulls, _) =
        super::super::semantic_entity_indices(&native.entity_records, &classes)
            .expect("native semantic indices fit service limits");
    let references = super::super::CatiaEntityReferenceIndex {
        entities: &entities,
        classes: &classes,
        terminal_nulls: &terminal_nulls,
    };
    let derived = crate::test_support::with_service_context(|ctx| {
        super::super::derive_schema_configuration_row_chains(
            ctx,
            &native.entity_records,
            &references,
            native.object_graphs.iter().flat_map(|graph| &graph.records),
        )
    })
    .expect("derive the configuration row chains");
    assert_eq!(derived.bounded_links, 0);
    let chains = derived.chains;
    assert_eq!(chains, native.schema_configuration_row_chains);

    let links = chains
        .iter()
        .flat_map(super::super::CatiaSchemaConfigurationRowChain::links);
    let intervening = links
        .clone()
        .filter_map(|link| link.intervening_entities.as_ref())
        .flatten()
        .collect::<Vec<_>>();
    assert!(!intervening.is_empty());
    let class_text = links
        .map(|link| &link.row)
        .chain(intervening.iter().copied())
        .filter_map(super::super::CatiaEntityReference::class_name)
        .map(str::len)
        .sum::<usize>();
    let entity_text = intervening
        .iter()
        .filter_map(|reference| reference.entity())
        .map(str::len)
        .sum::<usize>();
    let retained = u64::try_from(class_text + entity_text).expect("fixture text fits");
    let derive_within = |limit| {
        crate::test_support::with_retained_limit(limit, |ctx| {
            super::super::derive_schema_configuration_row_chains(
                ctx,
                &native.entity_records,
                &references,
                native.object_graphs.iter().flat_map(|graph| &graph.records),
            )
        })
    };
    assert_eq!(
        derive_within(retained)
            .expect("the kept reference text fits its own length")
            .chains,
        chains
    );
    let error = derive_within(retained - 1).expect_err("every kept reference text is charged");
    assert!(matches!(
        error,
        cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::RetainedBytes
    ));
}

#[test]
fn configuration_row_links_past_the_intervening_allowance_keep_no_order() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_schema_configuration_row_chain());
    let classes = super::super::entity_class_index(
        native.object_graphs.iter().flat_map(|graph| &graph.records),
    );
    let (_, _, entities, terminal_nulls, _) =
        super::super::semantic_entity_indices(&native.entity_records, &classes)
            .expect("native semantic indices fit service limits");
    let references = super::super::CatiaEntityReferenceIndex {
        entities: &entities,
        classes: &classes,
        terminal_nulls: &terminal_nulls,
    };
    let derive_within = |allowance| {
        crate::test_support::with_service_context(|ctx| {
            super::super::schema_configuration_chain::derive_schema_configuration_row_chains_within(
                ctx,
                &native.entity_records,
                &references,
                native.object_graphs.iter().flat_map(|graph| &graph.records),
                allowance,
            )
        })
        .expect("a bounded link is a loss, not a refusal")
    };
    let intervening = |chains: &[super::super::CatiaSchemaConfigurationRowChain]| {
        chains
            .iter()
            .flat_map(super::super::CatiaSchemaConfigurationRowChain::links)
            .map(|link| link.intervening_entities.as_ref().map(Vec::len))
            .collect::<Vec<_>>()
    };
    let full = derive_within(3);
    assert_eq!(full.bounded_links, 0);
    assert_eq!(full.chains, native.schema_configuration_row_chains);
    assert_eq!(intervening(&full.chains), [Some(1), Some(1), Some(1)]);

    let bounded = derive_within(2);
    assert_eq!(bounded.bounded_links, 1);
    assert_eq!(intervening(&bounded.chains), [Some(1), Some(1), None]);
    assert_eq!(
        bounded.chains[0].terminal,
        native.schema_configuration_row_chains[0].terminal
    );

    let empty = derive_within(0);
    assert_eq!(empty.bounded_links, 3);
    assert_eq!(intervening(&empty.chains), [None, None, None]);
}

#[test]
fn semantic_indices_find_entities_in_configuration_row_chain() {
    let native =
        crate::native::CatiaNative::decode(&standard_catpart_with_schema_configuration_row_chain());
    let records = native
        .object_graphs
        .iter()
        .flat_map(|graph| &graph.records)
        .collect::<Vec<_>>();
    let classes = super::super::entity_class_index(records.iter().copied());
    assert!(!classes.is_empty());
    let admitted = super::super::semantic_entity_indices(&native.entity_records, &classes)
        .expect("compute the semantic entity indices");
    assert!(!admitted.2.is_empty());
}

#[test]
fn relation_signature_names_its_input_parameter() {
    let source = "(#1_ : #In Length) : Real\n";
    let service = super::super::relation_type_signature(None, source).expect("valid signature");
    assert_eq!(service.inputs[0].parameter, "#1_");
}

#[test]
fn configuration_entity_produces_a_schema_configuration_record() {
    let file = standard_catpart_with_configuration_incidences(8, 5, 7);
    let native = crate::native::CatiaNative::decode(&file);
    let graph = &native.object_graphs[0];
    let configuration_entity = &native.entity_records[0];
    let configuration_object = graph
        .records
        .iter()
        .find(|record| record.id == configuration_entity.object_record)
        .expect("configuration object record");

    let classes = super::super::entity_class_index(graph.records.iter());
    let (expressions, expression_entities, entities, terminal_nulls, bindings) =
        super::super::semantic_entity_indices(&native.entity_records, &classes)
            .expect("compute the semantic entity indices");
    let references = super::super::CatiaEntityReferenceIndex {
        entities: &entities,
        classes: &classes,
        terminal_nulls: &terminal_nulls,
    };
    let service = crate::test_support::with_service_context(|ctx| {
        super::super::object_production(
            ctx,
            configuration_entity,
            configuration_object,
            &references,
            &expressions,
            &expression_entities,
            &mut super::super::RelationDependencies::new(&bindings, usize::MAX),
        )
    })
    .expect("select the configuration object production");
    assert!(matches!(
        service,
        Some(crate::native::CatiaEntityObjectProduction::SchemaConfigurationRecord(_))
    ));
}

#[test]
fn decode_links_value_block_graph_to_its_catalog() {
    let bytes = standard_catpart_with_value_block();
    let native = crate::test_support::with_service_context(|ctx| {
        super::super::CatiaNative::decode_with_record_sources(
            ctx,
            &bytes,
            &[],
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("decode the native namespace");
    assert!(native.object_graphs[0].catalog.is_some());
}
