// SPDX-License-Identifier: Apache-2.0
//! Native-namespace tests for consolidated family layouts.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]
use cadmpeg_core::decode::u64_from_index;

use cadmpeg_test_support::wire;

use cadmpeg_ir::geometry::{SolvedCurveGeometry, SolvedSurfaceGeometry};

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};

use crate::native::owner_chart::{
    CatiaOwnerChartAddress, CatiaOwnerChartBridge, CatiaOwnerChartCarrier, CatiaOwnerChartSideAxis,
};
use crate::test_support::test_a5_bound::{
    a5_native_edge_run_stream, a5_sphere_bound_edge_stream, a5_torus_bound_edge_stream,
};
use crate::test_support::test_a5a8::{a5_native_edge_identity_stream, a5_pcurve_stream};
use crate::test_support::test_b2::{
    b2_adjacent_face_counted_owner_stream, b2_adjacent_face_owner_stream,
    b2_chamfer_contact_stream, b2_chamfer_stream, b2_circle_stream, b2_class5b5c_stream,
    b2_class60_reference_stream, b2_cone_stream, b2_counted_61_stream, b2_cylinder_stream,
    b2_edge_node_stream, b2_fixed_owner_boundary_cycle_stream,
    b2_fixed_owner_boundary_face_node_cycle_stream, b2_implicit_axis_cylinder_stream,
    b2_line_profile_stream, b2_owner_chart_stream, b2_parameter_point_stream, b2_pcurve_stream,
    b2_plane_carrier_stream, b2_range_origin_cylinder_stream, b2_reference_list_stream,
    b2_resolved_revolution_stream, b2_sphere_stream, b2_torus_stream,
    b2_width_coded_owner_with_allocation_stream, class61_false_long_stream,
};
use crate::test_support::test_bytes::{be32, le_f64};
use crate::test_support::test_container::{
    grouped_surface_alias_stream, standard_catpart, surface_alias_stream,
};
use crate::CatiaCodec;

#[test]
fn native_namespace_retains_unbound_consolidated_pcurve_jets() {
    let mut bytes = Vec::new();
    for _ in 0..6 {
        bytes.extend(a5_pcurve_stream());
        bytes.extend(b2_pcurve_stream());
    }
    let native = crate::native::CatiaNative::decode(&bytes);

    assert_eq!(native.consolidated_pcurves.len(), 12);
    assert_eq!(
        native.consolidated_pcurves[0].family,
        crate::native::CatiaConsolidatedFamily::A
    );
    assert_eq!(
        native.consolidated_pcurves[1].family,
        crate::native::CatiaConsolidatedFamily::B
    );
    assert_eq!(native.consolidated_pcurves[0].support_id, 0x1234);
    assert_eq!(
        native.consolidated_pcurves[0].points,
        vec![[0.0, 0.0], [1.0, 1.0]]
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA pcurves");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA pcurves"),
        native
    );

    let mut invalid = native;
    invalid.consolidated_pcurves[0].degree = 4;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA pcurve for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_counted_class60_references() {
    let native = crate::native::CatiaNative::decode(&b2_class60_reference_stream());
    let [record] = native.consolidated_class60_records.as_slice() else {
        panic!("one counted class-0x60 record")
    };
    assert_eq!(record.frame.pos, 9);
    assert_eq!(record.source_offset, 9);
    assert_eq!(record.references[0].value, 3);
    assert_eq!(
        record.references[0].encoding,
        crate::native::CatiaAllocationReferenceEncoding::BackwardDistance
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA class-0x60 records");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA class-0x60 records"),
        native
    );

    let mut invalid = native;
    invalid.consolidated_class60_records[0]
        .id
        .push_str("-changed");
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid class-0x60 record for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_counted_class61_members_and_refuses_false_long_fixture() {
    let mut stream = b2_counted_61_stream();
    stream.extend_from_slice(&class61_false_long_stream());
    let native = crate::native::CatiaNative::decode(&stream);
    let [counted] = native.consolidated_class61_records.as_slice() else {
        panic!("one complete counted roster; the manufactured long fixture does not close")
    };
    assert_eq!(
        counted
            .members
            .iter()
            .map(|member| member.value)
            .collect::<Vec<_>>(),
        [1300, 1294, 30, 74]
    );
    assert_eq!(
        &counted.frame.payload[counted.frame.payload.len() - 2..],
        &[0x41, 0x03]
    );
    assert_eq!(counted.roster_control, 1);
    assert_eq!(
        counted
            .members
            .iter()
            .map(|member| member.orientation_bit)
            .collect::<Vec<_>>(),
        [false, false, true, false]
    );
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA counted roster");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA counted roster"),
        native
    );
    let mut invalid = native;
    invalid.consolidated_class61_records[0].members[0].orientation_bit = true;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid occurrence bit for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_class5b5c_control_records_without_assigning_roles() {
    let native = crate::native::CatiaNative::decode(&b2_class5b5c_stream());
    let records = &native.consolidated_class5b5c_records;
    assert_eq!(records.len(), 3);
    assert_eq!(
        records
            .iter()
            .map(|record| u8::from(record.class))
            .collect::<Vec<_>>(),
        [0x5b, 0x5c, 0x5b]
    );
    assert_eq!(records[0].source_index, 0);
    assert_eq!(records[0].source_offset, records[0].frame.pos);
    assert_eq!(
        records[1].frame.width(),
        crate::wire::records::ConsolidatedFrameWidth::Two
    );
    assert!(records
        .iter()
        .all(|record| !record.frame.payload.is_empty()));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA class-0x5b/0x5c records");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA class-0x5b/0x5c records"),
        native
    );
}

#[test]
fn native_namespace_retains_all_consolidated_parameter_point_layouts() {
    let native = crate::native::CatiaNative::decode(&b2_parameter_point_stream());
    let [two_scalars, three_scalars, five_scalars, last_three_scalars] =
        native.consolidated_parameter_points.as_slice()
    else {
        panic!("four consolidated parameter points")
    };
    assert_eq!(
        [
            two_scalars.operand.value(),
            three_scalars.operand.value(),
            five_scalars.operand.value(),
            last_three_scalars.operand.value()
        ],
        [1, 2, 3, 4]
    );
    assert_eq!(two_scalars.payload.byte_len(two_scalars.operand), 0x12);
    assert_eq!(two_scalars.control, 0x12);
    assert!(matches!(
        &two_scalars.payload,
        crate::families::b2::records::B2ParameterPointPayload::TwoScalars { values } if *values == [2.0, 3.0]
    ));
    assert_eq!(three_scalars.payload.byte_len(three_scalars.operand), 0x1a);
    assert!(matches!(
        &three_scalars.payload,
        crate::families::b2::records::B2ParameterPointPayload::ThreeScalars { values } if *values == [11.0, 4.0, 5.0]
    ));
    assert_eq!(five_scalars.payload.byte_len(five_scalars.operand), 0x2a);
    assert!(matches!(
        &five_scalars.payload,
        crate::families::b2::records::B2ParameterPointPayload::FiveScalars { values }
            if *values == [-1.0, 2.0, 3.0, 0.6, 0.8]
    ));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA parameter points");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA parameter points"),
        native
    );
}

#[test]
fn consolidated_parameter_point_wire_rejects_contradictory_controls() {
    let native = crate::native::CatiaNative::decode(&b2_parameter_point_stream());
    for (index, control) in [(0, 0x01), (1, 0x08), (2, 0x48)] {
        let mut wire = serde_json::to_value(&native.consolidated_parameter_points[index])
            .expect("serialize parameter point");
        wire["control"] = serde_json::json!(control);
        assert!(
            serde_json::from_value::<crate::native::CatiaConsolidatedParameterPoint>(wire).is_err()
        );
    }
    let mut wire = serde_json::to_value(&native.consolidated_parameter_points[2])
        .expect("serialize explicit line");
    wire["payload"]["values"][3] = serde_json::json!(2.0);
    assert!(
        serde_json::from_value::<crate::native::CatiaConsolidatedParameterPoint>(wire).is_err()
    );
}

#[test]
fn parameter_operand_native_round_trip_preserves_all_compact_widths() {
    let native = crate::native::CatiaNative::decode(
        &crate::test_support::test_b2::b2_compact_parameter_operand_stream(),
    );
    assert_eq!(
        native
            .consolidated_parameter_points
            .iter()
            .map(|p| p.operand.value())
            .collect::<Vec<_>>(),
        [220, 65_390, 1_727_824, u32::MAX, 1]
    );
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store compact parameter operands");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load compact parameter operands"),
        native
    );
    for (encoding, invalid) in [
        ("inline", 64),
        ("u8", 256),
        ("u16", 65536),
        ("u24", 0x0100_0000),
    ] {
        let mut wire = serde_json::to_value(&native.consolidated_parameter_points[0]).unwrap();
        wire["operand"] = serde_json::json!({"value":invalid,"encoding":encoding});
        assert!(
            serde_json::from_value::<crate::native::CatiaConsolidatedParameterPoint>(wire).is_err()
        );
    }
    let mut wire = serde_json::to_value(&native.consolidated_parameter_points[0]).unwrap();
    wire["byte_len"] = serde_json::json!(5);
    assert!(
        serde_json::from_value::<crate::native::CatiaConsolidatedParameterPoint>(wire).is_err()
    );
}

#[test]
fn native_namespace_retains_all_consolidated_plane_carrier_layouts() {
    let plane_stream = b2_plane_carrier_stream();
    let native = crate::native::CatiaNative::decode(&plane_stream);
    let [direction2, direction3, tail] = native.consolidated_plane_carriers.as_slice() else {
        panic!("three consolidated plane carriers")
    };
    assert_eq!(
        [
            direction2.payload.selector(),
            direction3.payload.selector(),
            tail.payload.selector()
        ],
        [0xe4, 0xc4, 0xec]
    );
    for (carrier, u_bounds) in [
        (direction2, [0.0, 5.0]),
        (direction3, [0.0, 5.0]),
        (tail, [-2.0, 5.0]),
    ] {
        assert!(
            matches!(&carrier.payload, crate::families::b2::records::B2PlaneCarrierPayload::Plane {
            point, direction, u_range, v_range, ..
        } if *point == [10.0,20.0] && direction.get() == [1.0,0.0,0.0]
            && u_range.endpoints() == u_bounds && v_range.endpoints() == [-2.0,3.0])
        );
    }

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA plane carriers");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA plane carriers"),
        native
    );

    let mut file = standard_catpart();
    file.splice(16..16, plane_stream);
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode CATIA plane carrier coverage");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_PLANE_CARRIER_COUNT.as_str()
        ),
        3
    );
}

#[test]
fn native_namespace_retains_unclassified_consolidated_plane_carrier_lanes() {
    let mut stream = b2_plane_carrier_stream();
    let values = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
    stream.extend_from_slice(&[
        0xb2,
        0x03,
        0x27,
        2 + u8::try_from(values.len() * 8).expect("scalar lane fixture"),
        0x05,
        0xb4,
        0x40,
    ]);
    for value in values {
        stream.extend_from_slice(&le_f64(value));
    }

    let native = crate::native::CatiaNative::decode(&stream);
    let Some(carrier) = native.consolidated_plane_carriers.get(3) else {
        panic!("unclassified consolidated plane carrier")
    };
    assert_eq!(carrier.payload.selector(), 0x40);
    assert!(matches!(
        &carrier.payload,
        crate::families::b2::records::B2PlaneCarrierPayload::ScalarLane { values: lane, .. }
            if cadmpeg_ir::scalar::FiniteReal::raw_lane(lane) == values
    ));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store unclassified plane carrier");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load unclassified plane carrier"),
        native
    );
}

#[test]
fn native_namespace_retains_consolidated_reference_lists() {
    let native = crate::native::CatiaNative::decode(&b2_reference_list_stream());
    let [list] = native.consolidated_reference_lists.as_slice() else {
        panic!("one consolidated reference list")
    };
    assert_eq!(list.references, (0u32..26).collect::<Vec<_>>());

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA reference list");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA reference list"),
        native
    );

    let mut invalid = native;
    invalid.consolidated_reference_lists[0].references.clear();
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA reference list");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_standalone_consolidated_circle_supports() {
    let native = crate::native::CatiaNative::decode(&b2_circle_stream());
    let [circle] = native.consolidated_circles.as_slice() else {
        panic!("one consolidated circle")
    };
    assert_eq!(circle.layout, crate::native::CatiaCircleLayout::Word);
    assert_eq!(circle.record_id, 0x1234);
    assert_eq!(circle.frame_token, 0x05);
    assert_eq!(
        circle.center_pair,
        crate::test_support::test_b5::finite_vector([4.0, -2.0])
    );
    assert_eq!(circle.radius.get(), 3.0);
    assert_eq!(
        circle.range.endpoints(),
        [0.0, std::f64::consts::TAU * circle.radius.get()]
    );
    assert!(circle.full_circle());
    assert_eq!(
        circle.chart_shift,
        crate::test_support::test_b5::finite(0.0)
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA circle");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA circle"),
        native
    );
}

#[test]
fn consolidated_circle_borrowed_wire_preserves_json_bytes() {
    let native = crate::native::CatiaNative::decode(&b2_circle_stream());
    let [circle] = native.consolidated_circles.as_slice() else {
        panic!("one consolidated circle")
    };
    let owned: crate::native::CatiaConsolidatedCircleWire = circle.clone().into();
    assert_eq!(
        serde_json::to_vec(circle).expect("borrowed circle JSON"),
        serde_json::to_vec(&owned).expect("owned circle JSON")
    );
}

#[test]
fn consolidated_circle_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&b2_circle_stream());
    let [circle] = native.consolidated_circles.as_slice() else {
        panic!("one consolidated circle")
    };
    let json_len = serde_json::to_vec(circle).expect("circle JSON").len();
    let arena_name = "consolidated_circles";
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(circle))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(circle))
            .expect("store the native arena");
    });
}

#[test]
fn consolidated_parameter_point_borrowed_wire_preserves_json_bytes() {
    let native = crate::native::CatiaNative::decode(&b2_parameter_point_stream());
    for point in &native.consolidated_parameter_points {
        let owned: crate::native::CatiaConsolidatedParameterPointWire = point.clone().into();
        assert_eq!(
            serde_json::to_vec(point).expect("borrowed parameter point JSON"),
            serde_json::to_vec(&owned).expect("owned parameter point JSON")
        );
    }
    assert!(!native.consolidated_parameter_points.is_empty());
}

#[test]
fn consolidated_parameter_point_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&b2_parameter_point_stream());
    let point = native
        .consolidated_parameter_points
        .first()
        .expect("parameter point");
    let arena_name = "consolidated_parameter_points";
    let json_len = serde_json::to_vec(point)
        .expect("parameter point JSON")
        .len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(point))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(point))
            .expect("store the native arena");
    });
}

#[test]
fn consolidated_plane_carrier_borrowed_wire_preserves_json_bytes() {
    let native = crate::native::CatiaNative::decode(&b2_plane_carrier_stream());
    for carrier in &native.consolidated_plane_carriers {
        let owned: crate::native::CatiaConsolidatedPlaneCarrierWire = carrier.clone().into();
        assert_eq!(
            serde_json::to_vec(carrier).expect("borrowed plane carrier JSON"),
            serde_json::to_vec(&owned).expect("owned plane carrier JSON")
        );
    }
    assert!(!native.consolidated_plane_carriers.is_empty());
}

#[test]
fn consolidated_plane_carrier_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&b2_plane_carrier_stream());
    let carrier = native
        .consolidated_plane_carriers
        .first()
        .expect("plane carrier");
    let arena_name = "consolidated_plane_carriers";
    let json_len = serde_json::to_vec(carrier)
        .expect("plane carrier JSON")
        .len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(carrier))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(carrier))
            .expect("store the native arena");
    });
}

#[test]
fn consolidated_cylinder_borrowed_wire_preserves_json_bytes() {
    let mut stream = b2_cylinder_stream();
    stream.extend_from_slice(&b2_implicit_axis_cylinder_stream());
    stream.extend_from_slice(&b2_range_origin_cylinder_stream());
    let native = crate::native::CatiaNative::decode(&stream);
    for cylinder in &native.consolidated_cylinders {
        let owned: crate::native::CatiaConsolidatedCylinderWire = cylinder.clone().into();
        assert_eq!(
            serde_json::to_vec(cylinder).expect("borrowed cylinder JSON"),
            serde_json::to_vec(&owned).expect("owned cylinder JSON")
        );
    }
    assert!(!native.consolidated_cylinders.is_empty());
}

#[test]
fn consolidated_cylinder_retained_limit_refuses_json_record() {
    let native = crate::native::CatiaNative::decode(&b2_cylinder_stream());
    let cylinder = native.consolidated_cylinders.first().expect("cylinder");
    let arena_name = "consolidated_cylinders";
    let json_len = serde_json::to_vec(cylinder).expect("cylinder JSON").len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(cylinder))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(cylinder))
            .expect("store the native arena");
    });
}

#[test]
fn consolidated_owner_packet_borrowed_wire_preserves_json_bytes() {
    for bytes in [
        crate::test_support::test_b2::b2_owner_packet_stream(),
        b2_adjacent_face_counted_owner_stream(),
    ] {
        let native = crate::native::CatiaNative::decode(&bytes);
        let packet = native
            .consolidated_owner_packets
            .first()
            .expect("owner packet");
        let owned: crate::native::CatiaConsolidatedOwnerPacketWire = packet.clone().into();
        assert_eq!(
            serde_json::to_vec(packet).expect("borrowed packet JSON"),
            serde_json::to_vec(&owned).expect("owned packet JSON")
        );
    }
}

#[test]
fn consolidated_owner_packet_retained_limit_refuses_json_record() {
    let native =
        crate::native::CatiaNative::decode(&crate::test_support::test_b2::b2_owner_packet_stream());
    let packet = native
        .consolidated_owner_packets
        .first()
        .expect("owner packet");
    let arena_name = "consolidated_owner_packets";
    let json_len = serde_json::to_vec(packet).expect("packet JSON").len();
    let limit = u64::try_from(json_len - 1).expect("small JSON");
    let refused = crate::test_support::with_retained_limit(limit, |ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace.set_arena(ctx, arena_name, std::slice::from_ref(packet))
    });
    let error = refused.expect_err("record exceeds retained-byte limit");
    assert!(error.to_string().contains("RetainedBytes"), "{error}");
    crate::test_support::with_service_context(|ctx| {
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        namespace
            .set_arena(ctx, arena_name, std::slice::from_ref(packet))
            .expect("store the native arena");
    });
}

#[test]
fn consolidated_circle_deserialization_rejects_mismatched_full_circle() {
    let native = crate::native::CatiaNative::decode(&b2_circle_stream());
    let [circle] = native.consolidated_circles.as_slice() else {
        panic!("one consolidated circle")
    };
    let mut wire = serde_json::to_value(circle).expect("serialize CATIA circle");
    let full_circle = wire["full_circle"]
        .as_bool()
        .expect("serialized circle flag");
    wire["full_circle"] = serde_json::json!(!full_circle);

    let error = serde_json::from_value::<crate::native::CatiaConsolidatedCircle>(wire)
        .expect_err("full_circle mismatch must fail admission");
    assert!(error.to_string().contains("full_circle"), "{error}");
}

#[test]
fn native_namespace_retains_all_consolidated_cylinder_layouts() {
    let mut stream = b2_cylinder_stream();
    stream.extend_from_slice(&b2_implicit_axis_cylinder_stream());
    stream.extend_from_slice(&b2_range_origin_cylinder_stream());
    let native = crate::native::CatiaNative::decode(&stream);
    let [explicit, implicit, range_origin] = native.consolidated_cylinders.as_slice() else {
        panic!("three consolidated cylinders")
    };
    assert_eq!(explicit.payload.layout(), 0x5a);
    assert_eq!(
        explicit.origin,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(explicit.radius.get(), 2.0);
    assert!(matches!(
        explicit.payload,
        crate::native::CatiaConsolidatedCylinderPayload::Layout5a {
            frame_token: 0x19,
            axis,
            reference_direction,
        } if axis.get() == [1.0, 0.0, 0.0] && reference_direction.get() == [0.0, 1.0, 0.0]
    ));
    assert_eq!(implicit.payload.layout(), 0x52);
    assert!(matches!(
        implicit.payload,
        crate::native::CatiaConsolidatedCylinderPayload::Layout52 { .. }
    ));
    assert_eq!(range_origin.payload.layout(), 0x62);
    assert_eq!(range_origin.radius.get(), 4.0);
    assert!(matches!(
        range_origin.payload,
        crate::native::CatiaConsolidatedCylinderPayload::RangeOrigin {
            stored_vector,
            axis,
            reference_direction,
            range_origin,
        } if stored_vector.get() == [0.0, 1.0]
            && axis.get() == [0.0, 1.0, 0.0]
            && reference_direction.get() == [0.0, 0.0, 1.0]
            && range_origin.to_bits()
                == ((0.0 + 8.0) * 0.5 - std::f64::consts::PI * 4.0).to_bits()
    ));

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA cylinders");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA cylinders"),
        native
    );

    let mut invalid = native;
    let crate::native::CatiaConsolidatedCylinderPayload::RangeOrigin { range_origin, .. } =
        &mut invalid.consolidated_cylinders[2].payload
    else {
        panic!("range-origin cylinder")
    };
    *range_origin += 1.0;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA cylinder for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_exact_consolidated_cone_charts() {
    let native = crate::native::CatiaNative::decode(&b2_cone_stream());
    let [cone] = native.consolidated_cones.as_slice() else {
        panic!("one consolidated cone")
    };
    assert_eq!(
        cone.apex,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(cone.direction_x.get(), [1.0, 0.0, 0.0]);
    assert_eq!(cone.direction_y.get(), [0.0, 1.0, 0.0]);
    assert_eq!(cone.axis.get(), [0.0, 0.0, 1.0]);
    assert_eq!(cone.half_angle.get(), 0.25);
    assert_eq!(
        cone.reference_radius,
        crate::test_support::test_b5::finite(4.0)
    );
    assert_eq!(
        cone.angular_range,
        crate::test_support::test_b5::increasing([0.5, 0.5 + std::f64::consts::PI])
    );
    assert_eq!(cone.slant_range.endpoints(), [2.0, 8.0]);
    assert_eq!(cone.angular_scale.get(), 3.0);
    assert_eq!(
        cone.angular_domain,
        crate::test_support::test_b5::increasing([
            0.5 - std::f64::consts::FRAC_PI_2,
            0.5 + 3.0 * std::f64::consts::FRAC_PI_2
        ])
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA cone");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA cone"),
        native
    );

    let mut invalid = native;
    let [lower, upper] = invalid.consolidated_cones[0].angular_domain.endpoints();
    invalid.consolidated_cones[0].angular_domain =
        crate::test_support::test_b5::increasing([lower + 0.25, upper]);
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA cone for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_two_support_chamfers() {
    let native = crate::native::CatiaNative::decode(&b2_chamfer_contact_stream());
    let [face] = native.consolidated_chamfers.as_slice() else {
        panic!("one compact chamfer")
    };
    assert_eq!(
        face.support_surfaces
            .map(crate::wire::compact_unsigned::CompactUnsigned::value),
        [1407, 788]
    );
    assert_eq!(
        face.support_pcurves
            .map(crate::wire::compact_unsigned::CompactUnsigned::value),
        [57, 55]
    );
    assert_eq!(
        face.parameters.result_kind,
        crate::families::chamfer::ChamferResultKind::Cone
    );
    assert!(
        matches!(face.parameters.definition, crate::families::chamfer::ChamferDefinition::LengthAngle { length1, .. } if length1.get() == 1.5)
    );
    assert_eq!(
        face.parameter_points,
        [
            "catia:consolidated:parameter-point#0",
            "catia:consolidated:parameter-point#1",
            "catia:consolidated:parameter-point#2",
            "catia:consolidated:parameter-point#3",
        ]
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA chamfer");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA chamfer"),
        native
    );

    let mut invalid = native.clone();
    invalid.consolidated_chamfers[0].byte_len += 1;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA chamfer");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut invalid = native.clone();
    invalid.consolidated_chamfers[0].parameter_points.swap(0, 1);
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA chamfer contact run");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut mixed = b2_chamfer_contact_stream();
    mixed.extend_from_slice(&[0xb2, 0x03, 0x18, 0x02, 0x05, 0x99, 0x99]);
    let mixed = crate::native::CatiaNative::decode(&mixed);
    assert_eq!(mixed.consolidated_chamfers[0].parameter_points.len(), 4);

    let mut file = standard_catpart();
    file.splice(16..16, b2_chamfer_contact_stream());
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode CATIA chamfer");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_CHAMFER_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_CHAMFER_PARAMETER_POINT_COUNT.as_str()
        ),
        4
    );
}

#[test]
fn consolidated_revolution_wire_rejects_directions_outside_the_exact_tolerance() {
    let native = crate::native::CatiaNative::decode(&b2_resolved_revolution_stream());
    let [revolution] = native.consolidated_revolutions.as_slice() else {
        panic!("one consolidated revolution carrier")
    };
    let mut wire = serde_json::to_value(revolution).expect("serialize CATIA revolution");
    let off_axis = (1.0_f64 + 5.0e-10).sqrt();
    wire["axis"] = serde_json::json!([0.0, 0.0, off_axis]);
    let error = serde_json::from_value::<crate::native::CatiaConsolidatedRevolution>(wire)
        .expect_err(
            "an axis outside the exact squared-length tolerance is not a revolution direction",
        );
    assert!(error.to_string().contains("unit vector"));
}

#[test]
fn native_namespace_retains_resolved_consolidated_revolution_carriers() {
    let native = crate::native::CatiaNative::decode(&b2_resolved_revolution_stream());
    let [revolution] = native.consolidated_revolutions.as_slice() else {
        panic!("one consolidated revolution carrier")
    };
    assert_eq!(
        revolution.reference_token,
        crate::native::CatiaRevolutionReferenceToken::Lead0a
    );
    assert_eq!(revolution.profile_reference, 0x1234);
    assert_eq!(
        revolution.origin,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(revolution.direction_x.get(), [1.0, 0.0, 0.0]);
    assert_eq!(revolution.direction_y.get(), [0.0, 1.0, 0.0]);
    assert_eq!(revolution.axis.get(), [0.0, 0.0, 1.0]);
    assert_eq!(revolution.profile_range.endpoints(), [-4.0, 9.0]);
    assert_eq!(
        revolution.profile_circle.as_deref(),
        Some("catia:consolidated:circle#0")
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA revolution");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA revolution"),
        native
    );

    let mut invalid = native.clone();
    invalid.consolidated_revolutions[0].profile_circle = None;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA revolution profile binding");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut invalid = native;
    invalid.consolidated_revolutions[0].axis =
        crate::checked::ExactUnitVector3::new([0.0, 0.0, -1.0]).expect("unit axis");
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA revolution for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut file = standard_catpart();
    file.splice(16..16, b2_resolved_revolution_stream());
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode resolved CATIA revolution");
    let directrix = decoded
        .ir()
        .geometry
        .curves
        .iter()
        .find(|curve| {
            curve
                .id
                .as_str()
                .starts_with("catia:consolidated:surface-revolution-directrix#")
        })
        .expect("transferred revolution directrix");
    assert!(
        matches!(directrix.geometry, cadmpeg_ir::geometry::CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))
                if {
                    let center = circle_curve.center().get();
        let axis = circle_curve.frame().axis().as_raw();
        let ref_direction = circle_curve.frame().reference().as_raw();
                    (circle_curve.radius().get() == 3.0)
                        && (center == cadmpeg_ir::math::Point3::new(1.0, 4.0, -2.0)
                            && *axis == cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0)
                            && *ref_direction == cadmpeg_ir::math::Vector3::new(0.0, 1.0, 0.0))
                })
    );
    let revolution = decoded
        .ir()
        .geometry
        .procedural_surfaces
        .iter()
        .find(|surface| {
            surface
                .id
                .as_str()
                .starts_with("catia:consolidated:surface-revolution#")
        })
        .expect("transferred revolution construction");
    assert!(decoded.ir().geometry.surfaces.iter().any(|surface| {
        decoded.ir().geometry.procedural_surface_owner(&revolution.id) == Some(&surface.id)
            && surface.source_object.is_none()
            && matches!(surface.geometry.solved_cache(), Some(SolvedSurfaceGeometry::Torus(torus_surface))
                    if {
                        let center = torus_surface.center();
                        let axis = torus_surface.frame().axis().as_raw();
                        let ref_direction = torus_surface.frame().reference().as_raw();
                        (torus_surface.major_radius().get() == 2.0)
                            && (torus_surface.minor_radius().get() == 3.0)
                            && (*center == cadmpeg_ir::math::Point3::new(1.0, 2.0, -2.0)
                                && *axis == cadmpeg_ir::math::Vector3::new(0.0, 0.0, 1.0)
                                && *ref_direction == cadmpeg_ir::math::Vector3::new(0.0, 1.0, 0.0))
                    })
    }));
    assert!(
        cadmpeg_ir::validate::validate_neutral(decoded.ir(), Vec::new())
            .expect("validate the neutral model")
            .is_ok()
    );
    assert!(match revolution.definition() {
        cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Revolution(matched_payload) => matches!(
            (
                matched_payload.angular_interval().endpoints(),
                &matched_payload.parameter_interval().map(
                    cadmpeg_ir::topology::IncreasingParameterInterval::endpoints
                ),
            ),
            (angular_interval, Some([-4.0, 9.0]),)
                if angular_interval == [0.5, 0.5 + std::f64::consts::TAU]
        ),
        _ => false,
    });
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_CONSOLIDATED_REVOLUTION_COUNT.as_str()
        ),
        1
    );
    assert!(!decoded.report().losses.iter().any(|loss| loss
        .message
        .contains("consolidated surface-of-revolution record")));
}

#[test]
fn native_namespace_retains_exact_consolidated_line_profiles() {
    let native = crate::native::CatiaNative::decode(&b2_line_profile_stream());
    let [line] = native.consolidated_line_profiles.as_slice() else {
        panic!("one consolidated line profile")
    };
    assert_eq!(
        line.origin,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(line.direction.get(), [0.0, 0.6, 0.8]);
    assert_eq!(line.range.endpoints(), [-4.0, 9.0]);

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA line profile");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA line profile"),
        native
    );
}

#[test]
fn consolidated_cylinder_frames_round_trip_at_the_stored_pair_tolerance_edge() {
    let component = 1.0_f64 + 6.0e-10;
    let mut stream = b2_cylinder_stream();
    stream[30..38].copy_from_slice(&component.to_le_bytes());
    stream[38..46].copy_from_slice(&0.0_f64.to_le_bytes());
    let native = crate::native::CatiaNative::decode(&stream);
    let [cylinder] = native.consolidated_cylinders.as_slice() else {
        panic!("one consolidated cylinder at the tolerance edge")
    };
    let crate::native::CatiaConsolidatedCylinderPayload::Layout5a { axis, .. } = cylinder.payload
    else {
        panic!("layout 0x5a frame")
    };
    assert_eq!(axis.get(), [component, 0.0, 0.0]);

    let wire = serde_json::to_value(cylinder).expect("serialize CATIA cylinder");
    assert_eq!(
        &serde_json::from_value::<crate::native::CatiaConsolidatedCylinder>(wire)
            .expect("a decoded frame deserializes wherever its stored pair was admitted"),
        cylinder
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA cylinder");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA cylinder"),
        native
    );
}

#[test]
fn native_namespace_retains_exact_consolidated_torus_charts() {
    let native = crate::native::CatiaNative::decode(&b2_torus_stream());
    let [torus] = native.consolidated_tori.as_slice() else {
        panic!("one consolidated torus")
    };
    assert_eq!(
        torus.center,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(torus.direction_x.get(), [1.0, 0.0, 0.0]);
    assert_eq!(torus.direction_y.get(), [0.0, 1.0, 0.0]);
    assert_eq!(torus.axis.get(), [0.0, 0.0, 1.0]);
    assert_eq!(torus.major_radius.get(), 7.0);
    assert_eq!(torus.minor_radius.get(), 2.0);
    assert_eq!(
        torus.major_angular_range,
        crate::test_support::test_b5::increasing([
            std::f64::consts::FRAC_PI_2,
            3.0 * std::f64::consts::FRAC_PI_2
        ])
    );
    assert_eq!(
        torus.major_angular_domain,
        crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU])
    );
    assert_eq!(
        torus.minor_angular_range,
        crate::test_support::test_b5::increasing([0.0, std::f64::consts::PI])
    );
    assert_eq!(
        torus.minor_angular_domain,
        crate::test_support::test_b5::increasing([
            -std::f64::consts::FRAC_PI_2,
            3.0 * std::f64::consts::FRAC_PI_2
        ])
    );
    assert_eq!(torus.major_scale.get(), 14.0);
    assert_eq!(torus.minor_scale.get(), 4.0);

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA torus");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA torus"),
        native
    );

    let mut invalid = native;
    let [lower, upper] = invalid.consolidated_tori[0]
        .major_angular_domain
        .endpoints();
    invalid.consolidated_tori[0].major_angular_domain =
        crate::test_support::test_b5::increasing([lower + 0.25, upper]);
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA torus for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn native_namespace_retains_exact_consolidated_sphere_charts() {
    let native = crate::native::CatiaNative::decode(&b2_sphere_stream());
    let [sphere] = native.consolidated_spheres.as_slice() else {
        panic!("one consolidated sphere")
    };
    assert_eq!(
        sphere.center,
        crate::test_support::test_b5::finite_vector([1.0, 2.0, 3.0])
    );
    assert_eq!(sphere.direction_x.get(), [1.0, 0.0, 0.0]);
    assert_eq!(sphere.direction_y.get(), [0.0, 1.0, 0.0]);
    assert_eq!(sphere.axis.get(), [0.0, 0.0, 1.0]);
    assert_eq!(sphere.radius.get(), 5.0);
    assert_eq!(
        sphere.azimuth_range,
        crate::test_support::test_b5::increasing([-2.0, 4.0])
    );
    assert_eq!(
        sphere.latitude_range,
        crate::test_support::test_b5::increasing([-1.0, std::f64::consts::FRAC_PI_2])
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA sphere");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA sphere"),
        native
    );

    // A sphere holds its admitted increasing latitude range, so a reversed
    // range is refused before a native record can hold it.
    let [lower, upper] = native.consolidated_spheres[0].latitude_range.endpoints();
    assert!(cadmpeg_ir::topology::IncreasingParameterInterval::new([upper, lower]).is_none());
}

#[test]
fn native_namespace_retains_consolidated_owner_packet_and_face_node_relation() {
    let native = crate::native::CatiaNative::decode(&b2_adjacent_face_owner_stream());
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    assert_eq!(packet.source_index, 0);
    assert!(packet.identity_targets().is_empty());
    let crate::native::CatiaOwnerPacketPayload::FixedNine {
        references,
        identity_encodings,
        numeric_tail,
        ..
    } = &packet.payload
    else {
        panic!("fixed-nine owner payload")
    };
    assert_eq!(*references, [1000, 1, 1001, 2, 1002, 3, 1003, 4, 1004]);
    assert_eq!(
        *identity_encodings,
        std::array::from_fn(
            |index| crate::native::CatiaOwnerIdentityEncoding::Allocation(if index % 2 == 0 {
                crate::native::CatiaAllocationReferenceEncoding::TaggedU16
            } else {
                crate::native::CatiaAllocationReferenceEncoding::BackwardDistance
            },)
        )
    );
    assert_eq!(numeric_tail.header(), [0x84, 0x41, 0xbb, 0x05, 0x0d]);
    assert_eq!(numeric_tail.lower(), [-0.0, 4.5]);
    assert_eq!(numeric_tail.upper(), [12.25, 7.0]);
    assert_eq!(
        numeric_tail.bounds(),
        [[-2.0, 1.0], [3.5, 4.0], [5.25, 6.0]]
    );
    let face_node = packet.face_node.as_ref().expect("face-node relation");
    assert_eq!(packet.source_offset - face_node.source_offset, 11);
    assert_eq!(
        face_node.target_encoding,
        crate::native::CatiaFaceNodeTargetEncoding::Compact
    );
    assert_eq!(face_node.target, 1003);
    assert_eq!(face_node.terminal, [0x03, 0x05]);
    assert_eq!(face_node.target + 1, references[8]);

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA owner packet");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA owner packet"),
        native
    );

    let mut invalid = native;
    invalid.consolidated_owner_packets[0]
        .face_node
        .as_mut()
        .expect("face-node relation")
        .target -= 1;
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut namespace)
        .expect("store invalid CATIA owner packet");
    assert!(crate::native::CatiaNative::load(&namespace).is_err());
}

#[test]
fn native_namespace_retains_fixed_owner_allocation_targets() {
    let (bytes, target_positions, owner_pos) = b2_width_coded_owner_with_allocation_stream();
    let native = crate::native::CatiaNative::decode(&bytes);
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };

    assert_eq!(packet.frame.pos, u64_from_index(owner_pos));
    assert_eq!(packet.source_index, 0);
    assert_eq!(
        packet
            .identity_targets()
            .iter()
            .map(|target| (
                target.slot,
                target.distance,
                target.target_byte_offset,
                u8::from(target.target_class),
            ))
            .collect::<Vec<_>>(),
        [
            (0, 1, u64_from_index(target_positions[4]), 0x5e),
            (2, 4, u64_from_index(target_positions[1]), 0x5e),
            (4, 2, u64_from_index(target_positions[3]), 0x5e),
            (6, 3, u64_from_index(target_positions[2]), 0x5d),
            (8, 5, u64_from_index(target_positions[0]), 0x5d),
        ]
    );
}

#[test]
fn native_namespace_retains_closed_fixed_owner_boundary_cycle() {
    let (bytes, edge_positions, owner_pos, endpoint_records) =
        b2_fixed_owner_boundary_cycle_stream();
    let native = crate::native::CatiaNative::decode(&bytes);
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };

    assert_eq!(packet.frame.pos, u64_from_index(owner_pos));
    let cycle = packet
        .boundary_cycle()
        .expect("closed fixed-owner boundary cycle");
    assert!(cycle.face_node.is_none());
    assert_eq!(
        cycle.edges.map(|edge| edge.byte_offset),
        edge_positions.map(u64_from_index)
    );
    assert_eq!(
        cycle.edges.map(|edge| edge.endpoint_records),
        endpoint_records.map(|pair| pair.map(u64_from_index))
    );
}

#[test]
fn native_namespace_retains_boundary_face_node_for_checked_cycle_prelude() {
    let (bytes, edge_positions, owner_pos, endpoint_records, face_node_pos) =
        b2_fixed_owner_boundary_face_node_cycle_stream();
    let native = crate::native::CatiaNative::decode(&bytes);
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    // A boundary prelude is separated from the owner by its four edge records.
    assert!(packet.face_node.is_none());
    let cycle = packet
        .boundary_cycle()
        .expect("closed fixed-owner boundary cycle");
    let face_node = cycle
        .face_node
        .as_ref()
        .expect("source-scoped boundary face node");
    assert_eq!(face_node.frame.pos, u64_from_index(face_node_pos));
    assert_eq!(
        packet.source_offset - face_node.source_offset,
        cadmpeg_core::decode::u64_from_index(owner_pos - face_node_pos)
    );
    assert_eq!(face_node.target, 1014);
    assert_eq!(face_node.terminal, [0x27, 0x05]);
    assert_eq!(
        cycle.edges.map(|edge| edge.byte_offset),
        edge_positions.map(u64_from_index)
    );
    assert_eq!(
        cycle.edges.map(|edge| edge.endpoint_records),
        endpoint_records.map(|pair| pair.map(u64_from_index))
    );

    let mut wrong_terminal = bytes.clone();
    wrong_terminal[face_node_pos + 12] = 0x04;
    let native = crate::native::CatiaNative::decode(&wrong_terminal);
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    assert!(packet
        .boundary_cycle()
        .expect("cycle survives terminal change")
        .face_node
        .is_none());

    let mut wrong_identity = bytes;
    wrong_identity[face_node_pos + 9] = 0xe1;
    let native = crate::native::CatiaNative::decode(&wrong_identity);
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    assert!(packet
        .boundary_cycle()
        .expect("cycle survives identity change")
        .face_node
        .is_none());
}

#[test]
fn native_namespace_retains_source_closed_owner_chart() {
    let native = crate::native::CatiaNative::decode(&b2_owner_chart_stream(0x2b));
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    let chart = packet.owner_chart().expect("owner chart relation");
    assert_eq!(chart.carrier, CatiaOwnerChartCarrier::B2b);
    assert_eq!(chart.side_axis(), CatiaOwnerChartSideAxis::SecondParameter);
    let CatiaOwnerChartBridge::SupportedSurface {
        byte_offset,
        carrier_surface,
        support_surfaces,
        support_pcurves,
        construction_radius,
        ..
    } = &chart.bridge
    else {
        panic!("supported-surface owner bridge")
    };
    assert!(chart.carrier_byte_offset < *byte_offset);
    assert!(*byte_offset < chart.parameter_point_byte_offsets[0]);
    assert_eq!(
        [
            carrier_surface.value,
            support_surfaces[0].value,
            support_surfaces[1].value,
            support_pcurves[0].value,
            support_pcurves[1].value,
        ],
        [1, 100, 0, 101, 1]
    );
    assert_eq!(
        carrier_surface.encoding(),
        crate::native::CatiaAllocationReferenceEncoding::BackwardDistance
    );
    let wire = serde_json::to_value(chart).expect("serialize owner chart");
    let controls: [u8; 6] =
        serde_json::from_value::<cadmpeg_ir::native::bytes::NativeBytes<[u8; 6]>>(
            wire["bridge"]["controls"].clone(),
        )
        .expect("six bridge controls")
        .into_inner();
    assert_eq!(controls, [0x09, 0x05, 0x03, 0x05, 0x01, 0x05]);
    assert_eq!(construction_radius.get(), 1.0);
    assert!(chart.parameter_point_byte_offsets[3] < packet.frame.pos);

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store CATIA owner chart");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA owner chart"),
        native
    );
}

#[test]
fn owner_chart_width_coded_supports_select_unique_alias_rows() {
    let mut bytes = b2_owner_chart_stream(0x2b);
    bytes.extend(grouped_surface_alias_stream(0, 100, 0x148));
    bytes.extend(grouped_surface_alias_stream(1, 200, 0x148));
    let mut pcurve_alias = surface_alias_stream();
    pcurve_alias[8..12].copy_from_slice(&101u32.to_le_bytes());
    bytes.extend(pcurve_alias);
    let mut local_collision = surface_alias_stream();
    local_collision[8..12].copy_from_slice(&1u32.to_le_bytes());
    bytes.extend(local_collision);

    let native = crate::native::CatiaNative::decode(&bytes);
    let chart = native.consolidated_owner_packets[0]
        .owner_chart()
        .expect("owner chart");
    let CatiaOwnerChartBridge::SupportedSurface {
        carrier_surface,
        support_surfaces,
        support_pcurves,
        ..
    } = &chart.bridge
    else {
        panic!("supported-surface bridge")
    };
    let surface_alias = native
        .alias_rows
        .iter()
        .find(|alias| alias.tag() == 100)
        .expect("support-surface alias");
    let pcurve_alias = native
        .alias_rows
        .iter()
        .find(|alias| alias.tag() == 101)
        .expect("support-pcurve alias");
    assert_eq!(
        support_surfaces[0]
            .alias()
            .map(|binding| binding.row().to_owned()),
        Some(surface_alias.id.clone())
    );
    assert_eq!(
        support_surfaces[0]
            .alias()
            .and_then(super::super::owner_chart::CatiaOwnerChartAliasBinding::canonical_tag),
        Some(200)
    );
    assert_eq!(
        support_pcurves[0]
            .alias()
            .map(|binding| binding.row().to_owned()),
        Some(pcurve_alias.id.clone())
    );
    assert_eq!(
        support_pcurves[0]
            .alias()
            .and_then(super::super::owner_chart::CatiaOwnerChartAliasBinding::canonical_tag),
        Some(101)
    );
    assert_ne!(
        support_pcurves[1].encoding(),
        crate::native::CatiaAllocationReferenceEncoding::WidthCoded
    );
    assert_eq!(support_pcurves[1].alias(), None);
    assert_eq!(carrier_surface.alias(), None);

    let mut invalid = native;
    let Some(chart) = invalid.consolidated_owner_packets[0].owner_chart_mut() else {
        panic!("owner chart")
    };
    let CatiaOwnerChartBridge::SupportedSurface {
        support_surfaces, ..
    } = &mut chart.bridge
    else {
        panic!("supported-surface bridge")
    };
    if let CatiaOwnerChartAddress::WidthCoded { alias: Some(alias) } =
        &mut support_surfaces[0].address
    {
        *alias = crate::native::CatiaOwnerChartAliasBinding::new(
            cadmpeg_core::text::NonBlankString::new(alias.row().to_owned())
                .expect("alias row is non-empty"),
            Some(100),
        );
    }
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut namespace)
        .expect("store invalid support alias");
    assert!(matches!(
        crate::native::CatiaNative::load(&namespace),
        Err(cadmpeg_ir::NativeConvertError::InvalidOwner(_))
    ));
}

#[test]
fn owner_chart_duplicate_alias_tags_remain_unresolved() {
    let mut bytes = b2_owner_chart_stream(0x2b);
    for lead in [1u32, 0x8e] {
        let mut alias = surface_alias_stream();
        alias[..4].copy_from_slice(&lead.to_le_bytes());
        alias[8..12].copy_from_slice(&100u32.to_le_bytes());
        bytes.extend(alias);
    }

    let native = crate::native::CatiaNative::decode(&bytes);
    let chart = native.consolidated_owner_packets[0]
        .owner_chart()
        .expect("owner chart");
    let CatiaOwnerChartBridge::SupportedSurface {
        support_surfaces, ..
    } = &chart.bridge
    else {
        panic!("supported-surface bridge")
    };
    assert_eq!(support_surfaces[0].alias(), None);
}

#[test]
fn native_namespace_retains_count_framed_owner_packet_and_face_node_relation() {
    let native = crate::native::CatiaNative::decode(&b2_adjacent_face_counted_owner_stream());
    let [packet] = native.consolidated_owner_packets.as_slice() else {
        panic!("one consolidated owner packet")
    };
    let crate::native::CatiaOwnerPacketPayload::Counted {
        references,
        reference_encodings,
        tail,
        ..
    } = &packet.payload
    else {
        panic!("count-framed owner payload")
    };
    assert_eq!(references, &[911, 7, 263, 258, 281, 276, 917]);
    assert_eq!(
        reference_encodings,
        &[
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
            crate::native::CatiaAllocationReferenceEncoding::BackwardDistance,
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
            crate::native::CatiaAllocationReferenceEncoding::WidthCoded,
        ]
    );
    assert_eq!(tail.as_slice(), &[0x83, 0x41, 0x92, 0x00, 0x01]);
    let face_node = packet.face_node.as_ref().expect("face-node relation");
    assert_eq!(face_node.target, 916);
    assert_eq!(
        face_node.target + 1,
        *references.last().expect("final owner reference")
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store count-framed CATIA owner packet");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load count-framed CATIA owner packet"),
        native
    );

    let mut invalid = serde_json::to_value(packet).expect("owner packet wire");
    invalid["payload"]["tail"] = serde_json::json!("");
    assert!(
        serde_json::from_value::<crate::native::CatiaConsolidatedOwnerPacket>(invalid).is_err()
    );
}

#[test]
fn native_namespace_retains_consolidated_historical_edge_runs() {
    let bytes = a5_native_edge_run_stream(6, 139, 142);
    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.consolidated_pcurves.len(), 2);
    assert_eq!(native.consolidated_edge_runs.len(), 1);
    let run = &native.consolidated_edge_runs[0];
    assert_eq!(
        run.pcurves,
        ["catia:consolidated:pcurve#0", "catia:consolidated:pcurve#1"]
    );
    assert_eq!(run.node, "catia:consolidated:edge-node#0");
    let [node] = native.consolidated_edge_nodes.as_slice() else {
        panic!("one consolidated edge node");
    };
    assert_eq!(node.vertex_refs, [139, 142]);
    assert_eq!(
        native.vertex_identity_ids(node),
        [
            "catia:consolidated:vertex-identity#0",
            "catia:consolidated:vertex-identity#1"
        ]
    );
    assert_eq!(node.parameter_selectors, [2, 1]);
    let uses = node.uses.as_ref().expect("edge-owned oriented uses");
    assert_eq!(uses.references, [[4, 5], [5, 6]]);
    let definition = node.definition.as_ref().expect("edge-owned definition");
    assert_eq!(u8::from(definition.class()), 0x23);
    assert!(definition.frame().pos < node.byte_offset);
    assert_eq!(native.consolidated_vertex_identities.len(), 2);
    assert_eq!(native.consolidated_vertex_identities[0].identity, 139);
    assert_eq!(
        native.consolidated_vertex_identities[0].incident_edge_nodes,
        ["catia:consolidated:edge-node#0"]
    );

    let mut file = standard_catpart();
    file.splice(16..16, bytes.clone());
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode consolidated edge-run coverage");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_EDGE_RUN_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_EDGE_RUN_SUPPORT_BINDING_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::UNRESOLVED_CONSOLIDATED_EDGE_RUN_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::PARTIALLY_RESOLVED_CONSOLIDATED_EDGE_RUN_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::FULLY_RESOLVED_CONSOLIDATED_EDGE_RUN_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_EDGE_RUN_SHARED_LOCUS_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_EDGE_RUN_ENDPOINT_LOCUS_COUNT.as_str()
        ),
        0
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native.store(&mut namespace).expect("store CATIA edge run");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load CATIA edge run"),
        native
    );

    let mut invalid = native;
    invalid.consolidated_edge_runs[0].pcurves[1] = "missing".to_string();
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA edge run for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut invalid = serde_json::to_value(crate::native::CatiaNative::decode(&bytes))
        .expect("serialize CATIA edge definition");
    invalid["consolidated_edge_nodes"][0]["definition"]["class"] = serde_json::json!(0x26);
    assert!(serde_json::from_value::<crate::native::CatiaNative>(invalid).is_err());

    let mut invalid = crate::native::CatiaNative::decode(&bytes);
    invalid.consolidated_edge_nodes[0].uses = None;
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store orphaned CATIA edge definition");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let mut invalid = crate::native::CatiaNative::decode(&bytes);
    invalid.consolidated_vertex_identities[0]
        .incident_edge_nodes
        .clear();
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid CATIA vertex incidence for load validation");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());
}

#[test]
fn compact_owner_does_not_type_unresolved_edge_references_as_vertices() {
    let allocation = [
        0xb2, 0x03, 0x5f, 0x04, 0x05, 0x82, 0x1d, 0x03, 0x05, 0xb2, 0x03, 0x62, 0x08, 0x05, 0x82,
        0x0b, 0x21, 0x84, 0x41, 0xff, 0x0f, 0x01, 0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00, 0xb2,
        0x03, 0x05, 0x03, 0x05, 0x82, 0x0b, 0x57, 0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x09, 0x0f,
        0x07, 0x0b, 0x21,
    ];
    let bytes = allocation.repeat(2);
    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.consolidated_edge_nodes.len(), 2);
    assert!(native.consolidated_vertex_identities.is_empty());
    assert_ne!(
        native.consolidated_edge_nodes[0]
            .allocation
            .as_ref()
            .map(|(owner, _)| owner),
        native.consolidated_edge_nodes[1]
            .allocation
            .as_ref()
            .map(|(owner, _)| owner)
    );
    assert_eq!(
        native.consolidated_edge_nodes[0]
            .allocation
            .as_ref()
            .map(|(_, ordinal)| *ordinal),
        Some(2)
    );
    assert_eq!(
        native.consolidated_edge_nodes[1]
            .allocation
            .as_ref()
            .map(|(_, ordinal)| *ordinal),
        Some(2)
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0]),
        ["", ""]
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1]),
        ["", ""]
    );
}

#[test]
fn compact_vertex_identity_uses_resolved_endpoint_records() {
    let first_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x20, 0x03, 0x07, 0x06, 0x30, 0x06, 0x31, 0x21,
    ];
    let vertex = [0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00];
    let second_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x21, 0x09, 0x0d, 0x06, 0x32, 0x06, 0x33, 0x21,
    ];
    let first_vertex_pos = u64_from_index(first_edge.len());
    let second_vertex_pos = first_vertex_pos + u64_from_index(vertex.len());
    let mut bytes = first_edge.to_vec();
    bytes.extend_from_slice(&vertex);
    bytes.extend_from_slice(&vertex);
    bytes.extend_from_slice(&second_edge);

    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.consolidated_edge_nodes.len(), 2);
    assert_eq!(native.consolidated_vertex_identities.len(), 2);
    assert_eq!(
        native.consolidated_edge_nodes[0].endpoint_records,
        Some([first_vertex_pos, second_vertex_pos])
    );
    assert_eq!(
        native.consolidated_edge_nodes[1].endpoint_records,
        Some([first_vertex_pos, second_vertex_pos])
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0]),
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])
    );
    assert_eq!(
        native
            .consolidated_vertex_identities
            .iter()
            .map(|identity| identity.endpoint_record)
            .collect::<Vec<_>>(),
        vec![Some(first_vertex_pos), Some(second_vertex_pos)]
    );
}

#[test]
fn width_coded_forward_endpoints_merge_by_class18_record_identity() {
    fn edge(start_distance: u8, end_distance: u8) -> Vec<u8> {
        vec![
            0xb2,
            0x03,
            0x5e,
            0x0a,
            0x05,
            0x03,
            0x08,
            start_distance,
            0x00,
            0x08,
            end_distance,
            0x00,
            0x07,
            0x0b,
            0x21,
        ]
    }

    let filler = [0xb2, 0x03, 0x05, 0x01, 0x05, 0x01];
    let endpoint = [0xb2, 0x03, 0x18, 0x01, 0x05, 0x01];
    let mut bytes = edge(4, 5);
    bytes.extend_from_slice(&edge(3, 4));
    bytes.extend_from_slice(&filler);
    bytes.extend_from_slice(&filler);
    let first_endpoint = u64_from_index(bytes.len());
    bytes.extend_from_slice(&endpoint);
    let second_endpoint = u64_from_index(bytes.len());
    bytes.extend_from_slice(&endpoint);

    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.consolidated_edge_nodes.len(), 2);
    assert_eq!(native.consolidated_vertex_identities.len(), 2);
    assert_eq!(
        native.consolidated_edge_nodes[0].endpoint_records,
        Some([first_endpoint, second_endpoint])
    );
    assert_eq!(
        native.vertex_identity_ids(&native.consolidated_edge_nodes[0]),
        native.vertex_identity_ids(&native.consolidated_edge_nodes[1])
    );
    assert_eq!(
        native
            .consolidated_vertex_identities
            .iter()
            .map(|identity| identity.endpoint_record)
            .collect::<Vec<_>>(),
        [Some(first_endpoint), Some(second_endpoint)]
    );
}

mod vertex_identity;

#[test]
fn consolidated_cone_deserialization_rejects_combined_frame_and_chart_defects() {
    let native = crate::native::CatiaNative::decode(&b2_cone_stream());
    let cone = &native.consolidated_cones[0];
    let valid = serde_json::to_value(cone).expect("cone wire");
    assert_eq!(
        serde_json::from_value::<crate::native::CatiaConsolidatedCone>(valid.clone())
            .expect("admitted cone"),
        *cone
    );
    for (field, value) in [
        ("direction_y", serde_json::json!([1.0, 0.0, 0.0])),
        ("axis", serde_json::json!([0.0, 0.0, -1.0])),
        ("half_angle", serde_json::json!(0.0)),
        ("half_angle", serde_json::json!(std::f64::consts::FRAC_PI_2)),
        ("angular_range", serde_json::json!([-10.0, -9.0])),
        ("angular_domain", serde_json::json!([0.0, 1.0])),
        ("slant_range", serde_json::json!([-1.0, 1.0])),
    ] {
        let mut invalid = valid.clone();
        invalid[field] = value;
        assert!(
            serde_json::from_value::<crate::native::CatiaConsolidatedCone>(invalid).is_err(),
            "{field}"
        );
    }
}

mod admission;

#[test]
fn plane_wire_rejects_selector_direction_and_range_contradictions() {
    let native = crate::native::CatiaNative::decode(&b2_plane_carrier_stream());
    let original =
        serde_json::to_value(&native.consolidated_plane_carriers[0]).expect("plane wire");
    for (field, value) in [
        ("layout", serde_json::json!(0xdc)),
        ("direction", serde_json::json!([0.0, 1.0, 0.0])),
        ("u_range", serde_json::json!([5.0, 0.0])),
        ("v_range", serde_json::json!([3.0, -2.0])),
    ] {
        let mut wire = original.clone();
        wire["payload"][field] = value;
        assert!(
            serde_json::from_value::<crate::native::CatiaConsolidatedPlaneCarrier>(wire).is_err()
        );
    }
}

#[test]
fn b2_owner_packet_stream_projects_one_owner_packet() {
    let bytes = crate::test_support::test_b2::b2_owner_packet_stream();
    let records = crate::wire::records::consolidated_records(&bytes);
    let packets = super::super::projection::consolidated_owner_packets(&bytes, &records)
        .expect("valid source fixture");
    assert_eq!(packets.len(), 1);
}
