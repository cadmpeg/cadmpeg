// SPDX-License-Identifier: Apache-2.0

use crate::native::chamfer::{CatiaConsolidatedChamfer, CatiaObjectChamfer};
use crate::native::class61::CatiaConsolidatedClass61Record;
use crate::native::{resolved_range_interval, EntityIncidenceIndex, RelationDependencies};
use cadmpeg_core::decode::u64_from_index;

use super::test_consolidated::{
    validate_consolidated_chamfers, validate_consolidated_circles,
    validate_consolidated_class5b5c_records, validate_consolidated_cones,
    validate_consolidated_cylinders, validate_consolidated_line_profiles,
    validate_consolidated_parameter_points, validate_consolidated_pcurves,
    validate_consolidated_plane_carriers, validate_consolidated_reference_lists,
    validate_consolidated_revolutions, validate_consolidated_spheres, validate_consolidated_tori,
};
use super::test_legacy::{valid_entity_record_shape, validate_legacy_entity_runs};
use super::test_links::{
    validate_consolidated_edge_runs, validate_consolidated_owner_packets, validate_native_links,
    ConsolidatedSupportArenas,
};
use super::test_zero_entity::{
    validate_zero_entity_ownership_roots, validate_zero_entity_records,
    validate_zero_entity_support_runs, validate_zero_entity_topology_records,
};
use crate::entity_table;
use crate::native::class5b5c::CatiaConsolidatedClass5b5cRecord;
use crate::native::edge_node::{load_edge_nodes, CatiaConsolidatedEdgeNodeWire};
use crate::native::entity_record::CatiaEntityRecord;
use crate::native::projection::{external_reference_views, preview_views};
use crate::native::projection::{
    validate_alias_surface_tags, validate_owner_chart_support_aliases,
};
use crate::native::schema_configuration_chain::{
    derive_schema_configuration_row_chains, CatiaSchemaConfigurationRowChain,
};
use crate::native::{
    definition_schema_selections, derive_reference_signature_cohorts, design_object_id,
    design_objects, entity_class_index, entity_suffix_framing, entity_suffix_schema_selection,
    entity_suffix_value, entity_value_schema_selections, object_production, payload_references,
    reference_signature, semantic_entity_indices, store_projection, terminal_null_entity_id,
    value_production, CatiaAliasRow, CatiaArenaProjection, CatiaCatalog, CatiaCatalogEntry,
    CatiaCatalogWire, CatiaConsolidatedCircle, CatiaConsolidatedCone, CatiaConsolidatedCylinder,
    CatiaConsolidatedEdgeRun, CatiaConsolidatedLineProfile, CatiaConsolidatedOwnerPacket,
    CatiaConsolidatedParameterPoint, CatiaConsolidatedPcurve, CatiaConsolidatedPlaneCarrier,
    CatiaConsolidatedReferenceList, CatiaConsolidatedRevolution,
    CatiaConsolidatedRollingBallConstruction, CatiaConsolidatedSphere, CatiaConsolidatedTorus,
    CatiaConsolidatedVertexIdentity, CatiaDesignObject, CatiaEntityReferenceIndex,
    CatiaExternalReference, CatiaFinjplSegment, CatiaLegacyEntityRun, CatiaNative,
    CatiaObjectGraph, CatiaObjectOwner, CatiaObjectRecord, CatiaPreviewImage,
    CatiaReferenceSignatureCohort, CatiaValueBlock, CatiaValueSchemaSelection,
    CatiaZeroEntityEdgeStride, CatiaZeroEntityOrientedUsePair, CatiaZeroEntityOwnershipRoot,
    CatiaZeroEntityRecord, CatiaZeroEntitySupportRun, CatiaZeroEntityVertexIncidence,
};
use crate::object_graph;
use std::collections::{HashMap, HashSet};

pub(in crate::native) fn validate_rolling_ball_continuations(
    records: &[crate::native::rolling_ball_continuation::CatiaRollingBallContinuation],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (i, r) in records.iter().enumerate() {
        if r.id != format!("catia:consolidated:rolling-ball-continuation#{i}")
            || !crate::native::rolling_ball_continuation::valid_record(r)
            || (i > 0
                && (records[i - 1].source_index, records[i - 1].source_offset)
                    >= (r.source_index, r.source_offset))
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "invalid rolling-ball continuation source identity or fields".to_owned(),
            ));
        }
    }
    Ok(())
}

pub(in crate::native) fn validate_four_reference_edges(
    records: &[crate::native::four_reference_edge::CatiaConsolidatedFourReferenceEdge],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (ordinal, record) in records.iter().enumerate() {
        let order_valid = ordinal == 0
            || (
                records[ordinal - 1].source_index,
                records[ordinal - 1].source_offset,
            ) < (record.source_index, record.source_offset);
        if record.id != format!("catia:consolidated:four-reference-edge#{ordinal}")
            || !crate::native::four_reference_edge::valid_payload(record)
            || !order_valid
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "invalid four-reference edge source identity or payload".to_owned(),
            ));
        }
    }
    Ok(())
}

impl CatiaNative {
    /// Decode CATIA-native records directly from a synthesized record source.
    #[must_use]
    pub(crate) fn decode(bytes: &[u8]) -> Self {
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            bytes,
            &arena,
            &cadmpeg_core::decode::DecodePolicy::service(),
        )
        .expect("test source fits the service profile");
        let sources = [vec![crate::wire::records::SourceExtent::whole(bytes)]];
        Self::decode_with_record_sources(
            &ctx,
            bytes,
            &sources,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the records")
    }

    /// Load the typed CATIA namespace from generic native arenas.
    pub(crate) fn load(
        namespace: &cadmpeg_ir::NativeNamespace,
    ) -> Result<Self, cadmpeg_ir::NativeConvertError> {
        let mut catalog_headers: Vec<CatiaCatalogWire> = namespace.arena_as("catalogs")?;
        let entries: Vec<CatiaCatalogEntry> = namespace.arena_as("catalog_entries")?;
        let catalog_ids = catalog_headers
            .iter()
            .map(|catalog| catalog.id.as_str())
            .collect::<HashSet<_>>();
        if catalog_ids.len() != catalog_headers.len() {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "duplicate CATIA catalog identity".to_string(),
            ));
        }
        if let Some(entry) = entries
            .iter()
            .find(|entry| !catalog_ids.contains(entry.parent.as_str()))
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "catalog entry `{}` references missing catalog `{}`",
                entry.id, entry.parent
            )));
        }
        for catalog in &mut catalog_headers {
            let joined = entries
                .iter()
                .filter(|entry| entry.parent == catalog.id)
                .cloned()
                .collect::<Vec<_>>();
            catalog.entries = joined;
            catalog.entries.sort_by_key(|entry| entry.ordinal);
            if catalog
                .entries
                .iter()
                .enumerate()
                .any(|(ordinal, entry)| usize::try_from(entry.ordinal).ok() != Some(ordinal))
            {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                    "catalog `{}` has an invalid entry sequence",
                    catalog.id
                )));
            }
        }
        let catalogs = catalog_headers
            .into_iter()
            .map(CatiaCatalog::from)
            .collect::<Vec<_>>();
        let mut graphs: Vec<CatiaObjectGraph> = namespace.arena_as("object_graphs")?;
        let records: Vec<CatiaObjectRecord> = namespace.arena_as("object_graph_records")?;
        let entity_wires: Vec<crate::native::entity_record::CatiaEntityRecordWire> =
            namespace.arena_as("entity_records")?;
        let entity_records = entity_wires
            .into_iter()
            .map(|wire| {
                CatiaEntityRecord::try_from(wire)
                    .map_err(cadmpeg_ir::NativeConvertError::InvalidOwner)
            })
            .collect::<Result<Vec<_>, _>>()?;
        let schema_configuration_row_chains: Vec<CatiaSchemaConfigurationRowChain> =
            namespace.arena_as("schema_configuration_row_chains")?;
        let reference_signature_cohorts: Vec<CatiaReferenceSignatureCohort> =
            namespace.arena_as("reference_signature_cohorts")?;
        let graph_ids = graphs
            .iter()
            .map(|graph| graph.id.as_str())
            .collect::<HashSet<_>>();
        if graph_ids.len() != graphs.len() {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "duplicate CATIA object-graph identity".to_string(),
            ));
        }
        if let Some(record) = records
            .iter()
            .find(|record| !graph_ids.contains(record.parent.as_str()))
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "object record `{}` references missing graph `{}`",
                record.id, record.parent
            )));
        }
        let record_ids = records
            .iter()
            .map(|record| record.id.as_str())
            .collect::<HashSet<_>>();
        let entity_record_ids = entity_records
            .iter()
            .map(|record| record.id.as_str())
            .collect::<HashSet<_>>();
        if record_ids.len() != records.len() || entity_record_ids.len() != entity_records.len() {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "duplicate CATIA object or entity-record identity".to_string(),
            ));
        }
        if let Some(entity) = entity_records.iter().find(|entity| {
            !graph_ids.contains(entity.object_graph.as_str())
                || !record_ids.contains(entity.object_record.as_str())
        }) {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "entity record `{}` has a missing graph or object-record link",
                entity.id
            )));
        }
        let entity_classes_by_graph_identity = entity_class_index(&records);
        let (
            relation_expressions,
            relation_expression_entities,
            entities_by_graph_identity,
            terminal_nulls_by_graph,
            parameter_bindings,
        ) = semantic_entity_indices(&entity_records, &entity_classes_by_graph_identity)
            .map_err(|error| cadmpeg_ir::NativeConvertError::InvalidOwner(error.to_string()))?;
        let expected_reference_signature_cohorts =
            derive_reference_signature_cohorts(&entity_records);
        if reference_signature_cohorts != expected_reference_signature_cohorts {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "CATIA reference-signature cohorts are not canonical".to_string(),
            ));
        }
        let entity_references = CatiaEntityReferenceIndex {
            entities: &entities_by_graph_identity,
            classes: &entity_classes_by_graph_identity,
            terminal_nulls: &terminal_nulls_by_graph,
        };
        let expected_schema_configuration_row_chains =
            crate::test_support::with_service_context(|ctx| {
                derive_schema_configuration_row_chains(
                    ctx,
                    &entity_records,
                    &entity_references,
                    records.iter(),
                )
                .map(|derived| derived.chains)
            })
            .map_err(|error| cadmpeg_ir::NativeConvertError::InvalidOwner(error.to_string()))?;
        if schema_configuration_row_chains != expected_schema_configuration_row_chains {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "schema-configuration-row chains do not match their successor links".to_string(),
            ));
        }
        for graph in &mut graphs {
            graph.records = records
                .iter()
                .filter(|record| record.parent == graph.id)
                .cloned()
                .collect();
            graph.records.sort_by_key(|record| record.ordinal);
            let mut graph_entities = entity_records
                .iter()
                .filter(|entity| entity.object_graph == graph.id)
                .collect::<Vec<_>>();
            graph_entities.sort_by_key(|entity| entity.ordinal);
            let catalog = graph
                .catalog
                .as_ref()
                .and_then(|catalog_id| catalogs.iter().find(|catalog| catalog.id == *catalog_id));
            let incidences = EntityIncidenceIndex::new(&graph.records, &graph.id);
            if !graph_entities.is_empty()
                && (graph_entities.len() != graph.records.len()
                    || graph_entities
                        .iter()
                        .enumerate()
                        .any(|(ordinal, entity)| entity.ordinal != u64_from_index(ordinal))
                    || graph_entities
                        .windows(2)
                        .any(|pair| pair[0].entity_id >= pair[1].entity_id)
                    || graph_entities
                        .iter()
                        .any(|entity| !valid_entity_record_shape(entity))
                    || graph_entities.iter().any(|entity| {
                        entity.reference_signature
                            != entity_table::parse_reference_signature(entity.value_payload())
                                .and_then(|production| {
                                    crate::test_support::with_service_context(|ctx| {
                                        reference_signature(
                                            ctx,
                                            production,
                                            &graph.id,
                                            &entity_references,
                                        )
                                    })
                                    .ok()
                                })
                    })
                    || graph_entities.iter().any(|entity| {
                        let selectors = entity_table::parse_definition_schema_selectors(
                            entity.definition_prefix(),
                        );
                        crate::test_support::with_service_context(|ctx| {
                            definition_schema_selections(ctx, &selectors, catalog)
                        })
                        .ok()
                        .as_ref()
                            != Some(&entity.definition_schema_selections)
                    })
                    || graph_entities.iter().any(|entity| {
                        let fields = entity.value_fields();
                        let packets = entity.value_packets(&fields);
                        crate::test_support::with_service_context(|ctx| {
                            entity_value_schema_selections(ctx, &fields, catalog, &packets)
                        })
                        .ok()
                        .as_ref()
                            != Some(&entity.value_schema_selections)
                    })
                    || graph_entities.iter().any(|entity| {
                        let fields = entity.value_fields();
                        crate::test_support::with_service_context(|ctx| {
                            value_production(ctx, entity, &incidences, &fields)
                        })
                        .ok()
                        .as_ref()
                            != Some(&entity.value_production)
                    })
                    || graph_entities.iter().any(|entity| {
                        entity.suffix_value()
                            != entity_suffix_value(entity.record_suffix()).as_ref()
                    })
                    || graph_entities.iter().any(|entity| {
                        entity.suffix_framing()
                            != entity_suffix_framing(entity.record_suffix()).as_ref()
                    })
                    || graph_entities.iter().any(|entity| {
                        crate::test_support::with_service_context(|ctx| {
                            entity_suffix_schema_selection(ctx, entity.suffix_value(), catalog)
                        })
                        .ok()
                        .as_ref()
                            != Some(&entity.suffix_schema_selection)
                    })
                    || graph_entities.iter().any(|entity| {
                        crate::test_support::with_service_context(|ctx| {
                            resolved_range_interval(
                                ctx,
                                entity.value_payload(),
                                &entity.value_schema_selections,
                                entity.suffix_value(),
                                &incidences,
                                entity.entity_id,
                            )
                        })
                        .ok()
                        .as_ref()
                            != Some(&entity.range_interval)
                    })
                    || graph_entities.iter().any(|entity| {
                        let object = graph
                            .records
                            .iter()
                            .find(|record| record.id == entity.object_record);
                        entity.object_production
                            != object.and_then(|object| {
                                crate::test_support::with_service_context(|ctx| {
                                    object_production(
                                        ctx,
                                        entity,
                                        object,
                                        &entity_references,
                                        &relation_expressions,
                                        &relation_expression_entities,
                                        &mut RelationDependencies::new(
                                            &parameter_bindings,
                                            usize::MAX,
                                        ),
                                    )
                                })
                                .ok()
                                .flatten()
                            })
                    })
                    || graph_entities.windows(2).any(|pair| {
                        pair[0].byte_offset.checked_add(pair[0].byte_len())
                            != Some(pair[1].byte_offset)
                    })
                    || graph_entities.last().and_then(|entity| {
                        entity
                            .byte_offset
                            .checked_add(entity.byte_len())?
                            .checked_add(1)
                    }) != Some(graph.byte_offset))
            {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                    "object graph `{}` has an invalid entity-table sequence",
                    graph.id
                )));
            }
            let record_indices = graph
                .records
                .iter()
                .enumerate()
                .filter_map(|(index, record)| Some((record.entity_id()?, index)))
                .collect::<HashMap<_, _>>();
            let terminal_null_entity_id = terminal_null_entity_id(&record_indices);
            if record_indices.len()
                != graph
                    .records
                    .iter()
                    .filter(|record| record.entity_id().is_some())
                    .count()
            {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                    "object graph `{}` has duplicate entity identities",
                    graph.id
                )));
            }
            for (ordinal, record) in graph.records.iter().enumerate() {
                let expected_head_roles = object_graph::head_roles(record.lead, &record.head);
                let expected_owner = expected_head_roles.owner.map(CatiaObjectOwner::from);
                let expected_design_object = record
                    .owner_entity_id()
                    .map(|owner| design_object_id(graph.byte_offset, owner));
                let paired_entity = graph_entities.get(ordinal).copied();
                let expected_storage = record
                    .storage_ref()
                    .and_then(|identity| record_indices.get(&identity))
                    .and_then(|index| graph.records.get(*index));
                let expected_reference_count = payload_references(&record.payload).count();
                let references_match = expected_reference_count == record.references.len()
                    && record
                        .references
                        .iter()
                        .zip(payload_references(&record.payload))
                        .all(|(actual, (entity_id, payload_offset, source))| {
                            let target = record_indices
                                .get(&entity_id)
                                .and_then(|index| graph.records.get(*index));
                            actual.entity_id() == entity_id
                                && actual.payload_offset() == u64_from_index(payload_offset)
                                && actual.source() == &source
                                && actual.is_null() == (Some(entity_id) == terminal_null_entity_id)
                                && actual.target() == target.map(|target| target.id.as_str())
                                && actual.design_object()
                                    == target.and_then(|target| target.design_object.as_deref())
                        });
                if usize::try_from(record.ordinal).ok() != Some(ordinal)
                    || record.owner != expected_owner
                    || (record.class_ref(), record.storage_ref())
                        != (
                            expected_head_roles.class_ref,
                            expected_head_roles.storage_ref,
                        )
                    || record.design_object != expected_design_object
                    || record.entity_record() != paired_entity.map(|entity| entity.id.as_str())
                    || record.entity_id() != paired_entity.map(|entity| entity.entity_id)
                    || paired_entity.is_some_and(|entity| entity.object_record != record.id)
                    || (record.storage_record(), record.storage_design_object())
                        != (
                            expected_storage.map(|target| target.id.as_str()),
                            expected_storage.and_then(|target| target.design_object.as_deref()),
                        )
                    || record.inline_body.as_ref().is_some_and(|body| {
                        (graph_entities.is_empty() && object_graph::inline::parse(body).is_none())
                            || body.first() != Some(&record.lead)
                            || !record.head.is_empty()
                            || record.owner.is_some()
                            || record.class_ref().is_some()
                            || record.storage_ref().is_some()
                            || record.payload.size != 0
                            || !record.payload.fields.is_empty()
                    })
                    || record.inline_body.is_none() && record.head.is_empty()
                    || !references_match
                {
                    return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                        "object graph `{}` has an invalid record sequence",
                        graph.id
                    )));
                }
            }
        }
        let mut value_blocks: Vec<CatiaValueBlock> = namespace.arena_as("value_blocks")?;
        let value_schema_selections: Vec<CatiaValueSchemaSelection> =
            namespace.arena_as("value_schema_selections")?;
        let value_block_ids = value_blocks
            .iter()
            .map(|block| block.id.clone())
            .collect::<HashSet<_>>();
        if value_block_ids.len() != value_blocks.len() {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "duplicate CATIA value-block identity".to_string(),
            ));
        }
        let mut selections_by_block = HashMap::<String, Vec<CatiaValueSchemaSelection>>::new();
        for selection in value_schema_selections {
            if !value_block_ids.contains(&selection.parent) {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                    "value selection `{}` references missing block `{}`",
                    selection.id, selection.parent
                )));
            }
            selections_by_block
                .entry(selection.parent.clone())
                .or_default()
                .push(selection);
        }
        for block in &mut value_blocks {
            block.schema_selections = selections_by_block.remove(&block.id).unwrap_or_default();
            block
                .schema_selections
                .sort_by_key(|selection| selection.offset);
        }
        let design_objects = crate::test_support::with_service_context(|ctx| {
            design_objects(ctx, &graphs, &entity_records)
        })
        .map_err(|error| {
            cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "CATIA design objects do not rederive: {error}"
            ))
        })?;
        let stored: Vec<CatiaDesignObject> = namespace.arena_as("design_objects")?;
        let stored_by_id = stored
            .iter()
            .map(|object| (object.id.as_str(), object))
            .collect::<HashMap<_, _>>();
        if stored_by_id.len() != stored.len()
            || stored.len() != design_objects.len()
            || design_objects
                .iter()
                .any(|object| stored_by_id.get(object.id.as_str()).copied() != Some(object))
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "stored CATIA design objects disagree with their object graph".to_string(),
            ));
        }
        let mut finjpl_segments: Vec<CatiaFinjplSegment> = namespace.arena_as("finjpl_segments")?;
        finjpl_segments.sort_by_key(|segment| segment.byte_offset);
        let mut external_references: Vec<CatiaExternalReference> =
            namespace.arena_as("external_references")?;
        external_references.sort_by_key(|reference| reference.byte_offset);
        let expected_external_references = external_reference_views(&finjpl_segments);
        if external_references != expected_external_references {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "stored CATIA external references disagree with their project-flags segments"
                    .to_string(),
            ));
        }
        let external_references = expected_external_references;
        let mut legacy_entity_runs: Vec<CatiaLegacyEntityRun> =
            namespace.arena_as("legacy_entity_runs")?;
        legacy_entity_runs.sort_by_key(|run| run.byte_offset);
        validate_legacy_entity_runs(&legacy_entity_runs)?;
        let mut preview_images: Vec<CatiaPreviewImage> = namespace.arena_as("preview_images")?;
        preview_images.sort_by_key(|preview| preview.byte_offset);
        let expected_preview_images = preview_views(&finjpl_segments);
        if preview_images != expected_preview_images {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                "stored CATIA previews disagree with their summary segments".to_string(),
            ));
        }
        let preview_images = expected_preview_images;
        let inline_fields = namespace.arena_as("inline_fields")?;
        let storage_property_members = namespace.arena_as("storage_property_members")?;
        let alias_rows: Vec<CatiaAliasRow> = namespace.arena_as("alias_rows")?;
        let mut consolidated_circles: Vec<CatiaConsolidatedCircle> =
            namespace.arena_as("consolidated_circles")?;
        consolidated_circles.sort_by_key(|circle| circle.byte_offset);
        validate_consolidated_circles(&consolidated_circles)?;
        let mut consolidated_four_reference_edges: Vec<
            crate::native::four_reference_edge::CatiaConsolidatedFourReferenceEdge,
        > = namespace.arena_as("consolidated_four_reference_edges")?;
        consolidated_four_reference_edges
            .sort_by_key(|record| (record.source_index, record.source_offset));
        validate_four_reference_edges(&consolidated_four_reference_edges)?;
        let mut consolidated_class61_records: Vec<CatiaConsolidatedClass61Record> =
            namespace.arena_as("consolidated_class61_records")?;
        consolidated_class61_records
            .sort_by_key(|record| (record.source_index, record.source_offset));
        crate::native::class61::validate(&consolidated_class61_records)?;
        let mut consolidated_class5b5c_records: Vec<CatiaConsolidatedClass5b5cRecord> =
            namespace.arena_as("consolidated_class5b5c_records")?;
        consolidated_class5b5c_records
            .sort_by_key(|record| (record.source_index, record.source_offset));
        validate_consolidated_class5b5c_records(&consolidated_class5b5c_records)?;
        let mut consolidated_chamfers: Vec<CatiaConsolidatedChamfer> =
            namespace.arena_as("consolidated_chamfers")?;
        consolidated_chamfers.sort_by_key(|face| face.byte_offset);
        let mut object_chamfers: Vec<CatiaObjectChamfer> = namespace.arena_as("object_chamfers")?;
        object_chamfers.sort_by_key(|row| row.byte_offset);
        super::test_consolidated::validate_object_chamfers(&object_chamfers)?;
        let mut consolidated_cones: Vec<CatiaConsolidatedCone> =
            namespace.arena_as("consolidated_cones")?;
        consolidated_cones.sort_by_key(|cone| cone.byte_offset);
        validate_consolidated_cones(&consolidated_cones)?;
        let mut consolidated_cylinders: Vec<CatiaConsolidatedCylinder> =
            namespace.arena_as("consolidated_cylinders")?;
        consolidated_cylinders.sort_by_key(|cylinder| cylinder.byte_offset);
        validate_consolidated_cylinders(&consolidated_cylinders)?;
        let mut consolidated_class60_records: Vec<
            crate::native::class60::CatiaConsolidatedClass60Record,
        > = namespace.arena_as("consolidated_class60_records")?;
        consolidated_class60_records
            .sort_by_key(|record| (record.source_index, record.source_offset));
        crate::native::class60::validate(&consolidated_class60_records)?;
        let mut consolidated_line_profiles: Vec<CatiaConsolidatedLineProfile> =
            namespace.arena_as("consolidated_line_profiles")?;
        consolidated_line_profiles.sort_by_key(|line| line.byte_offset);
        validate_consolidated_line_profiles(&consolidated_line_profiles)?;
        let mut consolidated_owner_packets: Vec<CatiaConsolidatedOwnerPacket> =
            namespace.arena_as("consolidated_owner_packets")?;
        consolidated_owner_packets.sort_by_key(|packet| packet.frame.pos);
        validate_consolidated_owner_packets(&consolidated_owner_packets)?;
        let mut consolidated_parameter_points: Vec<CatiaConsolidatedParameterPoint> =
            namespace.arena_as("consolidated_parameter_points")?;
        consolidated_parameter_points.sort_by_key(|point| point.byte_offset);
        validate_consolidated_parameter_points(&consolidated_parameter_points)?;
        validate_consolidated_chamfers(&consolidated_chamfers, &consolidated_parameter_points)?;
        let mut consolidated_plane_carriers: Vec<CatiaConsolidatedPlaneCarrier> =
            namespace.arena_as("consolidated_plane_carriers")?;
        consolidated_plane_carriers.sort_by_key(|carrier| carrier.byte_offset);
        validate_consolidated_plane_carriers(&consolidated_plane_carriers)?;
        let mut consolidated_pcurves: Vec<CatiaConsolidatedPcurve> =
            namespace.arena_as("consolidated_pcurves")?;
        consolidated_pcurves.sort_by_key(|pcurve| pcurve.byte_offset);
        validate_consolidated_pcurves(&consolidated_pcurves)?;
        let mut consolidated_reference_lists: Vec<CatiaConsolidatedReferenceList> =
            namespace.arena_as("consolidated_reference_lists")?;
        consolidated_reference_lists.sort_by_key(|list| list.byte_offset);
        validate_consolidated_reference_lists(&consolidated_reference_lists)?;
        let mut consolidated_revolutions: Vec<CatiaConsolidatedRevolution> =
            namespace.arena_as("consolidated_revolutions")?;
        consolidated_revolutions.sort_by_key(|revolution| revolution.byte_offset);
        validate_consolidated_revolutions(&consolidated_revolutions, &consolidated_circles)?;
        let mut consolidated_rolling_ball_constructions: Vec<
            CatiaConsolidatedRollingBallConstruction,
        > = namespace.arena_as("consolidated_rolling_ball_constructions")?;
        consolidated_rolling_ball_constructions
            .sort_by_key(|construction| construction.byte_offset);
        let mut consolidated_rolling_ball_continuations: Vec<
            crate::native::rolling_ball_continuation::CatiaRollingBallContinuation,
        > = namespace.arena_as("consolidated_rolling_ball_continuations")?;
        consolidated_rolling_ball_continuations
            .sort_by_key(|record| (record.source_index, record.source_offset));
        validate_rolling_ball_continuations(&consolidated_rolling_ball_continuations)?;
        let mut consolidated_spheres: Vec<CatiaConsolidatedSphere> =
            namespace.arena_as("consolidated_spheres")?;
        consolidated_spheres.sort_by_key(|sphere| sphere.byte_offset);
        validate_consolidated_spheres(&consolidated_spheres)?;
        let mut consolidated_tori: Vec<CatiaConsolidatedTorus> =
            namespace.arena_as("consolidated_tori")?;
        consolidated_tori.sort_by_key(|torus| torus.byte_offset);
        validate_consolidated_tori(&consolidated_tori)?;
        let mut consolidated_edge_runs: Vec<CatiaConsolidatedEdgeRun> =
            namespace.arena_as("consolidated_edge_runs")?;
        consolidated_edge_runs.sort_by_key(|run| run.byte_offset);
        let consolidated_edge_node_wires: Vec<CatiaConsolidatedEdgeNodeWire> =
            namespace.arena_as("consolidated_edge_nodes")?;
        let consolidated_vertex_identities: Vec<CatiaConsolidatedVertexIdentity> =
            namespace.arena_as("consolidated_vertex_identities")?;
        let mut consolidated_edge_nodes = load_edge_nodes(
            consolidated_edge_node_wires,
            &consolidated_vertex_identities,
        )
        .map_err(cadmpeg_ir::NativeConvertError::InvalidOwner)?;
        consolidated_edge_nodes.sort_by_key(|node| node.byte_offset);
        let zero_entity_allocation_edges = namespace.arena_as("zero_entity_allocation_edges")?;
        let mut zero_entity_edge_strides: Vec<CatiaZeroEntityEdgeStride> =
            namespace.arena_as("zero_entity_edge_strides")?;
        zero_entity_edge_strides.sort_by_key(|record| record.byte_offset);
        let mut zero_entity_oriented_use_pairs: Vec<CatiaZeroEntityOrientedUsePair> =
            namespace.arena_as("zero_entity_oriented_use_pairs")?;
        zero_entity_oriented_use_pairs.sort_by_key(|pair| pair.header_byte_offset);
        let zero_entity_ownership_roots: Vec<CatiaZeroEntityOwnershipRoot> =
            namespace.arena_as("zero_entity_ownership_roots")?;
        let mut zero_entity_records: Vec<CatiaZeroEntityRecord> =
            namespace.arena_as("zero_entity_records")?;
        zero_entity_records.sort_by_key(|record| record.record_ordinal);
        validate_zero_entity_records(&zero_entity_records)?;
        let mut zero_entity_support_runs: Vec<CatiaZeroEntitySupportRun> =
            namespace.arena_as("zero_entity_support_runs")?;
        zero_entity_support_runs.sort_by_key(|run| run.carrier_byte_offset);
        validate_zero_entity_support_runs(&zero_entity_support_runs, &zero_entity_records)?;
        validate_zero_entity_ownership_roots(
            &zero_entity_ownership_roots,
            &zero_entity_support_runs,
            &zero_entity_records,
        )?;
        let mut zero_entity_vertex_incidences: Vec<CatiaZeroEntityVertexIncidence> =
            namespace.arena_as("zero_entity_vertex_incidences")?;
        zero_entity_vertex_incidences.sort_by_key(|record| record.byte_offset);
        validate_zero_entity_topology_records(
            &zero_entity_edge_strides,
            &zero_entity_oriented_use_pairs,
            &zero_entity_vertex_incidences,
            &zero_entity_records,
        )?;
        crate::native::zero_entity_allocation::validate(
            &zero_entity_allocation_edges,
            &zero_entity_records,
            &zero_entity_edge_strides,
            &zero_entity_oriented_use_pairs,
            &zero_entity_vertex_incidences,
            &zero_entity_support_runs,
        )?;
        validate_consolidated_edge_runs(
            &consolidated_edge_runs,
            &consolidated_pcurves,
            &ConsolidatedSupportArenas {
                circles: &consolidated_circles,
                cones: &consolidated_cones,
                cylinders: &consolidated_cylinders,
                planes: &consolidated_plane_carriers,
                spheres: &consolidated_spheres,
                tori: &consolidated_tori,
            },
            &consolidated_edge_nodes,
            &consolidated_vertex_identities,
        )?;
        validate_native_links(
            &alias_rows,
            &catalogs,
            &graphs,
            &finjpl_segments,
            &value_blocks,
        )?;
        validate_alias_surface_tags(&alias_rows)?;
        validate_owner_chart_support_aliases(&consolidated_owner_packets, &alias_rows)?;
        let e5_curve_supports = namespace.arena_as("e5_curve_supports")?;
        let e5_edges = namespace.arena_as("e5_edges")?;
        let e5_nurbs_limit_programs = namespace.arena_as("e5_nurbs_limit_programs")?;
        let mut consolidated_a5_charts: Vec<crate::native::a5_chart::CatiaConsolidatedA5Chart> =
            namespace.arena_as("consolidated_a5_charts")?;
        consolidated_a5_charts.sort_by_key(|chart| (chart.source_index, chart.source_offset));
        for (index, chart) in consolidated_a5_charts.iter().enumerate() {
            if chart.id != format!("catia:consolidated:a5-chart#{index:00}") {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                    "invalid consolidated A5 chart identity".to_owned(),
                ));
            }
        }
        let mut consolidated_domain_relations: Vec<
            crate::native::domain_relation::CatiaConsolidatedDomainRelation,
        > = namespace.arena_as("consolidated_domain_relations")?;
        consolidated_domain_relations
            .sort_by_key(|relation| (relation.source_index, relation.source_offset));
        for (index, relation) in consolidated_domain_relations.iter().enumerate() {
            if relation.id != format!("catia:consolidated:domain-relation#{index:00}") {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                    "invalid consolidated domain relation identity".to_owned(),
                ));
            }
        }
        let mut consolidated_a_class25_maps: Vec<
            crate::native::a_class25_map::CatiaConsolidatedAClass25Map,
        > = namespace.arena_as("consolidated_a_class25_maps")?;
        consolidated_a_class25_maps.sort_by_key(|map| (map.source_index, map.source_offset));
        for (index, map) in consolidated_a_class25_maps.iter().enumerate() {
            if map.id != format!("catia:consolidated:a-class25-map#{index:00}") {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                    "invalid A-family class-25 map identity".to_owned(),
                ));
            }
        }
        let mut sampled_parameter_maps: Vec<
            crate::native::parameter_map::CatiaSampledParameterMap,
        > = namespace.arena_as("sampled_parameter_maps")?;
        sampled_parameter_maps.sort_by_key(|map| (map.source_index, map.source_offset));
        for (index, map) in sampled_parameter_maps.iter().enumerate() {
            if map.id != format!("catia:a8:sampled-parameter-map#{index:00}") {
                return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(
                    "invalid sampled parameter map identity".to_owned(),
                ));
            }
        }
        Ok(Self {
            sampled_parameter_maps,
            alias_rows,
            inline_fields,
            storage_property_members,
            catalogs,
            consolidated_circles,
            consolidated_class61_records,
            consolidated_class5b5c_records,
            consolidated_chamfers,
            object_chamfers,
            consolidated_cones,
            consolidated_cylinders,
            consolidated_a5_charts,
            consolidated_domain_relations,
            consolidated_a_class25_maps,
            consolidated_four_reference_edges,
            consolidated_edge_nodes,
            consolidated_edge_runs,
            consolidated_class60_records,
            consolidated_line_profiles,
            consolidated_owner_packets,
            consolidated_parameter_points,
            consolidated_plane_carriers,
            consolidated_pcurves,
            consolidated_reference_lists,
            consolidated_revolutions,
            consolidated_rolling_ball_constructions,
            consolidated_rolling_ball_continuations,
            consolidated_spheres,
            consolidated_tori,
            consolidated_vertex_identities,
            design_objects,
            e5_curve_supports,
            e5_edges,
            e5_nurbs_limit_programs,
            entity_records,
            external_references,
            finjpl_segments,
            legacy_entity_runs,
            object_graphs: graphs,
            preview_images,
            reference_signature_cohorts,
            schema_configuration_row_chains,
            value_blocks,
            zero_entity_allocation_edges,
            zero_entity_edge_strides,
            zero_entity_oriented_use_pairs,
            zero_entity_ownership_roots,
            zero_entity_records,
            zero_entity_support_runs,
            zero_entity_vertex_incidences,
        })
    }

    /// Store the typed CATIA namespace into generic native arenas.
    pub(crate) fn store(
        &self,
        namespace: &mut cadmpeg_ir::NativeNamespace,
    ) -> Result<(), cadmpeg_ir::NativeConvertError> {
        let ctx = cadmpeg_core::decode::test_support::service_decode_context();
        let projection = CatiaArenaProjection::from_owned(self.clone());
        store_projection(&ctx, &projection, namespace)
    }
}
