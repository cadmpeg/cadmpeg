// SPDX-License-Identifier: Apache-2.0

use crate::families::b2::records::{B2PlaneCarrierLayout, B2PlaneCarrierPayload};
use crate::native::chamfer::{CatiaConsolidatedChamfer, CatiaObjectChamfer};
use crate::native::class5b5c::CatiaConsolidatedClass5b5cRecord;
use crate::native::{
    CatiaConsolidatedCircle, CatiaConsolidatedCone, CatiaConsolidatedCylinder,
    CatiaConsolidatedCylinderPayload, CatiaConsolidatedLineProfile,
    CatiaConsolidatedParameterPoint, CatiaConsolidatedPcurve, CatiaConsolidatedPlaneCarrier,
    CatiaConsolidatedReferenceList, CatiaConsolidatedRevolution, CatiaConsolidatedSphere,
    CatiaConsolidatedTorus,
};
use cadmpeg_ir::geometry::nurbs::knots_strictly_increasing;
use cadmpeg_ir::scalar::FiniteReal;
use std::collections::HashMap;
use std::mem::size_of;

pub(super) fn validate_consolidated_class5b5c_records(
    records: &[CatiaConsolidatedClass5b5cRecord],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, record) in records.iter().enumerate() {
        let source_order_valid = index == 0
            || (
                records[index - 1].source_index,
                records[index - 1].source_offset,
            ) < (record.source_index, record.source_offset);
        if record.id != format!("catia:consolidated:class5b5c-record#{index}")
            || !source_order_valid
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated class-0x5b/0x5c record `{}` is structurally invalid",
                record.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_chamfers(
    rows: &[CatiaConsolidatedChamfer],
    parameter_points: &[CatiaConsolidatedParameterPoint],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    let points = parameter_points
        .iter()
        .map(|point| (point.id.as_str(), point))
        .collect::<HashMap<_, _>>();
    for (index, row) in rows.iter().enumerate() {
        let mut next = row.byte_offset.checked_add(row.byte_len);
        let valid_contacts = row.parameter_points.iter().enumerate().all(|(index, id)| {
            let Some(point) = points.get(id.as_str()) else {
                return false;
            };
            if Some(point.byte_offset) != next
                || point.operand.value() != u32::try_from(index + 1).unwrap_or(u32::MAX)
            {
                return false;
            }
            next = point.byte_offset.checked_add(point.byte_len);
            next.is_some()
        });
        let payload_len = 24
            + row
                .support_surfaces
                .iter()
                .chain(&row.support_pcurves)
                .map(|reference| u64::from(reference.byte_len()))
                .sum::<u64>();
        if row.id != format!("catia:consolidated:chamfer#{index}")
            || !matches!(row.byte_len.checked_sub(payload_len), Some(5..=7))
            || row
                .support_surfaces
                .iter()
                .any(|reference| reference.byte_len() == 1)
            || (row.support_pcurves[0].byte_len() == 1) != (row.support_pcurves[1].byte_len() == 1)
            || !matches!(row.parameter_points.len(), 0 | 2 | 4)
            || !valid_contacts
            || index > 0 && rows[index - 1].byte_offset >= row.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated chamfer `{}` is structurally invalid",
                row.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_object_chamfers(
    rows: &[CatiaObjectChamfer],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, row) in rows.iter().enumerate() {
        let payload_len = 23
            + row
                .references
                .iter()
                .map(|reference| u64::from(reference.byte_len()))
                .sum::<u64>();
        if row.id != format!("catia:object:chamfer#{index}")
            || row.byte_len != payload_len + 8
            || index > 0 && rows[index - 1].byte_offset >= row.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "object chamfer `{}` is structurally invalid",
                row.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_pcurves(
    pcurves: &[CatiaConsolidatedPcurve],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, pcurve) in pcurves.iter().enumerate() {
        let expected_id = format!("catia:consolidated:pcurve#{index}");
        let count = pcurve.knots.len();
        if pcurve.id != expected_id
            || pcurve.degree != 5
            || count < 2
            || pcurve.points.len() != count
            || pcurve.first_derivatives.len() != count
            || pcurve.second_derivatives.len() != count
            || !knots_strictly_increasing(&FiniteReal::raw_lane(&pcurve.knots))
            || !matches!(pcurve.tail.as_slice(), [0x07] | [0x07, 0x00])
            || index > 0 && pcurves[index - 1].byte_offset >= pcurve.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated pcurve `{}` is structurally invalid",
                pcurve.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_circles(
    circles: &[CatiaConsolidatedCircle],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, circle) in circles.iter().enumerate() {
        let compact_len =
            usize::from(u8::from(circle.layout)).checked_sub(5 * size_of::<f64>() + 9);
        let record_id_fits_layout = matches!(
            (compact_len, circle.record_id),
            (Some(1), 0..=63) | (Some(2), 0..=255) | (Some(3), 0..=65_535)
        );
        if circle.id != format!("catia:consolidated:circle#{index}")
            || !record_id_fits_layout
            || circle.center_pair.iter().any(|value| value.abs() > 1e6)
            || index > 0 && circles[index - 1].byte_offset >= circle.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated circle `{}` is structurally invalid",
                circle.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_cones(
    cones: &[CatiaConsolidatedCone],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, cone) in cones.iter().enumerate() {
        let expected_id = format!("catia:consolidated:cone#{index}");
        let direction_x = cone.direction_x.get();
        let direction_y = cone.direction_y.get();
        let axis = cone.axis.get();
        let cross = [
            direction_x[1] * direction_y[2] - direction_x[2] * direction_y[1],
            direction_x[2] * direction_y[0] - direction_x[0] * direction_y[2],
            direction_x[0] * direction_y[1] - direction_x[1] * direction_y[0],
        ];
        if cone.id != expected_id
            || cross
                .iter()
                .zip(axis)
                .any(|(cross, axis)| (cross - axis).abs() > 1.0e-9)
            || cone.half_angle.get() <= 0.0
            || cone.half_angle.get() >= std::f64::consts::FRAC_PI_2
            || !crate::analytic::periodic_angular_range_is_valid(
                cone.angular_range.endpoints(),
                cone.angular_domain.endpoints(),
            )
            || cone.slant_range.lower() < 0.0
            || index > 0 && cones[index - 1].byte_offset >= cone.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated cone `{}` is structurally invalid",
                cone.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_cylinders(
    cylinders: &[CatiaConsolidatedCylinder],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, cylinder) in cylinders.iter().enumerate() {
        let expected_id = format!("catia:consolidated:cylinder#{index}");
        let dot = |first: [f64; 3], second: [f64; 3]| {
            first[0] * second[0] + first[1] * second[1] + first[2] * second[2]
        };
        let payload_valid = match &cylinder.payload {
            CatiaConsolidatedCylinderPayload::Layout52 {
                frame_token,
                axis,
                reference_direction,
            } => {
                *frame_token == 0x1d
                    && axis.get() == [1.0, 0.0, 0.0]
                    && reference_direction.get() == [0.0, 1.0, 0.0]
                    && dot(axis.get(), reference_direction.get()).abs() <= 1.0e-9
                    && crate::families::b2::records::circle_range_is_full_turn(
                        cylinder.radius.get(),
                        cylinder.u_range.endpoints(),
                    )
            }
            CatiaConsolidatedCylinderPayload::Layout5a {
                frame_token,
                axis,
                reference_direction,
            } => {
                matches!(*frame_token, 0x19 | 0x1c)
                    && axis.get()[2] == 0.0
                    && reference_direction.get() == [-axis.get()[1], axis.get()[0], 0.0]
                    && dot(axis.get(), reference_direction.get()).abs() <= 1.0e-9
                    && crate::families::b2::records::circle_range_is_full_turn(
                        cylinder.radius.get(),
                        cylinder.u_range.endpoints(),
                    )
            }
            CatiaConsolidatedCylinderPayload::RangeOrigin {
                stored_vector,
                axis,
                reference_direction,
                range_origin,
            } => {
                cylinder.payload.layout() == 0x62
                    && range_origin.is_finite()
                    && axis.get() == [0.0, 1.0, 0.0]
                    && reference_direction.get()
                        == [stored_vector.get()[0], 0.0, stored_vector.get()[1]]
                    && crate::families::b2::records::circle_range_is_within_full_turn(
                        cylinder.radius.get(),
                        cylinder.u_range.endpoints(),
                    )
                    && range_origin.to_bits()
                        == crate::families::b2::records::cylinder_range_origin(
                            cylinder.radius.get(),
                            cylinder.u_range.endpoints(),
                        )
                        .to_bits()
            }
        };
        if cylinder.id != expected_id
            || !payload_valid
            || index > 0 && cylinders[index - 1].byte_offset >= cylinder.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated cylinder `{}` is structurally invalid",
                cylinder.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_parameter_points(
    points: &[CatiaConsolidatedParameterPoint],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, point) in points.iter().enumerate() {
        let frame_overhead = point
            .byte_len
            .checked_sub(u64::from(point.payload.byte_len(point.operand)));
        if point.id != format!("catia:consolidated:parameter-point#{index}")
            || !matches!(frame_overhead, Some(5..=7))
            || !point.payload.matches_control(point.control)
            || index > 0 && points[index - 1].byte_offset >= point.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated parameter point `{}` is structurally invalid",
                point.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_plane_carriers(
    carriers: &[CatiaConsolidatedPlaneCarrier],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, carrier) in carriers.iter().enumerate() {
        let (scalar_count, payload_valid) = match &carrier.payload {
            B2PlaneCarrierPayload::Plane { layout, .. } => {
                (layout.scalar_count(), carrier.payload.valid_plane())
            }
            B2PlaneCarrierPayload::ScalarLane { selector, values } => (
                values.len(),
                !values.is_empty() && B2PlaneCarrierLayout::try_from(*selector).is_err(),
            ),
        };
        let header_limit = 1u32 << (8 * u8::from(carrier.width));
        let scalar_count = u64::try_from(scalar_count).map_err(|_| {
            cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated plane carrier `{}` has too many scalars",
                carrier.id
            ))
        })?;
        let expected_len = 4 + u64::from(u8::from(carrier.width)) + 2 + 8 * scalar_count;
        if carrier.id != format!("catia:consolidated:plane-carrier#{index}")
            || carrier.header_token >= header_limit
            || carrier.byte_len != expected_len
            || !payload_valid
            || index > 0 && carriers[index - 1].byte_offset >= carrier.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated plane carrier `{}` is structurally invalid",
                carrier.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_reference_lists(
    lists: &[CatiaConsolidatedReferenceList],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, list) in lists.iter().enumerate() {
        if list.id != format!("catia:consolidated:reference-list#{index}")
            || list.references.is_empty()
            || index > 0 && lists[index - 1].byte_offset >= list.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated reference list `{}` is structurally invalid",
                list.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_revolutions(
    revolutions: &[CatiaConsolidatedRevolution],
    circles: &[CatiaConsolidatedCircle],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, revolution) in revolutions.iter().enumerate() {
        let mut profile_candidates = circles.iter().filter(|circle| {
            circle.range.lower().to_bits() == revolution.profile_range.lower().to_bits()
                && circle.range.upper().to_bits() == revolution.profile_range.upper().to_bits()
        });
        let expected_profile = profile_candidates.next().and_then(|circle| {
            profile_candidates
                .next()
                .is_none()
                .then_some(circle.id.as_str())
        });
        let expected_id = format!("catia:consolidated:revolution#{index}");
        let direction_x = revolution.direction_x.get();
        let direction_y = revolution.direction_y.get();
        let axis = revolution.axis.get();
        let cross = [
            direction_x[1] * direction_y[2] - direction_x[2] * direction_y[1],
            direction_x[2] * direction_y[0] - direction_x[0] * direction_y[2],
            direction_x[0] * direction_y[1] - direction_x[1] * direction_y[0],
        ];
        if revolution.id != expected_id
            || revolution.profile_reference == 0
            || revolution.profile_circle.as_deref() != expected_profile
            || cross
                .iter()
                .zip(axis)
                .any(|(cross, axis)| (cross - axis).abs() > 1.0e-12)
            || revolution.angular_range.lower() / revolution.angular_scale.get() != 0.5
            || (revolution.angular_range.upper() - revolution.angular_range.lower())
                / revolution.angular_scale.get()
                != std::f64::consts::TAU
            || index > 0 && revolutions[index - 1].byte_offset >= revolution.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated revolution `{}` is structurally invalid",
                revolution.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_line_profiles(
    lines: &[CatiaConsolidatedLineProfile],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, line) in lines.iter().enumerate() {
        if line.id != format!("catia:consolidated:line-profile#{index}")
            || index > 0 && lines[index - 1].byte_offset >= line.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated line profile `{}` is structurally invalid",
                line.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_spheres(
    spheres: &[CatiaConsolidatedSphere],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, sphere) in spheres.iter().enumerate() {
        let expected_id = format!("catia:consolidated:sphere#{index}");
        let dot = |first: [f64; 3], second: [f64; 3]| {
            first[0] * second[0] + first[1] * second[1] + first[2] * second[2]
        };
        let direction_x = sphere.direction_x.get();
        let direction_y = sphere.direction_y.get();
        let axis = sphere.axis.get();
        let cross = [
            direction_x[1] * direction_y[2] - direction_x[2] * direction_y[1],
            direction_x[2] * direction_y[0] - direction_x[0] * direction_y[2],
            direction_x[0] * direction_y[1] - direction_x[1] * direction_y[0],
        ];
        if sphere.id != expected_id
            || dot(direction_x, direction_y).abs() > 1.0e-12
            || dot(direction_x, axis).abs() > 1.0e-12
            || dot(direction_y, axis).abs() > 1.0e-12
            || cross
                .iter()
                .zip(axis)
                .any(|(cross, axis)| (cross - axis).abs() > 1.0e-12)
            || !crate::analytic::sphere_angular_ranges_are_valid(
                sphere.azimuth_range.endpoints(),
                sphere.latitude_range.endpoints(),
            )
            || index > 0 && spheres[index - 1].byte_offset >= sphere.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated sphere `{}` is structurally invalid",
                sphere.id
            )));
        }
    }
    Ok(())
}

pub(super) fn validate_consolidated_tori(
    tori: &[CatiaConsolidatedTorus],
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    for (index, torus) in tori.iter().enumerate() {
        let expected_id = format!("catia:consolidated:torus#{index}");
        let dot = |first: [f64; 3], second: [f64; 3]| {
            first[0] * second[0] + first[1] * second[1] + first[2] * second[2]
        };
        let direction_x = torus.direction_x.get();
        let direction_y = torus.direction_y.get();
        let axis = torus.axis.get();
        let cross = [
            direction_x[1] * direction_y[2] - direction_x[2] * direction_y[1],
            direction_x[2] * direction_y[0] - direction_x[0] * direction_y[2],
            direction_x[0] * direction_y[1] - direction_x[1] * direction_y[0],
        ];
        if torus.id != expected_id
            || dot(direction_x, direction_y).abs() > 1.0e-12
            || dot(direction_x, axis).abs() > 1.0e-12
            || dot(direction_y, axis).abs() > 1.0e-12
            || cross
                .iter()
                .zip(axis)
                .any(|(cross, axis)| (cross - axis).abs() > 1.0e-12)
            || !crate::analytic::periodic_angular_range_is_valid(
                torus.major_angular_range.endpoints(),
                torus.major_angular_domain.endpoints(),
            )
            || !crate::analytic::periodic_angular_range_is_valid(
                torus.minor_angular_range.endpoints(),
                torus.minor_angular_domain.endpoints(),
            )
            || index > 0 && tori[index - 1].byte_offset >= torus.byte_offset
        {
            return Err(cadmpeg_ir::NativeConvertError::InvalidOwner(format!(
                "consolidated torus `{}` is structurally invalid",
                torus.id
            )));
        }
    }
    Ok(())
}
