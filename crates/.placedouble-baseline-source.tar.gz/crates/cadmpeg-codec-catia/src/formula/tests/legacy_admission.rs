// SPDX-License-Identifier: Apache-2.0
//! Entity admission for the three legacy parameter packet forms.

use cadmpeg_ir::document::CadIr;

fn legacy_values() -> crate::native::CatiaNative {
    let mut bytes = Vec::new();
    for entity_id in [1_u32, 4, 9, 12, 13] {
        bytes.push(0xea);
        bytes.extend(entity_id.to_le_bytes());
        bytes.extend([0x81, 0xfd, 0x8c]);
        if entity_id == 4 {
            for (role, selector, value) in [
                ("body", vec![0x80, 4, 0, 0, 0], "#1_ + 2"),
                ("param", vec![0xd1, 8], "(#1_ : #In Real) : Real\n"),
            ] {
                bytes.push(u8::try_from(role.len() + 1).expect("short role"));
                bytes.extend(role.as_bytes());
                bytes.extend(selector);
                bytes.extend(b"\xe8\x00\x12\x01");
                bytes.push(u8::try_from(value.len() + 1).expect("short text"));
                bytes.extend(value.as_bytes());
                bytes.push(0xfe);
            }
        } else if entity_id == 9 {
            bytes.extend([8, b'p', b'a', b'r', b'a', b'm', b'i', b'n', 0x80]);
            bytes.extend(4134_u32.to_le_bytes());
            bytes.extend([0xe8, 0xe4, 0x0b, 0x01]);
            bytes.extend(b"\xfe\x84\x92\x82\x05Real\x83");
            bytes.extend([5, b'n', b'a', b'm', b'e', 0xd1, 9]);
            bytes.extend(b"\xe8\x00\x12\x01\x07Result\xfe");
            bytes.extend(b"\xfe\x84\x88\x82\xfe\xe6");
            bytes.extend(3.5_f64.to_bits().to_le_bytes());
        } else if entity_id == 12 {
            bytes.extend([5, b'n', b'a', b'm', b'e', 0xd1, 11]);
            bytes.extend(b"\xe8\x00\x12\x01\x0cResponsible\xfe");
            bytes.extend(b"\xfe\x84\x92\x82\x07String\x83");
            bytes.extend(b"\xfe\x85\x93\x82\xfe\x0cCilas Evans");
        } else if entity_id == 13 {
            bytes.extend([5, b'n', b'a', b'm', b'e', 0xd1, 12]);
            bytes.extend(b"\xe8\x00\x12\x01\x06Count\xfe");
            bytes.extend(b"\xfe\x84\x92\x82\x08Integer\x83");
            bytes.extend(b"\xfe\x85\x9d\x82\xfe\x8c");
        }
    }
    bytes.extend(b"\xde\x04\xfe\xfe\x12CATCatalogManager");
    bytes.extend(b"\xfe\xfe\xfe");
    bytes.extend([0x81, 0x04, b'F', b'o', b'o', 0x84, 0xfe]);
    bytes.extend(b"\x4e\x11\x00\x00\x00DASSAULT-SYSTEMES\x05\x00\x00\x00CATIA");
    let native = crate::native::CatiaNative::decode(&bytes);
    let [run] = native.legacy_entity_runs.as_slice() else {
        panic!("one complete legacy entity run");
    };
    assert_eq!(run.scalar_values.len(), 1);
    assert_eq!(run.string_values.len(), 1);
    assert_eq!(run.integer_values.len(), 1);
    native
}

fn assert_first_candidate_refused(native: &crate::native::CatiaNative) {
    crate::test_support::with_entity_limit(0, |ctx| {
        let mut ir = CadIr::empty();
        let Err(cadmpeg_core::CodecError::ResourceLimit(limit)) =
            crate::formula::transfer_parameters(
                ctx,
                &mut ir,
                native,
                &mut cadmpeg_ir::Annotations::default(),
                &crate::decode::ModelingGraphScope::Unscoped,
            )
        else {
            panic!("legacy candidate must exceed the zero entity limit");
        };
        assert_eq!(
            limit.dimension,
            cadmpeg_core::decode::ResourceDimension::Entities
        );
        assert_eq!(limit.used, 0);
        assert_eq!(limit.operation, "admit CATIA formula candidate");
        assert!(ir.model.parameters.is_empty());
    });
}

#[test]
fn formula_legacy_scalar_limit_refuses_before_candidate_creation() {
    let mut native = legacy_values();
    let run = &mut native.legacy_entity_runs[0];
    run.string_values.clear();
    run.integer_values.clear();
    assert_first_candidate_refused(&native);
}

#[test]
fn formula_legacy_string_limit_refuses_before_candidate_creation() {
    let mut native = legacy_values();
    let run = &mut native.legacy_entity_runs[0];
    run.scalar_values.clear();
    run.integer_values.clear();
    assert_first_candidate_refused(&native);
}

#[test]
fn formula_legacy_integer_limit_refuses_before_candidate_creation() {
    let mut native = legacy_values();
    let run = &mut native.legacy_entity_runs[0];
    run.scalar_values.clear();
    run.string_values.clear();
    assert_first_candidate_refused(&native);
}

#[test]
fn formula_legacy_candidates_transfer_under_service_profile() {
    let native = legacy_values();
    let mut ir = CadIr::empty();
    crate::test_support::with_service_context(|ctx| {
        crate::formula::transfer_parameters(
            ctx,
            &mut ir,
            &native,
            &mut cadmpeg_ir::Annotations::default(),
            &crate::decode::ModelingGraphScope::Unscoped,
        )
    })
    .expect("transfer parameters");
    assert_eq!(ir.model.parameters.len(), 3);
}

#[test]
fn legacy_types_follow_unique_selector_chains() {
    let descriptor = |entity_id: u32, value: serde_json::Value| {
        serde_json::from_value::<crate::native::CatiaLegacyTypeDescriptor>(serde_json::json!({
            "byte_offset": 0,
            "entity_id": entity_id,
            "value": value,
        }))
        .expect("descriptor wire")
    };
    let name = |value: &str| serde_json::json!({ "Name": { "value": value } });
    let selector = |value: u32| serde_json::json!({ "Selector": { "value": value } });
    let descriptors = [
        descriptor(1, name("Length")),
        descriptor(2, selector(1)),
        descriptor(3, selector(2)),
        descriptor(4, selector(5)),
        descriptor(5, selector(4)),
        descriptor(6, selector(9)),
        descriptor(7, name("Real")),
        descriptor(7, name("Angle")),
        descriptor(8, selector(7)),
    ];
    let types = super::super::LegacyTypes::new(&descriptors);
    assert_eq!(types.resolved(1), Some(("Length", false)));
    assert_eq!(types.resolved(2), Some(("Length", true)));
    assert_eq!(types.resolved(3), Some(("Length", true)));
    // A selector cycle, a missing target, a repeated descriptor and a chain
    // into a repeated descriptor resolve nothing.
    assert_eq!(types.resolved(4), None);
    assert_eq!(types.resolved(5), None);
    assert_eq!(types.resolved(6), None);
    assert_eq!(types.resolved(7), None);
    assert_eq!(types.resolved(8), None);
    assert_eq!(types.resolved(9), None);
    assert!(types.descriptors.contains_key(&7));
    assert!(!types.descriptors.contains_key(&9));
}

/// Every input name `symbol` binds, listed one whitespace prefix at a time.
fn materialised_symbol_input_forms(symbol: &str) -> Vec<&str> {
    let mut forms = Vec::new();
    let mut push_whitespace_prefixes = |end: usize| {
        let start = symbol[..end]
            .trim_end_matches(|character: char| character.is_ascii_whitespace())
            .len();
        for form_end in start..=end {
            forms.push(&symbol[..form_end]);
        }
    };
    push_whitespace_prefixes(symbol.len());
    if let Some(slash) = symbol.rfind('/') {
        let ordinal = &symbol[slash + 1..];
        if !ordinal.is_empty() && ordinal.bytes().all(|byte| byte.is_ascii_digit()) {
            push_whitespace_prefixes(slash);
        }
    }
    forms
}

#[test]
fn relation_symbol_binds_inputs_up_to_its_ordinal() {
    for (symbol, forms) in [
        ("#1_", &["#1_"][..]),
        ("#1_/2", &["#1_/2", "#1_"]),
        ("#1_  /23", &["#1_  /23", "#1_", "#1_ ", "#1_  "]),
        ("#1_ ", &["#1_", "#1_ "]),
        ("#1_ /", &["#1_ /"]),
        ("#1_ /2a", &["#1_ /2a"]),
    ] {
        let heads = super::super::LegacySymbolHeads::new([symbol]);
        let extended = format!("{symbol} ");
        for end in 0..=extended.len() {
            let input = &extended[..end];
            assert_eq!(
                heads.binds(input),
                forms.contains(&input),
                "{symbol:?} binding {input:?}"
            );
        }
    }
}

#[test]
fn symbol_heads_bind_across_a_long_whitespace_run() {
    const SPACES: usize = 1 << 20;
    let spaces = " ".repeat(SPACES);
    let symbol = format!("#1_{spaces}/1");
    let heads = super::super::LegacySymbolHeads::new([symbol.as_str()]);
    assert!(heads.binds("#1_"));
    assert!(heads.binds("#1_ "));
    assert!(heads.binds(&format!("#1_{spaces}")));
    assert!(heads.binds(&symbol));
    assert!(!heads.binds("#1_\t"));
    assert!(!heads.binds(&format!("#1_{spaces} ")));
    assert!(!heads.binds("#2_"));
}

#[test]
fn symbol_heads_bind_exactly_the_materialised_input_forms() {
    let words = |max_len: usize| {
        let mut words = vec![String::new()];
        let mut layer = vec![String::new()];
        for _ in 0..max_len {
            layer = layer
                .iter()
                .flat_map(|word| ['a', ' ', '\t', '/', '1'].map(|next| format!("{word}{next}")))
                .collect();
            words.extend(layer.iter().cloned());
        }
        words
    };
    let inputs = words(4);
    let symbols = words(3);
    for symbol in &symbols {
        let heads = super::super::LegacySymbolHeads::new([symbol.as_str()]);
        let forms = materialised_symbol_input_forms(symbol);
        for input in &inputs {
            assert_eq!(
                heads.binds(input),
                forms.contains(&input.as_str()),
                "{symbol:?} binding {input:?}"
            );
        }
    }
    let heads = super::super::LegacySymbolHeads::new(symbols.iter().map(String::as_str));
    let forms = symbols
        .iter()
        .flat_map(|symbol| materialised_symbol_input_forms(symbol))
        .collect::<std::collections::HashSet<_>>();
    for input in &inputs {
        assert_eq!(
            heads.binds(input),
            forms.contains(input.as_str()),
            "binding {input:?}"
        );
    }
}
