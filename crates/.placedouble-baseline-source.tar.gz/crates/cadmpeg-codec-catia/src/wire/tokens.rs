// SPDX-License-Identifier: Apache-2.0
//! Compact-atom, compact-int, and reference-token readers.
//!
//! `object_ref` and `compact_uint` expose the `(&[u8], &mut usize)` signature
//! used by the `b5` and `e5` scan loops. `object_ref` and `compact_uint` are thin
//! adapters over [`Cursor`], which owns the byte semantics; `counted_refs`
//! composes `object_ref`. The free-function surface is the settled boundary
//! between those position-threading loops and the cursor.

use super::cursor::Cursor;

/// Reads a reference token at `*position`, advancing `*position` past it.
///
/// `extended` selects the token dialect. Most `e5` payloads use the restricted
/// dialect (`extended = false`): the lead bytes `0x38`, `0x18`, `0x10`,
/// `0x08`, and any `0x80..=0xff`. `b5` payloads use the extended dialect
/// (`extended = true`), which additionally recognises `0x30`, `0x28`, and
/// `0x20`. Any other lead byte fails the read without advancing.
pub(crate) fn object_ref(bytes: &[u8], position: &mut usize, extended: bool) -> Option<u32> {
    let mut cursor = Cursor::new_at(bytes, *position)?;
    let value = cursor.object_ref(extended)?;
    *position = cursor.position();
    Some(value)
}

/// Reads a compact unsigned integer at `*position`, advancing past it.
///
/// See [`Cursor::compact_uint`] for the encoding.
pub(crate) fn compact_uint(bytes: &[u8], position: &mut usize) -> Option<u32> {
    let mut cursor = Cursor::new_at(bytes, *position)?;
    let value = cursor.compact_uint()?;
    *position = cursor.position();
    Some(value)
}

/// Reads a count-prefixed reference list: a lead byte `0x80 + count` followed
/// by `count` reference tokens of the given `extended` dialect.
///
/// Returns the references and the offset just past the last token. Callers
/// that require the payload to be fully consumed check the returned offset
/// against the payload length themselves.
pub(crate) fn counted_refs(payload: &[u8], extended: bool) -> Option<(Vec<u32>, usize)> {
    let count = payload.first().and_then(|lead| lead.checked_sub(0x80))?;
    let mut position = 1;
    let references = (0..count)
        .map(|_| object_ref(payload, &mut position, extended))
        .collect::<Option<Vec<_>>>();
    references.map(|references| (references, position))
}

/// Read a catalog/entity compact atom and return its value and end offset.
///
/// Leads `0x80..=0xd0` encode `0..=80`. Leads `0xd1..=0xe4` encode
/// `(lead - 0xd1) * 256 + tail + 1`. Other leads and truncated atoms fail.
pub(crate) fn compact_atom(data: &[u8], at: usize) -> Option<(u32, usize)> {
    let byte = *data.get(at)?;
    match byte {
        0x80..=0xd0 => Some((u32::from(byte - 0x80), at + 1)),
        0xd1..=0xe4 => Some((
            u32::from(byte - 0xd1) * 256 + u32::from(*data.get(at + 1)?) + 1,
            at + 2,
        )),
        _ => None,
    }
}
