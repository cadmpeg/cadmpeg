// SPDX-License-Identifier: Apache-2.0
//! Byte-offset and value constants generated from `docs/layouts/catia.toml`.
//!
//! Do not edit by hand. Regenerate with:
//! `UPDATE_LAYOUT_CODE=1 cargo test -p cadmpeg --test layout_tables`.

/// Tag constants from the table inventory.
pub(crate) mod token {
    /// `named stream block` (`FINJPL  `). Spec §4.
    pub(crate) const NAMED_STREAM_BLOCK: [u8; 8] = *b"FINJPL  ";
    /// `E5 record family` (`E5 0D 03`). Spec §4.
    pub(crate) const E5_RECORD_FAMILY: [u8; 3] = [0xe5, 0x0d, 0x03];
}

/// Byte offsets for the `outer_header` record.
///
/// Spec §3.1. Record length 64 B.
///
/// ```text
/// `directory_offset + directory_length == file_size`. The parser reads only the magic and the two directory words; the fill and flag regions are never read.
/// ```
pub(crate) mod outer_header {
    /// Stated value of `magic` (`bytes[8]`). Spec §3.1.
    pub(crate) const MAGIC_VALUE: [u8; 8] = *b"V5_CFV2\0";
    /// Offset of `directory_offset` (`u32`, big-endian). Spec §3.1.
    pub(crate) const DIRECTORY_OFFSET: usize = 8;
    /// Offset of `directory_length` (`u32`, big-endian). Spec §3.1.
    pub(crate) const DIRECTORY_LENGTH: usize = 12;
    /// Offset of `fill_ff` (`bytes[8]`). Spec §3.1.
    pub(crate) const FILL_FF: usize = 16;
}

/// Byte offsets for the `inner_header` record.
///
/// Spec §3.2. Record length 16 B.
///
/// ```text
/// `inner` is the first `V5_CFV2\0` after outer byte 8. `diroff = inner + A`.
/// ```
pub(crate) mod inner_header {
    /// Record length in bytes. Spec §3.2.
    pub(crate) const LEN: usize = 16;
    /// Offset of `directory_offset_delta` (`u32`, big-endian). Spec §3.2.
    pub(crate) const DIRECTORY_OFFSET_DELTA: usize = 8;
    /// Offset of `directory_length` (`u32`, big-endian). Spec §3.2.
    pub(crate) const DIRECTORY_LENGTH: usize = 12;
}

/// Byte offsets for the `stream_descriptor_header` record.
///
/// Spec §3.4. Record length 84 B.
///
/// ```text
/// Descriptor-relative. `k` extent structs of 20 bytes each follow at ds+0x54. The standard name form ends at the three-byte tail ds-3..ds (`00 00 00`); the legacy form starts at ds+0x10 and ends with the same UTF-16LE terminator, with zero fill through ds+0x50.
/// ```
pub(crate) mod stream_descriptor_header {
    /// Record length in bytes. Spec §3.4.
    pub(crate) const LEN: usize = 84;
    /// Offset of `logical_stream_length` (`u32`, big-endian). Spec §3.4.
    pub(crate) const LOGICAL_STREAM_LENGTH: usize = 12;
    /// Offset of `extent_count` (`u32`, big-endian). Spec §3.4.
    pub(crate) const EXTENT_COUNT: usize = 80;
}

/// Byte offsets for the `extent_struct` record.
///
/// Spec §3.4. Record length 20 B.
///
/// ```text
/// `inner + phys_off + phys_len <= filesize`, `phys_len != 0`, `log_off` cumulative from 0, `log_len == phys_len`, and `sum(log_len) == logical_stream_length`.
/// ```
pub(crate) mod extent_struct {
    /// Record length in bytes. Spec §3.4.
    pub(crate) const LEN: usize = 20;
    /// Offset of `phys_off` (`u32`, big-endian). Spec §3.4.
    pub(crate) const PHYS_OFF: usize = 0;
    /// Offset of `phys_len` (`u32`, big-endian). Spec §3.4.
    pub(crate) const PHYS_LEN: usize = 4;
    /// Offset of `log_len` (`u32`, big-endian). Spec §3.4.
    pub(crate) const LOG_LEN: usize = 8;
    /// Offset of `log_off` (`u32`, big-endian). Spec §3.4.
    pub(crate) const LOG_OFF: usize = 12;
    /// Offset of `trailing_word` (`u32`, big-endian). Spec §3.4.
    pub(crate) const TRAILING_WORD: usize = 16;
}

/// Byte offsets for the `visible_body_roster_prefix` record.
///
/// Spec §3.1. Record length 4 B.
///
/// ```text
/// The count is followed by count positive u32le allocation ends and four zero u32le words.
/// ```
pub(crate) mod visible_body_roster_prefix {
    /// Record length in bytes. Spec §3.1.
    pub(crate) const LEN: usize = 4;
    /// Offset of `count` (`u32`, little-endian). Spec §3.1.
    pub(crate) const COUNT: usize = 0;
}

/// Byte offsets for the `visible_body_roster_suffix` record.
///
/// Spec §3.1. Record length 16 B.
pub(crate) mod visible_body_roster_suffix {
    /// Record length in bytes. Spec §3.1.
    pub(crate) const LEN: usize = 16;
}

/// Byte offsets for the `vertex_roster_row` record.
///
/// Spec §3.5. Record length 7 B.
///
/// ```text
/// The tags are unique and strictly increasing across the run.
/// ```
pub(crate) mod vertex_roster_row {
    /// Record length in bytes. Spec §3.5.
    pub(crate) const LEN: usize = 7;
    /// Offset of `marker` (`u8`). Spec §3.5.
    pub(crate) const MARKER: usize = 0;
    /// Offset of `tag` (`u24`, little-endian). Spec §3.5.
    pub(crate) const TAG: usize = 1;
    /// Offset of `zero_run` (`bytes[3]`). Spec §3.5.
    pub(crate) const ZERO_RUN: usize = 4;
}

/// Byte offsets for the `freeform_surface_core` record.
///
/// Spec §3.5. Record length 47 B.
///
/// ```text
/// `f[0:3]` is the trimmed face's AABB centre, `f[3:6]` its AABB half-extents, `f[6:9]` its bounding-sphere centre, and `f[9]` the bounding-sphere radius. The containment invariant `|f[i]−f[6+i]| + f[3+i] ≤ f[9]` holds.
/// ```
pub(crate) mod freeform_surface_core {
    /// Record length in bytes. Spec §3.5.
    pub(crate) const LEN: usize = 47;
    /// Offset of `zero_run` (`bytes[3]`). Spec §3.5.
    pub(crate) const ZERO_RUN: usize = 3;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §3.5.
    pub(crate) const BOUNDS: usize = 6;
    /// Offset of `sign` (`i8`). Spec §3.5.
    pub(crate) const SIGN: usize = 46;
}

/// Byte offsets for the `analytic_surface_plane` record.
///
/// Spec §5.8. Record length 49 B.
///
/// ```text
/// Record start is `marker_pos − 5`. Grammar: `tag:u24le <parameter_length:u16be> 00 33 <kind> <payload> <sign:i8>`. The payload holds BE f32 parameters; the spec states its slot order but no per-slot offsets.
/// ```
pub(crate) mod analytic_surface_plane {
    /// Record length in bytes. Spec §5.8.
    pub(crate) const LEN: usize = 49;
    /// Offset of `marker` (`bytes[2]`). Spec §5.8.
    pub(crate) const MARKER: usize = 5;
    /// Offset of `kind` (`u8`). Spec §5.8.
    pub(crate) const KIND: usize = 7;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §5.8.
    pub(crate) const BOUNDS: usize = 8;
    /// Offset of `sign` (`i8`). Spec §5.8.
    pub(crate) const SIGN: usize = 48;
}

/// Byte offsets for the `analytic_surface_cylinder` record.
///
/// Spec §5.8. Record length 73 B.
///
/// ```text
/// Cylinder and cone share the parameter-length word and record length; the kind byte distinguishes them. Payload slots are `[px py pz ax ay radius]` as BE f32.
/// ```
pub(crate) mod analytic_surface_cylinder {
    /// Record length in bytes. Spec §5.8.
    pub(crate) const LEN: usize = 73;
    /// Offset of `marker` (`bytes[2]`). Spec §5.8.
    pub(crate) const MARKER: usize = 5;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §5.8.
    pub(crate) const BOUNDS: usize = 32;
    /// Offset of `sign` (`i8`). Spec §5.8.
    pub(crate) const SIGN: usize = 72;
}

/// Byte offsets for the `analytic_surface_cone` record.
///
/// Spec §5.8. Record length 73 B.
pub(crate) mod analytic_surface_cone {
    /// Record length in bytes. Spec §5.8.
    pub(crate) const LEN: usize = 73;
    /// Offset of `marker` (`bytes[2]`). Spec §5.8.
    pub(crate) const MARKER: usize = 5;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §5.8.
    pub(crate) const BOUNDS: usize = 32;
    /// Offset of `sign` (`i8`). Spec §5.8.
    pub(crate) const SIGN: usize = 72;
}

/// Byte offsets for the `analytic_surface_sphere` record.
///
/// Spec §5.8. Record length 65 B.
pub(crate) mod analytic_surface_sphere {
    /// Record length in bytes. Spec §5.8.
    pub(crate) const LEN: usize = 65;
    /// Offset of `marker` (`bytes[2]`). Spec §5.8.
    pub(crate) const MARKER: usize = 5;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §5.8.
    pub(crate) const BOUNDS: usize = 24;
    /// Offset of `sign` (`i8`). Spec §5.8.
    pub(crate) const SIGN: usize = 64;
}

/// Byte offsets for the `analytic_surface_torus` record.
///
/// Spec §5.8. Record length 77 B.
pub(crate) mod analytic_surface_torus {
    /// Record length in bytes. Spec §5.8.
    pub(crate) const LEN: usize = 77;
    /// Offset of `marker` (`bytes[2]`). Spec §5.8.
    pub(crate) const MARKER: usize = 5;
    /// Offset of `bounds` (`f32[10]`, little-endian). Spec §5.8.
    pub(crate) const BOUNDS: usize = 36;
    /// Offset of `sign` (`i8`). Spec §5.8.
    pub(crate) const SIGN: usize = 76;
}

/// Byte offsets for the `a_family_frame` record.
///
/// Spec §6. Record length 7 B.
///
/// ```text
/// Header only; the width-`W` header token occupies +7..+7+W and the payload starts at +7+W. `next = +7+W+payload_len`. The canonical header token is retained independently of the class-specific payload; it does not supply a per-record object id.
/// ```
pub(crate) mod a_family_frame {
    /// Record length in bytes. Spec §6.
    pub(crate) const LEN: usize = 7;
    /// Offset of `flag` (`u8`). Spec §6.
    pub(crate) const FLAG: usize = 1;
    /// Offset of `class` (`u8`). Spec §6.
    pub(crate) const CLASS: usize = 2;
    /// Offset of `payload_len` (`u32`, little-endian). Spec §6.
    pub(crate) const PAYLOAD_LEN: usize = 3;
}

/// Byte offsets for the `b_family_frame` record.
///
/// Spec §6. Record length 4 B.
///
/// ```text
/// Header only; the width-`W` header token occupies +4..+4+W and the payload starts at +4+W. `next = +4+W+payload_len`.
/// ```
pub(crate) mod b_family_frame {
    /// Record length in bytes. Spec §6.
    pub(crate) const LEN: usize = 4;
    /// Offset of `payload_len` (`u8`). Spec §6.
    pub(crate) const PAYLOAD_LEN: usize = 3;
}

/// Byte offsets for the `a9_03_frame` record.
///
/// Spec §8. Record length 4 B.
///
/// ```text
/// Header only; the payload of `YY + 8` bytes follows at +4, so the record length is `YY + 12`. Records reference each other by one-based global record ordinal into the `a9 03` stream.
/// ```
pub(crate) mod a9_03_frame {
    /// Record length in bytes. Spec §8.
    pub(crate) const LEN: usize = 4;
    /// Offset of `family` (`bytes[2]`). Spec §8.
    pub(crate) const FAMILY: usize = 0;
    /// Offset of `tag_hi` (`u8`). Spec §8.
    pub(crate) const TAG_HI: usize = 2;
    /// Offset of `tag_lo_length_driver` (`u8`). Spec §8.
    pub(crate) const TAG_LO_LENGTH_DRIVER: usize = 3;
}

/// Byte offsets for the `zero_entity_edge_stride_5e1a` record.
///
/// Spec §8. Record length 38 B.
///
/// ```text
/// Each tagged allocation value is one tag byte plus a little-endian u32, so the five values run at stride 5.
/// ```
pub(crate) mod zero_entity_edge_stride_5e1a {
    /// Offset of `tagged_one_prefix` (`bytes[5]`). Spec §8.
    pub(crate) const TAGGED_ONE_PREFIX: usize = 7;
    /// Offset of `allocations` (`bytes[25]`). Spec §8.
    pub(crate) const ALLOCATIONS: usize = 12;
    /// Offset of `terminal` (`u8`). Spec §8.
    pub(crate) const TERMINAL: usize = 37;
}

/// Byte offsets for the `zero_entity_vertex_owner_5d06` record.
///
/// Spec §8. Record length 18 B.
pub(crate) mod zero_entity_vertex_owner_5d06 {
    /// Record length in bytes. Spec §8.
    pub(crate) const LEN: usize = 18;
    /// Offset of `tagged_one_a` (`bytes[5]`). Spec §8.
    pub(crate) const TAGGED_ONE_A: usize = 7;
    /// Offset of `tagged_one_b` (`bytes[5]`). Spec §8.
    pub(crate) const TAGGED_ONE_B: usize = 12;
    /// Offset of `terminal` (`u8`). Spec §8.
    pub(crate) const TERMINAL: usize = 17;
}

/// Byte offsets for the `zero_entity_pcurve_2171` record.
///
/// Spec §8. Record length 125 B.
///
/// ```text
/// One row of the §8 inline support-pcurve family table. Distinct f64 knots are followed by equally many tagged u32 multiplicities; `degree = first_multiplicity - 1` and `control_count = sum(multiplicities) - degree - 1`. The 125-byte total is the parser's required end for this tag; §8 states logical lengths only for `2145`, `2172`, and `219f`.
/// ```
pub(crate) mod zero_entity_pcurve_2171 {
    /// Record length in bytes. Spec §8.
    pub(crate) const LEN: usize = 125;
    /// Offset of `knots` (`f64[2]`, little-endian). Spec §8.
    pub(crate) const KNOTS: usize = 67;
    /// Offset of `multiplicities` (`bytes[10]`). Spec §8.
    pub(crate) const MULTIPLICITIES: usize = 83;
    /// Offset of `poles` (`f64[4]`, little-endian). Spec §8.
    pub(crate) const POLES: usize = 93;
}

/// Byte offsets for the `e5_record_frame` record.
///
/// Spec §9. Record length 13 B.
///
/// ```text
/// The 13-byte header precedes the counted payload; an initial payload reference-count byte is separate from the header.
/// ```
pub(crate) mod e5_record_frame {
    /// Record length in bytes. Spec §9.
    pub(crate) const LEN: usize = 13;
    /// Offset of `class` (`u8`). Spec §9.
    pub(crate) const CLASS: usize = 3;
    /// Offset of `record_id` (`u32`, little-endian). Spec §9.
    pub(crate) const RECORD_ID: usize = 9;
}

/// Byte offsets for the `value_block_7c0b` record.
///
/// Spec §7.4. Record length 6 B.
///
/// ```text
/// Header only. `declared_len` measures from the `7C0B` marker through the byte before the terminator, so the complete block occupies `declared_len + 1` bytes: payload of `declared_len - 6` bytes at +6, the `FE` terminator at `+declared_len`, then the associated `7C02` catalog.
/// ```
pub(crate) mod value_block_7c0b {
    /// Record length in bytes. Spec §7.4.
    pub(crate) const LEN: usize = 6;
    /// Offset of `declared_len` (`u32`, little-endian). Spec §7.4.
    pub(crate) const DECLARED_LEN: usize = 2;
}

/// Byte offsets for the `outer_alias_row` record.
///
/// Spec §7.5. Record length 24 B.
///
/// ```text
/// Offsets are row-relative; the `01 00 04 00` marker sits at row offset 4. The lead is a u32 whose low byte is `0x01`, exact `0x8e`, or exact `0x8f`. The low 24 bits of `tag` are the persistent roster tag and the high byte remains part of the stored word.
/// ```
pub(crate) mod outer_alias_row {
    /// Record length in bytes. Spec §7.5.
    pub(crate) const LEN: usize = 24;
    /// Offset of `lead` (`u32`, little-endian). Spec §7.5.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `marker` (`bytes[4]`). Spec §7.5.
    pub(crate) const MARKER: usize = 4;
    /// Offset of `tag` (`u32`, little-endian). Spec §7.5.
    pub(crate) const TAG: usize = 8;
    /// Offset of `flag` (`u8`). Spec §7.5.
    pub(crate) const FLAG: usize = 12;
    /// Offset of `f1` (`bytes[3]`). Spec §7.5.
    pub(crate) const F1: usize = 13;
    /// Offset of `f2` (`u32`, little-endian). Spec §7.5.
    pub(crate) const F2: usize = 16;
    /// Offset of `f3` (`u32`, little-endian). Spec §7.5.
    pub(crate) const F3: usize = 20;
}

/// Byte offsets for the `fbb_face_row` record.
///
/// Spec §7.4. Record length 8 B.
///
/// ```text
/// The leading byte of a colour-bearing FBB marker can set bit 7 without changing its face-row role. §5.2 gives the row's marker form as `(30|b0) 04 04 ff` at stride 8.
/// ```
pub(crate) mod fbb_face_row {
    /// Record length in bytes. Spec §7.4.
    pub(crate) const LEN: usize = 8;
    /// Offset of `alpha` (`u8`). Spec §7.4.
    pub(crate) const ALPHA: usize = 4;
    /// Offset of `blue` (`u8`). Spec §7.4.
    pub(crate) const BLUE: usize = 5;
    /// Offset of `green` (`u8`). Spec §7.4.
    pub(crate) const GREEN: usize = 6;
    /// Offset of `red` (`u8`). Spec §7.4.
    pub(crate) const RED: usize = 7;
}

/// Byte offsets for the `storage_member_core` record.
///
/// Spec §7.6. Record length 20 B.
pub(crate) mod storage_member_core {
    /// Record length in bytes. Spec §7.6.
    pub(crate) const LEN: usize = 20;
    /// Offset of `tag` (`u32`, little-endian). Spec §7.6.
    pub(crate) const TAG: usize = 4;
    /// Offset of `flag` (`u8`). Spec §7.6.
    pub(crate) const FLAG: usize = 8;
    /// Offset of `prefix` (`bytes[2]`). Spec §7.6.
    pub(crate) const PREFIX: usize = 9;
    /// Offset of `slot` (`u32`, little-endian). Spec §7.6.
    pub(crate) const SLOT: usize = 11;
    /// Offset of `tail` (`bytes[5]`). Spec §7.6.
    pub(crate) const TAIL: usize = 15;
}

/// Byte offsets for the `storage_member_direct_prefix` record.
///
/// Spec §7.6. Record length 4 B.
pub(crate) mod storage_member_direct_prefix {
    /// Record length in bytes. Spec §7.6.
    pub(crate) const LEN: usize = 4;
    /// Offset of `lead` (`u32`, little-endian). Spec §7.6.
    pub(crate) const LEAD: usize = 0;
}

/// Byte offsets for the `storage_member_nullable_prefix` record.
///
/// Spec §7.6. Record length 8 B.
pub(crate) mod storage_member_nullable_prefix {
    /// Record length in bytes. Spec §7.6.
    pub(crate) const LEN: usize = 8;
    /// Offset of `state` (`u32`, little-endian). Spec §7.6.
    pub(crate) const STATE: usize = 0;
    /// Offset of `discriminator` (`u32`, little-endian). Spec §7.6.
    pub(crate) const DISCRIMINATOR: usize = 4;
}

/// Byte offsets for the `storage_member_number_prefix` record.
///
/// Spec §7.6. Record length 6 B.
pub(crate) mod storage_member_number_prefix {
    /// Record length in bytes. Spec §7.6.
    pub(crate) const LEN: usize = 6;
    /// Offset of `inclusive_length` (`u16`, little-endian). Spec §7.6.
    pub(crate) const INCLUSIVE_LENGTH: usize = 0;
    /// Offset of `digit_count` (`u32`, little-endian). Spec §7.6.
    pub(crate) const DIGIT_COUNT: usize = 2;
}

/// Byte offsets for the `inline_schema_words` record.
///
/// Spec §7.3. Record length 12 B.
pub(crate) mod inline_schema_words {
    /// Record length in bytes. Spec §7.3.
    pub(crate) const LEN: usize = 12;
    /// Offset of `open_count` (`u8`). Spec §7.3.
    pub(crate) const OPEN_COUNT: usize = 0;
    /// Offset of `outer_marker` (`u8`). Spec §7.3.
    pub(crate) const OUTER_MARKER: usize = 1;
    /// Offset of `outer_selector` (`u32`, little-endian). Spec §7.3.
    pub(crate) const OUTER_SELECTOR: usize = 2;
    /// Offset of `field_marker` (`u8`). Spec §7.3.
    pub(crate) const FIELD_MARKER: usize = 6;
    /// Offset of `field_selector` (`u32`, little-endian). Spec §7.3.
    pub(crate) const FIELD_SELECTOR: usize = 7;
    /// Offset of `close_count` (`u8`). Spec §7.3.
    pub(crate) const CLOSE_COUNT: usize = 11;
}

/// Byte offsets for the `e5_nurbs_pcurve_limits` record.
///
/// Spec §9. Record length 37 B.
pub(crate) mod e5_nurbs_pcurve_limits {
    /// Record length in bytes. Spec §9.
    pub(crate) const LEN: usize = 37;
}

/// Byte offsets for the `e5_nurbs_surface_limits` record.
///
/// Spec §9. Record length 148 B.
pub(crate) mod e5_nurbs_surface_limits {
    /// Record length in bytes. Spec §9.
    pub(crate) const LEN: usize = 148;
}

/// Byte offsets for the `b5_loop_numeric_terminal` record.
///
/// Spec §6.7. Record length 62 B.
///
/// ```text
/// Terminal-relative offsets; all six compact controls use the canonical one-byte form.
/// ```
pub(crate) mod b5_loop_numeric_terminal {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 62;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `scalars` (`f64[4]`, little-endian). Spec §6.7.
    pub(crate) const SCALARS: usize = 1;
    /// Offset of `trailing_controls` (`u8[5]`). Spec §6.7.
    pub(crate) const TRAILING_CONTROLS: usize = 33;
    /// Offset of `bounds` (`f32[6]`, little-endian). Spec §6.7.
    pub(crate) const BOUNDS: usize = 38;
}

/// Byte offsets for the `surface_terminal_span_tail` record.
///
/// Spec §6.6. Record length 141 B.
///
/// ```text
/// Tail-relative offsets. The generic 133-byte and 142-byte surface tails share the prefix through offset 71.
/// ```
pub(crate) mod surface_terminal_span_tail {
    /// Record length in bytes. Spec §6.6.
    pub(crate) const LEN: usize = 141;
    /// Offset of `controls` (`bytes[4]`). Spec §6.6.
    pub(crate) const CONTROLS: usize = 0;
    /// Offset of `parameters` (`bytes[64]`). Spec §6.6.
    pub(crate) const PARAMETERS: usize = 4;
    /// Offset of `flags` (`bytes[3]`). Spec §6.6.
    pub(crate) const FLAGS: usize = 68;
    /// Offset of `continuation` (`bytes[64]`). Spec §6.6.
    pub(crate) const CONTINUATION: usize = 71;
    /// Offset of `suffix` (`bytes[6]`). Spec §6.6.
    pub(crate) const SUFFIX: usize = 135;
}

/// Byte offsets for the `b5_cone_payload` record.
///
/// Spec §6.7. Record length 185 B.
pub(crate) mod b5_cone_payload {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 185;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `origin` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const ORIGIN: usize = 1;
    /// Offset of `direction_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_X: usize = 25;
    /// Offset of `direction_y` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_Y: usize = 49;
    /// Offset of `axis` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const AXIS: usize = 73;
    /// Offset of `radial_angle` (`f64`, little-endian). Spec §6.7.
    pub(crate) const RADIAL_ANGLE: usize = 97;
    /// Offset of `reference_radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const REFERENCE_RADIUS: usize = 105;
    /// Offset of `angular_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_RANGE: usize = 113;
    /// Offset of `slant_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const SLANT_RANGE: usize = 129;
    /// Offset of `angular_scale` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_SCALE: usize = 145;
    /// Offset of `parameter_scale` (`f64`, little-endian). Spec §6.7.
    pub(crate) const PARAMETER_SCALE: usize = 153;
    /// Offset of `parameter_shift` (`f64`, little-endian). Spec §6.7.
    pub(crate) const PARAMETER_SHIFT: usize = 161;
    /// Offset of `angular_domain` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_DOMAIN: usize = 169;
}

/// Byte offsets for the `rolling_ball_tail_prefix` record.
///
/// Spec §6.2. Record length 57 B.
pub(crate) mod rolling_ball_tail_prefix {
    /// Record length in bytes. Spec §6.2.
    pub(crate) const LEN: usize = 57;
    /// Offset of `parameters` (`f64[5]`, little-endian). Spec §6.2.
    pub(crate) const PARAMETERS: usize = 0;
    /// Offset of `control` (`u8`). Spec §6.2.
    pub(crate) const CONTROL: usize = 40;
    /// Offset of `maximal_v` (`f64[2]`, little-endian). Spec §6.2.
    pub(crate) const MAXIMAL_V: usize = 41;
}

/// Byte offsets for the `rolling_ball_tail_unmapped_suffix` record.
///
/// Spec §6.2. Record length 22 B.
pub(crate) mod rolling_ball_tail_unmapped_suffix {
    /// Record length in bytes. Spec §6.2.
    pub(crate) const LEN: usize = 22;
    /// Offset of `branch` (`bytes[6]`). Spec §6.2.
    pub(crate) const BRANCH: usize = 0;
    /// Stated value of `branch` (`bytes[6]`). Spec §6.2.
    pub(crate) const BRANCH_VALUE: [u8; 6] = [0x05, 0x00, 0x00, 0x00, 0x00, 0x00];
    /// Offset of `maximal_u` (`f64[2]`, little-endian). Spec §6.2.
    pub(crate) const MAXIMAL_U: usize = 6;
}

/// Byte offsets for the `consolidated_wide_face_roster_prefix` record.
///
/// Spec §6.4. Record length 3 B.
pub(crate) mod consolidated_wide_face_roster_prefix {
    /// Record length in bytes. Spec §6.4.
    pub(crate) const LEN: usize = 3;
    /// Offset of `marker` (`u8`). Spec §6.4.
    pub(crate) const MARKER: usize = 0;
    /// Offset of `face_count` (`u16`, little-endian). Spec §6.4.
    pub(crate) const FACE_COUNT: usize = 1;
}

/// Byte offsets for the `b5_plane_payload` record.
///
/// Spec §6.7. Record length 121 B.
pub(crate) mod b5_plane_payload {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 121;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `origin` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const ORIGIN: usize = 1;
    /// Offset of `direction_u` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_U: usize = 25;
    /// Offset of `direction_v` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_V: usize = 49;
    /// Offset of `fixed_values` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const FIXED_VALUES: usize = 73;
    /// Offset of `u_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const U_RANGE: usize = 89;
    /// Offset of `v_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const V_RANGE: usize = 105;
}

/// Byte offsets for the `b5_cylinder_payload` record.
///
/// Spec §6.7. Record length 137 B.
pub(crate) mod b5_cylinder_payload {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 137;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `origin` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const ORIGIN: usize = 1;
    /// Offset of `reference_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const REFERENCE_X: usize = 25;
    /// Offset of `stored_v` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const STORED_V: usize = 49;
    /// Offset of `radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const RADIUS: usize = 73;
    /// Offset of `u_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const U_RANGE: usize = 81;
    /// Offset of `v_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const V_RANGE: usize = 97;
    /// Offset of `angular_factor` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_FACTOR: usize = 113;
    /// Offset of `one` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ONE: usize = 121;
    /// Offset of `chart_origin` (`f64`, little-endian). Spec §6.7.
    pub(crate) const CHART_ORIGIN: usize = 129;
}

/// Byte offsets for the `b5_sphere_payload` record.
///
/// Spec §6.7. Record length 153 B.
pub(crate) mod b5_sphere_payload {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 153;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `center` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const CENTER: usize = 1;
    /// Offset of `scaled_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const SCALED_X: usize = 25;
    /// Offset of `scaled_y` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const SCALED_Y: usize = 49;
    /// Offset of `scaled_axis` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const SCALED_AXIS: usize = 73;
    /// Offset of `radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const RADIUS: usize = 97;
    /// Offset of `azimuth_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const AZIMUTH_RANGE: usize = 105;
    /// Offset of `latitude_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const LATITUDE_RANGE: usize = 121;
    /// Offset of `construction_radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const CONSTRUCTION_RADIUS: usize = 137;
    /// Offset of `chart_origin` (`f64`, little-endian). Spec §6.7.
    pub(crate) const CHART_ORIGIN: usize = 145;
}

/// Byte offsets for the `b5_torus_payload` record.
///
/// Spec §6.7. Record length 201 B.
pub(crate) mod b5_torus_payload {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 201;
    /// Offset of `lead` (`u8`). Spec §6.7.
    pub(crate) const LEAD: usize = 0;
    /// Offset of `center` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const CENTER: usize = 1;
    /// Offset of `direction_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_X: usize = 25;
    /// Offset of `direction_y` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_Y: usize = 49;
    /// Offset of `axis` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const AXIS: usize = 73;
    /// Offset of `major_radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const MAJOR_RADIUS: usize = 97;
    /// Offset of `minor_radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const MINOR_RADIUS: usize = 105;
    /// Offset of `major_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const MAJOR_RANGE: usize = 113;
    /// Offset of `major_domain` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const MAJOR_DOMAIN: usize = 129;
    /// Offset of `minor_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const MINOR_RANGE: usize = 145;
    /// Offset of `minor_domain` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const MINOR_DOMAIN: usize = 161;
    /// Offset of `major_scale` (`f64`, little-endian). Spec §6.7.
    pub(crate) const MAJOR_SCALE: usize = 177;
    /// Offset of `minor_scale` (`f64`, little-endian). Spec §6.7.
    pub(crate) const MINOR_SCALE: usize = 185;
    /// Offset of `reserved` (`bytes[8]`). Spec §6.7.
    pub(crate) const RESERVED: usize = 193;
}

/// Byte offsets for the `indexed_visualization_point_header` record.
///
/// Spec §5.4.2. Record length 19 B.
pub(crate) mod indexed_visualization_point_header {
    /// Record length in bytes. Spec §5.4.2.
    pub(crate) const LEN: usize = 19;
    /// Offset of `entry_count` (`u32`, little-endian). Spec §5.4.2.
    pub(crate) const ENTRY_COUNT: usize = 6;
    /// Offset of `secondary_sentinel` (`u8`). Spec §5.4.2.
    pub(crate) const SECONDARY_SENTINEL: usize = 10;
    /// Offset of `secondary_count` (`u32`, little-endian). Spec §5.4.2.
    pub(crate) const SECONDARY_COUNT: usize = 11;
    /// Offset of `reserved` (`bytes[3]`). Spec §5.4.2.
    pub(crate) const RESERVED: usize = 15;
    /// Offset of `mode` (`u8`). Spec §5.4.2.
    pub(crate) const MODE: usize = 18;
}

/// Byte offsets for the `indexed_visualization_point_row` record.
///
/// Spec §5.4.2. Record length 12 B.
pub(crate) mod indexed_visualization_point_row {
    /// Record length in bytes. Spec §5.4.2.
    pub(crate) const LEN: usize = 12;
    /// Offset of `y` (`f32`, little-endian). Spec §5.4.2.
    pub(crate) const Y: usize = 4;
    /// Offset of `z` (`f32`, little-endian). Spec §5.4.2.
    pub(crate) const Z: usize = 8;
}

/// Byte offsets for the `indexed_visualization_scalar_prefix` record.
///
/// Spec §5.4.2. Record length 5 B.
pub(crate) mod indexed_visualization_scalar_prefix {
    /// Record length in bytes. Spec §5.4.2.
    pub(crate) const LEN: usize = 5;
    /// Offset of `scalar_count` (`u32`, little-endian). Spec §5.4.2.
    pub(crate) const SCALAR_COUNT: usize = 1;
}

/// Byte offsets for the `b_four_reference_edge_payload` record.
///
/// Spec §6.3. Record length 5 B.
///
/// ```text
/// Payload only; the surrounding B-family frame carries the independent width, flag and header token.
/// ```
pub(crate) mod b_four_reference_edge_payload {
    /// Record length in bytes. Spec §6.3.
    pub(crate) const LEN: usize = 5;
    /// Offset of `operands` (`u8[4]`). Spec §6.3.
    pub(crate) const OPERANDS: usize = 0;
    /// Offset of `terminal` (`u8`). Spec §6.3.
    pub(crate) const TERMINAL: usize = 4;
}

/// Byte offsets for the `rolling_ball_tail_scalar_branch` record.
///
/// Spec §6.2. Record length 2 B.
pub(crate) mod rolling_ball_tail_scalar_branch {
    /// Stated value of `branch` (`bytes[2]`). Spec §6.2.
    pub(crate) const BRANCH_VALUE: [u8; 2] = [0x01, 0x01];
}

/// Byte offsets for the `e5_rolling_ball_tail` record.
///
/// Spec §9. Record length 63 B.
pub(crate) mod e5_rolling_ball_tail {
    /// Record length in bytes. Spec §9.
    pub(crate) const LEN: usize = 63;
    /// Stated value of `terminal` (`bytes[3]`). Spec §9.
    pub(crate) const TERMINAL_VALUE: [u8; 3] = [0x01, 0x00, 0x00];
}

/// Byte offsets for the `b5_line_profile` record.
///
/// Spec §6.7. Record length 73 B.
pub(crate) mod b5_line_profile {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 73;
    /// Offset of `point` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const POINT: usize = 1;
    /// Offset of `direction` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION: usize = 25;
    /// Offset of `one` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ONE: usize = 49;
    /// Offset of `parameter_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const PARAMETER_RANGE: usize = 57;
}

/// Byte offsets for the `b5_arc_profile` record.
///
/// Spec §6.7. Record length 113 B.
pub(crate) mod b5_arc_profile {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 113;
    /// Offset of `center` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const CENTER: usize = 1;
    /// Offset of `direction_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_X: usize = 25;
    /// Offset of `direction_y` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const DIRECTION_Y: usize = 49;
    /// Offset of `radius` (`f64`, little-endian). Spec §6.7.
    pub(crate) const RADIUS: usize = 73;
    /// Offset of `parameter_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const PARAMETER_RANGE: usize = 81;
    /// Offset of `one` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ONE: usize = 97;
    /// Offset of `chart_origin` (`f64`, little-endian). Spec §6.7.
    pub(crate) const CHART_ORIGIN: usize = 105;
}

/// Byte offsets for the `b5_revolution_carrier_tail` record.
///
/// Spec §6.7. Record length 171 B.
pub(crate) mod b5_revolution_carrier_tail {
    /// Record length in bytes. Spec §6.7.
    pub(crate) const LEN: usize = 171;
    /// Offset of `reference_x` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const REFERENCE_X: usize = 24;
    /// Offset of `reference_y` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const REFERENCE_Y: usize = 48;
    /// Offset of `axis` (`f64[3]`, little-endian). Spec §6.7.
    pub(crate) const AXIS: usize = 72;
    /// Offset of `angular_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_RANGE: usize = 96;
    /// Offset of `profile_range` (`f64[2]`, little-endian). Spec §6.7.
    pub(crate) const PROFILE_RANGE: usize = 112;
    /// Offset of `controls` (`bytes[2]`). Spec §6.7.
    pub(crate) const CONTROLS: usize = 128;
    /// Offset of `angular_scale` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ANGULAR_SCALE: usize = 130;
    /// Offset of `one0` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ONE0: usize = 138;
    /// Offset of `one1` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ONE1: usize = 146;
    /// Offset of `zero` (`f64`, little-endian). Spec §6.7.
    pub(crate) const ZERO: usize = 154;
    /// Offset of `terminal` (`u8`). Spec §6.7.
    pub(crate) const TERMINAL: usize = 162;
    /// Offset of `half_turn` (`f64`, little-endian). Spec §6.7.
    pub(crate) const HALF_TURN: usize = 163;
}

/// Byte offsets for the `container_property_header` record.
///
/// Spec §3.1. Record length 12 B.
pub(crate) mod container_property_header {
    /// Record length in bytes. Spec §3.1.
    pub(crate) const LEN: usize = 12;
    /// Offset of `total_size` (`u32`, big-endian). Spec §3.1.
    pub(crate) const TOTAL_SIZE: usize = 0;
    /// Offset of `count` (`u32`, big-endian). Spec §3.1.
    pub(crate) const COUNT: usize = 8;
}

/// Byte offsets for the `container_property_record` record.
///
/// Spec §3.1. Record length 14 B.
pub(crate) mod container_property_record {
    /// Record length in bytes. Spec §3.1.
    pub(crate) const LEN: usize = 14;
    /// Offset of `size` (`u32`, big-endian). Spec §3.1.
    pub(crate) const SIZE: usize = 0;
    /// Offset of `value_type` (`u16`, big-endian). Spec §3.1.
    pub(crate) const VALUE_TYPE: usize = 8;
    /// Offset of `value_bytes` (`u32`, big-endian). Spec §3.1.
    pub(crate) const VALUE_BYTES: usize = 10;
}
