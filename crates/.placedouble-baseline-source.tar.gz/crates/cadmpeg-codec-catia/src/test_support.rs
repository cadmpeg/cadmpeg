// SPDX-License-Identifier: Apache-2.0
//! Shared synthetic CATPart byte-fixture builders for `#[cfg(test)]` suites.
//!
//! Helpers hand-build `.CATPart` byte images and embedded-stream payloads.
//! They construct raw bytes only; decode, native, and family tests own the
//! assertions.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

pub(crate) mod test_a5_bound;
pub(crate) mod test_a5a8;
pub(crate) mod test_annotations;
pub(crate) mod test_b2;
pub(crate) mod test_b5;
pub(crate) mod test_bytes;
pub(crate) mod test_class25;
pub(crate) mod test_container;
pub(crate) mod test_e5;
pub(crate) mod test_formula;
pub(crate) mod test_object_graph;
pub(crate) mod test_parameter_map;
pub(crate) mod test_rolling_ball_continuation;
pub(crate) mod test_sketch_bindings;
pub(crate) mod test_topology;
pub(crate) mod test_zero_entity;

pub(crate) fn with_service_context<T>(
    run: impl FnOnce(&cadmpeg_core::decode::DecodeContext<'_>) -> T,
) -> T {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    run(&ctx)
}

/// A fresh standard topology search budget, as the standard route creates one
/// per population.
pub(crate) fn topology_budget() -> cadmpeg_core::decode::WorkBudget {
    cadmpeg_core::decode::WorkBudget::new(crate::solve::mesh_quotient::MAX_MESH_TOPOLOGY_OPERATIONS)
}

thread_local! {
    static STANDARD_TOPOLOGY_LIMIT: std::cell::Cell<Option<usize>> =
        const { std::cell::Cell::new(None) };
}

/// The work limit of each standard population's topology search: the
/// production limit, or the one set by [`with_standard_topology_limit`].
pub(crate) fn standard_topology_limit() -> usize {
    STANDARD_TOPOLOGY_LIMIT
        .get()
        .unwrap_or(crate::solve::mesh_quotient::MAX_MESH_TOPOLOGY_OPERATIONS)
}

/// Runs `run` with every standard topology search on this thread limited to
/// `limit` work units.
pub(crate) fn with_standard_topology_limit<T>(limit: usize, run: impl FnOnce() -> T) -> T {
    let outer = STANDARD_TOPOLOGY_LIMIT.replace(Some(limit));
    let result = run();
    STANDARD_TOPOLOGY_LIMIT.set(outer);
    result
}

pub(crate) fn with_entity_limit<T>(
    max_entities: u64,
    run: impl FnOnce(&cadmpeg_core::decode::DecodeContext<'_>) -> T,
) -> T {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let mut policy = cadmpeg_core::decode::DecodePolicy::service();
    policy.limits.max_entities = max_entities;
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
        .expect("build the decode context");
    run(&ctx)
}

pub(crate) fn with_retained_limit<T>(
    max_retained_bytes: u64,
    run: impl FnOnce(&cadmpeg_core::decode::DecodeContext<'_>) -> T,
) -> T {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let mut policy = cadmpeg_core::decode::DecodePolicy::service();
    policy.limits.max_retained_bytes = max_retained_bytes;
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
        .expect("empty test root fits the retained limit");
    run(&ctx)
}

pub(crate) fn with_depth_limit<T>(
    max_recursion_depth: u64,
    run: impl FnOnce(&cadmpeg_core::decode::DecodeContext<'_>) -> T,
) -> T {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let mut policy = cadmpeg_core::decode::DecodePolicy::service();
    policy.limits.max_recursion_depth = max_recursion_depth;
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
        .expect("empty root fits the depth limit");
    run(&ctx)
}
