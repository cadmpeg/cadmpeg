// SPDX-License-Identifier: Apache-2.0
//! Geometry-backed boundary-role derivation shared by closed topology routes.

use cadmpeg_core::CodecError;
use cadmpeg_ir::geometry::{SolvedSurfaceGeometry, SurfaceGeometry};
use cadmpeg_ir::ids::LoopId;
use cadmpeg_ir::math::{Point2, Point3};
use cadmpeg_ir::topology::FaceLoops;

const EPS_PLANAR_COORDINATE: f64 = 1.0e-10;

/// Boundary points one planar face may state before its loops are left
/// unclassified. Segment intersection and containment are quadratic in them.
pub(crate) const MAX_PLANAR_BOUNDARY_POINTS: usize = 4096;

pub(crate) fn strictly_inside_planar_polygon(
    point: Point2,
    polygon: &[Point2],
    tolerance: f64,
) -> bool {
    let mut inside = false;
    for (left, right) in polygon
        .iter()
        .zip(polygon.iter().cycle().skip(1))
        .take(polygon.len())
    {
        let edge_u = right.u - left.u;
        let edge_v = right.v - left.v;
        let point_u = point.u - left.u;
        let point_v = point.v - left.v;
        let edge_length = edge_u.hypot(edge_v);
        let cross = edge_u * point_v - edge_v * point_u;
        let dot = point_u * (point.u - right.u) + point_v * (point.v - right.v);
        if edge_length > 0.0
            && cross.abs() <= tolerance * edge_length
            && dot <= tolerance * tolerance
        {
            return false;
        }
        if (left.v > point.v) != (right.v > point.v) {
            let intersection = left.u + (point.v - left.v) * edge_u / (right.v - left.v);
            if intersection > point.u {
                inside = !inside;
            }
        }
    }
    inside
}

fn point_on_segment(point: Point2, left: Point2, right: Point2, tolerance: f64) -> bool {
    let edge_u = right.u - left.u;
    let edge_v = right.v - left.v;
    let point_u = point.u - left.u;
    let point_v = point.v - left.v;
    let edge_length = edge_u.hypot(edge_v);
    edge_length > 0.0
        && (edge_u * point_v - edge_v * point_u).abs() <= tolerance * edge_length
        && point_u * (point.u - right.u) + point_v * (point.v - right.v) <= tolerance * tolerance
}

pub(crate) fn segments_intersect_or_touch(
    left_start: Point2,
    left_end: Point2,
    right_start: Point2,
    right_end: Point2,
    tolerance: f64,
) -> bool {
    let min_u = left_start
        .u
        .min(left_end.u)
        .max(right_start.u.min(right_end.u) - tolerance);
    let max_u = left_start
        .u
        .max(left_end.u)
        .min(right_start.u.max(right_end.u) + tolerance);
    let min_v = left_start
        .v
        .min(left_end.v)
        .max(right_start.v.min(right_end.v) - tolerance);
    let max_v = left_start
        .v
        .max(left_end.v)
        .min(right_start.v.max(right_end.v) + tolerance);
    if min_u > max_u || min_v > max_v {
        return false;
    }
    if [
        (right_start, left_start, left_end),
        (right_end, left_start, left_end),
        (left_start, right_start, right_end),
        (left_end, right_start, right_end),
    ]
    .into_iter()
    .any(|(point, start, end)| point_on_segment(point, start, end, tolerance))
    {
        return true;
    }
    let orientation = |first: Point2, second: Point2, third: Point2| {
        (second.u - first.u) * (third.v - first.v) - (second.v - first.v) * (third.u - first.u)
    };
    let left_left = orientation(left_start, left_end, right_start);
    let left_right = orientation(left_start, left_end, right_end);
    let right_left = orientation(right_start, right_end, left_start);
    let right_right = orientation(right_start, right_end, left_end);
    ((left_left > tolerance && left_right < -tolerance)
        || (left_left < -tolerance && left_right > tolerance))
        && ((right_left > tolerance && right_right < -tolerance)
            || (right_left < -tolerance && right_right > tolerance))
}

fn polygon_boundaries_intersect(
    left: &[Point2],
    right: &[Point2],
    tolerance: f64,
    same_polygon: bool,
) -> bool {
    for (left_index, (&left_start, &left_end)) in left
        .iter()
        .zip(left.iter().cycle().skip(1))
        .take(left.len())
        .enumerate()
    {
        for (right_index, (&right_start, &right_end)) in right
            .iter()
            .zip(right.iter().cycle().skip(1))
            .take(right.len())
            .enumerate()
        {
            if same_polygon
                && (left_index == right_index
                    || (left_index + 1) % left.len() == right_index
                    || (right_index + 1) % right.len() == left_index)
            {
                continue;
            }
            if segments_intersect_or_touch(left_start, left_end, right_start, right_end, tolerance)
            {
                return true;
            }
        }
    }
    false
}

/// Classify complete planar boundary polygons by strict containment.
///
/// Each row pairs a loop id with the closed polygon of that boundary, so the
/// classification and the loop list are one value and cannot disagree in
/// length or order. A single boundary is the outer boundary by the face
/// invariant. Multiple boundaries are classified only when one unique largest
/// non-degenerate polygon strictly contains every other polygon. This
/// deliberately declines disjoint, touching, nested-hole, malformed, and
/// non-planar arrangements. A face past [`MAX_PLANAR_BOUNDARY_POINTS`] is
/// declined with a loss in `refusal`.
pub(crate) fn classify_planar_boundaries(
    surface: &SurfaceGeometry,
    rows: &[(LoopId, Vec<Point3>)],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<FaceLoops, CodecError> {
    let unspecified = || -> Result<FaceLoops, CodecError> {
        let mut ids = Vec::new();
        for (id, _) in rows {
            let id = id.clone();
            ids.push(id);
        }
        Ok(FaceLoops::unspecified(ids))
    };
    if let [(single, _)] = rows {
        let id = single.clone();
        return Ok(FaceLoops::classified(id, Vec::new()));
    }
    let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)) = surface else {
        return unspecified();
    };

    let origin = plane_surface.origin().get();
    let u_axis = *plane_surface.frame().reference().as_raw();
    let v_axis = *plane_surface.frame().binormal().as_raw();
    let normal = *plane_surface.frame().axis().as_raw();
    let mut polygons = Vec::new();
    for (_, boundary) in rows {
        if boundary.len() < 3 {
            return unspecified();
        }
        let mut polygon = Vec::new();

        for point in boundary {
            let offset = point.vector_from(origin);
            let u = offset.dot(u_axis);
            let v = offset.dot(v_axis);
            let distance = offset.dot(normal);
            let scale = 1.0_f64.max(u.abs()).max(v.abs());
            if !u.is_finite()
                || !v.is_finite()
                || !distance.is_finite()
                || distance.abs() > EPS_PLANAR_COORDINATE * scale
            {
                return unspecified();
            }
            polygon.push(Point2::new(u, v));
        }
        polygons.push(polygon);
    }
    let coordinate_scale = polygons
        .iter()
        .flat_map(|polygon| polygon.iter())
        .flat_map(|point| [point.u.abs(), point.v.abs()])
        .fold(1.0, f64::max);
    let coordinate_tolerance = EPS_PLANAR_COORDINATE * coordinate_scale;
    let area_tolerance = coordinate_tolerance * coordinate_scale;
    let mut areas = Vec::new();
    for polygon in &polygons {
        let area = polygon
            .iter()
            .zip(polygon.iter().cycle().skip(1))
            .map(|(left, right)| left.u * right.v - right.u * left.v)
            .sum::<f64>()
            * 0.5;
        areas.push(area);
    }
    if areas
        .iter()
        .any(|area| !area.is_finite() || area.abs() <= area_tolerance)
    {
        return unspecified();
    }
    let points = polygons.iter().map(Vec::len).sum::<usize>();
    if points > MAX_PLANAR_BOUNDARY_POINTS {
        if let Some((first_loop, _)) = rows.first() {
            refusal.push_planar_boundary_bounded(first_loop.as_str(), points);
        }
        return unspecified();
    }
    if polygons.iter().enumerate().any(|(index, polygon)| {
        polygon_boundaries_intersect(polygon, polygon, coordinate_tolerance, true)
            || polygons.iter().skip(index + 1).any(|other| {
                polygon_boundaries_intersect(polygon, other, coordinate_tolerance, false)
            })
    }) {
        return unspecified();
    }
    let Some((outer, outer_area)) = areas
        .iter()
        .enumerate()
        .max_by(|(_, left), (_, right)| left.abs().total_cmp(&right.abs()))
    else {
        return unspecified();
    };
    let outer_area = outer_area.abs();
    if areas
        .iter()
        .enumerate()
        .any(|(index, area)| index != outer && outer_area - area.abs() <= area_tolerance)
    {
        return unspecified();
    }

    if polygons.iter().enumerate().any(|(index, polygon)| {
        index != outer
            && polygon.iter().any(|point| {
                !strictly_inside_planar_polygon(*point, &polygons[outer], coordinate_tolerance)
            })
    }) {
        return unspecified();
    }
    if polygons.iter().enumerate().any(|(index, polygon)| {
        index != outer
            && polygons.iter().enumerate().any(|(other_index, other)| {
                other_index != outer
                    && other_index != index
                    && polygon.iter().any(|point| {
                        strictly_inside_planar_polygon(*point, other, coordinate_tolerance)
                    })
            })
    }) {
        return unspecified();
    }
    let Some((outer_id, _)) = rows.get(outer) else {
        return unspecified();
    };
    let mut inner = Vec::new();
    for (index, (id, _)) in rows.iter().enumerate() {
        if index != outer {
            let id = id.clone();
            inner.push(id);
        }
    }
    let outer_id = outer_id.clone();
    Ok(FaceLoops::classified(outer_id, inner))
}

#[cfg(test)]
mod tests {
    use cadmpeg_ir::geometry::{SolvedSurfaceGeometry, SurfaceGeometry};
    use cadmpeg_ir::ids::LoopId;
    use cadmpeg_ir::math::{Point3, Vector3};
    use cadmpeg_ir::topology::FaceLoops;

    fn classify_planar_boundaries(
        surface: &SurfaceGeometry,
        rows: &[(cadmpeg_ir::ids::LoopId, Vec<Point3>)],
    ) -> FaceLoops {
        super::classify_planar_boundaries(surface, rows, &mut crate::nurbs::LaneRefusals::new())
            .expect("classify planar boundaries")
    }

    fn plane() -> SurfaceGeometry {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        ))
    }

    fn loop_id(index: usize) -> LoopId {
        LoopId::mint(format!("catia:test:loop#{index}")).expect("identity grammar")
    }

    fn square(min_u: f64, min_v: f64, max_u: f64, max_v: f64) -> Vec<Point3> {
        [
            [min_u, min_v, 0.0],
            [max_u, min_v, 0.0],
            [max_u, max_v, 0.0],
            [min_u, max_v, 0.0],
        ]
        .into_iter()
        .map(|[u, v, w]| Point3::new(u, v, w))
        .collect()
    }

    fn rows(boundaries: Vec<Vec<Point3>>) -> Vec<(LoopId, Vec<Point3>)> {
        boundaries
            .into_iter()
            .enumerate()
            .map(|(index, boundary)| (loop_id(index), boundary))
            .collect()
    }

    #[test]
    fn planar_boundaries_decline_an_off_plane_hole() {
        let outer = square(0.0, 0.0, 10.0, 10.0);
        let mut inner = square(2.0, 2.0, 3.0, 3.0);
        for point in &mut inner {
            point.z = 10.0;
        }
        assert_eq!(
            classify_planar_boundaries(&plane(), &rows(vec![outer, inner])),
            FaceLoops::unspecified(vec![loop_id(0), loop_id(1)])
        );
    }

    #[test]
    fn one_boundary_is_outer() {
        assert_eq!(
            classify_planar_boundaries(&plane(), &rows(vec![square(0.0, 0.0, 1.0, 1.0)])),
            FaceLoops::classified(loop_id(0), Vec::new())
        );
    }

    #[test]
    fn containment_classifies_outer_and_hole_independent_of_order() {
        assert_eq!(
            classify_planar_boundaries(
                &plane(),
                &rows(vec![square(1.0, 1.0, 3.0, 3.0), square(0.0, 0.0, 5.0, 5.0)])
            ),
            FaceLoops::classified(loop_id(1), vec![loop_id(0)])
        );
    }

    #[test]
    fn disjoint_boundaries_remain_unspecified() {
        assert_eq!(
            classify_planar_boundaries(
                &plane(),
                &rows(vec![square(0.0, 0.0, 1.0, 1.0), square(3.0, 0.0, 4.0, 1.0)])
            ),
            FaceLoops::unspecified(vec![loop_id(0), loop_id(1)])
        );
    }

    #[test]
    fn a_face_past_the_point_bound_stays_unclassified_with_a_loss() {
        let hole = square(-1.0, -1.0, 1.0, 1.0);
        let outer_points = u32::try_from(super::MAX_PLANAR_BOUNDARY_POINTS + 1 - hole.len())
            .expect("fixture point count");
        let outer = (0..outer_points)
            .map(|index| {
                let angle = std::f64::consts::TAU * f64::from(index) / f64::from(outer_points);
                Point3::new(10.0 * angle.cos(), 10.0 * angle.sin(), 0.0)
            })
            .collect();
        let mut refusal = crate::nurbs::LaneRefusals::new();
        assert_eq!(
            super::classify_planar_boundaries(&plane(), &rows(vec![outer, hole]), &mut refusal)
                .expect("classify planar boundaries"),
            FaceLoops::unspecified(vec![loop_id(0), loop_id(1)])
        );
        let notes = refusal.take_notes();
        let [note] = notes.as_slice() else {
            panic!("one bounded planar face");
        };
        assert_eq!(
            note.code,
            crate::loss::CatiaLossCode::TopologyPlanarBoundaryBounded.kind()
        );
        assert!(note
            .message
            .contains("loop catia:test:loop#0 states 4097 boundary points"));
        assert!(note.message.contains("bound of 4096 points"));
    }

    #[test]
    fn classified_and_declined_faces_within_the_bound_state_no_loss() {
        let mut refusal = crate::nurbs::LaneRefusals::new();
        for boundaries in [
            vec![square(1.0, 1.0, 3.0, 3.0), square(0.0, 0.0, 5.0, 5.0)],
            vec![square(0.0, 0.0, 1.0, 1.0), square(3.0, 0.0, 4.0, 1.0)],
        ] {
            super::classify_planar_boundaries(&plane(), &rows(boundaries), &mut refusal)
                .expect("classify planar boundaries");
        }
        assert_eq!(refusal.note_count(), 0);
    }

    #[test]
    fn overlapping_or_nested_holes_remain_unspecified() {
        let outer = square(0.0, 0.0, 10.0, 10.0);
        let unspecified = FaceLoops::unspecified(vec![loop_id(0), loop_id(1), loop_id(2)]);
        assert_eq!(
            classify_planar_boundaries(
                &plane(),
                &rows(vec![
                    outer.clone(),
                    square(1.0, 1.0, 5.0, 5.0),
                    square(4.0, 4.0, 8.0, 8.0)
                ])
            ),
            unspecified
        );
        assert_eq!(
            classify_planar_boundaries(
                &plane(),
                &rows(vec![
                    outer,
                    square(1.0, 1.0, 9.0, 9.0),
                    square(2.0, 2.0, 3.0, 3.0)
                ])
            ),
            unspecified
        );
    }
}
