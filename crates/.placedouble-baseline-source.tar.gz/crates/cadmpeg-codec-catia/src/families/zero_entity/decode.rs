// SPDX-License-Identifier: Apache-2.0
//! Zero-entity decode route for independently complete geometry carriers.

use cadmpeg_core::decode::u64_from_index;

use std::collections::HashMap;

use cadmpeg_ir::codec::DecodeBody;
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    pcurve::PcurveGeometry, Curve, CurveGeometry, IntcurveSupportContext, IntcurveSupportSide,
    ProceduralCurve, ProceduralCurveDefinition, SolvedCurveGeometry, Surface, SurfaceCurveFamily,
};
use cadmpeg_ir::ids::{
    BodyId, CurveId, EdgeId, PointId, ProceduralCurveId, RegionId, ShellId, SurfaceId, VertexId,
};
use cadmpeg_ir::scalar::{FiniteReal, PositiveReal};
use cadmpeg_ir::topology::{Body, BodyKind, Edge, Point, Region, Shell, Vertex};
use cadmpeg_ir::AnnotationBuilder;
use cadmpeg_ir::Exactness;

use crate::assemble::{
    annotate, link_payload_carriers, neutral_model_is_admissible, preserve_raw_payload,
};
use crate::container::{self, ContainerScan};
use crate::families::{FamilyEntityAdmission, FamilyOutput};
use crate::loss::CatiaLossCode;

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct WireTransferCounts {
    bodies: usize,
    owned_bodies: usize,
    loops: usize,
    edges: usize,
    vertices: usize,
    points: usize,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct WireCurveOrientation {
    reversed: bool,
    source_range: [f64; 2],
    edge_range: [f64; 2],
}

#[derive(Debug, Clone)]
struct WireSourceProcedural {
    construction_id: ProceduralCurveId,
    definition: ProceduralCurveDefinition,
    cache_fit_tolerance: Option<cadmpeg_ir::geometry::FitTolerance>,
}

struct ClosedWireMember<'a> {
    support: &'a crate::families::zero_entity::records::ZeroEntitySupportOccurrence,
    curve: CurveId,
    endpoints: [FinitePoint3; 2],
    forward: bool,
    parameter_range: Option<[f64; 2]>,
}

const ZERO_ENTITY_WIRE_TOLERANCE: PositiveReal = match PositiveReal::new(2e-3) {
    Some(tolerance) => tolerance,
    None => panic!("zero-entity point tolerance must be positive and finite"),
};

fn closed_wire_loop_members<'a>(
    run: &'a crate::families::zero_entity::records::ZeroEntitySupportRun,
    loop_record: &'a crate::families::zero_entity::records::ZeroEntityLoop,
    support_curve_ids: &'a HashMap<u32, CurveId>,
) -> Option<Vec<ClosedWireMember<'a>>> {
    let member_count = loop_record.support_record_ordinals.len();
    if member_count == 0
        || loop_record.forward_senses.len() != member_count
        || loop_record.oriented_model_endpoints.len() != member_count
    {
        return None;
    }
    let mut supports_by_ordinal = HashMap::new();

    for support in &run.supports {
        supports_by_ordinal.insert(support.record_ordinal, support);
    }
    let mut members = Vec::new();

    for ((record_ordinal, endpoints), forward) in loop_record
        .support_record_ordinals
        .iter()
        .zip(&loop_record.oriented_model_endpoints)
        .zip(&loop_record.forward_senses)
    {
        let support = supports_by_ordinal.get(record_ordinal).copied()?;
        let curve = support_curve_ids.get(record_ordinal)?;
        support.model_endpoints?;
        let parameter_range = support
            .model_parameters
            .map(|parameters| parameters.map(FiniteReal::get))
            .filter(|parameters| parameters[0] != parameters[1]);
        members.push(ClosedWireMember {
            support,
            curve: curve.clone(),
            endpoints: *endpoints,
            forward: *forward,
            parameter_range,
        });
    }
    members
        .iter()
        .enumerate()
        .all(|(index, member)| {
            let next_start = members[(index + 1) % member_count].endpoints[0];
            member.endpoints[1].distance(next_start.get()) <= ZERO_ENTITY_WIRE_TOLERANCE.get()
        })
        .then_some(members)
}

fn append_oriented_wire_curve(
    admission: &mut FamilyEntityAdmission<'_, '_>,
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    curve_id: CurveId,
    geometry: CurveGeometry,
    source_pos: usize,
    procedural: Option<(
        ProceduralCurveDefinition,
        Option<cadmpeg_ir::geometry::FitTolerance>,
    )>,
) -> Result<(), cadmpeg_core::CodecError> {
    let geometry = if let Some((definition, cache_fit_tolerance)) = procedural {
        let construction_id =
            ProceduralCurveId::mint(format!("{}-construction", curve_id.as_str()))
                .map_err(cadmpeg_core::CodecError::malformed)?;
        annotate(
            annotations,
            &construction_id,
            "zero_entity_a9_03",
            u64_from_index(source_pos),
            "oriented_support_model_curve_construction",
            Exactness::Derived,
        )?;
        annotations.derived(&construction_id, "curve")?;
        annotations.derived(&construction_id, "definition")?;
        let mut definition = definition;
        let cached = match cache_fit_tolerance.map(cadmpeg_ir::geometry::LegacyCache::new) {
            Some(cache) => definition
                .set_legacy_cache(cache)
                .map_err(|error| error.to_string()),
            None => {
                definition.clear_legacy_cache();
                Ok(())
            }
        };
        let admitted = match cached {
            Ok(()) => Ok(ProceduralCurve::new(construction_id.clone(), definition)),
            Err(error) => Err(error),
        };
        match admitted {
            Ok(procedural) => {
                let cache = match geometry {
                    CurveGeometry::Procedural { cache, .. } => cache,
                    CurveGeometry::Solved(SolvedCurveGeometry::Unknown { .. }) => None,
                    CurveGeometry::Solved(geometry) => Some(geometry),
                };
                admission.charge()?;
                ir.geometry.procedural_curves.push(procedural);
                CurveGeometry::Procedural {
                    construction: construction_id,
                    cache,
                }
            }
            Err(error) => return Err(cadmpeg_core::CodecError::malformed(error)),
        }
    } else {
        geometry
    };
    annotate(
        annotations,
        &curve_id,
        "zero_entity_a9_03",
        u64_from_index(source_pos),
        "oriented_support_model_curve",
        Exactness::Derived,
    )?;
    annotations.derived(&curve_id, "geometry")?;
    admission.charge()?;
    ir.geometry.curves.push(Curve {
        parameter_range: None,
        id: curve_id,
        geometry,
        source_object: None,
        native_ref: None,
    });
    Ok(())
}

fn copy_zero_procedural_definition(
    definition: &ProceduralCurveDefinition,
) -> Result<ProceduralCurveDefinition, cadmpeg_core::CodecError> {
    match definition {
        ProceduralCurveDefinition::Helix(_) => Ok(definition.clone()),
        ProceduralCurveDefinition::SurfaceCurve {
            family:
                SurfaceCurveFamily::Parametric {
                    context,
                    tail: None,
                },
        } => Ok(ProceduralCurveDefinition::SurfaceCurve {
            family: SurfaceCurveFamily::Parametric {
                context: context.clone(),
                tail: None,
            },
        }),
        _ => Err(cadmpeg_core::CodecError::malformed(
            "zero-entity wire source has an unexpected procedural construction",
        )),
    }
}

fn source_wire_procedural(
    ir: &CadIr,
    geometry: &CurveGeometry,
) -> Result<Option<WireSourceProcedural>, cadmpeg_core::CodecError> {
    let CurveGeometry::Procedural { construction, .. } = geometry else {
        return Ok(None);
    };
    ir.geometry
        .procedural_curves
        .iter()
        .find(|candidate| candidate.id == *construction)
        .map(|candidate| {
            Ok(WireSourceProcedural {
                construction_id: candidate.id.clone(),
                definition: copy_zero_procedural_definition(candidate.definition())?,
                cache_fit_tolerance: candidate.definition().cache_fit_tolerance(),
            })
        })
        .transpose()
}

/// Transfer closed face-local boundary wires without assigning unresolved
/// source physical-edge or face identities. A complete ownership root groups
/// the wires under its one source shell and body.
fn transfer_closed_wire_loops(
    admission: &mut FamilyEntityAdmission<'_, '_>,
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    support_runs: &[crate::families::zero_entity::records::ZeroEntitySupportRun],
    support_curve_ids: &HashMap<u32, CurveId>,
    ownership_root: Option<&crate::families::zero_entity::records::ZeroEntityOwnershipRoot>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<WireTransferCounts, cadmpeg_core::CodecError> {
    let mut counts = WireTransferCounts::default();
    let root_owns_support_runs = ownership_root.is_some_and(|root| {
        root.face_slots.len() == support_runs.len()
            && support_runs.iter().all(|run| run.face.is_some())
    });
    let mut owned_edge_ids = Vec::new();
    let mut source_curve_geometries = HashMap::<CurveId, Option<CurveGeometry>>::new();
    let mut source_curve_procedurals = HashMap::<CurveId, Option<WireSourceProcedural>>::new();
    let mut source_curve_orientations = HashMap::<CurveId, WireCurveOrientation>::new();

    for run in support_runs {
        let Some(face) = run.face.as_ref() else {
            continue;
        };

        for loop_record in face.loops.iter().flatten() {
            let Some(members) = closed_wire_loop_members(run, loop_record, support_curve_ids)
            else {
                continue;
            };
            let member_count = members.len();

            let carrier_ordinal = run.carrier_record_ordinal;
            let face_ordinal = face.record_ordinal;
            let loop_ordinal = loop_record.record_ordinal;
            let body_id = BodyId::mint(format!(
                "catia:zero-entity:wire-body#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}"
            ))
            .map_err(cadmpeg_core::CodecError::malformed)?;
            let region_id = RegionId::mint(format!(
                "catia:zero-entity:wire-region#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}"
            ))
            .map_err(cadmpeg_core::CodecError::malformed)?;
            let shell_id = ShellId::mint(format!(
                "catia:zero-entity:wire-shell#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}"
            ))
            .map_err(cadmpeg_core::CodecError::malformed)?;
            if !root_owns_support_runs {
                annotate(
                    annotations,
                    &body_id,
                    "zero_entity_a9_03",
                    u64_from_index(loop_record.pos),
                    "standalone_wire_owner",
                    Exactness::Inferred,
                )?;
                annotate(
                    annotations,
                    &region_id,
                    "zero_entity_a9_03",
                    u64_from_index(loop_record.pos),
                    "standalone_wire_region",
                    Exactness::Inferred,
                )?;
                annotate(
                    annotations,
                    &shell_id,
                    "zero_entity_a9_03",
                    u64_from_index(loop_record.pos),
                    "standalone_wire_shell",
                    Exactness::Inferred,
                )?;
            }

            let mut vertex_ids = Vec::new();

            for (index, member) in members.iter().enumerate() {
                let start = member.endpoints[0];
                let point_id = PointId::mint(format!(
                    "catia:zero-entity:wire-point#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}-{index}"
                ))
                .map_err(cadmpeg_core::CodecError::malformed)?;
                let vertex_id = VertexId::mint(format!(
                    "catia:zero-entity:wire-vertex#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}-{index}"
                ))
                .map_err(cadmpeg_core::CodecError::malformed)?;
                annotate(
                    annotations,
                    &point_id,
                    "zero_entity_a9_03",
                    u64_from_index(loop_record.pos),
                    "standalone_wire_point",
                    Exactness::Derived,
                )?;
                annotate(
                    annotations,
                    &vertex_id,
                    "zero_entity_a9_03",
                    u64_from_index(loop_record.pos),
                    "standalone_wire_vertex",
                    Exactness::Derived,
                )?;
                annotations.derived(&point_id, "position")?;
                annotations.derived(&vertex_id, "point")?;
                admission.charge()?;
                ir.geometry
                    .points
                    .push(Point::new(point_id.clone(), start, None));
                admission.charge()?;
                ir.geometry.vertices.push(Vertex {
                    id: vertex_id.clone(),
                    point: point_id,
                    tolerance: Some(ZERO_ENTITY_WIRE_TOLERANCE),
                    native_ref: None,
                });
                vertex_ids.push(vertex_id);
                counts.points += 1;
                counts.vertices += 1;
            }

            let mut edge_ids = Vec::new();

            for (index, member) in members.iter().enumerate() {
                let ClosedWireMember {
                    support,
                    curve,
                    forward,
                    parameter_range,
                    ..
                } = member;
                let edge_id = EdgeId::mint(format!(
                    "catia:zero-entity:wire-edge#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}-{index}"
                ))
                .map_err(cadmpeg_core::CodecError::malformed)?;
                let (curve_id, param_range) = if let Some(parameters) = *parameter_range {
                    let oriented_range = if *forward {
                        parameters
                    } else {
                        [parameters[1], parameters[0]]
                    };
                    let reversed = oriented_range[0] > oriented_range[1];
                    let raw_source_range = if reversed {
                        [oriented_range[1], oriented_range[0]]
                    } else {
                        oriented_range
                    };
                    if !source_curve_geometries.contains_key(curve) {
                        let geometry = ir
                            .geometry
                            .curves
                            .iter()
                            .find(|candidate| candidate.id == *curve)
                            .map(|candidate| candidate.geometry.clone());
                        source_curve_geometries.insert(curve.clone(), geometry);
                    }
                    let source_geometry = source_curve_geometries
                        .get(curve)
                        .and_then(Option::as_ref)
                        .cloned();
                    let canonical_source_range = match source_geometry.as_ref() {
                        Some(geometry) => crate::nurbs::canonical_model_curve_range(
                            geometry,
                            raw_source_range,
                            refusal,
                            "zero-entity wire edge source parameter range",
                        ),
                        None => Some(raw_source_range),
                    };
                    let source_range = canonical_source_range.unwrap_or(raw_source_range);
                    let existing = source_curve_orientations.get(curve).copied();
                    if canonical_source_range.is_none() {
                        (curve.clone(), None)
                    } else if let Some(orientation) = existing.filter(|orientation| {
                        orientation.reversed == reversed && orientation.source_range == source_range
                    }) {
                        (curve.clone(), Some(orientation.edge_range))
                    } else if !reversed && existing.is_some_and(|orientation| !orientation.reversed)
                    {
                        (curve.clone(), Some(source_range))
                    } else if existing.is_none() && !reversed {
                        let procedural_available =
                            if matches!(&source_geometry, Some(CurveGeometry::Procedural { .. })) {
                                if !source_curve_procedurals.contains_key(curve) {
                                    let procedural = source_geometry
                                        .as_ref()
                                        .map(|geometry| source_wire_procedural(ir, geometry))
                                        .transpose()?
                                        .flatten();
                                    source_curve_procedurals.insert(curve.clone(), procedural);
                                }
                                source_curve_procedurals
                                    .get(curve)
                                    .and_then(Option::as_ref)
                                    .is_some()
                            } else {
                                true
                            };
                        if source_geometry.is_none() || !procedural_available {
                            (curve.clone(), None)
                        } else {
                            let orientation = WireCurveOrientation {
                                reversed,
                                source_range,
                                edge_range: source_range,
                            };
                            source_curve_orientations.insert(curve.clone(), orientation);
                            (curve.clone(), Some(source_range))
                        }
                    } else if let Some(geometry) = source_geometry {
                        if !source_curve_procedurals.contains_key(curve) {
                            let procedural = source_wire_procedural(ir, &geometry)?;
                            source_curve_procedurals.insert(curve.clone(), procedural);
                        }
                        let source_procedural =
                            source_curve_procedurals.get(curve).and_then(Option::as_ref);
                        let oriented = if reversed {
                            match source_procedural {
                                Some(procedural) => crate::nurbs::reverse_helix_definition(
                                    &procedural.definition,
                                    source_range,
                                    refusal,
                                    "zero-entity helix edge reversed onto its coedge",
                                )
                                .map(|(definition, edge_range)| {
                                    (
                                        geometry.clone(),
                                        edge_range,
                                        Some((definition, procedural.cache_fit_tolerance)),
                                    )
                                }),
                                None => crate::nurbs::reverse_curve_geometry(
                                    &geometry,
                                    source_range,
                                    refusal,
                                    "zero-entity edge curve reversed onto its edge",
                                )
                                .map(|(geometry, edge_range)| (geometry, edge_range, None)),
                            }
                        } else {
                            Some((
                                geometry,
                                source_range,
                                source_procedural
                                    .map(|procedural| {
                                        Ok::<_, cadmpeg_core::CodecError>((
                                            copy_zero_procedural_definition(
                                                &procedural.definition,
                                            )?,
                                            procedural.cache_fit_tolerance,
                                        ))
                                    })
                                    .transpose()?,
                            ))
                        };
                        if let Some((geometry, edge_range, procedural)) = oriented {
                            if existing.is_none() {
                                let carrier_updated = if reversed {
                                    if let (Some((definition, _)), Some(source_procedural)) =
                                        (procedural.as_ref(), source_procedural.as_ref())
                                    {
                                        if let Some(candidate) = ir
                                            .geometry
                                            .procedural_curves
                                            .iter_mut()
                                            .find(|candidate| {
                                                candidate.id == source_procedural.construction_id
                                            })
                                        {
                                            candidate.replace_definition(
                                                copy_zero_procedural_definition(definition)?,
                                            );
                                            true
                                        } else {
                                            false
                                        }
                                    } else {
                                        if let Some(candidate) = ir
                                            .geometry
                                            .curves
                                            .iter_mut()
                                            .find(|candidate| candidate.id == *curve)
                                        {
                                            candidate.geometry = geometry.clone();
                                            true
                                        } else {
                                            false
                                        }
                                    }
                                } else {
                                    true
                                };
                                if carrier_updated {
                                    source_curve_orientations.insert(
                                        curve.clone(),
                                        WireCurveOrientation {
                                            reversed,
                                            source_range,
                                            edge_range,
                                        },
                                    );
                                    (curve.clone(), Some(edge_range))
                                } else {
                                    (curve.clone(), None)
                                }
                            } else {
                                let oriented_curve_id = CurveId::mint(format!(
                                    "catia:zero-entity:wire-curve#{carrier_ordinal}-{face_ordinal}-{loop_ordinal}-{index}"
                                ))
                                .map_err(cadmpeg_core::CodecError::malformed)?;
                                append_oriented_wire_curve(
                                    admission,
                                    ir,
                                    annotations,
                                    oriented_curve_id.clone(),
                                    geometry,
                                    support.pos,
                                    procedural,
                                )?;
                                (oriented_curve_id, Some(edge_range))
                            }
                        } else {
                            (curve.clone(), None)
                        }
                    } else {
                        (curve.clone(), None)
                    }
                } else {
                    (curve.clone(), None)
                };
                let param_range = param_range.and_then(|range| {
                    ir.geometry
                        .curves
                        .iter()
                        .find(|candidate| candidate.id == curve_id)
                        .map(|candidate| (range, &candidate.geometry))
                });
                let param_range = match param_range {
                    Some((range, geometry)) => crate::nurbs::canonical_model_curve_range(
                        geometry,
                        range,
                        refusal,
                        "zero-entity standalone wire edge parameter range",
                    ),
                    None => None,
                };
                annotate(
                    annotations,
                    &edge_id,
                    "zero_entity_a9_03",
                    u64_from_index(support.pos),
                    "standalone_wire_edge",
                    Exactness::Derived,
                )?;
                annotations.derived(&edge_id, "curve")?;
                annotations.derived(&edge_id, "ends.start")?;
                annotations.derived(&edge_id, "ends.end")?;
                admission.charge()?;
                ir.geometry.edges.push(Edge {
                    id: edge_id.clone(),
                    carrier: cadmpeg_ir::topology::EdgeCarrier::new(Some(curve_id), param_range)
                        .map_err(cadmpeg_core::CodecError::malformed)?,
                    ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                        vertex_ids[index].clone(),
                        vertex_ids[(index + 1) % member_count].clone(),
                    )),
                    tolerance: Some(ZERO_ENTITY_WIRE_TOLERANCE),
                    native_ref: None,
                });
                if param_range.is_some() {
                    annotations.derived(&edge_id, "param_range")?;
                }
                edge_ids.push(edge_id);
                counts.edges += 1;
            }

            if root_owns_support_runs {
                owned_edge_ids.extend(edge_ids);
            } else {
                admission.charge()?;
                ir.geometry.bodies.push(Body {
                    id: body_id.clone(),
                    kind: BodyKind::Wire,
                    transform: None,
                    name: None,
                    color: None,
                    visible: None,
                    native_ref: None,
                });
                let shells = vec![shell_id.clone()];
                admission.charge()?;
                ir.geometry.regions.push(Region {
                    id: region_id.clone(),
                    body: body_id,
                    shells,
                    native_ref: None,
                });
                admission.charge()?;
                if edge_ids.is_empty() {
                    return Ok(counts);
                }
                ir.geometry.shells.push(Shell::with_members(
                    shell_id,
                    region_id,
                    edge_ids,
                    Vec::new(),
                ));
                counts.bodies += 1;
            }
            counts.loops += 1;
        }
    }

    if root_owns_support_runs && counts.loops != 0 {
        let Some(root) = ownership_root else {
            return Ok(counts);
        };
        let identity = root.body_record_ordinal()?;
        let body_id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "zero-entity", "owned-wire-body"),
            identity,
            BodyId::mint,
        )?;
        let region_id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "zero-entity", "owned-wire-region"),
            identity,
            RegionId::mint,
        )?;
        let shell_id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "zero-entity", "owned-wire-shell"),
            identity,
            ShellId::mint,
        )?;
        annotate(
            annotations,
            &body_id,
            "zero_entity_a9_03",
            u64_from_index(root.body_pos),
            "owned_wire_body",
            Exactness::Derived,
        )?;
        annotate(
            annotations,
            &region_id,
            "zero_entity_a9_03",
            u64_from_index(root.shell_pos),
            "owned_wire_region",
            Exactness::Derived,
        )?;
        annotate(
            annotations,
            &shell_id,
            "zero_entity_a9_03",
            u64_from_index(root.shell_pos),
            "owned_wire_shell",
            Exactness::Derived,
        )?;
        admission.charge()?;
        ir.geometry.bodies.push(Body {
            id: body_id.clone(),
            kind: BodyKind::Wire,
            transform: None,
            name: None,
            color: None,
            visible: None,
            native_ref: None,
        });
        let shells = vec![shell_id.clone()];
        admission.charge()?;
        ir.geometry.regions.push(Region {
            id: region_id.clone(),
            body: body_id,
            shells,
            native_ref: None,
        });
        admission.charge()?;
        if owned_edge_ids.is_empty() {
            return Ok(counts);
        }
        ir.geometry.shells.push(Shell::with_members(
            shell_id,
            region_id,
            owned_edge_ids,
            Vec::new(),
        ));
        counts.bodies += 1;
        counts.owned_bodies += 1;
    }

    Ok(counts)
}

fn zero_entity_coverage(
    transferred_support_curves: usize,
    transferred_parametric_surface_curves: usize,
    wire_counts: WireTransferCounts,
    topology_counts: Option<
        crate::families::zero_entity::topology_transfer::ZeroEntityTopologyCounts,
    >,
) -> cadmpeg_ir::report::decode::Coverage {
    let mut coverage = cadmpeg_ir::report::decode::Coverage::default();
    for (key, count) in [
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_SUPPORT_CURVE_COUNT,
            transferred_support_curves,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_PARAMETRIC_SURFACE_CURVE_COUNT,
            transferred_parametric_surface_curves,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_WIRE_BODY_COUNT,
            wire_counts.bodies,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_OWNED_WIRE_BODY_COUNT,
            wire_counts.owned_bodies,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_WIRE_LOOP_COUNT,
            wire_counts.loops,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_WIRE_EDGE_COUNT,
            wire_counts.edges,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_WIRE_VERTEX_COUNT,
            wire_counts.vertices,
        ),
        (
            crate::coverage::TRANSFERRED_ZERO_ENTITY_WIRE_POINT_COUNT,
            wire_counts.points,
        ),
    ] {
        coverage.record(key, count);
    }
    if let Some(counts) = topology_counts {
        for (key, count) in [
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_BODY_COUNT,
                counts.bodies,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_FACE_COUNT,
                counts.faces,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_LOOP_COUNT,
                counts.loops,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_COEDGE_COUNT,
                counts.coedges,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_EDGE_COUNT,
                counts.edges,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_VERTEX_COUNT,
                counts.vertices,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_POINT_COUNT,
                counts.points,
            ),
            (
                crate::coverage::TRANSFERRED_ZERO_ENTITY_TOPOLOGY_PCURVE_COUNT,
                counts.pcurves,
            ),
        ] {
            coverage.record(key, count);
        }
    }
    coverage
}

pub(in crate::families) fn try_decode_zero_entity(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<FamilyOutput>, cadmpeg_core::CodecError> {
    (|| -> Option<Result<FamilyOutput, cadmpeg_core::CodecError>> {
    macro_rules! admitted {
        ($value:expr) => {
            match $value {
                Ok(value) => value,
                Err(error) => return Some(Err(error)),
            }
        };
    }
    let preamble = container::outer_preamble_range(&scan.data)?;
    let surfaces = crate::families::zero_entity::records::zero_entity_surfaces_in_range(&scan.data, preamble.clone(), refusal);
    if surfaces.is_empty() {
        return None;
    }
    let support_runs = match crate::families::zero_entity::records::zero_entity_support_runs_in_range(
        ctx, &scan.data, preamble.clone(), refusal,
    ) {
        Ok(runs) => runs,
        Err(error) => return Some(Err(error)),
    };
    let allocation_topology = match super::allocation::parse(&scan.data, preamble.clone(), &support_runs) {
        Ok(topology) => topology,
        Err(error) => return Some(Err(error)),
    };
    let ownership_root = crate::families::zero_entity::records::zero_entity_ownership_root_in_range(&scan.data, preamble.clone());

    let mut ir = CadIr::empty();
    let mut admission = FamilyEntityAdmission::new(ctx);
    let mut annotations = AnnotationBuilder::new();
    let mut unknowns = Vec::new();
    let payload_index = match preserve_raw_payload(
        ctx,
        &mut unknowns,
        &mut annotations,
        scan,
        admitted!(cadmpeg_ir::ids::UnknownId::mint("catia:payload:unknown#zero-entity".to_owned()).map_err(cadmpeg_core::CodecError::malformed)),
    ) {
        Ok(index) => index,
        Err(error) => return Some(Err(error)),
    };

    let mut surface_ids_by_position = HashMap::new();
    for (index, surface) in surfaces.into_iter().enumerate() {
        let id = admitted!(crate::resource::compose_index_id(&cadmpeg_ir::identity_namespace!("catia", "zero-entity", "surf"), index, SurfaceId::mint));
        admitted!(annotate(&mut annotations, &id, "zero_entity_a9_03", u64_from_index(surface.pos), "analytic_surface", Exactness::ByteExact));
        if let Err(error) = admission.charge() {
            return Some(Err(error));
        }
        ir.geometry.surfaces.push(Surface {
            id: id.clone(),
            geometry: surface.geometry,
            source_object: None,
            native_ref: None,
        });
        surface_ids_by_position.insert(surface.pos, id);
    }

    let mut transferred_support_curves = 0usize;
    let mut transferred_parametric_surface_curves = 0usize;
    let mut support_curve_ids = HashMap::new();
    for run in &support_runs {
        let Some(surface) = surface_ids_by_position.get(&run.carrier_pos) else {
            continue;
        };
        let surface = surface.clone();
        for support in &run.supports {
            let curve_id = admitted!(crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "zero-entity", "support-curve"),
                support.record_ordinal,
                CurveId::mint
            ));
            if let Some(geometry) = support.model_curve.clone() {
                admitted!(annotate(&mut annotations, &curve_id, "zero_entity_a9_03", u64_from_index(support.pos), "support_model_curve", Exactness::Derived));
                admitted!(annotations.derived(&curve_id, "geometry").map(|_| ()).map_err(cadmpeg_core::CodecError::from));
                if let Err(error) = admission.charge() {
                    return Some(Err(error));
                }
                ir.geometry.curves.push(Curve {
                    parameter_range: None,
                    id: curve_id.clone(),
                    geometry,
                    source_object: None,
                    native_ref: None,
                });
                support_curve_ids.insert(support.record_ordinal, curve_id);
                transferred_support_curves += 1;
                continue;
            }

            let (definition, role) =
                if let Some(definition) = admitted!(support.model_curve_construction.as_ref().map(copy_zero_procedural_definition).transpose()) {
                    (definition, "support_model_curve_construction")
                } else {
                    let Some(pcurve) = support.pcurve.as_ref() else {
                        continue;
                    };
                    let Some(surface_geometry) = ir
                        .geometry
                        .surfaces
                        .iter()
                        .find(|candidate| candidate.id == surface)
                        .map(|candidate| &candidate.geometry)
                    else {
                        continue;
                    };
                    let Some(pcurve) =
                        crate::families::zero_entity::records::zero_entity_neutral_pcurve(
                            surface_geometry,
                            pcurve,
                            &format_args!(
                                "zero-entity support record #{} at byte {}",
                                support.record_ordinal, support.pos
                            ),
                            refusal,
                        )
                    else {
                        continue;
                    };
                    let PcurveGeometry::Nurbs { nurbs } = &pcurve else {
                        continue;
                    };
                    let Some(parameter_range) = usize::try_from(nurbs.degree())
                        .ok()
                        .and_then(|degree| {
                            Some([
                                *nurbs.knots().get(degree)?,
                                *nurbs.knots().get(nurbs.pole_rows().count())?,
                            ])
                        })
                        .filter(|range| range[0] < range[1])
                    else {
                        continue;
                    };
                    transferred_parametric_surface_curves += 1;
                    (
                        ProceduralCurveDefinition::SurfaceCurve {
                            family: SurfaceCurveFamily::Parametric {
                                context: IntcurveSupportContext::try_new(
                                    [
                                        IntcurveSupportSide {
                                            surface: Some(surface.clone()),
                                            pcurve: Some(pcurve.into()),
                                        },
                                        IntcurveSupportSide {
                                            surface: None,
                                            pcurve: None,
                                        },
                                    ],
                                    parameter_range,
                                    std::array::from_fn(|_| Vec::new()),
                                )
                                .ok()?,
                                tail: None,
                            },
                        },
                        "parametric_surface_curve",
                    )
                };
            let construction_id = admitted!(crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!(
                    "catia", "zero-entity", "support-curve-construction"),
                support.record_ordinal, ProceduralCurveId::mint));
            admitted!(annotate(&mut annotations, &curve_id, "zero_entity_a9_03", u64_from_index(support.pos), role, Exactness::Derived));
            admitted!(annotations.derived(&curve_id, "geometry").map_err(cadmpeg_core::CodecError::from));
            admitted!(annotate(&mut annotations, &construction_id, "zero_entity_a9_03", u64_from_index(support.pos), role, Exactness::Derived));
            admitted!(annotations.derived(&construction_id, "curve").map_err(cadmpeg_core::CodecError::from));
            admitted!(annotations.derived(&construction_id, "definition").map_err(cadmpeg_core::CodecError::from));
            admitted!(admission.charge());
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: curve_id.clone(),
                geometry: CurveGeometry::Procedural {
                    construction: construction_id.clone(),
                    cache: None,
                },
                source_object: None,
                native_ref: None,
            });
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry
                .procedural_curves
                .push(ProceduralCurve::new(construction_id, definition));
            support_curve_ids.insert(support.record_ordinal, curve_id);
            transferred_support_curves += 1;
        }
    }

    let topology_counts = if let Some(allocation_topology) = &allocation_topology {
        let mut candidate_ir = std::mem::replace(&mut ir, CadIr::empty());
        let mut candidate_annotations = annotations.copy_transaction();
        let counts = crate::families::zero_entity::topology_transfer::transfer_closed_face_topology(
            &mut admission,
            &mut candidate_ir,
            &mut candidate_annotations,
            crate::families::zero_entity::topology_transfer::ZeroEntityClosedTopology {
                allocation_topology,
                support_runs: &support_runs,
                surface_ids_by_position: &surface_ids_by_position,
                support_curve_ids: &support_curve_ids,
                ownership_root: ownership_root.as_ref(),
            },
            refusal,
        );
        let admissible = match &counts {
            Ok(Some(_)) => match neutral_model_is_admissible(ctx, &mut candidate_ir, &unknowns) {
                Ok(admissible) => admissible,
                Err(limit) => return Some(Err(limit)),
            },
            _ => false,
        };
        match counts {
            Ok(Some(counts)) if admissible => {
                ir = candidate_ir;
                annotations = candidate_annotations.into_retained();
                Some(counts)
            }
            Err(error) => return Some(Err(error)),
            _ => {
                // Only source carriers precede this transfer. Remove its
                // speculative topology before the wire fallback uses them.
                candidate_ir.geometry.bodies.clear();
                candidate_ir.geometry.regions.clear();
                candidate_ir.geometry.shells.clear();
                candidate_ir.geometry.faces.clear();
                candidate_ir.geometry.loops.clear();
                candidate_ir.geometry.coedges.clear();
                candidate_ir.geometry.edges.clear();
                candidate_ir.geometry.vertices.clear();
                candidate_ir.geometry.points.clear();
                candidate_ir.geometry.pcurves.clear();
                ir = candidate_ir;
                None
            },
        }
    } else { None };
    let wire_counts = if topology_counts.is_some() {
        WireTransferCounts::default()
    } else {
        match transfer_closed_wire_loops(
            &mut admission,
            &mut ir,
            &mut annotations,
            &support_runs,
            &support_curve_ids,
            ownership_root.as_ref(),
            refusal,
        ) {
            Ok(counts) => counts,
            Err(error @ cadmpeg_core::CodecError::ResourceLimit(_)) => return Some(Err(error)),
            Err(_) => return None,
        }
    };

    if let Err(error) = link_payload_carriers(&ir, &mut unknowns[payload_index], &mut annotations) {
        return Some(Err(error));
    }
    let coverage = zero_entity_coverage(transferred_support_curves, transferred_parametric_surface_curves, wire_counts, topology_counts);
    let topology_message = if topology_counts.is_some() && ownership_root.is_some() {
        "Complete zero-entity source edge/use/support/incidence/vertex bindings lower into connected neutral faces, loops, coedges, edges, vertices, p-curves, and a body/region/shell hierarchy bound to the complete native ownership root; physical edge, side-use, and vertex identities select their source records."
    } else if topology_counts.is_some() {
        "Complete zero-entity source edge/use/support/incidence/vertex bindings lower into connected neutral faces, loops, coedges, edges, vertices, and p-curves under a deterministic derived body/region/shell hierarchy; physical edge, side-use, and vertex identities select their source records."
    } else if wire_counts.loops == 0 {
        if ownership_root.is_some() {
            "Zero-entity loop members bind their face-local support occurrences and the terminal ownership root binds the complete face roster through one shell and body, but the complete allocation graph or its required geometry is unavailable; no neutral topology was transferred."
        } else {
            "Zero-entity loop members bind their face-local support occurrences, but the complete allocation graph or its required geometry is unavailable and body/shell ownership remains unresolved; no neutral topology was transferred."
        }
    } else if wire_counts.owned_bodies != 0 {
        "Complete zero-entity face-local loops with exact model carriers and closed endpoint tapes were emitted under one derived wire container bound to the complete source shell and body roster; the complete allocation graph or its required face geometry is unavailable."
    } else {
        "Complete zero-entity face-local loops with exact model carriers and closed endpoint tapes were emitted as independent wire bodies; the complete allocation graph or its required face geometry is unavailable and source body/shell bindings remain unresolved."
    };
    let topology_loss = if topology_counts.is_some() {
        CatiaLossCode::TopologyZeroEntityGaugeSubstituted
    } else if wire_counts.loops == 0 {
        CatiaLossCode::TopologyZeroEntityNotTransferred
    } else {
        CatiaLossCode::TopologyZeroEntityFaceUnresolved
    };
    let losses = vec![topology_loss.note(topology_message.to_string())];
    Some(Ok(FamilyOutput {
        ir,
        report: DecodeBody {
            transfer: cadmpeg_ir::report::decode::DecodeTransfer::full(true),
            coverage,
            losses,
            notes: Vec::new(),
            transfer_ledger: cadmpeg_ir::report::decode::TransferLedger::default(),
        },
        annotations: annotations.build(),
        unknowns,
        admitted_model_entities: admission.admitted(),
    }))
    })()
    .transpose()
}

#[cfg(test)]
mod tests {
    use super::{transfer_closed_wire_loops, WireTransferCounts};
    use crate::families::zero_entity::decode::closed_wire_loop_members;
    use crate::families::zero_entity::records::{ZeroEntityLoopClass, ZeroEntityLoopMembers};
    use cadmpeg_ir::document::CadIr;
    use cadmpeg_ir::features::FinitePoint3;
    use cadmpeg_ir::geometry::ProceduralCurveDefinition;
    use cadmpeg_ir::geometry::{
        nurbs::NurbsCurve, Curve, CurveGeometry, ProceduralCurve, SolvedCurveGeometry,
    };
    use cadmpeg_ir::ids::BodyId;
    use cadmpeg_ir::ids::CurveId;
    use cadmpeg_ir::ids::ProceduralCurveId;
    use cadmpeg_ir::math::Point3;
    use cadmpeg_ir::math::Vector3;
    use cadmpeg_ir::topology::BodyKind;
    use cadmpeg_ir::AnnotationBuilder;
    use std::collections::HashMap;
    use std::num::NonZeroUsize;

    fn support(
        record_ordinal: u32,
        pos: usize,
        endpoints: [Point3; 2],
    ) -> crate::families::zero_entity::records::ZeroEntitySupportOccurrence {
        support_with_parameters(record_ordinal, pos, endpoints, Some([0.0, 1.0]))
    }

    fn support_with_parameters(
        record_ordinal: u32,
        pos: usize,
        endpoints: [Point3; 2],
        model_parameters: Option<[f64; 2]>,
    ) -> crate::families::zero_entity::records::ZeroEntitySupportOccurrence {
        crate::families::zero_entity::records::ZeroEntitySupportOccurrence {
            pos,
            record_ordinal,
            tag: [0x21, 0x71],
            face_local_slot: record_ordinal,
            uv_endpoints: None,
            pcurve: None,
            model_curve: None,
            model_curve_construction: None,
            model_parameters: model_parameters.map(crate::test_support::test_b5::finite_pair),
            model_midpoint: None,
            model_endpoints: Some(finite_pair(endpoints)),
        }
    }

    fn finite_pair(pair: [Point3; 2]) -> [FinitePoint3; 2] {
        pair.map(|point| FinitePoint3::new(point).expect("finite test endpoint"))
    }

    fn finite_pairs(pairs: Vec<[Point3; 2]>) -> Vec<[FinitePoint3; 2]> {
        pairs.into_iter().map(finite_pair).collect()
    }

    #[test]
    fn closed_wire_clamps_nurbs_range_at_the_domain_boundary() {
        let first = Point3::new(0.0, 0.0, 0.0);
        let corner = Point3::new(1.0, 0.0, 0.0);
        let mut ir = CadIr::empty();
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: CurveId::mint("catia:test:nurbs#0".to_string()).expect("identity grammar"),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                NurbsCurve::from_lanes(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    vec![first, corner],
                    None,
                    false,
                )
                .expect("valid linear NURBS"),
            )),
            source_object: None,
            native_ref: None,
        });
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: CurveId::mint("catia:test:line#1".to_string()).expect("identity grammar"),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Line(
                cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                    corner,
                    Vector3::new(-1.0, 0.0, 0.0),
                )
                .expect("valid LineCurve fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
        let support_runs = vec![
            crate::families::zero_entity::records::ZeroEntitySupportRun {
                carrier_pos: 0,
                carrier_record_ordinal: 1,
                face: Some(crate::families::zero_entity::records::ZeroEntityFace {
                    pos: 10,
                    record_ordinal: 2,
                    tag: [0x5f, 0x0c],
                    allocations: vec![8],
                    loops: Some(vec![
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 20,
                            record_ordinal: 3,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                8,
                                1,
                                NonZeroUsize::new(2).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![1, 2],
                            support_record_ordinals: vec![4, 5],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true, true],
                            oriented_model_endpoints: finite_pairs(vec![
                                [first, corner],
                                [corner, first],
                            ]),
                        },
                    ]),
                    terminal_control:
                        crate::families::zero_entity::records::ZeroEntityFaceControl::Control05,
                }),
                supports: vec![
                    support_with_parameters(
                        4,
                        30,
                        [first, corner],
                        Some([-1.0e-12, 1.0 + 1.0e-12]),
                    ),
                    support(5, 40, [corner, first]),
                ],
            },
        ];
        let support_curve_ids = HashMap::from([
            (
                4,
                CurveId::mint("catia:test:nurbs#0".to_string()).expect("identity grammar"),
            ),
            (
                5,
                CurveId::mint("catia:test:line#1".to_string()).expect("identity grammar"),
            ),
        ]);
        let mut annotations = AnnotationBuilder::new();

        let counts = crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            transfer_closed_wire_loops(
                &mut admission,
                &mut ir,
                &mut annotations,
                &support_runs,
                &support_curve_ids,
                None,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("valid exactness fields");

        assert_eq!(counts.edges, 2);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
    }

    #[test]
    fn closed_face_local_loop_uses_ownership_root_with_untransferred_sibling() {
        let first = Point3::new(0.0, 0.0, 0.0);
        let corner = Point3::new(1.0, 0.0, 0.0);
        let mut ir = CadIr::empty();
        for (index, (origin, direction)) in [
            (corner, Vector3::new(-1.0, 0.0, 0.0)),
            (first, Vector3::new(1.0, 0.0, 0.0)),
        ]
        .into_iter()
        .enumerate()
        {
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: CurveId::mint(format!("catia:test:curve#{index}")).expect("identity grammar"),
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Line(
                    cadmpeg_ir::geometry::analytic::LineCurve::try_new(origin, direction)
                        .expect("valid LineCurve fixture"),
                )),
                source_object: None,
                native_ref: None,
            });
        }
        let support_runs = vec![
            crate::families::zero_entity::records::ZeroEntitySupportRun {
                carrier_pos: 0,
                carrier_record_ordinal: 1,
                face: Some(crate::families::zero_entity::records::ZeroEntityFace {
                    pos: 10,
                    record_ordinal: 2,
                    tag: [0x5f, 0x0c],
                    allocations: vec![9, 8],
                    loops: Some(vec![
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 20,
                            record_ordinal: 3,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                8,
                                1,
                                NonZeroUsize::new(2).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![1, 2],
                            support_record_ordinals: vec![4, 5],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true, false],
                            oriented_model_endpoints: finite_pairs(vec![
                                [first, corner],
                                [corner, first],
                            ]),
                        },
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 25,
                            record_ordinal: 6,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                9,
                                1,
                                NonZeroUsize::new(2).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![4, 5],
                            support_record_ordinals: vec![5, 4],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true, false],
                            oriented_model_endpoints: finite_pairs(vec![
                                [first, corner],
                                [corner, first],
                            ]),
                        },
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 30,
                            record_ordinal: 7,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                10,
                                1,
                                NonZeroUsize::new(1).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![3],
                            support_record_ordinals: vec![99],
                            loop_class: ZeroEntityLoopClass::Bound50,
                            forward_senses: vec![true],
                            oriented_model_endpoints: finite_pairs(vec![[first, corner]]),
                        },
                    ]),
                    terminal_control:
                        crate::families::zero_entity::records::ZeroEntityFaceControl::Control05,
                }),
                supports: vec![
                    support_with_parameters(4, 30, [first, corner], Some([1.0, 0.0])),
                    support(5, 40, [first, corner]),
                ],
            },
        ];
        let support_curve_ids = HashMap::from([
            (
                4,
                CurveId::mint("catia:test:curve#0".to_string()).expect("identity grammar"),
            ),
            (
                5,
                CurveId::mint("catia:test:curve#1".to_string()).expect("identity grammar"),
            ),
        ]);
        let ownership_root = crate::families::zero_entity::records::ZeroEntityOwnershipRoot {
            face_roster_pos: 50,
            face_roster_record_ordinal: 6,
            face_slots: vec![1],
            shell_pos: 60,
            body_pos: 70,
        };
        let mut annotations = AnnotationBuilder::new();

        let counts = crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            transfer_closed_wire_loops(
                &mut admission,
                &mut ir,
                &mut annotations,
                &support_runs,
                &support_curve_ids,
                Some(&ownership_root),
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("valid exactness fields");

        assert_eq!(counts.bodies, 1);
        assert_eq!(counts.owned_bodies, 1);
        assert_eq!(counts.loops, 2);
        assert_eq!(counts.edges, 4);
        assert_eq!(counts.vertices, 4);
        assert_eq!(counts.points, 4);
        assert_eq!(
            ir.geometry.bodies[0].id,
            BodyId::mint("catia:zero-entity:owned-wire-body#8".to_string())
                .expect("identity grammar")
        );
        assert!(matches!(ir.geometry.bodies[0].kind, BodyKind::Wire));
        assert_eq!(ir.geometry.shells[0].wire_edges().count(), 4);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
        assert_eq!(
            ir.geometry.edges[1]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
        assert_eq!(
            ir.geometry.edges[1].curve().cloned(),
            Some(CurveId::mint("catia:test:curve#1".to_string()).expect("identity grammar"))
        );
        assert!(matches!(ir
        .geometry
        .curves
        .iter()
        .find(|curve| curve.id
            == CurveId::mint("catia:test:curve#1".to_string()).expect("identity grammar"))
        .map(|curve| &curve.geometry), Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve)))
            if {
                let origin = line_curve.origin().get();
                let direction = *line_curve.direction().as_raw();
                origin == corner && direction == Vector3::new(-1.0, 0.0, 0.0)
            }));
        assert_eq!(
            ir.geometry.edges[2].curve().cloned(),
            Some(
                CurveId::mint("catia:zero-entity:wire-curve#1-2-6-0".to_string())
                    .expect("identity grammar")
            )
        );
        assert_eq!(
            ir.geometry.edges[3].curve().cloned(),
            Some(
                CurveId::mint("catia:zero-entity:wire-curve#1-2-6-1".to_string())
                    .expect("identity grammar")
            )
        );
        assert!(crate::assemble::neutral_model_is_admissible(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &mut ir,
            &[]
        )
        .expect("check that the neutral model is admissible"));
    }

    #[test]
    fn closed_wire_canonicalizes_periodic_model_range() {
        let start_angle: f64 = 0.25;
        let end_angle: f64 = 1.25;
        let first = Point3::new(start_angle.cos(), start_angle.sin(), 0.0);
        let corner = Point3::new(end_angle.cos(), end_angle.sin(), 0.0);
        let chord = first.distance(corner);
        let mut ir = CadIr::empty();
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: CurveId::mint("catia:test:circle#0".to_string()).expect("identity grammar"),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                    1.0,
                )
                .expect("valid CircleCurve fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: CurveId::mint("catia:test:line#1".to_string()).expect("identity grammar"),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Line(
                cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                    corner,
                    first.vector_from(corner).scale(1.0 / chord),
                )
                .expect("valid LineCurve fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
        let support_runs = vec![
            crate::families::zero_entity::records::ZeroEntitySupportRun {
                carrier_pos: 0,
                carrier_record_ordinal: 1,
                face: Some(crate::families::zero_entity::records::ZeroEntityFace {
                    pos: 10,
                    record_ordinal: 2,
                    tag: [0x5f, 0x0c],
                    allocations: vec![8],
                    loops: Some(vec![
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 20,
                            record_ordinal: 3,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                8,
                                1,
                                NonZeroUsize::new(2).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![1, 2],
                            support_record_ordinals: vec![4, 5],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true, true],
                            oriented_model_endpoints: finite_pairs(vec![
                                [first, corner],
                                [corner, first],
                            ]),
                        },
                    ]),
                    terminal_control:
                        crate::families::zero_entity::records::ZeroEntityFaceControl::Control05,
                }),
                supports: vec![
                    support_with_parameters(
                        4,
                        30,
                        [first, corner],
                        Some([
                            std::f64::consts::TAU + start_angle,
                            std::f64::consts::TAU + end_angle,
                        ]),
                    ),
                    support_with_parameters(5, 40, [corner, first], Some([0.0, chord])),
                ],
            },
        ];
        let support_curve_ids = HashMap::from([
            (
                4,
                CurveId::mint("catia:test:circle#0".to_string()).expect("identity grammar"),
            ),
            (
                5,
                CurveId::mint("catia:test:line#1".to_string()).expect("identity grammar"),
            ),
        ]);
        let mut annotations = AnnotationBuilder::new();

        let counts = crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            transfer_closed_wire_loops(
                &mut admission,
                &mut ir,
                &mut annotations,
                &support_runs,
                &support_curve_ids,
                None,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("valid exactness fields");

        assert_eq!(counts.loops, 1);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([start_angle, end_angle])
        );
        assert_eq!(
            ir.geometry.edges[1]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, chord])
        );
        assert!(crate::assemble::neutral_model_is_admissible(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &mut ir,
            &[]
        )
        .expect("check that the neutral model is admissible"));
    }

    #[test]
    // These checked constructors must accept the explicit test fixtures.
    #[allow(clippy::unwrap_used)]
    fn closed_wire_reverses_helix_construction_and_clones_mixed_orientation() {
        let first = Point3::new(0.0, 0.0, 0.0);
        let corner = Point3::new(1.0, 0.0, 0.0);
        let curve_id =
            CurveId::mint("catia:test:helix-curve#0".to_string()).expect("identity grammar");
        let construction_id =
            ProceduralCurveId::mint("catia:test:helix-construction#0".to_string())
                .expect("identity grammar");
        let definition = ProceduralCurveDefinition::Helix(
            cadmpeg_ir::geometry::HelixCurveConstruction::try_new(
                [0.0, 1.0],
                cadmpeg_ir::geometry::HelixFrame {
                    center: Point3::new(0.0, 0.0, 0.0),
                    major: Vector3::new(1.0, 0.0, 0.0),
                    minor: Vector3::new(0.0, 1.0, 0.0),
                    pitch: Vector3::new(0.0, 0.0, 1.0),
                    axis: Vector3::new(0.0, 0.0, 1.0),
                },
                0.2,
                None,
            )
            .unwrap(),
        );
        let mut ir = CadIr::empty();
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Procedural {
                construction: construction_id.clone(),
                cache: None,
            },
            source_object: None,
            native_ref: None,
        });
        ir.geometry
            .add_procedural_curve(
                &curve_id,
                ProceduralCurve::new(construction_id.clone(), definition.clone()),
            )
            .unwrap();
        let support_runs = vec![
            crate::families::zero_entity::records::ZeroEntitySupportRun {
                carrier_pos: 0,
                carrier_record_ordinal: 1,
                face: Some(crate::families::zero_entity::records::ZeroEntityFace {
                    pos: 10,
                    record_ordinal: 2,
                    tag: [0x5f, 0x0c],
                    allocations: vec![8],
                    loops: Some(vec![
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 20,
                            record_ordinal: 3,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                8,
                                1,
                                NonZeroUsize::new(2).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![1, 2],
                            support_record_ordinals: vec![4, 4],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true, false],
                            oriented_model_endpoints: finite_pairs(vec![
                                [first, corner],
                                [corner, first],
                            ]),
                        },
                    ]),
                    terminal_control:
                        crate::families::zero_entity::records::ZeroEntityFaceControl::Control05,
                }),
                supports: vec![support_with_parameters(
                    4,
                    30,
                    [first, corner],
                    Some([1.0, 0.0]),
                )],
            },
        ];
        let support_curve_ids = HashMap::from([(4, curve_id.clone())]);
        let mut annotations = AnnotationBuilder::new();

        let counts = crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            transfer_closed_wire_loops(
                &mut admission,
                &mut ir,
                &mut annotations,
                &support_runs,
                &support_curve_ids,
                None,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("valid exactness fields");

        assert_eq!(counts.bodies, 1);
        assert_eq!(counts.loops, 1);
        assert_eq!(counts.edges, 2);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
        assert_eq!(
            ir.geometry.edges[1]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
        assert_eq!(
            ir.geometry.edges[0].curve().cloned(),
            Some(curve_id.clone())
        );
        let derived_curve_id = CurveId::mint("catia:zero-entity:wire-curve#1-2-3-1".to_string())
            .expect("identity grammar");
        assert_eq!(
            ir.geometry.edges[1].curve().cloned(),
            Some(derived_curve_id.clone())
        );
        let source_definition = ir
            .geometry
            .procedural_curves
            .iter()
            .find(|construction| construction.id == construction_id)
            .expect("source construction")
            .definition()
            .clone();
        assert_ne!(source_definition, definition);
        let derived_construction = match &ir
            .geometry
            .curves
            .iter()
            .find(|curve| curve.id == derived_curve_id)
            .expect("derived curve")
            .geometry
        {
            CurveGeometry::Procedural { construction, .. } => construction.clone(),
            CurveGeometry::Solved(_) => panic!("derived curve remains procedural"),
        };
        assert_ne!(derived_construction, construction_id);
        assert_eq!(
            ir.geometry
                .procedural_curves
                .iter()
                .find(|construction| construction.id == derived_construction)
                .expect("derived construction")
                .definition(),
            &definition
        );
        assert!(crate::assemble::neutral_model_is_admissible(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &mut ir,
            &[]
        )
        .expect("check that the neutral model is admissible"));
    }

    #[test]
    fn incomplete_face_local_loop_is_not_emitted_as_wire() {
        let first = Point3::new(0.0, 0.0, 0.0);
        let second = Point3::new(1.0, 0.0, 0.0);
        let support_runs = vec![
            crate::families::zero_entity::records::ZeroEntitySupportRun {
                carrier_pos: 0,
                carrier_record_ordinal: 1,
                face: Some(crate::families::zero_entity::records::ZeroEntityFace {
                    pos: 10,
                    record_ordinal: 2,
                    tag: [0x5f, 0x0c],
                    allocations: vec![9, 8],
                    loops: Some(vec![
                        crate::families::zero_entity::records::ZeroEntityLoop {
                            pos: 20,
                            record_ordinal: 3,
                            tag: [0x62, 0x14],
                            members: ZeroEntityLoopMembers::try_new(
                                8,
                                1,
                                NonZeroUsize::new(1).expect("nonzero loop member count"),
                            )
                            .expect("admitted loop member run"),
                            edge_stride_distances: vec![1],
                            support_record_ordinals: vec![4],
                            loop_class: ZeroEntityLoopClass::Outer41,
                            forward_senses: vec![true],
                            oriented_model_endpoints: finite_pairs(vec![[first, second]]),
                        },
                    ]),
                    terminal_control:
                        crate::families::zero_entity::records::ZeroEntityFaceControl::Control05,
                }),
                supports: vec![support(4, 30, [first, second])],
            },
        ];
        let mut ir = CadIr::empty();
        let mut annotations = AnnotationBuilder::new();

        let counts = crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            transfer_closed_wire_loops(
                &mut admission,
                &mut ir,
                &mut annotations,
                &support_runs,
                &HashMap::new(),
                None,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("valid exactness fields");

        assert_eq!(counts, WireTransferCounts::default());
        assert!(ir.geometry.bodies.is_empty());
    }

    #[test]
    fn zero_entity_coverage_counts_transferred_support_curves() {
        let build = |_: &cadmpeg_core::decode::DecodeContext<'_>| {
            super::zero_entity_coverage(1, 1, WireTransferCounts::default(), None)
        };
        let service = crate::test_support::with_service_context(build);
        assert_eq!(
            service.get(crate::coverage::TRANSFERRED_ZERO_ENTITY_SUPPORT_CURVE_COUNT.as_str()),
            Some(&1)
        );
    }

    #[test]
    fn closed_wire_loop_yields_one_member() {
        let point = Point3::new(0.0, 0.0, 0.0);
        let run = crate::families::zero_entity::records::ZeroEntitySupportRun {
            carrier_pos: 0,
            carrier_record_ordinal: 1,
            face: None,
            supports: vec![support(7, 10, [point, point])],
        };
        let loop_record = crate::families::zero_entity::records::ZeroEntityLoop {
            pos: 20,
            record_ordinal: 2,
            tag: [0x62, 0x14],
            members: ZeroEntityLoopMembers::try_new(2, 1, NonZeroUsize::MIN)
                .expect("one loop member"),
            edge_stride_distances: vec![1],
            support_record_ordinals: vec![7],
            loop_class: ZeroEntityLoopClass::Outer41,
            forward_senses: vec![true],
            oriented_model_endpoints: finite_pairs(vec![[point, point]]),
        };
        let curve_ids = HashMap::from([(
            7,
            CurveId::mint("catia:test:wire#0".to_string()).expect("identity grammar"),
        )]);
        let service = { closed_wire_loop_members(&run, &loop_record, &curve_ids) };
        assert_eq!(service.expect("closed wire").len(), 1);
    }

    #[test]
    fn wire_nurbs_geometry_clone_equals_the_original() {
        let nurbs = NurbsCurve::from_lanes(
            1,
            vec![0.0, 0.0, 1.0, 1.0],
            vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
            None,
            false,
        )
        .expect("valid linear NURBS");
        let geometry = CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs));
        let service = { geometry.clone() };
        assert_eq!(service, geometry);
    }
}
