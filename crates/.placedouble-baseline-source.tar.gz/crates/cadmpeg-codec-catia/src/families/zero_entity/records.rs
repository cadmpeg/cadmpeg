// SPDX-License-Identifier: Apache-2.0
//!
//! Decodes analytic (plane, cylinder, cone, torus) and inline non-rational
//! NURBS surface carriers from a zero-entity record stream.

/// Zero-entity `a9 03` stream surface decoders.
use cadmpeg_core::decode::index_from_u32;
use cadmpeg_core::decode::{DecodeContext, View};

use cadmpeg_core::CodecError;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve,
    pcurve::{PcurveGeometry, PcurveNurbs},
    CurveGeometry, ProceduralCurveDefinition, SolvedCurveGeometry, SolvedSurfaceGeometry,
    SurfaceGeometry,
};
use cadmpeg_ir::math::{Point2, Point3};
use cadmpeg_ir::scalar::{FiniteReal, NonZeroReal, PositiveReal};
use cadmpeg_ir::units::FinitePoint2;
use std::collections::{HashMap, HashSet};
use std::num::NonZeroUsize;
use std::ops::Range;

use crate::analytic::signed_reference_frame;
use crate::layout::a9_03_frame as a9_03;
use crate::layout::zero_entity_edge_stride_5e1a as edge_5e1a;
use crate::layout::zero_entity_pcurve_2171 as pcurve_2171;
use crate::layout::zero_entity_vertex_owner_5d06 as vertex_5d06;
use crate::wire::bytes::{f64_le, f64_point, f64_vector};

/// A directly decoded analytic carrier in the zero-entity `a9 03` stream.
#[derive(Debug, Clone)]
pub(in crate::families::zero_entity) struct ZeroEntitySurface {
    /// Offset of the framed record in the file.
    pub(super) pos: usize,
    /// The decoded surface carrier.
    pub(super) geometry: SurfaceGeometry,
}

/// One face-local support occurrence owned by a zero-entity surface carrier.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ZeroEntitySupportOccurrence {
    /// Offset of the framed `21xx` record.
    pub(crate) pos: usize,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    pub(crate) tag: [u8; 2],
    /// Face-local support slot stored by the framed token at record offset 12.
    pub(crate) face_local_slot: u32,
    /// Stored UV endpoints when this support family carries them inline.
    pub(crate) uv_endpoints: Option<[[FiniteReal; 2]; 2]>,
    /// Complete parameter-space curve carried by the support record.
    pub(crate) pcurve: Option<PcurveGeometry>,
    /// Exact model-space carrier derived from the pcurve and owning surface.
    pub(crate) model_curve: Option<CurveGeometry>,
    /// Exact procedural model-space carrier derived from the pcurve and owning surface.
    pub(crate) model_curve_construction: Option<ProceduralCurveDefinition>,
    /// Model-carrier parameters at the two stored UV endpoints.
    pub(crate) model_parameters: Option<[FiniteReal; 2]>,
    /// Surface point at the midpoint of the bounded pcurve parameter interval.
    pub(crate) model_midpoint: Option<FinitePoint3>,
    /// UV endpoints lifted through the owning surface carrier.
    pub(crate) model_endpoints: Option<[FinitePoint3; 2]>,
}

/// One surface carrier and its maximal following `21xx` support run.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ZeroEntitySupportRun {
    /// Offset of the owning surface-carrier record.
    pub(crate) carrier_pos: usize,
    /// One-based global record ordinal of the owning surface carrier.
    pub(crate) carrier_record_ordinal: u32,
    /// Positionally aligned face record when the complete rosters agree.
    pub(crate) face: Option<ZeroEntityFace>,
    /// Face-local support occurrences in storage order.
    pub(crate) supports: Vec<ZeroEntitySupportOccurrence>,
}

/// Terminal control byte following a zero-entity face allocation lane.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ZeroEntityFaceControl {
    /// Negative face-to-surface orientation, stored as `0x03`.
    Control03,
    /// Positive face-to-surface orientation, stored as `0x05`.
    Control05,
}

impl ZeroEntityFaceControl {
    fn from_byte(value: u8) -> Option<Self> {
        match value {
            0x03 => Some(Self::Control03),
            0x05 => Some(Self::Control05),
            _ => None,
        }
    }

    pub(crate) fn as_byte(self) -> u8 {
        match self {
            Self::Control03 => 0x03,
            Self::Control05 => 0x05,
        }
    }
}

/// One counted zero-entity `5fxx` face record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ZeroEntityFace {
    /// Offset of the framed face record.
    pub(crate) pos: usize,
    /// One-based global record ordinal.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    pub(crate) tag: [u8; 2],
    /// Counted allocation values in storage order.
    pub(crate) allocations: Vec<u32>,
    /// Positionally aligned loop records when the complete flattened roster agrees.
    pub(crate) loops: Option<Vec<ZeroEntityLoop>>,
    /// Terminal control byte following the allocation lane.
    pub(crate) terminal_control: ZeroEntityFaceControl,
}

#[cfg(test)]
impl ZeroEntityFace {
    pub(crate) fn loop_terminals(&self) -> Vec<u32> {
        let Some(first) = self.allocations.first().copied() else {
            return Vec::new();
        };
        self.allocations[1..]
            .iter()
            .filter_map(|allocation| first.checked_sub(*allocation))
            .collect()
    }
}

/// A nonempty descending run of logical loop members below its terminal.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityLoopMembers {
    terminal_id: u32,
    gap: u32,
    member_count: NonZeroUsize,
}

impl ZeroEntityLoopMembers {
    /// Admit a nonempty run with a positive gap and no identifier underflow.
    pub(super) fn try_new(terminal_id: u32, gap: u32, member_count: NonZeroUsize) -> Option<Self> {
        if gap == 0 {
            return None;
        }
        terminal_id
            .checked_sub(gap)?
            .checked_sub(u32::try_from(member_count.get() - 1).ok()?)?;
        Some(Self {
            terminal_id,
            gap,
            member_count,
        })
    }

    /// Terminal even-lane logical identifier.
    pub(crate) const fn terminal_id(&self) -> u32 {
        self.terminal_id
    }

    /// Difference between the terminal and first member identifiers.
    pub(crate) const fn gap(&self) -> u32 {
        self.gap
    }

    /// Nonterminal identifiers in source order.
    pub(crate) fn member_ids(&self) -> impl Iterator<Item = u32> + '_ {
        std::iter::successors(Some(self.terminal_id - self.gap), |id| id.checked_sub(1))
            .take(self.member_count.get())
    }

    /// Face-local support slots in member order.
    fn support_slots(&self) -> impl Iterator<Item = u32> + '_ {
        (self.gap..=self.terminal_id).take(self.member_count.get())
    }
}

/// Admitted zero-entity loop classes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub(crate) enum ZeroEntityLoopClass {
    /// Outer loop with forward face sense.
    Outer41 = 0x41,
    /// Inner bound loop.
    Bound50 = 0x50,
    /// Outer loop with reversed face sense.
    ReversedC1 = 0xc1,
}

impl ZeroEntityLoopClass {
    /// Admit a declared loop-class byte.
    const fn from_byte(byte: u8) -> Option<Self> {
        match byte {
            0x41 => Some(Self::Outer41),
            0x50 => Some(Self::Bound50),
            0xc1 => Some(Self::ReversedC1),
            _ => None,
        }
    }

    /// Native loop-class byte.
    pub(crate) const fn as_byte(self) -> u8 {
        match self {
            Self::Outer41 => 0x41,
            Self::Bound50 => 0x50,
            Self::ReversedC1 => 0xc1,
        }
    }
}

/// One counted zero-entity `62xx` loop record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ZeroEntityLoop {
    /// Offset of the framed loop record.
    pub(crate) pos: usize,
    /// One-based global record ordinal.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    pub(crate) tag: [u8; 2],
    /// Nonterminal even-lane arithmetic run.
    pub(crate) members: ZeroEntityLoopMembers,
    /// Backward distances from the loop to physical-edge stride records.
    pub(crate) edge_stride_distances: Vec<u32>,
    /// Face-local support record ordinals selected by the logical members.
    pub(crate) support_record_ordinals: Vec<u32>,
    /// Stored loop-class byte.
    pub(crate) loop_class: ZeroEntityLoopClass,
    /// Absolute coedge senses in member order; `true` is forward.
    pub(crate) forward_senses: Vec<bool>,
    /// Complete sense-oriented model-space endpoint pairs in member order.
    pub(crate) oriented_model_endpoints: Vec<[FinitePoint3; 2]>,
}

/// One `5e1a` allocation tuple.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityEdgeStride {
    /// Offset of the framed record.
    pub(crate) pos: usize,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Five allocation values following the fixed tagged-one prefix.
    pub(crate) allocations: [u32; 5],
}

/// One positional `0638` oriented use.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityOrientedUse {
    /// Offset of the framed record.
    pub(crate) pos: usize,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
}

/// Position within an oriented-use pair.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ZeroEntityUseSlot {
    /// First use in source order.
    First,
    /// Second use in source order.
    Second,
}

impl ZeroEntityUseSlot {
    /// One-based positional side number.
    pub(crate) const fn side(self) -> u32 {
        match self {
            Self::First => 1,
            Self::Second => 2,
        }
    }
}

/// One `2569` header and its two immediately following positional uses.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityOrientedUsePair {
    /// Offset of the `2569` header.
    pub(crate) header_pos: usize,
    /// One-based global record ordinal of the `2569` header.
    pub(crate) header_record_ordinal: u32,
    base_columns: [u32; 2],
    /// Side-one then side-two oriented uses.
    pub(crate) uses: [ZeroEntityOrientedUse; 2],
}

impl ZeroEntityOrientedUsePair {
    /// Stored base columns.
    pub(crate) const fn base_columns(&self) -> [u32; 2] {
        self.base_columns
    }

    /// Allocation columns for the selected use slot.
    pub(crate) const fn allocations(&self, slot: ZeroEntityUseSlot) -> [u32; 2] {
        let side = slot.side();
        [self.base_columns[0] + side, self.base_columns[1] + side]
    }
}

/// Counted allocation vector of a zero-entity vertex-incidence record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum ZeroEntityVertexAllocations {
    /// Tag `050b`: two allocations.
    Two([u32; 2]),
    /// Tag `0510`: three allocations.
    Three([u32; 3]),
    /// Tag `0515`: four allocations.
    Four([u32; 4]),
}

impl ZeroEntityVertexAllocations {
    /// Complete two-byte record tag for this allocation arity.
    fn tag(&self) -> [u8; 2] {
        match self {
            Self::Two(_) => [0x05, 0x0b],
            Self::Three(_) => [0x05, 0x10],
            Self::Four(_) => [0x05, 0x15],
        }
    }

    pub(crate) fn as_slice(&self) -> &[u32] {
        match self {
            Self::Two(allocations) => allocations,
            Self::Three(allocations) => allocations,
            Self::Four(allocations) => allocations,
        }
    }
}

/// One counted zero-entity vertex-incidence record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityVertexIncidence {
    /// Offset of the framed `05xx` record.
    pub(crate) pos: usize,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Stored allocation values whose length selects the record tag.
    pub(crate) allocations: ZeroEntityVertexAllocations,
}

impl ZeroEntityVertexIncidence {
    /// Complete two-byte record tag selected by allocation arity.
    pub(crate) fn tag(&self) -> [u8; 2] {
        self.allocations.tag()
    }
}

/// The terminal zero-entity body hierarchy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityOwnershipRoot {
    /// Offset of the counted `6142` face-roster record.
    pub(crate) face_roster_pos: usize,
    /// One-based global record ordinal of the face-roster record.
    pub(crate) face_roster_record_ordinal: u32,
    /// Descending one-based face-allocation slots.
    pub(crate) face_slots: Vec<u32>,
    /// Offset of the immediately following `6006` shell root.
    pub(crate) shell_pos: usize,
    /// Offset of the immediately following `6508` body root.
    pub(crate) body_pos: usize,
}

impl ZeroEntityOwnershipRoot {
    /// One-based ordinal of the immediately following `6006` shell root.
    pub(crate) fn shell_record_ordinal(&self) -> Result<u32, CodecError> {
        self.face_roster_record_ordinal
            .checked_add(1)
            .ok_or_else(|| CodecError::malformed("CATIA zero-entity shell ordinal overflows"))
    }

    /// One-based ordinal of the immediately following `6508` body root.
    pub(crate) fn body_record_ordinal(&self) -> Result<u32, CodecError> {
        self.face_roster_record_ordinal
            .checked_add(2)
            .ok_or_else(|| CodecError::malformed("CATIA zero-entity body ordinal overflows"))
    }
}

/// One framed record in the zero-entity global identity namespace.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ZeroEntityRecordIdentity {
    /// Offset of the framed record.
    pub(crate) pos: usize,
    /// Exclusive logical end, including any inline continuation.
    pub(crate) end: usize,
    /// Complete two-byte record tag.
    pub(crate) tag: [u8; 2],
    /// One-based global record ordinal.
    pub(crate) record_ordinal: u32,
}

#[derive(Debug, Clone, Copy)]
struct ZeroEntityRecord {
    pos: usize,
    end: usize,
    tag: [u8; 2],
    ordinal: u32,
}

struct ZeroEntityNurbsLayout {
    u_distinct: Vec<FiniteReal>,
    u_mults: Vec<u32>,
    u_degree: u32,
    u_count: u32,
    v_distinct: Vec<FiniteReal>,
    v_mults: Vec<u32>,
    v_degree: u32,
    v_count: u32,
    grid: usize,
    end: usize,
}

struct ZeroEntityNurbsKnotLane {
    distinct: Vec<FiniteReal>,
    multiplicities: Vec<u32>,
    degree: u32,
    control_count: u32,
}

fn zero_entity_fixed_logical_length(tag: [u8; 2]) -> Option<usize> {
    match tag {
        [0x21, 0x45] => Some(337),
        [0x21, 0x72] => Some(382),
        [0x21, 0x9f] => Some(427),
        _ => None,
    }
}

fn zero_entity_2118_logical_end(data: &[u8], record: usize) -> Option<usize> {
    let end = record.checked_add(292)?;
    if end > data.len() || data.get(record.checked_add(12)?) != Some(&0x10) {
        return None;
    }
    let knots = [67usize, 75, 83, 91, 99].map(|offset| f64_le(data, record.checked_add(offset)?));
    let [Some(first), Some(second), Some(third), Some(fourth), Some(fifth)] = knots else {
        return None;
    };
    let knots = [first, second, third, fourth, fifth];
    if !knots.windows(2).all(|pair| pair[0] < pair[1]) {
        return None;
    }
    for (index, multiplicity) in [4u32, 2, 2, 2, 4].into_iter().enumerate() {
        if tagged_u32(
            data,
            record.checked_add(107usize.checked_add(index.checked_mul(5)?)?)?,
        )? != multiplicity
        {
            return None;
        }
    }
    for index in 0usize..10 {
        let pole = record.checked_add(132usize.checked_add(index.checked_mul(16)?)?)?;
        if f64_le(data, pole).is_none() || f64_le(data, pole.checked_add(8)?).is_none() {
            return None;
        }
    }
    Some(end)
}

fn zero_entity_face_roster_logical_end(data: &[u8], record: usize) -> Option<usize> {
    if tagged_u32(data, record.checked_add(7)?)? != 1 {
        return None;
    }
    let count = data.get(record.checked_add(12)?)?.checked_sub(0x80)?;
    if count == 0 {
        return None;
    }
    let count = usize::from(count);
    let values = record.checked_add(13)?;
    for index in 0..count {
        let value = tagged_u32(data, values.checked_add(index.checked_mul(5)?)?)?;
        if value != u32::try_from(count.checked_sub(index)?).ok()? {
            return None;
        }
    }
    let trailer = values.checked_add(count.checked_mul(5)?)?;
    let end = trailer.checked_add(11)?;
    (data.get(trailer..end)? == [0x00, 0x01, 0xc0, 0xff, 0xff, 0x3f, 0, 0, 0, 0, 0x03])
        .then_some(end)
}

fn zero_entity_records_in_range(data: &[u8], range: Range<usize>) -> Vec<ZeroEntityRecord> {
    if data.get(range.clone()).is_none() {
        return Vec::new();
    }
    let mut records = Vec::new();
    let mut position = range.start;
    while position + a9_03::LEN <= range.end {
        if data[position + a9_03::FAMILY..position + a9_03::TAG_HI] != [0xa9, 0x03] {
            position += 1;
            continue;
        }
        let tag = [
            data[position + a9_03::TAG_HI],
            data[position + a9_03::TAG_LO_LENGTH_DRIVER],
        ];
        let nominal_end =
            position.checked_add(usize::from(data[position + a9_03::TAG_LO_LENGTH_DRIVER]) + 12);
        let Some(nominal_end) = nominal_end else {
            break;
        };
        let end = if tag == [0x21, 0x18] {
            zero_entity_2118_logical_end(data, position).unwrap_or(nominal_end)
        } else if tag == [0x61, 0x42] {
            let Some(end) = zero_entity_face_roster_logical_end(data, position) else {
                break;
            };
            end
        } else if matches!(tag, [0x34, 0xc8 | 0x5e]) {
            let Some(end) = zero_entity_nurbs_logical_end(data, position) else {
                break;
            };
            end
        } else if let Some(length) = zero_entity_fixed_logical_length(tag) {
            let Some(end) = position.checked_add(length) else {
                break;
            };
            end
        } else {
            nominal_end
        };
        if end > range.end {
            break;
        }
        let Some(one_based_ordinal) = records.len().checked_add(1) else {
            break;
        };
        let Ok(ordinal) = u32::try_from(one_based_ordinal) else {
            break;
        };
        records.push(ZeroEntityRecord {
            pos: position,
            end,
            tag,
            ordinal,
        });
        position = end;
    }
    records
}

#[cfg(test)]
fn zero_entity_records(data: &[u8]) -> Vec<ZeroEntityRecord> {
    zero_entity_records_in_range(data, 0..data.len())
}

fn zero_entity_nurbs_logical_end(data: &[u8], record: usize) -> Option<usize> {
    zero_entity_nurbs_layout(data, record).map(|layout| layout.end)
}

fn zero_entity_nurbs_layout(data: &[u8], record: usize) -> Option<ZeroEntityNurbsLayout> {
    let tag = [
        *data.get(record.checked_add(a9_03::TAG_HI)?)?,
        *data.get(record.checked_add(a9_03::TAG_LO_LENGTH_DRIVER)?)?,
    ];
    let (grid_offset, expected_u_count, expected_v_count) = zero_entity_nurbs_shape(tag)?;
    let knot_start = record.checked_add(23)?;
    let grid = record.checked_add(grid_offset)?;
    let pole_count = crate::nurbs_surface_control_count(expected_u_count, expected_v_count)?;
    let pole_bytes = pole_count.checked_mul(24)?;
    let end = grid.checked_add(pole_bytes)?;
    data.get(grid..end)?;

    // The carrier has no count word for either distinct-knot lane. Its fixed
    // pole boundary makes the two lanes a bounded parse: U knots, two tagged
    // V-dimension words, one V marker, V knots, V multiplicities, and the
    // three-byte pole marker. Enumerate the possible U lane widths and retain
    // exactly one structural interpretation. A value range or a first
    // terminator would turn ordinary model parameters into framing bytes.
    let pole_marker_start = grid.checked_sub(3)?;
    let available = pole_marker_start.checked_sub(knot_start)?;
    let minimum_after_u = 2usize.checked_mul(5)?.checked_add(1)?.checked_add(2 * 13)?;
    let max_u_distinct = available.checked_sub(minimum_after_u)?.checked_div(13)?;
    if max_u_distinct < 2 {
        return None;
    }
    let mut candidate = None;
    for u_distinct_count in 2..=max_u_distinct {
        let u_after = knot_start.checked_add(u_distinct_count.checked_mul(13)?)?;
        let Some(u_lane) =
            zero_entity_nurbs_knot_lane(data, knot_start, u_distinct_count, expected_u_count)
        else {
            continue;
        };
        let Some((_, after_dimensions)) = u32_tokens(data, u_after, 2) else {
            continue;
        };
        let v_start = after_dimensions.checked_add(1)?;
        if v_start > pole_marker_start {
            continue;
        }
        let v_bytes = pole_marker_start.checked_sub(v_start)?;
        if v_bytes % 13 != 0 {
            continue;
        }
        let v_distinct_count = v_bytes / 13;
        if v_distinct_count < 2 {
            continue;
        }
        let Some(v_lane) =
            zero_entity_nurbs_knot_lane(data, v_start, v_distinct_count, expected_v_count)
        else {
            continue;
        };
        if candidate.is_some() {
            return None;
        }
        candidate = Some((u_lane, v_lane));
    }
    let (u_lane, v_lane) = candidate?;
    Some(ZeroEntityNurbsLayout {
        u_distinct: u_lane.distinct,
        u_mults: u_lane.multiplicities,
        u_degree: u_lane.degree,
        u_count: u_lane.control_count,
        v_distinct: v_lane.distinct,
        v_mults: v_lane.multiplicities,
        v_degree: v_lane.degree,
        v_count: v_lane.control_count,
        grid,
        end,
    })
}

fn zero_entity_nurbs_knot_lane(
    data: &[u8],
    start: usize,
    distinct_count: usize,
    expected_control_count: usize,
) -> Option<ZeroEntityNurbsKnotLane> {
    let distinct_end = start.checked_add(distinct_count.checked_mul(8)?)?;
    let mut distinct = Vec::new();
    for index in 0..distinct_count {
        let value = f64_le(data, start.checked_add(index.checked_mul(8)?)?)?;
        if distinct.last().is_some_and(|last| value <= *last) {
            return None;
        }
        distinct.push(value);
    }
    let (mults, end) = u32_tokens(data, distinct_end, distinct_count)?;
    let degree = mults.first().copied()?.checked_sub(1)?;
    let control_count = mults
        .iter()
        .try_fold(0u32, |sum, value| sum.checked_add(*value))?
        .checked_sub(degree + 1)?;
    if !(1..=9).contains(&degree)
        || usize::try_from(control_count).ok()? != expected_control_count
        || end != distinct_end.checked_add(distinct_count.checked_mul(5)?)?
    {
        return None;
    }
    Some(ZeroEntityNurbsKnotLane {
        distinct,
        multiplicities: mults,
        degree,
        control_count,
    })
}

/// Inventory every complete framed record in the one-based global namespace.
pub(crate) fn zero_entity_record_inventory(data: &[u8]) -> Vec<ZeroEntityRecordIdentity> {
    zero_entity_record_inventory_in_range(data, 0..data.len())
}

/// Inventory complete framed records whose extents stay inside `range`.
pub(crate) fn zero_entity_record_inventory_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Vec<ZeroEntityRecordIdentity> {
    let records = zero_entity_records_in_range(data, range);
    let mut output = Vec::new();

    for record in records {
        output.push(ZeroEntityRecordIdentity {
            pos: record.pos,
            end: record.end,
            tag: record.tag,
            record_ordinal: record.ordinal,
        });
    }
    output
}

/// Decode the terminal face-roster, shell, and body ownership roots.
#[cfg(test)]
#[must_use]
fn zero_entity_ownership_root(data: &[u8]) -> Option<ZeroEntityOwnershipRoot> {
    zero_entity_ownership_root_in_range(data, 0..data.len())
}

/// Decode every complete ownership hierarchy in the zero-entity stream.
#[cfg(test)]
#[must_use]
fn zero_entity_ownership_roots(data: &[u8]) -> Vec<ZeroEntityOwnershipRoot> {
    zero_entity_ownership_roots_in_range(data, 0..data.len())
}

/// Decode ownership roots whose records stay inside `range`.
pub(super) fn zero_entity_ownership_root_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Option<ZeroEntityOwnershipRoot> {
    let roots = zero_entity_ownership_roots_in_range(data, range);
    (roots.len() == 1)
        .then(|| roots.into_iter().next())
        .flatten()
}

/// Decode every ownership root whose records stay inside `range`.
pub(crate) fn zero_entity_ownership_roots_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Vec<ZeroEntityOwnershipRoot> {
    let records = zero_entity_records_in_range(data, range);
    let mut roots = Vec::new();
    for window in records.windows(3) {
        let candidate = (|| {
            let [face_roster, shell, body] = window else {
                return None;
            };
            let body_trailer = body.pos.checked_add(18)?;
            if face_roster.tag != [0x61, 0x42]
                || shell.tag != [0x60, 0x06]
                || body.tag != [0x65, 0x08]
                || face_roster.end != shell.pos
                || shell.end != body.pos
                || tagged_u32(data, shell.pos.checked_add(7)?)? != 1
                || data.get(shell.pos.checked_add(12)?) != Some(&0x81)
                || tagged_u32(data, shell.pos.checked_add(13)?)? != 1
                || tagged_u32(data, body.pos.checked_add(7)?)? != 1
                || data.get(body.pos.checked_add(12)?) != Some(&0x81)
                || tagged_u32(data, body.pos.checked_add(13)?)? != 1
                || data.get(body_trailer..body.end)? != [0x05, 0x0d]
            {
                return None;
            }
            let count = usize::from(
                data.get(face_roster.pos.checked_add(12)?)?
                    .checked_sub(0x80)?,
            );
            Some((*face_roster, *shell, *body, count))
        })();
        let Some((face_roster, shell, body, count)) = candidate else {
            continue;
        };
        let mut face_slots = Vec::new();

        let mut valid = true;
        for index in 0..count {
            let Some(offset) = index
                .checked_mul(5)
                .and_then(|at| face_roster.pos.checked_add(13 + at))
            else {
                valid = false;
                break;
            };
            let Some(value) = tagged_u32(data, offset) else {
                valid = false;
                break;
            };
            face_slots.push(value);
        }
        if !valid {
            continue;
        }
        roots.push(ZeroEntityOwnershipRoot {
            face_roster_pos: face_roster.pos,
            face_roster_record_ordinal: face_roster.ordinal,
            face_slots,
            shell_pos: shell.pos,
            body_pos: body.pos,
        });
    }
    roots
}

/// Decode analytic surface carriers in a zero-entity `a9 03` stream.  The
/// record's second tag byte is also its length code (`length = tag + 12`), so
/// the decoder walks framed records.
#[cfg(test)]
fn zero_entity_surfaces(data: &[u8]) -> Vec<ZeroEntitySurface> {
    zero_entity_surfaces_in_range(data, 0..data.len(), &mut crate::nurbs::LaneRefusals::new())
}

/// Decode surface carriers whose records stay inside `range`.
pub(super) fn zero_entity_surfaces_in_range(
    data: &[u8],
    range: Range<usize>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Vec<ZeroEntitySurface> {
    let records = zero_entity_records_in_range(data, range);
    let mut surfaces = Vec::new();
    for record in records {
        if let Some(geometry) = zero_entity_surface_at(data, record.pos, refusal) {
            surfaces.push(ZeroEntitySurface {
                pos: record.pos,
                geometry,
            });
        }
    }
    surfaces
}

/// Decode surface-carrier ownership and exact face-local support occurrences.
#[cfg(test)]
#[must_use]
fn zero_entity_support_runs(data: &[u8]) -> Vec<ZeroEntitySupportRun> {
    crate::test_support::with_service_context(|ctx| {
        zero_entity_support_runs_in_range(
            ctx,
            data,
            0..data.len(),
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("compute the zero entity support runs in range")
}

/// Decode support runs whose complete record population stays inside `range`.
pub(crate) fn zero_entity_support_runs_in_range(
    ctx: &DecodeContext<'_>,
    data: &[u8],
    range: Range<usize>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<ZeroEntitySupportRun>, CodecError> {
    let records = zero_entity_records_in_range(data, range);
    let mut runs = Vec::new();
    let mut index = 0usize;
    while index + 1 < records.len() {
        let carrier_record = records[index];
        let Some(carrier_geometry) = zero_entity_surface_at(data, carrier_record.pos, refusal)
        else {
            index += 1;
            continue;
        };
        if records[index + 1].tag[0] != 0x21 {
            index += 1;
            continue;
        }
        let mut supports = Vec::new();
        let mut next = index + 1;
        while records
            .get(next)
            .is_some_and(|record| record.tag[0] == 0x21)
        {
            let record = records[next];
            if let Some(support) = zero_entity_support_occurrence(data, record, refusal) {
                let mut support = support;
                let model_curve = if let (Some(pcurve), Some(uv_endpoints)) =
                    (support.pcurve.as_ref(), support.uv_endpoints)
                {
                    zero_entity_model_curve(
                        ctx,
                        &carrier_geometry,
                        pcurve,
                        uv_endpoints.map(|uv| uv.map(FiniteReal::get)),
                        &format_args!("zero-entity support record at byte {}", record.pos),
                        refusal,
                    )?
                } else {
                    None
                };
                if let Some((curve, parameters)) = model_curve {
                    support.model_curve = Some(curve);
                    support.model_parameters = Some(parameters);
                }
                support.model_curve_construction = support.pcurve.as_ref().and_then(|pcurve| {
                    zero_entity_model_curve_construction(&carrier_geometry, pcurve)
                });
                if support.model_curve_construction.is_some() {
                    support.model_parameters = support
                        .uv_endpoints
                        .map(|endpoints| endpoints.map(|uv| uv[0]));
                }
                let midpoint_input = support.pcurve.as_ref().and_then(|pcurve| {
                    let PcurveGeometry::Nurbs { nurbs } = pcurve else {
                        return None;
                    };
                    let start = *nurbs.knots().get(usize::try_from(nurbs.degree()).ok()?)?;
                    let end = *nurbs.knots().get(nurbs.pole_rows().count())?;
                    if start >= end {
                        return None;
                    }
                    Some((pcurve, start.midpoint(end)))
                });
                if let Some((pcurve, parameter)) = midpoint_input {
                    if let Some(uv) = cadmpeg_ir::eval::finite_or_refusal(
                        cadmpeg_ir::eval::decode::outer_refusal(
                            cadmpeg_ir::eval::decode::pcurve_uv(ctx, pcurve, parameter),
                        )?,
                    )? {
                        support.model_midpoint =
                            zero_entity_surface_point(ctx, &carrier_geometry, [uv.u, uv.v])?;
                    }
                }
                if let Some(endpoints) = support.uv_endpoints {
                    let [first, second] = endpoints.map(|uv| {
                        zero_entity_surface_point(ctx, &carrier_geometry, uv.map(FiniteReal::get))
                    });
                    support.model_endpoints =
                        first?.zip(second?).map(|(first, second)| [first, second]);
                }
                supports.push(support);
            } else {
                supports.clear();
                break;
            }
            next += 1;
        }
        if !supports.is_empty() {
            runs.push(ZeroEntitySupportRun {
                carrier_pos: carrier_record.pos,
                carrier_record_ordinal: carrier_record.ordinal,
                face: None,
                supports,
            });
        }
        index = next.max(index + 1);
    }
    let mut faces = zero_entity_faces_from_records(data, &records);
    let loops = zero_entity_loops_from_records(data, &records);
    let mut flattened_terminals = Vec::new();
    let mut face_terminals = Vec::new();

    for face in &faces {
        let mut terminals = Vec::new();
        if let Some(&first) = face.allocations.first() {
            for allocation in &face.allocations[1..] {
                if let Some(terminal) = first.checked_sub(*allocation) {
                    terminals.push(terminal);
                    flattened_terminals.push(terminal);
                }
            }
        }
        face_terminals.push(terminals);
    }
    let mut loop_terminals = Vec::new();

    for loop_record in &loops {
        loop_terminals.push(loop_record.members.terminal_id());
    }
    let mut loop_roster_is_valid = flattened_terminals == loop_terminals;
    if loop_roster_is_valid {
        let mut loop_index = 0;
        for (face, terminals) in faces.iter().zip(&face_terminals) {
            let loop_end = loop_index + terminals.len();
            let face_loops = &loops[loop_index..loop_end];
            loop_index = loop_end;
            if !face_loops.first().is_some_and(|outer| {
                matches!(
                    (face.terminal_control, outer.loop_class),
                    (
                        ZeroEntityFaceControl::Control05,
                        ZeroEntityLoopClass::Outer41
                    ) | (
                        ZeroEntityFaceControl::Control03,
                        ZeroEntityLoopClass::ReversedC1
                    )
                ) && face_loops[1..]
                    .iter()
                    .all(|inner| inner.loop_class == ZeroEntityLoopClass::Bound50)
            }) {
                loop_roster_is_valid = false;
                break;
            }
        }
    }
    if loop_roster_is_valid {
        let mut remaining_loops = loops.into_iter();
        for (face, terminals) in faces.iter_mut().zip(&face_terminals) {
            let mut face_loops = Vec::new();

            face_loops.extend(remaining_loops.by_ref().take(terminals.len()));
            face.loops = Some(face_loops);
        }
    }
    let face_population = records
        .iter()
        .filter(|record| record.tag[0] == 0x5f)
        .count();
    let surface_population = records
        .iter()
        .filter(|record| zero_entity_surface_carrier_tag(record.tag))
        .count();
    // Equal filtered lengths are not enough: independent drops can shift the
    // positional rosters. Bind only when every framed candidate survived.
    let rosters_are_complete = faces.len() == face_population
        && runs.len() == surface_population
        && faces.len() == runs.len();
    if rosters_are_complete {
        for (run, mut face) in runs.iter_mut().zip(faces) {
            bind_face_support_occurrences(&mut face, &run.supports);
            run.face = Some(face);
        }
    }
    Ok(runs)
}

fn bind_face_support_occurrences(
    face: &mut ZeroEntityFace,
    supports: &[ZeroEntitySupportOccurrence],
) {
    let Some(face_loops) = face.loops.as_mut() else {
        return;
    };
    let mut supports_by_slot = HashMap::<u32, Option<u32>>::new();
    for support in supports {
        if let Some(record) = supports_by_slot.get_mut(&support.face_local_slot) {
            *record = None;
        } else {
            supports_by_slot.insert(support.face_local_slot, Some(support.record_ordinal));
        }
    }
    let mut bindings = Vec::new();

    for loop_record in face_loops.iter() {
        let mut row = Vec::new();

        for slot in loop_record.members.support_slots() {
            let Some(ordinal) = supports_by_slot.get(&slot).copied().flatten() else {
                return;
            };
            row.push(ordinal);
        }
        bindings.push(row);
    }
    if bindings.iter().map(Vec::len).sum::<usize>() != supports.len() {
        return;
    }
    let mut bound = HashSet::new();
    for ordinal in bindings.iter().flatten().copied() {
        bound.insert(ordinal);
    }
    if bound.len() != supports.len() {
        return;
    }
    for (loop_record, support_record_ordinals) in face_loops.iter_mut().zip(bindings) {
        loop_record.support_record_ordinals = support_record_ordinals;
    }
    let mut supports_by_ordinal = HashMap::new();

    for support in supports {
        supports_by_ordinal.insert(support.record_ordinal, support);
    }
    for loop_record in face_loops {
        let mut endpoints = Vec::new();

        for ordinal in &loop_record.support_record_ordinals {
            endpoints.push(
                supports_by_ordinal
                    .get(ordinal)
                    .and_then(|support| support.model_endpoints),
            );
        }
        if let Some(oriented) =
            oriented_closed_model_endpoints(&endpoints, &loop_record.forward_senses)
        {
            loop_record.oriented_model_endpoints = oriented;
        }
    }
}

pub(crate) fn oriented_closed_model_endpoints(
    endpoints: &[Option<[FinitePoint3; 2]>],
    forward_senses: &[bool],
) -> Option<Vec<[FinitePoint3; 2]>> {
    const CLOSURE_TOLERANCE: f64 = 2e-3;

    if endpoints.is_empty() || endpoints.len() != forward_senses.len() {
        return None;
    }
    let mut oriented = Vec::new();

    let mut missing = None;
    for (index, (endpoints, forward)) in endpoints.iter().zip(forward_senses).enumerate() {
        let pair = endpoints.map(|[start, end]| if *forward { [start, end] } else { [end, start] });
        if pair.is_none() && missing.replace(index).is_some() {
            return None;
        }
        oriented.push(pair);
    }
    if let Some(index) = missing {
        if oriented.len() <= 1 {
            return None;
        }
        let previous = (index + oriented.len() - 1) % oriented.len();
        let next = (index + 1) % oriented.len();
        let (Some(previous), Some(next)) = (oriented[previous], oriented[next]) else {
            return None;
        };
        oriented[index] = Some([previous[1], next[0]]);
    }
    let mut complete = Vec::new();

    for pair in oriented {
        let pair = pair?;
        complete.push(pair);
    }
    complete
        .iter()
        .enumerate()
        .all(|(index, endpoints)| {
            endpoints[1].distance(complete[(index + 1) % complete.len()][0].get())
                <= CLOSURE_TOLERANCE
        })
        .then_some(complete)
}

fn zero_entity_faces_from_records(
    data: &[u8],
    records: &[ZeroEntityRecord],
) -> Vec<ZeroEntityFace> {
    let mut faces = Vec::new();
    for record in records {
        let face = (|| -> Option<ZeroEntityFace> {
            if record.tag[0] != 0x5f || tagged_u32(data, record.pos + 7) != Some(1) {
                return None;
            }
            let count = data
                .get(record.pos + 12)
                .and_then(|value| value.checked_sub(0x80))?;
            let count = usize::from(count);
            if count < 2 || record.pos.checked_add(14 + count * 5) != Some(record.end) {
                return None;
            }
            let mut allocations = Vec::new();

            for index in 0..count {
                let value = tagged_u32(data, record.pos + 13 + index * 5)?;
                allocations.push(value);
            }
            if allocations.contains(&0) {
                return None;
            }
            let first = allocations[0];
            let mut loop_terminals = Vec::new();

            for allocation in &allocations[1..] {
                let terminal = first.checked_sub(*allocation)?;
                loop_terminals.push(terminal);
            }
            if loop_terminals.contains(&0)
                || !loop_terminals[1..].windows(2).all(|pair| pair[0] < pair[1])
            {
                return None;
            }
            let terminal_control = data
                .get(record.end - 1)
                .and_then(|value| ZeroEntityFaceControl::from_byte(*value))?;
            Some(ZeroEntityFace {
                pos: record.pos,
                record_ordinal: record.ordinal,
                tag: record.tag,
                allocations,
                loops: None,
                terminal_control,
            })
        })();
        if let Some(face) = face {
            faces.push(face);
        }
    }
    faces
}

fn zero_entity_loops_from_records(
    data: &[u8],
    records: &[ZeroEntityRecord],
) -> Vec<ZeroEntityLoop> {
    let mut loops = Vec::new();
    for record in records {
        let loop_record = (|| -> Option<ZeroEntityLoop> {
            if record.tag[0] != 0x62 {
                return None;
            }
            let reference_count = data
                .get(record.pos + 12)
                .and_then(|value| value.checked_sub(0x80))?;
            let reference_count = usize::from(reference_count);
            if reference_count < 3 || reference_count % 2 == 0 {
                return None;
            }
            let edge_count = (reference_count - 1) / 2;
            let mut references = Vec::new();

            for index in 0..reference_count {
                let value = tagged_u32(data, record.pos + 13 + index * 5)?;
                references.push(value);
            }
            let mut edge_stride_distances = Vec::new();
            edge_stride_distances.extend(
                references[1..reference_count - 1]
                    .iter()
                    .step_by(2)
                    .copied(),
            );
            if edge_stride_distances.contains(&0) {
                return None;
            }
            let terminal_id = references[reference_count - 1];
            let gap = terminal_id.checked_sub(references[0])?;
            let member_count = NonZeroUsize::new(edge_count)?;
            let members = ZeroEntityLoopMembers::try_new(terminal_id, gap, member_count)?;
            if !members
                .member_ids()
                .eq(references[..reference_count - 1].iter().step_by(2).copied())
            {
                return None;
            }
            let trailer = record.pos.checked_add(13 + reference_count * 5)?;
            let loop_class = data
                .get(trailer + 1)
                .and_then(|value| ZeroEntityLoopClass::from_byte(*value))?;
            let Ok(edge_count_byte) = u8::try_from(edge_count) else {
                return None;
            };
            if data.get(trailer) != Some(&(0x80 + edge_count_byte)) {
                return None;
            }
            let packed_length = (edge_count * 3).div_ceil(8);
            if trailer.checked_add(3 + packed_length) != Some(record.end)
                || data.get(trailer + 2 + packed_length) != Some(&0x01)
            {
                return None;
            }
            let packed = data.get(trailer + 2..trailer + 2 + packed_length)?;
            let mut forward_senses = Vec::new();

            for index in 0..edge_count {
                let bit = index * 3;
                let code = (0..3).fold(0, |code, offset| {
                    code | (((packed[(bit + offset) / 8] >> ((bit + offset) % 8)) & 1) << offset)
                });
                match code {
                    2 => forward_senses.push(false),
                    7 => forward_senses.push(true),
                    _ => return None,
                }
            }
            Some(ZeroEntityLoop {
                pos: record.pos,
                record_ordinal: record.ordinal,
                tag: record.tag,
                members,
                edge_stride_distances,
                support_record_ordinals: Vec::new(),
                loop_class,
                forward_senses,
                oriented_model_endpoints: Vec::new(),
            })
        })();
        if let Some(loop_record) = loop_record {
            loops.push(loop_record);
        }
    }
    loops
}

fn zero_entity_support_occurrence(
    data: &[u8],
    record: ZeroEntityRecord,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<ZeroEntitySupportOccurrence> {
    if data.get(record.pos + 12) != Some(&0x10) {
        return None;
    }
    let face_local_slot = View::u32_le_at(data, record.pos + 13)?;
    if face_local_slot == 0 {
        return None;
    }
    let uv_offsets = match record.tag {
        [0x21, 0x18] => Some([132, 276]),
        [0x21, 0x45] => Some([145, 321]),
        [0x21, 0x71] => Some([pcurve_2171::POLES, pcurve_2171::POLES + 16]),
        [0x21, 0x72] => Some([158, 366]),
        [0x21, 0x91] => Some([93, 141]),
        [0x21, 0x99] => Some([93, 125]),
        [0x21, 0x9f] => Some([171, 411]),
        [0x21, 0xd6] => Some([106, 170]),
        [0x21, 0xe8] => Some([132, 228]),
        _ => None,
    };
    let uv_endpoints = if let Some(offsets) = uv_offsets {
        let mut values = [[FiniteReal::ZERO; 2]; 2];
        for (index, offset) in offsets.into_iter().enumerate() {
            let absolute = record.pos.checked_add(offset)?;
            if absolute.checked_add(16)? > record.end {
                return None;
            }
            values[index] = [
                f64_le(data, absolute)?,
                f64_le(data, absolute.checked_add(8)?)?,
            ];
        }
        Some(values)
    } else {
        None
    };
    let pcurve = zero_entity_support_pcurve(data, record, refusal);
    if matches!(
        record.tag,
        [
            0x21,
            0x18 | 0x45 | 0x71 | 0x72 | 0x91 | 0x99 | 0x9f | 0xd6 | 0xe8
        ]
    ) && pcurve.is_none()
    {
        return None;
    }
    Some(ZeroEntitySupportOccurrence {
        pos: record.pos,
        record_ordinal: record.ordinal,
        tag: record.tag,
        face_local_slot,
        uv_endpoints,
        pcurve,
        model_curve: None,
        model_curve_construction: None,
        model_parameters: None,
        model_midpoint: None,
        model_endpoints: None,
    })
}

fn zero_entity_support_pcurve(
    data: &[u8],
    record: ZeroEntityRecord,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<PcurveGeometry> {
    let (
        knot_offsets,
        multiplicity_start,
        expected_multiplicities,
        pole_start,
        control_count,
        weight_start,
        required_end,
    ) = match record.tag {
        [0x21, 0x18] => (
            &[67, 75, 83, 91, 99][..],
            107,
            &[4, 2, 2, 2, 4][..],
            132,
            10,
            None,
            292,
        ),
        [0x21, 0x45] => (
            &[67, 75, 83, 91, 99, 107][..],
            115,
            &[4, 2, 2, 2, 2, 4][..],
            145,
            12,
            None,
            337,
        ),
        [0x21, 0x71] => (
            &[pcurve_2171::KNOTS, pcurve_2171::KNOTS + 8][..],
            pcurve_2171::MULTIPLICITIES,
            &[2, 2][..],
            pcurve_2171::POLES,
            2,
            None,
            pcurve_2171::LEN,
        ),
        [0x21, 0x72] => (
            &[67, 75, 83, 91, 99, 107, 115][..],
            123,
            &[4, 2, 2, 2, 2, 2, 4][..],
            158,
            14,
            None,
            382,
        ),
        [0x21, 0x91] => (&[67, 75][..], 83, &[4, 4][..], 93, 4, None, 157),
        [0x21, 0x99] => (&[67, 75][..], 83, &[3, 3][..], 93, 3, Some(141), 165),
        [0x21, 0x9f] => (
            &[67, 75, 83, 91, 99, 107, 115, 123][..],
            131,
            &[4, 2, 2, 2, 2, 2, 2, 4][..],
            171,
            16,
            None,
            427,
        ),
        [0x21, 0xd6] => (&[67, 75, 83][..], 91, &[3, 2, 3][..], 106, 5, None, 186),
        [0x21, 0xe8] => (
            &[67, 75, 83, 91, 99][..],
            107,
            &[4, 1, 1, 1, 4][..],
            132,
            7,
            None,
            244,
        ),
        _ => return None,
    };
    if record.pos.checked_add(required_end)? > record.end {
        return None;
    }
    let mut distinct_knots = Vec::new();
    for offset in knot_offsets {
        distinct_knots.push(f64_le(data, record.pos.checked_add(*offset)?)?.get());
    }
    if !distinct_knots.windows(2).all(|pair| pair[0] < pair[1]) {
        return None;
    }
    let mut multiplicities = Vec::new();
    for index in 0..distinct_knots.len() {
        multiplicities.push(tagged_u32(
            data,
            record
                .pos
                .checked_add(multiplicity_start + index.checked_mul(5)?)?,
        )?);
    }
    if multiplicities != expected_multiplicities {
        return None;
    }
    let degree = multiplicities.first().copied()?.checked_sub(1)?;
    let derived_control_count = multiplicities
        .iter()
        .try_fold(0u32, |sum, multiplicity| sum.checked_add(*multiplicity))?
        .checked_sub(degree.checked_add(1)?)?;
    if derived_control_count != u32::try_from(control_count).ok()? {
        return None;
    }
    let knots = zero_entity_expand_knots(distinct_knots.iter().copied(), &multiplicities);
    let mut control_points = Vec::new();
    for index in 0usize..control_count {
        let at = record
            .pos
            .checked_add(pole_start + index.checked_mul(16)?)?;
        control_points.push(FinitePoint2::from_coordinates(
            f64_le(data, at)?,
            f64_le(data, at.checked_add(8)?)?,
        ));
    }
    let weights = if let Some(weight_start) = weight_start {
        let mut weights = Vec::new();
        for index in 0usize..control_count {
            let weight = f64_le(
                data,
                record
                    .pos
                    .checked_add(weight_start + index.checked_mul(8)?)?,
            )?;
            weights.push(PositiveReal::new(weight.get()).map(NonZeroReal::from)?);
        }
        Some(weights)
    } else {
        None
    };
    let nurbs = crate::nurbs::note_refusal(
        PcurveNurbs::from_checked_lanes(degree, knots, control_points, weights, false),
        refusal,
        format_args!("zero-entity NURBS pcurve record at byte {}", record.pos),
    )?;
    Some(PcurveGeometry::Nurbs { nurbs })
}

/// Convert a zero-entity support pcurve from the carrier's native chart into
/// the neutral IR chart.  The support records store cylindrical and toroidal
/// coordinates as arc lengths and conical latitude as slant length; IR
/// analytic surfaces use angles and axial distance respectively.
pub(super) fn zero_entity_neutral_pcurve(
    surface: &SurfaceGeometry,
    pcurve: &PcurveGeometry,
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<PcurveGeometry> {
    let (u_scale, v_scale) = match surface {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) => {
            let radius = cylinder_surface.radius().get();
            (radius.recip(), 1.0)
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)) => {
            let half_angle = cone_surface.half_angle().get();
            (1.0, half_angle.cos())
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)) => {
            let major_radius = torus_surface.major_radius().get();
            let minor_radius = torus_surface.minor_radius().get();
            (major_radius.recip(), minor_radius.recip())
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_)) => (1.0, 1.0),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(_)) => (1.0, 1.0),
        _ => return None,
    };
    if !u_scale.is_finite() || !v_scale.is_finite() || u_scale == 0.0 || v_scale == 0.0 {
        return None;
    }
    let PcurveGeometry::Nurbs { nurbs } = pcurve else {
        return None;
    };
    let mut control_points = Vec::new();

    match nurbs.pole_rows() {
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial { points } => {
            for point in points {
                let point = point.get();
                let scaled = FinitePoint2::new(Point2::new(point.u * u_scale, point.v * v_scale))?;
                control_points.push(scaled);
            }
        }
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Rational { points } => {
            for pole in points {
                let point = pole.point.get();
                let scaled = FinitePoint2::new(Point2::new(point.u * u_scale, point.v * v_scale))?;
                control_points.push(scaled);
            }
        }
    }
    let weights = match nurbs.pole_rows() {
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial { .. } => None,
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Rational { points } => {
            let mut weights = Vec::new();

            weights.extend(points.iter().map(|pole| pole.weight));
            Some(weights)
        }
    };
    let knots = nurbs.knots().clone();
    crate::nurbs::note_refusal(
        PcurveNurbs::from_checked_lanes(
            nurbs.degree(),
            knots,
            control_points,
            weights,
            nurbs.periodic(),
        ),
        refusal,
        format_args!("zero-entity pcurve scaled onto its surface parameters: {record}"),
    )
    .map(|nurbs| PcurveGeometry::Nurbs { nurbs })
}

fn zero_entity_model_curve(
    ctx: &DecodeContext<'_>,
    surface: &SurfaceGeometry,
    pcurve: &PcurveGeometry,
    uv_endpoints: [[f64; 2]; 2],
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<(CurveGeometry, [FiniteReal; 2])>, CodecError> {
    (|| -> Option<Result<(CurveGeometry, [FiniteReal; 2]), CodecError>> {
        let PcurveGeometry::Nurbs { nurbs } = pcurve else {
            return None;
        };
        if nurbs.periodic() {
            return None;
        }
        let pole_point = |index: usize| match nurbs.pole_rows() {
            cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial { points } => {
                points.get(index).copied()
            }
            cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Rational { points } => {
                points.get(index).map(|pole| pole.point)
            }
        };
        let constant_coordinate = |dimension: usize| {
            let point = pole_point(0)?;
            let value = if dimension == 0 { point.u } else { point.v };
            (0..nurbs.pole_rows().count())
                .all(|index| {
                    pole_point(index).is_some_and(|point| {
                        if dimension == 0 {
                            point.u == value
                        } else {
                            point.v == value
                        }
                    })
                })
                .then_some(value)
        };
        let (curve, parameters) = match surface {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)) => {
                let origin = plane_surface.origin().get();
                let normal = plane_surface.frame().axis().as_raw();
                let u_axis = plane_surface.frame().reference().as_raw();
                let v_axis = normal.cross(*u_axis);
                let degree_index = usize::try_from(nurbs.degree()).ok()?;
                let parameters = [
                    *nurbs.knots().get(degree_index)?,
                    *nurbs
                        .knots()
                        .get(nurbs.knots().len().checked_sub(degree_index + 1)?)?,
                ];
                let lifted = zero_entity_lift_pcurve(
                    nurbs,
                    |point| {
                        Point3::new(
                            origin.x + point.u * u_axis.x + point.v * v_axis.x,
                            origin.y + point.u * u_axis.y + point.v * v_axis.y,
                            origin.z + point.u * u_axis.z + point.v * v_axis.z,
                        )
                    },
                    refusal,
                    record,
                )?;
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(lifted)),
                    parameters,
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface))
                if { constant_coordinate(0).is_some() } =>
            {
                let point =
                    match zero_entity_surface_point(ctx, surface, [constant_coordinate(0)?, 0.0]) {
                        Ok(Some(point)) => point,
                        Ok(None) => return None,
                        Err(limit) => return Some(Err(limit.into())),
                    };
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Line(
                        cadmpeg_ir::geometry::analytic::LineCurve::new(
                            point,
                            *cylinder_surface.frame().axis(),
                        ),
                    )),
                    uv_endpoints.map(|uv| uv[1]),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface))
                if { constant_coordinate(1).is_some() } =>
            {
                let origin = cylinder_surface.origin().get();
                let axis = cylinder_surface.frame().axis().as_raw();
                let radius = cylinder_surface.radius().get();
                let height = constant_coordinate(1)?;
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                        cadmpeg_ir::geometry::analytic::CircleCurve::new(
                            cadmpeg_ir::features::FinitePoint3::new(Point3::new(
                                origin.x + height * axis.x,
                                origin.y + height * axis.y,
                                origin.z + height * axis.z,
                            ))?,
                            *cylinder_surface.frame(),
                            cylinder_surface.radius(),
                        ),
                    )),
                    uv_endpoints.map(|uv| uv[0] / radius),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface))
                if {
                    (cone_surface.ratio().get() == 1.0) && (constant_coordinate(0).is_some())
                } =>
            {
                let axis = cone_surface.frame().axis().as_raw();
                let ref_direction = cone_surface.frame().reference().as_raw();
                let half_angle = cone_surface.half_angle().get();
                let angle = constant_coordinate(0)?;
                let transverse = axis.cross(*ref_direction);
                let radial = cadmpeg_ir::math::Vector3::new(
                    angle.cos() * ref_direction.x + angle.sin() * transverse.x,
                    angle.cos() * ref_direction.y + angle.sin() * transverse.y,
                    angle.cos() * ref_direction.z + angle.sin() * transverse.z,
                );
                let point = match zero_entity_surface_point(ctx, surface, [angle, 0.0]) {
                    Ok(Some(point)) => point,
                    Ok(None) => return None,
                    Err(limit) => return Some(Err(limit.into())),
                };
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Line(
                        cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                            point.get(),
                            cadmpeg_ir::math::Vector3::new(
                                half_angle.cos() * axis.x + half_angle.sin() * radial.x,
                                half_angle.cos() * axis.y + half_angle.sin() * radial.y,
                                half_angle.cos() * axis.z + half_angle.sin() * radial.z,
                            ),
                        )
                        .ok()?,
                    )),
                    uv_endpoints.map(|uv| uv[1]),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface))
                if {
                    (cone_surface.ratio().get() == 1.0) && (constant_coordinate(1).is_some())
                } =>
            {
                let origin = cone_surface.origin().get();
                let axis = cone_surface.frame().axis().as_raw();
                let radius = cone_surface.radius().get();
                let half_angle = cone_surface.half_angle().get();
                let slant = constant_coordinate(1)?;
                let circle_radius = radius + slant * half_angle.sin();
                (circle_radius.is_finite() && circle_radius != 0.0).then_some(())?;
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                        cadmpeg_ir::geometry::analytic::CircleCurve::new(
                            cadmpeg_ir::features::FinitePoint3::new(Point3::new(
                                origin.x + slant * half_angle.cos() * axis.x,
                                origin.y + slant * half_angle.cos() * axis.y,
                                origin.z + slant * half_angle.cos() * axis.z,
                            ))?,
                            signed_reference_frame(*cone_surface.frame(), circle_radius),
                            cadmpeg_ir::scalar::PositiveLength::new(circle_radius.abs())?,
                        ),
                    )),
                    uv_endpoints.map(|uv| uv[0]),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface))
                if { constant_coordinate(0).is_some() } =>
            {
                let center = torus_surface.center().get();
                let axis = torus_surface.frame().axis().as_raw();
                let ref_direction = torus_surface.frame().reference().as_raw();
                let major_radius = torus_surface.major_radius().get();
                let minor_radius = torus_surface.minor_radius().get();
                let angle = constant_coordinate(0)? / major_radius;
                let transverse = axis.cross(*ref_direction);
                let radial = cadmpeg_ir::math::Vector3::new(
                    angle.cos() * ref_direction.x + angle.sin() * transverse.x,
                    angle.cos() * ref_direction.y + angle.sin() * transverse.y,
                    angle.cos() * ref_direction.z + angle.sin() * transverse.z,
                );
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                        cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                            Point3::new(
                                center.x + major_radius * radial.x,
                                center.y + major_radius * radial.y,
                                center.z + major_radius * radial.z,
                            ),
                            radial.cross(*axis),
                            radial,
                            minor_radius,
                        )
                        .ok()?,
                    )),
                    uv_endpoints.map(|uv| uv[1] / minor_radius),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface))
                if { constant_coordinate(1).is_some() } =>
            {
                let center = torus_surface.center().get();
                let axis = torus_surface.frame().axis().as_raw();
                let major_radius = torus_surface.major_radius().get();
                let minor_radius = torus_surface.minor_radius().get();
                let angle = constant_coordinate(1)? / minor_radius;
                let circle_radius = major_radius + minor_radius * angle.cos();
                (circle_radius.is_finite() && circle_radius != 0.0).then_some(())?;
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                        cadmpeg_ir::geometry::analytic::CircleCurve::new(
                            cadmpeg_ir::features::FinitePoint3::new(Point3::new(
                                center.x + minor_radius * angle.sin() * axis.x,
                                center.y + minor_radius * angle.sin() * axis.y,
                                center.z + minor_radius * angle.sin() * axis.z,
                            ))?,
                            signed_reference_frame(*torus_surface.frame(), circle_radius),
                            cadmpeg_ir::scalar::PositiveLength::new(circle_radius.abs())?,
                        ),
                    )),
                    uv_endpoints.map(|uv| uv[0] / major_radius),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface))
                if constant_coordinate(0).is_some() =>
            {
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                        match cadmpeg_ir::eval::nurbs_surface_isocurve(
                            ctx,
                            surface,
                            cadmpeg_ir::geometry::nurbs::SurfaceParameterAxis::U,
                            constant_coordinate(0)?,
                        ) {
                            Ok(Some(curve)) => curve,
                            Ok(None) => return None,
                            Err(error) => return Some(Err(error.into())),
                        },
                    )),
                    uv_endpoints.map(|uv| uv[1]),
                ))
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface))
                if constant_coordinate(1).is_some() =>
            {
                Some((
                    CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                        match cadmpeg_ir::eval::nurbs_surface_isocurve(
                            ctx,
                            surface,
                            cadmpeg_ir::geometry::nurbs::SurfaceParameterAxis::V,
                            constant_coordinate(1)?,
                        ) {
                            Ok(Some(curve)) => curve,
                            Ok(None) => return None,
                            Err(error) => return Some(Err(error.into())),
                        },
                    )),
                    uv_endpoints.map(|uv| uv[0]),
                ))
            }
            _ => None,
        }?;
        Some(Ok((
            curve,
            [
                FiniteReal::new(parameters[0])?,
                FiniteReal::new(parameters[1])?,
            ],
        )))
    })()
    .transpose()
}

fn zero_entity_lift_pcurve(
    nurbs: &PcurveNurbs,
    mut lift: impl FnMut(Point2) -> Point3,
    refusal: &mut crate::nurbs::LaneRefusals,
    record: &dyn std::fmt::Display,
) -> Option<NurbsCurve> {
    let mut points = Vec::new();

    let weights = match nurbs.pole_rows() {
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial { points: source } => {
            points.extend(source.iter().map(|point| lift(point.get())));
            None
        }
        cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Rational { points: source } => {
            points.extend(source.iter().map(|pole| lift(pole.point.get())));
            let mut weights = Vec::new();

            weights.extend(source.iter().map(|pole| pole.weight));
            Some(weights)
        }
    };
    let knots = nurbs.knots().clone();
    crate::nurbs::note_refusal(
        NurbsCurve::from_checked_lanes(nurbs.degree(), knots, points, weights, nurbs.periodic()),
        refusal,
        format_args!("zero-entity planar edge curve lifted from its pcurve: {record}"),
    )
}

fn zero_entity_model_curve_construction(
    surface: &SurfaceGeometry,
    pcurve: &PcurveGeometry,
) -> Option<ProceduralCurveDefinition> {
    let (
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)),
        PcurveGeometry::Nurbs { nurbs },
    ) = (surface, pcurve)
    else {
        return None;
    };
    if !(cone_surface.ratio().get() == 1.0) {
        return None;
    }
    let origin = cone_surface.origin().get();
    let axis = cone_surface.frame().axis().as_raw();
    let ref_direction = cone_surface.frame().reference().as_raw();
    let radius = cone_surface.radius().get();
    let half_angle = cone_surface.half_angle().get();
    if nurbs.degree() != 1 || nurbs.periodic() {
        return None;
    }
    let cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles::Polynomial { points } = nurbs.pole_rows()
    else {
        return None;
    };
    let [first, second] = points.as_slice() else {
        return None;
    };
    if first.u == second.u || first.v == second.v {
        return None;
    }
    let [start, end] = if first.u < second.u {
        [first, second]
    } else {
        [second, first]
    };
    let slope = (end.v - start.v) / (end.u - start.u);
    let zero_angle_v = start.v - slope * start.u;
    let zero_angle_radius = radius + zero_angle_v * half_angle.sin();
    if !slope.is_finite() || !zero_angle_radius.is_finite() || zero_angle_radius == 0.0 {
        return None;
    }
    let transverse = axis.cross(*ref_direction);
    let major = cadmpeg_ir::math::Vector3::new(
        zero_angle_radius * ref_direction.x,
        zero_angle_radius * ref_direction.y,
        zero_angle_radius * ref_direction.z,
    );
    let minor = cadmpeg_ir::math::Vector3::new(
        zero_angle_radius * transverse.x,
        zero_angle_radius * transverse.y,
        zero_angle_radius * transverse.z,
    );
    Some(ProceduralCurveDefinition::Helix(
        cadmpeg_ir::geometry::HelixCurveConstruction::try_new(
            [start.u, end.u],
            cadmpeg_ir::geometry::HelixFrame {
                center: Point3::new(
                    origin.x + zero_angle_v * half_angle.cos() * axis.x,
                    origin.y + zero_angle_v * half_angle.cos() * axis.y,
                    origin.z + zero_angle_v * half_angle.cos() * axis.z,
                ),
                major,
                minor,
                pitch: cadmpeg_ir::math::Vector3::new(
                    std::f64::consts::TAU * slope * half_angle.cos() * axis.x,
                    std::f64::consts::TAU * slope * half_angle.cos() * axis.y,
                    std::f64::consts::TAU * slope * half_angle.cos() * axis.z,
                ),
                axis: *axis,
            },
            std::f64::consts::TAU * slope * half_angle.sin() / zero_angle_radius,
            None,
        )
        .ok()?,
    ))
}

fn zero_entity_surface_point(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    geometry: &SurfaceGeometry,
    [u, v]: [f64; 2],
) -> Result<Option<FinitePoint3>, cadmpeg_core::decode::ResourceLimit> {
    let point = match geometry {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)) => {
            let origin = plane_surface.origin().get();
            let normal = plane_surface.frame().axis().as_raw();
            let u_axis = plane_surface.frame().reference().as_raw();
            let v_axis = normal.cross(*u_axis);
            Point3::new(
                origin.x + u * u_axis.x + v * v_axis.x,
                origin.y + u * u_axis.y + v * v_axis.y,
                origin.z + u * u_axis.z + v * v_axis.z,
            )
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) => {
            let origin = cylinder_surface.origin().get();
            let axis = cylinder_surface.frame().axis().as_raw();
            let ref_direction = cylinder_surface.frame().reference().as_raw();
            let radius = cylinder_surface.radius().get();
            let angle = u / radius;
            let transverse = axis.cross(*ref_direction);
            Point3::new(
                origin.x
                    + radius * (angle.cos() * ref_direction.x + angle.sin() * transverse.x)
                    + v * axis.x,
                origin.y
                    + radius * (angle.cos() * ref_direction.y + angle.sin() * transverse.y)
                    + v * axis.y,
                origin.z
                    + radius * (angle.cos() * ref_direction.z + angle.sin() * transverse.z)
                    + v * axis.z,
            )
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface))
            if {
                let ratio = cone_surface.ratio().get();
                ratio == 1.0
            } =>
        {
            let origin = cone_surface.origin().get();
            let axis = cone_surface.frame().axis().as_raw();
            let ref_direction = cone_surface.frame().reference().as_raw();
            let radius = cone_surface.radius().get();
            let half_angle = cone_surface.half_angle().get();
            let transverse = axis.cross(*ref_direction);
            let axial = v * half_angle.cos();
            let radial = radius + v * half_angle.sin();
            Point3::new(
                origin.x
                    + radial * (u.cos() * ref_direction.x + u.sin() * transverse.x)
                    + axial * axis.x,
                origin.y
                    + radial * (u.cos() * ref_direction.y + u.sin() * transverse.y)
                    + axial * axis.y,
                origin.z
                    + radial * (u.cos() * ref_direction.z + u.sin() * transverse.z)
                    + axial * axis.z,
            )
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)) => {
            let center = torus_surface.center().get();
            let axis = torus_surface.frame().axis().as_raw();
            let ref_direction = torus_surface.frame().reference().as_raw();
            let major_radius = torus_surface.major_radius().get();
            let minor_radius = torus_surface.minor_radius().get();
            let major_angle = u / major_radius;
            let minor_angle = v / minor_radius;
            let transverse = axis.cross(*ref_direction);
            let radial = major_radius + minor_radius * minor_angle.cos();
            Point3::new(
                center.x
                    + radial
                        * (major_angle.cos() * ref_direction.x + major_angle.sin() * transverse.x)
                    + minor_radius * minor_angle.sin() * axis.x,
                center.y
                    + radial
                        * (major_angle.cos() * ref_direction.y + major_angle.sin() * transverse.y)
                    + minor_radius * minor_angle.sin() * axis.y,
                center.z
                    + radial
                        * (major_angle.cos() * ref_direction.z + major_angle.sin() * transverse.z)
                    + minor_radius * minor_angle.sin() * axis.z,
            )
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface)) => {
            return cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::nurbs_surface_point(ctx, surface, u, v),
            )?);
        }
        _ => return Ok(None),
    };
    Ok(FinitePoint3::new(point))
}

/// Decode complete `5e1a` allocation tuples.
#[cfg(test)]
#[must_use]
fn zero_entity_edge_strides(data: &[u8]) -> Vec<ZeroEntityEdgeStride> {
    zero_entity_edge_strides_in_range(data, 0..data.len())
}

/// Decode edge strides whose records stay inside `range`.
pub(crate) fn zero_entity_edge_strides_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Vec<ZeroEntityEdgeStride> {
    let records = zero_entity_records_in_range(data, range);
    let mut output = Vec::new();
    for record in records {
        let parsed = (|| {
            if record.tag != [0x5e, 0x1a]
                || tagged_u32(data, record.pos + edge_5e1a::TAGGED_ONE_PREFIX) != Some(1)
                || data.get(record.pos + edge_5e1a::TERMINAL) != Some(&0x21)
            {
                return None;
            }
            let mut allocations = [0; 5];
            for (index, allocation) in allocations.iter_mut().enumerate() {
                *allocation = tagged_u32(
                    data,
                    record.pos.checked_add(edge_5e1a::ALLOCATIONS + index * 5)?,
                )?;
            }
            if allocations.contains(&0) {
                return None;
            }
            if allocations[0].checked_sub(1) != Some(allocations[3])
                || allocations[0].checked_sub(2) != Some(allocations[4])
            {
                return None;
            }
            Some(ZeroEntityEdgeStride {
                pos: record.pos,
                record_ordinal: record.ordinal,
                allocations,
            })
        })();
        if let Some(record) = parsed {
            output.push(record);
        }
    }
    output
}

/// Decode complete `2569` headers with their adjacent `(1, 2)` oriented uses.
#[cfg(test)]
#[must_use]
fn zero_entity_oriented_use_pairs(data: &[u8]) -> Vec<ZeroEntityOrientedUsePair> {
    zero_entity_oriented_use_pairs_in_range(data, 0..data.len())
}

/// Decode oriented-use pairs whose records stay inside `range`.
pub(crate) fn zero_entity_oriented_use_pairs_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Vec<ZeroEntityOrientedUsePair> {
    let records = zero_entity_records_in_range(data, range);
    let mut output = Vec::new();
    for records in records.windows(3) {
        let parsed = (|| {
            let [header, side_one, side_two] = records else {
                return None;
            };
            if header.tag != [0x25, 0x69]
                || side_one.tag != [0x06, 0x38]
                || side_two.tag != [0x06, 0x38]
                || tagged_u32(data, header.pos + 7) != Some(1)
                || data.get(header.pos + 12) != Some(&0x82)
            {
                return None;
            }
            let base_columns = [
                tagged_u32(data, header.pos + 13)?,
                tagged_u32(data, header.pos + 18)?,
            ];
            let parse_use = |record: ZeroEntityRecord, expected_side: u32| {
                if tagged_u32(data, record.pos + 7) != Some(1)
                    || data.get(record.pos + 12) != Some(&0x83)
                    || tagged_u32(data, record.pos + 13) != Some(expected_side)
                {
                    return None;
                }
                let allocations = [
                    tagged_u32(data, record.pos + 18)?,
                    tagged_u32(data, record.pos + 23)?,
                ];
                let expected_allocations = [
                    base_columns[0].checked_add(expected_side)?,
                    base_columns[1].checked_add(expected_side)?,
                ];
                if allocations != expected_allocations {
                    return None;
                }
                Some(ZeroEntityOrientedUse {
                    pos: record.pos,
                    record_ordinal: record.ordinal,
                })
            };
            Some(ZeroEntityOrientedUsePair {
                header_pos: header.pos,
                header_record_ordinal: header.ordinal,
                base_columns,
                uses: [parse_use(*side_one, 1)?, parse_use(*side_two, 2)?],
            })
        })();
        if let Some(pair) = parsed {
            output.push(pair);
        }
    }
    output
}

/// Decode complete counted `050b`, `0510`, and `0515` incidence records.
#[cfg(test)]
#[must_use]
fn zero_entity_vertex_incidences(data: &[u8]) -> Vec<ZeroEntityVertexIncidence> {
    zero_entity_vertex_incidences_in_range(data, 0..data.len())
}

/// Decode vertex incidences whose records stay inside `range`.
pub(crate) fn zero_entity_vertex_incidences_in_range(
    data: &[u8],
    range: Range<usize>,
) -> Vec<ZeroEntityVertexIncidence> {
    let records = zero_entity_records_in_range(data, range);
    let mut output = Vec::new();
    for records in records.windows(2) {
        let parsed = (|| {
            let [record, owner] = records else {
                return None;
            };
            let count: u8 = match record.tag {
                [0x05, 0x0b] => 2,
                [0x05, 0x10] => 3,
                [0x05, 0x15] => 4,
                _ => return None,
            };
            if tagged_u32(data, record.pos + 7) != Some(1)
                || data.get(record.pos + 12) != Some(&(0x80 + count))
                || record.end != owner.pos
                || !zero_entity_vertex_owner(data, *owner)
            {
                return None;
            }
            let slot = |index: usize| tagged_u32(data, record.pos + 13 + index * 5);
            let allocations = match record.tag {
                [0x05, 0x0b] => ZeroEntityVertexAllocations::Two([slot(0)?, slot(1)?]),
                [0x05, 0x10] => ZeroEntityVertexAllocations::Three([slot(0)?, slot(1)?, slot(2)?]),
                [0x05, 0x15] => {
                    ZeroEntityVertexAllocations::Four([slot(0)?, slot(1)?, slot(2)?, slot(3)?])
                }
                _ => return None,
            };
            if allocations.as_slice().contains(&0) {
                return None;
            }
            Some(ZeroEntityVertexIncidence {
                pos: record.pos,
                record_ordinal: record.ordinal,
                allocations,
            })
        })();
        if let Some(incidence) = parsed {
            output.push(incidence);
        }
    }
    output
}

fn zero_entity_vertex_owner(data: &[u8], record: ZeroEntityRecord) -> bool {
    let Some(expected_end) = record.pos.checked_add(vertex_5d06::LEN) else {
        return false;
    };
    let Some(first_token) = record.pos.checked_add(vertex_5d06::TAGGED_ONE_A) else {
        return false;
    };
    let Some(second_token) = record.pos.checked_add(vertex_5d06::TAGGED_ONE_B) else {
        return false;
    };
    let Some(terminal) = record.pos.checked_add(vertex_5d06::TERMINAL) else {
        return false;
    };
    record.tag == [0x5d, 0x06]
        && record.end == expected_end
        && tagged_u32(data, first_token) == Some(1)
        && tagged_u32(data, second_token) == Some(1)
        && data.get(terminal) == Some(&0)
}

fn tagged_u32(data: &[u8], at: usize) -> Option<u32> {
    (data.get(at) == Some(&0x10)).then(|| View::u32_le_at(data, at + 1))?
}

fn zero_entity_surface_at(
    data: &[u8],
    record: usize,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<SurfaceGeometry> {
    let (tag, payload) = (|| {
        let tag = [
            *data.get(record + a9_03::TAG_HI)?,
            *data.get(record + a9_03::TAG_LO_LENGTH_DRIVER)?,
        ];
        if !zero_entity_surface_carrier_tag(tag) {
            return None;
        }
        let payload_end = record
            .checked_add(usize::from(*data.get(record + a9_03::TAG_LO_LENGTH_DRIVER)?) + 12)?;
        let payload = data.get(record + a9_03::LEN..payload_end)?;
        Some((tag, payload))
    })()?;
    if matches!(tag, [0x34, 0xc8 | 0x5e]) {
        return zero_entity_nurbs_surface(data, record, refusal);
    }
    match tag {
        [0x27, 0x6a] => zero_entity_plane(payload),
        [0x28, 0x8a] => zero_entity_cylinder(payload),
        [0x29, 0xb8] => zero_entity_cone(payload),
        [0x2b, 0xc8] => zero_entity_torus(payload),
        _ => None,
    }
}

fn zero_entity_surface_carrier_tag(tag: [u8; 2]) -> bool {
    matches!(
        tag,
        [0x27, 0x6a] | [0x28, 0x8a] | [0x29, 0xb8] | [0x2b | 0x34, 0xc8] | [0x34, 0x5e]
    )
}

fn zero_entity_nurbs_shape(tag: [u8; 2]) -> Option<(usize, usize, usize)> {
    match tag {
        [0x34, 0xc8] => Some((167, 7, 7)),
        [0x34, 0x5e] => Some((141, 5, 7)),
        _ => None,
    }
}

/// Decode the inline zero-entity non-rational NURBS carrier. Its pole grid
/// extends past the nominal framed record at a tag-specific fixed offset.
fn zero_entity_nurbs_surface(
    data: &[u8],
    record: usize,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<SurfaceGeometry> {
    let layout = zero_entity_nurbs_layout(data, record)?;
    let pole_count = crate::nurbs_surface_control_count(
        index_from_u32(layout.u_count),
        index_from_u32(layout.v_count),
    )?;
    let mut control_points = Vec::new();

    for pole in 0..pole_count {
        let at = pole
            .checked_mul(24)
            .and_then(|offset| layout.grid.checked_add(offset))?;
        let point = f64_point(data, at)?;
        control_points.push(point);
    }
    let u_knots = zero_entity_expand_knots(
        layout.u_distinct.iter().map(|knot| knot.get()),
        &layout.u_mults,
    );
    let v_knots = zero_entity_expand_knots(
        layout.v_distinct.iter().map(|knot| knot.get()),
        &layout.v_mults,
    );
    let mut rows = Vec::new();

    for row in control_points.chunks(index_from_u32(layout.v_count)) {
        rows.push(row.to_vec());
    }
    crate::nurbs::note_refusal(
        cadmpeg_ir::geometry::nurbs::NurbsSurface::from_lanes(
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(layout.u_degree, u_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(layout.v_degree, v_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(rows, None),
            false,
        ),
        refusal,
        format_args!("zero-entity NURBS surface record at byte {record}"),
    )
    .map(|surface| SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface)))
}

fn zero_entity_expand_knots(
    distinct: impl Iterator<Item = f64>,
    multiplicities: &[u32],
) -> Vec<f64> {
    let mut knots = Vec::new();
    for (knot, &multiplicity) in distinct.zip(multiplicities) {
        knots.extend(std::iter::repeat_with(|| knot).take(index_from_u32(multiplicity)));
    }
    knots
}

fn zero_entity_plane(payload: &[u8]) -> Option<SurfaceGeometry> {
    let origin = f64_point(payload, 10)?;
    let row0 = f64_vector(payload, 34)?.get();
    let row1 = f64_vector(payload, 58)?.get();
    Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::new(
            origin,
            cadmpeg_ir::units::OrthonormalFrame3::from_units(
                cadmpeg_ir::units::UnitVector3::normalized(row0.cross(row1))?,
                cadmpeg_ir::units::UnitVector3::normalized(row0)?,
            )?,
        ),
    )))
}

fn zero_entity_cylinder(payload: &[u8]) -> Option<SurfaceGeometry> {
    // The origin sits at offset 8; a one-byte gap separates it from the
    // contiguous frame-row block at offset 33.
    let mut c = crate::wire::cursor::Cursor::new_at(payload, 8)?;
    let origin = c.point3()?;
    c.skip(1)?;
    crate::analytic::cylinder_uvr(&mut c, origin).map(|(geometry, _)| geometry)
}

fn zero_entity_cone(payload: &[u8]) -> Option<SurfaceGeometry> {
    let mut c = crate::wire::cursor::Cursor::new_at(payload, 8)?;
    let (geometry, _, _) = crate::analytic::cone_ozra(&mut c)?;
    Some(geometry)
}

fn zero_entity_torus(payload: &[u8]) -> Option<SurfaceGeometry> {
    let mut c = crate::wire::cursor::Cursor::new_at(payload, 8)?;
    let (geometry, _, _) = crate::analytic::torus_ozrr(&mut c)?;
    Some(geometry)
}

fn u32_tokens(bytes: &[u8], at: usize, count: usize) -> Option<(Vec<u32>, usize)> {
    let mut view = View::over_retained(bytes);
    view.seek(at)?;
    let mut values = Vec::new();

    for _ in 0..count {
        if view.u8() != Some(0x10) {
            return None;
        }
        let value = view.u32_le()?;
        if value == 0 {
            return None;
        }
        values.push(value);
    }
    Some((values, view.position()))
}

#[cfg(test)]
mod tests {
    use super::{
        oriented_closed_model_endpoints, zero_entity_cone, zero_entity_cylinder,
        zero_entity_edge_strides, zero_entity_fixed_logical_length, zero_entity_loops_from_records,
        zero_entity_model_curve as model_curve_with_context, zero_entity_model_curve_construction,
        zero_entity_neutral_pcurve, zero_entity_nurbs_layout, zero_entity_nurbs_shape,
        zero_entity_oriented_use_pairs, zero_entity_ownership_root, zero_entity_ownership_roots,
        zero_entity_record_inventory, zero_entity_records, zero_entity_support_occurrence,
        zero_entity_support_runs, zero_entity_surface_at, zero_entity_surface_point,
        zero_entity_surfaces, zero_entity_torus, zero_entity_vertex_incidences,
        ZeroEntityFaceControl, ZeroEntityLoopMembers, ZeroEntityUseSlot,
    };
    use cadmpeg_ir::features::FinitePoint3;
    use cadmpeg_ir::geometry::pcurve::PcurveGeometry;
    use cadmpeg_ir::geometry::pcurve::PcurveNurbs;
    use cadmpeg_ir::geometry::CurveGeometry;
    use cadmpeg_ir::geometry::ProceduralCurveDefinition;
    use cadmpeg_ir::geometry::SolvedCurveGeometry;
    use cadmpeg_ir::geometry::SolvedSurfaceGeometry;
    use cadmpeg_ir::geometry::SurfaceGeometry;
    use cadmpeg_ir::math::Point2;
    use cadmpeg_ir::math::Point3;
    use cadmpeg_ir::scalar::FiniteReal;
    use std::num::NonZeroUsize;

    fn zero_entity_model_curve(
        surface: &SurfaceGeometry,
        pcurve: &PcurveGeometry,
        uv_endpoints: [[f64; 2]; 2],
        record: &dyn std::fmt::Display,
        refusal: &mut crate::nurbs::LaneRefusals,
    ) -> Option<(CurveGeometry, [FiniteReal; 2])> {
        crate::test_support::with_service_context(|ctx| {
            model_curve_with_context(ctx, surface, pcurve, uv_endpoints, record, refusal)
        })
        .expect("compute the model curve")
    }

    #[test]
    fn loop_member_run_bounds_preserve_zero_members_and_terminal_slots() {
        let count = NonZeroUsize::new(3).expect("nonzero loop member count");
        let members =
            ZeroEntityLoopMembers::try_new(4, 2, count).expect("admitted loop member run");
        assert_eq!(members.member_ids().collect::<Vec<_>>(), [2, 1, 0]);
        assert_eq!(members.support_slots().collect::<Vec<_>>(), [2, 3, 4]);
        assert!(ZeroEntityLoopMembers::try_new(4, 0, count).is_none());
        assert!(ZeroEntityLoopMembers::try_new(4, 3, count).is_none());
        let singleton = ZeroEntityLoopMembers::try_new(u32::MAX, u32::MAX, NonZeroUsize::MIN)
            .expect("admitted loop member run");
        assert_eq!(singleton.member_ids().collect::<Vec<_>>(), [0]);
        assert_eq!(singleton.support_slots().collect::<Vec<_>>(), [u32::MAX]);
    }

    use crate::test_support::test_zero_entity::{
        zero_entity_face_loop_support_stream, zero_entity_face_support_stream,
        zero_entity_ownership_stream, zero_entity_support_stream, zero_entity_topology_stream,
    };

    // These checked constructors must accept the explicit test fixtures.
    #[allow(clippy::unwrap_used)]
    fn test_pcurve(points: Vec<Point2>) -> PcurveGeometry {
        PcurveGeometry::Nurbs {
            nurbs: PcurveNurbs::from_lanes(1, vec![0.0, 0.0, 1.0, 1.0], points, None, false)
                .unwrap(),
        }
    }

    fn write_tagged_u32(record: &mut [u8], at: usize, value: u32) {
        record[at] = 0x10;
        record[at + 1..at + 5].copy_from_slice(&value.to_le_bytes());
    }

    fn nurbs_carrier(
        tag: [u8; 2],
        u_knots: &[f64],
        u_mults: &[u32],
        v_knots: &[f64],
        v_mults: &[u32],
    ) -> Vec<u8> {
        let (grid_offset, u_count, v_count) =
            zero_entity_nurbs_shape(tag).expect("unsupported test carrier");
        let pole_count = crate::nurbs_surface_control_count(u_count, v_count)
            .expect("test NURBS dimensions fit the codec limit");
        let mut bytes = vec![0u8; grid_offset + pole_count * 24];
        bytes[..4].copy_from_slice(&[0xa9, 0x03, tag[0], tag[1]]);
        let mut at = 23;
        for knot in u_knots {
            bytes[at..at + 8].copy_from_slice(&knot.to_le_bytes());
            at += 8;
        }
        for multiplicity in u_mults {
            write_tagged_u32(&mut bytes, at, *multiplicity);
            at += 5;
        }
        write_tagged_u32(&mut bytes, at, 1);
        at += 5;
        write_tagged_u32(&mut bytes, at, 1);
        at += 5;
        bytes[at] = 0x04;
        at += 1;
        for knot in v_knots {
            bytes[at..at + 8].copy_from_slice(&knot.to_le_bytes());
            at += 8;
        }
        for multiplicity in v_mults {
            write_tagged_u32(&mut bytes, at, *multiplicity);
            at += 5;
        }
        bytes[at..at + 3].copy_from_slice(&[0x08, 0x00, 0x00]);
        at += 3;
        assert_eq!(at, grid_offset);
        for pole in 0..pole_count {
            let value = cadmpeg_core::convert::f64_from_index(pole)
                .expect("fixture index is exactly representable");
            for coordinate in 0..3 {
                let offset = at + pole * 24 + coordinate * 8;
                bytes[offset..offset + 8].copy_from_slice(
                    &(value
                        + cadmpeg_core::convert::f64_from_index(coordinate)
                            .expect("fixture index is exactly representable"))
                    .to_le_bytes(),
                );
            }
        }
        bytes
    }

    #[test]
    fn nurbs_layout_uses_fixed_boundaries_without_parameter_windows() {
        let carriers = [
            (
                [0x34, 0xc8],
                vec![10.0, 20.0, 30.0, 40.0, 50.0],
                vec![4, 1, 1, 1, 4],
                vec![-100.0, 0.0, 100.0, 200.0, 300.0],
                vec![4, 1, 1, 1, 4],
                167usize + 49 * 24,
            ),
            (
                [0x34, 0x5e],
                vec![10.0, 20.0, 30.0],
                vec![4, 1, 4],
                vec![-100.0, 0.0, 100.0, 200.0, 300.0],
                vec![4, 1, 1, 1, 4],
                141usize + 35 * 24,
            ),
        ];
        for (tag, u_knots, u_mults, v_knots, v_mults, expected_end) in carriers {
            let bytes = nurbs_carrier(tag, &u_knots, &u_mults, &v_knots, &v_mults);
            let layout = zero_entity_nurbs_layout(&bytes, 0).expect("bounded NURBS layout");
            assert_eq!(layout.end, expected_end);
            assert_eq!(FiniteReal::raw_lane(&layout.u_distinct), u_knots);
            assert_eq!(FiniteReal::raw_lane(&layout.v_distinct), v_knots);
            assert!(matches!(
                zero_entity_surface_at(&bytes, 0, &mut crate::nurbs::LaneRefusals::new()),
                Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(_)))
            ));
        }
    }

    #[test]
    fn nurbs_layout_rejects_an_invalid_dimension_token() {
        let mut bytes = nurbs_carrier(
            [0x34, 0x5e],
            &[10.0, 20.0, 30.0],
            &[4, 1, 4],
            &[-100.0, 0.0, 100.0, 200.0, 300.0],
            &[4, 1, 1, 1, 4],
        );
        let first_dimension_value = 23 + 3 * 13 + 1;
        bytes[first_dimension_value..first_dimension_value + 4].fill(0);
        assert!(zero_entity_nurbs_layout(&bytes, 0).is_none());
    }

    #[test]
    fn nurbs_layout_rejects_nonfinite_knots() {
        let mut bytes = nurbs_carrier(
            [0x34, 0xc8],
            &[10.0, f64::NAN, 30.0, 40.0, 50.0],
            &[4, 1, 1, 1, 4],
            &[-100.0, 0.0, 100.0, 200.0, 300.0],
            &[4, 1, 1, 1, 4],
        );
        bytes[23..31].copy_from_slice(&10.0f64.to_le_bytes());
        assert!(zero_entity_nurbs_layout(&bytes, 0).is_none());
    }

    #[test]
    fn nurbs_layout_requires_the_declared_pole_grid_before_allocation() {
        let mut bytes = vec![0u8; 79];
        bytes[23..31].copy_from_slice(&0.0f64.to_le_bytes());
        bytes[31..39].copy_from_slice(&1.0f64.to_le_bytes());
        write_tagged_u32(&mut bytes, 39, 2);
        write_tagged_u32(&mut bytes, 44, 1000);
        bytes[50..58].copy_from_slice(&0.0f64.to_le_bytes());
        bytes[58..66].copy_from_slice(&1.0f64.to_le_bytes());
        write_tagged_u32(&mut bytes, 66, 2);
        write_tagged_u32(&mut bytes, 71, 1000);

        assert!(zero_entity_nurbs_layout(&bytes, 0).is_none());
    }

    #[test]
    fn nurbs_surface_control_count_has_one_codec_wide_ceiling() {
        assert_eq!(
            crate::nurbs_surface_control_count(1000, 1000),
            Some(1_000_000)
        );
        assert_eq!(crate::nurbs_surface_control_count(1001, 1000), None);
        assert_eq!(crate::nurbs_surface_control_count(usize::MAX, 2), None);
    }

    fn support_pcurve_record(tag: u8) -> Vec<u8> {
        let logical_len = if tag == 0x18 {
            292
        } else {
            zero_entity_fixed_logical_length([0x21, tag]).unwrap_or(usize::from(tag) + 12)
        };
        let mut record = vec![0u8; logical_len];
        record[..4].copy_from_slice(&[0xa9, 0x03, 0x21, tag]);
        write_tagged_u32(&mut record, 12, 1);
        let (knots, multiplicities, control_count, rational): (&[_], &[_], usize, bool) = match tag
        {
            0x18 => (&[0.0, 0.25, 0.5, 0.75, 1.0], &[4, 2, 2, 2, 4], 10, false),
            0x45 => (
                &[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                &[4, 2, 2, 2, 2, 4],
                12,
                false,
            ),
            0x71 => (&[0.0, 1.0], &[2, 2], 2, false),
            0x72 => (
                &[0.0, 1.0 / 6.0, 2.0 / 6.0, 0.5, 4.0 / 6.0, 5.0 / 6.0, 1.0],
                &[4, 2, 2, 2, 2, 2, 4],
                14,
                false,
            ),
            0x91 => (&[0.0, 1.0], &[4, 4], 4, false),
            0x99 => (&[0.0, 1.0], &[3, 3], 3, true),
            0x9f => (
                &[
                    0.0,
                    1.0 / 7.0,
                    2.0 / 7.0,
                    3.0 / 7.0,
                    4.0 / 7.0,
                    5.0 / 7.0,
                    6.0 / 7.0,
                    1.0,
                ],
                &[4, 2, 2, 2, 2, 2, 2, 4],
                16,
                false,
            ),
            0xd6 => (&[0.0, 0.5, 1.0], &[3, 2, 3], 5, false),
            0xe8 => (&[0.0, 0.25, 0.5, 0.75, 1.0], &[4, 1, 1, 1, 4], 7, false),
            _ => unreachable!(),
        };
        let knot_start = 67;
        for (index, knot) in knots.iter().enumerate() {
            record[knot_start + index * 8..knot_start + (index + 1) * 8]
                .copy_from_slice(&f64::to_le_bytes(*knot));
        }
        let multiplicity_start = knot_start + knots.len() * 8;
        for (index, multiplicity) in multiplicities.iter().copied().enumerate() {
            write_tagged_u32(&mut record, multiplicity_start + index * 5, multiplicity);
        }
        let pole_start = multiplicity_start + multiplicities.len() * 5;
        let points = (0..control_count)
            .map(|index| {
                let parameter = cadmpeg_core::convert::f64_from_index(index)
                    .expect("fixture index is exactly representable")
                    / cadmpeg_core::convert::f64_from_index(control_count - 1)
                        .expect("fixture index is exactly representable");
                [parameter, parameter * (1.0 - parameter)]
            })
            .collect::<Vec<_>>();
        for (index, point) in points.iter().enumerate() {
            let at = pole_start + index * 16;
            record[at..at + 8].copy_from_slice(&f64::to_le_bytes(point[0]));
            record[at + 8..at + 16].copy_from_slice(&f64::to_le_bytes(point[1]));
        }
        if rational {
            let weight_start = pole_start + points.len() * 16;
            for (index, weight) in (0..control_count)
                .map(|index| if index == control_count / 2 { 0.5 } else { 1.0 })
                .enumerate()
            {
                let at = weight_start + index * 8;
                record[at..at + 8].copy_from_slice(&f64::to_le_bytes(weight));
            }
        }
        record
    }

    #[test]
    fn support_run_binds_maximal_21xx_lane_to_preceding_surface() {
        let runs = zero_entity_support_runs(&zero_entity_support_stream());
        let [run] = runs.as_slice() else {
            panic!("one support run")
        };
        assert_eq!(run.carrier_pos, 0);
        let [support] = run.supports.as_slice() else {
            panic!("one support occurrence")
        };
        assert_eq!(support.tag, [0x21, 0x71]);
        assert_eq!(support.face_local_slot, 42);
        assert_eq!(
            support.uv_endpoints,
            Some([[-2.0, 4.0], [6.0, 8.0]].map(crate::test_support::test_b5::finite_pair))
        );
        assert_eq!(
            support.pcurve,
            Some(test_pcurve(vec![
                Point2::new(-2.0, 4.0),
                Point2::new(6.0, 8.0),
            ]))
        );
        assert!(matches!(
            support.model_curve,
            Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(ref curve)))
                if curve.degree() == 1
                    && curve.weights().is_none()
                    && !curve.periodic()
                    && curve.control_points()
                == [Point3::new(-1.0, 6.0, 3.0), Point3::new(7.0, 10.0, 3.0)]
        ));
        assert_eq!(
            support.model_parameters,
            Some(crate::test_support::test_b5::finite_pair([0.0, 1.0]))
        );
        assert_eq!(
            support.model_midpoint.map(FinitePoint3::get),
            Some(Point3::new(3.0, 8.0, 3.0))
        );
        assert_eq!(
            support
                .model_endpoints
                .map(|pair| pair.map(FinitePoint3::get)),
            Some([Point3::new(-1.0, 6.0, 3.0), Point3::new(7.0, 10.0, 3.0)])
        );
    }

    #[test]
    fn support_run_lifts_midpoint_across_a_wide_finite_pcurve_domain() {
        let mut stream = zero_entity_support_stream();
        let support_start = 0x6a + 12;
        stream[support_start + 67..support_start + 75].copy_from_slice(&(-f64::MAX).to_le_bytes());
        stream[support_start + 75..support_start + 83].copy_from_slice(&f64::MAX.to_le_bytes());
        let runs = zero_entity_support_runs(&stream);
        assert_eq!(runs.len(), 1);
        assert_eq!(runs[0].supports.len(), 1);
        assert_eq!(
            runs[0].supports[0].model_midpoint.map(FinitePoint3::get),
            Some(Point3::new(3.0, 8.0, 3.0))
        );
    }

    #[test]
    fn support_pcurves_decode_each_complete_clamped_family() {
        for (tag, degree, control_count, rational) in [
            (0x18, 3, 10, false),
            (0x45, 3, 12, false),
            (0x71, 1, 2, false),
            (0x72, 3, 14, false),
            (0x91, 3, 4, false),
            (0x99, 2, 3, true),
            (0x9f, 3, 16, false),
            (0xd6, 2, 5, false),
            (0xe8, 3, 7, false),
        ] {
            let bytes = support_pcurve_record(tag);
            let records = zero_entity_records(&bytes);
            let [record] = records.as_slice() else {
                panic!("one support record")
            };
            let support = zero_entity_support_occurrence(
                &bytes,
                *record,
                &mut crate::nurbs::LaneRefusals::new(),
            )
            .expect("complete support pcurve");
            assert_eq!(
                support.uv_endpoints,
                Some([[0.0, 0.0], [1.0, 0.0]].map(crate::test_support::test_b5::finite_pair))
            );
            let Some(PcurveGeometry::Nurbs { nurbs }) = support.pcurve else {
                panic!("NURBS support pcurve")
            };
            assert_eq!(nurbs.degree(), degree);
            assert_eq!(nurbs.control_points().len(), control_count);
            assert_eq!(nurbs.weights().is_some(), rational);

            let multiplicity_start = match tag {
                0x18 => 107,
                0x45 => 115,
                0x71 | 0x91 | 0x99 => 83,
                0x72 => 123,
                0x9f => 131,
                0xd6 => 91,
                0xe8 => 107,
                _ => unreachable!(),
            };
            let mut malformed = bytes;
            malformed[multiplicity_start + 1] ^= 1;
            let malformed_records = zero_entity_records(&malformed);
            let [record] = malformed_records.as_slice() else {
                panic!("one malformed support record")
            };
            assert!(zero_entity_support_occurrence(
                &malformed,
                *record,
                &mut crate::nurbs::LaneRefusals::new()
            )
            .is_none());
        }
    }

    #[test]
    fn rational_support_pcurve_rejects_a_nonpositive_weight_atomically() {
        let mut bytes = support_pcurve_record(0x99);
        bytes[149..157].copy_from_slice(&0.0f64.to_le_bytes());
        let records = zero_entity_records(&bytes);
        let [record] = records.as_slice() else {
            panic!("one support record")
        };
        assert!(zero_entity_support_occurrence(
            &bytes,
            *record,
            &mut crate::nurbs::LaneRefusals::new()
        )
        .is_none());
    }

    #[test]
    fn affine_cone_pcurve_lifts_to_an_exact_conical_helix() {
        use cadmpeg_ir::math::Vector3;

        let half_angle = 0.25;
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(1.0, 2.0, 3.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
                1.0,
                half_angle,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let pcurve = test_pcurve(vec![Point2::new(0.0, 1.0), Point2::new(0.5, 2.0)]);
        let Some(ProceduralCurveDefinition::Helix(helix_payload)) =
            zero_entity_model_curve_construction(&surface, &pcurve)
        else {
            panic!("conical helix")
        };
        let angle_range = *helix_payload.angle_range();
        let center = *helix_payload.center().as_raw();
        let major = *helix_payload.major();
        let minor = *helix_payload.minor();
        let pitch = *helix_payload.pitch();
        let apex_factor = helix_payload.apex_factor();
        let axis = *helix_payload.axis();

        let slope = 2.0;
        let start_radius = 2.0 + half_angle.sin();
        assert_eq!(angle_range.get(), [0.0, 0.5]);
        assert_eq!(center, Point3::new(1.0, 2.0, 3.0 + half_angle.cos()));
        assert_eq!(major, Vector3::new(start_radius, 0.0, 0.0));
        assert_eq!(minor, Vector3::new(0.0, start_radius, 0.0));
        assert_eq!(
            pitch,
            Vector3::new(0.0, 0.0, std::f64::consts::TAU * slope * half_angle.cos())
        );
        assert_eq!(
            apex_factor.get(),
            std::f64::consts::TAU * slope * half_angle.sin() / start_radius
        );
        assert_eq!(axis, Vector3::new(0.0, 0.0, 1.0));

        let revolution_fraction = angle_range[1] / std::f64::consts::TAU;
        let end_radius = start_radius * (1.0 + apex_factor.get() * revolution_fraction);
        assert!((end_radius - (2.0 + 2.0 * half_angle.sin())).abs() < 1.0e-12);
        assert!(
            (center.z + pitch.z * revolution_fraction - (3.0 + 2.0 * half_angle.cos())).abs()
                < 1.0e-12
        );
        for fraction in [0.0, 0.25, 0.5, 0.75, 1.0] {
            let angle = angle_range[0] + fraction * (angle_range[1] - angle_range[0]);
            let revolution_fraction = (angle - angle_range[0]) / std::f64::consts::TAU;
            let radial_scale = 1.0 + apex_factor.get() * revolution_fraction;
            let construction_point = Point3::new(
                center.x
                    + radial_scale * (major.x * angle.cos() + minor.x * angle.sin())
                    + pitch.x * revolution_fraction,
                center.y
                    + radial_scale * (major.y * angle.cos() + minor.y * angle.sin())
                    + pitch.y * revolution_fraction,
                center.z
                    + radial_scale * (major.z * angle.cos() + minor.z * angle.sin())
                    + pitch.z * revolution_fraction,
            );
            let surface_point = crate::test_support::with_service_context(|ctx| {
                zero_entity_surface_point(ctx, &surface, [angle, 1.0 + fraction])
            })
            .expect("evaluator allocation succeeds")
            .expect("finite cone point");
            assert!((construction_point.x - surface_point.x).abs() < 1.0e-12);
            assert!((construction_point.y - surface_point.y).abs() < 1.0e-12);
            assert!((construction_point.z - surface_point.z).abs() < 1.0e-12);
        }
    }

    #[test]
    fn negative_cone_latitude_radius_flips_the_circle_reference_direction() {
        use cadmpeg_ir::math::Vector3;

        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                1.0,
                1.0,
                std::f64::consts::FRAC_PI_4,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let endpoints = [[0.0, -2.0], [1.0, -2.0]];
        let pcurve = test_pcurve(
            endpoints
                .map(|[u, v]| Point2::new(u, v))
                .into_iter()
                .collect(),
        );
        let (curve, parameters) = zero_entity_model_curve(
            &surface,
            &pcurve,
            endpoints,
            &"test support record",
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("cone latitude");
        for index in 0..2 {
            let curve_point = cadmpeg_ir::eval::decode::curve_point(
                cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                &curve,
                parameters[index].get(),
            )
            .expect("circle point");
            let surface_point = crate::test_support::with_service_context(|ctx| {
                zero_entity_surface_point(ctx, &surface, endpoints[index])
            })
            .expect("evaluator allocation succeeds")
            .expect("cone point");
            assert!((curve_point.x - surface_point.x).abs() < 1.0e-12);
            assert!((curve_point.y - surface_point.y).abs() < 1.0e-12);
            assert!((curve_point.z - surface_point.z).abs() < 1.0e-12);
        }
    }

    #[test]
    fn zero_entity_model_curve_refuses_unrepresentable_circle_parameters() {
        use cadmpeg_ir::math::Vector3;

        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                f64::from_bits(1),
            )
            .expect("finite positive radius"),
        ));
        let endpoints = [[0.0, 0.0], [1.0, 0.0]];
        let pcurve = test_pcurve(vec![Point2::new(0.0, 0.0), Point2::new(1.0, 0.0)]);
        assert!(zero_entity_model_curve(
            &surface,
            &pcurve,
            endpoints,
            &"test support record",
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .is_none());
    }

    #[test]
    fn analytic_support_endpoints_use_native_surface_charts() {
        use cadmpeg_ir::math::Vector3;

        let origin = Point3::new(0.0, 0.0, 0.0);
        let x = Vector3::new(1.0, 0.0, 0.0);
        let z = Vector3::new(0.0, 0.0, 1.0);
        let cylinder = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(origin, z, x, 2.0)
                .expect("valid CylinderSurface fixture"),
        ));
        let cone = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                origin,
                z,
                x,
                2.0,
                1.0,
                std::f64::consts::FRAC_PI_4,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let torus = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(
            cadmpeg_ir::geometry::analytic::TorusSurface::try_new(origin, z, x, 4.0, 2.0)
                .expect("valid TorusSurface fixture"),
        ));

        let cylinder_point = crate::test_support::with_service_context(|ctx| {
            zero_entity_surface_point(ctx, &cylinder, [std::f64::consts::PI, 3.0])
        })
        .expect("evaluator allocation succeeds")
        .expect("cylinder");
        let cone_point = crate::test_support::with_service_context(|ctx| {
            zero_entity_surface_point(ctx, &cone, [std::f64::consts::FRAC_PI_2, 3.0])
        })
        .expect("evaluator allocation succeeds")
        .expect("cone");
        let torus_point = crate::test_support::with_service_context(|ctx| {
            zero_entity_surface_point(
                ctx,
                &torus,
                [2.0 * std::f64::consts::PI, std::f64::consts::PI],
            )
        })
        .expect("evaluator allocation succeeds")
        .expect("torus");

        assert!(cylinder_point.x.abs() < 1.0e-12);
        assert!((cylinder_point.y - 2.0).abs() < 1.0e-12);
        assert_eq!(cylinder_point.z, 3.0);
        assert!(cone_point.x.abs() < 1.0e-12);
        assert!((cone_point.y - (2.0 + 3.0 / 2.0_f64.sqrt())).abs() < 1.0e-12);
        assert!((cone_point.z - 3.0 / 2.0_f64.sqrt()).abs() < 1.0e-12);
        assert!(torus_point.x.abs() < 1.0e-12);
        assert!((torus_point.y - 4.0).abs() < 1.0e-12);
        assert_eq!(torus_point.z, 2.0);
    }

    #[test]
    fn support_pcurve_conversion_uses_the_neutral_surface_chart() {
        use cadmpeg_ir::math::Vector3;

        let pcurve = test_pcurve(vec![Point2::new(2.0, 3.0), Point2::new(4.0, 5.0)]);
        let cylinder = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
            )
            .expect("valid CylinderSurface fixture"),
        ));
        assert_eq!(
            zero_entity_neutral_pcurve(
                &cylinder,
                &pcurve,
                &"test support record",
                &mut crate::nurbs::LaneRefusals::new()
            ),
            Some(test_pcurve(vec![
                Point2::new(1.0, 3.0),
                Point2::new(2.0, 5.0),
            ]))
        );

        let cone = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
            cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
                1.0,
                0.25,
            )
            .expect("valid ConeSurface fixture"),
        ));
        let Some(PcurveGeometry::Nurbs { nurbs }) = zero_entity_neutral_pcurve(
            &cone,
            &pcurve,
            &"test support record",
            &mut crate::nurbs::LaneRefusals::new(),
        ) else {
            panic!("neutral cone pcurve")
        };
        assert_eq!(nurbs.control_points()[0].u, 2.0);
        assert_eq!(nurbs.control_points()[0].v, 3.0 * 0.25_f64.cos());

        let torus = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(
            cadmpeg_ir::geometry::analytic::TorusSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                4.0,
                2.0,
            )
            .expect("valid TorusSurface fixture"),
        ));
        let Some(PcurveGeometry::Nurbs { nurbs }) = zero_entity_neutral_pcurve(
            &torus,
            &pcurve,
            &"test support record",
            &mut crate::nurbs::LaneRefusals::new(),
        ) else {
            panic!("neutral torus pcurve")
        };
        assert_eq!(nurbs.control_points()[1], Point2::new(1.0, 2.5));
    }

    #[test]
    fn analytic_carriers_have_no_model_size_cutoff() {
        let mut cylinder = vec![0_u8; 89];
        cylinder[33..41].copy_from_slice(&1.0_f64.to_le_bytes());
        cylinder[65..73].copy_from_slice(&1.0_f64.to_le_bytes());
        cylinder[81..89].copy_from_slice(&2_000_000.0_f64.to_le_bytes());
        assert!(
            matches!(zero_entity_cylinder(&cylinder), Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)))
                if { cylinder_surface.radius().get() == 2_000_000.0 })
        );

        let mut cone = vec![0_u8; 120];
        cone[32..40].copy_from_slice(&1.0_f64.to_le_bytes());
        cone[96..104].copy_from_slice(&1.0_f64.to_le_bytes());
        cone[104..112].copy_from_slice(&std::f64::consts::FRAC_PI_4.to_le_bytes());
        cone[112..120].copy_from_slice(&2_000_000.0_f64.to_le_bytes());
        assert!(
            matches!(zero_entity_cone(&cone), Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)))
                if { cone_surface.radius().get() == 2_000_000.0 })
        );

        let mut torus = vec![0_u8; 120];
        torus[32..40].copy_from_slice(&1.0_f64.to_le_bytes());
        torus[96..104].copy_from_slice(&1.0_f64.to_le_bytes());
        torus[104..112].copy_from_slice(&2_000_000.0_f64.to_le_bytes());
        torus[112..120].copy_from_slice(&1_500_000.0_f64.to_le_bytes());
        assert!(
            matches!(zero_entity_torus(&torus), Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)))
            if {
                (torus_surface.major_radius().get() == 2_000_000.0)
                    && (torus_surface.minor_radius().get() == 1_500_000.0)
            })
        );
    }

    #[test]
    fn oriented_endpoint_tape_closes_one_missing_occurrence() {
        let finite = |point| FinitePoint3::new(point).expect("finite test endpoint");
        let first = finite(Point3::new(1.0, 0.0, 0.0));
        let second = finite(Point3::new(0.0, 1.0, 0.0));
        let third = finite(Point3::new(0.0, 0.0, 1.0));
        let endpoints = [Some([first, second]), Some([third, second]), None];

        assert_eq!(
            oriented_closed_model_endpoints(&endpoints, &[true, false, true]),
            Some(vec![[first, second], [second, third], [third, first],])
        );
        assert!(oriented_closed_model_endpoints(&[endpoints[0], None, None], &[true; 3]).is_none());
        assert!(oriented_closed_model_endpoints(
            &[
                Some([first, second]),
                Some([finite(Point3::new(1.0, 1.0, 0.0)), first]),
            ],
            &[true; 2],
        )
        .is_none());
    }

    #[test]
    fn malformed_support_invalidates_its_structural_run() {
        let mut stream = zero_entity_support_stream();
        stream[0x6a + 12 + 12] = 0;
        assert!(zero_entity_support_runs(&stream).is_empty());
    }

    #[test]
    fn record_walk_skips_complete_logical_support_continuations() {
        let fixture = zero_entity_support_stream();
        let plane = &fixture[..0x6a + 12];
        let mut support = support_pcurve_record(0x45);
        support[13..17].copy_from_slice(&42u32.to_le_bytes());
        support[200..204].copy_from_slice(&[0xa9, 0x03, 0x27, 0x6a]);

        let mut stream = plane.to_vec();
        stream.extend(support);
        stream.extend(plane);

        assert_eq!(zero_entity_surfaces(&stream).len(), 2);
        let runs = zero_entity_support_runs(&stream);
        let [run] = runs.as_slice() else {
            panic!("one support run")
        };
        assert_eq!(run.supports.len(), 1);
        assert_eq!(run.supports[0].tag, [0x21, 0x45]);
    }

    #[test]
    fn malformed_extended_carrier_stops_before_its_unbounded_continuation() {
        let fixture = zero_entity_support_stream();
        let plane = &fixture[..0x6a + 12];
        let mut stream = vec![0u8; 0xc8 + 12];
        stream[..4].copy_from_slice(&[0xa9, 0x03, 0x34, 0xc8]);
        stream[80..80 + plane.len()].copy_from_slice(plane);
        stream.extend(plane);

        assert!(zero_entity_record_inventory(&stream).is_empty());
        assert!(zero_entity_surfaces(&stream).is_empty());
    }

    #[test]
    fn ownership_root_extends_the_counted_face_roster_and_binds_shell_and_body() {
        let stream = zero_entity_ownership_stream(62);
        let records = zero_entity_record_inventory(&stream);
        assert_eq!(records.len(), 3);
        assert_eq!(records[0].tag, [0x61, 0x42]);
        assert_eq!(records[0].end, 13 + 62 * 5 + 11);
        assert_eq!(records[0].end, records[1].pos);

        let root = zero_entity_ownership_root(&stream).expect("complete ownership root");
        assert_eq!(root.face_roster_record_ordinal, 1);
        assert_eq!(root.face_slots, (1..=62).rev().collect::<Vec<_>>());
        assert_eq!(root.shell_record_ordinal().expect("shell ordinal fits"), 2);
        assert_eq!(root.body_record_ordinal().expect("body ordinal fits"), 3);
    }

    #[test]
    fn ownership_root_refuses_overflowed_shell_and_body_ordinals() {
        let mut root = zero_entity_ownership_root(&zero_entity_ownership_stream(1))
            .expect("complete ownership root");
        root.face_roster_record_ordinal = u32::MAX - 1;
        assert!(format!("{:?}", root.body_record_ordinal()).starts_with("Err("));
        root.face_roster_record_ordinal = u32::MAX;
        assert!(format!("{:?}", root.shell_record_ordinal()).starts_with("Err("));
    }

    #[test]
    fn ownership_root_requires_one_complete_candidate_for_unique_selection() {
        let first = zero_entity_ownership_stream(3);
        let mut stream = first.clone();
        stream.extend(first);

        let roots = zero_entity_ownership_roots(&stream);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].face_roster_record_ordinal, 1);
        assert_eq!(roots[1].face_roster_record_ordinal, 4);
        assert!(zero_entity_ownership_root(&stream).is_none());
    }

    #[test]
    fn ownership_root_rejects_noncanonical_face_allocations_atomically() {
        let mut stream = zero_entity_ownership_stream(3);
        write_tagged_u32(&mut stream, 13, 2);
        assert!(zero_entity_record_inventory(&stream).is_empty());
        assert!(zero_entity_ownership_root(&stream).is_none());
    }

    #[test]
    fn topology_records_retain_global_ordinals_and_separate_namespaces() {
        let stream = zero_entity_topology_stream();
        let edge_strides = zero_entity_edge_strides(&stream);
        let [edge_stride] = edge_strides.as_slice() else {
            panic!("one edge stride")
        };
        assert_eq!(edge_stride.record_ordinal, 1);
        assert_eq!(edge_stride.allocations, [5, 7, 8, 4, 3]);

        let pairs = zero_entity_oriented_use_pairs(&stream);
        let [pair] = pairs.as_slice() else {
            panic!("one oriented-use pair")
        };
        assert_eq!(pair.header_record_ordinal, 2);
        assert_eq!(pair.base_columns, [100, 200]);
        assert_eq!(ZeroEntityUseSlot::First.side(), 1);
        assert_eq!(ZeroEntityUseSlot::Second.side(), 2);
        assert_eq!(pair.uses[0].record_ordinal, 3);
        assert_eq!(pair.allocations(ZeroEntityUseSlot::First), [101, 201]);
        assert_eq!(pair.uses[1].record_ordinal, 4);
        assert_eq!(pair.allocations(ZeroEntityUseSlot::Second), [102, 202]);

        let incidences = zero_entity_vertex_incidences(&stream);
        let [incidence] = incidences.as_slice() else {
            panic!("one vertex incidence")
        };
        assert_eq!(incidence.record_ordinal, 5);
        assert_eq!(incidence.tag(), [0x05, 0x10]);
        assert_eq!(incidence.allocations.as_slice(), &[1, 2, 5]);
    }

    #[test]
    fn vertex_incidence_requires_the_complete_adjacent_owner_production() {
        for owner_offset in [7usize, 12, 17] {
            let mut stream = zero_entity_topology_stream();
            let owner = zero_entity_records(&stream)[5];
            stream[owner.pos + owner_offset] ^= 1;
            assert!(zero_entity_vertex_incidences(&stream).is_empty());
        }
    }

    #[test]
    fn oriented_use_pair_requires_adjacent_ordered_sides() {
        let mut stream = zero_entity_topology_stream();
        let second_use = 38 + (0x69 + 12) + (0x38 + 12);
        write_tagged_u32(&mut stream, second_use + 13, 1);
        assert!(zero_entity_oriented_use_pairs(&stream).is_empty());
    }

    #[test]
    fn oriented_use_allocations_must_extend_the_header_columns() {
        let mut stream = zero_entity_topology_stream();
        let first_use = 38 + 0x69 + 12;
        write_tagged_u32(&mut stream, first_use + 18, 102);
        assert!(zero_entity_oriented_use_pairs(&stream).is_empty());
    }

    #[test]
    fn topology_allocation_lanes_are_not_global_record_ordinals() {
        let mut stream = zero_entity_topology_stream();
        let header = 38;
        let second_use = header + (0x69 + 12) + (0x38 + 12);
        let incidence = second_use + 0x38 + 12;
        for (offset, value) in [
            (incidence + 13, 105),
            (incidence + 18, 106),
            (incidence + 23, 107),
        ] {
            write_tagged_u32(&mut stream, offset, value);
        }

        let pairs = zero_entity_oriented_use_pairs(&stream);
        let [pair] = pairs.as_slice() else {
            panic!("one oriented-use pair")
        };
        assert_eq!(pair.allocations(ZeroEntityUseSlot::First), [101, 201]);
        assert_eq!(pair.allocations(ZeroEntityUseSlot::Second), [102, 202]);
        let incidences = zero_entity_vertex_incidences(&stream);
        let [incidence] = incidences.as_slice() else {
            panic!("one vertex incidence")
        };
        assert_eq!(incidence.allocations.as_slice(), &[105, 106, 107]);
    }

    #[test]
    fn edge_stride_requires_its_fixed_tagged_one_prefix() {
        let mut stream = zero_entity_topology_stream();
        write_tagged_u32(&mut stream, 7, 2);
        assert!(zero_entity_edge_strides(&stream).is_empty());
    }

    #[test]
    fn edge_stride_rejects_a_zero_allocation() {
        let mut stream = zero_entity_topology_stream();
        write_tagged_u32(&mut stream, 12, 0);
        assert!(zero_entity_edge_strides(&stream).is_empty());
    }

    #[test]
    fn edge_stride_requires_its_descending_terminal_tail() {
        let mut stream = zero_entity_topology_stream();
        write_tagged_u32(&mut stream, 27, 3);
        assert!(zero_entity_edge_strides(&stream).is_empty());
    }

    #[test]
    fn complete_face_roster_aligns_to_surface_support_runs() {
        let stream = zero_entity_face_support_stream();
        let runs = zero_entity_support_runs(&stream);
        let [run] = runs.as_slice() else {
            panic!("one support run")
        };
        let face = run.face.as_ref().expect("positionally aligned face");
        assert_eq!(face.record_ordinal, 3);
        assert_eq!(face.tag, [0x5f, 0x0c]);
        assert_eq!(face.allocations, [10, 3]);
        assert_eq!(face.loop_terminals(), [7]);
        assert_eq!(face.terminal_control, ZeroEntityFaceControl::Control05);
    }

    #[test]
    fn face_roster_admits_only_the_two_terminal_controls() {
        for control in [0x03, 0x05] {
            let mut stream = zero_entity_face_support_stream();
            *stream.last_mut().expect("face terminal") = control;
            assert_eq!(
                zero_entity_support_runs(&stream)[0]
                    .face
                    .as_ref()
                    .expect("admitted face")
                    .terminal_control
                    .as_byte(),
                control
            );
        }

        let mut stream = zero_entity_face_support_stream();
        *stream.last_mut().expect("face terminal") = 0x04;
        assert!(zero_entity_support_runs(&stream)[0].face.is_none());
    }

    #[test]
    fn face_roster_requires_nonzero_allocation_lanes() {
        for allocation_offset in [13usize, 18] {
            let mut stream = zero_entity_face_support_stream();
            let face = zero_entity_records(&stream)[2];
            write_tagged_u32(&mut stream, face.pos + allocation_offset, 0);
            assert!(zero_entity_support_runs(&stream)[0].face.is_none());
        }
    }

    #[test]
    fn face_roster_requires_positive_loop_terminals() {
        let mut stream = zero_entity_face_support_stream();
        let face = zero_entity_records(&stream)[2];
        write_tagged_u32(&mut stream, face.pos + 18, 10);
        assert!(zero_entity_support_runs(&stream)[0].face.is_none());
    }

    #[test]
    fn mismatched_face_roster_does_not_partially_bind_support_runs() {
        let mut stream = zero_entity_face_support_stream();
        let face = stream[stream.len() - (0x0c + 12)..].to_vec();
        stream.extend(face);
        let runs = zero_entity_support_runs(&stream);
        let [run] = runs.as_slice() else {
            panic!("one support run")
        };
        assert!(run.face.is_none());
    }

    #[test]
    fn independently_incomplete_rosters_do_not_shift_face_bindings() {
        let mut stream = zero_entity_support_stream();
        stream[38..62].fill(0);
        stream.extend(zero_entity_support_stream());

        let face_stream = zero_entity_face_support_stream();
        let face_start = zero_entity_support_stream().len();
        let valid_face = face_stream[face_start..].to_vec();
        stream.extend_from_slice(&valid_face);
        let mut invalid_face = valid_face;
        *invalid_face.last_mut().expect("face terminal") = 0x04;
        stream.extend(invalid_face);

        let runs = zero_entity_support_runs(&stream);
        let [run] = runs.as_slice() else {
            panic!("one complete support run")
        };
        assert_eq!(run.carrier_record_ordinal, 3);
        assert!(run.face.is_none());
    }

    #[test]
    fn complete_loop_roster_aligns_to_face_terminals() {
        let runs = zero_entity_support_runs(&zero_entity_face_loop_support_stream());
        let [run] = runs.as_slice() else {
            panic!("one support run")
        };
        let face = run.face.as_ref().expect("face");
        let [loop_record] = face.loops.as_deref().unwrap_or(&[]) else {
            panic!("one loop")
        };
        assert_eq!(loop_record.record_ordinal, 4);
        assert_eq!(loop_record.tag, [0x62, 0x14]);
        assert_eq!(loop_record.members.member_ids().collect::<Vec<_>>(), [6]);
        assert_eq!(loop_record.edge_stride_distances, [1]);
        assert_eq!(loop_record.members.terminal_id(), 7);
        assert_eq!(loop_record.members.gap(), 1);
        assert_eq!(loop_record.loop_class.as_byte(), 0x41);
        assert_eq!(loop_record.forward_senses, [true]);
        assert!(loop_record.support_record_ordinals.is_empty());
    }

    #[test]
    fn face_orientation_must_agree_with_outer_loop_class() {
        let mut stream = zero_entity_face_loop_support_stream();
        let records = zero_entity_records(&stream);
        let loop_record = records.iter().find(|r| r.tag[0] == 0x62).expect("loop");
        let face_record = records.iter().find(|r| r.tag[0] == 0x5f).expect("face");
        stream[face_record.end - 1] = 0x03;
        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("retained face");
        assert!(face.loops.is_none(), "contradictory orientation is unbound");
        stream[loop_record.end - 3] = 0xc1;
        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("retained negative face");
        assert_eq!(face.terminal_control.as_byte(), 0x03);
        assert_eq!(
            face.loops.as_ref().expect("matching negative outer loop")[0]
                .loop_class
                .as_byte(),
            0xc1
        );
    }

    #[test]
    fn loop_roster_requires_one_leading_outer_loop() {
        let mut stream = zero_entity_face_loop_support_stream();
        let loop_record = zero_entity_records(&stream)[3];
        stream[loop_record.end - 3] = 0x50;
        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("face");
        assert!(face.loops.is_none());
    }

    #[test]
    fn face_roster_requires_strictly_ascending_inner_terminals() {
        let mut stream = zero_entity_support_stream();
        let mut face = vec![0u8; 0x16 + 12];
        face[..4].copy_from_slice(&[0xa9, 0x03, 0x5f, 0x16]);
        write_tagged_u32(&mut face, 7, 1);
        face[12] = 0x84;
        for (index, allocation) in [20, 13, 10, 11].into_iter().enumerate() {
            write_tagged_u32(&mut face, 13 + index * 5, allocation);
        }
        face[33] = 0x05;
        stream.extend(face);
        for (terminal, class) in [(7, 0x41), (10, 0x50), (9, 0x50)] {
            let mut loop_record = vec![0u8; 0x14 + 12];
            loop_record[..4].copy_from_slice(&[0xa9, 0x03, 0x62, 0x14]);
            loop_record[12] = 0x83;
            for (index, value) in [terminal - 1, 1, terminal].into_iter().enumerate() {
                write_tagged_u32(&mut loop_record, 13 + index * 5, value);
            }
            loop_record[28..].copy_from_slice(&[0x81, class, 0x07, 0x01]);
            stream.extend(loop_record);
        }

        let runs = zero_entity_support_runs(&stream);
        assert!(runs[0].face.is_none());
    }

    #[test]
    fn loop_member_lane_must_remain_strictly_below_its_terminal() {
        let mut stream = zero_entity_face_loop_support_stream();
        let loop_record = zero_entity_records(&stream)[3];
        write_tagged_u32(&mut stream, loop_record.pos + 23, 6);
        assert!(zero_entity_loops_from_records(&stream, &zero_entity_records(&stream)).is_empty());
    }

    #[test]
    fn loop_typed_lane_requires_one_based_record_references() {
        let mut stream = zero_entity_face_loop_support_stream();
        let loop_record = zero_entity_records(&stream)[3];
        write_tagged_u32(&mut stream, loop_record.pos + 18, 0);
        assert!(zero_entity_loops_from_records(&stream, &zero_entity_records(&stream)).is_empty());
    }

    #[test]
    fn support_occurrence_requires_a_nonzero_face_local_slot() {
        let mut stream = zero_entity_face_support_stream();
        let support = zero_entity_records(&stream)[1];
        stream[support.pos + 13..support.pos + 17].copy_from_slice(&0u32.to_le_bytes());
        assert!(zero_entity_support_occurrence(
            &stream,
            support,
            &mut crate::nurbs::LaneRefusals::new()
        )
        .is_none());
    }

    #[test]
    fn loop_members_bind_unique_face_local_support_slots() {
        let mut stream = zero_entity_face_loop_support_stream();
        let support_slot = 0x6a + 12 + 13;
        stream[support_slot..support_slot + 4].copy_from_slice(&1u32.to_le_bytes());

        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("face");
        assert_eq!(
            face.loops.as_ref().expect("aligned loops")[0].support_record_ordinals,
            [2]
        );
    }

    #[test]
    fn loop_support_binding_rejects_duplicate_face_local_slots_atomically() {
        let mut stream = zero_entity_face_loop_support_stream();
        let carrier_length = 0x6a + 12;
        let support_length = 0x71 + 12;
        let support = stream[carrier_length..carrier_length + support_length].to_vec();
        stream.splice(
            carrier_length + support_length..carrier_length + support_length,
            support,
        );
        let support_slot = carrier_length + 13;
        stream[support_slot..support_slot + 4].copy_from_slice(&1u32.to_le_bytes());
        let duplicate_slot = carrier_length + support_length + 13;
        stream[duplicate_slot..duplicate_slot + 4].copy_from_slice(&1u32.to_le_bytes());

        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("face");
        assert!(face.loops.as_ref().expect("aligned loops")[0]
            .support_record_ordinals
            .is_empty());
    }

    #[test]
    fn invalid_loop_tape_does_not_partially_bind_faces() {
        let mut stream = zero_entity_face_loop_support_stream();
        *stream.last_mut().expect("loop terminator") = 0;
        let runs = zero_entity_support_runs(&stream);
        let face = runs[0].face.as_ref().expect("face");
        assert!(face.loops.is_none());
    }

    #[test]
    fn zero_entity_model_curve_lifts_an_isocurve_on_a_degree_16_surface() {
        use cadmpeg_ir::geometry::nurbs::{NurbsSurface, NurbsSurfaceAxis, NurbsSurfaceLanes};
        let fixed_degree = 16;
        let fixed_poles = fixed_degree + 1;
        let mut fixed_knots = vec![0.0; fixed_poles];
        fixed_knots.extend(vec![1.0; fixed_poles]);
        let rows = (0..fixed_poles)
            .map(|row| {
                let x = cadmpeg_core::convert::f64_from_index(row)
                    .expect("fixture index is exactly representable");
                vec![Point3::new(x, 0.0, 0.0), Point3::new(x, 1.0, 0.0)]
            })
            .collect();
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
            NurbsSurface::from_lanes(
                NurbsSurfaceAxis::new(16, fixed_knots, false),
                NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
                NurbsSurfaceLanes::new(rows, None),
                false,
            )
            .expect("valid NURBS surface"),
        ));
        let pcurve = test_pcurve(vec![Point2::new(0.5, 0.0), Point2::new(0.5, 1.0)]);
        let endpoints = [[0.5, 0.0], [0.5, 1.0]];
        assert!(zero_entity_model_curve(
            &surface,
            &pcurve,
            endpoints,
            &"test support",
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .is_some());
    }
}
