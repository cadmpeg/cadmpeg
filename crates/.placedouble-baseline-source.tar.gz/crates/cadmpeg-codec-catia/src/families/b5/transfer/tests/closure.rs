// SPDX-License-Identifier: Apache-2.0

use super::super::super::graph::{
    bounded_occurrence_range, edge_pcurve_parameters, pcurve_parameter_domain,
    B5ExtrusionDirectrix, B5ExtrusionSurface, B5Face, B5Graph, B5IncidenceLane, B5LogicalVertex,
    B5Loop, B5LoopMember, B5OffsetSurface, B5ParameterIncidence, B5Pcurve,
    B5PcurveParameterization, B5SupportedSurface, B5SupportedSurfaceParameters, B5Surface,
};
use super::super::edges::{
    b5_edge_support_definition, b5_supports_follow_edge, ordered_subrange,
    orient_b5_supports_to_edge,
};
use super::super::faces::{orient_loop_members, ownership_plan};
use super::super::surfaces::{rational_arc, revolve_nurbs};
use crate::families::b5::graph::vertex_refs::B5VertexRef;
use crate::families::b5::tests::test_loop_members;
use crate::families::b5::tests::test_loop_metadata;
use crate::families::b5::transfer::edges::b5_supports_agree;
use crate::families::b5::transfer::{curve_on_parameter_range, transfer, SurfacePlan};
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve,
    pcurve::{PcurveGeometry, PcurveNurbs},
    CurveGeometry, ProceduralCurveDefinition, SolvedCurveGeometry, SolvedSurfaceGeometry,
    SurfaceGeometry,
};
use cadmpeg_ir::ids::{SurfaceId, UnknownId};
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::topology::BodyKind;
use cadmpeg_ir::AnnotationBuilder;
use std::collections::{BTreeMap, BTreeSet, HashMap};

fn transfer_vertex_tolerances(
    graph: &B5Graph,
    supports: &super::super::B5SupportPlan,
    surfaces: &BTreeMap<u32, SurfacePlan>,
    pcurves: &BTreeMap<u32, (PcurveGeometry, bool, [cadmpeg_ir::scalar::FiniteReal; 2])>,
) -> BTreeMap<usize, cadmpeg_ir::scalar::PositiveReal> {
    crate::test_support::with_service_context(|ctx| {
        super::super::vertices::transfer_vertex_tolerances(ctx, graph, supports, surfaces, pcurves)
    })
    .expect("transfer vertex tolerances")
}

use super::super::referenced_surface_ids;

#[test]
fn affine_curve_ranges_reparameterize_without_changing_geometry() {
    let nurbs = NurbsCurve::from_lanes(
        1,
        vec![10.0, 10.0, 20.0, 20.0],
        vec![Point3::new(1.0, 2.0, 3.0), Point3::new(4.0, 5.0, 6.0)],
        None,
        false,
    )
    .expect("valid affine curve");
    let CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(translated)) = curve_on_parameter_range(
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs.clone())),
        [10.0, 20.0],
        crate::test_support::test_b5::increasing([0.0, 10.0]),
        &"test record",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("equal-span NURBS translation") else {
        unreachable!();
    };
    assert_eq!(translated.knots().as_slice(), [0.0, 0.0, 10.0, 10.0]);
    assert_eq!(translated.control_points(), nurbs.control_points());

    let line = CurveGeometry::Solved(SolvedCurveGeometry::Line(
        cadmpeg_ir::geometry::analytic::LineCurve::try_new(
            Point3::new(10.0, 0.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid LineCurve fixture"),
    ));
    assert_eq!(
        curve_on_parameter_range(
            line,
            [10.0, 20.0],
            crate::test_support::test_b5::increasing([0.0, 10.0]),
            &"test record",
            &mut crate::nurbs::LaneRefusals::new()
        ),
        Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(
            cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                Point3::new(20.0, 0.0, 0.0),
                Vector3::new(1.0, 0.0, 0.0)
            )
            .expect("valid LineCurve fixture")
        )))
    );
    assert_eq!(
        curve_on_parameter_range(
            CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs.clone())),
            [10.0, 20.0],
            crate::test_support::test_b5::increasing([12.0, 18.0]),
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        ),
        Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
            nurbs.clone()
        )))
    );
    let CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(scaled)) = curve_on_parameter_range(
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs)),
        [10.0, 20.0],
        crate::test_support::test_b5::increasing([0.0, 2.0]),
        &"test record",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("positive affine NURBS mapping") else {
        unreachable!();
    };
    assert_eq!(scaled.knots().as_slice(), [0.0, 0.0, 2.0, 2.0]);
    assert_eq!(
        curve_on_parameter_range(
            CurveGeometry::Solved(SolvedCurveGeometry::Line(
                cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                    Point3::new(10.0, 0.0, 0.0),
                    Vector3::new(1.0, 0.0, 0.0)
                )
                .expect("valid LineCurve fixture")
            )),
            [10.0, 20.0],
            crate::test_support::test_b5::increasing([0.0, 2.0]),
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        ),
        Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
            NurbsCurve::from_lanes(
                1,
                vec![0.0, 0.0, 2.0, 2.0],
                vec![Point3::new(20.0, 0.0, 0.0), Point3::new(30.0, 0.0, 0.0)],
                None,
                false,
            )
            .expect("valid NurbsCurve fixture")
        )))
    );
}

#[test]
fn wide_affine_nurbs_range_maps_finite_exterior_knots() {
    let curve = NurbsCurve::from_lanes(
        1,
        vec![-0.01, 0.0, 1.0, 1.01],
        vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
        None,
        false,
    )
    .expect("finite NURBS with exterior knots");
    let CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(mapped)) = curve_on_parameter_range(
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve)),
        [0.0, 1.0],
        crate::test_support::test_b5::increasing([-9.0e307, 9.0e307]),
        &"wide interval",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("wide target maps finite exterior knots") else {
        panic!("NURBS carrier");
    };
    let knots = mapped.knots().as_slice();
    assert!(knots.iter().all(|knot| knot.is_finite()));
    assert!((knots[0] / 9.0e307 + 1.02).abs() <= 4.0 * f64::EPSILON);
    assert_eq!(&knots[1..3], &[-9.0e307, 9.0e307]);
    assert!((knots[3] / 9.0e307 - 1.02).abs() <= 4.0 * f64::EPSILON);
}

#[test]
fn tiny_affine_nurbs_range_maps_when_scale_ratio_overflows() {
    let tiny = f64::MIN_POSITIVE / 4.0;
    let curve = NurbsCurve::from_lanes(
        1,
        vec![0.0, 0.0, tiny, tiny],
        vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
        None,
        false,
    )
    .expect("finite NURBS with a tiny domain");
    let CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(mapped)) = curve_on_parameter_range(
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve)),
        [0.0, tiny],
        crate::test_support::test_b5::increasing([0.0, 1.0]),
        &"tiny interval",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("finite target despite overflowing scale ratio") else {
        panic!("NURBS carrier");
    };
    assert_eq!(mapped.knots().as_slice(), [0.0, 0.0, 1.0, 1.0]);
}

#[test]
fn wide_affine_line_range_keeps_finite_endpoints() {
    let line = cadmpeg_ir::geometry::analytic::LineCurve::try_new(
        Point3::new(0.0, 0.0, 0.0),
        Vector3::new(1.0, 0.0, 0.0),
    )
    .expect("finite line");
    let CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(mapped)) = curve_on_parameter_range(
        CurveGeometry::Solved(SolvedCurveGeometry::Line(line)),
        [0.0, 1.0],
        crate::test_support::test_b5::increasing([-f64::MAX, f64::MAX]),
        &"wide interval",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("wide line range keeps its finite endpoint points") else {
        panic!("NURBS line carrier");
    };
    assert_eq!(
        mapped.knots().as_slice(),
        [-f64::MAX, -f64::MAX, f64::MAX, f64::MAX]
    );
    assert_eq!(
        mapped.control_points(),
        vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)]
    );
}

#[test]
fn explicit_pcurve_range_must_be_a_subrange_of_its_knot_domain() {
    let mut pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 10.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([1.0, 0.0]),
        ],
        weights: None,
        parameter_range: Some(crate::test_support::test_b5::finite_pair([2.0, 8.0])),
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    assert_eq!(
        pcurve_parameter_domain(&pcurve),
        Some(crate::test_support::test_b5::finite_pair([2.0, 8.0]))
    );
    pcurve.parameter_range = None;
    assert_eq!(
        pcurve_parameter_domain(&pcurve),
        Some(crate::test_support::test_b5::finite_pair([0.0, 10.0]))
    );
    pcurve.parameter_range = Some(crate::test_support::test_b5::finite_pair([-1.0, 8.0]));
    assert_eq!(pcurve_parameter_domain(&pcurve), None);
}

#[test]
fn support_bound_surface_closure_includes_carrier_supports_and_offsets() {
    let offsets = BTreeMap::from([(
        30,
        B5OffsetSurface {
            object_id: 30,
            carrier_surface: 31,
            source_surface: 50,
            distance: crate::test_support::test_b5::finite(1.0),
            carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Extrusion,
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [0.0, 1.0],
                [0.0, 1.0],
            ]),
        },
    )]);
    let supported = BTreeMap::from([(
        10,
        B5SupportedSurface {
            object_id: 10,
            carrier_surface: 20,
            support_surfaces: [30, 40],
            support_pcurves: [60, 70],
            parameters: B5SupportedSurfaceParameters::Radius {
                controls: [1; 6],
                construction_radius: crate::test_support::test_b5::positive_length(2.0),
            },
        },
    )]);
    let extrusions = BTreeMap::from([(
        50,
        B5ExtrusionSurface {
            object_id: 50,
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [0.0, 1.0],
                [0.0, 2.0],
            ]),
            directrix: B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 80,
                support: (
                    90,
                    91,
                    crate::test_support::test_b5::finite_pair([0.0, 1.0]),
                ),
                parameter_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
            },
        },
    )]);

    assert_eq!(
        referenced_surface_ids([10], &offsets, &supported, &extrusions, &BTreeMap::new(),),
        BTreeSet::from([10, 20, 30, 31, 40, 50, 90])
    );
}

#[test]
fn surface_closure_follows_aliases_to_native_constructions() {
    let offsets = BTreeMap::from([(
        20,
        B5OffsetSurface {
            object_id: 20,
            carrier_surface: 30,
            source_surface: 40,
            distance: crate::test_support::test_b5::finite(2.0),
            carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Plane,
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [0.0, 1.0],
                [0.0, 2.0],
            ]),
        },
    )]);
    let aliases = BTreeMap::from([(10, 11), (11, 20)]);

    assert_eq!(
        referenced_surface_ids([10], &offsets, &BTreeMap::new(), &BTreeMap::new(), &aliases,),
        BTreeSet::from([10, 30, 40])
    );
}

#[test]
fn occurrence_interval_orders_and_bounds_native_stations() {
    assert_eq!(
        ordered_subrange(
            crate::test_support::test_b5::finite_pair([8.0, 2.0]),
            crate::test_support::test_b5::finite_pair([0.0, 10.0])
        ),
        Some(crate::test_support::test_b5::finite_pair([2.0, 8.0]))
    );
    assert_eq!(
        ordered_subrange(
            crate::test_support::test_b5::finite_pair([-5e-10, 10.0 + 5e-10]),
            crate::test_support::test_b5::finite_pair([0.0, 10.0])
        ),
        Some(crate::test_support::test_b5::finite_pair([0.0, 10.0]))
    );
    assert!(ordered_subrange(
        crate::test_support::test_b5::finite_pair([2.0, 2.0]),
        crate::test_support::test_b5::finite_pair([0.0, 10.0])
    )
    .is_none());
    assert!(ordered_subrange(
        crate::test_support::test_b5::finite_pair([-2e-9, 8.0]),
        crate::test_support::test_b5::finite_pair([0.0, 10.0])
    )
    .is_none());
    assert!(ordered_subrange(
        crate::test_support::test_b5::finite_pair([2.0, 12.0]),
        crate::test_support::test_b5::finite_pair([0.0, 10.0])
    )
    .is_none());
    assert_eq!(
        bounded_occurrence_range(
            crate::test_support::test_b5::finite_pair([8.0, 2.0]),
            crate::test_support::test_b5::finite_pair([0.0, 10.0])
        ),
        Some(crate::test_support::test_b5::finite_pair([8.0, 2.0]))
    );

    let tiny = 1e-200_f64;
    assert_eq!(
        bounded_occurrence_range(
            crate::test_support::test_b5::finite_pair([0.0, tiny]),
            crate::test_support::test_b5::finite_pair([0.0, tiny])
        ),
        Some(crate::test_support::test_b5::finite_pair([0.0, tiny]))
    );
    assert!(bounded_occurrence_range(
        crate::test_support::test_b5::finite_pair([0.0, 2.0 * tiny]),
        crate::test_support::test_b5::finite_pair([0.0, tiny])
    )
    .is_none());
    assert!(bounded_occurrence_range(
        crate::test_support::test_b5::finite_pair([0.0, tiny]),
        crate::test_support::test_b5::finite_pair([tiny, 0.0])
    )
    .is_none());
}

#[test]
fn edge_parameters_follow_ordered_edge_refs_for_a_closed_vertex() {
    let mut graph = B5Graph {
        complete: false,
        faces: Vec::new(),
        face_records: BTreeMap::new(),
        loops: BTreeMap::new(),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::new(),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::from([
            (
                40,
                B5ParameterIncidence {
                    object_id: 40,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(0.0),
                        control: 0,
                    }],
                },
            ),
            (
                41,
                B5ParameterIncidence {
                    object_id: 41,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(1.0),
                        control: 0,
                    }],
                },
            ),
        ]),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            vec![B5LogicalVertex {
                object_id: 50,
                point: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
            }],
            BTreeMap::from([(30, [B5VertexRef::Logical(0), B5VertexRef::Logical(0)])]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::from([(30, [40, 41])]),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };

    assert_eq!(
        edge_pcurve_parameters(&graph, 30, 20),
        Some(crate::test_support::test_b5::finite_pair([0.0, 1.0]))
    );
    graph.edge_parameter_incidences.insert(30, [41, 40]);
    assert_eq!(
        edge_pcurve_parameters(&graph, 30, 20),
        Some(crate::test_support::test_b5::finite_pair([1.0, 0.0]))
    );
}

/// Missing geometry cannot turn a closed source population into a recovered
/// sheet by discarding one of the two face occurrences on each shared edge.
#[test]
fn incomplete_graph_does_not_publish_a_partial_face_body() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream_with_native_vertex_chain();
    let mut graph = crate::test_support::with_service_context(|ctx| {
        super::super::super::graph::parse(ctx, &bytes, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("service decode")
    .expect("complete native identity graph");
    let mut second_face = graph.faces[0].clone();
    second_face.object_id += 1;
    let first_loop = graph.faces[0].loops[0];
    let mut second_loop = graph.loops[&first_loop].clone();
    second_loop.object_id += 1;
    second_face.loops = vec![second_loop.object_id];
    graph.faces.push(second_face);
    graph.loops.insert(second_loop.object_id, second_loop);
    assert_eq!(
        crate::test_support::with_service_context(|ctx| ownership_plan(ctx, &graph))
            .expect("service decode")
            .expect("the complete population has unique loop ownership")
            .body_kind,
        BodyKind::Solid
    );
    graph
        .loops
        .get_mut(&(first_loop + 1))
        .expect("second loop")
        .members[0]
        .pcurve += 1_000;
    graph.complete = false;
    assert!(
        crate::test_support::with_service_context(|ctx| ownership_plan(ctx, &graph))
            .expect("service decode")
            .is_none()
    );
    let mut ir = CadIr::empty();
    let transferred = crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        transfer(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &graph,
            &UnknownId::mint("catia:test:unknown#partial-population".to_string())
                .expect("identity grammar"),
            &mut crate::nurbs::LaneRefusals::new(),
            &mut admission,
        )
    })
    .expect("service limits admit the source graph");
    assert!(!transferred);
    assert_eq!(ir, CadIr::empty());
}

#[test]
fn repeated_source_pcurve_retains_occurrence_ranges_and_directions() {
    let mut graph = B5Graph {
        complete: true,
        faces: vec![B5Face {
            object_id: 1,
            surface: 10,
            loops: vec![2],
            terminal_control: None,
        }],
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(
            2,
            B5Loop {
                object_id: 2,
                members: test_loop_members(&[20, 20, 20], &[30, 31, 32]),
                metadata: test_loop_metadata(),
                surface: 10,
            },
        )]),
        pcurves: BTreeMap::from([(
            20,
            B5Pcurve {
                object_id: 20,
                surface: 10,
                degree: 1,
                distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
                multiplicities: vec![2, 2],
                control_points: vec![
                    crate::test_support::test_b5::finite_vector([0.0, 0.0]),
                    crate::test_support::test_b5::finite_vector([1.0, 0.0]),
                ],
                weights: None,
                parameter_range: None,
                parameterization: B5PcurveParameterization::Native,
                class_21_suffix_scalar: None,
                lifted_endpoints: None,
            },
        )]),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::from([(
            10,
            B5Surface::Plane {
                origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
                direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
                u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
                v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
            },
        )]),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::from([
            (
                40,
                B5ParameterIncidence {
                    object_id: 40,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(0.0),
                        control: 0,
                    }],
                },
            ),
            (
                41,
                B5ParameterIncidence {
                    object_id: 41,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(0.5),
                        control: 0,
                    }],
                },
            ),
            (
                42,
                B5ParameterIncidence {
                    object_id: 42,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(1.0),
                        control: 0,
                    }],
                },
            ),
        ]),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            vec![
                B5LogicalVertex {
                    object_id: 50,
                    point: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                },
                B5LogicalVertex {
                    object_id: 51,
                    point: crate::test_support::test_b5::point([0.5, 0.0, 0.0]),
                },
                B5LogicalVertex {
                    object_id: 52,
                    point: crate::test_support::test_b5::point([1.0, 0.0, 0.0]),
                },
            ],
            BTreeMap::from([
                (30, [B5VertexRef::Logical(0), B5VertexRef::Logical(1)]),
                (31, [B5VertexRef::Logical(1), B5VertexRef::Logical(2)]),
                (32, [B5VertexRef::Logical(2), B5VertexRef::Logical(0)]),
            ]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::from([(30, [40, 41]), (31, [41, 42]), (32, [42, 40])]),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };
    graph.loops.get_mut(&2).expect("required loop").members[1].controls[2] = -1;
    let mut ir = CadIr::empty();

    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        assert!(transfer(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &graph,
            &UnknownId::mint("catia:test:unknown#catia:test-payload".to_string())
                .expect("identity grammar"),
            &mut crate::nurbs::LaneRefusals::new(),
            &mut admission,
        )
        .expect("transfer the B5 topology"));
    });
    assert_eq!(ir.geometry.pcurves.len(), 3);
    assert_eq!(ir.geometry.coedges.len(), 3);
    assert_eq!(
        ir.geometry
            .points
            .iter()
            .map(|point| point
                .source_object
                .as_ref()
                .map(|source| source.object_id.as_str()))
            .collect::<Vec<_>>(),
        [
            Some("cgm-vertex:000032"),
            Some("cgm-vertex:000033"),
            Some("cgm-vertex:000034"),
        ]
    );
    assert_eq!(
        ir.geometry
            .pcurves
            .iter()
            .map(|pcurve| pcurve
                .parameter_range()
                .map(cadmpeg_ir::units::FiniteVector::get))
            .collect::<Vec<_>>(),
        [Some([0.0, 0.5]), Some([0.0, 1.0]), Some([0.5, 1.0])]
    );
    assert_eq!(
        ir.geometry
            .coedges
            .iter()
            .flat_map(|coedge| coedge.pcurves.iter().map(|use_| use_.pcurve.as_str()))
            .collect::<Vec<_>>(),
        [
            "catia:b5:pcurve#20@0",
            "catia:b5:pcurve#20@2",
            "catia:b5:pcurve#20@1",
        ]
    );
    assert_eq!(
        ir.geometry
            .coedges
            .iter()
            .map(|coedge| coedge.pcurves[0]
                .parameter_range
                .map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints))
            .collect::<Vec<_>>(),
        [None, Some([1.0, 0.5]), None]
    );
    assert_eq!(ir.geometry.loops.len(), 1);
    assert_eq!(
        ir.geometry.loops[0]
            .anchored_vertex_uses()
            .iter()
            .map(|use_| use_.vertex.as_str())
            .collect::<Vec<_>>(),
        [
            "catia:b5:vertex#1",
            "catia:b5:vertex#2",
            "catia:b5:vertex#0"
        ]
    );
    assert_eq!(
        ir.geometry.loops[0]
            .anchored_vertex_uses()
            .iter()
            .map(|use_| Some(use_.after.as_str()))
            .collect::<Vec<_>>(),
        [
            Some("catia:b5:coedge#2-0"),
            Some("catia:b5:coedge#2-1"),
            Some("catia:b5:coedge#2-2")
        ]
    );
}

#[test]
fn edge_supports_preserve_one_sided_and_intersection_constructions() {
    let surfaces = HashMap::from([
        (
            10,
            SurfaceId::mint("catia:test:surface#surface-10".to_string()).expect("identity grammar"),
        ),
        (
            11,
            SurfaceId::mint("catia:test:surface#surface-11".to_string()).expect("identity grammar"),
        ),
    ]);
    let pcurve_20 = PcurveGeometry::Line(
        cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
            Point2::new(0.0, 0.0),
            Point2::new(1.0, 0.0),
        )
        .expect("valid LinePcurve fixture"),
    );
    let pcurve_21 = PcurveGeometry::Line(
        cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
            Point2::new(0.0, 1.0),
            Point2::new(1.0, 0.0),
        )
        .expect("valid LinePcurve fixture"),
    );
    let pcurves = BTreeMap::from([
        (
            20,
            (
                pcurve_20.clone(),
                false,
                crate::test_support::test_b5::finite_pair([2.0, 4.0]),
            ),
        ),
        (
            21,
            (
                pcurve_21.clone(),
                false,
                crate::test_support::test_b5::finite_pair([2.0, 5.0]),
            ),
        ),
    ]);
    let (_, _, one_sided) = b5_edge_support_definition(
        &[(
            10,
            20,
            crate::test_support::test_b5::finite_pair([2.0, 4.0]),
        )],
        &surfaces,
        &pcurves,
        None,
    )
    .expect("one-sided surface curve");
    assert!(matches!(
        one_sided,
        ProceduralCurveDefinition::SurfaceCurve { family }
            if family.context().parameter_range().endpoints() == [2.0, 4.0]
                && family.context().sides()[0].surface == Some(surfaces[&10].clone())
                && family.context().sides()[0]
                    .pcurve
                    .as_ref()
                    .map(|pcurve| &pcurve.geometry)
                    == Some(&pcurve_20)
                && family.context().sides()[1].surface.is_none()
    ));

    let (_, _, intersection) = b5_edge_support_definition(
        &[
            (
                10,
                20,
                crate::test_support::test_b5::finite_pair([2.0, 4.0]),
            ),
            (
                11,
                21,
                crate::test_support::test_b5::finite_pair([2.0, 4.0]),
            ),
        ],
        &surfaces,
        &pcurves,
        None,
    )
    .expect("two-sided intersection");
    assert!(matches!(
        intersection,
        ProceduralCurveDefinition::Intersection { context, .. }
            if context.parameter_range().endpoints() == [2.0, 4.0]
                && context.sides()[1].surface == Some(surfaces[&11].clone())
                && context.sides()[1]
                    .pcurve
                    .as_ref()
                    .map(|pcurve| &pcurve.geometry)
                    == Some(&pcurve_21)
            && context.sides()
                .iter()
                .all(|side| side.pcurve_parameter_range().is_none())
    ));
    let (_, _, independently_parameterized) = b5_edge_support_definition(
        &[
            (
                10,
                20,
                crate::test_support::test_b5::finite_pair([2.0, 4.0]),
            ),
            (
                11,
                21,
                crate::test_support::test_b5::finite_pair([5.0, 2.0]),
            ),
        ],
        &surfaces,
        &pcurves,
        None,
    )
    .expect("independently parameterized intersection");
    assert!(matches!(
        independently_parameterized,
        ProceduralCurveDefinition::Intersection { context, .. }
            if context.parameter_range().endpoints() == [0.0, 1.0]
            && context.sides()[0].pcurve_parameter_range().map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints) == Some([2.0, 4.0])
            && context.sides()[1].pcurve_parameter_range().map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints) == Some([5.0, 2.0])
    ));
    let (_, _, distance_parameterized) = b5_edge_support_definition(
        &[(
            10,
            20,
            crate::test_support::test_b5::finite_pair([2.0, 4.0]),
        )],
        &surfaces,
        &pcurves,
        Some([0.0, 8.0]),
    )
    .expect("distance-parameterized surface curve");
    assert!(matches!(
        distance_parameterized,
        ProceduralCurveDefinition::SurfaceCurve { family }
            if family.context().parameter_range().endpoints() == [0.0, 8.0]
            && family.context().sides()[0].pcurve_parameter_range().map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints) == Some([2.0, 4.0])
    ));
}

#[test]
fn procedural_support_requires_physical_edge_endpoint_agreement() {
    let plane = || SurfacePlan {
        geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        )),
        procedure: None,
    };
    let surfaces = BTreeMap::from([(10, plane()), (11, plane())]);
    let pcurves = BTreeMap::from([
        (
            20,
            (
                PcurveGeometry::Line(
                    cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                        Point2::new(0.0, 0.0),
                        Point2::new(1.0, 0.0),
                    )
                    .expect("valid LinePcurve fixture"),
                ),
                false,
                crate::test_support::test_b5::finite_pair([0.0, 1.0]),
            ),
        ),
        (
            21,
            (
                PcurveGeometry::Line(
                    cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                        Point2::new(1.0, 0.0),
                        Point2::new(-1.0, 0.0),
                    )
                    .expect("valid LinePcurve fixture"),
                ),
                false,
                crate::test_support::test_b5::finite_pair([0.0, 1.0]),
            ),
        ),
    ]);
    let supports = [(
        10,
        20,
        crate::test_support::test_b5::finite_pair([0.0, 1.0]),
    )];
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_follow_edge(
            ctx,
            &supports,
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.5e-3; 2],
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
    assert!(
        !crate::test_support::with_service_context(|ctx| b5_supports_follow_edge(
            ctx,
            &supports,
            [[0.0, 1.0, 0.0], [1.0, 1.0, 0.0]],
            [1.5e-3; 2],
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
    assert!(
        !crate::test_support::with_service_context(|ctx| b5_supports_follow_edge(
            ctx,
            &supports,
            [[1.0, 0.0, 0.0], [0.0, 0.0, 0.0]],
            [1.5e-3; 2],
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
    let mut reversed_supports = [(
        10,
        20,
        crate::test_support::test_b5::finite_pair([1.0, 0.0]),
    )];
    crate::test_support::with_service_context(|ctx| {
        orient_b5_supports_to_edge(
            ctx,
            &mut reversed_supports,
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.5e-3; 2],
            &surfaces,
            &pcurves,
        )
    })
    .expect("evaluator allocation succeeds");
    assert_eq!(
        reversed_supports[0].2,
        crate::test_support::test_b5::finite_pair([0.0, 1.0])
    );
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_follow_edge(
            ctx,
            &reversed_supports,
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.5e-3; 2],
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
    let mut tolerance_ambiguous_supports = [(
        10,
        20,
        crate::test_support::test_b5::finite_pair([1.0, 0.0]),
    )];
    crate::test_support::with_service_context(|ctx| {
        orient_b5_supports_to_edge(
            ctx,
            &mut tolerance_ambiguous_supports,
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.01; 2],
            &surfaces,
            &pcurves,
        )
    })
    .expect("evaluator allocation succeeds");
    assert_eq!(
        tolerance_ambiguous_supports[0].2,
        crate::test_support::test_b5::finite_pair([0.0, 1.0])
    );
    let mut oppositely_parameterized_supports = [
        (
            10,
            20,
            crate::test_support::test_b5::finite_pair([0.0, 1.0]),
        ),
        (
            11,
            21,
            crate::test_support::test_b5::finite_pair([0.0, 1.0]),
        ),
    ];
    crate::test_support::with_service_context(|ctx| {
        orient_b5_supports_to_edge(
            ctx,
            &mut oppositely_parameterized_supports,
            [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            [1.01; 2],
            &surfaces,
            &pcurves,
        )
    })
    .expect("evaluator allocation succeeds");
    assert_eq!(
        oppositely_parameterized_supports[1].2,
        crate::test_support::test_b5::finite_pair([1.0, 0.0])
    );
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_agree(
            ctx,
            &oppositely_parameterized_supports,
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_follow_edge(
            ctx,
            &supports,
            [[0.0, 1.0, 0.0], [1.0, 1.0, 0.0]],
            [1.01; 2],
            &surfaces,
            &pcurves,
        ))
        .expect("evaluator allocation succeeds")
    );
}

#[test]
fn exact_revolution_builders_reject_unbounded_subdivision_counts() {
    assert!(rational_arc(
        [0.0; 3],
        ([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        1.0e-300,
        [0.0, 1.0],
        &"test record",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .is_none());
    let profile = NurbsCurve::from_lanes(
        1,
        vec![0.0, 0.0, 1.0, 1.0],
        vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 0.0, 1.0)],
        None,
        false,
    )
    .expect("valid revolution profile");
    assert!(
        crate::test_support::with_service_context(|ctx| revolve_nurbs(
            ctx,
            &profile,
            [0.0; 3],
            [0.0, 0.0, 1.0],
            [[0.0, 1.0e300], [0.0, 1.0]],
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        ))
        .expect("revolve NURBS")
        .is_none()
    );
    let mut wide_knots = vec![0.0; 123];
    wide_knots.extend([1.0, 1.0]);
    let wide_profile = NurbsCurve::from_lanes(
        1,
        wide_knots,
        vec![Point3::new(1.0, 0.0, 0.0); 123],
        None,
        false,
    )
    .expect("valid wide revolution profile");
    assert!(
        crate::test_support::with_service_context(|ctx| revolve_nurbs(
            ctx,
            &wide_profile,
            [0.0; 3],
            [0.0, 0.0, 1.0],
            [[0.0, 4096.0 * std::f64::consts::FRAC_PI_2], [0.0, 1.0]],
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        ))
        .expect("revolve NURBS")
        .is_none()
    );
}

#[test]
fn body_kind_requires_unique_complete_loop_ownership() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let mut graph = B5Graph {
        complete: true,
        faces: vec![B5Face {
            object_id: 1,
            surface: 10,
            loops: vec![2],
            terminal_control: None,
        }],
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(
            2,
            B5Loop {
                object_id: 2,
                members: test_loop_members(&[4], &[3]),
                metadata: test_loop_metadata(),
                surface: 10,
            },
        )]),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::new(),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::new(),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            vec![[0.0; 3], [1.0, 0.0, 0.0]]
                .into_iter()
                .map(crate::test_support::test_b5::point)
                .collect(),
            Vec::new(),
            BTreeMap::from([(3, [B5VertexRef::Raw(0), B5VertexRef::Raw(1)])]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::new(),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };

    assert_eq!(
        ownership_plan(&ctx, &graph)
            .expect("build the ownership plan")
            .expect("required invariant")
            .body_kind,
        BodyKind::Sheet
    );
    graph.faces[0].loops.push(2);
    assert!(ownership_plan(&ctx, &graph)
        .expect("build the ownership plan")
        .is_none());
    graph.faces[0].loops.pop();
    graph.faces.push(B5Face {
        object_id: 5,
        surface: 10,
        loops: vec![2],
        terminal_control: None,
    });
    assert!(ownership_plan(&ctx, &graph)
        .expect("build the ownership plan")
        .is_none());
    graph.faces.pop();

    graph.faces.push(B5Face {
        object_id: 5,
        surface: 10,
        loops: vec![6],
        terminal_control: None,
    });
    graph.loops.insert(
        6,
        B5Loop {
            object_id: 6,
            members: test_loop_members(&[8], &[7]),
            metadata: test_loop_metadata(),
            surface: 10,
        },
    );
    graph
        .vertices
        .insert_edge(7, [B5VertexRef::Raw(0), B5VertexRef::Raw(1)])
        .expect("edge references select existing rows");
    let ownership = ownership_plan(&ctx, &graph)
        .expect("build the ownership plan")
        .expect("required invariant");
    assert_eq!(ownership.face_components, vec![0, 1]);
    assert_eq!(ownership.components().len(), 2);
    assert_eq!(ownership.body_kind, BodyKind::Sheet);
    assert_eq!(ownership.loop_owners.get(&2), Some(&0));
    assert_eq!(ownership.loop_owners.get(&6), Some(&1));

    graph
        .loops
        .get_mut(&2)
        .expect("required invariant")
        .members
        .push(B5LoopMember {
            pcurve: 0,
            edge: 3,
            controls: [1, 1, 1],
        });
    assert_eq!(
        ownership_plan(&ctx, &graph)
            .expect("build the ownership plan")
            .expect("required invariant")
            .body_kind,
        BodyKind::General
    );
    graph
        .loops
        .get_mut(&2)
        .expect("required invariant")
        .members
        .pop();

    graph.loops.get_mut(&6).expect("required invariant").members[0].edge = 3;
    let ownership = ownership_plan(&ctx, &graph)
        .expect("build the ownership plan")
        .expect("required invariant");
    assert_eq!(ownership.face_components, vec![0, 0]);
    assert_eq!(ownership.components().len(), 1);
    assert_eq!(ownership.body_kind, BodyKind::Solid);

    graph.faces.pop();
    graph.loops.remove(&6);
    graph.vertices.remove_edge(7);
    assert!(graph
        .vertices
        .insert_edge(3, [B5VertexRef::Raw(0), B5VertexRef::Raw(2)])
        .is_err());
}

#[test]
fn loop_orientation_reverses_member_order_and_rejects_frustrated_parity() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let loop_ = |object_id: u32, edges: Vec<u32>| B5Loop {
        object_id,
        members: test_loop_members(&vec![0; edges.len()], &edges),
        metadata: test_loop_metadata(),
        surface: 10,
    };
    let mut graph = B5Graph {
        complete: true,
        faces: Vec::new(),
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(1, loop_(1, vec![3])), (2, loop_(2, vec![4, 5, 3]))]),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::new(),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::new(),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            Vec::new(),
            BTreeMap::new(),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::new(),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };
    graph.loops.get_mut(&2).expect("required loop").members[1].controls[2] = -1;
    let orientation = orient_loop_members(
        &ctx,
        &graph,
        BTreeMap::from([(1, vec![false]), (2, vec![false; 3])]),
    )
    .expect("orient the loop members")
    .expect("required invariant");
    assert_eq!(orientation[&1].member_order().collect::<Vec<_>>(), vec![0]);
    assert_eq!(
        orientation[&2].member_order().collect::<Vec<_>>(),
        vec![2, 1, 0]
    );
    assert_eq!(
        orientation[&1]
            .members
            .iter()
            .map(|member| member.reversed)
            .collect::<Vec<_>>(),
        vec![false]
    );
    assert_eq!(
        orientation[&2]
            .members
            .iter()
            .map(|member| member.reversed)
            .collect::<Vec<_>>(),
        vec![true; 3]
    );
    assert_eq!(
        orientation[&1]
            .members
            .iter()
            .map(|member| member.pcurve_reversed)
            .collect::<Vec<_>>(),
        vec![false]
    );
    assert_eq!(
        orientation[&2]
            .members
            .iter()
            .map(|member| member.pcurve_reversed)
            .collect::<Vec<_>>(),
        vec![true, false, true]
    );

    graph.loops = BTreeMap::from([
        (1, loop_(1, vec![1, 3])),
        (2, loop_(2, vec![1, 2])),
        (3, loop_(3, vec![2, 3])),
    ]);
    assert!(orient_loop_members(
        &ctx,
        &graph,
        BTreeMap::from([
            (1, vec![false; 2]),
            (2, vec![false; 2]),
            (3, vec![false; 2]),
        ]),
    )
    .expect("orient the loop members")
    .is_none());
}

#[test]
fn emitted_carriers_determine_logical_vertex_tolerance() {
    let graph = B5Graph {
        complete: true,
        faces: Vec::new(),
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(
            1,
            B5Loop {
                object_id: 1,
                members: test_loop_members(&[2], &[3]),
                metadata: test_loop_metadata(),
                surface: 4,
            },
        )]),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::new(),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::from([
            (
                20,
                B5ParameterIncidence {
                    object_id: 20,
                    lanes: vec![B5IncidenceLane {
                        curve: 2,
                        parameter: crate::test_support::test_b5::finite(0.25),
                        control: 0,
                    }],
                },
            ),
            (
                21,
                B5ParameterIncidence {
                    object_id: 21,
                    lanes: vec![B5IncidenceLane {
                        curve: 2,
                        parameter: crate::test_support::test_b5::finite(0.75),
                        control: 0,
                    }],
                },
            ),
        ]),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            vec![
                B5LogicalVertex {
                    object_id: 10,
                    point: crate::test_support::test_b5::point([0.25, 0.0, 1e-4]),
                },
                B5LogicalVertex {
                    object_id: 11,
                    point: crate::test_support::test_b5::point([0.75, 0.0, 0.0]),
                },
            ],
            BTreeMap::from([(3, [B5VertexRef::Logical(0), B5VertexRef::Logical(1)])]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::from([(3, [20, 21])]),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };
    let pcurves = BTreeMap::from([(
        2,
        (
            PcurveGeometry::Nurbs {
                nurbs: PcurveNurbs::from_lanes(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    vec![Point2::new(0.0, 0.0), Point2::new(1.0, 0.0)],
                    None,
                    false,
                )
                .expect("valid test pcurve"),
            },
            false,
            crate::test_support::test_b5::finite_pair([0.0, 1.0]),
        ),
    )]);
    let surfaces = BTreeMap::from([(
        4,
        SurfacePlan {
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            procedure: None,
        },
    )]);
    let supports = HashMap::from([(
        3,
        vec![(
            4,
            2,
            crate::test_support::test_b5::finite_pair([0.25, 0.75]),
        )],
    )]);

    let tolerances = transfer_vertex_tolerances(&graph, &supports, &surfaces, &pcurves);
    assert!((tolerances[&0].get() - (1e-4 + 1.0e-9)).abs() < 1.0e-12);
    assert!(!tolerances.contains_key(&1));
}

#[test]
fn b5_supports_with_an_overflowing_endpoint_agree_on_their_finite_endpoints() {
    // The plane's origin is the largest finite x coordinate, so the pcurve
    // start u = MAX lifts to a point without a finite x and the end u = -MAX
    // lifts to the origin of the model.
    let surfaces = BTreeMap::from([(
        10,
        SurfacePlan {
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(f64::MAX, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            procedure: None,
        },
    )]);
    let pcurves = BTreeMap::from([(
        20,
        (
            PcurveGeometry::Line(
                cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                    Point2::new(0.0, 0.0),
                    Point2::new(f64::MAX, 0.0),
                )
                .expect("valid LinePcurve fixture"),
            ),
            false,
            crate::test_support::test_b5::finite_pair([-1.0, 1.0]),
        ),
    )]);
    let supports = [
        (
            10,
            20,
            crate::test_support::test_b5::finite_pair([1.0, -1.0]),
        ),
        (
            10,
            20,
            crate::test_support::test_b5::finite_pair([1.0, -1.0]),
        ),
    ];
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_agree(
            ctx, &supports, &surfaces, &pcurves
        ))
        .expect("evaluator allocation succeeds")
    );
}

#[test]
fn b5_supports_with_an_overflowing_placed_endpoint_agree_on_their_finite_endpoints() {
    // The placement adds the largest finite x coordinate, so the pcurve start
    // u = MAX lifts to a point without a finite x and the end u = -MAX lifts
    // to the origin of the model.
    let surfaces = BTreeMap::from([(
        10,
        SurfacePlan {
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Transformed(
                cadmpeg_ir::geometry::PlacedSurface::try_new(
                    Box::new(SolvedSurfaceGeometry::Plane(
                        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                            Point3::new(0.0, 0.0, 0.0),
                            Vector3::new(0.0, 0.0, 1.0),
                            Vector3::new(1.0, 0.0, 0.0),
                        )
                        .expect("valid PlaneSurface fixture"),
                    )),
                    cadmpeg_ir::transform::Transform::affine([
                        [1.0, 0.0, 0.0, f64::MAX],
                        [0.0, 1.0, 0.0, 0.0],
                        [0.0, 0.0, 1.0, 0.0],
                    ])
                    .expect("affine transform"),
                )
                .expect("valid PlacedSurface fixture"),
            )),
            procedure: None,
        },
    )]);
    let pcurves = BTreeMap::from([(
        20,
        (
            PcurveGeometry::Line(
                cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                    Point2::new(0.0, 0.0),
                    Point2::new(f64::MAX, 0.0),
                )
                .expect("valid LinePcurve fixture"),
            ),
            false,
            crate::test_support::test_b5::finite_pair([-1.0, 1.0]),
        ),
    )]);
    let supports = [
        (
            10,
            20,
            crate::test_support::test_b5::finite_pair([1.0, -1.0]),
        ),
        (
            10,
            20,
            crate::test_support::test_b5::finite_pair([1.0, -1.0]),
        ),
    ];
    assert!(
        crate::test_support::with_service_context(|ctx| b5_supports_agree(
            ctx, &supports, &surfaces, &pcurves
        ))
        .expect("evaluator allocation succeeds")
    );
}

#[test]
fn nurbs_curve_reparameterizes_onto_a_new_range() {
    let curve = CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
        NurbsCurve::from_lanes(
            1,
            vec![10.0, 10.0, 20.0, 20.0],
            vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
            None,
            false,
        )
        .expect("valid curve"),
    ));
    let target = crate::test_support::test_b5::increasing([0.0, 2.0]);
    assert!(curve_on_parameter_range(
        curve,
        [10.0, 20.0],
        target,
        &"curve",
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .is_some());
}
