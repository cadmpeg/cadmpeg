// SPDX-License-Identifier: Apache-2.0
//! Surface-layer transfer: neutral surface lowering and the surface/procedural
//! emit pass.

use cadmpeg_core::convert::{f64_from_index, truncate_f64_to_usize};

use std::collections::{BTreeMap, HashMap, HashSet};

use cadmpeg_core::decode::DecodeContext;
use cadmpeg_core::CodecError;
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    nurbs::{NurbsCurve, NurbsSurface},
    Curve, CurveGeometry, ProceduralCurve, ProceduralCurveDefinition, ProceduralSurface,
    ProceduralSurfaceDefinition, SolvedCurveGeometry, SolvedSurfaceGeometry, Surface,
    SurfaceGeometry,
};
use cadmpeg_ir::ids::{CurveId, ProceduralCurveId, ProceduralSurfaceId, SurfaceId, UnknownId};
use cadmpeg_ir::scalar::PositiveReal;
use cadmpeg_ir::units::UnitVector3;
use cadmpeg_ir::{AnnotationBuilder, Exactness};

use super::super::graph::{B5Graph, B5Profile, B5Surface};
use super::super::vecmath::{add, components, coordinates, cross, scale};
use super::{
    annotate, dot, point3, subtract, RevolutionPlan, SurfacePlan, SurfaceProcedure, TransferPlan,
};
use crate::assemble::cgm_source;

/// Direct geometry or a procedural surface construction.
pub(super) enum B5SurfaceCarrier<'a> {
    Analytic(SurfaceGeometry),
    Procedural(B5ProceduralSurface<'a>),
}

/// Surface constructions that require procedural lowering.
pub(super) enum B5ProceduralSurface<'a> {
    Unresolved,
    RollingBall {
        carrier_object_id: u32,
        definition: &'a ProceduralSurfaceDefinition,
    },
    Revolution {
        profile_curve: u32,
        axis_origin: FinitePoint3,
        axis_direction: UnitVector3,
        angular_scale: PositiveReal,
        bounds: [[f64; 2]; 2],
    },
}

/// Classify a surface into its direct geometry or procedural construction.
pub(super) fn surface_carrier(surface: &B5Surface) -> B5SurfaceCarrier<'_> {
    match surface {
        B5Surface::Plane { origin, frame, .. } => {
            B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::new(*origin, *frame),
            )))
        }
        B5Surface::Cylinder {
            origin,
            frame,
            radius,
            ..
        } => B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::new(*origin, *frame, *radius),
        ))),
        B5Surface::Cone { surface, .. } => surface.map_or(
            B5SurfaceCarrier::Procedural(B5ProceduralSurface::Unresolved),
            |surface| {
                B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
                    surface,
                )))
            },
        ),
        B5Surface::Sphere {
            center,
            frame,
            radius,
            ..
        } => B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(
            cadmpeg_ir::geometry::analytic::SphereSurface::new(*center, *frame, (*radius).into()),
        ))),
        B5Surface::Torus {
            center,
            frame,
            major_radius,
            minor_radius,
            ..
        } => B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(
            cadmpeg_ir::geometry::analytic::TorusSurface::new(
                *center,
                *frame,
                *major_radius,
                (*minor_radius).into(),
            ),
        ))),
        B5Surface::Nurbs(surface) => B5SurfaceCarrier::Analytic(SurfaceGeometry::Solved(
            SolvedSurfaceGeometry::Nurbs(surface.clone()),
        )),
        B5Surface::UnresolvedNurbs { .. } | B5Surface::Unknown { .. } => {
            B5SurfaceCarrier::Procedural(B5ProceduralSurface::Unresolved)
        }
        B5Surface::RollingBall {
            carrier_object_id,
            definition,
        } => B5SurfaceCarrier::Procedural(B5ProceduralSurface::RollingBall {
            carrier_object_id: *carrier_object_id,
            definition,
        }),
        B5Surface::Revolution {
            profile_curve,
            axis_origin,
            axis_direction,
            angular_scale,
            profile_range,
            angular_range,
            ..
        } => B5SurfaceCarrier::Procedural(B5ProceduralSurface::Revolution {
            profile_curve: *profile_curve,
            axis_origin: *axis_origin,
            axis_direction: *axis_direction,
            angular_scale: *angular_scale,
            bounds: [profile_range.endpoints(), angular_range.endpoints()],
        }),
    }
}

pub(super) fn neutral_surface(
    ctx: &DecodeContext<'_>,
    surface: &B5Surface,
    graph: &B5Graph,
    surface_id: u32,
    payload: &UnknownId,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<SurfacePlan, CodecError> {
    let carrier = match surface_carrier(surface) {
        B5SurfaceCarrier::Analytic(geometry) => {
            return Ok(SurfacePlan {
                geometry,
                procedure: None,
            })
        }
        B5SurfaceCarrier::Procedural(carrier) => carrier,
    };
    if let Some(extrusion) = super::resolved_extrusion_surface(ctx, graph, surface_id, refusal)? {
        return Ok(SurfacePlan {
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown {
                record: Some(payload.clone()),
            }),
            // The resolved extrusion is retained by the surface plan.
            procedure: { Some(SurfaceProcedure::Extrusion(Box::new(extrusion))) },
        });
    }
    let mut procedure = None;
    let geometry = match carrier {
        B5ProceduralSurface::Unresolved => {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown {
                record: Some(payload.clone()),
            })
        }
        B5ProceduralSurface::RollingBall {
            carrier_object_id,
            definition,
        } => {
            procedure = Some(SurfaceProcedure::RollingBall {
                carrier_object_id,
                definition: Box::new(copy_rolling_ball_definition(definition)?),
            });
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown {
                record: Some(payload.clone()),
            })
        }
        B5ProceduralSurface::Revolution {
            profile_curve,
            axis_origin,
            axis_direction,
            angular_scale,
            bounds,
        } => match revolution_surface(
            ctx,
            graph.profiles.get(&profile_curve),
            (axis_origin, axis_direction),
            angular_scale,
            bounds,
            &format_args!("b5 revolution surface record #{surface_id}"),
            refusal,
        )? {
            Some((surface, plan)) => {
                procedure = Some(SurfaceProcedure::Revolution(plan));
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface))
            }
            None => SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown {
                record: Some(payload.clone()),
            }),
        },
    };

    Ok(SurfacePlan {
        geometry,
        procedure,
    })
}

pub(in crate::families) fn copy_rolling_ball_definition(
    definition: &ProceduralSurfaceDefinition,
) -> Result<ProceduralSurfaceDefinition, CodecError> {
    let ProceduralSurfaceDefinition::RollingBallJet(jet) = definition else {
        return Err(CodecError::malformed(
            "B5 rolling-ball carrier requires a jet definition",
        ));
    };
    let stations = jet.stations().to_vec();
    Ok(ProceduralSurfaceDefinition::RollingBallJet(
        cadmpeg_ir::geometry::RollingBallJetStations::from_parts(jet.degree(), stations)
            .map_err(CodecError::malformed)?,
    ))
}

#[cfg(test)]
mod carrier_resource_tests {
    use super::{surface_carrier, B5SurfaceCarrier};
    use crate::families::b5::graph::B5Surface;
    use cadmpeg_ir::geometry::nurbs::{NurbsSurface, NurbsSurfaceAxis, NurbsSurfaceLanes};
    use cadmpeg_ir::math::Point3;

    #[test]
    fn bilinear_nurbs_surface_maps_to_an_analytic_carrier() {
        let surface = B5Surface::Nurbs(
            NurbsSurface::from_lanes(
                NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
                NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
                NurbsSurfaceLanes::new(vec![vec![Point3::new(0.0, 0.0, 0.0); 2]; 2], None),
                false,
            )
            .expect("valid bilinear surface"),
        );
        let admitted = surface_carrier(&surface);
        assert!(matches!(admitted, B5SurfaceCarrier::Analytic(_)));
    }
}

pub(super) fn revolution_surface(
    ctx: &DecodeContext<'_>,
    profile: Option<&B5Profile>,
    axis: (FinitePoint3, UnitVector3),
    angular_scale: PositiveReal,
    bounds: [[f64; 2]; 2],
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<(NurbsSurface, RevolutionPlan)>, CodecError> {
    let (axis_origin, axis_direction) = axis;
    let Some(profile) = profile else {
        return Ok(None);
    };
    let [parameter_interval, native_angular_interval] = bounds;
    let Some(directrix) = profile_nurbs(profile, parameter_interval, record, refusal) else {
        return Ok(None);
    };
    let angular_interval = [
        native_angular_interval[0] / angular_scale.get(),
        native_angular_interval[1] / angular_scale.get(),
    ];
    let surface = revolve_nurbs(
        ctx,
        &directrix,
        coordinates(axis_origin),
        components(&axis_direction),
        [angular_interval, native_angular_interval],
        record,
        refusal,
    )?;
    let Some(surface) = surface else {
        return Ok(None);
    };
    Ok(Some((
        surface,
        RevolutionPlan {
            directrix,
            axis_origin,
            axis_direction,
            angular_interval,
            angular_parameter_interval: native_angular_interval,
            parameter_interval,
        },
    )))
}

fn profile_nurbs(
    profile: &B5Profile,
    interval: [f64; 2],
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<NurbsCurve> {
    if !profile
        .parameter_range()
        .endpoints()
        .into_iter()
        .zip(interval)
        .all(|(profile, surface)| profile.to_bits() == surface.to_bits())
    {
        return None;
    }
    match profile {
        B5Profile::Line {
            point, direction, ..
        } => crate::nurbs::note_refusal(
            cadmpeg_ir::geometry::nurbs::NurbsCurve::from_lanes(
                1,
                vec![interval[0], interval[0], interval[1], interval[1]],
                interval
                    .into_iter()
                    .map(|parameter| {
                        point3(add(coordinates(*point), scale(direction.get(), parameter)))
                    })
                    .collect::<Vec<_>>(),
                None,
                false,
            ),
            refusal,
            format_args!("b5 line profile of a revolution surface: {record}"),
        ),
        B5Profile::Arc {
            center,
            direction_x,
            direction_y,
            radius,
            ..
        } => rational_arc(
            coordinates(*center),
            (direction_x.get(), direction_y.get()),
            radius.get(),
            interval,
            record,
            refusal,
        ),
    }
}

pub(super) fn rational_arc(
    center: [f64; 3],
    (direction_x, direction_y): ([f64; 3], [f64; 3]),
    radius: f64,
    interval: [f64; 2],
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<NurbsCurve> {
    let angles = [interval[0] / radius, interval[1] / radius];
    let span_count = ((angles[1] - angles[0]).abs() / std::f64::consts::FRAC_PI_2).ceil();
    if !span_count.is_finite() || span_count > crate::MAX_EXACT_ARC_SPANS {
        return None;
    }
    // `ceil` answers zero only for an angular span of exactly zero: an arc that
    // sweeps no angle states no span, which this route refuses as it refuses
    // every other degeneracy.
    let span_count = truncate_f64_to_usize(span_count).and_then(std::num::NonZeroUsize::new)?;
    let span_count = span_count.get();
    let mut control_points = Vec::new();

    let mut weights = Vec::new();

    let mut knots = Vec::new();

    for span in 0..span_count {
        let fraction0 = f64_from_index(span)? / f64_from_index(span_count)?;
        let fraction1 = f64_from_index(span + 1)? / f64_from_index(span_count)?;
        let angle0 = angles[0] + (angles[1] - angles[0]) * fraction0;
        let angle1 = angles[0] + (angles[1] - angles[0]) * fraction1;
        let middle = (angle0 + angle1) * 0.5;
        let middle_weight = ((angle1 - angle0) * 0.5).cos();
        if middle_weight <= f64::EPSILON {
            return None;
        }
        if span == 0 {
            control_points.push(point3(circle_point(
                center,
                direction_x,
                direction_y,
                radius,
                angle0,
            )));
            weights.push(1.0);
        }
        control_points.push(point3(circle_point(
            center,
            direction_x,
            direction_y,
            radius / middle_weight,
            middle,
        )));
        weights.push(middle_weight);
        control_points.push(point3(circle_point(
            center,
            direction_x,
            direction_y,
            radius,
            angle1,
        )));
        weights.push(1.0);
        append_quadratic_span_knots(&mut knots, interval, span, span_count)?;
    }
    crate::nurbs::note_refusal(
        cadmpeg_ir::geometry::nurbs::NurbsCurve::from_lanes(
            2,
            knots,
            control_points,
            Some(weights),
            false,
        ),
        refusal,
        format_args!("b5 rational arc profile of a revolution surface: {record}"),
    )
}

pub(super) fn revolve_nurbs(
    ctx: &DecodeContext<'_>,
    profile: &NurbsCurve,
    axis_origin: [f64; 3],
    axis_direction: [f64; 3],
    intervals: [[f64; 2]; 2],
    record: &dyn std::fmt::Display,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<NurbsSurface>, CodecError> {
    let [angular_interval, native_interval] = intervals;
    (|| -> Option<Result<NurbsSurface, CodecError>> {
        let span_count = ((angular_interval[1] - angular_interval[0]).abs()
            / std::f64::consts::FRAC_PI_2)
            .ceil();
        if !span_count.is_finite() || span_count > crate::MAX_EXACT_ARC_SPANS {
            return None;
        }
        // `ceil` answers zero only for an angular span of exactly zero: an arc that
        // sweeps no angle states no span, which this route refuses as it refuses
        // every other degeneracy.
        let span_count = std::num::NonZeroUsize::new(truncate_f64_to_usize(span_count)?)?.get();
        let angular_count = span_count.checked_mul(2)?.checked_add(1)?;
        crate::nurbs_surface_control_count(profile.pole_count(), angular_count)?;
        let mut angles = Vec::new();
        let mut angular_weights = Vec::new();
        let mut v_knots = Vec::new();
        for span in 0..span_count {
            let fraction0 = f64_from_index(span)? / f64_from_index(span_count)?;
            let fraction1 = f64_from_index(span + 1)? / f64_from_index(span_count)?;
            let angle0 =
                angular_interval[0] + (angular_interval[1] - angular_interval[0]) * fraction0;
            let angle1 =
                angular_interval[0] + (angular_interval[1] - angular_interval[0]) * fraction1;
            let middle = (angle0 + angle1) * 0.5;
            let middle_weight = ((angle1 - angle0) * 0.5).cos();
            if middle_weight <= f64::EPSILON {
                return None;
            }
            if span == 0 {
                angles.push((angle0, 1.0));
                angular_weights.push(1.0);
            }
            angles.push((middle, 1.0 / middle_weight));
            angular_weights.push(middle_weight);
            angles.push((angle1, 1.0));
            angular_weights.push(1.0);
            append_quadratic_span_knots(&mut v_knots, native_interval, span, span_count)?;
        }
        let profile_weights = match profile.pole_rows() {
            cadmpeg_ir::geometry::nurbs::NurbsPoles3::Rational { points } => points
                .iter()
                .map(|point| point.weight.get())
                .collect::<Vec<_>>(),
            cadmpeg_ir::geometry::nurbs::NurbsPoles3::Polynomial { .. } => match ctx.alloc_filled(
                profile.pole_count(),
                1.0,
                "catia b5 revolution profile weights",
            ) {
                Ok(weights) => weights,
                Err(error) => return Some(Err(error)),
            },
        };
        let mut control_points = Vec::new();
        let mut weights = Vec::new();
        for (index, profile_weight) in profile_weights.into_iter().enumerate() {
            let profile_point = profile.pole_rows().point_at(index)?;
            let relative = [
                profile_point.x - axis_origin[0],
                profile_point.y - axis_origin[1],
                profile_point.z - axis_origin[2],
            ];
            let axial = scale(axis_direction, dot(relative, axis_direction));
            let radial = subtract(relative, axial);
            for ((angle, radial_scale), angular_weight) in
                angles.iter().copied().zip(angular_weights.iter().copied())
            {
                let rotated = rotate_vector(radial, axis_direction, angle);
                control_points.push(point3(add(
                    axis_origin,
                    add(axial, scale(rotated, radial_scale)),
                )));
                weights.push(profile_weight * angular_weight);
            }
        }
        let profile_knots = profile.knots().as_slice().to_vec();
        let point_rows = control_points
            .chunks(angular_count)
            .map(<[_]>::to_vec)
            .collect::<Vec<_>>();
        let weight_rows = weights
            .chunks(angular_count)
            .map(<[_]>::to_vec)
            .collect::<Vec<_>>();
        let surface = crate::nurbs::note_refusal(
            cadmpeg_ir::geometry::nurbs::NurbsSurface::from_lanes(
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(
                    profile.degree(),
                    profile_knots,
                    false,
                ),
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(2, v_knots, false),
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(point_rows, Some(weight_rows)),
                false,
            ),
            refusal,
            format_args!("b5 revolution surface built from its profile: {record}"),
        )?;
        Some(Ok(surface))
    })()
    .transpose()
}

fn append_quadratic_span_knots(
    knots: &mut Vec<f64>,
    interval: [f64; 2],
    span: usize,
    span_count: usize,
) -> Option<()> {
    let at = |index: usize| {
        let fraction = f64_from_index(index)? / f64_from_index(span_count)?;
        let ordinary = interval[0] + (interval[1] - interval[0]) * fraction;
        if ordinary.is_finite() {
            Some(ordinary)
        } else {
            cadmpeg_ir::math::interpolate(interval[0], interval[1], fraction)
                .map(cadmpeg_ir::scalar::FiniteReal::get)
        }
    };
    let start = at(span)?;
    let end = at(span + 1)?;
    if span == 0 {
        knots.extend([start, start, start]);
    } else {
        knots.extend([start, start]);
    }
    if span + 1 == span_count {
        knots.extend([end, end, end]);
    }
    Some(())
}

fn circle_point(
    center: [f64; 3],
    direction_x: [f64; 3],
    direction_y: [f64; 3],
    radius: f64,
    angle: f64,
) -> [f64; 3] {
    add(
        center,
        scale(
            add(
                scale(direction_x, angle.cos()),
                scale(direction_y, angle.sin()),
            ),
            radius,
        ),
    )
}

fn rotate_vector(value: [f64; 3], axis: [f64; 3], angle: f64) -> [f64; 3] {
    add(
        add(
            scale(value, angle.cos()),
            scale(cross(axis, value), angle.sin()),
        ),
        scale(axis, dot(axis, value) * (1.0 - angle.cos())),
    )
}

/// Emit the referenced surfaces, their procedural definitions, and the offset
/// procedural surfaces, returning the map from `object_id` to emitted
/// [`SurfaceId`]. Consumes the planned surfaces out of the transfer plan.
pub(super) fn emit_surfaces(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    graph: &B5Graph,
    plan: &mut TransferPlan,
    admission: &mut crate::families::FamilyEntityAdmission<'_, '_>,
) -> Result<HashMap<u32, SurfaceId>, cadmpeg_core::CodecError> {
    let surface_plan: BTreeMap<u32, SurfacePlan> = std::mem::take(&mut plan.surface_plan);
    let namespace = cadmpeg_ir::identity_namespace!("catia", "b5", "surface");
    let planned = surface_plan.keys().copied().collect::<Vec<_>>();
    let mut surface_ids = HashMap::new();
    for &object_id in &planned {
        let id = crate::resource::compose_u32_id(&namespace, object_id, SurfaceId::mint)?;
        surface_ids.insert(object_id, id);
    }
    let mut face_surfaces = HashSet::new();
    for face in &graph.faces {
        face_surfaces.insert(face.surface);
    }
    for (object_id, plan) in surface_plan {
        let id = surface_ids[&object_id].clone();
        let revolution_cache = matches!(
            plan.procedure.as_ref(),
            Some(SurfaceProcedure::Revolution(_))
        );
        let rolling_ball_carrier = matches!(
            plan.procedure.as_ref(),
            Some(SurfaceProcedure::RollingBall { .. })
        );
        let exact_procedural_carrier = rolling_ball_carrier
            || matches!(
                plan.procedure.as_ref(),
                Some(SurfaceProcedure::Extrusion(_))
            );
        annotate(
            annotations,
            &id,
            "object_stream_b5_03",
            if face_surfaces.contains(&object_id) {
                "face_surface"
            } else {
                "construction_surface"
            },
            if exact_procedural_carrier {
                Exactness::ByteExact
            } else if matches!(
                plan.geometry,
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { .. })
            ) {
                Exactness::Unknown
            } else if revolution_cache {
                Exactness::Derived
            } else {
                Exactness::ByteExact
            },
        )?;
        if revolution_cache {
            annotations.derived(id.as_str(), "geometry")?;
        }
        let model_id = id.clone();
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id: model_id,
            geometry: plan.geometry,
            source_object: Some(cgm_source("surface", object_id)?),
            native_ref: None,
        });
        match plan.procedure {
            Some(SurfaceProcedure::Extrusion(extrusion)) => {
                emit_extrusion_procedure(
                    ir,
                    annotations,
                    &surface_ids,
                    &id,
                    object_id,
                    *extrusion,
                    admission,
                )?;
            }
            Some(SurfaceProcedure::Revolution(revolution)) => {
                let directrix_id = crate::resource::compose_u32_id(
                    &cadmpeg_ir::identity_namespace!("catia", "b5", "profile"),
                    object_id,
                    CurveId::mint,
                )?;
                annotate(
                    annotations,
                    &directrix_id,
                    "object_stream_b5_03",
                    "2d_profile_curve",
                    Exactness::Derived,
                )?;
                annotations.derived(directrix_id.as_str(), "geometry")?;
                admission.charge()?;
                ir.geometry.curves.push(Curve {
                    parameter_range: None,
                    id: directrix_id.clone(),
                    geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                        revolution.directrix,
                    )),
                    source_object: None,
                    native_ref: None,
                });
                let procedural_id = crate::resource::compose_u32_id(
                    &cadmpeg_ir::identity_namespace!("catia", "b5", "procedural-surface"),
                    object_id,
                    ProceduralSurfaceId::mint,
                )?;
                annotate(
                    annotations,
                    &procedural_id,
                    "object_stream_b5_03",
                    "2d_surface_of_revolution",
                    Exactness::Derived,
                )?;
                admission.charge()?;
                let _attached = ir.geometry.add_procedural_surface(
                    &id,
                    cadmpeg_ir::geometry::surface_payloads::RevolutionSurfaceConstruction::try_new(
                        directrix_id,
                        (revolution.axis_origin, revolution.axis_direction),
                        revolution.angular_interval,
                        Some(revolution.angular_parameter_interval),
                        Some(revolution.parameter_interval),
                        false,
                        cadmpeg_ir::geometry::CacheContract::from_form(None),
                    )
                    .map(|admitted_payload| {
                        ProceduralSurface::new(
                            procedural_id,
                            ProceduralSurfaceDefinition::Revolution(admitted_payload),
                            None,
                        )
                    })
                    .map_err(cadmpeg_core::CodecError::malformed)?,
                );
            }
            Some(SurfaceProcedure::RollingBall {
                carrier_object_id,
                definition,
            }) if graph
                .canonical_surface_id(object_id)
                .is_some_and(|id| !graph.offset_surfaces.contains_key(&id)) =>
            {
                let procedural_id = crate::resource::compose_u32_id(
                    &cadmpeg_ir::identity_namespace!("catia", "b5", "rolling-ball"),
                    object_id,
                    ProceduralSurfaceId::mint,
                )?;
                let carrier_tag = format!("result_carrier:{carrier_object_id:08x}");
                annotate(
                    annotations,
                    &procedural_id,
                    "object_stream_a8_03_32",
                    &carrier_tag,
                    Exactness::ByteExact,
                )?;
                admission.charge()?;
                let _attached = ir.geometry.add_procedural_surface(
                    &id,
                    ProceduralSurface::new(procedural_id, *definition, None),
                );
            }
            Some(SurfaceProcedure::RollingBall { .. }) | None => {}
        }
    }
    for &object_id in &planned {
        let Some(construction_id) = graph.canonical_surface_id(object_id) else {
            continue;
        };
        let Some(offset) = graph.offset_surfaces.get(&construction_id) else {
            continue;
        };
        if offset.carrier_kind == super::super::graph::B5OffsetCarrierKind::Cone {
            continue;
        }
        let (Some(surface), Some(support)) = (
            surface_ids.get(&object_id),
            surface_ids.get(&offset.source_surface),
        ) else {
            continue;
        };
        let procedural_id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "b5", "offset"),
            object_id,
            ProceduralSurfaceId::mint,
        )?;
        annotate(
            annotations,
            &procedural_id,
            "object_stream_b5_03",
            "30_offset_surface",
            Exactness::Derived,
        )?;
        let record_bounds = super::parameter_record_bounds(offset.parameter_bounds);
        admission.charge()?;
        let _attached = ir.geometry.add_procedural_surface(
            &surface.clone(),
            ProceduralSurface::new(
                procedural_id,
                ProceduralSurfaceDefinition::Offset(
                    cadmpeg_ir::geometry::surface_payloads::OffsetSurfaceConstruction::legacy(
                        support.clone(),
                        offset.distance,
                        None,
                        None,
                        false,
                        cadmpeg_ir::geometry::LegacyExtensionFlags::Absent {},
                        None,
                    ),
                ),
                Some(record_bounds),
            ),
        );
    }
    Ok(surface_ids)
}

fn emit_extrusion_procedure(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    surface_ids: &HashMap<u32, SurfaceId>,
    surface_id: &SurfaceId,
    surface_object_id: u32,
    extrusion: super::ResolvedExtrusionSurface,
    admission: &mut crate::families::FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    let directrix_id = crate::resource::compose_u32_id(
        &cadmpeg_ir::identity_namespace!("catia", "b5", "extrusion-directrix"),
        extrusion.directrix_object_id,
        CurveId::mint,
    )?;
    match extrusion.directrix {
        super::ResolvedExtrusionDirectrix::SurfaceCurve { curve, .. } => {
            annotate(
                annotations,
                &directrix_id,
                "object_stream_surface_curve",
                "support_pcurve_lift",
                Exactness::Derived,
            )?;
            admission.charge()?;
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: directrix_id.clone(),
                geometry: curve,
                source_object: Some(cgm_source("curve", extrusion.directrix_object_id)?),
                native_ref: None,
            });
        }
        super::ResolvedExtrusionDirectrix::Offset {
            source_object_id,
            support,
            source_curve,
            source_parameter_range,
            distance,
            direction,
        } => {
            let source_id = crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "b5", "extrusion-directrix-source"),
                source_object_id,
                CurveId::mint,
            )?;
            annotate(
                annotations,
                &source_id,
                "object_stream_surface_curve",
                "support_pcurve_lift",
                Exactness::Derived,
            )?;
            admission.charge()?;
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: source_id.clone(),
                geometry: source_curve,
                source_object: Some(cgm_source("curve", source_object_id)?),
                native_ref: None,
            });
            annotate(
                annotations,
                &directrix_id,
                "object_stream_b5_03_14",
                "fixed_direction_offset_curve",
                Exactness::Unknown,
            )?;
            admission.charge()?;
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: directrix_id.clone(),
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Unknown { record: None }),
                source_object: Some(cgm_source("curve", extrusion.directrix_object_id)?),
                native_ref: None,
            });
            let procedure_id = crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "b5", "extrusion-directrix-procedure"),
                extrusion.directrix_object_id,
                ProceduralCurveId::mint,
            )?;
            annotate(
                annotations,
                &procedure_id,
                "object_stream_b5_03_14",
                "fixed_direction_offset_curve",
                Exactness::ByteExact,
            )?;
            admission.charge()?;
            let _attached = ir.geometry.add_procedural_curve(&directrix_id.clone(), ProceduralCurve::new(
                    procedure_id,
                    ProceduralCurveDefinition::Offset(
                        cadmpeg_ir::geometry::curve_payloads::OffsetCurveConstruction::along_direction(
                            source_id,
                            distance,
                            direction,
                            Some(surface_ids[&support.surface_object_id].clone()),
                            source_parameter_range,
                        ),
                    ),
                ));
        }
    }
    let procedure_id = crate::resource::compose_u32_id(
        &cadmpeg_ir::identity_namespace!("catia", "b5", "extrusion"),
        surface_object_id,
        ProceduralSurfaceId::mint,
    )?;
    annotate(
        annotations,
        &procedure_id,
        "object_stream_b5_03",
        "2c_extrusion_surface",
        Exactness::ByteExact,
    )?;
    let record_bounds = super::parameter_record_bounds(extrusion.parameter_bounds);
    admission.charge()?;
    let _attached = ir.geometry.add_procedural_surface(
        surface_id,
        ProceduralSurface::new(
            procedure_id,
            ProceduralSurfaceDefinition::Extrusion(
                cadmpeg_ir::geometry::surface_payloads::ExtrusionSurfaceConstruction::legacy(
                    directrix_id,
                    Some(extrusion.directrix_parameter_range.into()),
                    extrusion.direction.into(),
                    None,
                    None,
                ),
            ),
            Some(record_bounds),
        ),
    );
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{append_quadratic_span_knots, emit_extrusion_procedure};
    use crate::families::b5::transfer::surfaces::revolve_nurbs;
    use cadmpeg_ir::document::CadIr;
    use cadmpeg_ir::geometry::CurveGeometry;
    use cadmpeg_ir::geometry::ProceduralSurfaceDefinition;
    use cadmpeg_ir::geometry::SolvedCurveGeometry;
    use cadmpeg_ir::geometry::SolvedSurfaceGeometry;
    use cadmpeg_ir::geometry::Surface;
    use cadmpeg_ir::geometry::SurfaceGeometry;
    use cadmpeg_ir::ids::SurfaceId;
    use cadmpeg_ir::AnnotationBuilder;
    use std::collections::HashMap;

    use cadmpeg_ir::math::Vector3;

    use crate::families::b5::transfer::{
        ResolvedExtrusionDirectrix, ResolvedExtrusionSupport, ResolvedExtrusionSurface,
    };

    #[test]
    fn quadratic_span_knots_remain_finite_across_a_wide_native_interval() {
        let mut knots = Vec::new();
        for span in 0..2 {
            append_quadratic_span_knots(&mut knots, [-f64::MAX, f64::MAX], span, 2)
                .expect("finite interval maps to finite knots");
        }
        assert_eq!(
            knots,
            vec![
                -f64::MAX,
                -f64::MAX,
                -f64::MAX,
                0.0,
                0.0,
                f64::MAX,
                f64::MAX,
                f64::MAX,
            ]
        );
    }

    #[test]
    fn extrusion_emits_exact_reference_lift_without_intersection() {
        let support_ids = HashMap::from([
            (
                10,
                SurfaceId::mint("catia:test:surface#support-10".to_string())
                    .expect("identity grammar"),
            ),
            (
                20,
                SurfaceId::mint("catia:test:surface#support-20".to_string())
                    .expect("identity grammar"),
            ),
        ]);
        let extrusion = ResolvedExtrusionSurface {
            surface_object_id: 30,
            directrix_object_id: 40,
            directrix_parameter_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 3.0],
                [0.0, 1.0],
            ]),
            directrix: ResolvedExtrusionDirectrix::SurfaceCurve {
                support: ResolvedExtrusionSupport {
                    surface_object_id: 10,
                    surface: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                            cadmpeg_ir::math::Point3::new(0.0, 0.0, 0.0),
                            Vector3::new(1.0, 0.0, 0.0),
                            Vector3::new(0.0, 1.0, 0.0),
                        )
                        .expect("valid plane"),
                    )),
                },
                curve: CurveGeometry::Solved(SolvedCurveGeometry::Line(
                    cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                        cadmpeg_ir::math::Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 1.0, 0.0),
                    )
                    .expect("exact reference lift"),
                )),
            },
        };
        let mut ir = CadIr::empty();
        let surface_id = SurfaceId::mint("catia:test:surface#result-30").expect("identity grammar");
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });

        crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            emit_extrusion_procedure(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &support_ids,
                &surface_id,
                30,
                extrusion,
                &mut admission,
            )
            .expect("service limits admit the extrusion procedure");
        });

        assert!(matches!(
            &ir.geometry.curves[0].geometry,
            CurveGeometry::Solved(SolvedCurveGeometry::Line(_))
        ));
        assert!(ir.geometry.procedural_curves.is_empty());
        assert!(match ir.geometry.procedural_surfaces[0].definition() {
            ProceduralSurfaceDefinition::Extrusion(matched_payload) =>
                matches!((&matched_payload.parameter_interval().map(cadmpeg_ir::units::FiniteVector::get), matched_payload.direction(), &matched_payload.native_position(),), (Some([0.0, 1.0]), direction, None,) if *direction == Vector3::new(0.0, 0.0, 1.0)),
            _ => false,
        });
        assert_eq!(
            ir.geometry.procedural_surfaces[0]
                .record_bounds()
                .map(cadmpeg_ir::geometry::RecordBounds::get),
            Some([Some(-2.0), Some(3.0), Some(0.0), Some(1.0)])
        );
    }

    #[test]
    fn quarter_turn_revolution_of_a_line_builds_a_nurbs_surface() {
        use cadmpeg_ir::geometry::nurbs::NurbsCurve;
        use cadmpeg_ir::math::Point3;
        let profile = NurbsCurve::from_lanes(
            1,
            vec![0.0, 0.0, 1.0, 1.0],
            vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 0.0, 1.0)],
            None,
            false,
        )
        .expect("valid revolution profile");
        let run = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
            revolve_nurbs(
                ctx,
                &profile,
                [0.0; 3],
                [0.0, 0.0, 1.0],
                [[0.0, std::f64::consts::FRAC_PI_2], [0.0, 1.0]],
                &"test record",
                &mut crate::nurbs::LaneRefusals::new(),
            )
        };
        let admitted = crate::test_support::with_service_context(run).expect("revolve NURBS");
        assert!(admitted.is_some());
    }
}
