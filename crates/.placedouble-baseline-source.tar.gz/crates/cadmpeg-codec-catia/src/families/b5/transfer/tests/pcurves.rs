// SPDX-License-Identifier: Apache-2.0

use super::super::super::graph::{
    loop_chain_closes, B5Face, B5Graph, B5IncidenceLane, B5LogicalVertex, B5Loop, B5OpaquePcurve,
    B5ParameterIncidence, B5Pcurve, B5PcurveParameterization, B5Profile, B5SphereGreatCirclePcurve,
    B5Surface,
};
use crate::families::b5::tests::test_loop_members;
use crate::families::b5::tests::test_loop_metadata;
use crate::families::b5::transfer::{
    build_plan, resolved_surface_carrier_in_graph, transfer, CurvePlan, ResolvedPcurveSurface,
};
const EPS_PCURVE_CONE_GEOMETRY: f64 = 1.0e-12;
const EPS_PCURVE_RESIDUAL_INCREMENT: f64 = 1.0e-9;

use super::super::edges::merge_curve_plan;
use super::super::faces::{orient_loop_members, ownership_plan};
use super::super::pcurves::{
    cylinder_point, neutral_pcurve_point, oriented_line_plan, sphere_great_circle_geometry,
    sphere_great_circle_pcurve,
};
use super::super::surfaces::revolution_surface;
use crate::families::b5::graph::vertex_refs::B5VertexRef;
use cadmpeg_ir::document::CadIr;

use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve, pcurve::PcurveGeometry, CurveGeometry, ProceduralCurveDefinition,
    SolvedCurveGeometry, SolvedSurfaceGeometry, SurfaceGeometry,
};
use cadmpeg_ir::ids::UnknownId;
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::AnnotationBuilder;
use std::collections::{BTreeMap, HashMap, HashSet};

fn oriented_nurbs_range(
    geometry: &CurveGeometry,
    parameters: [f64; 2],
    edge_start: [f64; 3],
    edge_end: [f64; 3],
) -> Option<CurvePlan> {
    crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::oriented_nurbs_range(ctx, geometry, parameters, edge_start, edge_end)
    })
    .expect("compute the oriented NURBS range")
}

fn lifted_curve_geometry(pcurve: &B5Pcurve, surface: &B5Surface) -> Option<CurveGeometry> {
    crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::lifted_curve_geometry(ctx, pcurve, surface)
    })
    .expect("compute the lifted curve geometry")
}

fn isocurve_endpoint_parameters(pcurve: &B5Pcurve, parameters: [f64; 2]) -> Option<[f64; 2]> {
    crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::isocurve_endpoint_parameters(ctx, pcurve, parameters)
    })
    .expect("compute the isocurve endpoint parameters")
}

fn oriented_circle_plan(
    pcurve: &B5Pcurve,
    surface: &B5Surface,
    geometry: &CurveGeometry,
    parameters: [f64; 2],
    edge_start: [f64; 3],
    edge_end: [f64; 3],
) -> Option<CurvePlan> {
    crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::oriented_circle_plan(
            ctx, pcurve, surface, geometry, parameters, edge_start, edge_end,
        )
    })
    .expect("compute the oriented circle plan")
}

fn cylinder_helix(
    pcurve: &B5Pcurve,
    surface: &B5Surface,
    parameters: [f64; 2],
    edge_start: [f64; 3],
    edge_end: [f64; 3],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<super::super::HelixPlan> {
    crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::cylinder_helix(
            ctx, pcurve, surface, parameters, edge_start, edge_end, refusal,
        )
    })
    .expect("compute the cylinder helix")
}

#[test]
fn cylinder_pcurve_uses_independent_angular_scale_without_origin_rotation() {
    let surface = B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(6.0),
        u_range: crate::test_support::test_b5::increasing([1.0, 1.0 + 6.0 * std::f64::consts::PI]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(3.0),
        chart_origin: crate::test_support::test_b5::finite(1.0),
    };
    let point = neutral_pcurve_point([3.0 * std::f64::consts::PI, 3.0], &surface);
    assert_eq!(point.u, std::f64::consts::PI);
    assert_eq!(point.v, 3.0);
    let lifted = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        6.0,
        3.0,
        [3.0 * std::f64::consts::PI, 3.0],
    );
    assert!((lifted[0] + 6.0).abs() < 1.0e-12);
    assert!(lifted[1].abs() < 1.0e-12);
    assert_eq!(lifted[2], 3.0);
}

#[test]
fn revolution_cache_preserves_native_profile_and_arc_length_chart() {
    let profile = B5Profile::Line {
        point: crate::test_support::test_b5::point([2.0, 0.0, 0.0]),
        direction: crate::test_support::test_b5::exact_unit([0.0, 0.0, 1.0]),
        parameter_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let (surface, plan) = crate::test_support::with_service_context(|ctx| {
        revolution_surface(
            ctx,
            Some(&profile),
            (
                crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            ),
            crate::test_support::test_b5::positive(2.0),
            [[-1.0, 1.0], [0.0, 2.0 * std::f64::consts::PI]],
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("compute the revolution surface")
    .expect("exact revolution cache");
    assert_eq!(plan.parameter_interval, [-1.0, 1.0]);
    assert_eq!(plan.angular_interval, [0.0, std::f64::consts::PI]);
    assert_eq!(
        plan.angular_parameter_interval,
        [0.0, 2.0 * std::f64::consts::PI]
    );
    let evaluated = cadmpeg_ir::eval::decode::surface_point(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface)),
        0.5,
        std::f64::consts::PI,
    )
    .expect("surface point");
    assert!(evaluated.x.abs() < 1.0e-12);
    assert!((evaluated.y - 2.0).abs() < 1.0e-12);
    assert!((evaluated.z - 0.5).abs() < 1.0e-12);
    assert!(
        crate::test_support::with_service_context(|ctx| revolution_surface(
            ctx,
            Some(&profile),
            (
                crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            ),
            crate::test_support::test_b5::positive(2.0),
            [[-0.5, 1.0], [0.0, 2.0 * std::f64::consts::PI]],
            &"test record",
            &mut crate::nurbs::LaneRefusals::new(),
        ))
        .expect("compute the revolution surface")
        .is_none()
    );
}

#[test]
fn revolution_isocurve_keeps_its_native_trim_range() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let angular_range = [0.0, std::f64::consts::TAU];
    let graph = B5Graph {
        complete: true,
        faces: vec![B5Face {
            object_id: 1,
            surface: 10,
            loops: vec![2],
            terminal_control: None,
        }],
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(
            2,
            B5Loop {
                object_id: 2,
                members: test_loop_members(&[20], &[30]),
                metadata: test_loop_metadata(),
                surface: 10,
            },
        )]),
        pcurves: BTreeMap::from([(
            20,
            B5Pcurve {
                object_id: 20,
                surface: 10,
                degree: 1,
                distinct_knots: crate::test_support::test_b5::finite_lane(&angular_range),
                multiplicities: vec![2, 2],
                control_points: vec![
                    crate::test_support::test_b5::finite_vector([0.5, angular_range[0]]),
                    crate::test_support::test_b5::finite_vector([0.5, angular_range[1]]),
                ],
                weights: None,
                parameter_range: None,
                parameterization: B5PcurveParameterization::Native,
                class_21_suffix_scalar: None,
                lifted_endpoints: None,
            },
        )]),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::from([(
            10,
            B5Surface::Revolution {
                profile_curve: 110,
                axis_origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                axis_direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
                profile_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
                angular_range: crate::test_support::test_b5::increasing(angular_range),
                angular_scale: crate::test_support::test_b5::positive(1.0),
            },
        )]),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::from([
            (
                40,
                B5ParameterIncidence {
                    object_id: 40,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(angular_range[0]),
                        control: 0,
                    }],
                },
            ),
            (
                41,
                B5ParameterIncidence {
                    object_id: 41,
                    lanes: vec![B5IncidenceLane {
                        curve: 20,
                        parameter: crate::test_support::test_b5::finite(angular_range[1]),
                        control: 0,
                    }],
                },
            ),
        ]),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            vec![B5LogicalVertex {
                object_id: 50,
                point: crate::test_support::test_b5::point([2.0, 0.0, 0.5]),
            }],
            BTreeMap::from([(30, [B5VertexRef::Logical(0), B5VertexRef::Logical(0)])]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::from([(30, [40, 41])]),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::from([(
            110,
            B5Profile::Line {
                point: crate::test_support::test_b5::point([2.0, 0.0, 0.0]),
                direction: crate::test_support::test_b5::exact_unit([0.0, 0.0, 1.0]),
                parameter_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
            },
        )]),
    };
    assert!(matches!(
        crate::test_support::with_service_context(|ctx| resolved_surface_carrier_in_graph(
            ctx,
            &graph,
            10,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("compute the resolved surface carrier in graph"),
        Some(ResolvedPcurveSurface::Geometry(SurfaceGeometry::Solved(
            SolvedSurfaceGeometry::Nurbs(_)
        )))
    ));
    let plan = build_plan(
        &ctx,
        &graph,
        &UnknownId::mint("catia:test:unknown#catia:test-payload".to_string())
            .expect("identity grammar"),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("build the topology transfer plan")
    .expect("closed revolution graph");
    let curve = plan.edge_curve_plan.get(&30).expect("revolution isocurve");
    assert_eq!(curve.parameter_range, Some(angular_range));
    assert!(matches!(
        curve.geometry,
        CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(_))
    ));
}

#[test]
fn affine_and_isoparametric_pcurves_produce_exact_curve_carriers() {
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 2.0]),
            crate::test_support::test_b5::finite_vector([3.0, 2.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let plane = B5Surface::Plane {
        origin: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
        frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve))) =
        lifted_curve_geometry(&pcurve, &plane)
    else {
        panic!("plane lift must be NURBS");
    };
    assert_eq!(curve.control_points()[0], Point3::new(1.0, 4.0, 3.0));
    assert_eq!(curve.control_points()[1], Point3::new(4.0, 4.0, 3.0));

    let cylinder = B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(2.0),
        u_range: crate::test_support::test_b5::increasing([0.0, 4.0 * std::f64::consts::PI]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(2.0),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    assert!(matches!(
        lifted_curve_geometry(&pcurve, &cylinder),
        Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)))
            if { circle_curve.radius().get() == 2.0 }
    ));
    let meridian = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([1.0, -2.0]),
            crate::test_support::test_b5::finite_vector([1.0, 4.0]),
        ],
        ..pcurve
    };
    assert!(matches!(
        lifted_curve_geometry(&meridian, &cylinder),
        Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(_)))
    ));
}

#[test]
fn analytic_isocurves_accept_finite_nonzero_scales() {
    let scale = 1e-200;
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([0.5 * scale, 0.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let cylinder = B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(scale),
        u_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU * scale]),
        v_range: crate::test_support::test_b5::increasing([-scale, scale]),
        angular_scale: crate::test_support::test_b5::finite(scale),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    let geometry = lifted_curve_geometry(&pcurve, &cylinder).expect("cylinder latitude");
    let edge_start = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        scale,
        scale,
        pcurve.control_points[0].get(),
    );
    let edge_end = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        scale,
        scale,
        pcurve.control_points[1].get(),
    );
    assert!(oriented_circle_plan(
        &pcurve,
        &cylinder,
        &geometry,
        [0.0, 1.0],
        edge_start,
        edge_end,
    )
    .is_some());

    let cone = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(std::f64::consts::FRAC_PI_6),
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([0.0, scale]),
        angular_scale: crate::test_support::test_b5::positive(1.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    let cone_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, scale]),
            crate::test_support::test_b5::finite_vector([0.5, scale]),
        ],
        ..pcurve.clone()
    };
    assert!(
        matches!(lifted_curve_geometry(&cone_pcurve, &cone), Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)))
        if {
            let radius = circle_curve.radius().get();
            (radius - scale * std::f64::consts::FRAC_PI_6.cos()).abs() < EPS_PCURVE_CONE_GEOMETRY
        })
    );

    let torus = B5Surface::Torus {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        major_radius: crate::test_support::test_b5::positive_length(scale),
        minor_radius: crate::test_support::test_b5::positive_length(scale),
        major_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        major_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        minor_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        minor_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        major_scale: crate::test_support::test_b5::positive(1.0),
        minor_scale: crate::test_support::test_b5::positive(1.0),
    };
    let torus_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([0.5, 0.0]),
        ],
        ..pcurve
    };
    assert!(
        matches!(lifted_curve_geometry(&torus_pcurve, &torus), Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)))
        if {
            let radius = circle_curve.radius().get();
            radius == 2.0 * scale
        })
    );
}

#[test]
fn affine_plane_lift_preserves_pcurve_weights() {
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 2,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![3, 3],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([1.0, 0.0]),
            crate::test_support::test_b5::finite_vector([1.0, 1.0]),
            crate::test_support::test_b5::finite_vector([0.0, 1.0]),
        ],
        weights: Some(crate::test_support::test_b5::positive_lane(&[
            1.0,
            std::f64::consts::FRAC_1_SQRT_2,
            1.0,
        ])),
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let plane = B5Surface::Plane {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 2.0]),
        frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve))) =
        lifted_curve_geometry(&pcurve, &plane)
    else {
        panic!("expected lifted rational curve");
    };
    assert_eq!(
        curve.pole_rows().weights(),
        pcurve.weights.map(|weights| {
            weights
                .into_iter()
                .map(cadmpeg_ir::scalar::PositiveReal::get)
                .collect()
        })
    );
    assert!(curve.control_points().iter().all(|point| point.z == 2.0));
}

#[test]
fn affine_lift_range_orients_and_trims_the_nurbs_carrier() {
    let geometry = CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
        NurbsCurve::from_lanes(
            1,
            vec![0.0, 0.0, 10.0, 10.0],
            vec![Point3::new(0.0, 0.0, 2.0), Point3::new(10.0, 0.0, 2.0)],
            None,
            false,
        )
        .expect("valid affine lift curve"),
    ));
    let forward = oriented_nurbs_range(&geometry, [2.0, 8.0], [2.0, 0.0, 2.0], [8.0, 0.0, 2.0])
        .expect("forward trimmed range");
    assert_eq!(forward.geometry, geometry);
    assert_eq!(forward.parameter_range, Some([2.0, 8.0]));
    assert_eq!(forward.edge_tolerance, None);

    let reversed = oriented_nurbs_range(&geometry, [8.0, 2.0], [8.0, 0.0, 2.0], [2.0, 0.0, 2.0])
        .expect("reversed trimmed range");
    assert_eq!(reversed.parameter_range, Some([2.0, 8.0]));
    let Some(SolvedCurveGeometry::Nurbs(reversed)) = reversed.geometry.solved() else {
        unreachable!();
    };
    assert_eq!(
        reversed.control_points(),
        [Point3::new(10.0, 0.0, 2.0), Point3::new(0.0, 0.0, 2.0)]
    );
    assert!(
        oriented_nurbs_range(&geometry, [2.0, 8.0], [3.0, 0.0, 2.0], [8.0, 0.0, 2.0]).is_none()
    );

    let tolerant = oriented_nurbs_range(
        &CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
            NurbsCurve::from_lanes(
                1,
                vec![0.0, 0.0, 10.0, 10.0],
                vec![Point3::new(0.0, 0.0, 2.0), Point3::new(10.0, 0.0, 2.0)],
                None,
                false,
            )
            .expect("valid tolerant lift curve"),
        )),
        [2.0, 8.0],
        [2.0, 0.0, 2.0 + 1e-4],
        [8.0, 0.0, 2.0],
    )
    .expect("tolerant trimmed range");
    assert!(
        (tolerant.edge_tolerance.expect("edge tolerance").get()
            - (1e-4 + EPS_PCURVE_RESIDUAL_INCREMENT))
            .abs()
            < 1e-15
    );
}

#[test]
fn isocurve_range_uses_monotone_varying_surface_coordinate() {
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 2,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![3, 3],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([4.0, 2.0]),
            crate::test_support::test_b5::finite_vector([4.0, 6.0]),
            crate::test_support::test_b5::finite_vector([4.0, 10.0]),
        ],
        weights: Some(crate::test_support::test_b5::positive_lane(&[
            1.0, 2.0, 1.0,
        ])),
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    assert_eq!(
        isocurve_endpoint_parameters(&pcurve, [0.25, 0.75]),
        Some([50.0 / 11.0, 82.0 / 11.0])
    );

    let decreasing = B5Pcurve {
        control_points: pcurve.control_points.iter().copied().rev().collect(),
        ..pcurve.clone()
    };
    assert_eq!(
        isocurve_endpoint_parameters(&decreasing, [0.25, 0.75]),
        Some([82.0 / 11.0, 50.0 / 11.0])
    );

    let turnback = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([4.0, 2.0]),
            crate::test_support::test_b5::finite_vector([4.0, 10.0]),
            crate::test_support::test_b5::finite_vector([4.0, 6.0]),
        ],
        ..pcurve.clone()
    };
    assert!(isocurve_endpoint_parameters(&turnback, [0.0, 1.0]).is_none());
}

#[test]
fn analytic_line_range_uses_oriented_signed_distance() {
    let line = CurveGeometry::Solved(SolvedCurveGeometry::Line(
        cadmpeg_ir::geometry::analytic::LineCurve::try_new(
            Point3::new(1.0, 2.0, 3.0),
            Vector3::new(0.0, 0.0, 2.0)
                .unit()
                .expect("nonzero fixture direction"),
        )
        .expect("valid LineCurve fixture"),
    ));
    let forward =
        oriented_line_plan(&line, [1.0, 2.0, 5.0], [1.0, 2.0, 9.0]).expect("forward line range");
    assert_eq!(forward.parameter_range, Some([2.0, 6.0]));
    assert!(
        matches!(forward.geometry, CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve))
        if {
            let direction = *line_curve.direction().as_raw();
            direction == Vector3::new(0.0, 0.0, 1.0)
        })
    );

    let reversed =
        oriented_line_plan(&line, [1.0, 2.0, 9.0], [1.0, 2.0, 5.0]).expect("reversed line range");
    assert_eq!(reversed.parameter_range, Some([-6.0, -2.0]));
    assert!(
        matches!(reversed.geometry, CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve))
        if {
            let direction = *line_curve.direction().as_raw();
            direction == Vector3::new(0.0, 0.0, -1.0)
        })
    );
    let tolerant = oriented_line_plan(&line, [1.001, 2.0, 5.0], [1.0, 2.0, 9.0])
        .expect("tolerant line endpoints");
    assert!(tolerant
        .edge_tolerance
        .is_some_and(|value| value.get() > 0.001));
    assert_eq!(tolerant.cache_fit_tolerance, None);
    assert!(oriented_line_plan(&line, [1.01, 2.0, 5.0], [1.0, 2.0, 9.0]).is_none());
    assert!(oriented_line_plan(&line, [1.0, 2.0, 5.0], [1.0, 2.0, 5.0]).is_none());

    let tiny_direction = CurveGeometry::Solved(SolvedCurveGeometry::Line(
        cadmpeg_ir::geometry::analytic::LineCurve::try_new(
            Point3::new(0.0, 0.0, 0.0),
            cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid LineCurve fixture"),
    ));
    let tiny = oriented_line_plan(&tiny_direction, [2.0, 0.0, 0.0], [3.0, 0.0, 0.0])
        .expect("finite nonzero line direction");
    assert!(
        matches!(tiny.geometry, CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve))
        if {
            let direction = *line_curve.direction().as_raw();
            direction == Vector3::new(1.0, 0.0, 0.0)
        })
    );
}

#[test]
fn isoparametric_circle_range_preserves_winding_and_seams() {
    let cylinder = B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(2.0),
        u_range: crate::test_support::test_b5::increasing([0.0, 4.0 * std::f64::consts::PI]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(2.0),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([11.0, 3.0]),
            crate::test_support::test_b5::finite_vector([13.0, 3.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let geometry = lifted_curve_geometry(&pcurve, &cylinder).expect("cylinder latitude");
    let edge_start = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        2.0,
        2.0,
        pcurve.control_points[0].get(),
    );
    let edge_end = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        2.0,
        2.0,
        pcurve.control_points[1].get(),
    );
    let forward = oriented_circle_plan(
        &pcurve,
        &cylinder,
        &geometry,
        [0.0, 1.0],
        edge_start,
        edge_end,
    )
    .expect("seam-crossing circle range");
    assert_eq!(forward.parameter_range, Some([5.5, 6.5]));

    let tiny_sweep = 1e-14_f64;
    let tiny_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 3.0]),
            crate::test_support::test_b5::finite_vector([2.0 * tiny_sweep, 3.0]),
        ],
        ..pcurve.clone()
    };
    let tiny_geometry =
        lifted_curve_geometry(&tiny_pcurve, &cylinder).expect("tiny cylinder latitude");
    let tiny_end = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        2.0,
        2.0,
        tiny_pcurve.control_points[1].get(),
    );
    let tiny = oriented_circle_plan(
        &tiny_pcurve,
        &cylinder,
        &tiny_geometry,
        [0.0, 1.0],
        [2.0, 0.0, 3.0],
        tiny_end,
    )
    .expect("tiny circle sweep");
    assert_eq!(tiny.parameter_range, Some([0.0, tiny_sweep]));

    let reversed_pcurve = B5Pcurve {
        control_points: pcurve.control_points.iter().copied().rev().collect(),
        ..pcurve.clone()
    };
    let reversed = oriented_circle_plan(
        &reversed_pcurve,
        &cylinder,
        &geometry,
        [0.0, 1.0],
        edge_end,
        edge_start,
    )
    .expect("reversed circle range");
    let [start, end] = reversed.parameter_range.expect("canonical range");
    assert!(start >= 0.0 && end > start && end - start == 1.0);
    assert!(
        matches!(reversed.geometry, CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))
        if {
            let axis = circle_curve.frame().axis().as_raw();
            *axis == Vector3::new(0.0, 0.0, -1.0)
        })
    );

    let turnback = B5Pcurve {
        degree: 2,
        multiplicities: vec![3, 3],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 3.0]),
            crate::test_support::test_b5::finite_vector([4.0, 3.0]),
            crate::test_support::test_b5::finite_vector([2.0, 3.0]),
        ],
        ..pcurve
    };
    let turnback_geometry =
        lifted_curve_geometry(&turnback, &cylinder).expect("turnback latitude locus");
    let turnback_end = cylinder_point(
        [0.0; 3],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        2.0,
        2.0,
        [2.0, 3.0],
    );
    assert!(oriented_circle_plan(
        &turnback,
        &cylinder,
        &turnback_geometry,
        [0.0, 1.0],
        [2.0, 0.0, 3.0],
        turnback_end,
    )
    .is_none());

    let radial_angle = std::f64::consts::FRAC_PI_6;
    let cone = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(radial_angle),
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([-4.0, 0.0]),
        angular_scale: crate::test_support::test_b5::positive(2.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    let cone_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, -4.0]),
            crate::test_support::test_b5::finite_vector([2.0, -4.0]),
        ],
        ..reversed_pcurve
    };
    let cone_geometry = lifted_curve_geometry(&cone_pcurve, &cone).expect("signed cone latitude");
    let cone_point = |angle: f64| {
        [
            -4.0 * radial_angle.cos() * angle.cos(),
            -4.0 * radial_angle.cos() * angle.sin(),
            -4.0 * radial_angle.sin(),
        ]
    };
    let signed = oriented_circle_plan(
        &cone_pcurve,
        &cone,
        &cone_geometry,
        [0.0, 1.0],
        cone_point(0.0),
        cone_point(1.0),
    )
    .expect("normalized signed-radius circle");
    assert!(
        matches!(signed.geometry, CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))
                if {
                    let ref_direction = circle_curve.frame().reference().as_raw();
        let radius = circle_curve.radius().get();
                    (radius - 4.0 * radial_angle.cos()).abs() < EPS_PCURVE_CONE_GEOMETRY && *ref_direction == Vector3::new(-1.0, 0.0, 0.0)
                })
    );
}

#[test]
fn edge_curve_plans_merge_proofs_and_discard_conflicting_carriers() {
    let geometry = CurveGeometry::Solved(SolvedCurveGeometry::Line(
        cadmpeg_ir::geometry::analytic::LineCurve::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid LineCurve fixture"),
    ));
    let mut plans = HashMap::new();
    let mut conflicts = HashSet::new();
    merge_curve_plan(
        &mut plans,
        &mut conflicts,
        4,
        CurvePlan {
            geometry: geometry.clone(),
            parameter_range: None,
            edge_tolerance: None,
            cache_fit_tolerance: None,
        },
    );
    merge_curve_plan(
        &mut plans,
        &mut conflicts,
        4,
        CurvePlan {
            geometry,
            parameter_range: Some([2.0, 8.0]),
            edge_tolerance: None,
            cache_fit_tolerance: None,
        },
    );
    assert_eq!(plans[&4].parameter_range, Some([2.0, 8.0]));

    let conflicting = CurvePlan {
        geometry: CurveGeometry::Solved(SolvedCurveGeometry::Line(
            cadmpeg_ir::geometry::analytic::LineCurve::try_new(
                Point3::new(0.0, 1.0, 0.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid LineCurve fixture"),
        )),
        parameter_range: Some([2.0, 8.0]),
        edge_tolerance: None,
        cache_fit_tolerance: None,
    };
    merge_curve_plan(&mut plans, &mut conflicts, 4, conflicting.clone());
    assert!(!plans.contains_key(&4));
    assert!(conflicts.contains(&4));
    merge_curve_plan(&mut plans, &mut conflicts, 4, conflicting);
    assert!(!plans.contains_key(&4));
}

#[test]
fn cone_chart_normalizes_arc_length_and_slant_coordinates() {
    let radial_angle = std::f64::consts::FRAC_PI_6;
    let cone = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(radial_angle),
        reference_radius: crate::test_support::test_b5::finite(4.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([2.0, 8.0]),
        angular_scale: crate::test_support::test_b5::positive(3.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[
            0.0,
            3.0 * std::f64::consts::PI,
        ]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 4.0]),
            crate::test_support::test_b5::finite_vector([3.0 * std::f64::consts::PI, 4.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    assert_eq!(
        pcurve
            .control_points
            .iter()
            .map(|point| neutral_pcurve_point(point.get(), &cone))
            .collect::<Vec<_>>(),
        [
            Point2::new(0.0, 2.0 * radial_angle.sin()),
            Point2::new(std::f64::consts::PI, 2.0 * radial_angle.sin()),
        ]
    );
    let mut opposite_handed = cone.clone();
    let B5Surface::Cone { frame, .. } = &mut opposite_handed else {
        unreachable!();
    };
    *frame = crate::test_support::test_b5::frame([0.0, 0.0, -1.0], [1.0, 0.0, 0.0]);
    assert_eq!(
        neutral_pcurve_point([3.0 * std::f64::consts::PI, 4.0], &opposite_handed),
        Point2::new(-std::f64::consts::PI, 2.0 * radial_angle.sin())
    );
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))) =
        lifted_curve_geometry(&pcurve, &cone)
    else {
        panic!("expected cone latitude circle");
    };
    let center = circle_curve.center().get();
    let axis = circle_curve.frame().axis().as_raw();
    let radius = circle_curve.radius().get();
    assert_eq!(center, Point3::new(0.0, 0.0, 4.0 * radial_angle.sin()));
    assert_eq!(*axis, Vector3::new(0.0, 0.0, 1.0));
    assert!((radius - (4.0 + 4.0 * radial_angle.cos())).abs() < EPS_PCURVE_CONE_GEOMETRY);
    let opposite_geometry =
        lifted_curve_geometry(&pcurve, &opposite_handed).expect("left-handed latitude carrier");
    assert!(oriented_circle_plan(
        &pcurve,
        &opposite_handed,
        &opposite_geometry,
        [0.0, 3.0 * std::f64::consts::PI],
        [radius, 0.0, -4.0 * radial_angle.sin()],
        [-radius, 0.0, -4.0 * radial_angle.sin()],
    )
    .is_some());
    let mut shifted_cone = cone.clone();
    let B5Surface::Cone { slant_shift, .. } = &mut shifted_cone else {
        unreachable!();
    };
    *slant_shift = crate::test_support::test_b5::finite(1.25);
    let shifted_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 5.25]),
            crate::test_support::test_b5::finite_vector([3.0 * std::f64::consts::PI, 5.25]),
        ],
        ..pcurve.clone()
    };
    assert_eq!(
        neutral_pcurve_point([0.0, 5.25], &shifted_cone),
        neutral_pcurve_point([0.0, 4.0], &cone)
    );
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(shifted_circle))) =
        lifted_curve_geometry(&shifted_pcurve, &shifted_cone)
    else {
        panic!("expected shifted cone latitude circle");
    };
    assert_eq!(shifted_circle, circle_curve);
    let generator = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 3.0]),
            crate::test_support::test_b5::finite_vector([0.0, 5.0]),
        ],
        ..pcurve
    };
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Line(line))) =
        lifted_curve_geometry(&generator, &cone)
    else {
        panic!("expected cone generator line");
    };
    assert_eq!(line.origin().get(), Point3::new(4.0, 0.0, 0.0));
    let expected = [radial_angle.cos(), 0.0, radial_angle.sin()];
    let direction = line.direction();
    let direction = direction.as_raw();
    assert!([direction.x, direction.y, direction.z]
        .into_iter()
        .zip(expected)
        .all(|(a, b)| (a - b).abs() < EPS_PCURVE_CONE_GEOMETRY));
}

#[test]
fn sphere_class_1d_fields_lift_to_the_exact_great_circle_plane() {
    let sphere = B5Surface::Sphere {
        center: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(5.0),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        construction_radius: crate::test_support::test_b5::positive_length(8.0),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    let pcurve = B5SphereGreatCirclePcurve {
        u_bounds: crate::test_support::test_b5::increasing([0.0, 8.0]),
        v_bounds: crate::test_support::test_b5::finite_pair([0.0, std::f64::consts::TAU * 8.0]),
        chart_shift: crate::test_support::test_b5::finite(0.0),
        chart_scale: crate::test_support::test_b5::positive(8.0),
        slope: crate::test_support::test_b5::finite(-1.0),
        phase: crate::test_support::test_b5::finite(-std::f64::consts::FRAC_PI_2),
    };
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))) =
        sphere_great_circle_geometry(&pcurve, &sphere)
    else {
        panic!("expected great circle");
    };
    let center = circle_curve.center().get();
    let axis = circle_curve.frame().axis().as_raw();
    let ref_direction = circle_curve.frame().reference().as_raw();
    let radius = circle_curve.radius().get();
    assert_eq!(center, Point3::new(1.0, 2.0, 3.0));
    assert!((radius - 5.0).abs() < 1.0e-12);
    assert!((axis.x * axis.x + axis.y * axis.y + axis.z * axis.z - 1.0).abs() < 1.0e-12);
    assert!(
        (axis.x * ref_direction.x + axis.y * ref_direction.y + axis.z * ref_direction.z).abs()
            < 1.0e-12
    );
    assert!((axis.y + std::f64::consts::FRAC_1_SQRT_2).abs() < 1.0e-12);
    assert!((axis.z - std::f64::consts::FRAC_1_SQRT_2).abs() < 1.0e-12);

    let (geometry, range) =
        sphere_great_circle_pcurve(&pcurve).expect("exact parameter-space curve");
    assert_eq!(range, crate::test_support::test_b5::finite_pair([0.0, 8.0]));
    let uv = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &geometry,
        8.0,
    )
    .expect("chart endpoint");
    assert_eq!(uv.u, 1.0);
    assert!((uv.v - (-(1.0 + std::f64::consts::FRAC_PI_2).cos()).atan()).abs() < 1.0e-12);

    let tiny = 1e-200;
    let mut tiny_sphere = sphere;
    let B5Surface::Sphere {
        construction_radius,
        radius,
        ..
    } = &mut tiny_sphere
    else {
        unreachable!()
    };
    *construction_radius = crate::test_support::test_b5::positive_length(tiny);
    *radius = crate::test_support::test_b5::positive_length(tiny);
    let tiny_pcurve = B5SphereGreatCirclePcurve {
        u_bounds: crate::test_support::test_b5::increasing([0.0, tiny]),
        v_bounds: crate::test_support::test_b5::finite_pair([0.0, std::f64::consts::TAU * tiny]),
        chart_shift: crate::test_support::test_b5::finite(0.0),
        chart_scale: crate::test_support::test_b5::positive(tiny),
        slope: crate::test_support::test_b5::finite(-1.0),
        phase: crate::test_support::test_b5::finite(0.0),
    };
    assert!(sphere_great_circle_geometry(&tiny_pcurve, &tiny_sphere).is_some());
    let (geometry, range) =
        sphere_great_circle_pcurve(&tiny_pcurve).expect("tiny parameter-space curve");
    assert_eq!(
        range,
        crate::test_support::test_b5::finite_pair([0.0, tiny])
    );
    let uv = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &geometry,
        tiny,
    )
    .expect("tiny chart endpoint");
    assert_eq!(uv.u, 1.0);
}

#[test]
fn owned_sphere_class_1d_pcurve_enters_the_transfer_plan() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let chart_scale = 8.0;
    let parameter_range = [0.0, 4.0 * std::f64::consts::PI];
    let graph = B5Graph {
        complete: true,
        faces: vec![B5Face {
            object_id: 1,
            surface: 2,
            loops: vec![3],
            terminal_control: None,
        }],
        face_records: BTreeMap::new(),
        loops: BTreeMap::from([(
            3,
            B5Loop {
                object_id: 3,
                members: test_loop_members(&[4, 4, 4], &[5, 6, 7]),
                metadata: test_loop_metadata(),
                surface: 2,
            },
        )]),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::from([(
            4,
            B5OpaquePcurve {
                object_id: 4,
                surface: 2,
                class: 0x1d,
                payload: Vec::new(),
                sphere_great_circle: Some(B5SphereGreatCirclePcurve {
                    u_bounds: crate::test_support::test_b5::increasing(parameter_range),
                    v_bounds: crate::test_support::test_b5::finite_pair([
                        0.0,
                        std::f64::consts::TAU * chart_scale,
                    ]),
                    chart_shift: crate::test_support::test_b5::finite(0.0),
                    chart_scale: crate::test_support::test_b5::positive(chart_scale),
                    slope: crate::test_support::test_b5::finite(0.0),
                    phase: crate::test_support::test_b5::finite(0.0),
                }),
            },
        )]),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::from([(
            2,
            B5Surface::Sphere {
                center: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
                frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
                direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
                radius: crate::test_support::test_b5::positive_length(5.0),
                azimuth_range: crate::test_support::test_b5::increasing([
                    0.0,
                    std::f64::consts::TAU,
                ]),
                latitude_range: crate::test_support::test_b5::increasing([
                    -std::f64::consts::FRAC_PI_2,
                    std::f64::consts::FRAC_PI_2,
                ]),
                construction_radius: crate::test_support::test_b5::positive_length(chart_scale),
                chart_origin: crate::test_support::test_b5::finite(0.0),
            },
        )]),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::new(),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            vec![[5.0, 0.0, 0.0], [0.0, 5.0, 0.0], [-5.0, 0.0, 0.0]]
                .into_iter()
                .map(crate::test_support::test_b5::point)
                .collect(),
            Vec::new(),
            BTreeMap::from([
                (5, [B5VertexRef::Raw(0), B5VertexRef::Raw(1)]),
                (6, [B5VertexRef::Raw(1), B5VertexRef::Raw(2)]),
                (7, [B5VertexRef::Raw(2), B5VertexRef::Raw(0)]),
            ]),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::new(),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };
    let payload = UnknownId::mint("catia:test:unknown#catia:test-payload".to_string())
        .expect("identity grammar");

    assert!(ownership_plan(&ctx, &graph)
        .expect("build the ownership plan")
        .is_some());
    assert!(loop_chain_closes(&graph.loops[&3], graph.vertices.edges()));
    let senses = graph.loops[&3].edge_senses();
    assert!(
        orient_loop_members(&ctx, &graph, BTreeMap::from([(3, senses)]))
            .expect("orient the loop members")
            .is_some()
    );
    let plan = build_plan(
        &ctx,
        &graph,
        &payload,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("build the topology transfer plan")
    .expect("complete owned graph");

    assert_eq!(
        plan.pcurve_plan.get(&4),
        Some(&(
            PcurveGeometry::SphericalGreatCircle(
                cadmpeg_ir::geometry::pcurve::SphericalGreatCirclePcurve::try_new(
                    0.0,
                    chart_scale.recip(),
                    0.0,
                    0.0
                )
                .expect("valid SphericalGreatCirclePcurve fixture")
            ),
            false,
            crate::test_support::test_b5::finite_pair(parameter_range),
        ))
    );
    assert_eq!(
        plan.edge_support_plan.get(&5),
        Some(&vec![(
            2,
            4,
            crate::test_support::test_b5::finite_pair(parameter_range)
        )])
    );
    assert!(plan.exact_support_edges.contains(&5));

    let mut ir = CadIr::empty();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        assert!(transfer(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &graph,
            &payload,
            &mut crate::nurbs::LaneRefusals::new(),
            &mut admission,
        )
        .expect("transfer the B5 topology"));
    });
    assert_eq!(ir.geometry.pcurves.len(), 1);
    assert!(matches!(
        ir.geometry.pcurves[0].geometry,
        PcurveGeometry::SphericalGreatCircle(_)
    ));
}

/// One closed spherical component of a synthetic B5 graph. `face`, `loop_`,
/// `pcurve`, and `surface` are persistent object ids; `edges` names the three
/// edge object ids and `vertices` the three vertex-point rows.
struct SyntheticSphericalComponent {
    face: u32,
    loop_: u32,
    pcurve: u32,
    surface: u32,
    edges: [u32; 3],
    vertices: [usize; 3],
    center: [f64; 3],
}

/// Build a B5 graph of independent closed spherical components. Each
/// component contributes one face carrying one three-member loop over a
/// single class-`1d` great-circle pcurve, as in
/// [`owned_sphere_class_1d_pcurve_enters_the_transfer_plan`].
fn synthetic_spherical_graph(components: &[SyntheticSphericalComponent]) -> B5Graph {
    let chart_scale = 8.0;
    let parameter_range = [0.0, 4.0 * std::f64::consts::PI];
    let radius = 5.0;
    let mut graph = B5Graph {
        complete: true,
        faces: Vec::new(),
        face_records: BTreeMap::new(),
        loops: BTreeMap::new(),
        pcurves: BTreeMap::new(),
        opaque_pcurves: BTreeMap::new(),
        implicit_pcurves: BTreeMap::new(),
        surfaces: BTreeMap::new(),
        surface_aliases: BTreeMap::new(),
        offset_surfaces: BTreeMap::new(),
        extrusion_surfaces: BTreeMap::new(),
        supported_surfaces: BTreeMap::new(),
        parameter_incidences: BTreeMap::new(),
        edges: BTreeMap::new(),
        vertex_incidence_links: BTreeMap::new(),
        vertices: crate::families::b5::graph::vertex_refs::B5Vertices::try_new(
            Vec::new(),
            Vec::new(),
            BTreeMap::new(),
        )
        .expect("valid vertex bindings"),
        edge_parameter_incidences: BTreeMap::new(),
        vertex_tolerances: BTreeMap::new(),
        profiles: BTreeMap::new(),
    };
    for component in components {
        graph.faces.push(B5Face {
            object_id: component.face,
            surface: component.surface,
            loops: vec![component.loop_],
            terminal_control: None,
        });
        graph.loops.insert(
            component.loop_,
            B5Loop {
                object_id: component.loop_,
                members: test_loop_members(&[component.pcurve; 3], &component.edges),
                metadata: test_loop_metadata(),
                surface: component.surface,
            },
        );
        graph.opaque_pcurves.insert(
            component.pcurve,
            B5OpaquePcurve {
                object_id: component.pcurve,
                surface: component.surface,
                class: 0x1d,
                payload: Vec::new(),
                sphere_great_circle: Some(B5SphereGreatCirclePcurve {
                    u_bounds: crate::test_support::test_b5::increasing(parameter_range),
                    v_bounds: crate::test_support::test_b5::finite_pair([
                        0.0,
                        std::f64::consts::TAU * chart_scale,
                    ]),
                    chart_shift: crate::test_support::test_b5::finite(0.0),
                    chart_scale: crate::test_support::test_b5::positive(chart_scale),
                    slope: crate::test_support::test_b5::finite(0.0),
                    phase: crate::test_support::test_b5::finite(0.0),
                }),
            },
        );
        graph.surfaces.insert(
            component.surface,
            B5Surface::Sphere {
                center: crate::test_support::test_b5::point(component.center),
                frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
                direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
                radius: crate::test_support::test_b5::positive_length(radius),
                azimuth_range: crate::test_support::test_b5::increasing([
                    0.0,
                    std::f64::consts::TAU,
                ]),
                latitude_range: crate::test_support::test_b5::increasing([
                    -std::f64::consts::FRAC_PI_2,
                    std::f64::consts::FRAC_PI_2,
                ]),
                construction_radius: crate::test_support::test_b5::positive_length(chart_scale),
                chart_origin: crate::test_support::test_b5::finite(0.0),
            },
        );
        let points = [
            [
                component.center[0] + radius,
                component.center[1],
                component.center[2],
            ],
            [
                component.center[0],
                component.center[1] + radius,
                component.center[2],
            ],
            [
                component.center[0] - radius,
                component.center[1],
                component.center[2],
            ],
        ];
        for (row, point) in component.vertices.into_iter().zip(points) {
            assert_eq!(
                row,
                graph.vertices.raw_points().len(),
                "contiguous vertex rows"
            );
            graph
                .vertices
                .push_raw(crate::test_support::test_b5::point(point));
        }
        for (position, edge) in component.edges.into_iter().enumerate() {
            graph
                .vertices
                .insert_edge(
                    edge,
                    [
                        B5VertexRef::Raw(component.vertices[position]),
                        B5VertexRef::Raw(component.vertices[(position + 1) % 3]),
                    ],
                )
                .expect("edge references select existing rows");
        }
    }
    graph
}

/// B5 object ids carry an unpadded decimal key, so a face pair such as
/// `#9`/`#10` reaches the neutral model in ascending native order while
/// sorting the other way. The route must still produce an admissible model.
#[test]
fn decimal_object_id_keys_transfer_to_an_admissible_model() {
    let graph = synthetic_spherical_graph(&[
        SyntheticSphericalComponent {
            face: 9,
            loop_: 29,
            pcurve: 39,
            surface: 2,
            edges: [49, 50, 51],
            vertices: [0, 1, 2],
            center: [0.0, 0.0, 0.0],
        },
        SyntheticSphericalComponent {
            face: 10,
            loop_: 200,
            pcurve: 300,
            surface: 12,
            edges: [400, 401, 402],
            vertices: [3, 4, 5],
            center: [100.0, 0.0, 0.0],
        },
    ]);

    let mut ir = CadIr::empty();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        assert!(transfer(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &graph,
            &UnknownId::mint("catia:payload:unknown#test".to_string()).expect("identity grammar"),
            &mut crate::nurbs::LaneRefusals::new(),
            &mut admission,
        )
        .expect("transfer the B5 topology"));
    });

    // Native traversal order, which the arena-order check reads as unsorted.
    assert_eq!(
        ir.geometry
            .faces
            .iter()
            .map(|face| face.id.as_str())
            .collect::<Vec<_>>(),
        ["catia:b5:face#9", "catia:b5:face#10"]
    );
    assert_eq!(ir.geometry.loops.len(), 2);
    assert_eq!(ir.geometry.shells.len(), 2);
    assert_eq!(ir.geometry.regions.len(), 2);
    assert_eq!(ir.geometry.edges.len(), 6);
    assert_eq!(ir.geometry.coedges.len(), 6);
    assert_eq!(ir.geometry.vertices.len(), 6);
    assert_eq!(ir.geometry.pcurves.len(), 2);
    let unsorted_arenas = cadmpeg_ir::validate::validate_neutral(&ir, Vec::new())
        .expect("validate the neutral model")
        .findings
        .iter()
        .filter(|finding| finding.check == cadmpeg_ir::report::check::Check::ArenaOrder)
        .count();
    assert!(
        unsorted_arenas >= 6,
        "one component cannot unsort this many arenas: {unsorted_arenas}"
    );

    assert!(crate::assemble::neutral_model_is_admissible(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        &mut ir,
        &[]
    )
    .expect("check that the neutral model is admissible"));
    assert_eq!(
        ir.geometry
            .faces
            .iter()
            .map(|face| face.id.as_str())
            .collect::<Vec<_>>(),
        ["catia:b5:face#10", "catia:b5:face#9"]
    );
}

#[test]
fn torus_chart_lifts_meridians_and_latitudes_exactly() {
    let torus = B5Surface::Torus {
        center: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        major_radius: crate::test_support::test_b5::positive_length(5.0),
        minor_radius: crate::test_support::test_b5::positive_length(2.0),
        major_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        major_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        minor_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        minor_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        major_scale: crate::test_support::test_b5::positive(5.0),
        minor_scale: crate::test_support::test_b5::positive(2.0),
    };
    let base = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([0.0, 4.0 * std::f64::consts::PI]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    assert_eq!(
        neutral_pcurve_point([5.0 * std::f64::consts::PI, 2.0], &torus),
        Point2::new(std::f64::consts::PI, 1.0)
    );
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))) =
        lifted_curve_geometry(&base, &torus)
    else {
        panic!("expected meridian circle");
    };
    let center = circle_curve.center().get();
    let axis = circle_curve.frame().axis().as_raw();
    let radius = circle_curve.radius().get();
    assert_eq!(center, Point3::new(5.0, 0.0, 0.0));
    assert_eq!(*axis, Vector3::new(0.0, -1.0, 0.0));
    assert_eq!(radius, 2.0);

    let latitude = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([10.0 * std::f64::consts::PI, 0.0]),
        ],
        ..base
    };
    let Some(CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))) =
        lifted_curve_geometry(&latitude, &torus)
    else {
        panic!("expected latitude circle");
    };
    let center = circle_curve.center().get();
    let axis = circle_curve.frame().axis().as_raw();
    let radius = circle_curve.radius().get();
    assert_eq!(center, Point3::new(0.0, 0.0, 0.0));
    assert_eq!(*axis, Vector3::new(0.0, 0.0, 1.0));
    assert_eq!(radius, 7.0);
}

#[test]
fn tensor_surface_contraction_preserves_exact_isocurve() {
    let surface = cadmpeg_ir::geometry::nurbs::NurbsSurface::from_lanes(
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(
            vec![
                vec![Point3::new(0.0, 0.0, 0.0), Point3::new(0.0, 1.0, 0.0)],
                vec![Point3::new(2.0, 0.0, 0.0), Point3::new(2.0, 1.0, 2.0)],
            ],
            None,
        ),
        false,
    )
    .expect("valid tensor surface");
    let curve = cadmpeg_ir::eval::nurbs_surface_isocurve(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &surface,
        cadmpeg_ir::geometry::nurbs::SurfaceParameterAxis::U,
        0.25,
    )
    .expect("build the NURBS surface isocurve")
    .expect("u isocurve");
    assert_eq!(curve.degree(), 1);
    assert_eq!(curve.knots(), surface.v_knots());
    assert_eq!(curve.control_points()[0], Point3::new(0.5, 0.0, 0.0));
    assert_eq!(curve.control_points()[1], Point3::new(0.5, 1.0, 0.5));
}

#[test]
fn affine_cylinder_pcurve_preserves_exact_helix_construction() {
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 3.0]),
            crate::test_support::test_b5::finite_vector([4.0, 7.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let cylinder = B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.0]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(2.0),
        u_range: crate::test_support::test_b5::increasing([0.0, 4.0 * std::f64::consts::PI]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(2.0),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    let end = [2.0 * 2.0_f64.cos(), 2.0 * 2.0_f64.sin(), 7.0];
    let Some(plan) = cylinder_helix(
        &pcurve,
        &cylinder,
        [0.0, 1.0],
        [2.0, 0.0, 3.0],
        end,
        &mut crate::nurbs::LaneRefusals::new(),
    ) else {
        panic!("degree-one cylinder helix");
    };
    let ProceduralCurveDefinition::Helix(helix_payload) = &plan.definition else {
        unreachable!();
    };
    let angle_range = helix_payload.angle_range();
    let center = helix_payload.center().as_raw();
    let pitch = helix_payload.pitch();
    let apex_factor = helix_payload.apex_factor();

    assert_eq!(angle_range.get(), [0.0, 2.0]);
    assert_eq!(*center, Point3::new(0.0, 0.0, 3.0));
    assert!((pitch.z - 4.0 * std::f64::consts::PI).abs() < 1.0e-12);
    assert_eq!(apex_factor.get(), 0.0);
    assert_eq!(plan.parameter_range, [0.0, 2.0]);
    assert!(plan.fit_tolerance.get() <= 1e-4);
    assert_eq!(
        plan.cache.pole_rows().raw_points().first(),
        Some(&Point3::new(2.0, 0.0, 3.0))
    );

    assert!(
        cylinder_helix(
            &pcurve,
            &cylinder,
            [0.0, 1.0],
            end,
            [2.0, 0.0, 3.0],
            &mut crate::nurbs::LaneRefusals::new()
        )
        .is_none(),
        "the native edge endpoint order is authoritative"
    );

    let trimmed_start = [2.0 * 0.5_f64.cos(), 2.0 * 0.5_f64.sin(), 4.0];
    let trimmed_end = [2.0 * 1.5_f64.cos(), 2.0 * 1.5_f64.sin(), 6.0];
    let trimmed = cylinder_helix(
        &pcurve,
        &cylinder,
        [0.25, 0.75],
        trimmed_start,
        trimmed_end,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("trimmed physical edge helix");
    let ProceduralCurveDefinition::Helix(helix_payload) = trimmed.definition else {
        unreachable!();
    };
    let angle_range = *helix_payload.angle_range();
    let center = *helix_payload.center().as_raw();
    let pitch = *helix_payload.pitch();

    assert_eq!(angle_range.get(), [0.0, 1.0]);
    assert_eq!(center.z, 4.0);
    assert!((pitch.z - 4.0 * std::f64::consts::PI).abs() < 1.0e-12);

    let tiny = 1e-14_f64;
    let tiny_pcurve = B5Pcurve {
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.0, 0.0]),
            crate::test_support::test_b5::finite_vector([2.0 * tiny, 2.0 * tiny]),
        ],
        ..pcurve
    };
    let tiny_end = [2.0 * tiny.cos(), 2.0 * tiny.sin(), 2.0 * tiny];
    let tiny_plan = cylinder_helix(
        &tiny_pcurve,
        &cylinder,
        [0.0, 1.0],
        [2.0, 0.0, 0.0],
        tiny_end,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("tiny helix sweep");
    let ProceduralCurveDefinition::Helix(helix_payload) = tiny_plan.definition else {
        unreachable!();
    };
    let angle_range = *helix_payload.angle_range();
    let pitch = *helix_payload.pitch();

    assert_eq!(angle_range.get(), [0.0, tiny]);
    assert!((pitch.z - 4.0 * std::f64::consts::PI).abs() < 1.0e-12);
}

#[test]
fn bilinear_surface_lifts_a_constant_u_pcurve_to_its_isocurve() {
    use cadmpeg_ir::geometry::nurbs::{NurbsSurface, NurbsSurfaceAxis, NurbsSurfaceLanes};
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[0.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([0.5, 0.0]),
            crate::test_support::test_b5::finite_vector([0.5, 1.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    let surface = NurbsSurface::from_lanes(
        NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        NurbsSurfaceLanes::new(
            vec![
                vec![Point3::new(0.0, 0.0, 0.0), Point3::new(0.0, 1.0, 0.0)],
                vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 1.0, 0.0)],
            ],
            None,
        ),
        false,
    )
    .expect("valid bilinear surface");
    let curve = crate::test_support::with_service_context(|ctx| {
        super::super::pcurves::nurbs_isocurve(ctx, &pcurve, &surface)
    })
    .expect("compute the NURBS isocurve")
    .expect("bilinear isocurve");
    assert_eq!(
        curve.control_points(),
        [Point3::new(0.5, 0.0, 0.0), Point3::new(0.5, 1.0, 0.0)]
    );
    assert_eq!(curve.knots().as_slice(), [0.0, 0.0, 1.0, 1.0]);
    assert!(curve.weights().is_none());
}
