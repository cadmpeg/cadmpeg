// SPDX-License-Identifier: Apache-2.0
//! Object-id topology in the CATIA `b5 03` short-frame family.

use cadmpeg_core::convert::{f64_from_index, truncate_f64_to_i64, truncate_f64_to_usize};

type VertexComponentOutput = (HashMap<u32, usize>, Vec<usize>, bool);
type CirclePcurveFields = Option<(u32, [f64; 2], f64, [f64; 2], [f64; 2])>;
type Class1aPcurveFields = Option<(u32, [f64; 2], [f64; 2], [f64; 2], f64, [f64; 2], [f64; 2])>;
type LoopReferencesOutput = Option<(Vec<u32>, B5LoopMetadata, Vec<[i16; 3]>)>;

use std::collections::{BTreeMap, HashMap, HashSet};
use std::ops::Range;

use cadmpeg_core::decode::{DecodeContext, View, WorkBudget};
use cadmpeg_core::CodecError;
use cadmpeg_ir::eval::nurbs_pcurve_uv;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    analytic::ConeSurface, nurbs::NurbsSurface, ProceduralSurfaceDefinition,
};
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::scalar::{
    Angle, FiniteReal, NonNegativeLength, PositiveAngle, PositiveLength, PositiveReal,
};
use cadmpeg_ir::topology::IncreasingParameterInterval;
use cadmpeg_ir::units::{FiniteVector, OrthonormalFrame3, UnitVector3};

/// Admitted topology control bytes.
pub(in crate::families) mod controls;
/// Source-closed shell orientation for selected standard plane charts.
pub(in crate::families) mod shell_orientation;
/// Vertex tables and typed endpoint references.
pub(in crate::families) mod vertex_refs;
use vertex_refs::{B5VertexRef, B5Vertices};

use controls::{B5EdgeTerminalControl, B5FramingControl, B5VertexIncidenceControl};

use super::vecmath::{add, components, coordinates, cross, scale};
use crate::analytic::{periodic_angular_range_is_valid, sphere_angular_ranges_are_valid};
use crate::checked::ExactUnitVector3;
use crate::families::chamfer::{ChamferParameters, ChamferResultKind};
use crate::layout::{
    b5_arc_profile, b5_cone_payload, b5_cylinder_payload, b5_line_profile,
    b5_loop_numeric_terminal, b5_plane_payload, b5_revolution_carrier_tail, b5_sphere_payload,
    b5_torus_payload,
};
use crate::wire;
use crate::wire::bytes::{f64_le, f64_point, read_f64_array};

const EPS_B5_GRAPH_GEOMETRY: f64 = 1.0e-9;
const EPS_B5_GRAPH_DEGENERATE: f64 = 1.0e-10;
const EPS_B5_GRAPH_EXACT_GEOMETRY: f64 = 1.0e-12;

/// Maximum frame-index, record-materialization, census, and graph-selection
/// operations admitted for one free-form object population. The allowance
/// covers one indexed-frame pass, topology materialization, dependency
/// closure, and one bounded graph-resolution pass.
pub(in crate::families) const MAX_OBJECT_STREAM_SELECTION_WORK: usize = 2_000_000;

/// Resolved `b5 03` object-stream topology graph: faces, loops, pcurves, and
/// surfaces bound through the in-stream `object_id` map ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)),
/// together with the `05 08 01` vertex points used to bind edge endpoints.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B5Graph {
    /// `true` when every serialized face and loop node belongs to the resolved
    /// reference-closed graph; `false` when the graph is its maximal closed
    /// subset.
    pub(in crate::families) complete: bool,
    /// `b5 03 5f` face nodes, in stream declaration order (equal to STEP
    /// `ADVANCED_FACE` order, [spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
    pub(in crate::families) faces: Vec<B5Face>,
    /// Structurally complete `b5 03 5f` records, keyed by object id.
    pub(in crate::families) face_records: BTreeMap<u32, B5FaceRecord>,
    /// `b5 03 62` loop nodes, keyed by `object_id`.
    pub(in crate::families) loops: BTreeMap<u32, B5Loop>,
    /// `b5 03 21` pcurve nodes, keyed by `object_id`.
    pub(in crate::families) pcurves: BTreeMap<u32, B5Pcurve>,
    /// Structurally bounded pcurve records whose parameter-space geometry is
    /// not yet assigned, keyed by `object_id`.
    pub(in crate::families) opaque_pcurves: BTreeMap<u32, B5OpaquePcurve>,
    /// Pcurve occurrence ids whose support is bound by a loop and both native
    /// edge-endpoint incidence records, but which have no standalone geometry
    /// record.
    pub(in crate::families) implicit_pcurves: BTreeMap<u32, u32>,
    /// `b5 03 27/28/2d` analytic surface nodes and `a8 03 34` NURBS
    /// surfaces, keyed by `object_id`.
    pub(in crate::families) surfaces: BTreeMap<u32, B5Surface>,
    /// Resolved class-`2e`/`38` surface alias targets, keyed by alias identity.
    pub(in crate::families) surface_aliases: BTreeMap<u32, u32>,
    /// `b5 03 30` offset constructions, keyed by their result surface id.
    pub(in crate::families) offset_surfaces: BTreeMap<u32, B5OffsetSurface>,
    /// `b5 03 2c` extrusion constructions, keyed by their result surface id.
    pub(in crate::families) extrusion_surfaces: BTreeMap<u32, B5ExtrusionSurface>,
    /// `b5 03 37/3b` support-bound constructions, keyed by result surface id.
    pub(in crate::families) supported_surfaces: BTreeMap<u32, B5SupportedSurface>,
    /// Native class-`06` curve-parameter incidences, keyed by object id.
    pub(in crate::families) parameter_incidences: BTreeMap<u32, B5ParameterIncidence>,
    /// Native class-`5e` physical-edge records, keyed by object id.
    pub(in crate::families) edges: BTreeMap<u32, B5Edge>,
    /// Native class-`5d` vertex-to-incidence links, keyed by object id.
    pub(in crate::families) vertex_incidence_links: BTreeMap<u32, B5VertexIncidenceLink>,
    /// Vertex tables with bounds-checked edge bindings.
    pub(in crate::families) vertices: B5Vertices,
    /// Ordered class-`06` start/end parameter-incidence references from each
    /// native class-`5e` edge.
    pub(in crate::families) edge_parameter_incidences: BTreeMap<u32, [u32; 2]>,
    /// Maximum incident endpoint residual for each logical vertex, keyed by
    /// the combined vertex index used by `edge_vertices`.
    pub(in crate::families) vertex_tolerances: BTreeMap<usize, PositiveReal>,
    /// `b5 03 0e`/`0f` line and arc profile curves, keyed by `object_id`;
    /// referenced by `B5Surface::Revolution::profile_curve`.
    pub(in crate::families) profiles: BTreeMap<u32, B5Profile>,
}

/// One native `5d` logical vertex: its object id and resolved world-frame
/// coordinate.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(in crate::families) struct B5LogicalVertex {
    /// Native `5d` object id.
    pub(in crate::families) object_id: u32,
    /// World-frame coordinate resolved from native incidence.
    pub(in crate::families) point: FinitePoint3,
}

impl B5Graph {
    /// Follow surface aliases to their canonical terminal identity.
    #[must_use]
    pub(super) fn canonical_surface_id(&self, object_id: u32) -> Option<u32> {
        canonical_surface_id(&self.surface_aliases, object_id)
    }

    /// Return native edge identities proven to belong to the closed B-rep.
    ///
    /// A structurally parseable class-`5e` allocation is a physical edge only
    /// when a resolved face loop references it.  An incomplete graph cannot
    /// prove that the retained loop set is exhaustive, so callers must use
    /// their unresolved-association fallback in that case.
    pub(in crate::families) fn referenced_edge_vertex_references(
        &self,
    ) -> Option<BTreeMap<u32, [u32; 2]>> {
        if !self.complete {
            return None;
        }
        let mut referenced = BTreeMap::new();
        for loop_ in self.loops.values() {
            for member in &loop_.members {
                if let Some(edge) = self.edges.get(&member.edge) {
                    referenced.insert(member.edge, edge.vertices);
                }
            }
        }
        Some(referenced)
    }
}

/// Return the ordered start/end stations for one edge's occurrence of a
/// pcurve when both native endpoint incidences name that pcurve consistently.
pub(super) fn edge_pcurve_parameters(
    graph: &B5Graph,
    edge: u32,
    pcurve: u32,
) -> Option<[FiniteReal; 2]> {
    edge_pcurve_parameter_values(
        &graph.edge_parameter_incidences,
        &graph.parameter_incidences,
        edge,
        pcurve,
    )
}

fn edge_pcurve_parameter_values(
    edge_parameter_incidences: &BTreeMap<u32, [u32; 2]>,
    parameter_incidences: &BTreeMap<u32, B5ParameterIncidence>,
    edge: u32,
    pcurve: u32,
) -> Option<[FiniteReal; 2]> {
    let incidences = edge_parameter_incidences.get(&edge)?;
    let endpoints = incidences.map(|incidence_id| {
        let incidence = parameter_incidences.get(&incidence_id)?;
        let mut parameters = incidence
            .lanes
            .iter()
            .filter_map(|lane| (lane.curve == pcurve).then_some((lane.parameter, lane.control)));
        let parameter = parameters.next()?;
        parameters
            .all(|other| other == parameter)
            .then_some(parameter.0)
    });
    Some([endpoints[0]?, endpoints[1]?])
}

/// Follow one surface identity through a direct alias map.
pub(in crate::families) fn canonical_surface_id(
    aliases: &BTreeMap<u32, u32>,
    mut object_id: u32,
) -> Option<u32> {
    for _ in 0..=aliases.len() {
        match aliases.get(&object_id) {
            Some(&target) => object_id = target,
            None => return Some(object_id),
        }
    }
    None
}

/// A profile curve swept by a `b5 03 2d` surface of revolution.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) enum B5Profile {
    /// `b5 03 0e`: a line through `point` along `direction`.
    Line {
        /// A point on the line.
        point: FinitePoint3,
        /// Unit direction of the line.
        direction: ExactUnitVector3,
        /// Complete native line parameter interval.
        parameter_range: IncreasingParameterInterval,
    },
    /// `b5 03 0f`: an arc with a positive radius.
    Arc {
        /// Arc center.
        center: FinitePoint3,
        /// Unit vector from `center` toward the zero-angle point.
        direction_x: ExactUnitVector3,
        /// Unit vector orthogonal to `direction_x` completing the arc
        /// plane's basis.
        direction_y: ExactUnitVector3,
        /// Positive arc radius.
        radius: PositiveLength,
        /// Complete native arc-length parameter interval.
        parameter_range: IncreasingParameterInterval,
    },
}

impl B5Profile {
    pub(super) fn parameter_range(&self) -> IncreasingParameterInterval {
        match self {
            Self::Line {
                parameter_range, ..
            }
            | Self::Arc {
                parameter_range, ..
            } => *parameter_range,
        }
    }
}

/// A resolved `b5 03` surface node ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) enum B5Surface {
    /// A NURBS surface whose parameter lattice is decoded but whose pole
    /// representation remains opaque.
    UnresolvedNurbs {
        /// Decoded degree, knot, multiplicity, and pole-cardinality fields.
        header: crate::families::a5a8::records::A8SurfaceHeader,
        /// Exact source payload, including the opaque pole representation.
        payload: Vec<u8>,
    },
    /// An identity-bearing surface record whose carrier geometry remains opaque.
    Unknown {
        /// Source record family.
        family: u8,
        /// Source surface class.
        class: u8,
        /// Exact source payload.
        payload: Vec<u8>,
    },
    /// `b5 03 27`: a plane spanned by `origin`, the stored first in-plane
    /// direction and `direction_v`.
    Plane {
        /// A point on the plane.
        origin: FinitePoint3,
        /// The unit normal `direction_u × direction_v`, normalized by its
        /// largest component, and the stored first in-plane unit direction
        /// `direction_u`.
        frame: OrthonormalFrame3,
        /// Second in-plane unit direction.
        direction_v: ExactUnitVector3,
        /// Active native U interval.
        u_range: IncreasingParameterInterval,
        /// Active native V interval.
        v_range: IncreasingParameterInterval,
    },
    /// `b5 03 28`: a cylinder with a positive radius.
    Cylinder {
        /// A point on the cylinder axis.
        origin: FinitePoint3,
        /// The unit cylinder axis `stored_u × stored_v`, normalized by its
        /// largest component, and the stored unit direction `stored_u`, the
        /// zero-angle ray.
        frame: OrthonormalFrame3,
        /// Positive cylinder radius.
        radius: PositiveLength,
        /// Active native circumferential interval.
        u_range: IncreasingParameterInterval,
        /// Active native axial interval.
        v_range: IncreasingParameterInterval,
        /// Divisor mapping native U to azimuth.
        angular_scale: FiniteReal,
        /// Origin of the full-turn native U chart.
        chart_origin: FiniteReal,
    },
    /// `b5 03 29`: a circular cone in its native arc-length/slant chart.
    Cone {
        /// Axis origin of the reference-radius cross section.
        origin: FinitePoint3,
        /// The stored cone-axis unit direction and the stored first transverse
        /// unit direction, the zero-angle ray.
        frame: OrthonormalFrame3,
        /// The stored second transverse unit direction.
        direction_y: UnitVector3,
        /// Generator angle from the radial plane, strictly between zero and a quarter
        /// turn.
        radial_angle: PositiveAngle,
        /// Reference radius of the conical surface, independent of the active chart ranges.
        reference_radius: FiniteReal,
        /// Active azimuth interval.
        angular_range: IncreasingParameterInterval,
        /// Native slant-coordinate range.
        slant_range: IncreasingParameterInterval,
        /// Subtract this value from native V to obtain local generator length.
        slant_shift: FiniteReal,
        /// Positive divisor mapping native U to azimuth.
        angular_scale: PositiveReal,
        /// Full-turn azimuth chart domain.
        angular_domain: IncreasingParameterInterval,
        /// Neutral carrier: its origin is the axis point at the slant-interval
        /// start and its radius is the cross-section radius there. Absent
        /// when the origin or radius cannot be admitted.
        surface: Option<ConeSurface>,
    },
    /// `b5 03 2a`: a sphere with a radius-scaled right-handed frame.
    Sphere {
        /// Sphere center.
        center: FinitePoint3,
        /// The polar-axis unit direction and the zero-azimuth unit direction.
        frame: OrthonormalFrame3,
        /// Quarter-turn azimuth unit direction.
        direction_y: UnitVector3,
        /// Positive sphere radius.
        radius: PositiveLength,
        /// Active azimuth interval, in radians.
        azimuth_range: IncreasingParameterInterval,
        /// Active latitude interval, in radians.
        latitude_range: IncreasingParameterInterval,
        /// Positive radius of the enclosing support-bound construction.
        construction_radius: PositiveLength,
        /// Origin of the native periodic V coordinate, in length units.
        chart_origin: FiniteReal,
    },
    /// `b5 03 2b`: a torus in its two arc-length angular coordinates.
    Torus {
        /// Torus center.
        center: FinitePoint3,
        /// The torus axis and the zero-major-angle direction.
        frame: OrthonormalFrame3,
        /// Quarter-turn major-angle direction.
        direction_y: ExactUnitVector3,
        /// Positive major radius.
        major_radius: PositiveLength,
        /// Positive minor radius.
        minor_radius: PositiveLength,
        /// Active major-angle interval.
        major_angular_range: IncreasingParameterInterval,
        /// Full-turn major-angle chart domain.
        major_angular_domain: IncreasingParameterInterval,
        /// Active minor-angle interval.
        minor_angular_range: IncreasingParameterInterval,
        /// Full-turn minor-angle chart domain.
        minor_angular_domain: IncreasingParameterInterval,
        /// Positive divisor mapping native U to the major angle.
        major_scale: PositiveReal,
        /// Positive divisor mapping native V to the minor angle.
        minor_scale: PositiveReal,
    },
    /// `b5 03 2d`: a surface of revolution sweeping `profile_curve` about
    /// `axis_origin`/`axis_direction`.
    Revolution {
        /// `object_id` of the swept [`B5Profile`].
        profile_curve: u32,
        /// A point on the revolution axis.
        axis_origin: FinitePoint3,
        /// Unit revolution axis of the stored right-handed frame.
        axis_direction: UnitVector3,
        /// Active parameter interval of the swept profile.
        profile_range: IncreasingParameterInterval,
        /// Active native arc-length interval of the revolution.
        angular_range: IncreasingParameterInterval,
        /// Positive divisor mapping native V to a revolution angle.
        angular_scale: PositiveReal,
    },
    /// An `a8 03 34` inline-pole B-spline surface, resolved through
    /// [`crate::families::a5a8::records::a8_surfaces`] and merged into the same
    /// `object_id` namespace.
    Nurbs(NurbsSurface),
    /// An `a8 03 32` rolling-ball result carrier, resolved through its exact
    /// stored value and derivative jet.
    RollingBall {
        /// Persistent object id of the `a8 03 32` result carrier.
        carrier_object_id: u32,
        /// Exact procedural definition decoded from the stored jet.
        definition: Box<ProceduralSurfaceDefinition>,
    },
}

/// An offset result carrier kind.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum B5OffsetCarrierKind {
    /// The cache carrier form.
    Cache,
    /// The cylinder carrier form.
    Cylinder,
    /// The sphere carrier form.
    Sphere,
    /// The torus carrier form.
    Torus,
    /// The canonical cone carrier form.
    Cone,
    /// The plane carrier form.
    Plane,
    /// The rollingball carrier form.
    RollingBall,
    /// The extrusion carrier form.
    Extrusion,
}

impl B5OffsetCarrierKind {
    fn from_byte(byte: u8) -> Option<Self> {
        match byte {
            0x01 => Some(Self::Cache),
            0x05 => Some(Self::Cylinder),
            0x09 => Some(Self::Sphere),
            0x0d => Some(Self::Torus),
            0x11 => Some(Self::Cone),
            0x15 => Some(Self::Plane),
            0x19 => Some(Self::RollingBall),
            0x21 => Some(Self::Extrusion),
            _ => None,
        }
    }
}

/// A `b5 03 30` offset construction with an explicit result carrier.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5OffsetSurface {
    /// This construction's result surface id.
    pub(super) object_id: u32,
    /// Explicit analytic carrier for the offset result.
    pub(super) carrier_surface: u32,
    /// Surface from which the result is offset.
    pub(super) source_surface: u32,
    /// Signed offset distance in millimetres.
    pub(super) distance: FiniteReal,
    /// Native carrier-kind discriminator.
    pub(super) carrier_kind: B5OffsetCarrierKind,
    /// Increasing native U and V bounds.
    pub(super) parameter_bounds: [IncreasingParameterInterval; 2],
}

/// A `b5 03 2c` extrusion construction with an exact directrix.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5ExtrusionSurface {
    /// This construction's result surface id.
    pub(super) object_id: u32,
    /// Unit world-space extrusion direction.
    pub(super) direction: UnitVector3,
    /// Increasing native U and V intervals.
    pub(super) parameter_bounds: [IncreasingParameterInterval; 2],
    /// Exact directrix construction.
    pub(super) directrix: B5ExtrusionDirectrix,
}

/// Exact directrix construction selected by a `b5 03 2c` extrusion.
#[derive(Debug, Clone, PartialEq)]
pub(super) enum B5ExtrusionDirectrix {
    /// One-support lift selected by a surface-curve wrapper or sampled map.
    SurfaceCurve {
        /// Persistent directrix object id.
        object_id: u32,
        /// `(surface, pcurve, pcurve range)` support side.
        support: (u32, u32, [FiniteReal; 2]),
        /// Increasing curve parameter range.
        parameter_range: IncreasingParameterInterval,
    },
    /// Fixed-direction offset carried by a `b5 03 14` record.
    Offset {
        /// Persistent offset-curve object id.
        object_id: u32,
        /// Complete source curve construction.
        source: Box<B5ExtrusionDirectrix>,
        /// Increasing interval on the source curve.
        source_parameter_range: IncreasingParameterInterval,
        /// Signed nonzero offset distance.
        distance: FiniteReal,
        /// Unit direction defining the positive offset side.
        direction: UnitVector3,
        /// Increasing result-curve parameter range.
        parameter_range: IncreasingParameterInterval,
    },
}

impl B5ExtrusionDirectrix {
    pub(super) fn object_id(&self) -> u32 {
        match self {
            Self::SurfaceCurve { object_id, .. } | Self::Offset { object_id, .. } => *object_id,
        }
    }

    fn parameter_range(&self) -> IncreasingParameterInterval {
        match self {
            Self::SurfaceCurve {
                parameter_range, ..
            }
            | Self::Offset {
                parameter_range, ..
            } => *parameter_range,
        }
    }

    fn reorigin_parameter_range(&mut self, range: IncreasingParameterInterval) {
        match self {
            Self::SurfaceCurve {
                parameter_range, ..
            }
            | Self::Offset {
                parameter_range, ..
            } => {
                *parameter_range = range;
            }
        }
    }

    pub(super) fn support(&self) -> &(u32, u32, [FiniteReal; 2]) {
        match self {
            Self::SurfaceCurve { support, .. } => support,
            Self::Offset { source, .. } => source.support(),
        }
    }
}

/// A two-support fillet or chamfer construction with an explicit result carrier.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5SupportedSurface {
    /// This construction's result surface id.
    pub(super) object_id: u32,
    /// Explicit carrier for the result geometry and chart.
    pub(super) carrier_surface: u32,
    /// Ordered construction support surfaces.
    pub(super) support_surfaces: [u32; 2],
    /// Ordered pcurves, one bound to each support surface.
    pub(super) support_pcurves: [u32; 2],
    /// Class-specific native controls and scalar parameters.
    pub(super) parameters: B5SupportedSurfaceParameters,
}

/// Native parameter layouts of a support-bound surface construction.
#[derive(Debug, Clone, PartialEq)]
pub(super) enum B5SupportedSurfaceParameters {
    /// Class `37`: constant-radius fillet controls and construction radius.
    Radius {
        /// Result selector, sentinel, two support sides, bound order, and closure.
        controls: [u8; 6],
        /// Positive radius of the support-bound construction.
        construction_radius: PositiveLength,
    },
    /// Class `3b`: two-support chamfer controls and definition.
    Chamfer(ChamferParameters),
}

/// One class-`06` incidence lane connecting curves to parameters at a vertex.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5ParameterIncidence {
    /// This record's stream object id.
    pub(super) object_id: u32,
    /// Curve, local parameter, and arc number in serialized order.
    pub(in crate::families) lanes: Vec<B5IncidenceLane>,
}

/// One curve station of a class-`06` incidence record.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(in crate::families) struct B5IncidenceLane {
    /// Referenced curve or pcurve object id.
    pub(super) curve: u32,
    /// Finite native parameter on that curve.
    pub(super) parameter: FiniteReal,
    /// Compact arc number; together with the local parameter, a `CATCrvParam`.
    pub(super) control: u32,
}

/// One complete class-`5e` physical-edge reference production.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(in crate::families) struct B5Edge {
    /// This record's stream object id.
    object_id: u32,
    /// Referenced curve-support wrapper.
    support: u32,
    /// Ordered start/end class-`5d` vertex identities.
    vertices: [u32; 2],
    /// Ordered start/end class-`06` parameter-incidence identities.
    parameter_incidences: [u32; 2],
    /// Exact admitted terminal control.
    pub(in crate::families) terminal_control: B5EdgeTerminalControl,
}

/// One complete class-`5d` vertex-to-incidence reference production.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(in crate::families) struct B5VertexIncidenceLink {
    /// This record's stream object id.
    object_id: u32,
    /// Referenced counted class-`05` incidence roster.
    incidence: u32,
    /// Exact admitted terminal control.
    pub(in crate::families) terminal_control: B5VertexIncidenceControl,
}

/// A resolved `b5 03 18`, `b5 03 19`, or `b5 03 21` pcurve node, represented as a 2D
/// B-spline curve in a surface's
/// parameter space ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5Pcurve {
    /// This record's stream `object_id`.
    pub(super) object_id: u32,
    /// `object_id` of the owning surface, taken directly from the pcurve's
    /// `catia_support_ref` ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
    pub(super) surface: u32,
    /// B-spline degree.
    pub(super) degree: u32,
    /// Distinct knot values, strictly increasing.
    pub(super) distinct_knots: Vec<FiniteReal>,
    /// Per-knot multiplicities, index-aligned with `distinct_knots`.
    pub(super) multiplicities: Vec<u32>,
    /// `(u, v)` control points in the surface's parameter space.
    pub(super) control_points: Vec<FiniteVector<2>>,
    /// Positive per-pole rational weights. `None` denotes a polynomial
    /// pcurve.
    pub(super) weights: Option<Vec<PositiveReal>>,
    /// Explicit occurrence parameter interval when the pcurve record stores one.
    pub(super) parameter_range: Option<[FiniteReal; 2]>,
    /// Coordinate convention for evaluating the stored knot vector.
    pub(super) parameterization: B5PcurveParameterization,
    /// Positive scalar stored in the exact class-`21` suffix. When a class-`21`
    /// pcurve is present, it is the length of the zero-based occurrence interval.
    pub(in crate::families) class_21_suffix_scalar: Option<PositiveReal>,
    /// The curve's two clamped-end poles lifted through `surface` into
    /// world-frame 3D points, or `None` before [`parse`] resolves them or
    /// when the lift fails (unresolved surface, degenerate revolution
    /// scale, or NURBS evaluation failure).
    pub(super) lifted_endpoints: Option<[FinitePoint3; 2]>,
}

/// Parameter coordinates used by one B5 pcurve record.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(super) enum B5PcurveParameterization {
    /// The pcurve's occurrence coordinate is its serialized knot coordinate.
    Native,
    /// The occurrence coordinate starts at zero while the serialized knot
    /// vector starts at `native_origin`.
    Translated {
        /// Native knot coordinate corresponding to occurrence station zero.
        native_origin: FiniteReal,
    },
}

/// Exact great-circle fields carried by a class-`1d` sphere pcurve.
#[derive(Debug, Clone, PartialEq)]
pub(super) struct B5SphereGreatCirclePcurve {
    /// Increasing length-valued U bounds of the curve in the sphere chart.
    pub(super) u_bounds: IncreasingParameterInterval,
    /// Length-valued V bounds of the curve in the sphere chart.
    pub(super) v_bounds: [FiniteReal; 2],
    /// Length-valued shift contributing to the great-circle plane phase.
    pub(super) chart_shift: FiniteReal,
    /// Positive length scale converting the sphere chart's angular
    /// coordinates.
    pub(super) chart_scale: PositiveReal,
    /// Signed slope in `tan(latitude) = slope * cos(azimuth - phase)`.
    pub(super) slope: FiniteReal,
    /// Stored phase term. The geometric phase is `chart_shift / chart_scale + phase`.
    pub(super) phase: FiniteReal,
}

/// An identity- and support-resolved pcurve whose native chart equation is
/// opaque or only partly assigned.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5OpaquePcurve {
    /// This record's stream `object_id`.
    pub(super) object_id: u32,
    /// Owning surface object id.
    pub(super) surface: u32,
    /// Native pcurve class.
    pub(super) class: u8,
    /// Exact source payload.
    pub(super) payload: Vec<u8>,
    /// Exact great-circle carrier fields when this is a validated class-`1d`
    /// sphere pcurve.
    pub(super) sphere_great_circle: Option<B5SphereGreatCirclePcurve>,
}

/// One length-framed `b5 03` record as found by the stream walk ([spec §6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#6-object-stream-record-framing-a5-03-a8-03-b5-03)).
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::families) struct B5Record {
    /// Byte offset of the `b5 03` marker in the source stream.
    pub(in crate::families) offset: usize,
    /// Record family byte (`0xb5` or `0xa8`).
    pub(in crate::families) family: u8,
    /// Third header byte: the record's type/class code (`0x5f` face,
    /// `0x62` loop, `0x21` pcurve, `0x27`/`0x28`/`0x2d` surface, `0x5e`
    /// edge, `0x18` line pcurve, `0x0e`/`0x0f` profile, ...).
    pub(in crate::families) class: u8,
    /// Dense creation-order `object_id` stored inline at `+4` ([spec §6.5](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#65-a8-03-common-object-stream-freeform-class)).
    pub(in crate::families) object_id: u32,
    /// Raw record payload after the 8-byte header.
    pub(in crate::families) payload: Vec<u8>,
}

#[derive(Clone, Copy)]
pub(in crate::families) struct ObjectFrame {
    pub(in crate::families) start: usize,
    pub(in crate::families) end: usize,
    family: u8,
    pub(in crate::families) class: u8,
    pub(in crate::families) object_id: u32,
}

type DependencyCandidates = HashMap<u32, Option<ObjectFrame>>;

/// A resolved `b5 03 5f` face node ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::families) struct B5Face {
    /// This record's stream `object_id`.
    pub(in crate::families) object_id: u32,
    /// `object_id` of the face's surface, taken from the first reference
    /// token.
    pub(super) surface: u32,
    /// `object_id`s of the face's `b5 03 62` loop nodes, in reference
    /// order.
    pub(super) loops: Vec<u32>,
    /// Exact terminal control of the counted face production. Uncounted face
    /// framing has no terminal control.
    pub(in crate::families) terminal_control: Option<B5FramingControl>,
}

/// Count the face incidences for each object-stream loop.
pub(super) fn face_loop_owner_counts(faces: &[B5Face]) -> HashMap<u32, usize> {
    let mut owners = HashMap::new();
    for face in faces {
        for &loop_id in &face.loops {
            if let Some(count) = owners.get_mut(&loop_id) {
                *count += 1;
            } else {
                owners.insert(loop_id, 1);
            }
        }
    }
    owners
}

/// One structurally complete class-`5f` face reference production.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::families) struct B5FaceRecord {
    /// This record's stream object id.
    pub(in crate::families) object_id: u32,
    /// Ordered native references.
    pub(in crate::families) references: Vec<u32>,
    /// Exact counted-production terminal control. Uncounted framing has no
    /// terminal control.
    pub(in crate::families) terminal_control: Option<B5FramingControl>,
}

/// A resolved `b5 03 62` loop node: payload `<0x80 + n_refs>
/// (pcurve_ref edge_ref)* surface_ref` ([spec §6.6](https://github.com/cadmpeg/cadmpeg/blob/main/docs/formats/catia.md#66-object-stream-topology-b5-03)).
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5Loop {
    /// This record's stream `object_id`.
    pub(super) object_id: u32,
    /// Pcurve/edge occurrences in serialized order, each with its native
    /// control triple.
    pub(super) members: Vec<B5LoopMember>,
    /// Source-native framing and optional numeric extension.
    pub(in crate::families) metadata: B5LoopMetadata,
    /// `object_id` of the loop's surface (the trailing reference token).
    pub(super) surface: u32,
}

/// One pcurve/edge occurrence of a class-`62` loop.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct B5LoopMember {
    /// `object_id` of the member pcurve (or `0x18` line).
    pub(super) pcurve: u32,
    /// `object_id` of the member `b5 03 5e` edge.
    pub(super) edge: u32,
    /// Edge occurrence, pcurve-to-edge parameter orientation, and pcurve
    /// occurrence signs, in source order. The middle sign compares composite
    /// stations by arc first, then local parameter within the same arc.
    pub(super) controls: [i16; 3],
}

/// Complete metadata following a class-`62` loop's reference lanes.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5LoopMetadata {
    /// Primary and secondary loop framing controls.
    pub(in crate::families) framing_controls: [B5FramingControl; 2],
    /// Optional fixed-width numeric extension.
    pub(in crate::families) extension: Option<B5LoopMetadataExtension>,
}

/// Optional fixed-width numeric extension of a class-`62` loop.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B5LoopMetadataExtension {
    /// Local rectangle coordinates U0, V0, U1, V1. The paired patch IDs
    /// occupy controls 1 through 4; coordinates order within each patch.
    scalars: [FiniteReal; 4],
    /// Canonical compact lead, U0/V0/U1/V1 patch IDs, and compact zero.
    controls: [u8; 6],
    /// Conservative Cartesian rectangle-image box, as X/Y/Z low/high pairs.
    floats: [f32; 6],
}

impl B5Loop {
    pub(super) fn edge_senses(&self) -> Vec<bool> {
        self.members
            .iter()
            .map(|member| member.controls[0] == -1)
            .collect::<Vec<_>>()
    }

    pub(super) fn pcurve_senses(&self) -> Vec<bool> {
        self.members
            .iter()
            .map(|member| member.controls[2] == -1)
            .collect::<Vec<_>>()
    }
}

/// Resolve the dominant object-stream topology graph through inline object ids.
pub(crate) fn parse(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<B5Graph>, CodecError> {
    let mut graphs = topology_runs(ctx, bytes, refusal)?
        .into_iter()
        .map(|(_, graph)| graph);
    let Some(graph) = graphs.next() else {
        return Ok(None);
    };
    Ok(graphs.next().is_none().then_some(graph))
}

/// Resolve each contiguous object-stream run independently.
fn topology_runs(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<(Range<usize>, B5Graph)>, CodecError> {
    let mut populations = StreamPopulations::new(bytes);
    let root_runs = topology_root_run_ranges_from_runs(bytes, &populations.runs);
    let candidates = if root_runs.is_empty() {
        populations.runs.clone()
    } else {
        root_runs
    };
    let mut graphs = Vec::new();
    for range in candidates {
        let population = populations.population(range.clone());
        if let Some(graph) = parse_flat(ctx, &population, refusal)? {
            graphs.push((range, graph));
        }
    }
    refusal.push_b5_population_bounded(populations.bounded_runs);
    Ok(graphs)
}

fn parse_flat(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<B5Graph>, CodecError> {
    let frames = collect_object_stream_frames(bytes);
    let records = records_from_frames(bytes, &frames, None);
    parse_from_records(ctx, bytes, &records, &frames, true, None, refusal)
}

pub(in crate::families) fn parse_from_frames(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    frames: &[ObjectFrame],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<B5Graph>, CodecError> {
    let records = records_from_frames(bytes, frames, None);
    parse_from_records(ctx, bytes, &records, frames, true, None, refusal)
}

pub(in crate::families) fn parse_from_records(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    records: &[B5Record],
    frames: &[ObjectFrame],
    require_topology: bool,
    budget: Option<&WorkBudget>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<B5Graph>, CodecError> {
    let mut by_id = HashMap::new();

    for record in records {
        by_id.insert(record.object_id, record);
    }
    if records.is_empty() || by_id.len() != records.len() {
        return Ok(None);
    }
    let class21_candidates = a8_class21_pcurves_from_frames(ctx, bytes, frames)?;
    let object_stream_pcurve_jets = crate::families::a5a8::records::object_stream_pcurves(bytes);
    let mut object_stream_pcurve_candidates = Vec::new();
    for jet in &object_stream_pcurve_jets {
        if let Some(candidate) = object_stream_pcurve_candidate(ctx, jet)? {
            object_stream_pcurve_candidates.push(candidate);
        }
    }
    parse_from_records_with_class21(
        ctx,
        bytes,
        (records, frames),
        require_topology,
        budget,
        refusal,
        PreparedB5Graph {
            class21_candidates,
            object_stream_pcurve_candidates,
            by_id: &by_id,
        },
    )
}

struct PreparedB5Graph<'a, 'b> {
    class21_candidates: Vec<B5Pcurve>,
    object_stream_pcurve_candidates: Vec<B5Pcurve>,
    by_id: &'a HashMap<u32, &'b B5Record>,
}

fn parse_from_records_with_class21(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    (records, frames): (&[B5Record], &[ObjectFrame]),
    require_topology: bool,
    budget: Option<&WorkBudget>,
    refusal: &mut crate::nurbs::LaneRefusals,
    prepared: PreparedB5Graph<'_, '_>,
) -> Result<Option<B5Graph>, CodecError> {
    let PreparedB5Graph {
        class21_candidates,
        object_stream_pcurve_candidates: object_stream_candidates,
        by_id,
    } = prepared;
    let mut object_stream_pcurve_candidates = BTreeMap::new();
    let mut conflicting_object_stream_pcurves = HashSet::new();
    let mut object_stream_pcurve_classes = HashMap::<u32, Option<u8>>::new();
    for candidate in object_stream_candidates {
        object_stream_pcurve_classes
            .entry(candidate.object_id)
            .and_modify(|class| {
                if *class != Some(0x20) {
                    *class = None;
                }
            })
            .or_insert(Some(0x20));
        merge_pcurve_candidate(
            &mut object_stream_pcurve_candidates,
            &mut conflicting_object_stream_pcurves,
            candidate,
        );
    }
    for candidate in class21_candidates {
        object_stream_pcurve_classes
            .entry(candidate.object_id)
            .and_modify(|class| {
                if *class != Some(0x21) {
                    *class = None;
                }
            })
            .or_insert(Some(0x21));
        merge_pcurve_candidate(
            &mut object_stream_pcurve_candidates,
            &mut conflicting_object_stream_pcurves,
            candidate,
        );
    }
    let mut a8_pcurve_supports = HashMap::new();
    for (&object_id, pcurve) in &object_stream_pcurve_candidates {
        a8_pcurve_supports.insert(object_id, pcurve.surface);
    }
    let mut a8_headers = BTreeMap::new();
    for frame in frames {
        if let Some(header) = crate::families::a5a8::records::a8_surface_header_from_object_frame(
            bytes,
            frame.start,
            frame.end,
            frame.object_id,
        ) {
            a8_headers.insert(header.object_id, header);
        }
    }
    let mut surfaces = BTreeMap::new();
    for record in records {
        if let Some(surface) = surface_node(record, a8_headers.get(&record.object_id)) {
            surfaces.insert(record.object_id, surface);
        }
    }
    let mut conflicting_surfaces = HashSet::new();
    for surface_id in topology_surface_references(records) {
        if surfaces.contains_key(&surface_id) {
            continue;
        }
        let Some(record) = by_id
            .get(&surface_id)
            .filter(|record| record.family == 0xb5 && is_opaque_surface_class(record.class))
        else {
            continue;
        };
        let payload = record.payload.clone();
        surfaces.insert(
            surface_id,
            B5Surface::Unknown {
                family: record.family,
                class: record.class,
                payload,
            },
        );
    }

    for frame in frames {
        let Some(surface) = crate::families::a5a8::records::a8_surface_from_object_frame(
            bytes,
            frame.start,
            frame.end,
            frame.object_id,
            refusal,
        )?
        else {
            continue;
        };
        if let Some(object_id) = surface.object_id() {
            merge_surface_candidate(
                &mut surfaces,
                &mut conflicting_surfaces,
                object_id,
                B5Surface::Nurbs(surface.geometry),
            );
        }
    }
    for jet in crate::families::a5a8::records::a8_freeform_curves(bytes) {
        if let Some(definition) = crate::families::a5a8::records::rolling_ball_jet_definition(&jet)
        {
            merge_surface_candidate(
                &mut surfaces,
                &mut conflicting_surfaces,
                jet.object_id,
                B5Surface::RollingBall {
                    carrier_object_id: jet.object_id,
                    definition: Box::new(definition),
                },
            );
        }
    }
    let mut object_stream_pcurves = BTreeMap::new();
    for (&object_id, pcurve) in &object_stream_pcurve_candidates {
        let Some((class, parameter_range)) = object_stream_pcurve_classes
            .get(&object_id)
            .copied()
            .flatten()
            .zip(pcurve.parameter_range)
        else {
            continue;
        };
        let distinct_knots = pcurve.distinct_knots.clone();
        object_stream_pcurves.insert(
            object_id,
            B5ObjectStreamPcurve {
                class,
                surface: pcurve.surface,
                parameter_range,
                class_21_suffix_scalar: pcurve.class_21_suffix_scalar,
                distinct_knots,
            },
        );
    }
    let offset_constructions = records
        .iter()
        .filter_map(parse_offset_surface_fields)
        .collect::<Vec<_>>();
    let mut extrusion_surfaces = BTreeMap::<u32, B5ExtrusionSurface>::new();
    let has_extrusion_candidates = records
        .iter()
        .any(|record| record.family == 0xb5 && record.class == 0x2c);
    if has_extrusion_candidates {
        loop {
            if budget.is_some_and(|budget| !budget.charge_by(records.len())) {
                return Ok(None);
            }
            let mut changed = false;
            for record in records {
                if extrusion_surfaces.contains_key(&record.object_id) {
                    continue;
                }
                let Some(extrusion) = parse_extrusion_surface_with_context(
                    ctx,
                    record,
                    by_id,
                    &object_stream_pcurves,
                    &offset_constructions,
                    &extrusion_surfaces,
                )?
                else {
                    continue;
                };
                extrusion_surfaces.insert(record.object_id, extrusion);
                changed = true;
            }
            if !changed {
                break;
            }
        }
    }
    let mut extrusion_pcurves = HashSet::new();
    for extrusion in extrusion_surfaces.values() {
        let (_, pcurve, _) = extrusion.directrix.support();
        extrusion_pcurves.insert(*pcurve);
    }
    let mut offset_surfaces = BTreeMap::new();
    let mut supported_surfaces = BTreeMap::new();
    let has_surface_fixpoint_candidates = !offset_constructions.is_empty()
        || records.iter().any(|record| {
            record.family == 0xb5 && matches!(record.class, 0x2e | 0x30 | 0x37 | 0x38 | 0x3b)
        });
    if has_surface_fixpoint_candidates {
        loop {
            if budget.is_some_and(|budget| !budget.charge_by(records.len())) {
                return Ok(None);
            }
            let mut changed =
                resolve_surface_aliases(records, by_id, &mut surfaces, &mut conflicting_surfaces)?;
            for record in records {
                let Some(offset) =
                    parse_offset_surface(record, &surfaces, &extrusion_surfaces, by_id)
                else {
                    continue;
                };
                let carrier = if let Some(carrier) = surfaces.get(&offset.carrier_surface) {
                    copy_surface(carrier)?
                } else {
                    let Some(record) = by_id.get(&offset.carrier_surface) else {
                        continue;
                    };
                    B5Surface::Unknown {
                        family: record.family,
                        class: record.class,
                        payload: record.payload.clone(),
                    }
                };
                let surface_changed = surfaces.get(&record.object_id) != Some(&carrier);
                if !merge_surface_candidate(
                    &mut surfaces,
                    &mut conflicting_surfaces,
                    offset.carrier_surface,
                    copy_surface(&carrier)?,
                ) || !merge_surface_candidate(
                    &mut surfaces,
                    &mut conflicting_surfaces,
                    record.object_id,
                    carrier,
                ) {
                    continue;
                }
                let metadata_changed = offset_surfaces.get(&record.object_id) != Some(&offset);
                offset_surfaces.insert(record.object_id, offset);
                changed |= surface_changed || metadata_changed;
            }
            for record in records {
                let Some(construction) = parse_supported_surface(record) else {
                    continue;
                };
                let Some(carrier) = surfaces.get(&construction.carrier_surface) else {
                    continue;
                };
                if !supported_surface_parameters_match_carrier(&construction.parameters, carrier) {
                    continue;
                }
                let carrier = copy_surface(carrier)?;
                let surface_changed = surfaces.get(&record.object_id) != Some(&carrier);
                if merge_surface_candidate(
                    &mut surfaces,
                    &mut conflicting_surfaces,
                    record.object_id,
                    carrier,
                ) && supported_surface_pcurves_match(&construction, by_id, &a8_pcurve_supports)
                    && construction
                        .support_surfaces
                        .iter()
                        .all(|surface| surfaces.contains_key(surface))
                {
                    let metadata_changed =
                        supported_surfaces.get(&record.object_id) != Some(&construction);
                    supported_surfaces.insert(record.object_id, construction);
                    changed |= surface_changed || metadata_changed;
                }
            }
            changed |=
                resolve_surface_aliases(records, by_id, &mut surfaces, &mut conflicting_surfaces)?;
            if !changed {
                break;
            }
        }
    }
    offset_surfaces.retain(|object_id, offset| {
        surfaces.get(object_id) == surfaces.get(&offset.carrier_surface)
    });
    supported_surfaces.retain(|object_id, construction| {
        surfaces.get(object_id) == surfaces.get(&construction.carrier_surface)
    });
    let mut profiles = BTreeMap::new();
    for record in records {
        if let Some(profile) = parse_profile(record) {
            profiles.insert(record.object_id, profile);
        }
    }
    let mut pcurves = BTreeMap::new();
    for record in records {
        let pcurve = match record.class {
            0x18 => parse_line_pcurve(record),
            0x19 => parse_circle_pcurve(record),
            0x1a => parse_class_1a_pcurve(record),
            0x21 => parse_pcurve(record),
            _ => None,
        };
        if let Some(pcurve) = pcurve {
            pcurves.insert(record.object_id, pcurve);
        }
    }
    let mut conflicting_pcurves = HashSet::new();
    let mut circle_candidates = BTreeMap::<u32, Vec<B5Pcurve>>::new();
    for pcurve in circle_pcurves_from_frames(bytes, frames) {
        if surfaces.contains_key(&pcurve.surface) {
            circle_candidates
                .entry(pcurve.object_id)
                .or_default()
                .push(pcurve);
        }
    }
    for (object_id, candidates) in circle_candidates {
        let mut distinct = candidates.into_iter();
        let Some(candidate) = distinct.next() else {
            continue;
        };
        if distinct.all(|other| other == candidate) {
            merge_pcurve_candidate(&mut pcurves, &mut conflicting_pcurves, candidate);
        } else {
            pcurves.remove(&object_id);
            conflicting_pcurves.insert(object_id);
        }
    }
    for candidate in object_stream_pcurve_candidates.into_values() {
        let directrix_reference = extrusion_pcurves.contains(&candidate.object_id);
        if !directrix_reference
            && by_id
                .get(&candidate.object_id)
                .is_none_or(|record| record.class != 0x20)
        {
            continue;
        }
        merge_pcurve_candidate(&mut pcurves, &mut conflicting_pcurves, candidate);
    }
    let mut opaque_pcurves = BTreeMap::new();
    for record in records {
        if let Some(pcurve) = parse_opaque_pcurve(record) {
            opaque_pcurves.insert(record.object_id, pcurve);
        }
    }
    for pcurve in opaque_pcurves.values_mut() {
        let Some(record) = by_id.get(&pcurve.object_id) else {
            continue;
        };
        pcurve.sphere_great_circle = surfaces
            .get(&pcurve.surface)
            .and_then(|surface| parse_sphere_great_circle_pcurve(record, surface));
    }
    let mut parameter_incidences = BTreeMap::new();
    for record in records {
        if let Some(incidence) = parameter_incidence(record) {
            parameter_incidences.insert(record.object_id, incidence);
        }
    }
    let mut edges = BTreeMap::new();
    for record in records.iter().filter(|record| record.class == 0x5e) {
        if let Some(edge) = parse_edge(record) {
            edges.insert(record.object_id, edge);
        }
    }
    let mut edge_parameter_incidences = BTreeMap::new();
    for (&object_id, edge) in &edges {
        if edge
            .parameter_incidences
            .iter()
            .all(|parameter| parameter_incidences.contains_key(parameter))
        {
            edge_parameter_incidences.insert(object_id, edge.parameter_incidences);
        }
    }
    let implicit_pcurves =
        implicit_pcurve_bindings(records, by_id, &pcurves, &opaque_pcurves, &surfaces);
    for pcurve in pcurves.values_mut() {
        pcurve.lifted_endpoints = if let (Some(surface), Some(first), Some(last)) = (
            surfaces.get(&pcurve.surface),
            pcurve.control_points.first(),
            pcurve.control_points.last(),
        ) {
            lift_pcurve_endpoints(ctx, surface, &profiles, [first.get(), last.get()])?
        } else {
            None
        };
    }
    let geometry = B5PcurveContext {
        pcurves: &pcurves,
        opaque_pcurves: &opaque_pcurves,
        surfaces: &surfaces,
        profiles: &profiles,
        edge_parameter_incidences: &edge_parameter_incidences,
        parameter_incidences: &parameter_incidences,
    };
    let source_face_count = records.iter().filter(|record| record.class == 0x5f).count();
    let mut loops = BTreeMap::new();
    for record in records.iter().filter(|record| record.class == 0x62) {
        let Some(parsed) = parse_loop_record(record) else {
            continue;
        };
        let Some(loop_) = parse_loop(
            &parsed,
            by_id,
            &pcurves,
            &opaque_pcurves,
            &implicit_pcurves,
            &surfaces,
        ) else {
            continue;
        };
        loops.insert(record.object_id, loop_);
    }
    let mut face_records = BTreeMap::new();
    for record in records.iter().filter(|record| record.class == 0x5f) {
        if let Some(face) = parse_face_record(record) {
            face_records.insert(record.object_id, face);
        }
    }
    let mut surface_aliases = BTreeMap::new();
    for record in records
        .iter()
        .filter(|record| surfaces.contains_key(&record.object_id))
    {
        if let Some(target) = surface_alias_target(record) {
            surface_aliases.insert(record.object_id, target);
        }
    }
    let mut faces = Vec::new();
    for record in records
        .iter()
        .filter_map(|record| face_records.get(&record.object_id))
    {
        if let Some(face) = parse_face(record, &loops, &surfaces, &surface_aliases) {
            faces.push(face);
        }
    }
    if require_topology && (faces.is_empty() || loops.is_empty()) {
        return Ok(None);
    }
    let vertex_points = crate::families::consolidated::records::object_stream_vertices(bytes)?;
    let geometric_edge_vertices = bind_edge_vertices(ctx, &loops, &geometry, &vertex_points)?;
    let mut vertex_incidence_links = BTreeMap::new();
    for record in records.iter().filter(|record| record.class == 0x5d) {
        if let Some(link) = parse_vertex_incidence_link(record) {
            vertex_incidence_links.insert(record.object_id, link);
        }
    }
    let mut native_edge_vertices = BTreeMap::new();
    for (&object_id, edge) in &edges {
        native_edge_vertices.insert(object_id, edge.vertices);
    }
    let native_vertex_coordinates = incidence_vertex_coordinates(
        ctx,
        &native_edge_vertices,
        &vertex_incidence_links,
        by_id,
        &geometry,
    )?;
    let bound_vertices = bind_native_vertices(
        ctx,
        &loops,
        &geometry,
        &native_edge_vertices,
        &geometric_edge_vertices,
        &native_vertex_coordinates,
        &vertex_points,
    )?;
    let edge_vertices = bound_vertices.edges;
    let logical_vertices = bound_vertices.vertices;
    let vertex_tolerances = bound_vertices.tolerances;
    let mut referenced_loops = HashSet::new();
    for face in &faces {
        for &loop_id in &face.loops {
            referenced_loops.insert(loop_id);
        }
    }
    loops.retain(|loop_id, _| referenced_loops.contains(loop_id));
    let complete = faces.len() == source_face_count
        && face_loop_owner_counts(&faces)
            .values()
            .all(|count| *count == 1)
        && referenced_loops.iter().all(|loop_id| {
            loops.get(loop_id).is_some_and(|loop_| {
                loop_.members.iter().all(|member| {
                    (pcurves
                        .get(&member.pcurve)
                        .is_some_and(|pcurve| pcurve.surface == loop_.surface)
                        || opaque_pcurves
                            .get(&member.pcurve)
                            .is_some_and(|pcurve| pcurve.surface == loop_.surface)
                        || implicit_pcurves.get(&member.pcurve) == Some(&loop_.surface))
                        && edge_vertices.contains_key(&member.edge)
                }) && loop_chain_closes(loop_, &edge_vertices)
            })
        });
    let Some(vertices) = B5Vertices::try_new(vertex_points, logical_vertices, edge_vertices).ok()
    else {
        return Ok(None);
    };
    Ok(Some(B5Graph {
        complete,
        faces,
        face_records,
        loops,
        pcurves,
        opaque_pcurves,
        implicit_pcurves,
        surfaces,
        surface_aliases,
        offset_surfaces,
        extrusion_surfaces,
        supported_surfaces,
        parameter_incidences,
        edges,
        vertex_incidence_links,
        vertices,
        edge_parameter_incidences,
        vertex_tolerances,
        profiles,
    }))
}

fn merge_pcurve_candidate(
    pcurves: &mut BTreeMap<u32, B5Pcurve>,
    conflicts: &mut HashSet<u32>,
    candidate: B5Pcurve,
) {
    let object_id = candidate.object_id;
    if conflicts.contains(&object_id) {
        return;
    }
    match pcurves.get(&object_id) {
        None => {
            pcurves.insert(object_id, candidate);
        }
        Some(existing) if existing == &candidate => {}
        Some(_) => {
            pcurves.remove(&object_id);
            conflicts.insert(object_id);
        }
    }
}

fn merge_surface_candidate(
    surfaces: &mut BTreeMap<u32, B5Surface>,
    conflicts: &mut HashSet<u32>,
    object_id: u32,
    candidate: B5Surface,
) -> bool {
    if conflicts.contains(&object_id) {
        return false;
    }
    match surfaces.get(&object_id) {
        None => {
            surfaces.insert(object_id, candidate);
        }
        Some(existing) if unresolved_surface_candidate(existing) => {
            surfaces.insert(object_id, candidate);
        }
        Some(existing) if unresolved_surface_candidate(&candidate) || existing == &candidate => {}
        Some(_) => {
            surfaces.remove(&object_id);
            conflicts.insert(object_id);
            return false;
        }
    }
    true
}

fn unresolved_surface_candidate(surface: &B5Surface) -> bool {
    matches!(
        surface,
        B5Surface::Unknown { .. } | B5Surface::UnresolvedNurbs { .. }
    )
}

fn copy_surface(surface: &B5Surface) -> Result<B5Surface, CodecError> {
    Ok(match surface {
        B5Surface::UnresolvedNurbs { header, payload } => B5Surface::UnresolvedNurbs {
            header: header.clone(),
            payload: payload.clone(),
        },
        B5Surface::Unknown {
            family,
            class,
            payload,
        } => B5Surface::Unknown {
            family: *family,
            class: *class,
            payload: payload.clone(),
        },
        B5Surface::Nurbs(nurbs) => B5Surface::Nurbs(nurbs.clone()),
        B5Surface::RollingBall {
            carrier_object_id,
            definition,
        } => {
            let ProceduralSurfaceDefinition::RollingBallJet(jet) = definition.as_ref() else {
                return Ok(surface.clone());
            };
            let stations = jet.stations().to_vec();
            let jet =
                cadmpeg_ir::geometry::RollingBallJetStations::from_parts(jet.degree(), stations)
                    .map_err(CodecError::malformed)?;

            B5Surface::RollingBall {
                carrier_object_id: *carrier_object_id,
                definition: Box::new(ProceduralSurfaceDefinition::RollingBallJet(jet)),
            }
        }
        other => other.clone(),
    })
}

fn resolve_surface_aliases(
    records: &[B5Record],
    by_id: &HashMap<u32, &B5Record>,
    surfaces: &mut BTreeMap<u32, B5Surface>,
    conflicts: &mut HashSet<u32>,
) -> Result<bool, CodecError> {
    let mut changed = false;
    for record in records {
        if surface_alias_target(record).is_none() {
            continue;
        }
        let Some(candidate) = surface_alias_carrier(record.object_id, by_id, surfaces)? else {
            continue;
        };
        let unchanged = surfaces.get(&record.object_id) == Some(&candidate);
        if merge_surface_candidate(surfaces, conflicts, record.object_id, candidate) && !unchanged {
            changed = true;
        }
    }
    Ok(changed)
}

fn surface_alias_carrier(
    mut object_id: u32,
    by_id: &HashMap<u32, &B5Record>,
    surfaces: &BTreeMap<u32, B5Surface>,
) -> Result<Option<B5Surface>, CodecError> {
    let mut visited = HashSet::new();
    loop {
        if !visited.insert(object_id) {
            return Ok(None);
        }
        let Some(record) = by_id.get(&object_id) else {
            return surfaces
                .get(&object_id)
                .filter(|surface| !unresolved_surface_candidate(surface))
                .map(copy_surface)
                .transpose();
        };
        let Some(target) = surface_alias_target(record) else {
            return surfaces
                .get(&object_id)
                .filter(|surface| !unresolved_surface_candidate(surface))
                .map(copy_surface)
                .transpose();
        };
        object_id = target;
    }
}

fn object_stream_pcurve_candidate(
    ctx: &DecodeContext<'_>,
    jet: &crate::families::a5a8::records::A8Pcurve,
) -> Result<Option<B5Pcurve>, CodecError> {
    let Some((_, control_points)) = jet.bspline() else {
        return Ok(None);
    };
    Ok(Some(B5Pcurve {
        object_id: jet.object_id,
        surface: jet.support_id,
        degree: crate::families::a5a8::records::A8Pcurve::DEGREE,
        distinct_knots: jet.knots(),
        multiplicities: ctx.alloc_filled(
            jet.sites.len(),
            crate::families::a5a8::records::A8Pcurve::DEGREE + 1,
            "catia_B5_object_pcurve_multiplicities",
        )?,
        control_points,
        weights: None,
        parameter_range: Some(jet.range),
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    }))
}

#[cfg(test)]
fn a8_class21_pcurves(ctx: &DecodeContext<'_>, bytes: &[u8]) -> Result<Vec<B5Pcurve>, CodecError> {
    let frames = collect_object_stream_frames(bytes);
    a8_class21_pcurves_from_frames(ctx, bytes, &frames)
}

fn a8_class21_pcurves_from_frames(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    frames: &[ObjectFrame],
) -> Result<Vec<B5Pcurve>, CodecError> {
    let mut pcurves = Vec::new();
    for frame in frames {
        if frame.family != 0xa8 || frame.class != 0x21 {
            continue;
        }
        if let Some(pcurve) =
            parse_a8_class21_pcurve(ctx, frame.object_id, &bytes[frame.start + 11..frame.end])?
        {
            pcurves.push(pcurve);
        }
    }
    Ok(pcurves)
}

fn parse_a8_class21_pcurve(
    ctx: &DecodeContext<'_>,
    object_id: u32,
    payload: &[u8],
) -> Result<Option<B5Pcurve>, CodecError> {
    (|| -> Option<Result<B5Pcurve, CodecError>> {
        (payload.first() == Some(&0x81)).then_some(())?;
        let mut position = 1;
        let surface = wire::tokens::object_ref(payload, &mut position, true)?;
        (payload.get(position) == Some(&0x01)).then_some(())?;
        position += 1;
        let degree = wire::tokens::compact_uint(payload, &mut position)?;
        (degree == 5 && payload.get(position..position + 2) == Some(&[0x01, 0x01])).then_some(())?;
        position += 2;
        let knot_count =
            usize::try_from(wire::tokens::compact_uint(payload, &mut position)?).ok()?;
        (knot_count >= 2).then_some(())?;
        matches!(payload.get(position), Some(0x01 | 0x11 | 0x19)).then_some(())?;
        position += 1;
        let scalar_bytes = knot_count.checked_mul(8)?;
        let minimum_known_bytes = scalar_bytes
            .checked_mul(7)?
            .checked_add(knot_count)?
            .checked_add(36)?;
        if position.checked_add(minimum_known_bytes)? > payload.len() {
            return None;
        }
        let read_values = |position: &mut usize, values: &mut Vec<FiniteReal>| -> Option<()> {
            for _ in 0..knot_count {
                values.push(f64_le(payload, *position)?);
                *position = position.checked_add(8)?;
            }
            Some(())
        };
        let mut distinct_knots = Vec::new();
        read_values(&mut position, &mut distinct_knots)?;
        let mut knot_values = Vec::new();
        knot_values.extend(distinct_knots.iter().copied().map(FiniteReal::get));
        if !cadmpeg_ir::geometry::nurbs::knots_strictly_increasing(&knot_values) {
            return None;
        }
        let mut multiplicities_valid = true;
        for index in 0..knot_count {
            let multiplicity = wire::tokens::compact_uint(payload, &mut position)?;
            multiplicities_valid &= multiplicity
                == if index == 0 || index + 1 == knot_count {
                    degree + 1
                } else {
                    3
                };
        }
        multiplicities_valid.then_some(())?;
        let read_lane = |position: &mut usize, values: &mut Vec<f64>| -> Option<()> {
            for _ in 0..knot_count {
                values.push(f64_le(payload, *position)?.get());
                *position = position.checked_add(8)?;
            }
            Some(())
        };
        let mut u = Vec::new();
        read_lane(&mut position, &mut u)?;
        let mut v = Vec::new();
        read_lane(&mut position, &mut v)?;
        let mut du = Vec::new();
        read_lane(&mut position, &mut du)?;
        let mut dv = Vec::new();
        read_lane(&mut position, &mut dv)?;
        let mut ddu = Vec::new();
        read_lane(&mut position, &mut ddu)?;
        let mut ddv = Vec::new();
        read_lane(&mut position, &mut ddv)?;
        let mut points = Vec::new();
        points.extend(u.into_iter().zip(v).map(|(u, v)| [u, v]));
        let mut first = Vec::new();
        first.extend(du.into_iter().zip(dv).map(|(u, v)| [u, v]));
        let mut second = Vec::new();
        second.extend(ddu.into_iter().zip(ddv).map(|(u, v)| [u, v]));
        let (_, control_points) =
            crate::nurbs::quintic_jet_bspline(degree, &knot_values, &points, &first, &second)?;
        let tail = payload.get(position..)?;
        let tail_control = tail.get(..2);
        let extension_control = tail.get(34..36);
        (matches!(tail.len(), 36 | 38)
            && (tail_control == Some(&[0x05, 0x05]) || tail_control == Some(&[0x05, 0x11]))
            && f64_le(tail, 2)?.get() == 0.0
            && f64_le(tail, 18)?.get() == 1.0
            && f64_le(tail, 26)?.get() == 0.0
            && (tail.len() == 36
                || extension_control == Some(&[0x01, 0x11])
                || extension_control == Some(&[0x01, 0x19]))
            && tail.get(tail.len() - 2..) == Some(&[0x00, 0x07]))
        .then_some(())?;
        let parameter_range = [*distinct_knots.first()?, *distinct_knots.last()?];
        let multiplicities =
            match ctx.alloc_filled(knot_count, degree + 1, "catia B5 pcurve multiplicities") {
                Ok(multiplicities) => multiplicities,
                Err(error) => return Some(Err(error)),
            };
        Some(Ok(B5Pcurve {
            object_id,
            surface,
            degree,
            distinct_knots,
            multiplicities,
            control_points,
            weights: None,
            parameter_range: Some(parameter_range),
            parameterization: B5PcurveParameterization::Native,
            class_21_suffix_scalar: Some(PositiveReal::new(f64_le(tail, 10)?.get())?),
            lifted_endpoints: None,
        }))
    })()
    .transpose()
}

/// Return native start/end vertex identities for every framed `b5 03 5e`
/// edge, keyed by the edge object id.
pub(in crate::families) fn edge_vertex_references(bytes: &[u8]) -> BTreeMap<u32, [u32; 2]> {
    let mut edges = BTreeMap::new();
    let mut ambiguous = HashSet::new();

    for frame in object_stream_frames(bytes) {
        if frame.family != 0xb5 || frame.class != 0x5e {
            continue;
        }
        let record = B5Record {
            offset: frame.start,
            family: 0xb5,
            class: 0x5e,
            object_id: frame.object_id,
            payload: bytes[frame.start + 8..frame.end].to_vec(),
        };
        let Some(edge) = parse_edge(&record) else {
            continue;
        };
        let vertices = edge.vertices;
        if edges
            .insert(frame.object_id, vertices)
            .is_some_and(|existing| existing != vertices)
        {
            ambiguous.insert(frame.object_id);
        }
    }
    edges.retain(|object_id, _| !ambiguous.contains(object_id));
    edges
}

/// Return the ordered pcurve pair owned by each requested native edge's
/// class-`23` curve-support wrapper.
#[must_use]
#[cfg(test)]
fn edge_support_pcurve_references(
    bytes: &[u8],
    edge_ids: &HashSet<u32>,
) -> BTreeMap<u32, [u32; 2]> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    edge_support_pcurve_references_from_frames(bytes, edge_ids, &frames)
}

pub(in crate::families) fn edge_support_pcurve_references_from_frames(
    bytes: &[u8],
    edge_ids: &HashSet<u32>,
    frames: &[ObjectFrame],
) -> BTreeMap<u32, [u32; 2]> {
    let mut edge_wrappers = HashMap::<u32, Option<u32>>::new();
    let mut wrappers = HashMap::<u32, Option<[u32; 2]>>::new();
    for frame in frames {
        if !((frame.class == 0x5e && edge_ids.contains(&frame.object_id))
            || (frame.family == 0xb5 && frame.class == 0x23))
        {
            continue;
        }
        let header = if frame.family == 0xa8 { 11 } else { 8 };
        let record = B5Record {
            offset: frame.start,
            family: frame.family,
            class: frame.class,
            object_id: frame.object_id,
            payload: bytes[frame.start + header..frame.end].to_vec(),
        };
        if frame.class == 0x5e && edge_ids.contains(&frame.object_id) {
            let Some(wrapper) = parse_edge(&record).map(|edge| edge.support) else {
                continue;
            };

            edge_wrappers
                .entry(frame.object_id)
                .and_modify(|stored| {
                    if stored.is_some_and(|stored| stored != wrapper) {
                        *stored = None;
                    }
                })
                .or_insert(Some(wrapper));
        } else if frame.family == 0xb5 && frame.class == 0x23 {
            let mut references = record_references(&record);
            let (Some(first), Some(second), None) =
                (references.next(), references.next(), references.next())
            else {
                continue;
            };
            let references = [first, second];

            wrappers
                .entry(frame.object_id)
                .and_modify(|stored| {
                    if stored.is_some_and(|stored| stored != references) {
                        *stored = None;
                    }
                })
                .or_insert(Some(references));
        }
    }
    let mut resolved = BTreeMap::new();
    for (edge, wrapper) in edge_wrappers {
        if let Some(references) = wrapper
            .and_then(|wrapper| wrappers.get(&wrapper))
            .and_then(Option::as_ref)
        {
            resolved.insert(edge, *references);
        }
    }
    resolved
}

pub(in crate::families) fn targeted_surfaces_from_frames(
    bytes: &[u8],
    object_ids: &HashSet<u32>,
    frames: &[ObjectFrame],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<BTreeMap<u32, B5Surface>, CodecError> {
    let mut resolved = HashMap::<u32, Option<B5Surface>>::new();

    for frame in frames {
        let Some(surface) = crate::families::a5a8::records::a8_surface_from_object_frame(
            bytes,
            frame.start,
            frame.end,
            frame.object_id,
            refusal,
        )?
        else {
            continue;
        };
        let Some(object_id) = surface.object_id() else {
            continue;
        };
        merge_targeted_surface(&mut resolved, object_id, B5Surface::Nurbs(surface.geometry));
    }
    let mut headers = HashMap::new();
    for frame in frames {
        if let Some(header) = crate::families::a5a8::records::a8_surface_header_from_object_frame(
            bytes,
            frame.start,
            frame.end,
            frame.object_id,
        ) {
            headers.insert(header.object_id, header);
        }
    }
    let mut records = HashMap::<u32, Option<B5Record>>::new();
    for frame in frames {
        if !is_surface_class(frame.class) {
            continue;
        }
        let Some(record) = record_from_frame(bytes, frame) else {
            continue;
        };

        records
            .entry(frame.object_id)
            .and_modify(|stored| {
                if stored.as_ref().is_some_and(|stored| {
                    stored.family != record.family
                        || stored.class != record.class
                        || stored.payload != record.payload
                }) {
                    *stored = None;
                }
            })
            .or_insert(Some(record));
    }
    let mut rolling = HashMap::<u32, Option<B5Surface>>::new();
    for jet in crate::families::a5a8::records::a8_freeform_curves(bytes) {
        let Some(definition) = crate::families::a5a8::records::rolling_ball_jet_definition(&jet)
        else {
            continue;
        };
        merge_targeted_surface(
            &mut rolling,
            jet.object_id,
            B5Surface::RollingBall {
                carrier_object_id: jet.object_id,
                definition: Box::new(definition),
            },
        );
    }
    let mut surfaces = BTreeMap::new();
    let mut bounded = 0usize;
    for &object_id in object_ids {
        let budget = WorkBudget::new(MAX_TARGETED_SURFACE_RESOLUTION_STEPS);
        let surface =
            resolve_targeted_surface(object_id, &records, &headers, &resolved, &rolling, &budget)?;
        if budget.exhausted() {
            bounded += 1;
        } else if let Some(surface) = surface {
            surfaces.insert(object_id, surface);
        }
    }
    if bounded > 0 {
        refusal.push_standard_search_bounded(format_args!(
            "The targeted B5 surface resolution reached its bound of \
             {MAX_TARGETED_SURFACE_RESOLUTION_STEPS} steps for {bounded} requested surfaces; \
             those surfaces stay unresolved."
        ));
    }
    Ok(surfaces)
}

/// Resolve the unique length-closed geometry construction frames independently
/// of the dominant topology run.
#[cfg(test)]
fn targeted_geometry_graph(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<B5Graph>, CodecError> {
    let frames = collect_object_stream_frames(bytes);
    targeted_geometry_graph_from_frames(ctx, bytes, &frames, &mut crate::nurbs::LaneRefusals::new())
}

pub(in crate::families) fn targeted_geometry_graph_from_frames(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    frames: &[ObjectFrame],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<B5Graph>, CodecError> {
    let mut candidates = HashMap::<u32, Option<B5Record>>::new();
    for frame in frames {
        if !is_targeted_geometry_class(frame.family, frame.class) {
            continue;
        }
        let Some(record) = record_from_frame(bytes, frame) else {
            continue;
        };

        candidates
            .entry(frame.object_id)
            .and_modify(|stored| {
                if stored.as_ref().is_some_and(|stored| {
                    stored.family != record.family
                        || stored.class != record.class
                        || stored.payload != record.payload
                }) {
                    *stored = None;
                }
            })
            .or_insert(Some(record));
    }
    let mut records = Vec::new();
    for record in candidates.into_values().flatten() {
        records.push(record);
    }
    records.sort_by_key(|left| left.offset);
    parse_from_records(ctx, bytes, &records, frames, false, None, refusal)
}

fn is_targeted_geometry_class(family: u8, class: u8) -> bool {
    match family {
        0xb5 => matches!(
            class,
            0x0e | 0x0f
                | 0x14
                | 0x18
                | 0x19
                | 0x1a
                | 0x1d
                | 0x21
                | 0x24
                | 0x27
                | 0x28
                | 0x29
                | 0x2a
                | 0x2c
                | 0x2d
                | 0x2e
                | 0x30
                | 0x31
                | 0x37
                | 0x38
                | 0x3b
        ),
        0xa8 => matches!(class, 0x20 | 0x21 | 0x25 | 0x32 | 0x34),
        _ => false,
    }
}

fn merge_targeted_surface(
    candidates: &mut HashMap<u32, Option<B5Surface>>,
    object_id: u32,
    surface: B5Surface,
) {
    candidates
        .entry(object_id)
        .and_modify(|stored| {
            if stored.as_ref().is_some_and(|stored| stored != &surface) {
                *stored = None;
            }
        })
        .or_insert(Some(surface));
}

/// Resolution calls for one requested surface. An analytic offset resolves
/// both its carrier and its source, so shared offsets can branch.
pub(crate) const MAX_TARGETED_SURFACE_RESOLUTION_STEPS: usize = 4_096;
/// Analytic offsets one requested surface may resolve through before its
/// resolution stops; each level holds two resolution frames on the stack.
pub(crate) const MAX_TARGETED_SURFACE_OFFSET_DEPTH: usize = 64;

/// Resolve one requested surface through aliases, constructions and analytic
/// offsets. `None` when it does not resolve; `budget` is exhausted when the
/// resolution stopped at its bound instead.
fn resolve_targeted_surface(
    object_id: u32,
    records: &HashMap<u32, Option<B5Record>>,
    headers: &HashMap<u32, crate::families::a5a8::records::A8SurfaceHeader>,
    resolved: &HashMap<u32, Option<B5Surface>>,
    rolling: &HashMap<u32, Option<B5Surface>>,
    budget: &WorkBudget,
) -> Result<Option<B5Surface>, CodecError> {
    resolve_targeted_surface_inner(
        object_id,
        records,
        headers,
        resolved,
        rolling,
        (HashSet::new(), 0),
        budget,
    )
}

fn resolve_targeted_surface_inner(
    mut object_id: u32,
    records: &HashMap<u32, Option<B5Record>>,
    headers: &HashMap<u32, crate::families::a5a8::records::A8SurfaceHeader>,
    resolved: &HashMap<u32, Option<B5Surface>>,
    rolling: &HashMap<u32, Option<B5Surface>>,
    (mut visited, depth): (HashSet<u32>, usize),
    budget: &WorkBudget,
) -> Result<Option<B5Surface>, CodecError> {
    if depth >= MAX_TARGETED_SURFACE_OFFSET_DEPTH {
        budget.exhaust();
        return Ok(None);
    }
    if !budget.charge() {
        return Ok(None);
    }
    loop {
        if !visited.insert(object_id) || records.get(&object_id).is_some_and(Option::is_none) {
            return Ok(None);
        }
        let rolling_surface = rolling
            .get(&object_id)
            .and_then(Option::as_ref)
            .map(copy_surface)
            .transpose()?;
        let resolved_surface = resolved
            .get(&object_id)
            .and_then(Option::as_ref)
            .map(copy_surface)
            .transpose()?;
        match (rolling_surface, resolved_surface) {
            (Some(left), Some(right)) if left != right => return Ok(None),
            (Some(surface), _) | (_, Some(surface)) => return Ok(Some(surface)),
            (None, None) => {}
        }
        let Some(record) = records.get(&object_id).and_then(Option::as_ref) else {
            return Ok(None);
        };
        if let Some(target) = surface_alias_target(record) {
            object_id = target;
            continue;
        }
        if let Some(construction) = parse_supported_surface(record) {
            let Some(carrier) = resolve_targeted_surface_inner(
                construction.carrier_surface,
                records,
                headers,
                resolved,
                rolling,
                (visited.clone(), depth + 1),
                budget,
            )?
            else {
                return Ok(None);
            };
            return Ok(supported_surface_parameters_match_carrier(
                &construction.parameters,
                &carrier,
            )
            .then_some(carrier));
        }
        if record.family == 0xb5 && record.class == 0x30 {
            return resolve_targeted_analytic_offset(
                record,
                records,
                headers,
                resolved,
                rolling,
                (&visited, depth + 1),
                budget,
            );
        }
        return Ok(surface_node(record, headers.get(&object_id)));
    }
}

fn resolve_targeted_analytic_offset(
    record: &B5Record,
    records: &HashMap<u32, Option<B5Record>>,
    headers: &HashMap<u32, crate::families::a5a8::records::A8SurfaceHeader>,
    resolved: &HashMap<u32, Option<B5Surface>>,
    rolling: &HashMap<u32, Option<B5Surface>>,
    (visited, depth): (&HashSet<u32>, usize),
    budget: &WorkBudget,
) -> Result<Option<B5Surface>, CodecError> {
    if record.payload.first() != Some(&0x82) {
        return Ok(None);
    }
    let mut position = 1;
    let Some(carrier_id) = wire::tokens::object_ref(&record.payload, &mut position, true) else {
        return Ok(None);
    };
    let Some(source_id) = wire::tokens::object_ref(&record.payload, &mut position, true) else {
        return Ok(None);
    };
    let Some(carrier) = resolve_targeted_surface_inner(
        carrier_id,
        records,
        headers,
        resolved,
        rolling,
        (visited.clone(), depth),
        budget,
    )?
    else {
        return Ok(None);
    };
    let mut surfaces = BTreeMap::new();
    surfaces.insert(carrier_id, copy_surface(&carrier)?);
    if !matches!(carrier, B5Surface::RollingBall { .. }) {
        let Some(source) = resolve_targeted_surface_inner(
            source_id,
            records,
            headers,
            resolved,
            rolling,
            (visited.clone(), depth),
            budget,
        )?
        else {
            return Ok(None);
        };
        surfaces.insert(source_id, source);
    }
    if parse_offset_surface(record, &surfaces, &BTreeMap::new(), &HashMap::new()).is_none() {
        return Ok(None);
    }
    Ok(Some(carrier))
}

fn parse_edge(record: &B5Record) -> Option<B5Edge> {
    (record.class == 0x5e && record.payload.first() == Some(&0x85)).then_some(())?;
    let mut position = 1;
    let references = [
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
    ];
    let &[terminal_control] = record.payload.get(position..)? else {
        return None;
    };
    let terminal_control = B5EdgeTerminalControl::from_byte(terminal_control)?;
    Some(B5Edge {
        object_id: record.object_id,
        support: references[0],
        vertices: [references[1], references[2]],
        parameter_incidences: [references[3], references[4]],
        terminal_control,
    })
}

struct B5PcurveContext<'a> {
    pcurves: &'a BTreeMap<u32, B5Pcurve>,
    opaque_pcurves: &'a BTreeMap<u32, B5OpaquePcurve>,
    surfaces: &'a BTreeMap<u32, B5Surface>,
    profiles: &'a BTreeMap<u32, B5Profile>,
    edge_parameter_incidences: &'a BTreeMap<u32, [u32; 2]>,
    parameter_incidences: &'a BTreeMap<u32, B5ParameterIncidence>,
}

fn incidence_vertex_coordinates(
    ctx: &DecodeContext<'_>,
    native_edges: &BTreeMap<u32, [u32; 2]>,
    vertex_incidence_links: &BTreeMap<u32, B5VertexIncidenceLink>,
    by_id: &HashMap<u32, &B5Record>,
    geometry: &B5PcurveContext<'_>,
) -> Result<BTreeMap<u32, FinitePoint3>, CodecError> {
    let mut seen = HashSet::new();
    let mut coordinates_by_vertex = BTreeMap::new();
    for vertex in native_edges.values().flatten().copied() {
        if !seen.insert(vertex) {
            continue;
        }
        let Some(link) = vertex_incidence_links.get(&vertex) else {
            continue;
        };
        let Some(roster_record) = by_id.get(&link.incidence) else {
            continue;
        };
        let Some(incidence_records) = counted_references(roster_record, 0x05) else {
            continue;
        };
        let mut first = None;
        let mut valid = true;
        let tolerance_squared = POINT_TOLERANCE * POINT_TOLERANCE;
        'incidences: for incidence_record in incidence_records {
            let Some(record) = by_id.get(&incidence_record) else {
                valid = false;
                break;
            };
            let Some(incidence) = parameter_incidence(record) else {
                valid = false;
                break;
            };
            if incidence.lanes.is_empty() {
                valid = false;
                break;
            }
            for lane in incidence.lanes {
                let Some(point) =
                    lift_parameter_incidence(ctx, lane.curve, lane.parameter, geometry)?
                else {
                    valid = false;
                    break 'incidences;
                };
                if let Some(reference) = first {
                    if distance_squared(coordinates(point), coordinates(reference))
                        > tolerance_squared
                    {
                        valid = false;
                        break 'incidences;
                    }
                } else {
                    first = Some(point);
                }
            }
        }
        if let (true, Some(point)) = (valid, first) {
            coordinates_by_vertex.insert(vertex, point);
        }
    }
    Ok(coordinates_by_vertex)
}

/// Evaluate one class-`06` curve/parameter pair at its native parameter
/// domain. A vertex roster is valid only when every pair evaluates, so one
/// unsupported, malformed, or out-of-domain member withholds the identity
/// coordinate instead of allowing an earlier member to win.
fn lift_parameter_incidence(
    ctx: &DecodeContext<'_>,
    pcurve_id: u32,
    parameter: FiniteReal,
    geometry: &B5PcurveContext<'_>,
) -> Result<Option<FinitePoint3>, CodecError> {
    if let Some(pcurve) = geometry.pcurves.get(&pcurve_id) {
        let Some(domain) = pcurve_parameter_domain(pcurve) else {
            return Ok(None);
        };
        if parameter < domain[0] || parameter > domain[1] {
            return Ok(None);
        }
        let Some(uv) = evaluate_pcurve(ctx, pcurve, parameter.get())? else {
            return Ok(None);
        };
        let Some(surface) = geometry.surfaces.get(&pcurve.surface) else {
            return Ok(None);
        };
        return Ok(
            lift_pcurve_endpoints(ctx, surface, geometry.profiles, [uv, uv])?
                .map(|[point, _]| point),
        );
    }
    let Some(opaque) = geometry.opaque_pcurves.get(&pcurve_id) else {
        return Ok(None);
    };
    let Some(pcurve) = opaque.sphere_great_circle.as_ref() else {
        return Ok(None);
    };
    let Some(surface) = geometry.surfaces.get(&opaque.surface) else {
        return Ok(None);
    };
    Ok(sphere_great_circle_point(pcurve, surface, parameter))
}

fn parse_vertex_incidence_link(record: &B5Record) -> Option<B5VertexIncidenceLink> {
    (record.class == 0x5d && record.payload.first() == Some(&0x81)).then_some(())?;
    let mut position = 1;
    let incidence = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let &[terminal_control] = record.payload.get(position..)? else {
        return None;
    };
    let terminal_control = B5VertexIncidenceControl::from_byte(terminal_control)?;
    Some(B5VertexIncidenceLink {
        object_id: record.object_id,
        incidence,
        terminal_control,
    })
}

fn counted_references(record: &B5Record, class: u8) -> Option<Vec<u32>> {
    if record.class != class {
        return None;
    }
    let (references, position) = wire::tokens::counted_refs(&record.payload, true)?;
    (position == record.payload.len()).then_some(references)
}

fn parameter_incidence(record: &B5Record) -> Option<B5ParameterIncidence> {
    if record.class != 0x06 {
        return None;
    }
    let count = record
        .payload
        .first()
        .and_then(|lead| lead.checked_sub(0x80))?;
    let count = usize::from(count);
    let mut position = 1;
    let references = (0..count)
        .map(|_| wire::tokens::object_ref(&record.payload, &mut position, true))
        .collect::<Option<Vec<_>>>()?;
    let expected = u8::try_from(count)
        .ok()
        .and_then(|count| 0x80u8.checked_add(count))?;
    if record.payload.get(position) != Some(&expected) {
        return None;
    }
    position += 1;
    let mut lanes = Vec::new();
    for curve in references {
        let parameter = f64_le(&record.payload, position)?;
        let next = position.checked_add(8)?;
        position = next;
        let control = wire::tokens::compact_uint(&record.payload, &mut position)?;
        lanes.push(B5IncidenceLane {
            curve,
            parameter,
            control,
        });
    }
    (position == record.payload.len()).then_some(B5ParameterIncidence {
        object_id: record.object_id,
        lanes,
    })
}

fn implicit_pcurve_bindings(
    records: &[B5Record],
    by_id: &HashMap<u32, &B5Record>,
    pcurves: &BTreeMap<u32, B5Pcurve>,
    opaque_pcurves: &BTreeMap<u32, B5OpaquePcurve>,
    surfaces: &BTreeMap<u32, B5Surface>,
) -> BTreeMap<u32, u32> {
    let mut bindings = BTreeMap::new();
    let mut ambiguous = HashSet::new();
    for record in records.iter().filter(|record| record.class == 0x62) {
        let Some((references, _, _)) = loop_references_and_metadata(record) else {
            continue;
        };
        let Some((&surface, occurrences)) = references.split_last() else {
            continue;
        };
        if !surfaces.contains_key(&surface) {
            continue;
        }
        for occurrence in occurrences.chunks_exact(2) {
            let pcurve = occurrence[0];
            if pcurves.contains_key(&pcurve)
                || opaque_pcurves.contains_key(&pcurve)
                || by_id.contains_key(&pcurve)
            {
                continue;
            }
            let Some(edge) = by_id.get(&occurrence[1]).and_then(|edge| parse_edge(edge)) else {
                continue;
            };
            let endpoint_incidence_contains = |reference_id| {
                by_id
                    .get(&reference_id)
                    .and_then(|record| parameter_incidence(record))
                    .is_some_and(|incidence| {
                        incidence.lanes.iter().any(|lane| lane.curve == pcurve)
                    })
            };
            let curve_wrapper_contains = by_id.get(&edge.support).is_some_and(|wrapper| {
                matches!(wrapper.class, 0x23..=0x25)
                    && record_references(wrapper).any(|reference| reference == pcurve)
            });
            if !(curve_wrapper_contains
                || endpoint_incidence_contains(edge.parameter_incidences[0])
                    && endpoint_incidence_contains(edge.parameter_incidences[1]))
            {
                continue;
            }
            if bindings
                .insert(pcurve, surface)
                .is_some_and(|existing| existing != surface)
            {
                ambiguous.insert(pcurve);
            }
        }
    }
    bindings.retain(|pcurve, _| !ambiguous.contains(pcurve));
    bindings
}

pub(super) fn evaluate_pcurve(
    ctx: &DecodeContext<'_>,
    pcurve: &B5Pcurve,
    parameter: f64,
) -> Result<Option<[f64; 2]>, CodecError> {
    let Some(knots) = pcurve_nurbs_knots(pcurve) else {
        return Ok(None);
    };
    let knots = knots.into_iter().map(FiniteReal::get).collect::<Vec<_>>();
    let control_points = pcurve
        .control_points
        .iter()
        .map(|point| Point2::new(point[0], point[1]))
        .collect::<Vec<_>>();
    let weights = pcurve.weights.as_ref().map(|weights| {
        weights
            .iter()
            .copied()
            .map(PositiveReal::get)
            .collect::<Vec<_>>()
    });
    let point = cadmpeg_ir::eval::finite_or_refusal(nurbs_pcurve_uv(
        ctx,
        pcurve.degree,
        &knots,
        &control_points,
        weights.as_deref(),
        parameter,
    ))?
    .map(Point2::from);
    Ok(point.map(|point| [point.u, point.v]))
}

fn pcurve_knots(pcurve: &B5Pcurve) -> Option<Vec<FiniteReal>> {
    let mut knots = Vec::new();

    for (&knot, &multiplicity) in pcurve.distinct_knots.iter().zip(&pcurve.multiplicities) {
        let multiplicity = usize::try_from(multiplicity).ok()?;
        knots.extend(std::iter::repeat_with(|| knot).take(multiplicity));
    }
    Some(knots)
}

/// Return the knot vector in the pcurve's occurrence coordinate system. A
/// translated knot is admitted finite, since the translation can overflow.
pub(super) fn pcurve_nurbs_knots(pcurve: &B5Pcurve) -> Option<Vec<FiniteReal>> {
    let mut knots = pcurve_knots(pcurve)?;
    match pcurve.parameterization {
        B5PcurveParameterization::Native => {}
        B5PcurveParameterization::Translated { native_origin } => {
            for knot in &mut knots {
                let value = FiniteReal::new(knot.get() - native_origin.get())?;
                *knot = value;
            }
        }
    }
    Some(knots)
}

pub(super) fn pcurve_parameter_domain(pcurve: &B5Pcurve) -> Option<[FiniteReal; 2]> {
    let degree = usize::try_from(pcurve.degree).ok()?;
    let total = pcurve
        .distinct_knots
        .iter()
        .zip(&pcurve.multiplicities)
        .try_fold(0usize, |count, (_, multiplicity)| {
            count.checked_add(usize::try_from(*multiplicity).ok()?)
        })?;
    let last = total.checked_sub(degree.checked_add(1)?)?;
    let mut first_knot = None;
    let mut last_knot = None;
    let mut index = 0usize;
    for (&knot, &multiplicity) in pcurve.distinct_knots.iter().zip(&pcurve.multiplicities) {
        let next = index.checked_add(usize::try_from(multiplicity).ok()?)?;
        if index < next {
            let knot = match pcurve.parameterization {
                B5PcurveParameterization::Native => knot,
                B5PcurveParameterization::Translated { native_origin } => {
                    FiniteReal::new(knot.get() - native_origin.get())?
                }
            };
            if index <= degree && degree < next {
                first_knot = Some(knot);
            }
            if index <= last && last < next {
                last_knot = Some(knot);
            }
        }
        index = next;
    }
    let spline_domain = [first_knot?, last_knot?];
    if spline_domain[0] >= spline_domain[1] {
        return None;
    }
    match pcurve.parameter_range {
        Some(range) => bounded_occurrence_range(range, spline_domain),
        None => Some(spline_domain),
    }
}

/// Clamp an occurrence range to an increasing native domain.
pub(super) fn bounded_occurrence_range(
    parameters: [FiniteReal; 2],
    domain: [FiniteReal; 2],
) -> Option<[FiniteReal; 2]> {
    const RELATIVE_PARAMETER_TOLERANCE: f64 = EPS_B5_GRAPH_DEGENERATE;

    let [lower, upper] = domain;
    let domain_span = upper.get() - lower.get();
    if !domain_span.is_finite() || domain_span <= 0.0 || parameters[0] == parameters[1] {
        return None;
    }
    let tolerance = RELATIVE_PARAMETER_TOLERANCE * domain_span;
    if parameters.iter().any(|parameter| {
        parameter.get() < lower.get() - tolerance || parameter.get() > upper.get() + tolerance
    }) {
        return None;
    }
    Some(parameters.map(|parameter| {
        if parameter < lower {
            lower
        } else if parameter > upper {
            upper
        } else {
            parameter
        }
    }))
}

struct BoundNativeVertices {
    edges: BTreeMap<u32, [B5VertexRef; 2]>,
    vertices: Vec<B5LogicalVertex>,
    tolerances: BTreeMap<usize, PositiveReal>,
}

fn bind_native_vertices(
    ctx: &DecodeContext<'_>,
    loops: &BTreeMap<u32, B5Loop>,
    geometry: &B5PcurveContext<'_>,
    native_edges: &BTreeMap<u32, [u32; 2]>,
    geometric_edges: &BTreeMap<u32, [usize; 2]>,
    native_coordinates: &BTreeMap<u32, FinitePoint3>,
    points: &[FinitePoint3],
) -> Result<BoundNativeVertices, CodecError> {
    let mut constraints = Vec::new();
    for (edge, vertices) in native_edges {
        if let Some(points) = geometric_edges.get(edge) {
            constraints.push((*vertices, *points));
        }
    }
    let mut adjacency = HashMap::<u32, Vec<usize>>::new();
    for (index, (vertices, _)) in constraints.iter().enumerate() {
        for vertex in vertices {
            adjacency.entry(*vertex).or_default().push(index);
        }
    }
    let vertex_points = propagate_vertex_points(&constraints, &adjacency, points);
    let mut logical_coordinates = HashMap::new();
    for (vertex, point) in vertex_points {
        logical_coordinates.insert(vertex, points[point]);
    }
    for (&vertex, &point) in native_coordinates {
        logical_coordinates.insert(vertex, point);
    }
    // Native vertex identity fixes topology even when incident lifted endpoints
    // are separated. Keep the first deterministic finite lift as the logical
    // coordinate; the pass below records every separation in vertex tolerance.
    for loop_ in loops.values() {
        for member in &loop_.members {
            let (Some(vertices), Some(lifted)) = (
                native_edges.get(&member.edge),
                pcurve_endpoints(ctx, member.pcurve, member.edge, geometry)?,
            ) else {
                continue;
            };
            for lane in 0..2 {
                logical_coordinates
                    .entry(vertices[lane])
                    .or_insert(lifted[lane]);
            }
        }
    }
    let mut ranked = logical_coordinates.into_iter().collect::<Vec<_>>();
    ranked.sort_unstable_by_key(|(left, _)| *left);
    let mut logical_vertex_indices = HashMap::new();
    let mut logical_vertices = Vec::new();
    for (rank, (object_id, point)) in ranked.into_iter().enumerate() {
        logical_vertex_indices.insert(object_id, B5VertexRef::Logical(rank));
        logical_vertices.push(B5LogicalVertex { object_id, point });
    }
    let mut edge_vertices = BTreeMap::new();
    for (&edge, vertices) in geometric_edges {
        edge_vertices.insert(edge, vertices.map(B5VertexRef::Raw));
    }
    for (&edge, vertices) in native_edges {
        if let (Some(&start), Some(&end)) = (
            logical_vertex_indices.get(&vertices[0]),
            logical_vertex_indices.get(&vertices[1]),
        ) {
            edge_vertices.insert(edge, [start, end]);
        }
    }
    let mut tolerances = BTreeMap::<usize, PositiveReal>::new();
    for loop_ in loops.values() {
        for member in &loop_.members {
            let Some(lifted) = pcurve_endpoints(ctx, member.pcurve, member.edge, geometry)? else {
                continue;
            };
            let lifted = lifted.map(coordinates);
            let Some(&loci) = edge_vertices.get(&member.edge) else {
                continue;
            };
            let residuals = [
                (
                    loci[0],
                    distance_squared(
                        vertex_coordinate(points, &logical_vertices, loci[0]),
                        lifted[0],
                    )
                    .sqrt(),
                ),
                (
                    loci[1],
                    distance_squared(
                        vertex_coordinate(points, &logical_vertices, loci[1]),
                        lifted[1],
                    )
                    .sqrt(),
                ),
            ];
            for (locus, residual) in residuals {
                if residual <= POINT_TOLERANCE {
                    continue;
                }
                let Some(candidate) = PositiveReal::new(residual + EPS_B5_GRAPH_GEOMETRY) else {
                    continue;
                };

                tolerances
                    .entry(locus.combined_index(points.len()))
                    .and_modify(|tolerance| {
                        if candidate > *tolerance {
                            *tolerance = candidate;
                        }
                    })
                    .or_insert(candidate);
            }
        }
    }
    Ok(BoundNativeVertices {
        edges: edge_vertices,
        vertices: logical_vertices,
        tolerances,
    })
}

fn propagate_vertex_points(
    constraints: &[([u32; 2], [usize; 2])],
    adjacency: &HashMap<u32, Vec<usize>>,
    points: &[FinitePoint3],
) -> HashMap<u32, usize> {
    let mut mapping = HashMap::<u32, usize>::new();
    let mut completed = HashSet::new();
    for seed in 0..constraints.len() {
        if completed.contains(&seed) {
            continue;
        }
        let (component, members, consistent) =
            propagate_vertex_component(seed, constraints, adjacency, points);
        for member in members {
            completed.insert(member);
        }
        if consistent {
            for (vertex, locus) in component {
                mapping.insert(vertex, locus);
            }
        }
    }
    mapping
}

fn propagate_vertex_component(
    seed: usize,
    constraints: &[([u32; 2], [usize; 2])],
    adjacency: &HashMap<u32, Vec<usize>>,
    points: &[FinitePoint3],
) -> VertexComponentOutput {
    let mut mapping = HashMap::new();
    let mut members = Vec::new();
    let mut pending = std::collections::VecDeque::new();
    let mut visited = HashSet::new();
    let mut consistent = true;
    let assign = |mapping: &mut HashMap<u32, usize>,
                  pending: &mut std::collections::VecDeque<u32>,
                  consistent: &mut bool,
                  vertex,
                  locus| {
        if let Some(&previous) = mapping.get(&vertex) {
            let residual =
                distance_squared(coordinates(points[previous]), coordinates(points[locus]));
            if !residual.is_finite() || residual > POINT_TOLERANCE * POINT_TOLERANCE {
                *consistent = false;
            }
        } else {
            mapping.insert(vertex, locus);
            pending.push_back(vertex);
        }
    };
    let (seed_vertices, seed_loci) = constraints[seed];
    assign(
        &mut mapping,
        &mut pending,
        &mut consistent,
        seed_vertices[0],
        seed_loci[0],
    );
    assign(
        &mut mapping,
        &mut pending,
        &mut consistent,
        seed_vertices[1],
        seed_loci[1],
    );
    while let Some(vertex) = pending.pop_front() {
        for &index in adjacency.get(&vertex).into_iter().flatten() {
            if !visited.insert(index) {
                continue;
            }
            members.push(index);
            let (vertices, loci) = constraints[index];
            for lane in 0..2 {
                assign(
                    &mut mapping,
                    &mut pending,
                    &mut consistent,
                    vertices[lane],
                    loci[lane],
                );
            }
        }
    }
    (mapping, members, consistent)
}

fn vertex_coordinate(
    points: &[FinitePoint3],
    logical_vertices: &[B5LogicalVertex],
    vertex: B5VertexRef,
) -> [f64; 3] {
    coordinates(match vertex {
        B5VertexRef::Raw(index) => points[index],
        B5VertexRef::Logical(index) => logical_vertices[index].point,
    })
}

pub(super) fn loop_chain_closes(
    loop_: &B5Loop,
    edge_vertices: &BTreeMap<u32, [B5VertexRef; 2]>,
) -> bool {
    let mut members = loop_.members.iter();
    let Some(first_member) = members.next() else {
        return false;
    };
    let Some(first) = edge_vertices.get(&first_member.edge) else {
        return false;
    };
    let first_reversed = usize::from(first_member.controls[0] == -1);
    let initial = first[first_reversed];
    let mut current = first[1 - first_reversed];
    for member in members {
        let Some(endpoints) = edge_vertices.get(&member.edge) else {
            return false;
        };
        let reversed = usize::from(member.controls[0] == -1);
        if endpoints[reversed] != current {
            return false;
        }
        current = endpoints[1 - reversed];
    }
    current == initial
}

fn parse_profile(record: &B5Record) -> Option<B5Profile> {
    (record.family == 0xb5).then_some(())?;
    match record.class {
        0x0e => {
            (record.payload.len() == b5_line_profile::LEN && record.payload.first() == Some(&0x80))
                .then_some(())?;
            let direction = ExactUnitVector3::new(
                read_f64_array::<3>(&record.payload, b5_line_profile::DIRECTION)?
                    .map(FiniteReal::get),
            )?;
            let parameter_range = IncreasingParameterInterval::new([
                f64_le(&record.payload, b5_line_profile::PARAMETER_RANGE)?.get(),
                f64_le(
                    &record.payload,
                    b5_line_profile::PARAMETER_RANGE + std::mem::size_of::<f64>(),
                )?
                .get(),
            ])?;
            (f64_le(&record.payload, b5_line_profile::ONE)?.get() == 1.0).then_some(
                B5Profile::Line {
                    point: f64_point(&record.payload, b5_line_profile::POINT)?,
                    direction,
                    parameter_range,
                },
            )
        }
        0x0f => {
            (record.payload.len() == b5_arc_profile::LEN && record.payload.first() == Some(&0x80))
                .then_some(())?;
            let [direction_x, direction_y] = unit_and_orthogonal_directions(
                read_f64_array::<3>(&record.payload, b5_arc_profile::DIRECTION_X)?
                    .map(FiniteReal::get),
                read_f64_array::<3>(&record.payload, b5_arc_profile::DIRECTION_Y)?
                    .map(FiniteReal::get),
            )?;
            let radius =
                PositiveLength::new(f64_le(&record.payload, b5_arc_profile::RADIUS)?.get())?;
            let parameter_range = [
                f64_le(&record.payload, b5_arc_profile::PARAMETER_RANGE)?.get(),
                f64_le(
                    &record.payload,
                    b5_arc_profile::PARAMETER_RANGE + std::mem::size_of::<f64>(),
                )?
                .get(),
            ];
            let chart_origin = f64_le(&record.payload, b5_arc_profile::CHART_ORIGIN)?.get();
            let scaled = |value: f64| value / radius.get();
            (periodic_angular_range_is_valid(
                parameter_range.map(scaled),
                [
                    scaled(chart_origin),
                    scaled(chart_origin) + std::f64::consts::TAU,
                ],
            ) && f64_le(&record.payload, b5_arc_profile::ONE)?.get() == 1.0)
                .then_some(())?;
            Some(B5Profile::Arc {
                center: f64_point(&record.payload, b5_arc_profile::CENTER)?,
                direction_x,
                direction_y,
                radius,
                // The angular check divides both endpoints by the positive
                // radius and finds them strictly increasing, so the stored
                // endpoints are strictly increasing too.
                parameter_range: IncreasingParameterInterval::new(parameter_range)?,
            })
        }
        _ => None,
    }
}

fn bind_edge_vertices(
    ctx: &DecodeContext<'_>,
    loops: &BTreeMap<u32, B5Loop>,
    geometry: &B5PcurveContext<'_>,
    points: &[FinitePoint3],
) -> Result<BTreeMap<u32, [usize; 2]>, CodecError> {
    let point_index = point_index(points)?;
    let mut edges: BTreeMap<u32, [usize; 2]> = BTreeMap::new();
    let mut conflicts = HashSet::new();
    for loop_ in loops.values() {
        for member in &loop_.members {
            if conflicts.contains(&member.edge) {
                continue;
            }
            let Some(endpoints) = pcurve_endpoints(ctx, member.pcurve, member.edge, geometry)?
            else {
                continue;
            };
            let [Some(start), Some(end)] = endpoints
                .map(|endpoint| canonical_point(points, &point_index, coordinates(endpoint)))
            else {
                continue;
            };
            let indices = [start, end];
            if let Some(previous) = edges.get(&member.edge) {
                let mut previous_sorted = *previous;
                let mut current_sorted = indices;
                previous_sorted.sort_unstable_by(Ord::cmp);
                current_sorted.sort_unstable_by(Ord::cmp);
                if previous_sorted != current_sorted {
                    edges.remove(&member.edge);
                    conflicts.insert(member.edge);
                }
            } else {
                edges.insert(member.edge, indices);
            }
        }
    }
    Ok(edges)
}

fn pcurve_endpoints(
    ctx: &DecodeContext<'_>,
    pcurve_id: u32,
    edge_id: u32,
    geometry: &B5PcurveContext<'_>,
) -> Result<Option<[FinitePoint3; 2]>, CodecError> {
    if let Some(pcurve) = geometry.pcurves.get(&pcurve_id) {
        let parameters = edge_pcurve_parameter_values(
            geometry.edge_parameter_incidences,
            geometry.parameter_incidences,
            edge_id,
            pcurve_id,
        )
        .and_then(|parameters| {
            bounded_occurrence_range(parameters, pcurve_parameter_domain(pcurve)?)
        })
        // A missing or invalid edge incidence selects the complete pcurve
        // knot domain. This is the native object-stream fallback; it is not
        // permission to use an arbitrary control-polygon endpoint.
        .or_else(|| pcurve_parameter_domain(pcurve));
        let Some(parameters) = parameters else {
            return Ok(pcurve.lifted_endpoints);
        };
        let Some(first) = evaluate_pcurve(ctx, pcurve, parameters[0].get())? else {
            return Ok(None);
        };
        let Some(second) = evaluate_pcurve(ctx, pcurve, parameters[1].get())? else {
            return Ok(None);
        };
        let uv = [first, second];
        let Some(surface) = geometry.surfaces.get(&pcurve.surface) else {
            return Ok(pcurve.lifted_endpoints);
        };
        return Ok(
            lift_pcurve_endpoints(ctx, surface, geometry.profiles, uv)?.or(pcurve.lifted_endpoints)
        );
    }
    let Some(opaque) = geometry.opaque_pcurves.get(&pcurve_id) else {
        return Ok(None);
    };
    let Some(pcurve) = opaque.sphere_great_circle.as_ref() else {
        return Ok(None);
    };
    let Some(surface) = geometry.surfaces.get(&opaque.surface) else {
        return Ok(None);
    };
    let [start, end] = edge_pcurve_parameter_values(
        geometry.edge_parameter_incidences,
        geometry.parameter_incidences,
        edge_id,
        pcurve_id,
    )
    .and_then(|parameters| bounded_occurrence_range(parameters, pcurve.u_bounds.finite_endpoints()))
    .unwrap_or(pcurve.u_bounds.finite_endpoints());
    Ok(sphere_great_circle_point(pcurve, surface, start)
        .zip(sphere_great_circle_point(pcurve, surface, end))
        .map(|(start, end)| [start, end]))
}

/// CATIA's object-stream on-carrier incidence tolerance, in millimetres.
const POINT_TOLERANCE: f64 = 1e-3;

fn point_cell(point: [f64; 3]) -> Option<[i64; 3]> {
    let [x, y, z] =
        point.map(|coordinate| truncate_f64_to_i64((coordinate / POINT_TOLERANCE).floor()));
    Some([x?, y?, z?])
}

fn point_index(points: &[FinitePoint3]) -> Result<HashMap<[i64; 3], Vec<usize>>, CodecError> {
    let mut index = HashMap::<[i64; 3], Vec<usize>>::new();
    for (point_index, point) in points.iter().enumerate() {
        let cell = point_cell(coordinates(*point))
            .ok_or_else(|| CodecError::malformed("B5 point exceeds spatial index range"))?;

        index.entry(cell).or_default().push(point_index);
    }
    Ok(index)
}

fn canonical_point(
    points: &[FinitePoint3],
    index: &HashMap<[i64; 3], Vec<usize>>,
    endpoint: [f64; 3],
) -> Option<usize> {
    let cell = point_cell(endpoint)?;
    let mut best = None;
    for dx in -1..=1 {
        for dy in -1..=1 {
            for dz in -1..=1 {
                let (Some(x), Some(y), Some(z)) = (
                    cell[0].checked_add(dx),
                    cell[1].checked_add(dy),
                    cell[2].checked_add(dz),
                ) else {
                    continue;
                };
                let neighbor = [x, y, z];
                for &point_index in index.get(&neighbor).into_iter().flatten() {
                    if distance_squared(coordinates(points[point_index]), endpoint)
                        <= POINT_TOLERANCE * POINT_TOLERANCE
                    {
                        best = Some(
                            best.map_or(point_index, |previous: usize| previous.min(point_index)),
                        );
                    }
                }
            }
        }
    }
    best
}

fn distance_squared(left: [f64; 3], right: [f64; 3]) -> f64 {
    (left[0] - right[0]).powi(2) + (left[1] - right[1]).powi(2) + (left[2] - right[2]).powi(2)
}

/// Admit two directions whose squared lengths are one and whose dot product
/// is zero, each within `1e-12`.
fn unit_and_orthogonal_directions(
    first: [f64; 3],
    second: [f64; 3],
) -> Option<[ExactUnitVector3; 2]> {
    let dot = first
        .iter()
        .zip(second)
        .map(|(left, right)| left * right)
        .sum::<f64>();
    let directions = [
        ExactUnitVector3::new(first)?,
        ExactUnitVector3::new(second)?,
    ];
    (dot.abs() <= EPS_B5_GRAPH_EXACT_GEOMETRY).then_some(directions)
}

/// Admit a `b5 03 2b` or `2d` frame: the two transverse directions are unit
/// length, perpendicular, and `direction_x × direction_y` lies within `1e-12`
/// of the axis. The frame holds the stored axis and `direction_x`; the
/// admitted `direction_y` is returned beside it.
fn right_handed_frame(
    axis: [f64; 3],
    direction_x: [f64; 3],
    direction_y: [f64; 3],
) -> Option<(OrthonormalFrame3, ExactUnitVector3)> {
    let direction_y = ExactUnitVector3::new(direction_y)?;
    let frame = OrthonormalFrame3::right_handed_euclidean_1e12(
        UnitVector3::new(Vector3::from(axis))?,
        ExactUnitVector3::new(direction_x)?.into(),
        direction_y.into(),
    )?;
    Some((frame, direction_y))
}

/// Admit a `b5 03 27` or `28` frame: the two stored directions are unit
/// length and perpendicular. The frame holds the unit normal of
/// `first × second` and the stored `first` direction.
fn completed_frame(first: [f64; 3], second: ExactUnitVector3) -> Option<OrthonormalFrame3> {
    OrthonormalFrame3::completing_by_largest_component(
        ExactUnitVector3::new(first)?.into(),
        second.into(),
    )
}

/// Admit a `b5 03 29` cone frame: the directions are unit length, the two
/// transverse directions are perpendicular, and `direction_x × direction_y`
/// lies within `2e-12` of the axis or of its reverse. The frame holds the
/// stored axis and `direction_x`.
fn cone_frame(
    axis: [f64; 3],
    direction_x: [f64; 3],
    direction_y: [f64; 3],
) -> Option<(OrthonormalFrame3, UnitVector3)> {
    let axis = UnitVector3::new(Vector3::from(axis))?;
    let direction_x = ExactUnitVector3::new(direction_x)?.into();
    let direction_y = ExactUnitVector3::new(direction_y)?.into();
    let frame = OrthonormalFrame3::right_handed_euclidean(axis, direction_x, direction_y).or_else(
        || {
            let mut frame = OrthonormalFrame3::right_handed_euclidean(
                axis.reversed(),
                direction_x,
                direction_y,
            )?;
            frame.reverse_axis();
            Some(frame)
        },
    )?;
    Some((frame, direction_y))
}

fn parse_surface(record: &B5Record) -> Option<B5Surface> {
    (record.family == 0xb5).then_some(())?;
    match record.class {
        0x27 => {
            (record.payload.len() == b5_plane_payload::LEN
                && record.payload.get(b5_plane_payload::LEAD) == Some(&0x80))
            .then_some(())?;
            let direction_u = read_f64_array::<3>(&record.payload, b5_plane_payload::DIRECTION_U)?
                .map(FiniteReal::get);
            let direction_v = ExactUnitVector3::new(
                read_f64_array::<3>(&record.payload, b5_plane_payload::DIRECTION_V)?
                    .map(FiniteReal::get),
            )?;
            let u_range = IncreasingParameterInterval::new([
                f64_le(&record.payload, b5_plane_payload::U_RANGE)?.get(),
                f64_le(&record.payload, b5_plane_payload::U_RANGE + 8)?.get(),
            ])?;
            let v_range = IncreasingParameterInterval::new([
                f64_le(&record.payload, b5_plane_payload::V_RANGE)?.get(),
                f64_le(&record.payload, b5_plane_payload::V_RANGE + 8)?.get(),
            ])?;
            let frame = completed_frame(direction_u, direction_v)?;
            (f64_le(&record.payload, b5_plane_payload::FIXED_VALUES)?.get() == 1.0
                && f64_le(&record.payload, b5_plane_payload::FIXED_VALUES + 8)?.get() == 1.0)
                .then_some(B5Surface::Plane {
                    origin: f64_point(&record.payload, b5_plane_payload::ORIGIN)?,
                    frame,
                    direction_v,
                    u_range,
                    v_range,
                })
        }
        0x28 => {
            (record.payload.len() == b5_cylinder_payload::LEN
                && record.payload.get(b5_cylinder_payload::LEAD) == Some(&0x80))
            .then_some(())?;
            let stored_u = read_f64_array::<3>(&record.payload, b5_cylinder_payload::REFERENCE_X)?
                .map(FiniteReal::get);
            let stored_v = read_f64_array::<3>(&record.payload, b5_cylinder_payload::STORED_V)?
                .map(FiniteReal::get);
            let radius = f64_le(&record.payload, b5_cylinder_payload::RADIUS)?.get();
            let u_range = [
                f64_le(&record.payload, b5_cylinder_payload::U_RANGE)?.get(),
                f64_le(&record.payload, b5_cylinder_payload::U_RANGE + 8)?.get(),
            ];
            let v_range = IncreasingParameterInterval::new([
                f64_le(&record.payload, b5_cylinder_payload::V_RANGE)?.get(),
                f64_le(&record.payload, b5_cylinder_payload::V_RANGE + 8)?.get(),
            ])?;
            let angular_factor =
                f64_le(&record.payload, b5_cylinder_payload::ANGULAR_FACTOR)?.get();
            let chart_origin = f64_le(&record.payload, b5_cylinder_payload::CHART_ORIGIN)?;
            let angular_scale = FiniteReal::new(radius / angular_factor)?;
            let chart_domain = [
                chart_origin.get(),
                chart_origin.get() + std::f64::consts::TAU * angular_scale.get(),
            ];
            chart_domain[1].is_finite().then_some(())?;
            let chart_tolerance = EPS_B5_GRAPH_EXACT_GEOMETRY
                * u_range
                    .into_iter()
                    .chain(chart_domain)
                    .chain([angular_scale.get()])
                    .map(f64::abs)
                    .fold(1.0, f64::max);
            let admitted_radius = PositiveLength::new(radius)?;
            let frame = completed_frame(stored_u, ExactUnitVector3::new(stored_v)?)?;
            (angular_factor > 0.0
                && f64_le(&record.payload, b5_cylinder_payload::ONE)?.get() == 1.0
                && u_range[0] >= chart_domain[0] - chart_tolerance
                && u_range[1] <= chart_domain[1] + chart_tolerance)
                .then_some(())?;
            let u_range = IncreasingParameterInterval::new(u_range)?;
            Some(B5Surface::Cylinder {
                origin: f64_point(&record.payload, b5_cylinder_payload::ORIGIN)?,
                frame,
                radius: admitted_radius,
                u_range,
                v_range,
                angular_scale,
                chart_origin,
            })
        }
        0x29 => {
            (record.payload.len() == b5_cone_payload::LEN
                && record.payload.get(b5_cone_payload::LEAD) == Some(&0x80))
            .then_some(())?;
            let chart_origin = f64_point(&record.payload, b5_cone_payload::ORIGIN)?;
            let direction_x = read_f64_array::<3>(&record.payload, b5_cone_payload::DIRECTION_X)?
                .map(FiniteReal::get);
            let direction_y = read_f64_array::<3>(&record.payload, b5_cone_payload::DIRECTION_Y)?
                .map(FiniteReal::get);
            let axis =
                read_f64_array::<3>(&record.payload, b5_cone_payload::AXIS)?.map(FiniteReal::get);
            let radial_angle = f64_le(&record.payload, b5_cone_payload::RADIAL_ANGLE)?;
            let reference_radius = f64_le(&record.payload, b5_cone_payload::REFERENCE_RADIUS)?;
            let angular_range = [
                f64_le(&record.payload, b5_cone_payload::ANGULAR_RANGE)?.get(),
                f64_le(&record.payload, b5_cone_payload::ANGULAR_RANGE + 8)?.get(),
            ];
            let mut slant_range = [
                f64_le(&record.payload, b5_cone_payload::SLANT_RANGE)?.get(),
                f64_le(&record.payload, b5_cone_payload::SLANT_RANGE + 8)?.get(),
            ];
            if slant_range[0].abs() <= EPS_B5_GRAPH_EXACT_GEOMETRY {
                slant_range[0] = 0.0;
            }
            let angular_scale =
                PositiveReal::new(f64_le(&record.payload, b5_cone_payload::ANGULAR_SCALE)?.get())?;
            let angular_domain = [
                f64_le(&record.payload, b5_cone_payload::ANGULAR_DOMAIN)?.get(),
                f64_le(&record.payload, b5_cone_payload::ANGULAR_DOMAIN + 8)?.get(),
            ];
            let slant_shift = f64_le(&record.payload, b5_cone_payload::PARAMETER_SHIFT)?;
            let (frame, direction_y) = cone_frame(axis, direction_x, direction_y)?;
            let positive_radial_angle = PositiveAngle::new(radial_angle.get())?;
            (radial_angle.get() < std::f64::consts::FRAC_PI_2
                && periodic_angular_range_is_valid(angular_range, angular_domain)
                && f64_le(&record.payload, b5_cone_payload::PARAMETER_SCALE)?.get() == 1.0)
                .then_some(())?;
            // The angular check admits a strictly increasing range inside a
            // strictly increasing full-turn domain.
            let angular_range = IncreasingParameterInterval::new(angular_range)?;
            let angular_domain = IncreasingParameterInterval::new(angular_domain)?;
            let slant_range = IncreasingParameterInterval::new(slant_range)?;
            let origin = add(
                coordinates(chart_origin),
                scale(axis, slant_range.lower() * radial_angle.get().sin()),
            );
            let radius = NonNegativeLength::new(
                reference_radius.get() + slant_range.lower() * radial_angle.get().cos(),
            );
            let half_angle = Angle::from_assigned_real(FiniteReal::new(
                std::f64::consts::FRAC_PI_2 - radial_angle.get(),
            )?);
            Some(B5Surface::Cone {
                origin: chart_origin,
                frame,
                direction_y,
                radial_angle: positive_radial_angle,
                reference_radius,
                angular_range,
                slant_range,
                slant_shift,
                angular_scale,
                angular_domain,
                surface: FinitePoint3::new(Point3::from(origin)).zip(radius).map(
                    |(origin, radius)| {
                        ConeSurface::new(origin, frame, radius, PositiveReal::ONE, half_angle)
                    },
                ),
            })
        }
        0x2a => {
            (record.payload.len() == b5_sphere_payload::LEN
                && record.payload.get(b5_sphere_payload::LEAD) == Some(&0x80))
            .then_some(())?;
            let center = f64_point(&record.payload, b5_sphere_payload::CENTER)?;
            let stored_x = read_f64_array::<3>(&record.payload, b5_sphere_payload::SCALED_X)?
                .map(FiniteReal::get);
            let stored_y = read_f64_array::<3>(&record.payload, b5_sphere_payload::SCALED_Y)?
                .map(FiniteReal::get);
            let stored_axis = read_f64_array::<3>(&record.payload, b5_sphere_payload::SCALED_AXIS)?
                .map(FiniteReal::get);
            let radius = f64_le(&record.payload, b5_sphere_payload::RADIUS)?.get();
            let azimuth_range =
                read_f64_array::<2>(&record.payload, b5_sphere_payload::AZIMUTH_RANGE)?
                    .map(FiniteReal::get);
            let latitude_range =
                read_f64_array::<2>(&record.payload, b5_sphere_payload::LATITUDE_RANGE)?
                    .map(FiniteReal::get);
            let construction_radius =
                f64_le(&record.payload, b5_sphere_payload::CONSTRUCTION_RADIUS)?.get();
            let chart_origin = f64_le(&record.payload, b5_sphere_payload::CHART_ORIGIN)?;
            let vector_length = |value: [f64; 3]| value[0].hypot(value[1]).hypot(value[2]);
            let direction_x =
                UnitVector3::normalized_by_largest_component(Vector3::from(stored_x))?;
            let direction_y =
                UnitVector3::normalized_by_largest_component(Vector3::from(stored_y))?;
            let axis = UnitVector3::normalized_by_largest_component(Vector3::from(stored_axis))?;
            let expected_chart_angle =
                (azimuth_range[0] + azimuth_range[1]) * 0.5 - std::f64::consts::PI;
            let expected_chart_origin = construction_radius * expected_chart_angle;
            let chart_origin_tolerance = 2.0
                * f64::EPSILON
                * chart_origin
                    .get()
                    .abs()
                    .max(expected_chart_origin.abs())
                    .max(1.0);
            let admitted_radius = PositiveLength::new(radius)?;
            let frame =
                OrthonormalFrame3::right_handed_euclidean_1e12(axis, direction_x, direction_y)?;
            let admitted_construction_radius = PositiveLength::new(construction_radius)?;
            (sphere_angular_ranges_are_valid(azimuth_range, latitude_range)
                && expected_chart_origin.is_finite()
                && (chart_origin.get() - expected_chart_origin).abs() <= chart_origin_tolerance
                && [stored_x, stored_y, stored_axis].iter().all(|direction| {
                    ((vector_length(*direction) / radius) - 1.0).abs()
                        <= EPS_B5_GRAPH_EXACT_GEOMETRY
                }))
            .then_some(())?;
            // The sphere chart check admits strictly increasing azimuth and
            // latitude ranges.
            Some(B5Surface::Sphere {
                center,
                frame,
                direction_y,
                radius: admitted_radius,
                azimuth_range: IncreasingParameterInterval::new(azimuth_range)?,
                latitude_range: IncreasingParameterInterval::new(latitude_range)?,
                construction_radius: admitted_construction_radius,
                chart_origin,
            })
        }
        0x2b => {
            (record.payload.len() == b5_torus_payload::LEN
                && record.payload.get(b5_torus_payload::LEAD) == Some(&0x80)
                && record
                    .payload
                    .get(b5_torus_payload::RESERVED..b5_torus_payload::LEN)
                    == Some(&[0; 8]))
            .then_some(())?;
            let direction_x = read_f64_array::<3>(&record.payload, b5_torus_payload::DIRECTION_X)?
                .map(FiniteReal::get);
            let direction_y = read_f64_array::<3>(&record.payload, b5_torus_payload::DIRECTION_Y)?
                .map(FiniteReal::get);
            let axis =
                read_f64_array::<3>(&record.payload, b5_torus_payload::AXIS)?.map(FiniteReal::get);
            let major_radius = f64_le(&record.payload, b5_torus_payload::MAJOR_RADIUS)?.get();
            let minor_radius = f64_le(&record.payload, b5_torus_payload::MINOR_RADIUS)?.get();
            let major_angular_range = [
                f64_le(&record.payload, b5_torus_payload::MAJOR_RANGE)?.get(),
                f64_le(&record.payload, b5_torus_payload::MAJOR_RANGE + 8)?.get(),
            ];
            let major_angular_domain = [
                f64_le(&record.payload, b5_torus_payload::MAJOR_DOMAIN)?.get(),
                f64_le(&record.payload, b5_torus_payload::MAJOR_DOMAIN + 8)?.get(),
            ];
            let minor_angular_range = [
                f64_le(&record.payload, b5_torus_payload::MINOR_RANGE)?.get(),
                f64_le(&record.payload, b5_torus_payload::MINOR_RANGE + 8)?.get(),
            ];
            let minor_angular_domain = [
                f64_le(&record.payload, b5_torus_payload::MINOR_DOMAIN)?.get(),
                f64_le(&record.payload, b5_torus_payload::MINOR_DOMAIN + 8)?.get(),
            ];
            let major_scale =
                PositiveReal::new(f64_le(&record.payload, b5_torus_payload::MAJOR_SCALE)?.get())?;
            let minor_scale =
                PositiveReal::new(f64_le(&record.payload, b5_torus_payload::MINOR_SCALE)?.get())?;
            let (frame, direction_y) = right_handed_frame(axis, direction_x, direction_y)?;
            let admitted_major_radius = PositiveLength::new(major_radius)?;
            let admitted_minor_radius = PositiveLength::new(minor_radius)?;
            (periodic_angular_range_is_valid(major_angular_range, major_angular_domain)
                && periodic_angular_range_is_valid(minor_angular_range, minor_angular_domain))
            .then_some(())?;
            // Each angular check admits a strictly increasing range inside a
            // strictly increasing full-turn domain.
            Some(B5Surface::Torus {
                center: f64_point(&record.payload, b5_torus_payload::CENTER)?,
                frame,
                direction_y,
                major_radius: admitted_major_radius,
                minor_radius: admitted_minor_radius,
                major_angular_range: IncreasingParameterInterval::new(major_angular_range)?,
                major_angular_domain: IncreasingParameterInterval::new(major_angular_domain)?,
                minor_angular_range: IncreasingParameterInterval::new(minor_angular_range)?,
                minor_angular_domain: IncreasingParameterInterval::new(minor_angular_domain)?,
                major_scale,
                minor_scale,
            })
        }
        0x2d => {
            let mut position = 1;
            let profile_curve = wire::tokens::object_ref(&record.payload, &mut position, true)?;
            (record.payload.len() == position.checked_add(b5_revolution_carrier_tail::LEN)?
                && record.payload.first() == Some(&0x81))
            .then_some(())?;
            let angular_range = [
                f64_le(
                    &record.payload,
                    position.checked_add(b5_revolution_carrier_tail::ANGULAR_RANGE)?,
                )?
                .get(),
                f64_le(
                    &record.payload,
                    position.checked_add(
                        b5_revolution_carrier_tail::ANGULAR_RANGE + std::mem::size_of::<f64>(),
                    )?,
                )?
                .get(),
            ];
            let profile_range = [
                f64_le(
                    &record.payload,
                    position.checked_add(b5_revolution_carrier_tail::PROFILE_RANGE)?,
                )?
                .get(),
                f64_le(
                    &record.payload,
                    position.checked_add(
                        b5_revolution_carrier_tail::PROFILE_RANGE + std::mem::size_of::<f64>(),
                    )?,
                )?
                .get(),
            ];
            let angular_scale = PositiveReal::new(
                f64_le(
                    &record.payload,
                    position.checked_add(b5_revolution_carrier_tail::ANGULAR_SCALE)?,
                )?
                .get(),
            )?;
            let angular_half_turn = f64_le(
                &record.payload,
                position.checked_add(b5_revolution_carrier_tail::HALF_TURN)?,
            )?
            .get();
            let reference_x = read_f64_array::<3>(
                &record.payload,
                position.checked_add(b5_revolution_carrier_tail::REFERENCE_X)?,
            )?
            .map(FiniteReal::get);
            let reference_y = read_f64_array::<3>(
                &record.payload,
                position.checked_add(b5_revolution_carrier_tail::REFERENCE_Y)?,
            )?
            .map(FiniteReal::get);
            let axis_direction = read_f64_array::<3>(
                &record.payload,
                position.checked_add(b5_revolution_carrier_tail::AXIS)?,
            )?
            .map(FiniteReal::get);
            (record.payload.get(
                position + b5_revolution_carrier_tail::CONTROLS
                    ..position + b5_revolution_carrier_tail::ANGULAR_SCALE,
            ) == Some(&[0x05, 0x05]))
            .then_some(())?;
            let (frame, _) = right_handed_frame(axis_direction, reference_x, reference_y)?;
            let angular_range = IncreasingParameterInterval::new(angular_range)?;
            let profile_range = IncreasingParameterInterval::new(profile_range)?;
            (angular_range.lower() >= 0.0
                && angular_range.upper() <= 2.0 * angular_half_turn
                && f64_le(&record.payload, position + b5_revolution_carrier_tail::ONE0)?.get()
                    == 1.0
                && f64_le(&record.payload, position + b5_revolution_carrier_tail::ONE1)?.get()
                    == 1.0
                && f64_le(&record.payload, position + b5_revolution_carrier_tail::ZERO)?.get()
                    == 0.0
                && record
                    .payload
                    .get(position + b5_revolution_carrier_tail::TERMINAL)
                    == Some(&0x01)
                && angular_half_turn.to_bits()
                    == (std::f64::consts::PI * angular_scale.get()).to_bits())
            .then_some(B5Surface::Revolution {
                profile_curve,
                axis_origin: f64_point(&record.payload, position)?,
                axis_direction: *frame.axis(),
                profile_range,
                angular_range,
                angular_scale,
            })
        }
        _ => None,
    }
}

fn surface_node(
    record: &B5Record,
    header: Option<&crate::families::a5a8::records::A8SurfaceHeader>,
) -> Option<B5Surface> {
    if let Some(surface) = parse_surface(record) {
        return Some(surface);
    }
    if record.family != 0xa8 || record.class != 0x34 {
        return None;
    }
    let payload = record.payload.clone();
    Some(match header {
        Some(header) => B5Surface::UnresolvedNurbs {
            header: header.clone(),
            payload,
        },
        None => B5Surface::Unknown {
            family: record.family,
            class: record.class,
            payload,
        },
    })
}

fn surface_alias_target(record: &B5Record) -> Option<u32> {
    (record.family == 0xb5 && matches!(record.class, 0x2e | 0x38)).then_some(())?;
    let mut position = 0;
    if record.payload.first() == Some(&0x81) {
        position += 1;
    }
    let target = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    if record.class == 0x38 {
        (record.payload.get(position..) == Some(&[0x05, 0x05, 0x09])).then_some(())?;
        position += 3;
    }
    (position == record.payload.len()).then_some(target)
}

fn parse_offset_surface_fields(record: &B5Record) -> Option<B5OffsetSurface> {
    (record.family == 0xb5 && record.class == 0x30 && record.payload.first() == Some(&0x82))
        .then_some(())?;
    let mut position = 1;
    let carrier_surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let source_surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let distance = f64_le(&record.payload, position)?;
    position += 8;
    let carrier_kind = B5OffsetCarrierKind::from_byte(*record.payload.get(position)?)?;
    position += 1;
    let [u0, u1, v0, v1] = read_f64_array::<4>(&record.payload, position)?.map(FiniteReal::get);
    position += 32;
    (position == record.payload.len()).then_some(())?;
    Some(B5OffsetSurface {
        object_id: record.object_id,
        carrier_surface,
        source_surface,
        distance,
        carrier_kind,
        parameter_bounds: [
            IncreasingParameterInterval::new([u0, u1])?,
            IncreasingParameterInterval::new([v0, v1])?,
        ],
    })
}

fn parse_offset_surface(
    record: &B5Record,
    surfaces: &BTreeMap<u32, B5Surface>,
    extrusion_surfaces: &BTreeMap<u32, B5ExtrusionSurface>,
    records: &HashMap<u32, &B5Record>,
) -> Option<B5OffsetSurface> {
    let fields = parse_offset_surface_fields(record)?;
    let B5OffsetSurface {
        carrier_surface,
        source_surface,
        distance,
        carrier_kind,
        parameter_bounds: [u_bounds, v_bounds],
        ..
    } = fields;
    if carrier_kind == B5OffsetCarrierKind::Extrusion {
        if let (Some(source), Some(carrier)) = (
            extrusion_surfaces.get(&source_surface),
            extrusion_surfaces.get(&carrier_surface),
        ) {
            return extrusion_offset_construction_agrees(
                source,
                carrier,
                distance,
                [u_bounds, v_bounds],
            )
            .then_some(fields);
        }
    }
    let expected_kind = match surfaces.get(&carrier_surface) {
        Some(carrier @ B5Surface::Cone { .. }) => cone_offset_construction_agrees(
            surfaces.get(&source_surface)?,
            carrier,
            distance.get(),
            [u_bounds, v_bounds],
        )
        .then_some(B5OffsetCarrierKind::Cone)?,
        Some(carrier @ B5Surface::Plane { .. }) => analytic_offset_magnitude_agrees(
            carrier,
            surfaces.get(&source_surface)?,
            distance.get(),
        )
        .then_some(B5OffsetCarrierKind::Plane)?,
        Some(carrier @ B5Surface::Cylinder { .. }) => analytic_offset_magnitude_agrees(
            carrier,
            surfaces.get(&source_surface)?,
            distance.get(),
        )
        .then_some(B5OffsetCarrierKind::Cylinder)?,
        Some(carrier @ B5Surface::Sphere { .. }) => analytic_offset_magnitude_agrees(
            carrier,
            surfaces.get(&source_surface)?,
            distance.get(),
        )
        .then_some(B5OffsetCarrierKind::Sphere)?,
        Some(carrier @ B5Surface::Torus { .. }) => analytic_offset_magnitude_agrees(
            carrier,
            surfaces.get(&source_surface)?,
            distance.get(),
        )
        .then_some(B5OffsetCarrierKind::Torus)?,
        Some(B5Surface::RollingBall { .. }) => B5OffsetCarrierKind::RollingBall,
        Some(B5Surface::Unknown {
            family: 0xb5,
            class: 0x2c,
            ..
        }) => return None,
        Some(_) => return None,
        None => {
            if let (Some(source), Some(carrier)) = (
                extrusion_surfaces.get(&source_surface),
                records
                    .get(&carrier_surface)
                    .and_then(|record| extrusion_carrier(record)),
            ) {
                if carrier.direction != source.direction
                    || carrier.u_bounds != v_bounds
                    || !matches!(carrier.chart, B5ExtrusionChart::Direct { bounds, .. } if bounds == u_bounds)
                {
                    return None;
                }
                return (carrier_kind == B5OffsetCarrierKind::Extrusion).then_some(fields);
            }
            let cache = parse_offset_cache(records.get(&carrier_surface)?)?;
            let source = surfaces.get(&source_surface)?;
            let cached_source = surfaces.get(&cache.source_surface)?;
            let [u0, u1] = u_bounds.endpoints();
            let [v0, v1] = v_bounds.endpoints();
            if source != cached_source
                || distance.get().to_bits() != cache.distance.get().to_bits()
                || [u0, v0, u1, v1]
                    .into_iter()
                    .zip(cache.interleaved_bounds)
                    .any(|(left, right)| left.to_bits() != right.get().to_bits())
            {
                return None;
            }
            B5OffsetCarrierKind::Cache
        }
    };
    (carrier_kind == expected_kind).then_some(fields)
}

fn cone_offset_construction_agrees(
    source: &B5Surface,
    carrier: &B5Surface,
    distance: f64,
    [u_bounds, v_bounds]: [IncreasingParameterInterval; 2],
) -> bool {
    let (
        B5Surface::Cone {
            origin: source_origin,
            frame: source_frame,
            direction_y: source_y,
            radial_angle: source_angle,
            reference_radius: source_radius,
            angular_scale: source_scale,
            slant_shift: source_shift,
            surface: Some(_),
            ..
        },
        B5Surface::Cone {
            origin,
            frame,
            direction_y,
            radial_angle,
            reference_radius,
            angular_scale,
            angular_range,
            slant_range,
            slant_shift,
            surface: Some(_),
            ..
        },
    ) = (source, carrier)
    else {
        return false;
    };
    if frame != source_frame
        || direction_y != source_y
        || radial_angle != source_angle
        || angular_scale != source_scale
    {
        return false;
    }
    let source_origin = coordinates(*source_origin);
    let origin = coordinates(*origin);
    let delta = std::array::from_fn::<_, 3, _>(|i| origin[i] - source_origin[i]);
    let axis = components(frame.axis());
    let axial = delta.into_iter().zip(axis).map(|(x, a)| x * a).sum::<f64>();
    let radial = reference_radius.get() - source_radius.get();
    let (sin, cos) = radial_angle.get().sin_cos();
    let handedness = cross(components(frame.reference()), components(direction_y))
        .into_iter()
        .zip(axis)
        .map(|(x, a)| x * a)
        .sum::<f64>()
        .signum();
    let translation = axial * sin + radial * cos;
    let measured = handedness * (radial * sin - axial * cos);
    let transverse = std::array::from_fn::<_, 3, _>(|i| delta[i] - axial * axis[i]);
    let transverse_length = transverse[0].hypot(transverse[1]).hypot(transverse[2]);
    let length_scale = axial.abs().max(radial.abs()).max(distance.abs());
    let arithmetic_tolerance = 4.0 * f64::EPSILON * length_scale;
    let transverse_tolerance = EPS_B5_GRAPH_DEGENERATE * length_scale;
    let distance_tolerance =
        EPS_B5_GRAPH_DEGENERATE * measured.abs().max(distance.abs()) + arithmetic_tolerance;
    let shift = slant_shift.get() - source_shift.get();
    let shift_tolerance =
        EPS_B5_GRAPH_DEGENERATE * translation.abs().max(shift.abs()) + arithmetic_tolerance;
    if ![
        translation,
        measured,
        transverse_length,
        distance_tolerance,
        shift_tolerance,
    ]
    .into_iter()
    .all(f64::is_finite)
        || transverse_length > transverse_tolerance
        || (measured - distance).abs() > distance_tolerance
        || (shift - translation).abs() > shift_tolerance
    {
        return false;
    }
    let [u0, u1] = u_bounds.endpoints().map(|u| u / angular_scale.get());
    u0 >= angular_range.lower() - EPS_B5_GRAPH_GEOMETRY
        && u1 <= angular_range.upper() + EPS_B5_GRAPH_GEOMETRY
        && slant_range
            .endpoints()
            .into_iter()
            .zip(v_bounds.endpoints())
            .all(|(local, native)| {
                let tolerance = EPS_B5_GRAPH_DEGENERATE
                    * local.abs().max(native.abs()).max(slant_shift.get().abs());
                (local - (native - slant_shift.get())).abs() <= tolerance
            })
}

fn extrusion_offset_construction_agrees(
    source: &B5ExtrusionSurface,
    carrier: &B5ExtrusionSurface,
    distance: FiniteReal,
    [u_bounds, v_bounds]: [IncreasingParameterInterval; 2],
) -> bool {
    if carrier.direction != source.direction {
        return false;
    }
    let B5ExtrusionDirectrix::Offset {
        source: offset_source,
        source_parameter_range,
        distance: curve_distance,
        direction,
        parameter_range,
        ..
    } = &carrier.directrix
    else {
        return carrier.parameter_bounds == [v_bounds, u_bounds];
    };
    offset_source.object_id() == source.directrix.object_id()
        && source_parameter_range
            .endpoints()
            .into_iter()
            .zip(offset_source.parameter_range().endpoints())
            .all(|(left, right)| left.to_bits() == right.to_bits())
        && curve_distance.get().to_bits() == distance.get().to_bits()
        && *direction == source.direction
        && carrier.parameter_bounds[0]
            .endpoints()
            .into_iter()
            .zip(v_bounds.endpoints())
            .all(|(left, right)| left.to_bits() == right.to_bits())
        && parameter_range
            .endpoints()
            .into_iter()
            .zip(u_bounds.endpoints())
            .all(|(left, right)| left.to_bits() == right.to_bits())
}

fn analytic_offset_magnitude_agrees(
    carrier: &B5Surface,
    source: &B5Surface,
    distance: f64,
) -> bool {
    const RELATIVE_TOLERANCE: f64 = EPS_B5_GRAPH_DEGENERATE;
    let relative_close = |left: f64, right: f64| {
        (left - right).abs() <= RELATIVE_TOLERANCE * left.abs().max(right.abs())
    };
    let dot = |left: [f64; 3], right: [f64; 3]| {
        left.into_iter().zip(right).map(|(a, b)| a * b).sum::<f64>()
    };
    let difference = |left: [f64; 3], right: [f64; 3]| {
        [left[0] - right[0], left[1] - right[1], left[2] - right[2]]
    };
    let length = |value: [f64; 3]| value[0].hypot(value[1]).hypot(value[2]);
    let parallel = |left: [f64; 3], right: [f64; 3]| relative_close(dot(left, right).abs(), 1.0);
    let projected_distance_close = |measured: f64, expected: f64, delta_length: f64| {
        (measured - expected).abs()
            <= RELATIVE_TOLERANCE * measured.abs().max(expected.abs())
                + 4.0 * f64::EPSILON * delta_length
    };
    let collinear = |delta: [f64; 3], axis: [f64; 3]| {
        let delta_length = length(delta);
        if delta_length == 0.0 {
            return true;
        }
        let axial_distance = dot(delta, axis);
        let transverse = [
            delta[0] - axial_distance * axis[0],
            delta[1] - axial_distance * axis[1],
            delta[2] - axial_distance * axis[2],
        ];
        length(transverse) <= RELATIVE_TOLERANCE * delta_length
    };
    let same_point = |left: [f64; 3], right: [f64; 3], geometric_scale: f64| {
        length(difference(left, right)) <= RELATIVE_TOLERANCE * geometric_scale
    };
    match (carrier, source) {
        (
            B5Surface::Plane {
                origin: carrier_origin,
                frame: carrier_frame,
                ..
            },
            B5Surface::Plane {
                origin: source_origin,
                frame: source_frame,
                ..
            },
        ) => {
            let source_normal = components(source_frame.axis());
            let delta = difference(coordinates(*carrier_origin), coordinates(*source_origin));
            parallel(components(carrier_frame.axis()), source_normal)
                && projected_distance_close(
                    dot(delta, source_normal).abs(),
                    distance.abs(),
                    length(delta),
                )
        }
        (
            B5Surface::Cylinder {
                origin: carrier_origin,
                frame: carrier_frame,
                radius: carrier_radius,
                ..
            },
            B5Surface::Cylinder {
                origin: source_origin,
                frame: source_frame,
                radius: source_radius,
                ..
            },
        ) => {
            let source_axis = components(source_frame.axis());
            let delta = difference(coordinates(*carrier_origin), coordinates(*source_origin));
            parallel(components(carrier_frame.axis()), source_axis)
                && collinear(delta, source_axis)
                && relative_close(
                    (carrier_radius.get() - source_radius.get()).abs(),
                    distance.abs(),
                )
        }
        (
            B5Surface::Sphere {
                center: carrier_center,
                radius: carrier_radius,
                ..
            },
            B5Surface::Sphere {
                center: source_center,
                radius: source_radius,
                ..
            },
        ) => {
            let (carrier_radius, source_radius) = (carrier_radius.get(), source_radius.get());
            let geometric_scale = carrier_radius
                .abs()
                .max(source_radius.abs())
                .max(distance.abs());
            same_point(
                coordinates(*carrier_center),
                coordinates(*source_center),
                geometric_scale,
            ) && relative_close((carrier_radius - source_radius).abs(), distance.abs())
        }
        (
            B5Surface::Torus {
                center: carrier_center,
                frame: carrier_frame,
                major_radius: carrier_major,
                minor_radius: carrier_minor,
                ..
            },
            B5Surface::Torus {
                center: source_center,
                frame: source_frame,
                major_radius: source_major,
                minor_radius: source_minor,
                ..
            },
        ) => {
            let (carrier_major, source_major) = (carrier_major.get(), source_major.get());
            let (carrier_minor, source_minor) = (carrier_minor.get(), source_minor.get());
            let geometric_scale = carrier_major
                .abs()
                .max(source_major.abs())
                .max(carrier_minor.abs())
                .max(source_minor.abs())
                .max(distance.abs());
            same_point(
                coordinates(*carrier_center),
                coordinates(*source_center),
                geometric_scale,
            ) && parallel(
                components(carrier_frame.axis()),
                components(source_frame.axis()),
            ) && relative_close(carrier_major, source_major)
                && relative_close((carrier_minor - source_minor).abs(), distance.abs())
        }
        _ => false,
    }
}

struct B5OffsetCache {
    source_surface: u32,
    distance: FiniteReal,
    interleaved_bounds: [FiniteReal; 4],
}

struct B5ObjectStreamPcurve {
    class: u8,
    surface: u32,
    parameter_range: [FiniteReal; 2],
    class_21_suffix_scalar: Option<PositiveReal>,
    distinct_knots: Vec<FiniteReal>,
}

fn parse_offset_cache(record: &B5Record) -> Option<B5OffsetCache> {
    (record.family == 0xb5 && record.class == 0x31 && record.payload.first() == Some(&0x81))
        .then_some(())?;
    let mut position = 1;
    let source_surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let [distance, u0, v0, u1, v1] = read_f64_array::<5>(&record.payload, position)?;
    position += 40;
    (position == record.payload.len() && u0 < u1 && v0 < v1).then_some(B5OffsetCache {
        source_surface,
        distance,
        interleaved_bounds: [u0, v0, u1, v1],
    })
}

#[cfg(test)]
fn parse_extrusion_surface(
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<B5ExtrusionSurface> {
    crate::test_support::with_service_context(|ctx| {
        parse_extrusion_surface_with_context(
            ctx,
            record,
            records,
            object_stream_pcurves,
            &[],
            &BTreeMap::new(),
        )
    })
    .expect("parse extrusion surface")
}

fn parse_extrusion_surface_with_context(
    ctx: &DecodeContext<'_>,
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
    offset_constructions: &[B5OffsetSurface],
    extrusion_surfaces: &BTreeMap<u32, B5ExtrusionSurface>,
) -> Result<Option<B5ExtrusionSurface>, CodecError> {
    let Some(carrier) = extrusion_carrier(record) else {
        return Ok(None);
    };
    let (active_bounds, controls) = match carrier.chart {
        B5ExtrusionChart::Direct { bounds, controls } => (bounds, controls),
        B5ExtrusionChart::OffsetLimits { .. } => {
            let Some(directrix_record) = records.get(&carrier.directrix_id) else {
                return Ok(None);
            };
            let Some(directrix) =
                parse_extrusion_directrix(ctx, directrix_record, records, object_stream_pcurves)?
            else {
                return Ok(None);
            };
            let B5ExtrusionDirectrix::Offset { source, .. } = &directrix else {
                return Ok(None);
            };
            if !records
                .get(&source.object_id())
                .is_some_and(|record| record.family == 0xb5 && record.class == 0x24)
            {
                return Ok(None);
            }
            let Some(parameter_bounds) = contextual_offset_extrusion_bounds(
                record.object_id,
                &carrier,
                &directrix,
                offset_constructions,
                extrusion_surfaces,
                object_stream_pcurves,
            ) else {
                return Ok(None);
            };
            return Ok(Some(B5ExtrusionSurface {
                object_id: record.object_id,
                direction: carrier.direction,
                parameter_bounds,
                directrix,
            }));
        }
    };
    let active = active_bounds.endpoints();
    let terminal_span_chart = matches!(controls, [0x05, 0x15 | 0x19]);
    let directrix = if terminal_span_chart {
        terminal_span_directrix(
            carrier.directrix_id,
            active_bounds,
            controls,
            object_stream_pcurves,
        )
    } else {
        let Some(directrix_record) = records.get(&carrier.directrix_id) else {
            return Ok(None);
        };
        parse_extrusion_directrix(ctx, directrix_record, records, object_stream_pcurves)?
    };
    let Some(mut directrix) = directrix else {
        return Ok(None);
    };
    let directrix_contains_active = active.into_iter().all(|value| {
        cadmpeg_ir::math::parameter_in_domain(
            value,
            directrix.parameter_range().endpoints(),
            64.0 * f64::EPSILON,
        )
    });
    let translated_chart = controls == [0x05, 0x11];
    if records
        .get(&carrier.directrix_id)
        .is_some_and(|record| record.family == 0xa8 && record.class == 0x25)
        && (translated_chart || !directrix_contains_active)
    {
        return Ok(None);
    }
    if translated_chart {
        if translated_directrix_span_count(&directrix, active, controls, object_stream_pcurves)
            .is_none()
        {
            return Ok(None);
        }
        directrix.reorigin_parameter_range(active_bounds);
    } else if !directrix_contains_active {
        let source_range = directrix.parameter_range().endpoints();
        let active_span = active[1] - active[0];
        let suffix_span = object_stream_pcurves
            .get(&directrix.support().1)
            .and_then(|candidate| candidate.class_21_suffix_scalar);
        if !parameter_range_spans_agree(source_range, active)
            || !suffix_span.is_some_and(|span| parameter_spans_agree(span.get(), active_span))
        {
            return Ok(None);
        }
        directrix.reorigin_parameter_range(active_bounds);
    }
    Ok(Some(B5ExtrusionSurface {
        object_id: record.object_id,
        direction: carrier.direction,
        parameter_bounds: [carrier.u_bounds, active_bounds],
        directrix,
    }))
}

fn contextual_offset_extrusion_bounds(
    carrier_surface: u32,
    carrier: &B5ExtrusionCarrier,
    directrix: &B5ExtrusionDirectrix,
    offset_constructions: &[B5OffsetSurface],
    extrusion_surfaces: &BTreeMap<u32, B5ExtrusionSurface>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<[IncreasingParameterInterval; 2]> {
    let B5ExtrusionDirectrix::Offset {
        source,
        source_parameter_range,
        distance,
        direction,
        parameter_range,
        ..
    } = directrix
    else {
        return None;
    };
    let B5ExtrusionChart::OffsetLimits {
        values,
        source_knot_count,
    } = carrier.chart
    else {
        return None;
    };
    let B5ExtrusionDirectrix::SurfaceCurve { support, .. } = source.as_ref() else {
        return None;
    };
    let pcurve = object_stream_pcurves.get(&support.1)?;
    (pcurve.class == 0x21).then_some(())?;
    let active = source_parameter_range.endpoints();
    let first = pcurve
        .distinct_knots
        .iter()
        .position(|knot| knot.get().to_bits() == active[0].to_bits())?;
    let last = pcurve
        .distinct_knots
        .iter()
        .position(|knot| knot.get().to_bits() == active[1].to_bits())?;
    (last.checked_sub(first)?.checked_add(1)? == source_knot_count).then_some(())?;
    let lower_origin = pcurve.distinct_knots.get(first.checked_sub(1)?)?.get();
    let upper_origin = pcurve.distinct_knots.get(last)?.get();
    let upper_flank = pcurve.distinct_knots.get(last.checked_add(1)?)?.get();
    let result = parameter_range.endpoints();
    (lower_origin < result[0]
        && result[0] < active[0]
        && active[1] < result[1]
        && result[1] < upper_flank
        && (result[0] - lower_origin).to_bits() == values[0].get().to_bits()
        && (result[1] - upper_origin).to_bits() == values[1].get().to_bits())
    .then_some(())?;
    let mut resolved = None;
    for construction in offset_constructions.iter().filter(|construction| {
        construction.carrier_surface == carrier_surface
            && construction.carrier_kind == B5OffsetCarrierKind::Extrusion
    }) {
        let source_extrusion = extrusion_surfaces.get(&construction.source_surface)?;
        let bounds = [
            construction.parameter_bounds[1],
            construction.parameter_bounds[0],
        ];
        if source.object_id() != source_extrusion.directrix.object_id()
            || carrier.direction != source_extrusion.direction
            || *direction != source_extrusion.direction
            || distance.get().to_bits() != construction.distance.get().to_bits()
            || carrier.u_bounds != bounds[0]
            || *parameter_range != bounds[1]
        {
            return None;
        }
        if resolved.is_some_and(|previous| previous != bounds) {
            return None;
        }
        resolved = Some(bounds);
    }
    resolved
}

fn terminal_span_directrix(
    directrix_id: u32,
    active: IncreasingParameterInterval,
    controls: [u8; 2],
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<B5ExtrusionDirectrix> {
    let mut first_position = 0;
    let target_span_count = wire::tokens::compact_uint(&controls[..1], &mut first_position)?;
    let mut second_position = 0;
    let source_span_count = usize::try_from(wire::tokens::compact_uint(
        &controls[1..],
        &mut second_position,
    )?)
    .ok()?;
    (target_span_count == 1 && matches!(source_span_count, 5 | 6)).then_some(())?;
    let pcurve = object_stream_pcurves.get(&directrix_id)?;
    (pcurve.class == 0x20 && pcurve.distinct_knots.len() == source_span_count + 1).then_some(())?;
    let source_range = [
        *pcurve.distinct_knots.get(source_span_count - 1)?,
        *pcurve.distinct_knots.get(source_span_count)?,
    ];
    pcurve
        .parameter_range
        .into_iter()
        .zip([
            *pcurve.distinct_knots.first()?,
            *pcurve.distinct_knots.last()?,
        ])
        .all(|(left, right)| left.get().to_bits() == right.get().to_bits())
        .then_some(())?;
    parameter_range_spans_agree(source_range.map(FiniteReal::get), active.endpoints()).then_some(
        B5ExtrusionDirectrix::SurfaceCurve {
            object_id: directrix_id,
            support: (pcurve.surface, directrix_id, source_range),
            parameter_range: active,
        },
    )
}

fn translated_directrix_span_count(
    directrix: &B5ExtrusionDirectrix,
    active: [f64; 2],
    controls: [u8; 2],
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<usize> {
    let mut first_position = 0;
    let target_span_count = wire::tokens::compact_uint(&controls[..1], &mut first_position)?;
    let mut second_position = 0;
    let source_span_count = usize::try_from(wire::tokens::compact_uint(
        &controls[1..],
        &mut second_position,
    )?)
    .ok()?;
    (target_span_count == 1 && source_span_count > 1).then_some(())?;
    let support = directrix.support();
    let pcurve = object_stream_pcurves.get(&support.1)?;
    (pcurve.class == 0x21).then_some(())?;
    let suffix_span = pcurve.class_21_suffix_scalar?.get();
    let active_span = active[1] - active[0];
    parameter_spans_agree(suffix_span, active_span).then_some(())?;
    let source = directrix.parameter_range().endpoints();
    let start = pcurve
        .distinct_knots
        .iter()
        .position(|knot| knot.get().to_bits() == source[0].to_bits())?;
    let end = pcurve
        .distinct_knots
        .iter()
        .position(|knot| knot.get().to_bits() == source[1].to_bits())?;
    (end.checked_sub(start)? == source_span_count).then_some(())?;
    pcurve.distinct_knots[start..=end]
        .windows(2)
        .all(|knots| parameter_spans_agree(knots[1].get() - knots[0].get(), suffix_span))
        .then_some(source_span_count)
}

fn parameter_spans_agree(left: f64, right: f64) -> bool {
    let scale = left.abs().max(right.abs()).max(1.0);
    (left - right).abs() <= 64.0 * f64::EPSILON * scale
}

fn parameter_range_spans_agree(left: [f64; 2], right: [f64; 2]) -> bool {
    let left_span = left[1] - left[0];
    let right_span = right[1] - right[0];
    if left_span.is_finite() && right_span.is_finite() {
        parameter_spans_agree(left_span, right_span)
    } else {
        parameter_spans_agree(
            left[1] * 0.5 - left[0] * 0.5,
            right[1] * 0.5 - right[0] * 0.5,
        )
    }
}

struct B5ExtrusionCarrier {
    directrix_id: u32,
    direction: UnitVector3,
    u_bounds: IncreasingParameterInterval,
    chart: B5ExtrusionChart,
}

#[derive(Clone, Copy)]
enum B5ExtrusionChart {
    Direct {
        bounds: IncreasingParameterInterval,
        controls: [u8; 2],
    },
    /// Two result limits measured from distinct source-knot origins.
    OffsetLimits {
        values: [FiniteReal; 2],
        source_knot_count: usize,
    },
}

fn extrusion_carrier(record: &B5Record) -> Option<B5ExtrusionCarrier> {
    (record.family == 0xb5 && record.class == 0x2c && record.payload.first() == Some(&0x81))
        .then_some(())?;
    let mut position = 1;
    let directrix_id = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let values = read_f64_array::<9>(&record.payload, position)?;
    position += 72;
    let controls: [u8; 2] = record.payload.get(position..)?.try_into().ok()?;
    let values = values.map(FiniteReal::get);
    let contextual_offset_chart = matches!(controls, [0x01, 0x09 | 0x15]);
    ((matches!(controls, [0x05, 0x05 | 0x11 | 0x15 | 0x19])
        || contextual_offset_chart
        || (matches!(controls[0], 0x01 | 0x05) && controls[1] == 0x29))
        && values[5].to_bits() == 1.0f64.to_bits()
        && values[6].to_bits() == 0.0f64.to_bits())
    .then_some(())?;
    let direction = ExactUnitVector3::new([values[0], values[1], values[2]])?.into();
    let u_bounds = IncreasingParameterInterval::new([values[3], values[4]])?;
    let chart = if contextual_offset_chart {
        B5ExtrusionChart::OffsetLimits {
            values: [FiniteReal::new(values[7])?, FiniteReal::new(values[8])?],
            source_knot_count: if controls[1] == 0x09 { 2 } else { 5 },
        }
    } else {
        B5ExtrusionChart::Direct {
            bounds: IncreasingParameterInterval::new([values[7], values[8]])?,
            controls,
        }
    };
    Some(B5ExtrusionCarrier {
        directrix_id,
        direction,
        u_bounds,
        chart,
    })
}

fn parse_extrusion_directrix(
    ctx: &DecodeContext<'_>,
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Result<Option<B5ExtrusionDirectrix>, CodecError> {
    if record.family == 0xb5 && record.class == 0x24 {
        return Ok(parse_surface_curve_directrix(
            record,
            records,
            object_stream_pcurves,
        ));
    }
    if record.family == 0xb5 && record.class == 0x14 {
        return parse_offset_curve_directrix(ctx, record, records, object_stream_pcurves);
    }
    if record.family != 0xa8 || record.class != 0x25 {
        return Ok(None);
    }
    let map = super::parameter_map::parse(&record.payload);
    let Some(map) = map else {
        return Ok(None);
    };
    let Some(first) = parameter_map_support(map.reference, records, object_stream_pcurves) else {
        return Ok(None);
    };
    // Both operands must resolve. Either side may name a surface-curve wrapper.
    let Some(_second) = parameter_map_support(map.co_curve, records, object_stream_pcurves) else {
        return Ok(None);
    };
    if !map
        .active_reference_range
        .endpoints()
        .into_iter()
        .all(|value| {
            cadmpeg_ir::math::parameter_in_domain(
                value,
                first.2.map(FiniteReal::get),
                64.0 * f64::EPSILON,
            )
        })
    {
        return Ok(None);
    }
    Ok(Some(B5ExtrusionDirectrix::SurfaceCurve {
        object_id: record.object_id,
        support: first,
        parameter_range: map.active_reference_range,
    }))
}

fn parameter_map_support(
    object_id: u32,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<(u32, u32, [FiniteReal; 2])> {
    if let Some(pcurve) = object_stream_pcurves.get(&object_id) {
        return Some((pcurve.surface, object_id, pcurve.parameter_range));
    }
    let record = records.get(&object_id)?;
    if record.family == 0xb5 && record.class == 0x24 {
        return match parse_surface_curve_directrix(record, records, object_stream_pcurves) {
            Some(B5ExtrusionDirectrix::SurfaceCurve { support, .. }) => Some(support),
            _ => None,
        };
    }
    let surface = pcurve_surface_reference(record)?;
    analytic_pcurve_range(record).map(|range| (surface, object_id, range))
}

fn parse_surface_curve_directrix(
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Option<B5ExtrusionDirectrix> {
    let parsed = (|| -> Option<_> {
        (record.family == 0xb5 && record.class == 0x24 && record.payload.first() == Some(&0x81))
            .then_some(())?;
        let mut position = 1;
        let pcurve = wire::tokens::object_ref(&record.payload, &mut position, true)?;
        if record.payload.get(position..position + 2) != Some(&[0x81, 0x01]) {
            return None;
        }
        position += 2;
        let [start, end, zero] = read_f64_array::<3>(&record.payload, position)?;
        position += 24;
        let interval = IncreasingParameterInterval::new([start.get(), end.get()])?;
        if record.payload.get(position..) != Some(&[0x01])
            || zero.get().to_bits() != 0.0f64.to_bits()
        {
            return None;
        }
        Some((pcurve, start, end, interval))
    })();
    let (pcurve, start, end, interval) = parsed?;
    let (surface, pcurve_range) = if let Some(candidate) = object_stream_pcurves.get(&pcurve) {
        (candidate.surface, candidate.parameter_range)
    } else {
        let pcurve_record = records.get(&pcurve)?;
        let surface = pcurve_surface_reference(pcurve_record)?;
        let range = analytic_pcurve_range(pcurve_record)?;
        (surface, range)
    };
    let parameter_range = [start, end];
    parameter_range
        .into_iter()
        .all(|value| {
            cadmpeg_ir::math::parameter_in_domain(
                value.get(),
                pcurve_range.map(FiniteReal::get),
                64.0 * f64::EPSILON,
            )
        })
        .then_some(B5ExtrusionDirectrix::SurfaceCurve {
            object_id: record.object_id,
            support: (surface, pcurve, parameter_range),
            parameter_range: interval,
        })
}

fn parse_offset_curve_directrix(
    ctx: &DecodeContext<'_>,
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    object_stream_pcurves: &BTreeMap<u32, B5ObjectStreamPcurve>,
) -> Result<Option<B5ExtrusionDirectrix>, CodecError> {
    let parsed = (|| -> Option<_> {
        (record.family == 0xb5 && record.class == 0x14 && record.payload.first() == Some(&0x81))
            .then_some(())?;
        let mut position = 1;
        let source_id = wire::tokens::object_ref(&record.payload, &mut position, true)?;
        let source_parameter_range = IncreasingParameterInterval::new(
            read_f64_array::<2>(&record.payload, position)?.map(FiniteReal::get),
        )?;
        position += 16;
        if record.payload.get(position) != Some(&0x05) {
            return None;
        }
        position += 1;
        let [distance, x, y, z, start, end] = read_f64_array::<6>(&record.payload, position)?;
        let [x, y, z, start, end] = [x, y, z, start, end].map(FiniteReal::get);
        let parameter_range = IncreasingParameterInterval::new([start, end])?;
        position += 48;
        let source_record = records.get(&source_id)?;
        if !((source_record.family == 0xb5 && source_record.class == 0x24)
            || (source_record.family == 0xa8 && source_record.class == 0x25))
        {
            return None;
        }
        let direction = ExactUnitVector3::new([x, y, z])?.into();
        if position != record.payload.len() || distance.get() == 0.0 {
            return None;
        }
        Some((
            source_record,
            source_parameter_range,
            distance,
            direction,
            parameter_range,
        ))
    })();
    let Some((source_record, source_parameter_range, distance, direction, parameter_range)) =
        parsed
    else {
        return Ok(None);
    };
    let Some(source) =
        parse_extrusion_directrix(ctx, source_record, records, object_stream_pcurves)?
    else {
        return Ok(None);
    };
    if !source
        .parameter_range()
        .endpoints()
        .into_iter()
        .zip(source_parameter_range.endpoints())
        .all(|(left, right)| left.to_bits() == right.to_bits())
    {
        return Ok(None);
    }

    Ok(Some(B5ExtrusionDirectrix::Offset {
        object_id: record.object_id,
        source: Box::new(source),
        source_parameter_range,
        distance,
        direction,
        parameter_range,
    }))
}

fn pcurve_surface_reference(record: &B5Record) -> Option<u32> {
    (matches!(record.class, 0x18..=0x21)).then_some(())?;
    let mut position = usize::from(record.payload.first() == Some(&0x81));
    wire::tokens::object_ref(&record.payload, &mut position, true)
}

fn analytic_pcurve_range(record: &B5Record) -> Option<[FiniteReal; 2]> {
    let pcurve = match record.class {
        0x18 => parse_line_pcurve(record),
        0x19 => parse_circle_pcurve(record),
        _ => None,
    };
    pcurve.and_then(|pcurve| {
        Some([
            *pcurve.distinct_knots.first()?,
            *pcurve.distinct_knots.last()?,
        ])
    })
}

fn parse_supported_surface(record: &B5Record) -> Option<B5SupportedSurface> {
    (record.family == 0xb5 && record.payload.first() == Some(&0x85)).then_some(())?;
    if record.class == 0x3b {
        let (references, parameters) = super::chamfer::payload(&record.payload)?;
        let references = references.map(crate::wire::object_reference::ObjectReference::value);
        return Some(B5SupportedSurface {
            object_id: record.object_id,
            carrier_surface: references[0],
            support_surfaces: [references[1], references[2]],
            support_pcurves: [references[3], references[4]],
            parameters: B5SupportedSurfaceParameters::Chamfer(parameters),
        });
    }
    let mut position = 1;
    let references = [
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
        wire::tokens::object_ref(&record.payload, &mut position, true)?,
    ];
    (record.payload.len() == position.checked_add(22)?).then_some(())?;
    let parameters = match record.class {
        0x37 => {
            let controls = [
                record.payload[position],
                record.payload[position + 1],
                record.payload[position + 10],
                record.payload[position + 11],
                record.payload[position + 20],
                record.payload[position + 21],
            ];
            (matches!(controls[0], 0x05 | 0x09 | 0x0d | 0x11)
                && controls[1] == 0x05
                && matches!(controls[2], 0x03 | 0x05)
                && matches!(controls[3], 0x03 | 0x05)
                && matches!(controls[4], 0x01 | 0x05)
                && if controls[0] == 0x0d {
                    matches!(
                        (controls[4], controls[5]),
                        (0x01, 0x11 | 0x81) | (0x05, 0x09 | 0x81)
                    )
                } else {
                    controls[5] == 0x05
                })
            .then_some(())?;
            let construction_radius =
                PositiveLength::new(f64_le(&record.payload, position + 2)?.get())?;
            (f64_le(&record.payload, position + 12)?.get().to_bits() == 0.0f64.to_bits())
                .then_some(())?;
            B5SupportedSurfaceParameters::Radius {
                controls,
                construction_radius,
            }
        }
        _ => return None,
    };
    Some(B5SupportedSurface {
        object_id: record.object_id,
        carrier_surface: references[0],
        support_surfaces: [references[1], references[2]],
        support_pcurves: [references[3], references[4]],
        parameters,
    })
}

fn supported_surface_parameters_match_carrier(
    parameters: &B5SupportedSurfaceParameters,
    carrier: &B5Surface,
) -> bool {
    let relative_close = |left: f64, right: f64| {
        (left - right).abs() <= EPS_B5_GRAPH_EXACT_GEOMETRY * left.abs().max(right.abs())
    };
    match (parameters, carrier) {
        (
            B5SupportedSurfaceParameters::Radius {
                construction_radius,
                controls,
            },
            B5Surface::Cylinder { radius, .. },
        ) => controls[0] == 0x05 && relative_close(construction_radius.get(), radius.get()),
        (
            B5SupportedSurfaceParameters::Radius {
                construction_radius,
                controls,
            },
            B5Surface::Torus { minor_radius, .. },
        ) => controls[0] == 0x09 && relative_close(construction_radius.get(), minor_radius.get()),
        (
            B5SupportedSurfaceParameters::Radius {
                construction_radius,
                controls,
            },
            B5Surface::Sphere {
                construction_radius: carrier_radius,
                latitude_range,
                ..
            },
        ) => {
            let [lower, upper] = latitude_range.endpoints();
            let pole = std::f64::consts::FRAC_PI_2;
            let closure = if lower == -pole {
                0x81
            } else if controls[4] == 0x01 {
                0x11
            } else {
                0x09
            };
            controls[0] == 0x0d
                && upper == pole
                && controls[5] == closure
                && relative_close(construction_radius.get(), carrier_radius.get())
        }
        (B5SupportedSurfaceParameters::Radius { controls, .. }, B5Surface::RollingBall { .. }) => {
            controls[0] == 0x11
        }
        (B5SupportedSurfaceParameters::Chamfer(parameters), B5Surface::Plane { .. }) => {
            parameters.result_kind == ChamferResultKind::Plane
        }
        (B5SupportedSurfaceParameters::Chamfer(parameters), B5Surface::Cone { .. }) => {
            parameters.result_kind == ChamferResultKind::Cone
        }
        _ => false,
    }
}

fn supported_surface_pcurves_match(
    construction: &B5SupportedSurface,
    by_id: &HashMap<u32, &B5Record>,
    a8_pcurve_supports: &HashMap<u32, u32>,
) -> bool {
    construction
        .support_pcurves
        .iter()
        .zip(construction.support_surfaces)
        .all(|(pcurve_id, support_id)| {
            let Some(pcurve) = by_id.get(pcurve_id) else {
                return false;
            };
            if pcurve.family == 0xa8 && pcurve.class == 0x20 {
                return a8_pcurve_supports.get(pcurve_id) == Some(&support_id);
            }
            let mut position = 1;
            pcurve.payload.first() == Some(&0x81)
                && wire::tokens::object_ref(&pcurve.payload, &mut position, true)
                    == Some(support_id)
        })
}

fn lift_pcurve_endpoints(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &B5Surface,
    profiles: &BTreeMap<u32, B5Profile>,
    endpoints: [[f64; 2]; 2],
) -> Result<Option<[FinitePoint3; 2]>, cadmpeg_core::decode::ResourceLimit> {
    if let B5Surface::Nurbs(surface) = surface {
        let Some(start) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::nurbs_surface_point(
                    ctx,
                    surface,
                    endpoints[0][0],
                    endpoints[0][1],
                ),
            )?)?
        else {
            return Ok(None);
        };
        let Some(end) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::nurbs_surface_point(
                    ctx,
                    surface,
                    endpoints[1][0],
                    endpoints[1][1],
                ),
            )?)?
        else {
            return Ok(None);
        };
        return Ok(Some([start, end]));
    }
    Ok((|| {
        let lifted = match surface {
            B5Surface::UnresolvedNurbs { .. }
            | B5Surface::Unknown { .. }
            | B5Surface::RollingBall { .. } => None,
            B5Surface::Plane {
                origin,
                frame,
                direction_v,
                ..
            } => {
                let (origin, direction_u) = (coordinates(*origin), components(frame.reference()));
                Some(endpoints.map(|[u, v]| {
                    add(
                        origin,
                        add(scale(direction_u, u), scale(direction_v.get(), v)),
                    )
                }))
            }
            B5Surface::Cylinder {
                origin,
                frame,
                radius,
                angular_scale,
                ..
            } => {
                let (origin, axis, reference_x) = (
                    coordinates(*origin),
                    components(frame.axis()),
                    components(frame.reference()),
                );
                let reference_y = cross(axis, reference_x);
                Some(endpoints.map(|[u, v]| {
                    let angle = u / angular_scale.get();
                    add(
                        origin,
                        add(
                            scale(
                                add(
                                    scale(reference_x, angle.cos()),
                                    scale(reference_y, angle.sin()),
                                ),
                                radius.get(),
                            ),
                            scale(axis, v),
                        ),
                    )
                }))
            }
            B5Surface::Cone {
                origin,
                frame,
                direction_y,
                radial_angle,
                angular_scale,
                reference_radius,
                slant_shift,
                ..
            } => Some(endpoints.map(|[u, v]| {
                let v = v - slant_shift.get();
                let angle = u / angular_scale.get();
                let radial = add(
                    scale(components(frame.reference()), angle.cos()),
                    scale(components(direction_y), angle.sin()),
                );
                add(
                    coordinates(*origin),
                    add(
                        scale(radial, reference_radius.get()),
                        scale(
                            add(
                                scale(components(frame.axis()), radial_angle.get().sin()),
                                scale(radial, radial_angle.get().cos()),
                            ),
                            v,
                        ),
                    ),
                )
            })),
            B5Surface::Torus {
                center,
                frame,
                direction_y,
                major_radius,
                minor_radius,
                major_scale,
                minor_scale,
                ..
            } => {
                let (center, axis, direction_x) = (
                    coordinates(*center),
                    components(frame.axis()),
                    components(frame.reference()),
                );
                let (major_radius, minor_radius) = (major_radius.get(), minor_radius.get());
                Some(endpoints.map(|[u, v]| {
                    let major_angle = u / major_scale.get();
                    let minor_angle = v / minor_scale.get();
                    let radial = add(
                        scale(direction_x, major_angle.cos()),
                        scale(direction_y.get(), major_angle.sin()),
                    );
                    add(
                        center,
                        add(
                            scale(radial, major_radius + minor_radius * minor_angle.cos()),
                            scale(axis, minor_radius * minor_angle.sin()),
                        ),
                    )
                }))
            }
            B5Surface::Sphere { .. } => None,
            B5Surface::Revolution {
                profile_curve,
                axis_origin,
                axis_direction,
                profile_range,
                angular_scale,
                ..
            } => {
                let profile = profiles.get(profile_curve)?;
                (profile
                    .parameter_range()
                    .endpoints()
                    .into_iter()
                    .zip(profile_range.endpoints())
                    .all(|(profile, surface)| profile.to_bits() == surface.to_bits()))
                .then_some(())?;
                Some(endpoints.map(|[u, v]| {
                    let point = match profile {
                        B5Profile::Line {
                            point, direction, ..
                        } => add(coordinates(*point), scale(direction.get(), u)),
                        B5Profile::Arc {
                            center,
                            direction_x,
                            direction_y,
                            radius,
                            ..
                        } => {
                            let angle = u / radius.get();
                            add(
                                coordinates(*center),
                                scale(
                                    add(
                                        scale(direction_x.get(), angle.cos()),
                                        scale(direction_y.get(), angle.sin()),
                                    ),
                                    radius.get(),
                                ),
                            )
                        }
                    };
                    rotate_about_axis(
                        point,
                        coordinates(*axis_origin),
                        components(axis_direction),
                        v / angular_scale.get(),
                    )
                }))
            }
            B5Surface::Nurbs(_) => None,
        };
        let [start, end] = lifted?;
        Some([
            FinitePoint3::new(Point3::from(start))?,
            FinitePoint3::new(Point3::from(end))?,
        ])
    })())
}

fn rotate_about_axis(point: [f64; 3], origin: [f64; 3], axis: [f64; 3], angle: f64) -> [f64; 3] {
    let relative = [
        point[0] - origin[0],
        point[1] - origin[1],
        point[2] - origin[2],
    ];
    let cross_term = cross(axis, relative);
    let dot = axis[0] * relative[0] + axis[1] * relative[1] + axis[2] * relative[2];
    add(
        origin,
        add(
            scale(relative, angle.cos()),
            add(
                scale(cross_term, angle.sin()),
                scale(axis, dot * (1.0 - angle.cos())),
            ),
        ),
    )
}

fn parse_pcurve(record: &B5Record) -> Option<B5Pcurve> {
    if record.family != 0xb5 || record.class != 0x21 || record.payload.first() != Some(&0x81) {
        return None;
    }
    let mut position = 1;
    let surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    if record.payload.get(position) != Some(&0x01) {
        return None;
    }
    position += 1;
    let degree = wire::tokens::compact_uint(&record.payload, &mut position)?;
    if !matches!(degree, 1 | 2 | 5)
        || record.payload.get(position..position + 2) != Some(&[0x01, 0x01])
    {
        return None;
    }
    position += 2;
    let knot_count =
        usize::try_from(wire::tokens::compact_uint(&record.payload, &mut position)?).ok()?;
    if knot_count != 2 || record.payload.get(position) != Some(&0x01) {
        return None;
    }
    position += 1;
    let mut view = View::over_retained(&record.payload);
    view.seek(position)?;
    let mut distinct_knots = Vec::new();
    for _ in 0..knot_count {
        let knot = FiniteReal::new(view.f64_le()?)?;
        distinct_knots.push(knot);
    }
    position = view.position();
    if !distinct_knots.windows(2).all(|pair| pair[0] < pair[1]) {
        return None;
    }
    let mut multiplicities = Vec::new();
    for _ in 0..knot_count {
        let multiplicity = wire::tokens::compact_uint(&record.payload, &mut position)?;
        multiplicities.push(multiplicity);
    }
    let endpoint_multiplicity = degree + 1;
    if multiplicities != [endpoint_multiplicity; 2] {
        return None;
    }
    let pole_count = endpoint_multiplicity;
    view.seek(position)?;
    let mut control_points = Vec::new();
    for _ in 0..pole_count {
        let u = view.f64_le()?;
        let v = view.f64_le()?;
        let point = FiniteVector::new([u, v])?;
        control_points.push(point);
    }
    position = view.position();
    let tail = record.payload.get(position..)?;
    let suffix_scalar = PositiveReal::new(f64_le(tail, 10)?.get())?;
    let native_origin = *distinct_knots.first()?;
    let native_span = distinct_knots[1].get() - native_origin.get();
    if tail.len() != 36
        || tail.get(..2) != Some(&[0x05, 0x05])
        || f64_le(tail, 2)?.get() != 0.0
        || suffix_scalar.get().to_bits() != native_span.to_bits()
        || f64_le(tail, 18)?.get() != 1.0
        || f64_le(tail, 26)?.get() != 0.0
        || tail.get(34..) != Some(&[0x00, 0x07])
    {
        return None;
    }
    Some(B5Pcurve {
        object_id: record.object_id,
        surface,
        degree,
        distinct_knots,
        multiplicities,
        control_points,
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Translated { native_origin },
        class_21_suffix_scalar: Some(suffix_scalar),
        lifted_endpoints: None,
    })
}

fn parse_circle_pcurve(record: &B5Record) -> Option<B5Pcurve> {
    let (surface, center, radius, range, angles) = parse_circle_pcurve_fields(record)?;
    rational_arc_pcurve(crate::families::b5::graph::RationalArcPcurveInputs {
        record,
        surface,
        center,
        reference_x: [1.0, 0.0],
        reference_y: [0.0, 1.0],
        radius,
        parameter_range: range,
        angle_range: angles,
    })
}

fn parse_circle_pcurve_fields(record: &B5Record) -> CirclePcurveFields {
    if record.family != 0xb5 || record.class != 0x19 || record.payload.first() != Some(&0x81) {
        return None;
    }
    let mut position = 1;
    let surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    if record.payload.len() != position.checked_add(58)? {
        return None;
    }
    let center = read_f64_array::<2>(&record.payload, position)?.map(FiniteReal::get);
    position += 16;
    if record.payload.get(position..position + 2) != Some(&[0x05, 0x05]) {
        return None;
    }
    position += 2;
    let [radius, start, end, orientation, _] =
        read_f64_array::<5>(&record.payload, position)?.map(FiniteReal::get);
    if radius <= 0.0 || start >= end || !matches!(orientation, -1.0 | 1.0) {
        return None;
    }
    let start_angle = orientation * start / radius;
    let end_angle = orientation * end / radius;
    Some((
        surface,
        center,
        radius,
        [start, end],
        [start_angle, end_angle],
    ))
}

fn parse_class_1a_pcurve(record: &B5Record) -> Option<B5Pcurve> {
    let (surface, center, reference_x, reference_y, radius, range, angles) =
        parse_class_1a_pcurve_fields(record)?;
    rational_arc_pcurve(crate::families::b5::graph::RationalArcPcurveInputs {
        record,
        surface,
        center,
        reference_x,
        reference_y,
        radius,
        parameter_range: range,
        angle_range: angles,
    })
}

fn parse_class_1a_pcurve_fields(record: &B5Record) -> Class1aPcurveFields {
    if record.family != 0xb5 || record.class != 0x1a || record.payload.first() != Some(&0x81) {
        return None;
    }
    let mut position = 1;
    let surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    if record.payload.len() != position.checked_add(74)? {
        return None;
    }
    let center = read_f64_array::<2>(&record.payload, position)?.map(FiniteReal::get);
    position += 16;
    if record.payload.get(position..position + 2) != Some(&[0x05, 0x05]) {
        return None;
    }
    let [diameter_u, diameter_v, conjugate_angle, start, end, orientation, period] =
        read_f64_array::<7>(&record.payload, position + 2)?.map(FiniteReal::get);
    let diameter = diameter_u.hypot(diameter_v);
    let relative_period = period / (std::f64::consts::PI * diameter);
    if diameter <= 0.0
        || start >= end
        || period <= 0.0
        || !matches!(orientation, -1.0 | 1.0)
        || (conjugate_angle - std::f64::consts::FRAC_PI_2).abs() > EPS_B5_GRAPH_EXACT_GEOMETRY
        || !relative_period.is_finite()
        || (relative_period - 1.0).abs() > EPS_B5_GRAPH_EXACT_GEOMETRY
    {
        return None;
    }
    let reference_x = [diameter_u / diameter, diameter_v / diameter];
    let reference_y = [-reference_x[1], reference_x[0]];
    let angles = [
        orientation * std::f64::consts::TAU * start / period,
        orientation * std::f64::consts::TAU * end / period,
    ];
    Some((
        surface,
        center,
        reference_x,
        reference_y,
        diameter * 0.5,
        [start, end],
        angles,
    ))
}
#[derive(Clone, Copy)]
struct RationalArcPcurveInputs<'input0> {
    record: &'input0 B5Record,
    surface: u32,
    center: [f64; 2],
    reference_x: [f64; 2],
    reference_y: [f64; 2],
    radius: f64,
    parameter_range: [f64; 2],
    angle_range: [f64; 2],
}

fn rational_arc_pcurve(inputs: RationalArcPcurveInputs<'_>) -> Option<B5Pcurve> {
    let RationalArcPcurveInputs {
        record,
        surface,
        center,
        reference_x,
        reference_y,
        radius,
        parameter_range,
        angle_range,
    } = inputs;

    let [start, end] = parameter_range;
    let [start_angle, end_angle] = angle_range;
    let span_count = ((end_angle - start_angle).abs() / std::f64::consts::FRAC_PI_2).ceil();
    if !span_count.is_finite() || span_count > crate::MAX_EXACT_ARC_SPANS {
        return None;
    }
    // `ceil` answers zero only for an angular span of exactly zero: an arc that
    // sweeps no angle states no span, which this route refuses as it refuses
    // every other degeneracy.
    let span_count = truncate_f64_to_usize(span_count).and_then(std::num::NonZeroUsize::new)?;
    let span_count = span_count.get();
    let mut control_points = Vec::new();
    let mut weights = Vec::new();
    let mut distinct_knots = Vec::new();
    let mut multiplicities = Vec::new();

    distinct_knots.push(start);
    multiplicities.push(3);
    for span in 0..span_count {
        let fraction0 = f64_from_index(span)? / f64_from_index(span_count)?;
        let fraction1 = f64_from_index(span + 1)? / f64_from_index(span_count)?;
        let angle0 = start_angle + (end_angle - start_angle) * fraction0;
        let angle1 = start_angle + (end_angle - start_angle) * fraction1;
        let middle = (angle0 + angle1) * 0.5;
        let middle_weight = ((angle1 - angle0) * 0.5).cos();
        if middle_weight <= f64::EPSILON {
            return None;
        }
        if span == 0 {
            control_points.push([
                center[0]
                    + radius * (reference_x[0] * angle0.cos() + reference_y[0] * angle0.sin()),
                center[1]
                    + radius * (reference_x[1] * angle0.cos() + reference_y[1] * angle0.sin()),
            ]);
            weights.push(1.0);
        }
        control_points.push([
            center[0]
                + radius / middle_weight
                    * (reference_x[0] * middle.cos() + reference_y[0] * middle.sin()),
            center[1]
                + radius / middle_weight
                    * (reference_x[1] * middle.cos() + reference_y[1] * middle.sin()),
        ]);
        control_points.push([
            center[0] + radius * (reference_x[0] * angle1.cos() + reference_y[0] * angle1.sin()),
            center[1] + radius * (reference_x[1] * angle1.cos() + reference_y[1] * angle1.sin()),
        ]);
        weights.extend([middle_weight, 1.0]);
        if span + 1 < span_count {
            let ordinary = start + (end - start) * fraction1;
            let knot = if ordinary.is_finite() {
                ordinary
            } else {
                let knot = cadmpeg_ir::math::interpolate(start, end, fraction1)?;
                knot.get()
            };
            distinct_knots.push(knot);
            multiplicities.push(2);
        }
    }
    distinct_knots.push(end);
    multiplicities.push(3);
    let distinct_knots = distinct_knots
        .into_iter()
        .map(FiniteReal::new)
        .collect::<Option<Vec<_>>>()?;
    let weights = weights
        .into_iter()
        .map(PositiveReal::new)
        .collect::<Option<Vec<_>>>()?;
    let control_points = control_points
        .into_iter()
        .map(FiniteVector::new)
        .collect::<Option<Vec<_>>>()?;
    Some(B5Pcurve {
        object_id: record.object_id,
        surface,
        degree: 2,
        distinct_knots,
        multiplicities,
        control_points,
        weights: Some(weights),
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    })
}

fn parse_opaque_pcurve(record: &B5Record) -> Option<B5OpaquePcurve> {
    if parse_class_1a_pcurve(record).is_some() {
        return None;
    }
    let surface = parse_opaque_pcurve_surface(record)?;
    Some(B5OpaquePcurve {
        object_id: record.object_id,
        surface,
        class: record.class,
        payload: record.payload.clone(),
        sphere_great_circle: None,
    })
}

fn parse_opaque_pcurve_surface(record: &B5Record) -> Option<u32> {
    if record.family != 0xb5 || record.payload.first() != Some(&0x81) {
        return None;
    }
    let mut position = 1;
    let surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    match record.class {
        0x1a => {
            (record.payload.len() == position.checked_add(74)?).then_some(())?;
            read_f64_array::<2>(&record.payload, position)?;
            position += 16;
            (record.payload.get(position..position + 2) == Some(&[0x05, 0x05])).then_some(())?;
            read_f64_array::<7>(&record.payload, position + 2)?;
        }
        0x1d => {
            (record.payload.len() == position.checked_add(99)?).then_some(())?;
            read_f64_array::<4>(&record.payload, position)?;
            position += 32;
            (record.payload.get(position..position + 2) == Some(&[0x05, 0x81])).then_some(())?;
            read_f64_array::<3>(&record.payload, position + 2)?;
            position += 26;
            (record.payload.get(position) == Some(&0x1d)).then_some(())?;
            read_f64_array::<5>(&record.payload, position + 1)?;
        }
        _ => return None,
    }
    Some(surface)
}

fn parse_sphere_great_circle_pcurve(
    record: &B5Record,
    surface: &B5Surface,
) -> Option<B5SphereGreatCirclePcurve> {
    let B5Surface::Sphere {
        construction_radius: sphere_chart_scale,
        azimuth_range,
        chart_origin,
        ..
    } = surface
    else {
        return None;
    };
    (record.family == 0xb5 && record.class == 0x1d && record.payload.first() == Some(&0x81))
        .then_some(())?;
    let mut position = 1;
    wire::tokens::object_ref(&record.payload, &mut position, true)?;
    (record.payload.len() == position.checked_add(99)?).then_some(())?;
    let [u0, u1, v0, v1] = read_f64_array::<4>(&record.payload, position)?;
    position += 32;
    (record.payload.get(position..position + 2) == Some(&[0x05, 0x81])).then_some(())?;
    let [chart_shift, direction, zero0] = read_f64_array::<3>(&record.payload, position + 2)?;
    let (direction, zero0) = (direction.get(), zero0.get());
    position += 26;
    (record.payload.get(position) == Some(&0x1d)).then_some(())?;
    let [chart_scale, slope, reciprocal_scale, phase, zero1] =
        read_f64_array::<5>(&record.payload, position + 1)?;
    let u_bounds = IncreasingParameterInterval::new([u0.get(), u1.get()])?;
    let v_bounds = [v0, v1];
    let chart_scale = PositiveReal::new(chart_scale.get())?;
    let (u0, u1, v0, v1) = (u0.get(), u1.get(), v0.get(), v1.get());
    let (reciprocal_scale, zero1) = (reciprocal_scale.get(), zero1.get());

    let surface_u_bounds = azimuth_range
        .endpoints()
        .map(|angle| chart_scale.get() * angle);
    let u_scale = surface_u_bounds
        .into_iter()
        .chain([u0, u1])
        .map(f64::abs)
        .fold(1.0, f64::max);
    let u_tolerance = EPS_B5_GRAPH_EXACT_GEOMETRY * u_scale;
    (direction.abs() == 1.0
        && zero0 == 0.0
        && zero1 == 0.0
        && chart_scale.get() == sphere_chart_scale.get()
        && reciprocal_scale == -direction / chart_scale.get()
        && u0 >= surface_u_bounds[0] - u_tolerance
        && u1 <= surface_u_bounds[1] + u_tolerance
        && v0 == chart_origin.get()
        && v1 == chart_origin.get() + std::f64::consts::TAU * chart_scale.get())
    .then_some(B5SphereGreatCirclePcurve {
        u_bounds,
        v_bounds,
        chart_shift,
        chart_scale,
        slope,
        phase,
    })
}

fn sphere_great_circle_point(
    pcurve: &B5SphereGreatCirclePcurve,
    surface: &B5Surface,
    parameter: FiniteReal,
) -> Option<FinitePoint3> {
    let B5Surface::Sphere {
        center,
        frame,
        direction_y,
        radius,
        construction_radius,
        ..
    } = surface
    else {
        return None;
    };
    let (center, direction_x, direction_y, axis, radius) = (
        coordinates(*center),
        components(frame.reference()),
        components(direction_y),
        components(frame.axis()),
        radius.get(),
    );
    let parameter = parameter.get();
    let chart_scale = pcurve.chart_scale.get();
    if parameter < pcurve.u_bounds.lower()
        || parameter > pcurve.u_bounds.upper()
        || chart_scale != construction_radius.get()
    {
        return None;
    }
    let azimuth = parameter / chart_scale;
    let phase = pcurve.chart_shift.get() / chart_scale + pcurve.phase.get();
    let latitude = (pcurve.slope.get() * (azimuth - phase).cos()).atan();
    let cos_latitude = latitude.cos();
    let sin_latitude = latitude.sin();
    let cos_azimuth = azimuth.cos();
    let sin_azimuth = azimuth.sin();
    let point = [
        center[0]
            + radius
                * (cos_latitude * (cos_azimuth * direction_x[0] + sin_azimuth * direction_y[0])
                    + sin_latitude * axis[0]),
        center[1]
            + radius
                * (cos_latitude * (cos_azimuth * direction_x[1] + sin_azimuth * direction_y[1])
                    + sin_latitude * axis[1]),
        center[2]
            + radius
                * (cos_latitude * (cos_azimuth * direction_x[2] + sin_azimuth * direction_y[2])
                    + sin_latitude * axis[2]),
    ];
    FinitePoint3::new(Point3::from(point))
}

fn circle_pcurves_from_frames(bytes: &[u8], frames: &[ObjectFrame]) -> Vec<B5Pcurve> {
    let mut pcurves = Vec::new();
    for frame in frames {
        if frame.family != 0xb5 || frame.class != 0x19 {
            continue;
        }
        let record = B5Record {
            offset: frame.start,
            family: 0xb5,
            class: 0x19,
            object_id: frame.object_id,
            payload: bytes[frame.start + 8..frame.end].to_vec(),
        };
        if let Some(pcurve) = parse_circle_pcurve(&record) {
            pcurves.push(pcurve);
        }
    }
    pcurves
}

fn parse_line_pcurve(record: &B5Record) -> Option<B5Pcurve> {
    let Some((surface, start, end, [Some(start_point), Some(end_point)])) =
        parse_line_pcurve_fields(record)
    else {
        return None;
    };
    Some(B5Pcurve {
        object_id: record.object_id,
        surface,
        degree: 1,
        distinct_knots: vec![start, end],
        multiplicities: vec![2, 2],
        control_points: vec![start_point, end_point],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    })
}

fn parse_line_pcurve_fields(
    record: &B5Record,
) -> Option<(u32, FiniteReal, FiniteReal, [Option<FiniteVector<2>>; 2])> {
    if record.family != 0xb5 || record.class != 0x18 || record.payload.first() != Some(&0x81) {
        return None;
    }
    let mut position = 1;
    let surface = wire::tokens::object_ref(&record.payload, &mut position, true)?;
    let mode = *record.payload.get(position)?;
    position += 1;
    let (start, end, control_points) = match mode {
        0x01 if record.payload.len() == position.checked_add(48)? => {
            let [u, v, du, dv, start, end] = read_f64_array::<6>(&record.payload, position)?;
            let [u, v, du, dv] = [u, v, du, dv].map(FiniteReal::get);
            if du == 0.0 && dv == 0.0 {
                return None;
            }
            (
                start,
                end,
                [
                    FiniteVector::new([u + start.get() * du, v + start.get() * dv]),
                    FiniteVector::new([u + end.get() * du, v + end.get() * dv]),
                ],
            )
        }
        0x05 if record.payload.len() == position.checked_add(24)? => {
            let [constant, start, end] = read_f64_array::<3>(&record.payload, position)?;
            (
                start,
                end,
                [
                    Some(FiniteVector::from([constant, start])),
                    Some(FiniteVector::from([constant, end])),
                ],
            )
        }
        0x09 if record.payload.len() == position.checked_add(24)? => {
            let [constant, start, end] = read_f64_array::<3>(&record.payload, position)?;
            (
                start,
                end,
                [
                    Some(FiniteVector::from([start, constant])),
                    Some(FiniteVector::from([end, constant])),
                ],
            )
        }
        _ => return None,
    };
    if start >= end {
        return None;
    }
    Some((surface, start, end, control_points))
}

#[cfg(test)]
fn records(bytes: &[u8]) -> Vec<B5Record> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    records_from_frames(bytes, &frames, None)
}

/// Dependency-admission fixpoint with an optional local work budget.
///
/// The dependency candidates are indexed once by object identity. Earlier
/// passes rescanned every frame for every newly discovered dependency, which
/// made a large population spend its bounded work slice on repeated scans
/// before the selected topology graph could be parsed.
fn records_from_frames(
    bytes: &[u8],
    frames: &[ObjectFrame],
    budget: Option<&WorkBudget>,
) -> Vec<B5Record> {
    let (mut records, candidates) = framed_records_and_dependency_candidates(bytes, frames, budget);
    admit_dependency_records(bytes, &mut records, &candidates, budget)
}

/// Materialize one already-indexed topology population.
///
/// Each materialized topology record and each admitted dependency in the
/// closure fixpoint spends one unit of the local work budget.
fn records_from_indexed_frames(
    bytes: &[u8],
    frames: &[ObjectFrame],
    budget: Option<&WorkBudget>,
) -> Option<Vec<B5Record>> {
    let (mut records, candidates) =
        indexed_topology_records_and_dependency_candidates(bytes, frames, budget)?;
    let records = admit_dependency_records(bytes, &mut records, &candidates, budget);
    if budget.is_some_and(WorkBudget::exhausted) {
        None
    } else {
        Some(records)
    }
}

fn admit_dependency_records(
    bytes: &[u8],
    records: &mut Vec<B5Record>,
    candidates: &DependencyCandidates,
    budget: Option<&WorkBudget>,
) -> Vec<B5Record> {
    let mut existing = HashSet::new();
    let mut pending = HashSet::new();
    for record in records.iter() {
        existing.insert(record.object_id);
    }
    for record in records.iter() {
        for reference in record_references(record) {
            if !existing.contains(&reference)
                && candidates.get(&reference).is_some_and(Option::is_some)
            {
                pending.insert(reference);
            }
        }
    }
    let mut admitted = HashSet::new();
    loop {
        pending.retain(|object_id| !existing.contains(object_id) && !admitted.contains(object_id));
        if pending.is_empty() {
            break;
        }
        if budget.is_some_and(|budget| !budget.charge_by(pending.len())) {
            break;
        }
        let mut found = Vec::new();
        for object_id in &pending {
            if let Some(frame) = candidates.get(object_id).and_then(Option::as_ref) {
                if frame_payload(bytes, frame).is_some() {
                    found.push(*frame);
                }
            }
        }
        if found.is_empty() {
            break;
        }
        found.sort_unstable_by_key(|left| left.start);
        pending.clear();
        for frame in found {
            let Some(candidate) = record_from_frame(bytes, &frame) else {
                continue;
            };
            admitted.insert(candidate.object_id);
            for reference in record_references(&candidate) {
                if !existing.contains(&reference)
                    && !admitted.contains(&reference)
                    && candidates.get(&reference).is_some_and(Option::is_some)
                {
                    pending.insert(reference);
                }
            }
            records.push(candidate);
        }
    }
    std::mem::take(records)
}

/// Build the topology records and the exact dependency index in one frame
/// pass. The two views used to scan the same frame slice independently, which
/// spent the bounded selection budget twice before dependency closure began.
fn framed_records_and_dependency_candidates(
    bytes: &[u8],
    frames: &[ObjectFrame],
    budget: Option<&WorkBudget>,
) -> (Vec<B5Record>, DependencyCandidates) {
    if budget.is_some_and(|budget| !budget.charge_by(frames.len())) {
        return (Vec::new(), HashMap::new());
    }

    let mut records = Vec::<(usize, B5Record)>::new();
    let mut seen = HashMap::<u32, ObjectFrame>::new();
    let mut candidates = DependencyCandidates::new();
    for frame in frames {
        if is_reference_dependency_class(frame.family, frame.class)
            && frame_payload(bytes, frame).is_some()
        {
            if let Some(slot) = candidates.get_mut(&frame.object_id) {
                if slot
                    .as_ref()
                    .is_some_and(|existing| !same_object_frame(bytes, existing, frame))
                {
                    *slot = None;
                }
            } else {
                candidates.insert(frame.object_id, Some(*frame));
            }
        }
        if !((frame.family == 0xb5 && is_topology_class(frame.class))
            || (frame.family == 0xa8 && matches!(frame.class, 0x34 | 0x62)))
        {
            continue;
        }
        if let Some(previous) = seen.get(&frame.object_id) {
            if previous.class == frame.class {
                let left = frame_payload(bytes, previous);
                let right = frame_payload(bytes, frame);

                if left == right {
                    continue;
                }
            }
        }
        let Some(record) = record_from_frame(bytes, frame) else {
            continue;
        };
        seen.insert(frame.object_id, *frame);
        records.push((frame.end, record));
    }
    records.sort_unstable_by(|(left_end, left), (right_end, right)| {
        left_end
            .cmp(right_end)
            .then_with(|| right.offset.cmp(&left.offset))
    });
    let mut ordered = Vec::new();
    for (_, record) in records {
        ordered.push(record);
    }
    (ordered, candidates)
}

/// Build topology records and dependency candidates from an existing frame
/// index without charging a second frame walk. Candidate identity conflicts
/// remain ambiguous until the dependency is requested.
fn indexed_topology_records_and_dependency_candidates(
    bytes: &[u8],
    frames: &[ObjectFrame],
    budget: Option<&WorkBudget>,
) -> Option<(Vec<B5Record>, DependencyCandidates)> {
    let mut records = Vec::<(usize, B5Record)>::new();
    let mut seen = HashMap::<u32, ObjectFrame>::new();
    let mut candidates = DependencyCandidates::new();
    for frame in frames {
        if is_reference_dependency_class(frame.family, frame.class)
            && frame_payload(bytes, frame).is_some()
        {
            if let Some(slot) = candidates.get_mut(&frame.object_id) {
                if slot
                    .as_ref()
                    .is_some_and(|existing| !same_object_frame(bytes, existing, frame))
                {
                    *slot = None;
                }
            } else {
                candidates.insert(frame.object_id, Some(*frame));
            }
        }
        if !((frame.family == 0xb5 && is_topology_class(frame.class))
            || (frame.family == 0xa8 && matches!(frame.class, 0x34 | 0x62)))
        {
            continue;
        }
        if budget.is_some_and(|budget| !budget.charge()) {
            return None;
        }
        if let Some(previous) = seen.get(&frame.object_id) {
            if previous.class == frame.class {
                let left = frame_payload(bytes, previous);
                let right = frame_payload(bytes, frame);

                if left == right {
                    continue;
                }
            }
        }
        let record = record_from_frame(bytes, frame)?;
        seen.insert(frame.object_id, *frame);
        records.push((frame.end, record));
    }
    records.sort_unstable_by(|(left_end, left), (right_end, right)| {
        left_end
            .cmp(right_end)
            .then_with(|| right.offset.cmp(&left.offset))
    });
    let mut ordered = Vec::new();
    for (_, record) in records {
        ordered.push(record);
    }
    Some((ordered, candidates))
}

fn same_object_frame(bytes: &[u8], left: &ObjectFrame, right: &ObjectFrame) -> bool {
    left.family == right.family
        && left.class == right.class
        && bytes
            .get(left.start..left.end)
            .zip(bytes.get(right.start..right.end))
            .is_some_and(|(left, right)| left == right)
}

fn frame_payload<'a>(bytes: &'a [u8], frame: &ObjectFrame) -> Option<&'a [u8]> {
    let header = if frame.family == 0xa8 { 11 } else { 8 };
    bytes.get(frame.start.checked_add(header)?..frame.end)
}

fn record_from_frame(bytes: &[u8], frame: &ObjectFrame) -> Option<B5Record> {
    if frame.family == 0xa8 && frame.class == 0x25 && bytes.get(frame.start + 1) != Some(&0x03) {
        return None;
    }
    let payload = frame_payload(bytes, frame)?;
    Some(B5Record {
        offset: frame.start,
        family: frame.family,
        class: frame.class,
        object_id: frame.object_id,
        payload: payload.to_vec(),
    })
}

#[cfg(test)]
fn framed_records(bytes: &[u8], frames: &[ObjectFrame]) -> Vec<B5Record> {
    let mut records = Vec::new();
    let mut seen = HashMap::<u32, (u8, Vec<u8>)>::new();
    for ObjectFrame {
        start,
        end,
        family,
        class,
        object_id,
    } in frames.iter().copied()
    {
        if !((family == 0xb5 && is_topology_class(class))
            || (family == 0xa8 && matches!(class, 0x34 | 0x62)))
        {
            continue;
        }
        let frame = ObjectFrame {
            start,
            end,
            family,
            class,
            object_id,
        };
        let Some(record) = record_from_frame(bytes, &frame) else {
            continue;
        };
        if seen
            .get(&object_id)
            .is_some_and(|(seen_class, seen_payload)| {
                *seen_class == record.class && *seen_payload == record.payload
            })
        {
            continue;
        }
        seen.insert(object_id, (record.class, record.payload.clone()));
        records.push((end, record));
    }
    // Preserve the historical child-before-wrapper order for records nested in
    // an A8 frame while retaining the walker's bounded admission rules.
    records.sort_unstable_by(|(left_end, left), (right_end, right)| {
        left_end
            .cmp(right_end)
            .then_with(|| right.offset.cmp(&left.offset))
    });
    records.into_iter().map(|(_, record)| record).collect()
}

/// Return complete byte ranges for length-closed object-stream records.
pub(in crate::families) fn framed_ranges(bytes: &[u8]) -> impl Iterator<Item = Range<usize>> + '_ {
    object_stream_frames(bytes).map(|frame| frame.start..frame.end)
}

struct ObjectFrames<'a> {
    bytes: &'a [u8],
    position: usize,
    child: Option<(usize, usize, usize)>,
}

impl Iterator for ObjectFrames<'_> {
    type Item = ObjectFrame;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            if let Some((start, end, position)) = self.child {
                let child = &self.bytes[start..end];
                let relative = position - start;
                if relative
                    .checked_add(8)
                    .is_some_and(|next| next <= child.len())
                {
                    if let Some((frame_end, family, class, object_id)) =
                        object_frame(child, relative)
                    {
                        if family == 0xb5 {
                            self.child = Some((start, end, start + frame_end));
                            return Some(ObjectFrame {
                                start: position,
                                end: start + frame_end,
                                family,
                                class,
                                object_id,
                            });
                        }
                    }
                }
                self.child = None;
            }
            if self
                .position
                .checked_add(8)
                .is_none_or(|next| next > self.bytes.len())
            {
                return None;
            }
            let position = self.position;
            let Some((end, family, class, object_id)) = object_frame(self.bytes, position) else {
                self.position += 1;
                continue;
            };
            match family {
                0xa8 => {
                    self.position = end;
                    if let Some(child_start) =
                        crate::families::a5a8::records::a8_nested_b5_run_start(
                            self.bytes, position, end,
                        )
                    {
                        self.child = Some((child_start, end, child_start));
                    }
                }
                0xb5 => self.position = end,
                _ => {
                    self.position += 1;
                    continue;
                }
            }
            return Some(ObjectFrame {
                start: position,
                end,
                family,
                class,
                object_id,
            });
        }
    }
}

/// Scan frames without allocating a frame index.
pub(in crate::families) fn object_stream_frames(
    bytes: &[u8],
) -> impl Iterator<Item = ObjectFrame> + '_ {
    ObjectFrames {
        bytes,
        position: 0,
        child: None,
    }
}

pub(in crate::families) fn collect_object_stream_frames(bytes: &[u8]) -> Vec<ObjectFrame> {
    object_stream_frames(bytes).collect::<Vec<_>>()
}

/// Return maximal contiguous top-level A8/B5 object-frame runs.
fn object_stream_run_ranges(bytes: &[u8]) -> Vec<Range<usize>> {
    let mut ranges = Vec::new();
    let mut position = 0usize;
    while position + 8 <= bytes.len() {
        let Some((end, _, _, _)) = object_frame(bytes, position) else {
            position += 1;
            continue;
        };
        let start = position;
        position = end;
        loop {
            if let Some((end, _, _, _)) = object_frame(bytes, position) {
                position = end;
                continue;
            }
            let coordinate_end = position.checked_add(15).filter(|&end| end <= bytes.len());
            let allocation_end = if let Some(end) = coordinate_end {
                crate::wire::records::scan_vertex_record_ranges(&bytes[position..end])
                    .eq(std::iter::once(0..15))
                    .then_some(end)
            } else {
                None
            };
            let Some(end) = allocation_end else {
                break;
            };
            position = end;
        }
        ranges.push(start..position);
    }
    ranges
}

/// Return runs that declare at least one face or loop topology root.
#[cfg(test)]
fn topology_root_run_ranges(bytes: &[u8]) -> Vec<Range<usize>> {
    let runs = object_stream_run_ranges(bytes);
    topology_root_run_ranges_from_runs(bytes, &runs)
}

fn topology_root_run_ranges_from_runs(bytes: &[u8], runs: &[Range<usize>]) -> Vec<Range<usize>> {
    let mut roots = Vec::new();
    for range in runs {
        if object_stream_frames(&bytes[range.clone()]).any(is_topology_root_frame) {
            roots.push(range.clone());
        }
    }
    roots
}

fn is_topology_root_frame(frame: ObjectFrame) -> bool {
    (frame.family == 0xb5 && frame.class == 0x5f)
        || ((frame.family == 0xb5 || frame.family == 0xa8) && frame.class == 0x62)
}

/// Partition one logical stream into independently resolved object populations.
pub(in crate::families) fn object_stream_populations<'stream>(
    stream: &'stream [u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Vec<std::borrow::Cow<'stream, [u8]>> {
    let mut stream_populations = StreamPopulations::new(stream);
    let topology_runs = topology_root_run_ranges_from_runs(stream, &stream_populations.runs);
    let mut owned_populations = HashMap::new();
    let mut claimed_isolated_ids = HashSet::new();
    for range in &topology_runs {
        let mut root_ids = HashSet::new();

        for frame in object_stream_frames(&stream[range.clone()]) {
            root_ids.insert(frame.object_id);
        }
        let population = stream_populations.population(range.clone());

        for frame in object_stream_frames(&population) {
            if !root_ids.contains(&frame.object_id) {
                claimed_isolated_ids.insert(frame.object_id);
            }
        }
        owned_populations.insert(range.start, population);
    }
    refusal.push_b5_population_bounded(stream_populations.bounded_runs);
    let mut populations = Vec::new();
    for range in stream_populations.runs {
        if let Some(population) = owned_populations.remove(&range.start) {
            populations.push(population);
            continue;
        }
        let claimed =
            object_frame(stream, range.start).is_some_and(|(end, family, class, object_id)| {
                end == range.end
                    && is_referenced_geometry_class(family, class)
                    && claimed_isolated_ids.contains(&object_id)
            });
        if !claimed {
            let population = std::borrow::Cow::Borrowed(&stream[range]);
            populations.push(population);
        }
    }
    populations
}

/// Unique object population selected across reconstructed logical streams.
pub(in crate::families) enum ObjectStreamSelection {
    /// Work budget ran out before a population could be chosen.
    Exhausted {
        /// Number of object runs observed before exhaustion.
        run_count: usize,
    },
    /// No unique topology-root (or unique unrooted) run.
    Unselected {
        /// Number of object runs in the reconstructed streams.
        run_count: usize,
        /// Records scanned across every run for census.
        census_records: Vec<B5Record>,
    },
    /// One topology-root population, or the unique unrooted run.
    Selected {
        /// Bytes of the selected run, with isolated referenced geometry appended.
        source: Vec<u8>,
        /// Frames of the selected population, rebased to `source`.
        frames: Vec<ObjectFrame>,
        /// Records of the selected population, rebased to `source`.
        records: Vec<B5Record>,
        /// Records scanned across every run for census.
        census_records: Vec<B5Record>,
        /// Number of object runs in the reconstructed streams.
        run_count: usize,
    },
}

#[cfg(test)]
impl ObjectStreamSelection {
    pub(in crate::families) fn run_count(&self) -> usize {
        match self {
            Self::Exhausted { run_count }
            | Self::Unselected { run_count, .. }
            | Self::Selected { run_count, .. } => *run_count,
        }
    }

    pub(in crate::families) fn selected(&self) -> bool {
        matches!(self, Self::Selected { .. })
    }

    pub(in crate::families) fn exhausted(&self) -> bool {
        matches!(self, Self::Exhausted { .. })
    }

    pub(in crate::families) fn source(&self) -> &[u8] {
        match self {
            Self::Selected { source, .. } => source,
            Self::Exhausted { .. } | Self::Unselected { .. } => &[],
        }
    }

    pub(in crate::families) fn records(&self) -> &[B5Record] {
        match self {
            Self::Selected { records, .. } => records,
            Self::Exhausted { .. } | Self::Unselected { .. } => &[],
        }
    }

    fn census_records(&self) -> &[B5Record] {
        match self {
            Self::Selected { census_records, .. } | Self::Unselected { census_records, .. } => {
                census_records
            }
            Self::Exhausted { .. } => &[],
        }
    }
}

struct IndexedObjectRun {
    stream_index: usize,
    range: Range<usize>,
    frame_range: Range<usize>,
    topology: bool,
}

/// Select one topology-root population, or one unrooted run when it is the
/// only object run in the reconstructed logical streams.
pub(in crate::families) fn select_object_stream_population(
    streams: &[impl AsRef<[u8]>],
    budget: Option<&WorkBudget>,
) -> ObjectStreamSelection {
    let mut stream_ranges = Vec::new();
    for stream in streams {
        let stream = stream.as_ref();
        stream_ranges.push(object_stream_run_ranges(stream));
    }
    let run_count = stream_ranges.iter().map(Vec::len).sum();
    let exhausted = || ObjectStreamSelection::Exhausted { run_count };
    let mut stream_frames = Vec::new();

    let mut runs = Vec::new();
    for (stream_index, (stream, ranges)) in streams.iter().zip(stream_ranges).enumerate() {
        let stream = stream.as_ref();
        let frames = collect_object_stream_frames(stream);
        if budget.is_some_and(|budget| !budget.charge_by(frames.len())) {
            return exhausted();
        }
        let mut frame_cursor = 0;
        for range in ranges {
            while frame_cursor < frames.len() && frames[frame_cursor].start < range.start {
                frame_cursor += 1;
            }
            let frame_start = frame_cursor;
            while frame_cursor < frames.len() && frames[frame_cursor].end <= range.end {
                frame_cursor += 1;
            }
            let frame_range = frame_start..frame_cursor;
            let topology = frames[frame_range.clone()]
                .iter()
                .copied()
                .any(is_topology_root_frame);
            runs.push(IndexedObjectRun {
                stream_index,
                range,
                frame_range,
                topology,
            });
        }
        stream_frames.push(frames);
    }
    let mut topology_runs = Vec::new();
    for (index, run) in runs.iter().enumerate() {
        if run.topology {
            topology_runs.push(index);
        }
    }
    let selected_run = match topology_runs.as_slice() {
        [index] => Some((*index, true)),
        [] if runs.len() == 1 => Some((0, false)),
        _ => None,
    };
    let Some((selected_index, topology)) = selected_run else {
        let mut census_records = Vec::new();
        for run in &runs {
            let frames = &stream_frames[run.stream_index][run.frame_range.clone()];
            let records = records_from_frames(streams[run.stream_index].as_ref(), frames, budget);
            if budget.is_some_and(WorkBudget::exhausted) {
                return exhausted();
            }

            census_records.extend(records);
        }
        return ObjectStreamSelection::Unselected {
            run_count,
            census_records,
        };
    };
    let selected = &runs[selected_index];
    let selected_stream = streams[selected.stream_index].as_ref();
    let selected_frames = &stream_frames[selected.stream_index][selected.frame_range.clone()];
    let Some(selected_records) =
        records_from_indexed_frames(selected_stream, selected_frames, budget)
    else {
        return exhausted();
    };
    let mut census_records = Vec::new();
    for record in &selected_records {
        let payload = record.payload.clone();
        census_records.push(B5Record {
            offset: record.offset,
            family: record.family,
            class: record.class,
            object_id: record.object_id,
            payload,
        });
    }
    for (index, run) in runs.iter().enumerate() {
        if index == selected_index {
            continue;
        }
        let frames = &stream_frames[run.stream_index][run.frame_range.clone()];
        let records = records_from_frames(streams[run.stream_index].as_ref(), frames, budget);
        if budget.is_some_and(WorkBudget::exhausted) {
            return exhausted();
        }

        census_records.extend(records);
    }
    let mut source = selected_stream[selected.range.clone()].to_vec();
    let mut frames = Vec::new();
    for frame in selected_frames {
        let mut frame = *frame;
        frame.start -= selected.range.start;
        frame.end -= selected.range.start;
        frames.push(frame);
    }
    let mut records = selected_records;
    for record in &mut records {
        record.offset -= selected.range.start;
    }
    if topology {
        let referenced = topology_surface_references(&records);
        let mut owned_ids = HashSet::new();
        for record in &records {
            owned_ids.insert(record.object_id);
        }
        let mut isolated = HashMap::<u32, Option<usize>>::new();
        for (index, run) in runs.iter().enumerate() {
            if index == selected_index || run.stream_index != selected.stream_index {
                continue;
            }
            let stream = streams[run.stream_index].as_ref();
            let Some((end, family, class, object_id)) = object_frame(stream, run.range.start)
            else {
                continue;
            };
            if end != run.range.end
                || owned_ids.contains(&object_id)
                || !referenced.contains(&object_id)
                || !is_referenced_geometry_class(family, class)
            {
                continue;
            }

            isolated
                .entry(object_id)
                .and_modify(|stored| {
                    if stored.is_some_and(|stored| {
                        let stored = &runs[stored];
                        streams[stored.stream_index].as_ref()[stored.range.clone()]
                            != stream[run.range.clone()]
                    }) {
                        *stored = None;
                    }
                })
                .or_insert(Some(index));
        }
        let mut isolated_values = Vec::new();
        for value in isolated.into_values().flatten() {
            isolated_values.push(value);
        }
        let mut isolated = isolated_values;
        isolated.sort_unstable_by(|left, right| {
            let left_run = &runs[*left];
            let right_run = &runs[*right];
            (left_run.stream_index, left_run.range.start)
                .cmp(&(right_run.stream_index, right_run.range.start))
        });
        for index in isolated {
            let run = &runs[index];
            let stream = streams[run.stream_index].as_ref();
            let run_frames = &stream_frames[run.stream_index][run.frame_range.clone()];
            let destination = source.len();
            source.extend_from_slice(&stream[run.range.clone()]);
            for frame in run_frames {
                let mut frame = *frame;
                frame.start = destination + frame.start - run.range.start;
                frame.end = destination + frame.end - run.range.start;
                frames.push(frame);
            }
        }
        if source.len() != selected.range.len() {
            records = records_from_frames(&source, &frames, None);
        }
    }
    ObjectStreamSelection::Selected {
        source,
        frames,
        records,
        census_records,
        run_count,
    }
}

/// Attached isolated-geometry bytes the topology runs of one logical stream may
/// copy into their populations, per stream byte.
pub(crate) const MAX_ATTACHED_GEOMETRY_PER_STREAM_BYTE: usize = 2;

/// The topology populations of one logical stream: its object runs, its
/// single-frame geometry runs by object id, and the attached bytes its
/// populations may still copy.
struct StreamPopulations<'stream> {
    stream: &'stream [u8],
    runs: Vec<Range<usize>>,
    /// An id stated by geometry runs of differing bytes maps to `None`.
    isolated: HashMap<u32, Option<Range<usize>>>,
    attach_allowance: usize,
    /// Topology runs read without their isolated geometry at the allowance.
    bounded_runs: usize,
}

impl<'stream> StreamPopulations<'stream> {
    fn new(stream: &'stream [u8]) -> Self {
        let runs = object_stream_run_ranges(stream);
        let mut isolated = HashMap::<u32, Option<Range<usize>>>::new();
        for range in &runs {
            let Some((end, frame_family, frame_class, object_id)) =
                object_frame(stream, range.start)
            else {
                continue;
            };
            if end != range.end || !is_referenced_geometry_class(frame_family, frame_class) {
                continue;
            }
            isolated
                .entry(object_id)
                .and_modify(|stored| {
                    if stored
                        .as_ref()
                        .is_some_and(|stored| stream[stored.clone()] != stream[range.clone()])
                    {
                        *stored = None;
                    }
                })
                .or_insert(Some(range.clone()));
        }
        let attach_allowance = stream
            .len()
            .checked_mul(MAX_ATTACHED_GEOMETRY_PER_STREAM_BYTE)
            .unwrap_or(stream.len());
        Self {
            stream,
            runs,
            isolated,
            attach_allowance,
            bounded_runs: 0,
        }
    }

    /// Build one topology population from its owning run and the uniquely
    /// stated geometry frames it references. A run never names its own
    /// single geometry frame: a run that references surfaces holds a face or
    /// loop root, so it is not a single geometry frame. Past the allowance the
    /// run is read alone and counted in `bounded_runs`.
    fn population(&mut self, topology_run: Range<usize>) -> std::borrow::Cow<'stream, [u8]> {
        let run = &self.stream[topology_run];
        let run_frames = collect_object_stream_frames(run);
        let run_records = records_from_frames(run, &run_frames, None);
        let referenced = topology_surface_references(&run_records);
        let mut owned_ids = HashSet::new();
        for record in &run_records {
            owned_ids.insert(record.object_id);
        }
        let mut isolated = Vec::new();
        for object_id in &referenced {
            if owned_ids.contains(object_id) {
                continue;
            }
            if let Some(Some(range)) = self.isolated.get(object_id) {
                isolated.push(range.clone());
            }
        }
        isolated.sort_by_key(|range| range.start);

        if isolated.is_empty() {
            return std::borrow::Cow::Borrowed(run);
        }
        let attached = isolated.iter().map(ExactSizeIterator::len).sum::<usize>();
        let Some(remaining) = self.attach_allowance.checked_sub(attached) else {
            self.bounded_runs += 1;
            return std::borrow::Cow::Borrowed(run);
        };
        self.attach_allowance = remaining;
        let mut population = run.to_vec();
        for range in isolated {
            population.extend_from_slice(&self.stream[range]);
        }
        std::borrow::Cow::Owned(population)
    }
}

fn record_references(record: &B5Record) -> impl Iterator<Item = u32> + '_ {
    let mut position = 0;
    let count = counted_cardinality(&record.payload, &mut position).unwrap_or_default();
    (0..count).map_while(move |_| wire::tokens::object_ref(&record.payload, &mut position, true))
}

fn topology_surface_references(records: &[B5Record]) -> HashSet<u32> {
    let mut surfaces = HashSet::new();
    for record in records {
        let reference = match record.class {
            0x5f => record_references(record).next(),
            0x62 => record_references(record).last(),
            _ => None,
        };
        if let Some(reference) = reference {
            surfaces.insert(reference);
        }
    }
    surfaces
}

fn is_referenced_geometry_class(family: u8, class: u8) -> bool {
    (family == 0xa8 && matches!(class, 0x25 | 0x32 | 0x34))
        || (family == 0xb5 && (matches!(class, 0x18..=0x21) || is_surface_class(class)))
}

fn is_reference_dependency_class(family: u8, class: u8) -> bool {
    is_referenced_geometry_class(family, class)
        || (family == 0xb5 && matches!(class, 0x05 | 0x06 | 0x14 | 0x23..=0x25 | 0x5d))
}

fn is_surface_class(class: u8) -> bool {
    matches!(
        class,
        0x27 | 0x28
            | 0x29
            | 0x2a
            | 0x2b
            | 0x2c
            | 0x2d
            | 0x2e
            | 0x30
            | 0x31
            | 0x34
            | 0x37
            | 0x38
            | 0x3b
    )
}

fn is_opaque_surface_class(class: u8) -> bool {
    matches!(class, 0x2c | 0x2e | 0x30 | 0x37 | 0x38 | 0x3b)
}

pub(crate) fn object_frame(bytes: &[u8], start: usize) -> Option<(usize, u8, u8, u32)> {
    if !matches!(bytes.get(start + 1), Some(0x03 | 0x13 | 0x83)) {
        return None;
    }
    let family = *bytes.get(start)?;
    let class = *bytes.get(start + 2)?;
    let (header, length, object_id) = match family {
        0xb5 => (
            8usize,
            usize::from(*bytes.get(start + 3)?),
            View::u32_le_at(bytes, start + 4)?,
        ),
        0xa8 => (
            11usize,
            usize::try_from(View::u32_le_at(bytes, start + 3)?).ok()?,
            View::u32_le_at(bytes, start + 7)?,
        ),
        _ => return None,
    };
    let end = start.checked_add(header)?.checked_add(length)?;
    (end <= bytes.len()).then_some((end, family, class, object_id))
}

fn is_topology_class(class: u8) -> bool {
    matches!(
        class,
        0x0e | 0x0f | 0x18 | 0x20 | 0x21 | 0x27 | 0x28 | 0x29 | 0x2b | 0x2d | 0x5e | 0x5f | 0x62
    )
}

fn parse_face(
    record: &B5FaceRecord,
    loops: &BTreeMap<u32, B5Loop>,
    surfaces: &BTreeMap<u32, B5Surface>,
    surface_aliases: &BTreeMap<u32, u32>,
) -> Option<B5Face> {
    let references = &record.references;
    let &surface = references.first()?;
    if !surfaces.contains_key(&surface) {
        return None;
    }
    canonical_surface_id(surface_aliases, surface)?;
    let mut loop_ids = Vec::new();
    for &reference in &references[1..] {
        if loops
            .get(&reference)
            .is_none_or(|loop_| loop_.surface != surface)
        {
            return None;
        }
        loop_ids.push(reference);
    }
    if loop_ids.is_empty() {
        return None;
    }
    Some(B5Face {
        object_id: record.object_id,
        surface,
        loops: loop_ids,
        terminal_control: record.terminal_control,
    })
}

fn parse_face_record(record: &B5Record) -> Option<B5FaceRecord> {
    if record.class != 0x5f {
        return None;
    }
    if let Some(count) = record
        .payload
        .first()
        .and_then(|lead| lead.checked_sub(0x80))
    {
        if count == 0 {
            return None;
        }
        let mut position = 1;
        let references = (0..count)
            .map(|_| wire::tokens::object_ref(&record.payload, &mut position, true))
            .collect::<Option<Vec<_>>>()?;
        let Some(&[terminal_control]) = record.payload.get(position..) else {
            return None;
        };
        let terminal_control = B5FramingControl::from_byte(terminal_control)?;
        Some(B5FaceRecord {
            object_id: record.object_id,
            references,
            terminal_control: Some(terminal_control),
        })
    } else {
        let references = uncounted_references(&record.payload)?;
        (!references.is_empty()).then_some(B5FaceRecord {
            object_id: record.object_id,
            references,
            terminal_control: None,
        })
    }
}

/// Read every structurally complete face record independently of target
/// resolution.
#[cfg(test)]
fn typed_face_records(bytes: &[u8]) -> BTreeMap<u32, B5FaceRecord> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_face_records_from_records(&records)
}

pub(in crate::families) fn typed_face_records_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5FaceRecord> {
    let mut faces = BTreeMap::new();
    for record in records {
        if let Some(face) = parse_face_record(record) {
            faces.insert(record.object_id, face);
        }
    }
    faces
}

/// Read every structurally complete loop record independently of target
/// resolution.
#[cfg(test)]
fn typed_loop_records(bytes: &[u8]) -> BTreeMap<u32, B5Loop> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_loop_records_from_records(&records)
}

pub(in crate::families) fn typed_loop_records_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5Loop> {
    let mut loops = BTreeMap::new();
    for record in records {
        if let Some(loop_) = parse_loop_record(record) {
            loops.insert(record.object_id, loop_);
        }
    }
    loops
}

/// Read every structurally complete physical-edge record independently of
/// topology resolution.
#[cfg(test)]
fn typed_edge_records(bytes: &[u8]) -> BTreeMap<u32, B5Edge> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_edge_records_from_records(&records)
}

pub(in crate::families) fn typed_edge_records_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5Edge> {
    let mut edges = BTreeMap::new();
    for record in records {
        if let Some(edge) = parse_edge(record) {
            edges.insert(record.object_id, edge);
        }
    }
    edges
}

/// Read every structurally complete vertex-incidence link independently of
/// topology resolution.
#[cfg(test)]
fn typed_vertex_incidence_links(bytes: &[u8]) -> BTreeMap<u32, B5VertexIncidenceLink> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_vertex_incidence_links_from_records(&records)
}

pub(in crate::families) fn typed_vertex_incidence_links_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5VertexIncidenceLink> {
    let mut links = BTreeMap::new();
    for record in records {
        if let Some(link) = parse_vertex_incidence_link(record) {
            links.insert(record.object_id, link);
        }
    }
    links
}

/// Read every structurally complete class-`21` pcurve independently of
/// support and topology resolution.
#[cfg(test)]
fn typed_class_21_pcurves(bytes: &[u8]) -> BTreeMap<u32, B5Pcurve> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_class_21_pcurves_from_records(&records)
}

pub(in crate::families) fn typed_class_21_pcurves_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5Pcurve> {
    let mut pcurves = BTreeMap::new();
    for record in records {
        if let Some(pcurve) = parse_pcurve(record) {
            pcurves.insert(record.object_id, pcurve);
        }
    }
    pcurves
}

/// Read every structurally complete parameter incidence independently of
/// curve, edge, and topology resolution.
#[cfg(test)]
fn typed_parameter_incidences(bytes: &[u8]) -> BTreeMap<u32, B5ParameterIncidence> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_parameter_incidences_from_records(&records)
}

pub(in crate::families) fn typed_parameter_incidences_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, B5ParameterIncidence> {
    let mut incidences = BTreeMap::new();
    for record in records {
        if let Some(incidence) = parameter_incidence(record) {
            incidences.insert(record.object_id, incidence);
        }
    }
    incidences
}

/// Read every structurally complete vertex-incidence roster independently of
/// member and topology resolution.
#[cfg(test)]
fn typed_vertex_incidence_rosters(bytes: &[u8]) -> BTreeMap<u32, Vec<u32>> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    let records = records_from_frames(bytes, &frames, None);
    typed_vertex_incidence_rosters_from_records(&records)
}

pub(in crate::families) fn typed_vertex_incidence_rosters_from_records(
    records: &[B5Record],
) -> BTreeMap<u32, Vec<u32>> {
    let mut rosters = BTreeMap::new();
    for record in records {
        if let Some(members) = counted_references(record, 0x05) {
            rosters.insert(record.object_id, members);
        }
    }
    rosters
}

/// Read each face's leading surface reference independently of its loop grammar.
#[cfg(test)]
fn face_surface_references(bytes: &[u8]) -> Vec<(u32, u32)> {
    let frames = object_stream_frames(bytes).collect::<Vec<_>>();
    face_surface_references_from_frames(bytes, &frames)
}

pub(in crate::families) fn face_surface_references_from_frames(
    bytes: &[u8],
    frames: &[ObjectFrame],
) -> Vec<(u32, u32)> {
    let mut references = Vec::new();
    for frame in frames {
        if frame.family != 0xb5 || frame.class != 0x5f {
            continue;
        }
        let payload = &bytes[frame.start + 8..frame.end];
        let Some(&lead) = payload.first() else {
            continue;
        };
        let mut position = usize::from(lead >= 0x80);
        if position == 1 && lead == 0x80 {
            continue;
        }
        let Some(surface) = wire::tokens::object_ref(payload, &mut position, true) else {
            continue;
        };
        references.push((frame.object_id, surface));
    }
    references
}

/// Return positive face-to-edge ownership from structurally complete face and
/// loop records, without requiring their referenced surfaces or p-curves to
/// resolve into a transferable graph.
pub(in crate::families) fn edge_face_references_from_frames(
    bytes: &[u8],
    frames: &[ObjectFrame],
) -> HashMap<u32, HashSet<u32>> {
    let records = records_from_frames(bytes, frames, None);
    let mut edge_ids = HashSet::new();
    for record in records
        .iter()
        .filter(|record| record.family == 0xb5 && record.class == 0x5e)
    {
        edge_ids.insert(record.object_id);
    }
    let loops = typed_loop_records_from_records(&records);
    let mut owners = HashMap::<u32, HashSet<u32>>::new();
    for (face, record) in typed_face_records_from_records(&records) {
        for loop_id in record.references.iter().skip(1) {
            let Some(loop_record) = loops.get(loop_id) else {
                continue;
            };
            for member in &loop_record.members {
                if edge_ids.contains(&member.edge) {
                    owners.entry(member.edge).or_default().insert(face);
                }
            }
        }
    }
    owners
}

fn parse_loop(
    record: &B5Loop,
    by_id: &HashMap<u32, &B5Record>,
    parsed_pcurves: &BTreeMap<u32, B5Pcurve>,
    opaque_pcurves: &BTreeMap<u32, B5OpaquePcurve>,
    implicit_pcurves: &BTreeMap<u32, u32>,
    surfaces: &BTreeMap<u32, B5Surface>,
) -> Option<B5Loop> {
    let surface = record.surface;
    if !surfaces.contains_key(&surface) {
        return None;
    }
    for member in &record.members {
        if (parsed_pcurves
            .get(&member.pcurve)
            .is_none_or(|pcurve| pcurve.surface != surface)
            && opaque_pcurves
                .get(&member.pcurve)
                .is_none_or(|pcurve| pcurve.surface != surface)
            && implicit_pcurves.get(&member.pcurve) != Some(&surface))
            || by_id.get(&member.edge)?.class != 0x5e
        {
            return None;
        }
    }
    Some(record.clone())
}

fn parse_loop_record(record: &B5Record) -> Option<B5Loop> {
    let (references, metadata, edge_controls) = loop_references_and_metadata(record)?;
    let &surface = references.last()?;
    let pairs = &references[..references.len() - 1];
    if pairs.len() / 2 != edge_controls.len() {
        return None;
    }
    let members = pairs
        .chunks_exact(2)
        .zip(edge_controls)
        .map(|(pair, controls)| B5LoopMember {
            pcurve: pair[0],
            edge: pair[1],
            controls,
        })
        .collect::<Vec<_>>();
    Some(B5Loop {
        object_id: record.object_id,
        members,
        metadata,
        surface,
    })
}

#[cfg(test)]
fn loop_references(record: &B5Record) -> Option<Vec<u32>> {
    loop_references_and_metadata(record).map(|(references, _, _)| references)
}

fn loop_references_and_metadata(record: &B5Record) -> LoopReferencesOutput {
    if record.class != 0x62 {
        return None;
    }
    let mut position = 0;
    let count = counted_cardinality(&record.payload, &mut position)?;
    if count < 3 || count % 2 == 0 {
        return None;
    }
    let references = (0..count)
        .map(|_| wire::tokens::object_ref(&record.payload, &mut position, true))
        .collect::<Option<Vec<_>>>()?;
    let edge_count = (count - 1) / 2;
    if counted_cardinality(&record.payload, &mut position) != Some(edge_count) {
        return None;
    }
    let bytes = record.payload.get(position..)?;
    let (metadata, edge_controls) = loop_metadata(bytes, edge_count)?;
    Some((references, metadata, edge_controls))
}

fn loop_metadata(bytes: &[u8], edge_count: usize) -> Option<(B5LoopMetadata, Vec<[i16; 3]>)> {
    let (controls_end, framing_controls) = (|| {
        let controls_len = edge_count.checked_mul(3)?.checked_mul(2)?;
        let controls_end = 3usize.checked_add(controls_len)?;
        let framing_controls = [
            B5FramingControl::from_byte(*bytes.first()?)?,
            B5FramingControl::from_byte(*bytes.get(1)?)?,
        ];
        Some((controls_end, framing_controls))
    })()?;
    if bytes.get(2) != Some(&0x03) || controls_end > bytes.len() {
        return None;
    }
    let edge_controls = bytes[3..controls_end]
        .chunks_exact(6)
        .map(|controls| {
            let mut view = View::over_retained(controls);
            let controls = [view.i16_le()?, view.i16_le()?, view.i16_le()?];
            controls
                .iter()
                .all(|control| matches!(control, -1 | 1))
                .then_some(controls)
        })
        .collect::<Option<Vec<_>>>()?;
    let extension = (|| -> Option<_> {
        Some(match bytes.get(controls_end..)? {
            [0x01] => None,
            extended if extended.len() == b5_loop_numeric_terminal::LEN => {
                let mut controls = [0; 6];
                controls[0] = *extended.get(b5_loop_numeric_terminal::LEAD)?;
                controls[1..].copy_from_slice(extended.get(
                    b5_loop_numeric_terminal::TRAILING_CONTROLS..b5_loop_numeric_terminal::BOUNDS,
                )?);
                if controls.iter().any(|control| control % 4 != 1) || controls[5] != 0x01 {
                    return None;
                }
                let mut view = View::over_retained(extended);
                view.seek(b5_loop_numeric_terminal::SCALARS)?;
                let scalars = [
                    FiniteReal::new(view.f64_le()?)?,
                    FiniteReal::new(view.f64_le()?)?,
                    FiniteReal::new(view.f64_le()?)?,
                    FiniteReal::new(view.f64_le()?)?,
                ];
                // Canonical compact bytes preserve decoded patch-ID order.
                if (controls[1], scalars[0].get()) > (controls[3], scalars[2].get())
                    || (controls[2], scalars[1].get()) > (controls[4], scalars[3].get())
                {
                    return None;
                }
                view.seek(b5_loop_numeric_terminal::BOUNDS)?;
                let floats = [
                    view.f32_le()?,
                    view.f32_le()?,
                    view.f32_le()?,
                    view.f32_le()?,
                    view.f32_le()?,
                    view.f32_le()?,
                ];
                if floats.iter().any(|value| !value.is_finite())
                    || floats.chunks_exact(2).any(|pair| pair[0] > pair[1])
                {
                    return None;
                }
                Some(B5LoopMetadataExtension {
                    scalars,
                    controls,
                    floats,
                })
            }
            _ => return None,
        })
    })();
    let extension = extension?;
    Some((
        B5LoopMetadata {
            framing_controls,
            extension,
        },
        edge_controls,
    ))
}

fn counted_cardinality(bytes: &[u8], position: &mut usize) -> Option<usize> {
    let lead = *bytes.get(*position)?;
    if lead >= 0x80 {
        *position += 1;
        Some(usize::from(lead - 0x80))
    } else {
        usize::try_from(wire::tokens::object_ref(bytes, position, true)?).ok()
    }
}

fn uncounted_references(bytes: &[u8]) -> Option<Vec<u32>> {
    let mut position = 0;
    let mut references = Vec::new();
    while position < bytes.len() {
        let reference = wire::tokens::object_ref(bytes, &mut position, true)?;
        references.push(reference);
    }
    Some(references)
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod nested_frame_work_tests {}
