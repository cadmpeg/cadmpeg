// SPDX-License-Identifier: Apache-2.0

use crate::families::b5::graph::tests::object_stream_pcurve;
use crate::families::b5::graph::{
    analytic_offset_magnitude_agrees, counted_cardinality, is_referenced_geometry_class,
    parse_extrusion_surface, parse_offset_surface, parse_profile, parse_sphere_great_circle_pcurve,
    parse_surface, surface_alias_target, B5ExtrusionDirectrix, B5ExtrusionSurface, B5OffsetSurface,
    B5OpaquePcurve, B5Pcurve, B5PcurveParameterization, B5Profile, B5Record,
    B5SphereGreatCirclePcurve, B5Surface,
};
use crate::wire;
use cadmpeg_ir::geometry::nurbs::NurbsSurface;
use std::collections::{BTreeMap, HashMap};

const OUTSIDE_DIRECTRIX_MARGIN: f64 = 1.0e-9;

fn evaluate_pcurve(pcurve: &B5Pcurve, parameter: f64) -> Option<[f64; 2]> {
    crate::test_support::with_service_context(|ctx| {
        super::super::evaluate_pcurve(ctx, pcurve, parameter)
    })
    .expect("evaluate pcurve")
}

use super::super::parse_line_pcurve;

use super::super::parse_circle_pcurve;

use super::super::parse_class_1a_pcurve;

#[allow(clippy::too_many_arguments)]
fn rational_arc_pcurve(
    record: &B5Record,
    surface: u32,
    center: [f64; 2],
    reference_x: [f64; 2],
    reference_y: [f64; 2],
    radius: f64,
    parameter_range: [f64; 2],
    angle_range: [f64; 2],
) -> Option<B5Pcurve> {
    super::super::rational_arc_pcurve(crate::families::b5::graph::RationalArcPcurveInputs {
        record,
        surface,
        center,
        reference_x,
        reference_y,
        radius,
        parameter_range,
        angle_range,
    })
}

use super::super::parse_opaque_pcurve;

#[test]
fn circle_pcurve_rejects_unbounded_subdivision_counts() {
    let mut payload = vec![0x81, 0x81];
    payload.extend_from_slice(&[0; 16]);
    payload.extend_from_slice(&[0x05, 0x05]);
    for value in [1.0e-300, 0.0, 1.0, 1.0, 0.0] {
        payload.extend_from_slice(&f64::to_le_bytes(value));
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x19,
        object_id: 0,
        payload,
    };
    assert!(parse_circle_pcurve(&record).is_none());
}

#[test]
fn rational_arc_pcurve_retains_an_interior_knot_in_a_wide_parameter_range() {
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x19,
        object_id: 7,
        payload: Vec::new(),
    };
    let pcurve = rational_arc_pcurve(
        &record,
        1,
        [0.0, 0.0],
        [1.0, 0.0],
        [0.0, 1.0],
        1.0,
        [-f64::MAX, f64::MAX],
        [0.0, std::f64::consts::PI],
    )
    .expect("wide parameter interval has finite interior knot");
    assert_eq!(
        pcurve
            .distinct_knots
            .iter()
            .map(|knot| knot.get())
            .collect::<Vec<_>>(),
        vec![-f64::MAX, 0.0, f64::MAX]
    );
}

#[test]
fn sparse_reference_tokens_fill_selected_id_bytes() {
    let mut position = 0;
    assert_eq!(
        wire::tokens::object_ref(&[0x28, 0x34, 0x02], &mut position, true),
        Some(0x02_0034)
    );
    assert_eq!(position, 3);
    position = 0;
    assert_eq!(
        wire::tokens::object_ref(&[0x20, 0x07], &mut position, true),
        Some(0x07_0000)
    );
    assert_eq!(position, 2);
    position = 0;
    assert_eq!(
        wire::tokens::object_ref(&[0x8b], &mut position, true),
        Some(11)
    );
    assert_eq!(position, 1);
}

#[test]
fn counted_cardinality_widens_with_reference_tokens() {
    let mut position = 0;
    assert_eq!(counted_cardinality(&[0x81], &mut position), Some(1));
    assert_eq!(position, 1);
    position = 0;
    assert_eq!(counted_cardinality(&[0x08, 0x81], &mut position), Some(129));
    assert_eq!(position, 2);
    position = 0;
    assert_eq!(
        counted_cardinality(&[0x18, 0x35, 0x01], &mut position),
        Some(309)
    );
    assert_eq!(position, 3);
}

#[test]
fn revolution_surface_requires_complete_sparse_reference_chart() {
    let mut payload = vec![0; 175];
    payload[0] = 0x81;
    payload[1..4].copy_from_slice(&[0x30, 0x86, 0x16]);
    payload[4..12].copy_from_slice(&1.0f64.to_le_bytes());
    payload[28..36].copy_from_slice(&1.0f64.to_le_bytes());
    payload[60..68].copy_from_slice(&1.0f64.to_le_bytes());
    payload[92..100].copy_from_slice(&1.0f64.to_le_bytes());
    for (offset, value) in [
        (100, 0.0f64),
        (108, 2.0 * std::f64::consts::PI),
        (116, -1.0),
        (124, 1.0),
        (134, 2.0),
        (142, 1.0),
        (150, 1.0),
        (158, 0.0),
        (167, 2.0 * std::f64::consts::PI),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    payload[132..134].copy_from_slice(&[0x05, 0x05]);
    payload[166] = 0x01;
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2d,
        object_id: 0x16_8601,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Revolution {
            profile_curve: 0x16_8600,
            axis_origin: crate::test_support::test_b5::point([1.0, 0.0, 0.0]),
            axis_direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            profile_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
            angular_range: crate::test_support::test_b5::increasing([
                0.0,
                2.0 * std::f64::consts::PI
            ]),
            angular_scale: crate::test_support::test_b5::positive(2.0)
        })
    );
    let mut left_handed = record.clone();
    left_handed.payload[92..100].copy_from_slice(&(-1.0f64).to_le_bytes());
    assert_eq!(parse_surface(&left_handed), None);
    let mut wrong_lead = record.clone();
    wrong_lead.payload[0] = 0x80;
    assert_eq!(parse_surface(&wrong_lead), None);
    let mut wrong_half_period = record;
    wrong_half_period.payload[167..175].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(parse_surface(&wrong_half_period), None);
}

#[test]
fn line_profile_requires_its_complete_unit_metric_chart() {
    let mut payload = vec![0; 73];
    payload[0] = 0x80;
    for (offset, values) in [(1, [1.0f64, 2.0, 3.0]), (25, [0.0, 0.0, 1.0])] {
        for (index, value) in values.into_iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    }
    payload[49..57].copy_from_slice(&1.0f64.to_le_bytes());
    payload[57..65].copy_from_slice(&(-2.0f64).to_le_bytes());
    payload[65..73].copy_from_slice(&4.0f64.to_le_bytes());
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x0e,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_profile(&record),
        Some(B5Profile::Line {
            point: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            direction: crate::test_support::test_b5::exact_unit([0.0, 0.0, 1.0]),
            parameter_range: crate::test_support::test_b5::increasing([-2.0, 4.0]),
        })
    );

    let mut nonunit = record.clone();
    nonunit.payload[41..49].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(parse_profile(&nonunit), None);
    let mut wrong_metric = record.clone();
    wrong_metric.payload[49..57].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(parse_profile(&wrong_metric), None);
    let mut unordered = record.clone();
    unordered.payload[65..73].copy_from_slice(&(-3.0f64).to_le_bytes());
    assert_eq!(parse_profile(&unordered), None);
    let mut wrong_lead = record;
    wrong_lead.payload[0] = 0x81;
    assert_eq!(parse_profile(&wrong_lead), None);
}

#[test]
fn arc_profile_requires_its_complete_centered_periodic_chart() {
    let mut payload = vec![0; 113];
    payload[0] = 0x80;
    for (offset, values) in [
        (1, [1.0f64, 2.0, 3.0]),
        (25, [1.0, 0.0, 0.0]),
        (49, [0.0, 1.0, 0.0]),
    ] {
        for (index, value) in values.into_iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    }
    let radius = 2.0f64;
    let parameter_range = [0.5 * radius, 1.5 * radius];
    let chart_origin =
        (parameter_range[0] + parameter_range[1]) * 0.5 - std::f64::consts::PI * radius;
    payload[73..81].copy_from_slice(&radius.to_le_bytes());
    payload[81..89].copy_from_slice(&parameter_range[0].to_le_bytes());
    payload[89..97].copy_from_slice(&parameter_range[1].to_le_bytes());
    payload[97..105].copy_from_slice(&1.0f64.to_le_bytes());
    payload[105..113].copy_from_slice(&chart_origin.to_le_bytes());
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x0f,
        object_id: 8,
        payload,
    };
    assert_eq!(
        parse_profile(&record),
        Some(B5Profile::Arc {
            center: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            direction_x: crate::test_support::test_b5::exact_unit([1.0, 0.0, 0.0]),
            direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
            radius: crate::test_support::test_b5::positive_length(radius),
            parameter_range: crate::test_support::test_b5::increasing(parameter_range),
        })
    );

    let mut nonorthogonal = record.clone();
    nonorthogonal.payload[49..57].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(parse_profile(&nonorthogonal), None);
    let mut overlong = record.clone();
    overlong.payload[89..97].copy_from_slice(
        &(parameter_range[0] + std::f64::consts::TAU * radius + 1.0).to_le_bytes(),
    );
    assert_eq!(parse_profile(&overlong), None);
    let mut wrong_fixed = record.clone();
    wrong_fixed.payload[97..105].copy_from_slice(&0.0f64.to_le_bytes());
    assert_eq!(parse_profile(&wrong_fixed), None);
    let mut wrong_origin = record;
    wrong_origin.payload[105..113].copy_from_slice(&0.0f64.to_le_bytes());
    assert_eq!(parse_profile(&wrong_origin), None);
}

#[test]
fn cone_surface_reads_the_native_slant_chart() {
    let mut payload = vec![0; 185];
    payload[0] = 0x80;
    for (offset, values) in [
        (1, [1.0f64, 2.0, 3.0]),
        (25, [1.0, 0.0, 0.0]),
        (49, [0.0, 1.0, 0.0]),
        (73, [0.0, 0.0, 1.0]),
    ] {
        for (index, value) in values.into_iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    }
    for (offset, value) in [
        (97, 0.25f64),
        (105, 4.0),
        (113, 0.5),
        (121, 0.5 + std::f64::consts::PI),
        (129, 0.0),
        (137, 8.0),
        (145, 3.0),
        (153, 1.0),
        (169, 0.5 - std::f64::consts::FRAC_PI_2),
        (177, 0.5 + 3.0 * std::f64::consts::FRAC_PI_2),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x29,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Cone {
            origin: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
            direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
            radial_angle: crate::test_support::test_b5::positive_angle(0.25),
            reference_radius: crate::test_support::test_b5::finite(4.0),
            slant_shift: crate::test_support::test_b5::finite(0.0),
            angular_range: crate::test_support::test_b5::increasing([
                0.5,
                0.5 + std::f64::consts::PI
            ]),
            slant_range: crate::test_support::test_b5::increasing([0.0, 8.0]),
            angular_scale: crate::test_support::test_b5::positive(3.0),
            angular_domain: crate::test_support::test_b5::increasing([
                0.5 - std::f64::consts::FRAC_PI_2,
                0.5 + 3.0 * std::f64::consts::FRAC_PI_2,
            ]),
            surface: Some(
                cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                    cadmpeg_ir::math::Point3::new(1.0, 2.0, 3.0),
                    cadmpeg_ir::math::Vector3::new(0.0, 0.0, 1.0),
                    cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0),
                    4.0,
                    1.0,
                    std::f64::consts::FRAC_PI_2 - 0.25,
                )
                .expect("the origin-chart cone carrier"),
            ),
        })
    );

    let mut opposite_handed = record.clone();
    opposite_handed.payload[89..97].copy_from_slice(&(-1.0f64).to_le_bytes());
    assert!(parse_surface(&opposite_handed).is_some());

    let mut malformed = record.clone();
    malformed.payload[169..177].copy_from_slice(&0.0f64.to_le_bytes());
    assert_eq!(parse_surface(&malformed), None);
    let mut degenerate = record.clone();
    degenerate.payload[97..105].copy_from_slice(&0.0_f64.to_le_bytes());
    assert_eq!(parse_surface(&degenerate), None);
    let mut nonunit = record.clone();
    nonunit.payload[25..33].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(parse_surface(&nonunit), None);
    let mut nonorthogonal = record.clone();
    nonorthogonal.payload[49..57].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(parse_surface(&nonorthogonal), None);
    let mut invalid_axis = record.clone();
    invalid_axis.payload[73..81].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(parse_surface(&invalid_axis), None);
    let mut wrong_lead = record;
    wrong_lead.payload[0] = 0x81;
    assert_eq!(parse_surface(&wrong_lead), None);
}

#[test]
fn plane_surface_requires_complete_unit_chart_frame() {
    let mut payload = vec![0; 121];
    payload[0] = 0x80;
    for (offset, value) in [
        (1usize, 1.0f64),
        (9, 2.0),
        (17, 3.0),
        (25, 1.0),
        (57, 1.0),
        (73, 1.0),
        (81, 1.0),
        (89, -4.0),
        (97, 8.0),
        (105, -2.0),
        (113, 6.0),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x27,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Plane {
            origin: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
            direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
            u_range: crate::test_support::test_b5::increasing([-4.0, 8.0]),
            v_range: crate::test_support::test_b5::increasing([-2.0, 6.0])
        })
    );
    let mut wrong_family = record.clone();
    wrong_family.family = 0xa8;
    assert_eq!(parse_surface(&wrong_family), None);

    let mut nonunit = record.clone();
    nonunit.payload[25..33].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(parse_surface(&nonunit), None);
    let mut parallel = record.clone();
    parallel.payload[49..57].copy_from_slice(&1.0f64.to_le_bytes());
    parallel.payload[57..65].copy_from_slice(&0.0f64.to_le_bytes());
    assert_eq!(parse_surface(&parallel), None);
    let mut reversed_range = record;
    reversed_range.payload[97..105].copy_from_slice(&(-5.0f64).to_le_bytes());
    assert_eq!(parse_surface(&reversed_range), None);
}

#[test]
fn cylinder_surface_retains_independent_angular_gauge_and_domain() {
    let radius = 6.0;
    let angular_factor = 2.0;
    let angular_scale = radius / angular_factor;
    let chart_origin = 1.0;
    let mut payload = vec![0; 137];
    payload[0] = 0x80;
    for (offset, value) in [
        (1usize, 1.0f64),
        (9, 2.0),
        (17, 3.0),
        (25, 1.0),
        (57, 1.0),
        (73, radius),
        (81, 2.0),
        (89, 10.0),
        (97, -4.0),
        (105, 5.0),
        (113, angular_factor),
        (121, 1.0),
        (129, chart_origin),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x28,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Cylinder {
            origin: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
            radius: crate::test_support::test_b5::positive_length(radius),
            u_range: crate::test_support::test_b5::increasing([2.0, 10.0]),
            v_range: crate::test_support::test_b5::increasing([-4.0, 5.0]),
            angular_scale: crate::test_support::test_b5::finite(angular_scale),
            chart_origin: crate::test_support::test_b5::finite(chart_origin)
        })
    );

    let mut outside_domain = record.clone();
    outside_domain.payload[89..97].copy_from_slice(
        &(chart_origin + std::f64::consts::TAU * angular_scale + 1.0).to_le_bytes(),
    );
    assert_eq!(parse_surface(&outside_domain), None);

    let mut overflowing_domain = record.clone();
    overflowing_domain.payload[73..81].copy_from_slice(&f64::MAX.to_le_bytes());
    overflowing_domain.payload[113..121].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(parse_surface(&overflowing_domain), None);

    let mut wrong_fixed_scalar = record;
    wrong_fixed_scalar.payload[121..129].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(parse_surface(&wrong_fixed_scalar), None);
}

#[test]
fn sphere_surface_validates_radius_scaled_frame_and_chart() {
    let construction_radius = 3.0;
    let azimuth_range = [0.0, 1.0];
    let chart_origin =
        construction_radius * ((azimuth_range[0] + azimuth_range[1]) * 0.5 - std::f64::consts::PI);
    let mut payload = vec![0; 153];
    payload[0] = 0x80;
    for (offset, value) in [
        (1usize, 1.0f64),
        (9, 2.0),
        (17, 3.0),
        (25, 2.0),
        (57, 2.0),
        (89, 2.0),
        (97, 2.0),
        (105, 0.0),
        (113, 1.0),
        (121, -1.0),
        (129, 1.0),
        (137, construction_radius),
        (145, chart_origin),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2a,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Sphere {
            center: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
            direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
            radius: crate::test_support::test_b5::positive_length(2.0),
            azimuth_range: crate::test_support::test_b5::increasing(azimuth_range),
            latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
            construction_radius: crate::test_support::test_b5::positive_length(construction_radius),
            chart_origin: crate::test_support::test_b5::finite(chart_origin)
        })
    );
    let tiny_radius = 1e-200_f64;
    let mut tiny = record.clone();
    for (offset, value) in [
        (25usize, tiny_radius),
        (57, tiny_radius),
        (89, tiny_radius),
        (97, tiny_radius),
    ] {
        tiny.payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    assert!(matches!(
        parse_surface(&tiny),
        Some(B5Surface::Sphere {
            frame,
            direction_y,
            radius,
            ..
        }) if frame == crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0])
            && direction_y == crate::test_support::test_b5::unit([0.0, 1.0, 0.0])
            && radius.get() == tiny_radius
    ));
    tiny.payload[25..33].copy_from_slice(&(2.0 * tiny_radius).to_le_bytes());
    assert_eq!(parse_surface(&tiny), None);

    let tiny_construction_radius = 1e-200_f64;
    let tiny_chart_origin = tiny_construction_radius
        * ((azimuth_range[0] + azimuth_range[1]) * 0.5 - std::f64::consts::PI);
    let mut tiny_chart = record.clone();
    tiny_chart.payload[137..145].copy_from_slice(&tiny_construction_radius.to_le_bytes());
    tiny_chart.payload[145..153].copy_from_slice(&tiny_chart_origin.to_le_bytes());
    assert!(parse_surface(&tiny_chart).is_some());
    tiny_chart.payload[145..153].copy_from_slice(&(tiny_chart_origin + f64::EPSILON).to_le_bytes());
    assert!(parse_surface(&tiny_chart).is_some());
    tiny_chart.payload[145..153].copy_from_slice(&1e-12_f64.to_le_bytes());
    assert_eq!(parse_surface(&tiny_chart), None);

    let mut left_handed = record.clone();
    left_handed.payload[89..97].copy_from_slice(&(-2.0f64).to_le_bytes());
    assert_eq!(parse_surface(&left_handed), None);

    let mut overlong_azimuth = record.clone();
    overlong_azimuth.payload[113..121]
        .copy_from_slice(&(std::f64::consts::TAU + 1.0).to_le_bytes());
    assert_eq!(parse_surface(&overlong_azimuth), None);

    let mut invalid_latitude = record.clone();
    invalid_latitude.payload[121..129].copy_from_slice(&(-std::f64::consts::PI).to_le_bytes());
    assert_eq!(parse_surface(&invalid_latitude), None);

    let mut wrong_chart_origin = record;
    wrong_chart_origin.payload[145..153].copy_from_slice(&0.0f64.to_le_bytes());
    assert_eq!(parse_surface(&wrong_chart_origin), None);
}

#[test]
fn torus_surface_separates_geometric_radii_from_chart_scales() {
    let mut payload = vec![0; 201];
    payload[0] = 0x80;
    for (offset, values) in [
        (1, [1.0f64, 2.0, 3.0]),
        (25, [1.0, 0.0, 0.0]),
        (49, [0.0, 1.0, 0.0]),
        (73, [0.0, 0.0, 1.0]),
    ] {
        for (index, value) in values.into_iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    }
    payload[97..105].copy_from_slice(&5.0f64.to_le_bytes());
    payload[105..113].copy_from_slice(&2.0f64.to_le_bytes());
    for (offset, value) in [
        (113, 0.0),
        (121, std::f64::consts::TAU),
        (129, 0.0),
        (137, std::f64::consts::TAU),
        (145, 0.0),
        (153, std::f64::consts::PI),
        (161, -std::f64::consts::FRAC_PI_2),
        (169, 3.0 * std::f64::consts::FRAC_PI_2),
    ] {
        payload[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    payload[177..185].copy_from_slice(&4.0f64.to_le_bytes());
    payload[185..193].copy_from_slice(&3.0f64.to_le_bytes());
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2b,
        object_id: 7,
        payload,
    };
    assert_eq!(
        parse_surface(&record),
        Some(B5Surface::Torus {
            center: crate::test_support::test_b5::point([1.0, 2.0, 3.0]),
            frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
            direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
            major_radius: crate::test_support::test_b5::positive_length(5.0),
            minor_radius: crate::test_support::test_b5::positive_length(2.0),
            major_angular_range: crate::test_support::test_b5::increasing([
                0.0,
                std::f64::consts::TAU
            ]),
            major_angular_domain: crate::test_support::test_b5::increasing([
                0.0,
                std::f64::consts::TAU
            ]),
            minor_angular_range: crate::test_support::test_b5::increasing([
                0.0,
                std::f64::consts::PI
            ]),
            minor_angular_domain: crate::test_support::test_b5::increasing([
                -std::f64::consts::FRAC_PI_2,
                3.0 * std::f64::consts::FRAC_PI_2,
            ]),
            major_scale: crate::test_support::test_b5::positive(4.0),
            minor_scale: crate::test_support::test_b5::positive(3.0)
        })
    );

    let mut malformed = record.clone();
    malformed.payload[129..137].copy_from_slice(&0.5f64.to_le_bytes());
    assert_eq!(parse_surface(&malformed), None);
    let mut left_handed = record.clone();
    left_handed.payload[89..97].copy_from_slice(&(-1.0f64).to_le_bytes());
    assert_eq!(parse_surface(&left_handed), None);
    let mut wrong_lead = record.clone();
    wrong_lead.payload[0] = 0x81;
    assert_eq!(parse_surface(&wrong_lead), None);
    let mut nonzero_tail = record;
    nonzero_tail.payload[200] = 1;
    assert_eq!(parse_surface(&nonzero_tail), None);
}

#[test]
fn torus_frames_admit_the_native_1e12_distance_band() {
    let mut payload = vec![0; 201];
    payload[0] = 0x80;
    let set = |payload: &mut Vec<u8>, offset: usize, values: &[f64]| {
        for (index, value) in values.iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    };
    set(&mut payload, 1, &[1.0, 2.0, 3.0]);
    set(&mut payload, 25, &[1.0, 0.0, 0.0]);
    set(&mut payload, 49, &[0.0, 1.0, 0.0]);
    set(
        &mut payload,
        97,
        &[
            5.0,
            2.0,
            0.0,
            std::f64::consts::TAU,
            0.0,
            std::f64::consts::TAU,
            0.0,
            std::f64::consts::PI,
            -std::f64::consts::FRAC_PI_2,
            3.0 * std::f64::consts::FRAC_PI_2,
            4.0,
            3.0,
        ],
    );
    let torus = |axis: [f64; 3]| {
        let mut payload = payload.clone();
        set(&mut payload, 73, &axis);
        parse_surface(&B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x2b,
            object_id: 7,
            payload,
        })
    };
    // One component 0.9e-12 from the cross product is inside the native
    // 1e-12 distance. The frame holds the stored axis and direction_x.
    let axis = [0.0, 0.9e-12, 1.0];
    let Some(B5Surface::Torus { frame, .. }) = torus(axis) else {
        panic!("the torus frame is admitted");
    };
    assert_eq!(
        *frame.axis().as_raw(),
        cadmpeg_ir::math::Vector3::from(axis)
    );
    assert_eq!(
        *frame.reference().as_raw(),
        cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0)
    );
    // One component 1.5e-12 from the cross product: inside the cone's 2e-12
    // band, outside the torus's 1e-12 band.
    assert_eq!(torus([0.0, 1.5e-12, 1.0]), None);
}

#[test]
fn line_pcurve_decodes_every_complete_mode() {
    let record = |mode: u8, values: &[f64]| {
        let mut payload = vec![0x81, 0x82, mode];
        for value in values {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x18,
            object_id: 7,
            payload,
        }
    };

    let general = parse_line_pcurve(&record(0x01, &[2.0, 3.0, 4.0, -2.0, 1.0, 5.0]))
        .expect("general line pcurve");
    assert_eq!(general.surface, 2);
    assert_eq!(
        general.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[1.0, 5.0])
    );
    assert_eq!(general.control_points, [[6.0, 1.0], [22.0, -7.0]]);
    let tiny = parse_line_pcurve(&record(0x01, &[0.0, 0.0, 1e-200, -1e-200, 1.0, 5.0]))
        .expect("tiny nonzero line direction");
    assert_eq!(tiny.control_points, [[1e-200, -1e-200], [5e-200, -5e-200]]);
    let mut wrong_family = record(0x01, &[2.0, 3.0, 4.0, -2.0, 1.0, 5.0]);
    wrong_family.family = 0xa8;
    assert!(parse_line_pcurve(&wrong_family).is_none());

    let constant_u =
        parse_line_pcurve(&record(0x05, &[3.0, -2.0, 7.0])).expect("constant-U pcurve");
    assert_eq!(
        constant_u.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[-2.0, 7.0])
    );
    assert_eq!(constant_u.control_points, [[3.0, -2.0], [3.0, 7.0]]);

    let constant_v =
        parse_line_pcurve(&record(0x09, &[3.0, -2.0, 7.0])).expect("constant-V pcurve");
    assert_eq!(
        constant_v.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[-2.0, 7.0])
    );
    assert_eq!(constant_v.control_points, [[-2.0, 3.0], [7.0, 3.0]]);
}

#[test]
fn line_pcurve_rejects_degenerate_or_unclosed_payloads() {
    let record = |mode: u8, values: &[f64]| {
        let mut payload = vec![0x81, 0x82, mode];
        for value in values {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x18,
            object_id: 7,
            payload,
        }
    };

    assert!(parse_line_pcurve(&record(0x01, &[2.0, 3.0, 0.0, 0.0, 1.0, 5.0])).is_none());
    assert!(parse_line_pcurve(&record(0x05, &[3.0, 2.0, 2.0])).is_none());
    assert!(parse_line_pcurve(&record(0x0d, &[3.0, -2.0, 7.0])).is_none());

    let mut tailed = record(0x09, &[3.0, -2.0, 7.0]);
    tailed.payload.push(0);
    assert!(parse_line_pcurve(&tailed).is_none());
}

#[test]
fn circle_pcurve_preserves_arc_length_parameterization() {
    let mut payload = vec![0x81, 0x18, 0x34, 0x12];
    for value in [0.0, 0.0, 2.0, 0.0, 2.0 * std::f64::consts::PI, 1.0, 0.0] {
        if payload.len() == 20 {
            payload.extend_from_slice(&[0x05, 0x05]);
        }
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x19,
        object_id: 0x1235,
        payload,
    };
    let pcurve = parse_circle_pcurve(&record).expect("circle pcurve");
    assert_eq!(pcurve.surface, 0x1234);
    assert_eq!(pcurve.degree, 2);
    assert_eq!(
        pcurve.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[
            0.0,
            std::f64::consts::PI,
            2.0 * std::f64::consts::PI
        ])
    );
    assert_eq!(pcurve.multiplicities, [3, 2, 3]);
    assert_eq!(pcurve.control_points.len(), 5);
    let weights = pcurve.weights.expect("rational weights");
    assert_eq!(weights.len(), 5);
    assert!((weights[1].get() - std::f64::consts::FRAC_1_SQRT_2).abs() < 1.0e-12);
    assert!((pcurve.control_points[0][0] - 2.0).abs() < 1.0e-12);
    assert!((pcurve.control_points[4][0] + 2.0).abs() < 1.0e-12);
    let mut wrong_family = record;
    wrong_family.family = 0xa8;
    assert!(parse_circle_pcurve(&wrong_family).is_none());
}

#[test]
fn class_1a_pcurve_uses_diameter_period_parameterization() {
    let mut payload = vec![0x81, 0x18, 0x34, 0x12];
    for value in [3.0_f64, 4.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    for value in [
        2.0_f64,
        0.0,
        std::f64::consts::FRAC_PI_2,
        0.0,
        std::f64::consts::PI,
        1.0,
        2.0 * std::f64::consts::PI,
    ] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x1a,
        object_id: 0x1235,
        payload,
    };
    let pcurve = parse_class_1a_pcurve(&record).expect("class-1a pcurve");
    assert_eq!(pcurve.surface, 0x1234);
    assert_eq!(
        pcurve.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[
            0.0,
            std::f64::consts::FRAC_PI_2,
            std::f64::consts::PI
        ])
    );
    assert_eq!(pcurve.multiplicities, [3, 2, 3]);
    assert_eq!(pcurve.control_points.len(), 5);
    assert_eq!(evaluate_pcurve(&pcurve, 0.0), Some([4.0, 4.0]));
    let end = evaluate_pcurve(&pcurve, std::f64::consts::PI).expect("end point");
    assert!((end[0] - 2.0).abs() < 1.0e-12);
    assert!((end[1] - 4.0).abs() < 1.0e-12);

    let diameter = 1e-200_f64;
    let period = std::f64::consts::PI * diameter;
    let mut tiny = record.clone();
    tiny.payload[22..30].copy_from_slice(&diameter.to_le_bytes());
    tiny.payload[54..62].copy_from_slice(&(period * 0.5).to_le_bytes());
    tiny.payload[70..78].copy_from_slice(&period.to_le_bytes());
    assert!(parse_class_1a_pcurve(&tiny).is_some());

    let wrong_period = 1e-13_f64;
    tiny.payload[54..62].copy_from_slice(&(wrong_period * 0.5).to_le_bytes());
    tiny.payload[70..78].copy_from_slice(&wrong_period.to_le_bytes());
    assert!(parse_class_1a_pcurve(&tiny).is_none());

    let mut wrong_family = record;
    wrong_family.family = 0xa8;
    assert!(parse_class_1a_pcurve(&wrong_family).is_none());
}

#[test]
fn class_1a_pcurve_accepts_a_finite_nonzero_diameter() {
    for diameter in [1e-200_f64, 1e200] {
        let period = std::f64::consts::PI * diameter;
        let mut payload = vec![0x81, 0x82];
        for value in [0.0_f64, 0.0] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        payload.extend_from_slice(&[0x05, 0x05]);
        for value in [
            diameter,
            0.0,
            std::f64::consts::FRAC_PI_2,
            0.0,
            period * 0.25,
            1.0,
            period,
        ] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        let record = B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x1a,
            object_id: 7,
            payload,
        };
        let pcurve = parse_class_1a_pcurve(&record).expect("class-1a pcurve");
        assert_eq!(
            pcurve.control_points[0],
            crate::test_support::test_b5::finite_vector([diameter * 0.5, 0.0])
        );
    }
}

#[test]
fn noncanonical_class_1a_payload_remains_opaque() {
    let mut payload = vec![0x81, 0x82];
    for value in [0.0_f64, 0.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    for value in [2.0_f64, 0.0, 1.0, 0.0, 1.0, 1.0, 3.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x1a,
        object_id: 7,
        payload,
    };
    assert!(parse_class_1a_pcurve(&record).is_none());
    assert!(parse_opaque_pcurve(&record).is_some());
}

#[test]
fn pcurve_evaluation_preserves_the_native_parameter() {
    let pcurve = B5Pcurve {
        object_id: 1,
        surface: 2,
        degree: 1,
        distinct_knots: crate::test_support::test_b5::finite_lane(&[-1.0, 1.0]),
        multiplicities: vec![2, 2],
        control_points: vec![
            crate::test_support::test_b5::finite_vector([2.0, 3.0]),
            crate::test_support::test_b5::finite_vector([4.0, 7.0]),
        ],
        weights: None,
        parameter_range: None,
        parameterization: B5PcurveParameterization::Native,
        class_21_suffix_scalar: None,
        lifted_endpoints: None,
    };
    assert_eq!(evaluate_pcurve(&pcurve, 0.0), Some([3.0, 5.0]));
    assert_eq!(evaluate_pcurve(&pcurve, -1.0), Some([2.0, 3.0]));
    assert_eq!(evaluate_pcurve(&pcurve, 1.0), Some([4.0, 7.0]));
}

#[test]
fn opaque_conic_pcurves_retain_support_identity_and_payload() {
    let mut ellipse = vec![0x81, 0x82];
    ellipse.extend_from_slice(&[0; 16]);
    ellipse.extend_from_slice(&[0x05, 0x05]);
    ellipse.extend_from_slice(&[0; 56]);
    let ellipse_record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x1a,
        object_id: 7,
        payload: ellipse.clone(),
    };
    assert_eq!(
        parse_opaque_pcurve(&ellipse_record),
        Some(B5OpaquePcurve {
            object_id: 7,
            surface: 2,
            class: 0x1a,
            payload: ellipse,
            sphere_great_circle: None,
        })
    );

    let mut class_1d = vec![0x81, 0x82];
    class_1d.extend_from_slice(&[0; 32]);
    class_1d.extend_from_slice(&[0x05, 0x81]);
    class_1d.extend_from_slice(&[0; 24]);
    class_1d.push(0x1d);
    class_1d.extend_from_slice(&[0; 40]);
    let class_1d_record = B5Record {
        class: 0x1d,
        payload: class_1d.clone(),
        ..ellipse_record
    };
    assert_eq!(
        parse_opaque_pcurve(&class_1d_record),
        Some(B5OpaquePcurve {
            object_id: 7,
            surface: 2,
            class: 0x1d,
            payload: class_1d,
            sphere_great_circle: None,
        })
    );
    let mut wrong_family = class_1d_record;
    wrong_family.family = 0xa8;
    assert_eq!(parse_opaque_pcurve(&wrong_family), None);
}

#[test]
fn class_1d_pcurve_decodes_a_sphere_great_circle_plane() {
    let radius = 5.0;
    let chart_scale = 8.0;
    let chart_origin = 11.0;
    let mut payload = vec![0x81, 0x82];
    for value in [
        chart_scale * 0.25,
        chart_scale * 1.25,
        chart_origin,
        chart_origin + std::f64::consts::TAU * chart_scale,
    ] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x05, 0x81]);
    for value in [2.0_f64, -1.0, 0.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.push(0x1d);
    for value in [chart_scale, -0.75, 1.0 / chart_scale, -1.25, 0.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x1d,
        object_id: 7,
        payload,
    };
    let sphere = B5Surface::Sphere {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(radius),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, 1.5]),
        latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        construction_radius: crate::test_support::test_b5::positive_length(chart_scale),
        chart_origin: crate::test_support::test_b5::finite(chart_origin),
    };

    assert_eq!(
        parse_sphere_great_circle_pcurve(&record, &sphere),
        Some(B5SphereGreatCirclePcurve {
            u_bounds: crate::test_support::test_b5::increasing([
                chart_scale * 0.25,
                chart_scale * 1.25
            ]),
            v_bounds: crate::test_support::test_b5::finite_pair([
                chart_origin,
                chart_origin + std::f64::consts::TAU * chart_scale,
            ]),
            chart_shift: crate::test_support::test_b5::finite(2.0),
            chart_scale: crate::test_support::test_b5::positive(chart_scale),
            slope: crate::test_support::test_b5::finite(-0.75),
            phase: crate::test_support::test_b5::finite(-1.25),
        })
    );

    let mut outside_surface_chart = record.clone();
    outside_surface_chart.payload[2..10].copy_from_slice(&(-1.0_f64).to_le_bytes());
    assert_eq!(
        parse_sphere_great_circle_pcurve(&outside_surface_chart, &sphere),
        None
    );

    let mut approximate_reciprocal = outside_surface_chart.clone();
    approximate_reciprocal.payload[2..10].copy_from_slice(&(chart_scale * 0.25).to_le_bytes());
    let reciprocal_offset = 2 + 32 + 2 + 24 + 1 + 16;
    approximate_reciprocal.payload[reciprocal_offset..reciprocal_offset + 8]
        .copy_from_slice(&f64::from_bits((1.0 / chart_scale).to_bits() + 1).to_le_bytes());
    assert_eq!(
        parse_sphere_great_circle_pcurve(&approximate_reciprocal, &sphere),
        None
    );

    let mut approximate_chart_scale = outside_surface_chart;
    approximate_chart_scale.payload[2..10].copy_from_slice(&(chart_scale * 0.25).to_le_bytes());
    let scale_offset = 2 + 32 + 2 + 24 + 1;
    approximate_chart_scale.payload[scale_offset..scale_offset + 8]
        .copy_from_slice(&f64::from_bits(chart_scale.to_bits() + 1).to_le_bytes());
    assert_eq!(
        parse_sphere_great_circle_pcurve(&approximate_chart_scale, &sphere),
        None
    );

    let mut rounded_surface_bounds = sphere;
    let rounded_lower = f64::from_bits(0.25_f64.to_bits() + 1);
    let B5Surface::Sphere { azimuth_range, .. } = &mut rounded_surface_bounds else {
        unreachable!()
    };
    *azimuth_range = crate::test_support::test_b5::increasing([rounded_lower, 1.5]);
    assert!(parse_sphere_great_circle_pcurve(&record, &rounded_surface_bounds).is_some());
}

#[test]
fn surface_aliases_require_their_complete_class_layout() {
    let alias = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2e,
        object_id: 9,
        payload: vec![0x38, 0x34, 0x12, 0x00],
    };
    assert_eq!(surface_alias_target(&alias), Some(0x1234));

    let counted = B5Record {
        payload: vec![0x81, 0x38, 0x34, 0x12, 0x00],
        ..alias.clone()
    };
    assert_eq!(surface_alias_target(&counted), Some(0x1234));

    let mut tailed = alias.clone();
    tailed.payload.push(0x05);
    assert_eq!(surface_alias_target(&tailed), None);

    let chart_alias = B5Record {
        class: 0x38,
        payload: vec![0x81, 0x38, 0x34, 0x12, 0x00, 0x05, 0x05, 0x09],
        ..alias
    };
    assert_eq!(surface_alias_target(&chart_alias), Some(0x1234));

    let mut truncated_chart_alias = chart_alias;
    truncated_chart_alias.payload.pop();
    assert_eq!(surface_alias_target(&truncated_chart_alias), None);
}

#[test]
fn offset_surface_separates_result_carrier_source_and_bounds() {
    let carrier = B5Surface::Plane {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let source = B5Surface::Plane {
        origin: crate::test_support::test_b5::point([0.0, 0.0, 0.5]),
        frame: crate::test_support::test_b5::plane_frame([0.0, 1.0, 0.0], [-1.0, 0.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([-1.0, 0.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let surfaces = BTreeMap::from([(2, carrier), (3, source)]);
    let mut payload = vec![0x82, 0x82, 0x83];
    payload.extend_from_slice(&(-0.5f64).to_le_bytes());
    payload.push(0x15);
    for value in [-2.0f64, 3.0, -4.0, 5.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x30,
        object_id: 9,
        payload,
    };
    assert_eq!(
        parse_offset_surface(&record, &surfaces, &BTreeMap::new(), &HashMap::new()),
        Some(B5OffsetSurface {
            object_id: 9,
            carrier_surface: 2,
            source_surface: 3,
            distance: crate::test_support::test_b5::finite(-0.5),
            carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Plane,
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 3.0],
                [-4.0, 5.0]
            ]),
        })
    );
}

#[test]
fn offset_surface_accepts_a_sphere_result_carrier() {
    let carrier = B5Surface::Sphere {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(2.0),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        construction_radius: crate::test_support::test_b5::positive_length(2.0),
        chart_origin: crate::test_support::test_b5::finite(-2.0),
    };
    let source = B5Surface::Sphere {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [0.0, 1.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([-1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(8.5),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        construction_radius: crate::test_support::test_b5::positive_length(8.5),
        chart_origin: crate::test_support::test_b5::finite(-2.0),
    };
    let surfaces = BTreeMap::from([(2, carrier), (3, source)]);
    let mut payload = vec![0x82, 0x82, 0x83];
    payload.extend_from_slice(&(-6.5_f64).to_le_bytes());
    payload.push(0x09);
    for value in [0.0_f64, 2.0, -2.0, 4.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x30,
        object_id: 9,
        payload,
    };

    assert_eq!(
        parse_offset_surface(&record, &surfaces, &BTreeMap::new(), &HashMap::new()),
        Some(B5OffsetSurface {
            object_id: 9,
            carrier_surface: 2,
            source_surface: 3,
            distance: crate::test_support::test_b5::finite(-6.5),
            carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Sphere,
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [0.0, 2.0],
                [-2.0, 4.0]
            ]),
        })
    );
}

#[test]
fn cone_frames_admit_the_native_distance_band_on_either_side_of_the_axis() {
    let mut payload = vec![0; 185];
    payload[0] = 0x80;
    let set = |payload: &mut Vec<u8>, offset: usize, values: &[f64]| {
        for (index, value) in values.iter().enumerate() {
            payload[offset + 8 * index..offset + 8 * index + 8]
                .copy_from_slice(&value.to_le_bytes());
        }
    };
    set(&mut payload, 1, &[1.0, 2.0, 3.0]);
    set(&mut payload, 25, &[1.0, 0.0, 0.0]);
    set(&mut payload, 49, &[0.0, 1.0, 0.0]);
    set(
        &mut payload,
        97,
        &[0.25, 4.0, 0.5, 0.5 + std::f64::consts::PI],
    );
    set(&mut payload, 129, &[2.0, 8.0, 3.0, 1.0, 0.0]);
    set(
        &mut payload,
        169,
        &[
            0.5 - std::f64::consts::FRAC_PI_2,
            0.5 + 3.0 * std::f64::consts::FRAC_PI_2,
        ],
    );
    let cone = |axis: [f64; 3]| {
        let mut payload = payload.clone();
        set(&mut payload, 73, &axis);
        parse_surface(&B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x29,
            object_id: 7,
            payload,
        })
    };
    // One component 1.5e-12 from the cross product: inside the 2e-12
    // distance, on either side of the axis. The carrier holds the stored
    // axis and direction_x.
    for axis in [[0.0, 1.5e-12, 1.0], [0.0, -1.5e-12, -1.0]] {
        let Some(B5Surface::Cone {
            surface: Some(surface),
            ..
        }) = cone(axis)
        else {
            panic!("the cone and its carrier are admitted");
        };
        assert_eq!(
            *surface.frame().axis().as_raw(),
            cadmpeg_ir::math::Vector3::from(axis)
        );
        assert_eq!(
            *surface.frame().reference().as_raw(),
            cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0)
        );
        assert_eq!(surface.radius().get(), 4.0 + 2.0 * 0.25_f64.cos());
    }
    // Two components 1.5e-12 from the cross product: about 2.1e-12 away.
    assert_eq!(cone([1.5e-12, 1.5e-12, 1.0]), None);
    // An apex whose axis point at the slant start overflows keeps the record
    // and has no carrier.
    let mut overflow = payload.clone();
    set(&mut overflow, 1, &[0.0, 0.0, f64::MAX]);
    set(&mut overflow, 73, &[0.0, 0.0, 1.0]);
    set(&mut overflow, 129, &[1.0e308, 1.5e308]);
    assert!(matches!(
        parse_surface(&B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x29,
            object_id: 7,
            payload: overflow,
        }),
        Some(B5Surface::Cone { surface: None, .. })
    ));
}

#[test]
fn offset_surface_does_not_infer_cone_construction_from_result_class() {
    let carrier = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(0.25),
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([-2.0, 4.0]),
        angular_scale: crate::test_support::test_b5::positive(3.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    let surfaces = BTreeMap::from([(2, carrier)]);
    let mut payload = vec![0x82, 0x82, 0x83];
    payload.extend_from_slice(&1.5_f64.to_le_bytes());
    payload.push(0x11);
    for value in [-3.0_f64, 3.0, -2.0, 4.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x30,
        object_id: 9,
        payload,
    };

    assert_eq!(
        parse_offset_surface(&record, &surfaces, &BTreeMap::new(), &HashMap::new()),
        None
    );
}

#[test]
fn analytic_offset_gate_requires_coaxial_equal_family_carriers() {
    let plane = |origin| B5Surface::Plane {
        origin: crate::test_support::test_b5::point(origin),
        frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    let tiny = 1e-200_f64;
    assert!(analytic_offset_magnitude_agrees(
        &plane([0.0, 0.0, tiny]),
        &plane([0.0; 3]),
        tiny
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &plane([0.0, 0.0, tiny]),
        &plane([0.0; 3]),
        1e-13
    ));

    let cylinder = |origin, radius| B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point(origin),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(radius),
        u_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU * radius]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(radius),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    assert!(analytic_offset_magnitude_agrees(
        &cylinder([0.0, 0.0, 4.0], 3.0),
        &cylinder([0.0; 3], 5.0),
        -2.0
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &cylinder([0.25, 0.0, 4.0], 3.0),
        &cylinder([0.0; 3], 5.0),
        -2.0
    ));
    assert!(analytic_offset_magnitude_agrees(
        &cylinder([0.0, 0.0, tiny], 2.0 * tiny),
        &cylinder([0.0; 3], tiny),
        tiny
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &cylinder([0.0, 0.0, tiny], 2.0 * tiny),
        &cylinder([0.0; 3], tiny),
        1e-13
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &cylinder([tiny, 0.0, tiny], 2.0 * tiny),
        &cylinder([0.0; 3], tiny),
        tiny
    ));

    let torus = |center, major_radius, minor_radius| B5Surface::Torus {
        center: crate::test_support::test_b5::point(center),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        major_radius: crate::test_support::test_b5::positive_length(major_radius),
        minor_radius: crate::test_support::test_b5::positive_length(minor_radius),
        major_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        major_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        minor_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        minor_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        major_scale: crate::test_support::test_b5::positive(major_radius),
        minor_scale: crate::test_support::test_b5::positive(minor_radius),
    };
    assert!(analytic_offset_magnitude_agrees(
        &torus([0.0; 3], 8.0, 3.0),
        &torus([0.0; 3], 8.0, 2.5),
        0.5
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &torus([0.0; 3], 9.0, 3.0),
        &torus([0.0; 3], 8.0, 2.5),
        0.5
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &torus([0.0; 3], 2.0 * tiny, 2.0 * tiny),
        &torus([0.0; 3], tiny, tiny),
        tiny
    ));

    let sphere = |center, radius| B5Surface::Sphere {
        center: crate::test_support::test_b5::point(center),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(radius),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        latitude_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        construction_radius: crate::test_support::test_b5::positive_length(radius),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    assert!(analytic_offset_magnitude_agrees(
        &sphere([0.0; 3], 2.0 * tiny),
        &sphere([0.0; 3], tiny),
        tiny
    ));
    assert!(!analytic_offset_magnitude_agrees(
        &sphere([1e-13, 0.0, 0.0], 2.0 * tiny),
        &sphere([0.0; 3], tiny),
        tiny
    ));
}

#[test]
fn offset_surface_accepts_an_identity_checked_class_31_cache() {
    assert!(is_referenced_geometry_class(0xb5, 0x31));
    let source = B5Surface::Nurbs(
        NurbsSurface::from_lanes(
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(
                [cadmpeg_ir::math::Point3::new(0.0, 0.0, 0.0); 4]
                    .chunks(2_usize)
                    .map(<[_]>::to_vec)
                    .collect(),
                None,
            ),
            false,
        )
        .expect("valid bilinear NURBS"),
    );
    let surfaces = BTreeMap::from([(3, source.clone()), (4, source)]);
    let mut cache_payload = vec![0x81, 0x84];
    for value in [-0.5f64, -2.0, -4.0, 3.0, 5.0] {
        cache_payload.extend_from_slice(&value.to_le_bytes());
    }
    let cache = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x31,
        object_id: 2,
        payload: cache_payload,
    };
    let records = HashMap::from([(2, &cache)]);
    let mut payload = vec![0x82, 0x82, 0x83];
    payload.extend_from_slice(&(-0.5f64).to_le_bytes());
    payload.push(0x01);
    for value in [-2.0f64, 3.0, -4.0, 5.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x30,
        object_id: 9,
        payload,
    };

    assert_eq!(
        parse_offset_surface(&record, &surfaces, &BTreeMap::new(), &records),
        Some(B5OffsetSurface {
            object_id: 9,
            carrier_surface: 2,
            source_surface: 3,
            distance: crate::test_support::test_b5::finite(-0.5),
            carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Cache,
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 3.0],
                [-4.0, 5.0]
            ]),
        })
    );
}

#[test]
fn extrusion_surface_uses_complete_sampled_map_reference_lift() {
    let mut pcurve_payload = vec![0x81, 0x86, 0x05];
    for value in [2.0f64, -3.0, 4.0] {
        pcurve_payload.extend_from_slice(&value.to_le_bytes());
    }
    let pcurve = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x18,
        object_id: 3,
        payload: pcurve_payload,
    };
    let mut wrapper_payload = vec![0x81, 0x83, 0x81, 0x01];
    for value in [-3.0f64, 4.0, 0.0] {
        wrapper_payload.extend_from_slice(&value.to_le_bytes());
    }
    wrapper_payload.push(0x01);
    let wrapper = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x24,
        object_id: 2,
        payload: wrapper_payload,
    };
    let mut directrix_payload = vec![0x82, 0x82, 0x84, 0x81, 0x15];
    for value in [-3.0f64, 4.0, 0.0, 10.0, 20.0] {
        directrix_payload.extend_from_slice(&value.to_le_bytes());
    }
    directrix_payload.push(0x82);
    for value in [-3.0_f64, 4.0, 20.0, 10.0, -3.0, 4.0, 0.0] {
        directrix_payload.extend_from_slice(&value.to_le_bytes());
    }
    directrix_payload.push(0x01);
    let directrix = B5Record {
        offset: 0,
        family: 0xa8,
        class: 0x25,
        object_id: 5,
        payload: directrix_payload,
    };
    let records = HashMap::from([(2, &wrapper), (3, &pcurve), (5, &directrix)]);
    let pcurves = BTreeMap::from([(4, object_stream_pcurve(7, vec![10.0, 20.0], None))]);
    let mut payload = vec![0x81, 0x85];
    for value in [0.0f64, 0.0, 1.0, -2.0, 6.0, 1.0, 0.0, -3.0, 4.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2c,
        object_id: 8,
        payload,
    };

    assert_eq!(
        parse_extrusion_surface(&record, &records, &pcurves),
        Some(B5ExtrusionSurface {
            object_id: 8,
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 6.0],
                [-3.0, 4.0]
            ]),
            directrix: B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 5,
                support: (6, 3, crate::test_support::test_b5::finite_pair([-3.0, 4.0])),
                parameter_range: crate::test_support::test_b5::increasing([-3.0, 4.0]),
            },
        })
    );
    let mut co_wrapper_payload = vec![0x81, 0x84, 0x81, 0x01];
    for value in [10.0_f64, 20.0, 0.0] {
        co_wrapper_payload.extend_from_slice(&value.to_le_bytes());
    }
    co_wrapper_payload.push(1);
    let co_wrapper = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x24,
        object_id: 9,
        payload: co_wrapper_payload,
    };
    for (reference, co_curve) in [(2, 4), (3, 4), (2, 9), (3, 9)] {
        let mut candidate = directrix.clone();
        candidate.payload[1] = 0x80 + reference;
        candidate.payload[2] = 0x80 + co_curve;
        let candidates = HashMap::from([
            (2, &wrapper),
            (3, &pcurve),
            (5, &candidate),
            (9, &co_wrapper),
        ]);
        let parsed = parse_extrusion_surface(&record, &candidates, &pcurves)
            .expect("either operand may be a wrapper");
        assert!(matches!(
            parsed.directrix,
            B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 5,
                support: (6, 3, _),
                ..
            }
        ));
    }
    for (offset, value) in [(4, 0x14), (45, 0x83), (1, 0x8f), (2, 0x8f)] {
        let mut candidate = directrix.clone();
        candidate.payload[offset] = value;
        let candidates = HashMap::from([(2, &wrapper), (3, &pcurve), (5, &candidate)]);
        assert!(parse_extrusion_surface(&record, &candidates, &pcurves).is_none());
    }
    let mut incomplete = directrix.clone();
    incomplete.payload = vec![0x82, 0x82, 0x84, 0];
    for value in [-3.0_f64, 4.0, 0.01] {
        incomplete.payload.extend_from_slice(&value.to_le_bytes());
    }
    incomplete.payload.push(1);
    let candidates = HashMap::from([(2, &wrapper), (3, &pcurve), (5, &incomplete)]);
    assert!(parse_extrusion_surface(&record, &candidates, &pcurves).is_none());

    // A sampled-map reference gauge does not inherit the class-24 jet-origin translation.
    let mut shifted_map = record.clone();
    shifted_map.payload[58..66].copy_from_slice(&10.0_f64.to_le_bytes());
    shifted_map.payload[66..74].copy_from_slice(&17.0_f64.to_le_bytes());
    let jet_records = HashMap::from([(2, &wrapper), (5, &directrix)]);
    let mut jet_pcurves = BTreeMap::from([(4, object_stream_pcurve(7, vec![10.0, 20.0], None))]);
    jet_pcurves.insert(3, object_stream_pcurve(6, vec![-3.0, 4.0], Some(7.0)));
    assert!(parse_extrusion_surface(&record, &jet_records, &jet_pcurves).is_some());
    assert!(parse_extrusion_surface(&shifted_map, &jet_records, &jet_pcurves).is_none());

    jet_pcurves.insert(
        3,
        object_stream_pcurve(6, vec![-3.0, -1.25, 0.5, 2.25, 4.0], Some(1.75)),
    );
    assert!(parse_extrusion_surface(&record, &jet_records, &jet_pcurves).is_some());
    shifted_map.payload[66..74].copy_from_slice(&11.75_f64.to_le_bytes());
    let tail = shifted_map.payload.len() - 2;
    shifted_map.payload[tail..].copy_from_slice(&[0x05, 0x11]);
    assert!(parse_extrusion_surface(&shifted_map, &jet_records, &jet_pcurves).is_none());

    let directrix_lower_bound = 2 + 7 * 8;
    let mut trimmed_interval = record.clone();
    trimmed_interval.payload[directrix_lower_bound..directrix_lower_bound + 8]
        .copy_from_slice(&(-2.0_f64).to_le_bytes());
    assert!(
        parse_extrusion_surface(&trimmed_interval, &records, &pcurves).is_some(),
        "the extrusion may use a strict subinterval of its directrix"
    );
    let mut outside_interval = record.clone();
    outside_interval.payload[directrix_lower_bound..directrix_lower_bound + 8]
        .copy_from_slice(&(-3.0_f64 - OUTSIDE_DIRECTRIX_MARGIN).to_le_bytes());
    assert_eq!(
        parse_extrusion_surface(&outside_interval, &records, &pcurves),
        None,
        "the active interval must remain inside the directrix domain"
    );

    for controls in [[0x05, 0x05], [0x01, 0x29], [0x05, 0x29]] {
        let mut candidate = record.clone();
        let tail = candidate.payload.len() - 2;
        candidate.payload[tail..].copy_from_slice(&controls);
        assert!(
            parse_extrusion_surface(&candidate, &records, &pcurves).is_some(),
            "terminal controls {controls:02x?}"
        );
    }
    for controls in [
        [0x01, 0x05],
        [0x05, 0x09],
        [0x05, 0x11],
        [0x05, 0x15],
        [0x05, 0x19],
        [0x01, 0x09],
        [0x01, 0x15],
        [0x01, 0x19],
        [0x09, 0x29],
    ] {
        let mut candidate = record.clone();
        let tail = candidate.payload.len() - 2;
        candidate.payload[tail..].copy_from_slice(&controls);
        assert_eq!(
            parse_extrusion_surface(&candidate, &records, &pcurves),
            None,
            "terminal controls {controls:02x?}"
        );
    }
}

#[test]
fn point_cell_refuses_positive_spatial_overflow() {
    let point =
        cadmpeg_ir::features::FinitePoint3::new(cadmpeg_ir::math::Point3::new(f64::MAX, 0.0, 0.0))
            .expect("finite point");
    let result = super::super::point_index(&[point]);
    assert!(matches!(
        result,
        Err(cadmpeg_core::CodecError::Malformed { .. })
    ));
}

#[test]
fn point_cell_refuses_negative_spatial_overflow() {
    let point =
        cadmpeg_ir::features::FinitePoint3::new(cadmpeg_ir::math::Point3::new(-f64::MAX, 0.0, 0.0))
            .expect("finite point");
    let result = super::super::point_index(&[point]);
    assert!(matches!(
        result,
        Err(cadmpeg_core::CodecError::Malformed { .. })
    ));
}

#[test]
fn point_cell_refuses_nonfinite_coordinate() {
    assert_eq!(super::super::point_cell([f64::NAN, 0.0, 0.0]), None);
}

#[test]
fn sampled_map_offset_uses_active_reference_range_inside_full_pcurve_domain() {
    let mut line_payload = vec![0x81, 0x86, 0x05];
    for value in [2.0_f64, 0.0, 1.0] {
        line_payload.extend_from_slice(&value.to_le_bytes());
    }
    let line = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x18,
        object_id: 1,
        payload: line_payload,
    };
    let map = B5Record {
        offset: 0,
        family: 0xa8,
        class: 0x25,
        object_id: 4,
        payload: crate::test_support::test_parameter_map::payload(17, true, 0.0),
    };
    let mut payload = vec![0x81, 0x84];
    for value in [0.25_f64, 0.75] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.push(0x05);
    for value in [0.5_f64, 0.0, 0.0, 1.0, 2.0, 3.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let offset = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x14,
        object_id: 5,
        payload,
    };
    let records = HashMap::from([(1, &line), (4, &map)]);
    let pcurves = BTreeMap::from([(2, object_stream_pcurve(7, vec![2.0, 3.0], None))]);
    let parsed = crate::test_support::with_service_context(|ctx| {
        super::super::parse_extrusion_directrix(ctx, &offset, &records, &pcurves)
    })
    .expect("bounded directrix parse")
    .expect("active map interval closes");
    let B5ExtrusionDirectrix::Offset {
        source,
        source_parameter_range,
        ..
    } = parsed.clone()
    else {
        panic!("offset source");
    };
    assert_eq!(source_parameter_range.endpoints(), [0.25, 0.75]);
    assert!(matches!(*source, B5ExtrusionDirectrix::SurfaceCurve {
        object_id: 4, support: (6, 1, _), parameter_range,
    } if parameter_range.endpoints() == [0.25, 0.75]));
    let source_extrusion = B5ExtrusionSurface {
        object_id: 9,
        direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
        parameter_bounds: crate::test_support::test_b5::increasing_bounds([
            [0.0, 1.0],
            [0.25, 0.75],
        ]),
        directrix: *source,
    };
    let carrier_extrusion = B5ExtrusionSurface {
        object_id: 10,
        direction: source_extrusion.direction,
        parameter_bounds: crate::test_support::test_b5::increasing_bounds([[0.0, 1.0], [2.0, 3.0]]),
        directrix: parsed,
    };
    assert!(super::super::extrusion_offset_construction_agrees(
        &source_extrusion,
        &carrier_extrusion,
        crate::test_support::test_b5::finite(0.5),
        crate::test_support::test_b5::increasing_bounds([[2.0, 3.0], [0.0, 1.0]]),
    ));
    let mut wrong = offset;
    wrong.payload[2..10].copy_from_slice(&0.0_f64.to_le_bytes());
    assert!(crate::test_support::with_service_context(|ctx| {
        super::super::parse_extrusion_directrix(ctx, &wrong, &records, &pcurves)
    })
    .expect("bounded directrix parse")
    .is_none());
}

mod circle;
