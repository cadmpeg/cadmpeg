// SPDX-License-Identifier: Apache-2.0

use crate::families::b5::graph::collect_object_stream_frames;
use crate::families::b5::graph::controls::{B5EdgeTerminalControl, B5VertexIncidenceControl};
use crate::families::b5::graph::propagate_vertex_points;
use crate::families::b5::graph::tests::object_stream_pcurve;
use crate::families::b5::graph::topology_surface_references;
use crate::families::b5::graph::ObjectFrame;
use crate::families::b5::graph::{
    a8_class21_pcurves, admit_dependency_records, edge_vertex_references, face_loop_owner_counts,
    framed_records, implicit_pcurve_bindings, is_referenced_geometry_class, object_stream_frames,
    object_stream_populations, object_stream_run_ranges, parameter_incidence, parse,
    parse_a8_class21_pcurve, parse_edge, parse_extrusion_surface, parse_flat, parse_from_frames,
    parse_from_records, parse_supported_surface, parse_vertex_incidence_link, records,
    records_from_frames, select_object_stream_population,
    supported_surface_parameters_match_carrier, supported_surface_pcurves_match, surface_node,
    targeted_geometry_graph, topology_root_run_ranges, topology_runs, typed_class_21_pcurves,
    typed_class_21_pcurves_from_records, typed_edge_records, typed_edge_records_from_records,
    typed_face_records, typed_face_records_from_records, typed_loop_records,
    typed_loop_records_from_records, typed_parameter_incidences,
    typed_parameter_incidences_from_records, typed_vertex_incidence_links,
    typed_vertex_incidence_links_from_records, typed_vertex_incidence_rosters,
    typed_vertex_incidence_rosters_from_records, B5Edge, B5ExtrusionDirectrix, B5ExtrusionSurface,
    B5IncidenceLane, B5OffsetSurface, B5Record, B5SupportedSurface, B5SupportedSurfaceParameters,
    B5Surface, B5VertexIncidenceLink,
};
use std::collections::{BTreeMap, HashMap};

fn parse_extrusion_directrix(
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    pcurves: &BTreeMap<u32, super::super::B5ObjectStreamPcurve>,
) -> Option<B5ExtrusionDirectrix> {
    crate::test_support::with_service_context(|ctx| {
        super::super::parse_extrusion_directrix(ctx, record, records, pcurves)
    })
    .expect("parse extrusion directrix")
}

fn parse_extrusion_surface_with_context(
    record: &B5Record,
    records: &HashMap<u32, &B5Record>,
    pcurves: &BTreeMap<u32, super::super::B5ObjectStreamPcurve>,
    offset_constructions: &[B5OffsetSurface],
    extrusion_surfaces: &BTreeMap<u32, B5ExtrusionSurface>,
) -> Option<B5ExtrusionSurface> {
    crate::test_support::with_service_context(|ctx| {
        super::super::parse_extrusion_surface_with_context(
            ctx,
            record,
            records,
            pcurves,
            offset_constructions,
            extrusion_surfaces,
        )
    })
    .expect("parse extrusion surface")
}

#[test]
fn contiguous_object_population_borrows_source_bytes() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let populations = object_stream_populations(&bytes, &mut crate::nurbs::LaneRefusals::new());
    assert_eq!(populations.len(), 1);
    assert!(matches!(populations[0], std::borrow::Cow::Borrowed(_)));
    assert_eq!(populations[0].as_ptr(), bytes.as_ptr());
    assert_eq!(&*populations[0], bytes);
}

#[test]
fn attached_population_bytes_append_the_detached_frame() {
    let original = crate::test_support::test_b5::b5_closed_triangle_stream();
    let isolated = object_stream_frames(&original)
        .find(|frame| is_referenced_geometry_class(frame.family, frame.class))
        .expect("referenced geometry frame");
    let mut bytes = original.clone();
    bytes.drain(isolated.start..isolated.end);
    bytes.push(0xff);
    bytes.extend_from_slice(&original[isolated.start..isolated.end]);
    let populations = object_stream_populations(&bytes, &mut crate::nurbs::LaneRefusals::new());
    assert_eq!(populations.len(), 1);
    assert!(matches!(populations[0], std::borrow::Cow::Owned(_)));
    let expected = original[..isolated.start]
        .iter()
        .chain(&original[isolated.end..])
        .chain(&original[isolated.start..isolated.end])
        .copied()
        .collect::<Vec<_>>();
    assert_eq!(&*populations[0], expected);
}

/// `surfaces` isolated surface frames, then `runs` topology runs whose faces
/// each reference every surface. Every run is separated from the next.
fn runs_sharing_isolated_surfaces(surfaces: u32, runs: u32) -> (Vec<u8>, Vec<u8>) {
    const LOOP: u32 = 9;
    let mut bytes = Vec::new();
    let mut surface_frames = Vec::new();
    for surface in 0..surfaces {
        let start = bytes.len();
        crate::test_support::test_b5::append_b5_record(&mut bytes, 0x27, 100 + surface, &[0; 200]);
        surface_frames.extend_from_slice(&bytes[start..]);
        bytes.push(0xff);
    }
    for run in 0..runs {
        for surface in 0..surfaces {
            let mut face = vec![0x82];
            face.extend_from_slice(&crate::test_support::test_b5::b5_object_ref(100 + surface));
            face.extend_from_slice(&crate::test_support::test_b5::b5_object_ref(LOOP));
            face.push(0x05);
            let id = 1000 + run * surfaces + surface;
            crate::test_support::test_b5::append_b5_record(&mut bytes, 0x5f, id, &face);
        }
        bytes.push(0xff);
    }
    (bytes, surface_frames)
}

#[test]
fn shared_isolated_surfaces_attach_until_the_stream_allowance() {
    const RUNS: usize = 16;
    let (bytes, surface_frames) = runs_sharing_isolated_surfaces(4, 16);
    let allowance = bytes.len() * crate::families::b5::graph::MAX_ATTACHED_GEOMETRY_PER_STREAM_BYTE;
    let attached_runs = allowance / surface_frames.len();
    assert!(attached_runs > 0 && attached_runs < RUNS);

    let mut refusal = crate::nurbs::LaneRefusals::new();
    let populations = object_stream_populations(&bytes, &mut refusal);
    assert_eq!(populations.len(), RUNS);
    for (index, population) in populations.iter().enumerate() {
        if index < attached_runs {
            assert!(matches!(population, std::borrow::Cow::Owned(_)));
            assert!(population.ends_with(&surface_frames));
        } else {
            assert!(matches!(population, std::borrow::Cow::Borrowed(_)));
        }
    }
    let notes = refusal.take_notes();
    let [note] = notes.as_slice() else {
        panic!("one bounded stream");
    };
    assert_eq!(
        note.code,
        crate::loss::CatiaLossCode::TopologyB5PopulationBounded.kind()
    );
    assert!(note
        .message
        .contains(&format!("{} topology runs were read", RUNS - attached_runs)));

    let mut refusal = crate::nurbs::LaneRefusals::new();
    crate::test_support::with_service_context(|ctx| topology_runs(ctx, &bytes, &mut refusal))
        .expect("resolve topology runs");
    let notes = refusal.take_notes();
    assert!(notes
        .iter()
        .any(|note| note.code == crate::loss::CatiaLossCode::TopologyB5PopulationBounded.kind()));
}

#[test]
fn isolated_surfaces_within_the_allowance_attach_without_a_loss() {
    let (bytes, surface_frames) = runs_sharing_isolated_surfaces(4, 1);
    let mut refusal = crate::nurbs::LaneRefusals::new();
    let populations = object_stream_populations(&bytes, &mut refusal);
    assert_eq!(populations.len(), 1);
    assert!(populations[0].ends_with(&surface_frames));
    assert_eq!(refusal.note_count(), 0);
}

#[test]
fn opaque_object_payload_bytes_form_one_population() {
    let mut bytes = Vec::new();
    crate::test_support::test_b5::append_b5_record(&mut bytes, 0x5f, 7, &[0; 200]);
    let populations = object_stream_populations(&bytes, &mut crate::nurbs::LaneRefusals::new());
    assert_eq!(populations.len(), 1);
    assert_eq!(&*populations[0], bytes);
}

#[test]
fn a8_class21_jet_decodes_a_piecewise_quintic_pcurve() {
    let mut payload = a8_class21_test_payload();

    let pcurve =
        crate::test_support::with_service_context(|ctx| parse_a8_class21_pcurve(ctx, 7, &payload))
            .expect("parse A8 class21 pcurve")
            .expect("complete class-21 jet");
    assert_eq!(pcurve.object_id, 7);
    assert_eq!(pcurve.surface, 3);
    assert_eq!(
        pcurve.distinct_knots,
        crate::test_support::test_b5::finite_lane(&[10.0, 20.0])
    );
    assert_eq!(pcurve.multiplicities, [6, 6]);
    assert_eq!(pcurve.control_points.len(), 6);
    assert_eq!(
        pcurve.parameter_range,
        Some(crate::test_support::test_b5::finite_pair([10.0, 20.0]))
    );
    assert_eq!(
        pcurve.class_21_suffix_scalar,
        Some(crate::test_support::test_b5::positive(10.0))
    );

    payload[6] = 0x0d;
    assert_eq!(
        crate::test_support::with_service_context(|ctx| parse_a8_class21_pcurve(ctx, 7, &payload))
            .expect("parse A8 class21 pcurve"),
        None
    );
}

fn a8_class21_large_test_payload(knot_count: usize) -> Vec<u8> {
    let mut payload = vec![0x81, 0x83, 0x01, 0x15, 0x01, 0x01, 0x08, 0x01, 0x20, 0x01];
    for index in 0..knot_count {
        payload.extend_from_slice(
            &f64::from(u32::try_from(index).expect("test knot index fits u32")).to_le_bytes(),
        );
    }
    payload.push(0x19);
    payload.extend(std::iter::repeat_n(0x0d, knot_count - 2));
    payload.push(0x19);
    for _ in 0..6 {
        for _ in 0..knot_count {
            payload.extend_from_slice(&0.0f64.to_le_bytes());
        }
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    for value in [0.0f64, 10.0, 1.0, 0.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x00, 0x07]);
    payload
}

#[test]
fn a8_class21_jet_uses_frame_extent_for_knot_count() {
    let knot_count = 8193;
    let payload = a8_class21_large_test_payload(knot_count);
    let pcurve =
        crate::test_support::with_service_context(|ctx| parse_a8_class21_pcurve(ctx, 7, &payload))
            .expect("parse A8 class21 pcurve")
            .expect("frame-sized class-21 jet");

    assert_eq!(pcurve.distinct_knots.len(), knot_count);
    assert_eq!(pcurve.multiplicities.len(), knot_count);
    assert_eq!(pcurve.control_points.len(), 6 * (knot_count - 1));
}

#[test]
fn a8_class21_jet_rejects_count_without_frame_extent() {
    let payload = vec![
        0x81, 0x83, 0x01, 0x15, 0x01, 0x01, 0x10, 0xff, 0xff, 0xff, 0xff, 0x01,
    ];

    assert_eq!(
        crate::test_support::with_service_context(|ctx| parse_a8_class21_pcurve(ctx, 7, &payload))
            .expect("parse A8 class21 pcurve"),
        None
    );
}

#[test]
fn a8_class21_scan_ignores_marker_shaped_nested_payload() {
    let child_payload = a8_class21_test_payload();
    let mut nested = vec![0xa8, 0x03, 0x21];
    nested.extend_from_slice(
        &u32::try_from(child_payload.len())
            .expect("small nested A8 payload")
            .to_le_bytes(),
    );
    nested.extend_from_slice(&7u32.to_le_bytes());
    nested.extend_from_slice(&child_payload);

    let mut wrapper = vec![0xa8, 0x03, 0x34];
    wrapper.extend_from_slice(
        &u32::try_from(nested.len())
            .expect("small wrapper A8 payload")
            .to_le_bytes(),
    );
    wrapper.extend_from_slice(&8u32.to_le_bytes());
    wrapper.extend_from_slice(&nested);

    let mut peer = vec![0xa8, 0x03, 0x21];
    peer.extend_from_slice(
        &u32::try_from(child_payload.len())
            .expect("small peer A8 payload")
            .to_le_bytes(),
    );
    peer.extend_from_slice(&9u32.to_le_bytes());
    peer.extend_from_slice(&child_payload);
    wrapper.extend_from_slice(&peer);

    let pcurves =
        crate::test_support::with_service_context(|ctx| a8_class21_pcurves(ctx, &wrapper))
            .expect("compute the A8 class21 pcurves");
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].object_id, 9);
}

#[test]
fn object_stream_frame_walk_descends_only_into_a8_b5_children() {
    let b5 = |class: u8, object_id: u32, payload: &[u8]| {
        let mut frame = vec![
            0xb5,
            0x03,
            class,
            u8::try_from(payload.len()).expect("fixture value fits u8"),
        ];
        frame.extend_from_slice(&object_id.to_le_bytes());
        frame.extend_from_slice(payload);
        frame
    };
    let nested_b5 = b5(0x5e, 7, &[0x00]);
    let mut wrapper = vec![0xa8, 0x03, 0x34];
    wrapper.extend_from_slice(
        &u32::try_from(nested_b5.len())
            .expect("small wrapper payload")
            .to_le_bytes(),
    );
    wrapper.extend_from_slice(&8u32.to_le_bytes());
    wrapper.extend_from_slice(&nested_b5);

    let mut nested_a8 = vec![0xa8, 0x03, 0x21];
    nested_a8.extend_from_slice(&1u32.to_le_bytes());
    nested_a8.extend_from_slice(&10u32.to_le_bytes());
    nested_a8.push(0x00);
    let peer_b5 = b5(0x5e, 9, &nested_a8);
    wrapper.extend_from_slice(&peer_b5);

    let frames = object_stream_frames(&wrapper).collect::<Vec<_>>();
    assert_eq!(
        frames
            .iter()
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 8), (0xb5, 0x5e, 7), (0xb5, 0x5e, 9)]
    );
}

#[test]
fn object_stream_frame_walk_ignores_marker_shaped_a8_payload_bytes() {
    let mut nested_b5 = vec![0xb5, 0x03, 0x5e, 0x01];
    nested_b5.extend_from_slice(&7u32.to_le_bytes());
    nested_b5.push(0x00);

    let mut payload = vec![0x00; 4];
    payload.extend_from_slice(&nested_b5);
    let mut wrapper = vec![0xa8, 0x03, 0x34];
    wrapper.extend_from_slice(
        &u32::try_from(payload.len())
            .expect("small wrapper payload")
            .to_le_bytes(),
    );
    wrapper.extend_from_slice(&8u32.to_le_bytes());
    wrapper.extend_from_slice(&payload);

    assert_eq!(
        object_stream_frames(&wrapper)
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 8)]
    );
}

#[test]
fn object_stream_frame_walk_requires_a_length_closed_a8_child_run() {
    let mut nested_b5 = vec![0xb5, 0x03, 0x5e, 0x01];
    nested_b5.extend_from_slice(&7u32.to_le_bytes());
    nested_b5.push(0x00);
    let mut wrapper = vec![0xa8, 0x03, 0x34];
    let payload_len = nested_b5.len() + 1;
    wrapper.extend_from_slice(
        &u32::try_from(payload_len)
            .expect("small wrapper payload")
            .to_le_bytes(),
    );
    wrapper.extend_from_slice(&8u32.to_le_bytes());
    wrapper.extend_from_slice(&nested_b5);
    wrapper.push(0x00);

    assert_eq!(
        object_stream_frames(&wrapper)
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 8)]
    );
}

#[test]
fn object_stream_frame_walk_ignores_marker_shaped_inline_surface_poles() {
    let mut bytes = crate::test_support::test_a5a8::a8_surface_stream();
    let mut nested_b5 = vec![0xb5, 0x03, 0x5e, 0x01];
    nested_b5.extend_from_slice(&7u32.to_le_bytes());
    nested_b5.push(0x00);
    bytes[11 + 100..11 + 100 + nested_b5.len()].copy_from_slice(&nested_b5);

    assert_eq!(
        object_stream_frames(&bytes)
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 0xdeca_fbad)]
    );
}

#[test]
fn object_stream_frame_walk_descends_after_inline_surface_poles() {
    let mut bytes = crate::test_support::test_a5a8::a8_surface_stream();
    let mut nested_b5 = vec![0xb5, 0x03, 0x5e, 0x01];
    nested_b5.extend_from_slice(&7u32.to_le_bytes());
    nested_b5.push(0x00);
    bytes.extend_from_slice(&nested_b5);
    let payload_len = u32::try_from(bytes.len() - 11).expect("small surface payload");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    assert_eq!(
        object_stream_frames(&bytes)
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 0xdeca_fbad), (0xb5, 0x5e, 7)]
    );
}

#[test]
fn object_stream_frame_walk_descends_after_inline_surface_tail() {
    let mut bytes = crate::test_support::test_a5a8::a8_inline_tail_surface_stream();
    let mut nested_b5 = vec![0xb5, 0x03, 0x5e, 0x01];
    nested_b5.extend_from_slice(&7u32.to_le_bytes());
    nested_b5.push(0x00);
    bytes.extend_from_slice(&nested_b5);
    let payload_len = u32::try_from(bytes.len() - 11).expect("small surface payload");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    assert_eq!(
        object_stream_frames(&bytes)
            .map(|frame| (frame.family, frame.class, frame.object_id))
            .collect::<Vec<_>>(),
        vec![(0xa8, 0x34, 0xdeca_fbad), (0xb5, 0x5e, 7)]
    );
}

#[test]
fn object_stream_runs_end_at_non_frame_bytes() {
    let frame = |object_id: u32| {
        let mut bytes = vec![0xb5, 0x03, 0x5e, 0x01];
        bytes.extend_from_slice(&object_id.to_le_bytes());
        bytes.push(0x00);
        bytes
    };
    let first = frame(7);
    let second = frame(9);
    let mut bytes = first.clone();
    bytes.push(0xff);
    bytes.extend_from_slice(&second);

    assert_eq!(
        object_stream_run_ranges(&bytes),
        vec![0..first.len(), first.len() + 1..bytes.len()]
    );
}

#[test]
fn object_stream_runs_cross_complete_vertex_allocations() {
    let mut bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    crate::test_support::test_b5::append_b5_record(&mut bytes, 0x5e, 900, &[]);

    assert_eq!(object_stream_run_ranges(&bytes), vec![0..bytes.len()]);
}

#[test]
fn object_stream_runs_include_complete_inline_surface_frames() {
    let bytes = crate::test_support::test_b5::a8_inline_surface_stream_with_native_vertex_chain();

    assert_eq!(object_stream_run_ranges(&bytes), vec![0..bytes.len()]);
}

#[test]
fn topology_parse_does_not_join_records_across_object_stream_runs() {
    let original = crate::test_support::test_b5::b5_closed_triangle_stream();
    let frames = object_stream_frames(&original).collect::<Vec<_>>();
    let split = frames[frames.len() / 2].start;
    let mut separated = original.clone();
    separated.insert(split, 0xff);

    let merged = crate::test_support::with_service_context(|ctx| {
        parse_flat(ctx, &separated, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("parse flat")
    .expect("flat scan can join the separated records");
    assert!(merged.complete);
    assert_ne!(
        crate::test_support::with_service_context(|ctx| parse(
            ctx,
            &separated,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse the B5 graph"),
        Some(merged)
    );
}

#[test]
fn topology_runs_retain_only_their_own_vertex_allocations() {
    let first = crate::test_support::test_b5::b5_closed_triangle_stream();
    let mut bytes = first.clone();
    bytes.push(0xff);
    bytes.extend_from_slice(&first);

    let graphs = crate::test_support::with_service_context(|ctx| {
        topology_runs(ctx, &bytes, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("parse the topology runs");
    assert_eq!(graphs.len(), 2);
    assert!(graphs
        .iter()
        .all(|(_, graph)| graph.vertices.raw_points().len() == 3));
}

#[test]
fn topology_parse_admits_one_referenced_isolated_geometry_frame() {
    let original = crate::test_support::test_b5::b5_closed_triangle_stream();
    let expected = crate::test_support::with_service_context(|ctx| {
        parse(ctx, &original, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("parse the B5 graph")
    .expect("closed source graph");
    let isolated = object_stream_frames(&original)
        .into_iter()
        .find(|frame| is_referenced_geometry_class(frame.family, frame.class))
        .expect("referenced geometry frame");
    let isolated_bytes = original[isolated.start..isolated.end].to_vec();
    let mut separated = original.clone();
    separated.drain(isolated.start..isolated.end);
    separated.push(0xff);
    separated.extend_from_slice(&isolated_bytes);

    assert_eq!(
        crate::test_support::with_service_context(|ctx| parse(
            ctx,
            &separated,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse the B5 graph"),
        Some(expected)
    );
    assert_eq!(
        object_stream_populations(&separated, &mut crate::nurbs::LaneRefusals::new()).len(),
        1
    );
}

#[test]
fn topology_parse_does_not_borrow_geometry_from_another_population() {
    let original = crate::test_support::test_b5::b5_closed_triangle_stream();
    let expected = crate::test_support::with_service_context(|ctx| {
        parse(ctx, &original, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("parse the B5 graph")
    .expect("closed source graph");
    let geometry = object_stream_frames(&original)
        .into_iter()
        .find(|frame| is_referenced_geometry_class(frame.family, frame.class))
        .expect("referenced geometry frame");
    let geometry_bytes = original[geometry.start..geometry.end].to_vec();
    let mut separated = original.clone();
    separated.drain(geometry.start..geometry.end);
    separated.push(0xff);
    separated.extend_from_slice(&geometry_bytes);
    crate::test_support::test_b5::append_b5_record(&mut separated, 0x5e, 900, &[]);

    assert_ne!(
        crate::test_support::with_service_context(|ctx| parse(
            ctx,
            &separated,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse the B5 graph"),
        Some(expected)
    );
    assert_eq!(
        object_stream_populations(&separated, &mut crate::nurbs::LaneRefusals::new()).len(),
        2
    );
}

#[test]
fn framed_records_ignore_marker_shaped_bytes_inside_b5_payloads() {
    let mut nested_a8 = vec![0xa8, 0x03, 0x62];
    nested_a8.extend_from_slice(&0u32.to_le_bytes());
    nested_a8.extend_from_slice(&7u32.to_le_bytes());

    let mut bytes = vec![
        0xb5,
        0x03,
        0x5f,
        u8::try_from(nested_a8.len()).expect("fixture value fits u8"),
    ];
    bytes.extend_from_slice(&8u32.to_le_bytes());
    bytes.extend_from_slice(&nested_a8);
    bytes.extend_from_slice(&[0xb5, 0x03, 0x5e, 0x01]);
    bytes.extend_from_slice(&9u32.to_le_bytes());
    bytes.push(0x00);

    let frames = object_stream_frames(&bytes).collect::<Vec<_>>();
    let records = framed_records(&bytes, &frames);
    assert_eq!(
        records
            .iter()
            .map(|record| (record.family, record.class, record.object_id))
            .collect::<Vec<_>>(),
        vec![(0xb5, 0x5f, 8), (0xb5, 0x5e, 9)]
    );
}

#[test]
fn wide_header_loop_is_a_topology_root_for_population_selection() {
    let mut bytes = vec![0xa8, 0x03, 0x62];
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&7u32.to_le_bytes());

    assert_eq!(topology_root_run_ranges(&bytes), vec![0..bytes.len()]);
    let selection = select_object_stream_population(&[bytes], None);
    assert!(selection.selected());
    assert!(!selection.source().is_empty());
}

#[test]
fn indexed_frame_parse_matches_one_shot_parse() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let frames = object_stream_frames(&bytes).collect::<Vec<_>>();
    let records = records_from_frames(&bytes, &frames, None);

    assert_eq!(
        crate::test_support::with_service_context(|ctx| parse(
            ctx,
            &bytes,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse the B5 graph"),
        crate::test_support::with_service_context(|ctx| parse_from_frames(
            ctx,
            &bytes,
            &frames,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse from frames")
    );
    assert_eq!(
        crate::test_support::with_service_context(|ctx| parse(
            ctx,
            &bytes,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse the B5 graph"),
        crate::test_support::with_service_context(|ctx| parse_from_records(
            ctx,
            &bytes,
            &records,
            &frames,
            true,
            None,
            &mut crate::nurbs::LaneRefusals::new()
        ))
        .expect("parse from records")
    );
    assert_eq!(
        typed_face_records(&bytes),
        typed_face_records_from_records(&records)
    );
    assert_eq!(
        typed_loop_records(&bytes),
        typed_loop_records_from_records(&records)
    );
    assert_eq!(
        typed_edge_records(&bytes),
        typed_edge_records_from_records(&records)
    );
    assert_eq!(
        typed_vertex_incidence_links(&bytes),
        typed_vertex_incidence_links_from_records(&records)
    );
    assert_eq!(
        typed_class_21_pcurves(&bytes),
        typed_class_21_pcurves_from_records(&records)
    );
    assert_eq!(
        typed_parameter_incidences(&bytes),
        typed_parameter_incidences_from_records(&records)
    );
    assert_eq!(
        typed_vertex_incidence_rosters(&bytes),
        typed_vertex_incidence_rosters_from_records(&records)
    );
}

#[test]
fn budgeted_dependency_admission_matches_one_shot_records() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let frames = object_stream_frames(&bytes).collect::<Vec<_>>();
    let expected = records_from_frames(&bytes, &frames, None);
    let budget = cadmpeg_core::decode::WorkBudget::new(10_000);

    let actual = records_from_frames(&bytes, &frames, Some(&budget));

    assert_eq!(actual, expected);
    assert!(!budget.exhausted());
}

#[test]
fn indexed_population_selection_preserves_records_and_census() {
    let topology = crate::test_support::test_b5::b5_closed_triangle_stream();
    let expected = select_object_stream_population(std::slice::from_ref(&topology), None);
    let budget = cadmpeg_core::decode::WorkBudget::new(100_000);
    let actual =
        { select_object_stream_population(std::slice::from_ref(&topology), Some(&budget)) };

    assert!(actual.selected());
    assert!(!actual.exhausted());
    assert_eq!(actual.source(), expected.source());
    assert_eq!(actual.records(), expected.records());
    assert_eq!(actual.census_records(), expected.census_records());
}

fn a8_class21_test_payload() -> Vec<u8> {
    let mut payload = vec![0x81, 0x83, 0x01, 0x15, 0x01, 0x01, 0x09, 0x01];
    for value in [10.0f64, 20.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x19, 0x19]);
    for channel in 0..6 {
        for station in 0..2 {
            payload.extend_from_slice(&(f64::from(channel * 2 + station)).to_le_bytes());
        }
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    for value in [0.0f64, 10.0, 1.0, 0.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x00, 0x07]);
    payload
}

#[test]
fn targeted_geometry_graph_closes_a_four_span_extrusion_without_topology() {
    let append_b5 = |bytes: &mut Vec<u8>, class, object_id: u32, payload: &[u8]| {
        bytes.extend_from_slice(&[
            0xb5,
            0x03,
            class,
            u8::try_from(payload.len()).expect("small B5 payload"),
        ]);
        bytes.extend_from_slice(&object_id.to_le_bytes());
        bytes.extend_from_slice(payload);
    };
    let append_a8 = |bytes: &mut Vec<u8>, class, object_id: u32, payload: &[u8]| {
        bytes.extend_from_slice(&[0xa8, 0x03, class]);
        bytes.extend_from_slice(
            &u32::try_from(payload.len())
                .expect("small A8 payload")
                .to_le_bytes(),
        );
        bytes.extend_from_slice(&object_id.to_le_bytes());
        bytes.extend_from_slice(payload);
    };
    let mut bytes = Vec::new();
    let mut plane = vec![0; 121];
    plane[0] = 0x80;
    for (offset, value) in [
        (25usize, 1.0f64),
        (57, 1.0),
        (73, 1.0),
        (81, 1.0),
        (89, -1.0),
        (97, 1.0),
        (105, -1.0),
        (113, 1.0),
    ] {
        plane[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
    }
    append_b5(&mut bytes, 0x27, 7, &plane);

    let knots = [0.0f64, 10.0, 20.0, 30.0, 40.0];
    let mut pcurve = vec![0x81, 0x87, 0x01, 0x15, 0x01, 0x01, 0x15, 0x01];
    for value in knots {
        pcurve.extend_from_slice(&value.to_le_bytes());
    }
    pcurve.extend_from_slice(&[0x19, 0x0d, 0x0d, 0x0d, 0x19]);
    for channel in 0..6 {
        for station in 0..knots.len() {
            pcurve.extend_from_slice(
                &f64::from(
                    u32::try_from(channel * knots.len() + station).expect("small channel station"),
                )
                .to_le_bytes(),
            );
        }
    }
    pcurve.extend_from_slice(&[0x05, 0x05]);
    for value in [0.0f64, 10.0, 1.0, 0.0] {
        pcurve.extend_from_slice(&value.to_le_bytes());
    }
    pcurve.extend_from_slice(&[0x00, 0x07]);
    append_a8(&mut bytes, 0x21, 3, &pcurve);

    let mut wrapper = vec![0x81, 0x83, 0x81, 0x01];
    for value in [0.0f64, 40.0, 0.0] {
        wrapper.extend_from_slice(&value.to_le_bytes());
    }
    wrapper.push(0x01);
    append_b5(&mut bytes, 0x24, 2, &wrapper);

    let mut extrusion = vec![0x81, 0x82];
    for value in [0.0f64, 0.0, 1.0, -2.0, 6.0, 1.0, 0.0, 0.0, 10.0] {
        extrusion.extend_from_slice(&value.to_le_bytes());
    }
    extrusion.extend_from_slice(&[0x05, 0x11]);
    append_b5(&mut bytes, 0x2c, 8, &extrusion);

    let graph =
        crate::test_support::with_service_context(|ctx| targeted_geometry_graph(ctx, &bytes))
            .expect("compute the targeted geometry graph")
            .expect("geometry-only graph");
    assert!(graph.faces.is_empty());
    assert_eq!(
        graph
            .extrusion_surfaces
            .get(&8)
            .map(|surface| surface.parameter_bounds),
        Some(crate::test_support::test_b5::increasing_bounds([
            [-2.0, 6.0],
            [0.0, 10.0]
        ]))
    );
    assert!(graph.pcurves.contains_key(&3));
}

#[test]
fn extrusion_reparameters_a_class21_surface_curve_from_validated_knot_spans() {
    let mut wrapper_payload = vec![0x81, 0x83, 0x81, 0x01];
    for value in [10.0f64, 20.0, 0.0] {
        wrapper_payload.extend_from_slice(&value.to_le_bytes());
    }
    wrapper_payload.push(0x01);
    let wrapper = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x24,
        object_id: 2,
        payload: wrapper_payload,
    };
    let records = HashMap::from([(2, &wrapper)]);
    let pcurves = BTreeMap::from([(
        3,
        object_stream_pcurve(7, vec![-10.0, 10.0, 20.0, 30.0], Some(10.0)),
    )]);
    let mut payload = vec![0x81, 0x82];
    for value in [0.0f64, 0.0, 1.0, -2.0, 6.0, 1.0, 0.0, 0.0, 10.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.extend_from_slice(&[0x05, 0x05]);
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2c,
        object_id: 8,
        payload,
    };

    assert_eq!(
        parse_extrusion_surface(&record, &records, &pcurves),
        Some(B5ExtrusionSurface {
            object_id: 8,
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 6.0],
                [0.0, 10.0]
            ]),
            directrix: B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 2,
                support: (
                    7,
                    3,
                    crate::test_support::test_b5::finite_pair([10.0, 20.0])
                ),
                parameter_range: crate::test_support::test_b5::increasing([0.0, 10.0]),
            },
        })
    );

    let mut nonunit_direction = record.clone();
    nonunit_direction.payload[2..10].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(
        parse_extrusion_surface(&nonunit_direction, &records, &pcurves),
        None
    );

    let mut translated_wrapper = wrapper.clone();
    translated_wrapper.payload[12..20].copy_from_slice(&50.0f64.to_le_bytes());
    let translated_records = HashMap::from([(2, &translated_wrapper)]);
    let translated_pcurves = BTreeMap::from([(
        3,
        object_stream_pcurve(
            7,
            vec![-10.0, 10.0, 20.0, 30.0, 40.0, 50.0, 70.0],
            Some(10.0),
        ),
    )]);
    let mut translated_control = record.clone();
    let tail = translated_control.payload.len() - 2;
    translated_control.payload[tail..].copy_from_slice(&[0x05, 0x11]);
    assert_eq!(
        parse_extrusion_surface(
            &translated_control,
            &translated_records,
            &translated_pcurves,
        ),
        Some(B5ExtrusionSurface {
            object_id: 8,
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [-2.0, 6.0],
                [0.0, 10.0]
            ]),
            directrix: B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 2,
                support: (
                    7,
                    3,
                    crate::test_support::test_b5::finite_pair([10.0, 50.0])
                ),
                parameter_range: crate::test_support::test_b5::increasing([0.0, 10.0]),
            },
        })
    );

    let missing_suffix = BTreeMap::from([(
        3,
        object_stream_pcurve(7, vec![-10.0, 10.0, 20.0, 30.0, 40.0, 50.0, 70.0], None),
    )]);
    assert_eq!(
        parse_extrusion_surface(&translated_control, &translated_records, &missing_suffix),
        None
    );
    let mismatched_suffix = BTreeMap::from([(
        3,
        object_stream_pcurve(
            7,
            vec![-10.0, 10.0, 20.0, 30.0, 40.0, 50.0, 70.0],
            Some(9.0),
        ),
    )]);
    assert_eq!(
        parse_extrusion_surface(&translated_control, &translated_records, &mismatched_suffix,),
        None
    );
    let mut mismatched_span = translated_control.clone();
    let active_end = 2 + 8 * 8;
    mismatched_span.payload[active_end..active_end + 8].copy_from_slice(&9.0f64.to_le_bytes());
    assert_eq!(
        parse_extrusion_surface(&mismatched_span, &translated_records, &translated_pcurves,),
        None
    );

    let nonuniform_pcurve = BTreeMap::from([(
        3,
        object_stream_pcurve(
            7,
            vec![-10.0, 10.0, 20.0, 31.0, 40.0, 50.0, 70.0],
            Some(10.0),
        ),
    )]);
    assert_eq!(
        parse_extrusion_surface(&translated_control, &translated_records, &nonuniform_pcurve,),
        None,
        "05 11 requires four uniform source spans"
    );
}

#[test]
fn extrusion_selects_the_terminal_span_of_a_direct_class20_pcurve() {
    let records = HashMap::new();
    for (controls, knots) in [
        ([0x05, 0x15], vec![0.0, 2.0, 5.0, 9.0, 12.0, 14.5]),
        ([0x05, 0x19], vec![0.0, 1.0, 3.0, 6.0, 10.0, 13.0, 15.5]),
    ] {
        let mut pcurve = object_stream_pcurve(7, knots.clone(), None);
        pcurve.class = 0x20;
        let pcurves = BTreeMap::from([(3, pcurve)]);
        let mut payload = vec![0x81, 0x83];
        for value in [0.0f64, 0.0, 1.0, -2.0, 6.0, 1.0, 0.0, 0.0, 2.5] {
            payload.extend_from_slice(&value.to_le_bytes());
        }
        payload.extend_from_slice(&controls);
        let record = B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x2c,
            object_id: 8,
            payload,
        };
        let source_range = [knots[knots.len() - 2], knots[knots.len() - 1]];

        assert_eq!(
            parse_extrusion_surface(&record, &records, &pcurves),
            Some(B5ExtrusionSurface {
                object_id: 8,
                direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
                parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                    [-2.0, 6.0],
                    [0.0, 2.5]
                ]),
                directrix: B5ExtrusionDirectrix::SurfaceCurve {
                    object_id: 3,
                    support: (
                        7,
                        3,
                        crate::test_support::test_b5::finite_pair(source_range)
                    ),
                    parameter_range: crate::test_support::test_b5::increasing([0.0, 2.5]),
                },
            })
        );

        let wrong_class = BTreeMap::from([(3, object_stream_pcurve(7, knots.clone(), None))]);
        assert_eq!(
            parse_extrusion_surface(&record, &records, &wrong_class),
            None
        );

        let mut wrong_span = record.clone();
        let active_end = 2 + 8 * 8;
        wrong_span.payload[active_end..active_end + 8].copy_from_slice(&2.0f64.to_le_bytes());
        assert_eq!(
            parse_extrusion_surface(&wrong_span, &records, &pcurves),
            None
        );

        let mut extra_knot = knots;
        extra_knot.insert(1, 0.5);
        let mut pcurve = object_stream_pcurve(7, extra_knot, None);
        pcurve.class = 0x20;
        let wrong_cardinality = BTreeMap::from([(3, pcurve)]);
        assert_eq!(
            parse_extrusion_surface(&record, &records, &wrong_cardinality),
            None
        );
    }
}

#[test]
fn offset_curve_directrix_binds_source_support_and_exact_ranges() {
    let mut source_payload = vec![0x81, 0x83, 0x81, 0x01];
    for value in [-3.0f64, 4.0, 0.0] {
        source_payload.extend_from_slice(&value.to_le_bytes());
    }
    source_payload.push(0x01);
    let source = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x24,
        object_id: 2,
        payload: source_payload,
    };
    let records = HashMap::from([(2, &source)]);
    let pcurves = BTreeMap::from([(3, object_stream_pcurve(7, vec![-3.0, 4.0], None))]);
    let mut payload = vec![0x81, 0x82];
    for value in [-3.0f64, 4.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    payload.push(0x05);
    for value in [-1.5f64, 0.0, 0.0, 1.0, -5.0, 6.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x14,
        object_id: 4,
        payload,
    };

    assert_eq!(
        parse_extrusion_directrix(&record, &records, &pcurves),
        Some(B5ExtrusionDirectrix::Offset {
            object_id: 4,
            source: Box::new(B5ExtrusionDirectrix::SurfaceCurve {
                object_id: 2,
                support: (7, 3, crate::test_support::test_b5::finite_pair([-3.0, 4.0])),
                parameter_range: crate::test_support::test_b5::increasing([-3.0, 4.0]),
            }),
            source_parameter_range: crate::test_support::test_b5::increasing([-3.0, 4.0]),
            distance: crate::test_support::test_b5::finite(-1.5),
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_range: crate::test_support::test_b5::increasing([-5.0, 6.0]),
        })
    );

    let mut nonunit_direction = record.clone();
    nonunit_direction.payload[27..35].copy_from_slice(&2.0f64.to_le_bytes());
    assert_eq!(
        parse_extrusion_directrix(&nonunit_direction, &records, &pcurves),
        None
    );

    let mut wrong_control = record.clone();
    wrong_control.payload[18] = 0x01;
    assert_eq!(
        parse_extrusion_directrix(&wrong_control, &records, &pcurves),
        None
    );
    let mut mismatched_range = record;
    mismatched_range.payload[1..9].copy_from_slice(&(-2.0f64).to_le_bytes());
    assert_eq!(
        parse_extrusion_directrix(&mismatched_range, &records, &pcurves),
        None
    );
}

#[test]
fn contextual_offset_extrusion_uses_the_class30_result_chart() {
    let mut source_payload = vec![0x81, 0x83, 0x81, 0x01];
    for value in [-3.0f64, 4.0, 0.0] {
        source_payload.extend_from_slice(&value.to_le_bytes());
    }
    source_payload.push(0x01);
    let source = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x24,
        object_id: 2,
        payload: source_payload,
    };
    let mut offset_payload = vec![0x81, 0x82];
    for value in [-3.0f64, 4.0] {
        offset_payload.extend_from_slice(&value.to_le_bytes());
    }
    offset_payload.push(0x05);
    for value in [-1.5f64, 0.0, 0.0, 1.0, -5.0, 6.0] {
        offset_payload.extend_from_slice(&value.to_le_bytes());
    }
    let offset_directrix = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x14,
        object_id: 4,
        payload: offset_payload,
    };
    let records = HashMap::from([(2, &source), (4, &offset_directrix)]);
    let pcurves = BTreeMap::from([(
        3,
        object_stream_pcurve(7, vec![-10.0, -3.0, 4.0, 10.0], Some(20.0)),
    )]);
    let source_extrusion = B5ExtrusionSurface {
        object_id: 10,
        direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
        parameter_bounds: crate::test_support::test_b5::increasing_bounds([[0.0, 1.0], [0.0, 7.0]]),
        directrix: B5ExtrusionDirectrix::SurfaceCurve {
            object_id: 2,
            support: (7, 3, crate::test_support::test_b5::finite_pair([-3.0, 4.0])),
            parameter_range: crate::test_support::test_b5::increasing([0.0, 7.0]),
        },
    };
    let source_extrusions = BTreeMap::from([(10, source_extrusion)]);
    let offset_construction = B5OffsetSurface {
        object_id: 11,
        carrier_surface: 8,
        source_surface: 10,
        distance: crate::test_support::test_b5::finite(-1.5),
        carrier_kind: crate::families::b5::graph::B5OffsetCarrierKind::Extrusion,
        parameter_bounds: crate::test_support::test_b5::increasing_bounds([
            [-5.0, 6.0],
            [2.0, 9.0],
        ]),
    };
    let mut carrier_payload = vec![0x81, 0x84];
    for value in [0.0f64, 0.0, 1.0, 2.0, 9.0, 1.0, 0.0, 5.0, 2.0] {
        carrier_payload.extend_from_slice(&value.to_le_bytes());
    }
    carrier_payload.extend_from_slice(&[0x01, 0x09]);
    let carrier = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x2c,
        object_id: 8,
        payload: carrier_payload,
    };

    assert_eq!(
        parse_extrusion_surface_with_context(
            &carrier,
            &records,
            &pcurves,
            std::slice::from_ref(&offset_construction),
            &source_extrusions,
        ),
        Some(B5ExtrusionSurface {
            object_id: 8,
            direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
            parameter_bounds: crate::test_support::test_b5::increasing_bounds([
                [2.0, 9.0],
                [-5.0, 6.0]
            ]),
            directrix: B5ExtrusionDirectrix::Offset {
                object_id: 4,
                source: Box::new(B5ExtrusionDirectrix::SurfaceCurve {
                    object_id: 2,
                    support: (7, 3, crate::test_support::test_b5::finite_pair([-3.0, 4.0])),
                    parameter_range: crate::test_support::test_b5::increasing([-3.0, 4.0]),
                }),
                source_parameter_range: crate::test_support::test_b5::increasing([-3.0, 4.0]),
                distance: crate::test_support::test_b5::finite(-1.5),
                direction: crate::test_support::test_b5::unit([0.0, 0.0, 1.0]),
                parameter_range: crate::test_support::test_b5::increasing([-5.0, 6.0]),
            },
        })
    );

    let mut wrong_distance = offset_construction.clone();
    wrong_distance.distance = crate::test_support::test_b5::finite(-1.0);
    assert_eq!(
        parse_extrusion_surface_with_context(
            &carrier,
            &records,
            &pcurves,
            &[wrong_distance],
            &source_extrusions,
        ),
        None
    );

    let mut wrong_bounds = offset_construction.clone();
    wrong_bounds.parameter_bounds[0] = crate::test_support::test_b5::increasing([-5.0, 7.0]);
    assert_eq!(
        parse_extrusion_surface_with_context(
            &carrier,
            &records,
            &pcurves,
            &[wrong_bounds],
            &source_extrusions,
        ),
        None
    );

    let auxiliary_start = 2 + 7 * 8;
    let mut increasing_auxiliary_scalars = carrier.clone();
    increasing_auxiliary_scalars.payload[auxiliary_start..auxiliary_start + 8]
        .copy_from_slice(&1.0f64.to_le_bytes());
    let increasing_pcurves = BTreeMap::from([(
        3,
        object_stream_pcurve(7, vec![-6.0, -3.0, 4.0, 20.0], Some(26.0)),
    )]);
    assert!(parse_extrusion_surface_with_context(
        &increasing_auxiliary_scalars,
        &records,
        &increasing_pcurves,
        std::slice::from_ref(&offset_construction),
        &source_extrusions,
    )
    .is_some());
    let mut five_knot_carrier = carrier.clone();
    *five_knot_carrier.payload.last_mut().expect("count control") = 0x15;
    let five_knot_pcurves = BTreeMap::from([(
        3,
        object_stream_pcurve(7, vec![-10.0, -3.0, -2.0, 0.0, 2.0, 4.0, 10.0], Some(20.0)),
    )]);
    assert!(parse_extrusion_surface_with_context(
        &five_knot_carrier,
        &records,
        &five_knot_pcurves,
        std::slice::from_ref(&offset_construction),
        &source_extrusions,
    )
    .is_some());
    let mut wrong_count = carrier.clone();
    *wrong_count.payload.last_mut().expect("count control") = 0x15;
    assert!(parse_extrusion_surface_with_context(
        &wrong_count,
        &records,
        &pcurves,
        std::slice::from_ref(&offset_construction),
        &source_extrusions,
    )
    .is_none());
    let missing_flanks = BTreeMap::from([(3, object_stream_pcurve(7, vec![-3.0, 4.0], Some(7.0)))]);
    assert!(parse_extrusion_surface_with_context(
        &carrier,
        &records,
        &missing_flanks,
        std::slice::from_ref(&offset_construction),
        &source_extrusions,
    )
    .is_none());
    let mut swapped_auxiliary_scalars = carrier;
    swapped_auxiliary_scalars.payload[auxiliary_start..auxiliary_start + 8]
        .copy_from_slice(&2.0f64.to_le_bytes());
    swapped_auxiliary_scalars.payload[auxiliary_start + 8..auxiliary_start + 16]
        .copy_from_slice(&5.0f64.to_le_bytes());
    assert_eq!(
        parse_extrusion_surface_with_context(
            &swapped_auxiliary_scalars,
            &records,
            &pcurves,
            std::slice::from_ref(&offset_construction),
            &source_extrusions,
        ),
        None
    );
}

#[test]
fn supported_surface_preserves_ordered_support_pcurves() {
    let pcurve0 = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x18,
        object_id: 5,
        payload: vec![0x81, 0x83],
    };
    let mut payload = vec![0x85, 0x82, 0x83, 0x84, 0x85, 0x86, 0x09, 0x05];
    payload.extend_from_slice(&2.5f64.to_le_bytes());
    payload.extend_from_slice(&[0x03, 0x05]);
    payload.extend_from_slice(&0.0f64.to_le_bytes());
    payload.extend_from_slice(&[0x01, 0x05]);
    let record = B5Record {
        class: 0x37,
        object_id: 7,
        payload,
        ..pcurve0.clone()
    };
    assert_eq!(
        parse_supported_surface(&record),
        Some(B5SupportedSurface {
            object_id: 7,
            carrier_surface: 2,
            support_surfaces: [3, 4],
            support_pcurves: [5, 6],
            parameters: B5SupportedSurfaceParameters::Radius {
                controls: [0x09, 0x05, 0x03, 0x05, 0x01, 0x05],
                construction_radius: crate::test_support::test_b5::positive_length(2.5),
            },
        })
    );
    let mut scalar_pair_payload = vec![0x85, 0x82, 0x83, 0x84, 0x85, 0x86];
    scalar_pair_payload.extend_from_slice(&[0x09, 0x01, 0x01, 0x05, 0x05, 0x0d]);
    scalar_pair_payload.extend_from_slice(&101.6f64.to_le_bytes());
    scalar_pair_payload.extend_from_slice(&20.0f64.to_le_bytes());
    let scalar_pair = B5Record {
        class: 0x3b,
        payload: scalar_pair_payload,
        ..record.clone()
    };
    assert_eq!(
        parse_supported_surface(&scalar_pair),
        Some(B5SupportedSurface {
            object_id: 7,
            carrier_surface: 2,
            support_surfaces: [3, 4],
            support_pcurves: [5, 6],
            parameters: B5SupportedSurfaceParameters::Chamfer(
                crate::families::chamfer::ChamferParameters::decode(
                    [0x09, 0x01, 0x01, 0x05, 0x05, 0x0d],
                    [
                        crate::test_support::test_b5::finite(101.6),
                        crate::test_support::test_b5::finite(20.0)
                    ]
                )
                .expect("valid chamfer")
            ),
        })
    );
    let scalar_pair = parse_supported_surface(&scalar_pair).expect("two-scalar supported surface");
    let plane = B5Surface::Plane {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::plane_frame([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        direction_v: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
    };
    assert!(supported_surface_parameters_match_carrier(
        &scalar_pair.parameters,
        &plane
    ));
    let cone_parameters = B5SupportedSurfaceParameters::Chamfer(
        crate::families::chamfer::ChamferParameters::decode(
            [0x05, 0x05, 0x01, 0x03, 0x05, 0x11],
            [
                crate::test_support::test_b5::finite(0.76),
                crate::test_support::test_b5::finite(std::f64::consts::FRAC_PI_4),
            ],
        )
        .expect("valid chamfer"),
    );
    let cone = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(std::f64::consts::FRAC_PI_4),
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        angular_scale: crate::test_support::test_b5::positive(1.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    assert!(supported_surface_parameters_match_carrier(
        &cone_parameters,
        &cone
    ));
    let other_cone_angle = B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: crate::test_support::test_b5::positive_angle(std::f64::consts::FRAC_PI_6),
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        angular_scale: crate::test_support::test_b5::positive(1.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    assert!(supported_surface_parameters_match_carrier(
        &cone_parameters,
        &other_cone_angle
    ));
    let construction = parse_supported_surface(&record).expect("supported surface");
    let pcurve0 = B5Record {
        object_id: 5,
        payload: vec![0x81, 0x83],
        ..pcurve0.clone()
    };
    let pcurve1 = B5Record {
        object_id: 6,
        payload: vec![0x81, 0x84],
        ..pcurve0.clone()
    };
    let records = HashMap::from([(5, &pcurve0), (6, &pcurve1)]);
    assert!(supported_surface_pcurves_match(
        &construction,
        &records,
        &HashMap::new()
    ));

    let wrong = B5Record {
        payload: vec![0x81, 0x82],
        ..pcurve1
    };
    assert!(!supported_surface_pcurves_match(
        &construction,
        &HashMap::from([(5, &pcurve0), (6, &wrong)]),
        &HashMap::new()
    ));
}

#[test]
fn supported_surface_parameter_matching_is_scale_independent() {
    let radius = 1e-200_f64;
    let parameters = B5SupportedSurfaceParameters::Radius {
        controls: [0x05, 0x05, 0x03, 0x03, 0x05, 0x05],
        construction_radius: crate::test_support::test_b5::positive_length(radius),
    };
    let cylinder = |carrier_radius| B5Surface::Cylinder {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(carrier_radius),
        u_range: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU * carrier_radius,
        ]),
        v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
        angular_scale: crate::test_support::test_b5::finite(carrier_radius),
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };
    let torus = |carrier_radius| B5Surface::Torus {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::exact_unit([0.0, 1.0, 0.0]),
        major_radius: crate::test_support::test_b5::positive_length(1.0),
        minor_radius: crate::test_support::test_b5::positive_length(carrier_radius),
        major_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        major_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        minor_angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        minor_angular_domain: crate::test_support::test_b5::increasing([
            0.0,
            std::f64::consts::TAU,
        ]),
        major_scale: crate::test_support::test_b5::positive(1.0),
        minor_scale: crate::test_support::test_b5::positive(carrier_radius),
    };
    let sphere = |carrier_radius| B5Surface::Sphere {
        center: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radius: crate::test_support::test_b5::positive_length(1.0),
        azimuth_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        latitude_range: crate::test_support::test_b5::increasing([
            -1.0,
            std::f64::consts::FRAC_PI_2,
        ]),
        construction_radius: carrier_radius,
        chart_origin: crate::test_support::test_b5::finite(0.0),
    };

    for (selector, closure, carrier) in [
        (0x05, 0x05, cylinder(radius)),
        (0x09, 0x05, torus(radius)),
        (
            0x0d,
            0x09,
            sphere(crate::test_support::test_b5::positive_length(radius)),
        ),
    ] {
        let mut parameters = parameters.clone();
        if let B5SupportedSurfaceParameters::Radius { controls, .. } = &mut parameters {
            controls[0] = selector;
            controls[5] = closure;
        }
        assert!(supported_surface_parameters_match_carrier(
            &parameters,
            &carrier
        ));
    }
    for (selector, closure, carrier) in [
        (0x05, 0x05, cylinder(2.0 * radius)),
        (0x09, 0x05, torus(2.0 * radius)),
        (
            0x0d,
            0x09,
            sphere(crate::test_support::test_b5::positive_length(2.0 * radius)),
        ),
    ] {
        let mut parameters = parameters.clone();
        if let B5SupportedSurfaceParameters::Radius { controls, .. } = &mut parameters {
            controls[0] = selector;
            controls[5] = closure;
        }
        assert!(!supported_surface_parameters_match_carrier(
            &parameters,
            &carrier
        ));
    }

    assert!(!supported_surface_parameters_match_carrier(
        &parameters,
        &torus(radius)
    ));
    let half_angle = 1e-200_f64;
    let cone_parameters = B5SupportedSurfaceParameters::Chamfer(
        crate::families::chamfer::ChamferParameters::decode(
            [0x05, 0x05, 0x01, 0x03, 0x05, 0x11],
            [
                crate::test_support::test_b5::finite(1.0),
                crate::test_support::test_b5::finite(half_angle),
            ],
        )
        .expect("valid chamfer"),
    );
    let cone = |carrier_radial_angle| B5Surface::Cone {
        origin: crate::test_support::test_b5::point([0.0; 3]),
        frame: crate::test_support::test_b5::frame([0.0, 0.0, 1.0], [1.0, 0.0, 0.0]),
        direction_y: crate::test_support::test_b5::unit([0.0, 1.0, 0.0]),
        radial_angle: carrier_radial_angle,
        reference_radius: crate::test_support::test_b5::finite(0.0),
        slant_shift: crate::test_support::test_b5::finite(0.0),
        angular_range: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        slant_range: crate::test_support::test_b5::increasing([0.0, 1.0]),
        angular_scale: crate::test_support::test_b5::positive(1.0),
        angular_domain: crate::test_support::test_b5::increasing([0.0, std::f64::consts::TAU]),
        surface: None,
    };
    assert!(supported_surface_parameters_match_carrier(
        &cone_parameters,
        &cone(crate::test_support::test_b5::positive_angle(half_angle))
    ));
    assert!(supported_surface_parameters_match_carrier(
        &cone_parameters,
        &cone(crate::test_support::test_b5::positive_angle(
            2.0 * half_angle
        ))
    ));
}

mod topology_walk;

#[test]
fn populations_split_each_logical_stream_run() {
    let triangle = crate::test_support::test_b5::b5_closed_triangle_stream();
    let mut bytes = vec![0; 16];
    for _ in 0..16 {
        bytes.extend_from_slice(&triangle);
        bytes.extend_from_slice(&[0; 16]);
    }
    let populations = object_stream_populations(&bytes, &mut crate::nurbs::LaneRefusals::new());
    assert_eq!(populations.len(), 16);
    assert!(populations.iter().all(|population| *population == triangle));
}

#[test]
fn indexed_duplicate_records_collapse_to_one_record() {
    let mut bytes = Vec::new();
    let payload = vec![0x00; 128];
    for _ in 0..16 {
        crate::test_support::test_b5::append_b5_record(&mut bytes, 0x5f, 7, &payload);
    }
    let frames = object_stream_frames(&bytes).collect::<Vec<_>>();
    let records = crate::families::b5::graph::indexed_topology_records_and_dependency_candidates(
        &bytes, &frames, None,
    )
    .expect("complete indexed records")
    .0;
    assert_eq!(records.len(), 1);
    assert_eq!(records[0].payload, payload);
}

#[test]
fn dependency_closure_admits_each_identity_once_through_back_references() {
    use crate::test_support::test_b5::{append_b5_record, b5_object_ref};
    const COUNT: u32 = 64;
    let mut bytes = Vec::new();
    for id in 1..=COUNT {
        let next = if id == COUNT { 1 } else { id + 1 };
        let mut payload = vec![0x82];
        payload.extend_from_slice(&b5_object_ref(0));
        payload.extend_from_slice(&b5_object_ref(next));
        append_b5_record(&mut bytes, 0x18, id, &payload);
    }
    let candidates = object_stream_frames(&bytes)
        .map(|frame| (frame.object_id, Some(frame)))
        .collect::<HashMap<_, _>>();
    let mut payload = vec![0x81];
    payload.extend_from_slice(&b5_object_ref(1));
    let root = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x5f,
        object_id: 0,
        payload,
    };
    let records = admit_dependency_records(&bytes, &mut vec![root.clone()], &candidates, None);
    assert_eq!(
        records
            .iter()
            .map(|record| record.object_id)
            .collect::<Vec<_>>(),
        (0..=COUNT).collect::<Vec<_>>()
    );
}

#[test]
fn collected_object_frames_match_the_frame_scan() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let admitted = collect_object_stream_frames(&bytes);
    let scanned = object_stream_frames(&bytes).collect::<Vec<_>>();
    assert_eq!(admitted.len(), scanned.len());
    assert!(admitted.iter().zip(scanned).all(|(left, right)| {
        (
            left.start,
            left.end,
            left.family,
            left.class,
            left.object_id,
        ) == (
            right.start,
            right.end,
            right.family,
            right.class,
            right.object_id,
        )
    }));
}

#[test]
fn single_closed_triangle_stream_is_selected_as_the_population() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let selected = select_object_stream_population(std::slice::from_ref(&bytes), None);
    assert!(selected.selected());
    assert_eq!(selected.source(), bytes);
}

#[test]
fn closed_triangle_stream_is_one_topology_root_run() {
    let bytes = crate::test_support::test_b5::b5_closed_triangle_stream();
    let ranges = topology_root_run_ranges(&bytes);
    assert_eq!(ranges, vec![0..bytes.len()]);
}

#[test]
fn a8_class21_pcurve_parse_admits_the_test_payload() {
    let payload = a8_class21_test_payload();
    assert!(
        crate::test_support::with_service_context(|ctx| parse_a8_class21_pcurve(ctx, 7, &payload))
            .expect("parse A8 class21 pcurve")
            .is_some()
    );
}

#[test]
fn class_5e_record_yields_a_typed_edge_record() {
    let records = [B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x5e,
        object_id: 17,
        payload: vec![0x85, 0x92, 0x8f, 0x95, 0x93, 0x94, 0x21],
    }];
    let edges = typed_edge_records_from_records(&records);
    assert!(!edges.is_empty());
}

#[test]
fn class_5d_record_yields_a_typed_vertex_incidence_link() {
    let records = [B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x5d,
        object_id: 17,
        payload: vec![0x81, 0x92, 0x04],
    }];
    let links = typed_vertex_incidence_links_from_records(&records);
    assert!(!links.is_empty());
}

#[test]
fn surface_reference_pulls_its_frame_into_the_dependency_closure() {
    let bytes = [0u8; 9];
    let frame = ObjectFrame {
        start: 0,
        end: bytes.len(),
        family: 0xb5,
        class: 0x18,
        object_id: 9,
    };
    let record = B5Record {
        offset: 0,
        family: 0xb5,
        class: 0x5f,
        object_id: 7,
        payload: vec![0x81, 0x89],
    };
    let candidates = HashMap::from([(9, Some(frame))]);
    assert_eq!(
        admit_dependency_records(&bytes, &mut vec![record.clone()], &candidates, None).len(),
        2
    );
    assert_eq!(
        topology_surface_references(&[record]),
        std::collections::HashSet::from([9])
    );
}
