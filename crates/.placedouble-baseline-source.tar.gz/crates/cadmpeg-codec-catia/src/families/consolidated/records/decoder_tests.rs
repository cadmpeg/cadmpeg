// SPDX-License-Identifier: Apache-2.0
//! Record-decoder tests for the `consolidated` family over synthetic byte fixtures.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]
use cadmpeg_test_support::wire;

use cadmpeg_ir::geometry::SolvedCurveGeometry;

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};

use crate::native::edge_definition::CatiaConsolidatedEdgeDefinition;
use crate::test_support::test_a5_bound::{
    a5_circle_bound_edge_stream, a5_cone_bound_edge_stream, a5_cylinder_bound_edge_stream,
    a5_edge_block_stream, a5_native_edge_run_stream, a5_nurbs_bound_edge_stream,
    a5_nurbs_pair_bound_edge_stream, a5_topology_edge_run_stream, a5_torus_bound_edge_stream,
};
use crate::test_support::test_a5a8::{
    a5_native_edge_identity_stream, a5_pcurve_stream, a6_pcurve_stream,
};
use crate::test_support::test_b2::{
    b2_circle_stream, b2_cylinder_stream, b2_edge_block_stream, b2_edge_parameter_stream_for,
    b2_fixed_owner_boundary_cycle_stream, b2_line_profile_stream, b2_plane_carrier_stream,
    b2_resolved_revolution_stream, b2_topology_edge_run_stream,
    b2_wide_cylinder_stream_with_operand, b3_cylinder_stream,
};
use crate::test_support::test_b5::append_b5_record;
use crate::test_support::test_bytes::{be32, le_f32};
use crate::test_support::test_container::{standard_catpart, standard_catpart_from_streams};
use crate::CatiaCodec;

fn parsed_compact_edge_endpoints(
    bytes: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
) -> Vec<crate::families::consolidated::records::ConsolidatedCompactEdgeEndpoints> {
    super::consolidated_compact_edge_endpoints_from_records(bytes, records)
}

fn parsed_owner_boundary_cycles(
    bytes: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
) -> Vec<crate::families::consolidated::records::ConsolidatedOwnerBoundaryCycle> {
    super::consolidated_owner_boundary_cycles_from_records(bytes, records)
}

#[test]
fn object_stream_vertices_exclude_framed_payload_markers() {
    let mut bytes = vec![0xb2, 0x03, 0x06, 0x10, 0x05];
    bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
    for value in [90.0f32, 91.0, 92.0] {
        bytes.extend_from_slice(&le_f32(value));
    }
    bytes.push(0);
    bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
    for value in [1.0f32, 2.0, 3.0] {
        bytes.extend_from_slice(&le_f32(value));
    }

    assert_eq!(
        crate::families::consolidated::records::object_stream_vertices(&bytes)
            .expect("decode the object stream vertices"),
        [cadmpeg_ir::math::Point3::new(1.0, 2.0, 3.0)]
    );
    assert!(
        crate::families::consolidated::records::object_stream_vertices(&bytes[5..])
            .expect("decode the object stream vertices")
            .is_empty()
    );

    let mut b5 = Vec::new();
    let mut payload = vec![0x05, 0x08, 0x01];
    for value in [90.0f32, 91.0, 92.0] {
        payload.extend_from_slice(&le_f32(value));
    }
    append_b5_record(&mut b5, 0x06, 1, &payload);
    append_b5_record(&mut b5, 0x06, 2, &[]);
    b5.extend_from_slice(&[0x05, 0x08, 0x01]);
    for value in [4.0f32, 5.0, 6.0] {
        b5.extend_from_slice(&le_f32(value));
    }
    assert_eq!(
        crate::families::consolidated::records::object_stream_vertices(&b5)
            .expect("decode the object stream vertices"),
        [cadmpeg_ir::math::Point3::new(4.0, 5.0, 6.0)]
    );
}

#[test]
fn a5_edge_block_parser_groups_two_coparametric_pcurves_and_packet() {
    let blocks =
        crate::families::consolidated::records::consolidated_edge_blocks(&a5_edge_block_stream());
    assert_eq!(blocks.len(), 1);
    assert_eq!(blocks[0].pcurves[0].support_id, 0x1234);
    assert_eq!(
        blocks[0].pcurves[1].range,
        crate::test_support::test_b5::increasing([0.0, 1.0])
    );
    assert_eq!(blocks[0].parameters.range.endpoints(), [0.0, 1.0]);
}

#[test]
fn consolidated_edge_block_groups_b_family_pcurves() {
    let blocks =
        crate::families::consolidated::records::consolidated_edge_blocks(&b2_edge_block_stream());
    assert_eq!(blocks.len(), 1);
    assert_eq!(blocks[0].pcurves[0].support_id, 0x1234);
    assert_eq!(
        blocks[0].pcurves[1].range,
        crate::test_support::test_b5::increasing([0.0, 1.0])
    );
}

#[test]
fn consolidated_edge_block_does_not_cross_an_unframed_gap() {
    let source = a5_edge_block_stream();
    let records = crate::wire::records::consolidated_records(&source);
    assert_eq!(records.len(), 3);
    let split = records[0].range().unwrap().end;
    let mut bytes = source[..split].to_vec();
    bytes.push(0);
    bytes.extend_from_slice(&source[split..]);

    assert!(
        crate::families::consolidated::records::consolidated_edge_blocks(&bytes).is_empty(),
        "a multi-frame edge block must not cross an unframed gap"
    );
}

#[test]
fn indexed_resolver_matches_the_one_shot_resolver_identity() {
    let bytes = a5_cylinder_bound_edge_stream();
    let records = crate::wire::records::consolidated_records(&bytes);
    let signature =
        |blocks: &[crate::families::consolidated::records::ResolvedConsolidatedEdgeBlock]| {
            blocks
                .iter()
                .map(|block| {
                    (
                        block.block.pcurves[0].pos,
                        block.block.pcurves[1].pos,
                        block.block.parameters.pos,
                        block.supports,
                    )
                })
                .collect::<Vec<_>>()
        };
    let one_shot = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("resolve the consolidated edge blocks");
    let indexed = crate::test_support::with_service_context(|ctx| {
        crate::families::consolidated::records::resolve_consolidated_edge_blocks_from_records(
            ctx,
            &bytes,
            &records,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("resolve the consolidated edge blocks")
    });
    assert_eq!(signature(&indexed), signature(&one_shot));
}

#[test]
fn class23_nine_scalar_definition_requires_three_equal_triples() {
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionData;

    let mut payload = vec![0x82, 0x05, 0x09, 0x0a, 0x87, 0x0d];
    for value in [0.0_f64, 2.0, 1.0, 0.0, 2.0, 1.0, 0.0, 2.0, 1.0] {
        payload.extend_from_slice(&value.to_le_bytes());
    }
    assert_eq!(
        crate::families::consolidated::records::consolidated_edge_definition_data(0x23, &payload),
        Some(ConsolidatedEdgeDefinitionData::Scalar23 {
            operands: [1, 2, 3463],
            values: vec![
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(2.0),
                crate::test_support::test_b5::finite(1.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(2.0),
                crate::test_support::test_b5::finite(1.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(2.0),
                crate::test_support::test_b5::finite(1.0)
            ]
            .try_into()
            .expect("admitted scalar arity"),
        })
    );

    for offset in [6 + 2 * 8, 6 + 8 * 8] {
        let mut unequal_tolerances = payload.clone();
        unequal_tolerances[offset..offset + 8].copy_from_slice(&2.0_f64.to_le_bytes());
        assert!(
            crate::families::consolidated::records::consolidated_edge_definition_data(
                0x23,
                &unequal_tolerances
            )
            .is_none()
        );
    }
}

#[test]
fn consolidated_topology_edge_run_accepts_b_family_pcurves() {
    let runs = crate::families::consolidated::records::consolidated_topology_edge_runs(
        &b2_topology_edge_run_stream(),
    );
    assert_eq!(runs.len(), 1);
    assert_eq!(runs[0].edge.pcurves[0].support_id, 0x1234);
    assert_eq!(runs[0].node.start_vertex_ref, 889);
    assert_eq!(runs[0].node.end_vertex_ref, 895);
}

#[test]
fn consolidated_native_edge_graph_uses_persistent_endpoint_incidence() {
    let mut bytes = Vec::new();
    bytes.extend_from_slice(&a5_native_edge_run_stream(3, 10, 11));
    bytes.extend_from_slice(&a5_native_edge_run_stream(6, 11, 12));
    bytes.extend_from_slice(&a5_native_edge_run_stream(9, 12, 10));
    let graph = crate::families::consolidated::records::consolidated_native_edge_graph(&bytes)
        .expect("native edge graph");
    assert_eq!(graph.vertex_identities, [10, 11, 12]);
    assert_eq!(
        graph
            .edges
            .iter()
            .map(|edge| edge.vertices)
            .collect::<Vec<_>>(),
        [[0, 1], [1, 2], [2, 0]]
    );
    assert_eq!(graph.components, [vec![0, 1, 2]]);
}

#[test]
fn consolidated_native_edge_graph_treats_curve_references_as_run_local() {
    let mut bytes = a5_native_edge_run_stream(3, 10, 11);
    bytes.extend_from_slice(&a5_native_edge_run_stream(3, 20, 21));
    let graph = crate::families::consolidated::records::consolidated_native_edge_graph(&bytes)
        .expect("native edge graph");
    assert_eq!(graph.edges.len(), 2);
    assert_eq!(graph.components, [vec![0], vec![1]]);
}

#[test]
fn a5_edge_block_does_not_cross_an_intervening_framed_record() {
    let mut bytes = a5_pcurve_stream();
    bytes.extend_from_slice(&[0xb2, 0x03, 0x06, 0x01, 0x05, 0x84]);
    bytes.extend_from_slice(&a5_pcurve_stream());
    bytes.extend_from_slice(&b2_edge_parameter_stream_for(0.0, 1.0));
    assert!(crate::families::consolidated::records::consolidated_edge_blocks(&bytes).is_empty());
}

#[test]
fn a5_edge_binding_resolves_cylinder_by_endpoint_lifts() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_cylinder_bound_edge_stream(),
    )
    .expect("evaluator allocation succeeds");
    assert_eq!(blocks.len(), 1);
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Cylinder { .. })
    ));
    assert!(matches!(
        blocks[0].supports[1],
        Some(ConsolidatedSupportBinding::Cylinder { .. })
    ));
    assert!(blocks[0].endpoint_loci.is_some());
}

#[test]
fn b2_edge_binding_resolves_direction_bearing_plane_by_endpoint_lifts() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let plane_stream = b2_plane_carrier_stream();
    let plane_end = crate::families::b2::records::b2_plane_carriers(&plane_stream)[0].end;
    let mut bytes = b2_edge_block_stream();
    bytes.extend_from_slice(&plane_stream[..plane_end]);
    for point in [[10.0f32, 20.0, 0.0], [11.0, 20.0, 1.0]] {
        bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in point {
            bytes.extend_from_slice(&le_f32(value));
        }
    }

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert_eq!(blocks.len(), 1);
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Plane { .. })
    ));
    assert!(matches!(
        blocks[0].supports[1],
        Some(ConsolidatedSupportBinding::Plane { .. })
    ));
    assert_eq!(
        blocks[0].endpoint_loci,
        Some([
            cadmpeg_ir::math::Point3::new(10.0, 20.0, 0.0),
            cadmpeg_ir::math::Point3::new(11.0, 20.0, 1.0),
        ])
    );
}

#[test]
fn a5_edge_binding_resolves_partner_nurbs_carrier() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_nurbs_bound_edge_stream(0.0),
    )
    .expect("evaluator allocation succeeds");
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Cylinder { .. })
    ));
    assert!(matches!(
        blocks[0].supports[1],
        Some(ConsolidatedSupportBinding::NurbsCarrier { offset, .. }) if offset.get() == 0.0
    ));
    assert_eq!(blocks[0].shared_loci.as_ref().map(Vec::len), Some(2));
    assert!(blocks[0].endpoint_loci.is_some());
}

#[test]
fn a5_edge_binding_resolves_constant_normal_offset_carrier() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_nurbs_bound_edge_stream(1.25),
    )
    .expect("evaluator allocation succeeds");
    assert!(matches!(
        blocks[0].supports[1],
        Some(ConsolidatedSupportBinding::NurbsCarrier { offset, .. }) if (offset.get().abs() - 1.25).abs() < 1.0e-6
    ));
    assert_eq!(blocks[0].shared_loci.as_ref().map(Vec::len), Some(2));
    assert!(blocks[0].endpoint_loci.is_some());
}

#[test]
fn a5_edge_binding_jointly_resolves_two_direct_nurbs_carriers() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_nurbs_pair_bound_edge_stream(false),
    )
    .expect("evaluator allocation succeeds");
    assert_eq!(blocks.len(), 1);
    assert!(
        blocks[0].supports.iter().all(|support| {
            matches!(
                support,
                Some(ConsolidatedSupportBinding::NurbsCarrier { offset, .. }) if offset.get() == 0.0
            )
        }),
        "{:#?}",
        blocks[0].supports
    );
    assert_eq!(blocks[0].shared_loci.as_ref().map(Vec::len), Some(2));
    assert!(blocks[0].endpoint_loci.is_some());
}

#[test]
fn a5_edge_binding_rejects_nonunique_direct_nurbs_carrier_pairs() {
    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_nurbs_pair_bound_edge_stream(true),
    )
    .expect("evaluator allocation succeeds");
    assert_eq!(blocks.len(), 1);
    assert_eq!(blocks[0].supports, [None, None]);
    assert!(blocks[0].shared_loci.is_none());
    assert!(blocks[0].endpoint_loci.is_none());
}

#[test]
fn a5_edge_binding_resolves_circle_by_constant_v_and_arc_range() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_circle_bound_edge_stream(),
    )
    .expect("evaluator allocation succeeds");
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Circle { .. })
    ));
}

#[test]
fn a5_edge_binding_uses_circle_identity_to_break_geometric_ties() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let mut bytes = a5_circle_bound_edge_stream();
    let original_circle_offset = bytes.len() - b2_circle_stream().len();
    let mut duplicate = b2_circle_stream();
    duplicate[6..8].copy_from_slice(&0x1235_u16.to_le_bytes());
    bytes.extend_from_slice(&duplicate);

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Circle { pos }) if pos == original_circle_offset
    ));
}

#[test]
fn a5_edge_binding_rejects_duplicate_circle_identities() {
    let mut bytes = a5_circle_bound_edge_stream();
    bytes.extend_from_slice(&b2_circle_stream());

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert!(blocks[0].supports[0].is_none());
}

#[test]
fn a5_edge_binding_rejects_an_identity_with_a_conflicting_circle_chart() {
    let mut bytes = a5_circle_bound_edge_stream();
    let original_circle_offset = bytes.len() - b2_circle_stream().len();
    bytes[original_circle_offset + 6..original_circle_offset + 8]
        .copy_from_slice(&0x1235_u16.to_le_bytes());
    let mut conflicting = b2_circle_stream();
    conflicting[40..48].copy_from_slice(&1.0_f64.to_le_bytes());
    bytes.extend_from_slice(&conflicting);

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert!(blocks[0].supports[0].is_none());
}

#[test]
fn a5_edge_binding_resolves_cone_by_endpoint_lifts() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_cone_bound_edge_stream(),
    )
    .expect("evaluator allocation succeeds");
    assert!(matches!(
        blocks[0].supports[0],
        Some(ConsolidatedSupportBinding::Cone { .. })
    ));
    assert!(blocks[0].endpoint_loci.is_some());
}

#[test]
fn a5_edge_binding_resolves_torus_by_scaled_chart_endpoint_lifts() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &a5_torus_bound_edge_stream(),
    )
    .expect("evaluator allocation succeeds");
    assert!(blocks[0]
        .supports
        .iter()
        .all(|support| matches!(support, Some(ConsolidatedSupportBinding::Torus { .. }))));
    assert_eq!(blocks[0].shared_loci.as_ref().map(Vec::len), Some(2));
    let endpoints = blocks[0].endpoint_loci.expect("lifted torus endpoints");
    assert!(endpoints[0].distance_squared(cadmpeg_ir::math::Point3::new(1.0, 11.0, 3.0)) < 1e-24);
    assert!(endpoints[1].distance_squared(cadmpeg_ir::math::Point3::new(-8.0, 2.0, 3.0)) < 1e-24);
}

#[test]
fn a5_edge_binding_resolves_sphere_by_endpoint_lifts() {
    use crate::families::consolidated::records::ConsolidatedSupportBinding;

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(
        &crate::test_support::test_a5_bound::a5_sphere_bound_edge_stream(),
    )
    .expect("evaluator allocation succeeds");
    assert!(blocks[0]
        .supports
        .iter()
        .all(|support| matches!(support, Some(ConsolidatedSupportBinding::Sphere { .. }))));
    assert_eq!(blocks[0].shared_loci.as_ref().map(Vec::len), Some(2));
    let endpoints = blocks[0].endpoint_loci.expect("lifted sphere endpoints");
    assert!(endpoints[0].distance_squared(cadmpeg_ir::math::Point3::new(6.0, 2.0, 3.0)) < 1e-24);
    assert!(endpoints[1].distance_squared(cadmpeg_ir::math::Point3::new(1.0, 7.0, 3.0)) < 1e-24);
}

#[test]
fn a5_edge_binding_rejects_duplicate_sphere_endpoint_lifts() {
    let mut bytes = crate::test_support::test_a5_bound::a5_sphere_bound_edge_stream();
    bytes.extend_from_slice(&crate::test_support::test_b2::b2_sphere_stream());

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert_eq!(blocks[0].supports, [None, None]);
}

#[test]
fn a5_edge_binding_rejects_duplicate_torus_endpoint_lifts() {
    let mut bytes = a5_torus_bound_edge_stream();
    bytes.extend_from_slice(&crate::test_support::test_b2::b2_torus_stream());

    let blocks = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    assert_eq!(blocks[0].supports, [None, None]);
}

#[test]
fn consolidated_record_walk_inventory_preserves_width_flag_and_boundaries() {
    use crate::wire::records::ConsolidatedFamily;

    let first = a6_pcurve_stream();
    let second = b3_cylinder_stream();
    let mut bytes = first.clone();
    bytes.extend_from_slice(&second);
    let records = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(records.len(), 2);
    assert_eq!(records[0].family(), ConsolidatedFamily::A);
    assert_eq!(
        (
            u8::from(records[0].width()),
            u8::from(records[0].flag()),
            records[0].class()
        ),
        (2, 0x03, 0x20)
    );
    assert_eq!(records[0].range(), Some(0..first.len()));
    assert_eq!(records[1].family(), ConsolidatedFamily::B);
    assert_eq!(
        records[1].range(),
        Some(first.len()..first.len() + second.len())
    );
}

#[test]
fn consolidated_record_walk_suppresses_payload_records_and_resumes_after_parent() {
    let nested = [0xb2, 0x03, 0x20, 1, 7, 0xaa];
    let mut outer = vec![
        0xb2,
        0x03,
        0x20,
        u8::try_from(nested.len()).expect("fixture value fits u8"),
        1,
    ];
    outer.extend_from_slice(&nested);
    let sibling_start = outer.len();
    outer.extend_from_slice(&[0xb2, 0x03, 0x20, 1, 2, 0xbb]);

    let records = crate::wire::records::consolidated_records(&outer);
    assert_eq!(records.len(), 2);
    assert_eq!(records[0].range(), Some(0..sibling_start));
    assert_eq!(records[1].range(), Some(sibling_start..outer.len()));
}

#[test]
fn consolidated_support_resolution_withholds_cross_family_matches() {
    let mut bytes = a5_cone_bound_edge_stream();
    let cylinder = crate::families::b2::records::b2_cylinders(&b2_cylinder_stream())
        .into_iter()
        .next()
        .expect("one cylinder carrier");
    bytes.extend_from_slice(&b2_cylinder_stream());
    for uv in [[0.0, 2.0], [1.0, 3.0]] {
        let point = crate::families::b2::records::b2_cylinder_point(&cylinder, uv)
            .expect("cylinder endpoint");
        bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in [point.x, point.y, point.z] {
            bytes.extend_from_slice(
                &(cadmpeg_core::convert::f32_from_f64(value).expect("fixture value fits f32"))
                    .to_le_bytes(),
            );
        }
    }

    let resolved = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    let [edge] = resolved.as_slice() else {
        panic!("one consolidated edge block");
    };
    assert_eq!(edge.supports, [None, None]);
    assert!(edge.shared_loci.is_none());
}

#[test]
fn consolidated_support_identity_mismatch_does_not_fall_back_to_geometry() {
    let mut bytes = a5_cone_bound_edge_stream();
    bytes.extend_from_slice(&b2_wide_cylinder_stream_with_operand(0x1234));

    let resolved = crate::families::consolidated::records::resolve_consolidated_edge_blocks(&bytes)
        .expect("evaluator allocation succeeds");
    let [edge] = resolved.as_slice() else {
        panic!("one consolidated edge block");
    };
    assert_eq!(edge.supports, [None, None]);
}

#[test]
fn consolidated_edge_use_run_is_independent_of_pcurve_availability() {
    use crate::families::b2::records::B2UseSense;

    let runs = crate::families::consolidated::records::consolidated_edge_use_runs(
        &a5_native_edge_identity_stream(6, 139, 142),
    );
    let [run] = runs.as_slice() else {
        panic!("one standalone edge-use run");
    };
    assert_eq!(run.uses[0].sense(), Some(B2UseSense::Sense88));
    assert_eq!(run.uses[1].sense(), Some(B2UseSense::Sense84));
    assert_eq!(run.node.start_vertex_ref, 139);
    assert_eq!(run.node.end_vertex_ref, 142);
}

#[test]
fn consolidated_edge_use_run_owns_adjacent_compact_definition() {
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionData;

    let mut bytes = vec![0xb2, 0x03, 0x24, 0x04, 0x05, 0x81, 0x05, 0x0f, 0x87];
    bytes.extend_from_slice(&a5_native_edge_identity_stream(3, 139, 142));

    let runs = crate::families::consolidated::records::consolidated_edge_use_runs(&bytes);
    let [run] = runs.as_slice() else {
        panic!("one edge-use run");
    };
    let definition = run.definition.as_ref().expect("adjacent definition");
    assert_eq!(u8::from(definition.class), 0x24);
    assert_eq!(definition.frame.header_token(), 5);
    assert_eq!(definition.frame.payload, [0x81, 0x05, 0x0f, 0x87]);
    assert_eq!(
        definition.data(),
        Some(ConsolidatedEdgeDefinitionData::Compact24 { operand: 1 })
    );

    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(
        u8::from(
            native.consolidated_edge_nodes[0]
                .definition
                .as_ref()
                .expect("native definition")
                .class()
        ),
        0x24
    );
    assert!(matches!(
        native.consolidated_edge_nodes[0]
            .definition
            .as_ref()
            .and_then(CatiaConsolidatedEdgeDefinition::data),
        Some(
            crate::families::consolidated::records::ConsolidatedEdgeDefinitionData::Compact24 {
                operand: 1
            }
        )
    ));
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store preceding definition");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load preceding definition"),
        native
    );
    let mut wrong_operand = bytes.clone();
    wrong_operand[6] = 0x09;
    assert!(super::consolidated_edge_use_runs(&wrong_operand).is_empty());
    for (offset, sense) in [(17, 0x84), (26, 0x88)] {
        let mut wrong_sense = bytes.clone();
        wrong_sense[offset] = sense;
        assert!(super::consolidated_edge_use_runs(&wrong_sense).is_empty());
    }
}

#[test]
fn consolidated_edge_use_run_accepts_compact_successor_layout() {
    use crate::families::b2::records::B2UseSense;
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionData;

    let bytes = [
        0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x09, 0x0f, 0x07, 0x0b, 0x21, 0xb2, 0x03, 0x24, 0x04,
        0x05, 0x81, 0x29, 0x0f, 0x87, 0xb2, 0x03, 0x06, 0x04, 0x05, 0x82, 0x05, 0x2d, 0x88, 0xb2,
        0x03, 0x06, 0x04, 0x05, 0x82, 0x09, 0x31, 0x84,
    ];
    let runs = crate::families::consolidated::records::consolidated_edge_use_runs(&bytes);
    let [run] = runs.as_slice() else {
        panic!("one successor-layout edge run")
    };
    assert_eq!(run.uses[0].sense(), Some(B2UseSense::Sense88));
    assert_eq!(run.uses[1].sense(), Some(B2UseSense::Sense84));
    assert_eq!(run.uses[0].references(), Some(&[1, 11][..]));
    assert_eq!(run.uses[1].references(), Some(&[2, 12][..]));
    assert_eq!(
        run.definition
            .as_ref()
            .and_then(super::ConsolidatedEdgeDefinition::data),
        Some(ConsolidatedEdgeDefinitionData::Compact24 { operand: 10 })
    );
    let native = crate::native::CatiaNative::decode(&bytes);
    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store successor layout");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load successor layout"),
        native
    );
    for (offset, sense) in [(28, 0x84), (37, 0x88)] {
        let mut wrong_sense = bytes;
        wrong_sense[offset] = sense;
        assert!(super::consolidated_edge_use_runs(&wrong_sense).is_empty());
    }
}

#[test]
fn compact_owner_ordinal_selects_the_owned_edge_node() {
    let bytes = [
        0xb2, 0x03, 0x5f, 0x04, 0x05, 0x82, 0x1d, 0x03, 0x05, 0xb2, 0x03, 0x62, 0x08, 0x05, 0x82,
        0x0b, 0x21, 0x84, 0x41, 0xff, 0x0f, 0x01, 0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00, 0xb2,
        0x03, 0x05, 0x03, 0x05, 0x82, 0x0b, 0x57, 0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x09, 0x0f,
        0x07, 0x0b, 0x21,
    ];
    let records = crate::wire::records::consolidated_records(&bytes);
    let owned = crate::families::consolidated::records::consolidated_owned_edge_nodes_from_records(
        &bytes, &records,
    );
    let [owned] = owned.as_slice() else {
        panic!("one owner-selected edge node")
    };
    assert_eq!(owned.owner_pos, 9);
    assert_eq!(owned.allocation_ordinal, 2);
    assert_eq!(owned.node.pos, 37);
}

#[test]
fn counted_face_owner_admits_only_pair_member_edge_slots() {
    let face = [0xb2, 3, 0x5f, 4, 5, 0x82, 0x0d, 3, 5];
    let owner = [
        0xb2, 3, 0x62, 11, 5, 0x85, 3, 7, 0x0b, 0x0f, 0x13, 0x84, 0x41, 0xff, 0x0f, 1,
    ];
    let edge = [0xb2, 3, 0x5e, 6, 5, 3, 9, 0x0f, 7, 0x0b, 0x21];
    let mut bytes = face.to_vec();
    bytes.extend_from_slice(&owner);
    for _ in 0..5 {
        bytes.extend_from_slice(&edge);
    }
    let records = crate::wire::records::consolidated_records(&bytes);
    let owned = super::consolidated_owned_edge_nodes_from_records(&bytes, &records);
    assert_eq!(
        owned
            .iter()
            .map(|node| node.allocation_ordinal)
            .collect::<Vec<_>>(),
        [1, 3]
    );
}

#[test]
fn owned_edge_ordinal_stops_at_allocation_boundaries() {
    let face = [0xb2, 3, 0x5f, 4, 5, 0x82, 0x1d, 3, 5];
    let owner = [
        0xb2, 3, 0x62, 11, 5, 0x85, 5, 0x0b, 5, 0x7f, 0x21, 0x84, 0x41, 0xff, 0x0f, 1,
    ];
    let ordinary = [0xb2, 3, 5, 1, 5, 1];
    let separator = [0xb2, 3, 0x65, 4, 5, 0x81, 3, 5, 0x0d];
    let non_separator = [0xb2, 3, 0x65, 4, 5, 0x81, 3, 5, 0x11];
    let other_owner = [0xb2, 3, 0x62, 1, 5, 1];
    let edge = [0xb2, 3, 0x5e, 6, 5, 3, 9, 0x0f, 7, 0x0b, 0x21];
    let decode = |boundary: &[u8], gap: bool| {
        let mut bytes = face.to_vec();
        bytes.extend_from_slice(&owner);
        bytes.extend_from_slice(boundary);
        if gap {
            bytes.push(0);
        }
        bytes.extend_from_slice(&ordinary);
        bytes.extend_from_slice(&edge);
        let records = crate::wire::records::consolidated_records(&bytes);
        super::consolidated_owned_edge_nodes_from_records(&bytes, &records)
    };
    assert_eq!(decode(&ordinary, false).len(), 1);
    assert_eq!(decode(&non_separator, false).len(), 1);
    for boundary in [&separator[..], &other_owner, &face] {
        assert!(decode(boundary, false).is_empty());
    }
    assert!(decode(&ordinary, true).is_empty());

    let mut bytes = face.to_vec();
    bytes.extend_from_slice(&owner);
    let split = bytes.len() + 6;
    bytes.extend_from_slice(&separator);
    bytes.extend_from_slice(&ordinary);
    bytes.extend_from_slice(&edge);
    let records = crate::wire::records::consolidated_records_in_range_sources(
        &bytes,
        [[0..split, split..bytes.len()]],
    );
    assert!(records
        .iter()
        .any(|record| record.class() == 0x65 && record.range().is_none()));
    assert!(super::consolidated_owned_edge_nodes_from_records(&bytes, &records).is_empty());
}

#[test]
fn owned_edge_ordinal_uses_logical_source_boundaries() {
    let face = [0xb2, 3, 0x5f, 4, 5, 0x82, 0x1d, 3, 5];
    let owner = [
        0xb2, 3, 0x62, 11, 5, 0x85, 5, 0x0b, 5, 0x7f, 0x21, 0x84, 0x41, 0xff, 0x0f, 1,
    ];
    let filler = [0xb2, 3, 5, 1, 5, 1];
    let edge = [0xb2, 3, 0x5e, 6, 5, 3, 9, 0x0f, 7, 0x0b, 0x21];
    let mut bytes = face.to_vec();
    bytes.extend_from_slice(&owner);
    bytes.extend_from_slice(&filler);
    let split = bytes.len();
    bytes.extend_from_slice(&filler);
    let edge_pos = bytes.len();
    bytes.extend_from_slice(&edge);

    let split_sources = crate::wire::records::consolidated_records_in_ranges(
        &bytes,
        [0..split, split..bytes.len()],
    );
    assert!(super::consolidated_owned_edge_nodes_from_records(&bytes, &split_sources).is_empty());

    let mut reordered = bytes[split..].to_vec();
    let next_extent = reordered.len();
    reordered.extend_from_slice(&bytes[..split]);
    let records = crate::wire::records::consolidated_records_in_range_sources(
        &reordered,
        [[next_extent..reordered.len(), 0..next_extent]],
    );
    let owned = super::consolidated_owned_edge_nodes_from_records(&reordered, &records);
    assert_eq!(owned.len(), 1);
    assert_eq!(owned[0].node.pos, edge_pos - split);
}

#[test]
fn counted_owner_endpoints_follow_complete_framed_allocation() {
    let face = [0xb2, 0x03, 0x5f, 0x04, 0x05, 0x82, 0x1d, 0x03, 0x05];
    let owner = [
        0xb2, 0x03, 0x62, 0x0d, 0x05, 0x87, 0x05, 0x03, 0x05, 0x0f, 0x05, 0x1b, 0x21, 0x84, 0x41,
        0xff, 0x0f, 0x01,
    ];
    let edge = [
        0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x03, 0x0f, 0x07, 0x0b, 0x21,
    ];
    let closing_edge = [
        0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x03, 0x15, 0x07, 0x0b, 0x21,
    ];
    let vertex = [0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00];
    let filler = [0xb2, 0x03, 0x05, 0x01, 0x05, 0x01];
    let mut bytes = face.to_vec();
    bytes.extend_from_slice(&owner);
    let mut expected = Vec::new();
    let mut vertices = Vec::new();
    for current in [&edge, &edge, &closing_edge] {
        let edge_pos = bytes.len();
        bytes.extend_from_slice(current);
        vertices.push(bytes.len());
        bytes.extend_from_slice(&vertex);
        expected.push(edge_pos);
        if expected.len() < 3 {
            bytes.extend_from_slice(&filler);
        }
    }
    let records = crate::wire::records::consolidated_records(&bytes);
    let endpoints = parsed_compact_edge_endpoints(&bytes, &records);
    let actual = endpoints
        .iter()
        .map(|binding| (binding.node.pos, binding.endpoint_records))
        .collect::<Vec<_>>();
    assert_eq!(
        actual,
        [
            (expected[0], [vertices[0], vertices[1]]),
            (expected[1], [vertices[1], vertices[2]]),
            (expected[2], [vertices[2], vertices[0]]),
        ]
    );

    let cycles = |data: &[u8], records: &[crate::wire::records::ConsolidatedRecord]| {
        let parsed = crate::families::b2::records::b2_edge_nodes_from_records(data, records)
            .map(|node| (node.pos, node))
            .collect::<std::collections::HashMap<_, _>>();
        let nodes = records
            .iter()
            .enumerate()
            .filter_map(|(index, record)| {
                parsed
                    .get(&record.byte_offset())
                    .copied()
                    .map(|node| (index, node))
            })
            .collect();
        super::counted_owner_endpoint_cycles(data, records, &nodes).cycles
    };
    let split = expected[1];
    let split_records = crate::wire::records::consolidated_records_in_ranges(
        &bytes,
        [0..split, split..bytes.len()],
    );
    assert!(cycles(&bytes, &split_records).is_empty());

    let mut reordered = bytes[split..].to_vec();
    let second_extent = reordered.len();
    reordered.extend_from_slice(&bytes[..split]);
    let reordered_records = crate::wire::records::consolidated_records_in_range_sources(
        &reordered,
        [[second_extent..reordered.len(), 0..second_extent]],
    );
    let physical = |offset: usize| {
        if offset < split {
            second_extent + offset
        } else {
            offset - split
        }
    };
    let reordered_endpoints = parsed_compact_edge_endpoints(&reordered, &reordered_records);
    for (edge, vertices) in &actual {
        assert!(reordered_endpoints.iter().any(|binding| {
            binding.node.pos == physical(*edge)
                && binding.endpoint_records == vertices.map(physical)
        }));
    }

    let separator = [0xb2, 0x03, 0x65, 0x04, 0x05, 0x81, 0x03, 0x05, 0x0d];
    let filler_pos = vertices[0] + vertex.len();
    let mut reset_bytes = bytes.clone();
    reset_bytes.splice(filler_pos..filler_pos + filler.len(), separator);
    let reset_records = crate::wire::records::consolidated_records(&reset_bytes);
    assert!(cycles(&reset_bytes, &reset_records).is_empty());
}

#[test]
fn incomplete_counted_owner_withholds_filtered_endpoint_walk() {
    let face = [0xb2, 0x03, 0x5f, 0x04, 0x05, 0x82, 0x1d, 0x03, 0x05];
    let owner = [
        0xb2, 0x03, 0x62, 0x0b, 0x05, 0x85, 0x05, 0x03, 0x05, 0x7f, 0x21, 0x84, 0x41, 0xff, 0x0f,
        0x01,
    ];
    let edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x20, 0x03, 0x07, 0x06, 0x30, 0x06, 0x31, 0x21,
    ];
    let vertex = [0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00];
    let mut allocation = edge.to_vec();
    allocation.extend_from_slice(&vertex);
    allocation.extend_from_slice(&vertex);
    let standalone = crate::wire::records::consolidated_records(&allocation);
    assert_eq!(
        parsed_compact_edge_endpoints(&allocation, &standalone).len(),
        1
    );

    let mut owned = face.to_vec();
    owned.extend_from_slice(&owner);
    owned.extend_from_slice(&allocation);
    let records = crate::wire::records::consolidated_records(&owned);
    assert!(parsed_compact_edge_endpoints(&owned, &records).is_empty());

    let width_coded_edge = [
        0xb2, 0x03, 0x5e, 0x0a, 0x05, 0x03, 0x08, 0x02, 0x00, 0x08, 0x03, 0x00, 0x07, 0x0b, 0x21,
    ];
    let filler = [0xb2, 0x03, 0x05, 0x01, 0x05, 0x01];
    let endpoint = [0xb2, 0x03, 0x18, 0x01, 0x05, 0x01];
    let mut owned = face.to_vec();
    owned.extend_from_slice(&owner);
    owned.extend_from_slice(&width_coded_edge);
    owned.extend_from_slice(&filler);
    let first = owned.len();
    owned.extend_from_slice(&endpoint);
    let second = owned.len();
    owned.extend_from_slice(&endpoint);
    let records = crate::wire::records::consolidated_records(&owned);
    let endpoints = parsed_compact_edge_endpoints(&owned, &records);
    assert_eq!(endpoints.len(), 1);
    assert_eq!(endpoints[0].endpoint_records, [first, second]);
}

#[test]
fn counted_owner_withholds_conflicting_complete_endpoint_cycles() {
    let face = [0xb2, 3, 0x5f, 4, 5, 0x82, 0x1d, 3, 5];
    let owner = [
        0xb2, 3, 0x62, 13, 5, 0x87, 5, 0x0f, 5, 0x27, 5, 0x37, 0x21, 0x84, 0x41, 0xff, 0x0f, 1,
    ];
    let vertex = [0xb2, 3, 0x5d, 2, 5, 3, 0];
    let filler = [0xb2, 3, 5, 1, 5, 1];
    let edges = [
        [0xb2, 3, 0x5e, 6, 5, 3, 7, 0x0b, 7, 0x0b, 0x21],
        [0xb2, 3, 0x5e, 6, 5, 3, 9, 0x11, 7, 0x0b, 0x21],
        [0xb2, 3, 0x5e, 6, 5, 3, 0x19, 0x1d, 7, 0x0b, 0x21],
    ];
    let mut bytes = face.to_vec();
    bytes.extend_from_slice(&owner);
    let mut next_edge = edges.iter();
    for kind in b"VVFEFVVVVEVFVE" {
        match kind {
            b'V' => bytes.extend_from_slice(&vertex),
            b'F' => bytes.extend_from_slice(&filler),
            b'E' => bytes.extend_from_slice(next_edge.next().expect("one edge per slot")),
            _ => unreachable!(),
        }
    }
    let records = crate::wire::records::consolidated_records(&bytes);
    assert!(parsed_compact_edge_endpoints(&bytes, &records).is_empty());
}

#[test]
fn endpoint_cycle_requires_connected_incidence() {
    assert!(super::is_simple_endpoint_cycle(&[[0, 1], [1, 2], [2, 0]]));
    assert!(!super::is_simple_endpoint_cycle(&[
        [0, 1],
        [1, 2],
        [2, 0],
        [3, 4],
        [4, 5],
        [5, 3],
    ]));
}

#[test]
fn compact_endpoint_walk_resolves_children_and_backward_edge_links() {
    let first_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x20, 0x03, 0x07, 0x06, 0x30, 0x06, 0x31, 0x21,
    ];
    let vertex = [0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00];
    let second_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x21, 0x09, 0x0d, 0x06, 0x32, 0x06, 0x33, 0x21,
    ];
    let first_vertex_pos = first_edge.len();
    let second_vertex_pos = first_vertex_pos + vertex.len();
    let mut bytes = first_edge.to_vec();
    bytes.extend_from_slice(&vertex);
    bytes.extend_from_slice(&vertex);
    bytes.extend_from_slice(&second_edge);
    let records = crate::wire::records::consolidated_records(&bytes);
    let endpoints = parsed_compact_edge_endpoints(&bytes, &records);

    assert_eq!(endpoints.len(), 2);
    assert_eq!(
        endpoints[0].endpoint_records,
        [first_vertex_pos, second_vertex_pos]
    );
    assert_eq!(
        endpoints[1].endpoint_records,
        [first_vertex_pos, second_vertex_pos]
    );
}

#[test]
fn compact_endpoint_walk_follows_a_deferring_chain_past_any_recursion_limit() {
    let first_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x20, 0x03, 0x07, 0x06, 0x30, 0x06, 0x31, 0x21,
    ];
    let vertex = [0xb2, 0x03, 0x5d, 0x02, 0x05, 0x03, 0x00];
    let deferring_edge = [
        0xb2, 0x03, 0x5e, 0x09, 0x05, 0x06, 0x21, 0x05, 0x05, 0x06, 0x32, 0x06, 0x33, 0x21,
    ];
    let chain = 2_000;
    let first_vertex_pos = first_edge.len();
    let second_vertex_pos = first_vertex_pos + vertex.len();
    let mut bytes = first_edge.to_vec();
    bytes.extend_from_slice(&vertex);
    bytes.extend_from_slice(&vertex);
    for _ in 0..chain {
        bytes.extend_from_slice(&deferring_edge);
    }
    let records = crate::wire::records::consolidated_records(&bytes);
    let endpoints = parsed_compact_edge_endpoints(&bytes, &records);

    assert_eq!(endpoints.len(), chain + 1);
    assert_eq!(
        endpoints[0].endpoint_records,
        [first_vertex_pos, second_vertex_pos]
    );
    assert!(endpoints[1..]
        .iter()
        .all(|edge| edge.endpoint_records == [second_vertex_pos, second_vertex_pos]));
}

#[test]
fn width_coded_endpoint_distances_resolve_forward_class18_records() {
    let edge = [
        0xb2, 0x03, 0x5e, 0x0a, 0x05, 0x03, 0x08, 0x02, 0x00, 0x08, 0x03, 0x00, 0x07, 0x0b, 0x21,
    ];
    let filler = [0xb2, 0x03, 0x05, 0x01, 0x05, 0x01];
    let endpoint = [0xb2, 0x03, 0x18, 0x01, 0x05, 0x01];
    let first_endpoint = edge.len() + filler.len();
    let second_endpoint = first_endpoint + endpoint.len();
    let mut bytes = edge.to_vec();
    bytes.extend_from_slice(&filler);
    bytes.extend_from_slice(&endpoint);
    bytes.extend_from_slice(&endpoint);
    let records = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(
        records
            .iter()
            .map(crate::wire::records::ConsolidatedRecord::class)
            .collect::<Vec<_>>(),
        [0x5e, 0x05, 0x18, 0x18]
    );
    let nodes = crate::families::b2::records::b2_edge_nodes_from_records(&bytes, &records)
        .collect::<Vec<_>>();
    assert_eq!(nodes.len(), 1);
    assert_eq!([nodes[0].start_vertex_ref, nodes[0].end_vertex_ref], [2, 3]);
    let endpoints = parsed_compact_edge_endpoints(&bytes, &records);

    let [resolved] = endpoints.as_slice() else {
        panic!("one edge with two forward endpoint records")
    };
    assert_eq!(resolved.endpoint_records, [first_endpoint, second_endpoint]);

    let split_sources = crate::wire::records::consolidated_records_in_ranges(
        &bytes,
        [0..edge.len(), edge.len()..bytes.len()],
    );
    assert!(
        parsed_compact_edge_endpoints(&bytes, &split_sources,).is_empty(),
        "a forward endpoint walk cannot cross bounded record sources"
    );

    let mut reordered = endpoint.to_vec();
    let edge_pos = reordered.len();
    reordered.extend_from_slice(&edge);
    let filler_pos = reordered.len();
    reordered.extend_from_slice(&filler);
    let second_endpoint_pos = reordered.len();
    reordered.extend_from_slice(&endpoint);
    let records = crate::wire::records::consolidated_records_in_range_sources(
        &reordered,
        [[
            edge_pos..filler_pos,
            filler_pos..second_endpoint_pos,
            0..endpoint.len(),
            second_endpoint_pos..reordered.len(),
        ]],
    );
    let endpoints = parsed_compact_edge_endpoints(&reordered, &records);
    let [resolved] = endpoints.as_slice() else {
        panic!("one edge can walk across physical extents in logical source order")
    };
    assert_eq!(resolved.endpoint_records, [0, second_endpoint_pos]);

    let mut spanning = edge.to_vec();
    let filler_start = spanning.len();
    spanning.extend_from_slice(&[0xa5, 0x03, 0x34]);
    spanning.extend_from_slice(&8u32.to_le_bytes());
    spanning.extend_from_slice(&[0x05, 0, 1, 2, 3, 4, 5, 6, 7]);
    let spanning_first_endpoint = spanning.len();
    spanning.extend_from_slice(&endpoint);
    let spanning_second_endpoint = spanning.len();
    spanning.extend_from_slice(&endpoint);
    let split = filler_start + 10;
    let records = crate::wire::records::consolidated_records_in_range_sources(
        &spanning,
        [[0..split, split..spanning.len()]],
    );
    assert!(records[1].range().is_none());
    let endpoints = parsed_compact_edge_endpoints(&spanning, &records);
    let [resolved] = endpoints.as_slice() else {
        panic!("a spanning frame remains in forward-distance ordinal accounting")
    };
    assert_eq!(
        resolved.endpoint_records,
        [spanning_first_endpoint, spanning_second_endpoint]
    );

    let mut wrong_class = bytes;
    wrong_class[first_endpoint + 2] = 0x19;
    let records = crate::wire::records::consolidated_records(&wrong_class);
    assert!(parsed_compact_edge_endpoints(&wrong_class, &records,).is_empty());
}

#[test]
fn fixed_owner_boundary_cycle_rejects_cross_source_endpoint_network() {
    let (bytes, _, _, endpoint_records) = b2_fixed_owner_boundary_cycle_stream();
    let records = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(parsed_owner_boundary_cycles(&bytes, &records,).len(), 1);

    let split = endpoint_records[1][1];
    let split_records = crate::wire::records::consolidated_records_in_ranges(
        &bytes,
        [0..split, split..bytes.len()],
    );
    assert!(
        parsed_owner_boundary_cycles(&bytes, &split_records,).is_empty(),
        "a fixed-owner cycle cannot join endpoint records across bounded sources"
    );
}

#[test]
fn consolidated_edge_definition_decodes_typed_class25_maps() {
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionData;
    for bytes in [
        crate::test_support::test_class25::affine_stream(),
        crate::test_support::test_class25::sampled_stream(),
    ] {
        let mut bytes = bytes;
        bytes.extend_from_slice(&a5_native_edge_identity_stream(6, 139, 142));
        let native = crate::native::CatiaNative::decode(&bytes);
        assert!(matches!(
            native.consolidated_edge_nodes[0]
                .definition
                .as_ref()
                .and_then(CatiaConsolidatedEdgeDefinition::data),
            Some(ConsolidatedEdgeDefinitionData::Domain25 { .. })
        ));
        let mut descriptor_payload = vec![0x08, 0x34, 0x12, 0x02];
        descriptor_payload.extend_from_slice(&3.0_f64.to_le_bytes());
        descriptor_payload.extend_from_slice(&7.0_f64.to_le_bytes());
        let mut described = vec![
            0xb2,
            0x03,
            0x18,
            u8::try_from(descriptor_payload.len()).expect("small descriptor"),
            0x05,
        ];
        described.extend_from_slice(&descriptor_payload);
        described.extend_from_slice(&bytes);
        let runs = super::consolidated_class25_edge_runs(&described);
        let [run] = runs.as_slice() else {
            panic!("one described class25 map")
        };
        assert_eq!(run.descriptor.record_id, 0x1234);
        assert_eq!(
            cadmpeg_ir::scalar::FiniteReal::raw_lane(&run.descriptor.values),
            [3.0, 7.0]
        );
        let native = crate::native::CatiaNative::decode(&described);
        assert_eq!(
            native.consolidated_edge_nodes[0]
                .class25_descriptor
                .as_ref()
                .expect("native descriptor")
                .control,
            0x02
        );
        let mut namespace = cadmpeg_ir::NativeNamespace::default();
        native.store(&mut namespace).expect("store described map");
        assert_eq!(
            crate::native::CatiaNative::load(&namespace).expect("load described map"),
            native
        );
    }
}

#[test]
fn consolidated_analytic_circle_run_binds_adjacent_carrier() {
    fn record(class: u8, token: u8, payload: &[u8]) -> Vec<u8> {
        let mut bytes = vec![
            0xb2,
            0x03,
            class,
            u8::try_from(payload.len()).expect("fixture value fits u8"),
            token,
        ];
        bytes.extend_from_slice(payload);
        bytes
    }

    const MAP_TOLERANCE: f64 = 1.0e-6;
    let mut parameter = vec![0x05, 0x02];
    for value in [12.0_f64, 4.0, 9.0] {
        parameter.extend_from_slice(&value.to_le_bytes());
    }
    let mut circle = vec![0x05];
    for value in [12.0_f64, 34.0, 5.0, 0.0, 10.0] {
        circle.extend_from_slice(&value.to_le_bytes());
    }
    circle.push(0x01);
    circle.extend_from_slice(&0.0_f64.to_le_bytes());
    let mut definition = vec![0x82, 0x05, 0x09, 0x0a, 0x87, 0x0d];
    for value in [
        0.0_f64,
        10.0,
        MAP_TOLERANCE,
        4.0,
        9.0,
        2.0,
        -8.0,
        MAP_TOLERANCE,
    ] {
        definition.extend_from_slice(&value.to_le_bytes());
    }
    let mut bytes = record(0x18, 0x15, &parameter);
    bytes.extend_from_slice(&record(0x19, 0x05, &circle));
    bytes.extend_from_slice(&record(0x23, 0x05, &definition));
    bytes.extend_from_slice(&a5_native_edge_identity_stream(3, 139, 142));

    let runs =
        crate::families::consolidated::records::consolidated_analytic_circle_edge_runs(&bytes);
    let [run] = runs.as_slice() else {
        panic!("one analytic-circle edge run");
    };
    assert_eq!(
        run.circle.center_pair,
        crate::test_support::test_b5::finite_vector([12.0, 34.0])
    );
    assert_eq!(run.circle.radius.get(), 5.0);
    assert_eq!(run.descriptor.header_token(), 0x15);
    assert_eq!(
        run.definition.frame.pos,
        parameter.len() + circle.len() + 10
    );

    let mut mismatched_circle = bytes.clone();
    let circle_lower = parameter.len() + 5 + 5 + 1 + 3 * 8;
    mismatched_circle[circle_lower..circle_lower + 8].copy_from_slice(&(-1.0_f64).to_le_bytes());
    assert!(
        crate::families::consolidated::records::consolidated_analytic_circle_edge_runs(
            &mismatched_circle
        )
        .is_empty()
    );

    let mut signed_zero_circle = bytes.clone();
    signed_zero_circle[circle_lower..circle_lower + 8].copy_from_slice(&(-0.0_f64).to_le_bytes());
    assert!(
        crate::families::consolidated::records::consolidated_analytic_circle_edge_runs(
            &signed_zero_circle
        )
        .is_empty()
    );

    let mut reversed_identity = bytes.clone();
    let definition_payload = parameter.len() + circle.len() + 15;
    reversed_identity[definition_payload + 1..definition_payload + 3]
        .copy_from_slice(&[0x09, 0x05]);
    for (offset, value) in [(30, 0.0_f64), (38, 10.0), (46, 1.0), (54, 0.0)] {
        let at = definition_payload + offset;
        reversed_identity[at..at + 8].copy_from_slice(&value.to_le_bytes());
    }
    assert!(
        crate::families::consolidated::records::consolidated_analytic_circle_edge_runs(
            &reversed_identity
        )
        .is_empty()
    );

    let native = crate::native::CatiaNative::decode(&bytes);
    let binding = native.consolidated_edge_nodes[0]
        .analytic_circle
        .as_ref()
        .expect("native analytic circle");
    assert_eq!(binding.circle, "catia:consolidated:circle#0");
    assert_eq!(
        native.consolidated_circles[0].center_pair,
        crate::test_support::test_b5::finite_vector([12.0, 34.0])
    );
    assert_eq!(
        native.consolidated_circles[0].range.endpoints(),
        [0.0, 10.0]
    );

    let mut namespace = cadmpeg_ir::NativeNamespace::default();
    native
        .store(&mut namespace)
        .expect("store analytic circle binding");
    assert_eq!(
        crate::native::CatiaNative::load(&namespace).expect("load analytic circle binding"),
        native
    );

    let mut inconsistent = native.clone();
    inconsistent.consolidated_circles[0].range =
        cadmpeg_ir::topology::IncreasingParameterInterval::new([-1.0, 10.0])
            .expect("increasing contradictory circle interval");
    let mut inconsistent_namespace = cadmpeg_ir::NativeNamespace::default();
    inconsistent
        .store(&mut inconsistent_namespace)
        .expect("store contradictory circle");
    assert!(crate::native::CatiaNative::load(&inconsistent_namespace).is_err());

    let mut invalid = native;
    invalid.consolidated_edge_nodes[0]
        .analytic_circle
        .as_mut()
        .expect("analytic circle binding")
        .circle = "missing".to_string();
    let mut invalid_namespace = cadmpeg_ir::NativeNamespace::default();
    invalid
        .store(&mut invalid_namespace)
        .expect("store invalid analytic circle binding");
    assert!(crate::native::CatiaNative::load(&invalid_namespace).is_err());

    let circle_end = parameter.len() + circle.len() + 10;
    let mut broken = bytes[..circle_end].to_vec();
    broken.extend_from_slice(&record(0x05, 0x05, &[0x00]));
    broken.extend_from_slice(&bytes[circle_end..]);
    assert!(
        crate::families::consolidated::records::consolidated_analytic_circle_edge_runs(&broken)
            .is_empty()
    );
}

#[test]
fn class25_edge_run_admits_complete_sampled_map_and_declines_wrong_count() {
    let mut descriptor = vec![0x08, 0x34, 0x12, 0x02];
    descriptor.extend_from_slice(&3.0_f64.to_le_bytes());
    descriptor.extend_from_slice(&7.0_f64.to_le_bytes());
    let mut bytes = vec![
        0xb2,
        0x03,
        0x18,
        u8::try_from(descriptor.len()).expect("small descriptor"),
        0x05,
    ];
    bytes.extend_from_slice(&descriptor);
    let map_start = bytes.len();
    bytes.extend_from_slice(&crate::test_support::test_class25::sampled_stream());
    bytes.extend_from_slice(&a5_native_edge_identity_stream(6, 139, 142));
    assert_eq!(super::consolidated_class25_edge_runs(&bytes).len(), 1);
    bytes[map_start + 5 + 6 + 40] = 0x83;
    assert!(super::consolidated_class25_edge_runs(&bytes).is_empty());
}

#[test]
fn a5_topology_edge_run_preserves_uses_and_native_endpoint_identities() {
    use crate::families::b2::records::B2UseSense;

    let stream = a5_topology_edge_run_stream();
    assert!(
        crate::families::consolidated::records::consolidated_topology_edge_runs(&stream).is_empty()
    );
    let uses = crate::families::b2::records::b2_use_metadata(&stream);
    let nodes = crate::families::b2::records::b2_edge_nodes(&stream);
    assert_eq!(uses[0].sense(), Some(B2UseSense::Sense84));
    assert_eq!(uses[1].sense(), Some(B2UseSense::Sense88));
    assert_eq!(uses[0].references(), Some(&[1, 2][..]));
    assert_eq!(uses[1].references(), Some(&[2, 3][..]));
    assert_eq!(nodes[0].start_vertex_ref, 889);
    assert_eq!(nodes[0].end_vertex_ref, 895);
}

#[test]
fn decode_transfers_exact_consolidated_line_profiles() {
    let mut file = standard_catpart();
    file.splice(16..16, b2_line_profile_stream());
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode consolidated line profile");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::DECODED_CONSOLIDATED_LINE_PROFILE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_CONSOLIDATED_LINE_PROFILE_COUNT.as_str()
        ),
        1
    );
    assert!(decoded.ir().geometry.curves.iter().any(
        |curve| matches!(curve.geometry, cadmpeg_ir::geometry::CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve))
                if {
                    let origin = line_curve.origin().get();
                    let direction = *line_curve.direction().as_raw();
                    origin == cadmpeg_ir::math::Point3::new(1.0, 2.0, 3.0)
                        && direction == cadmpeg_ir::math::Vector3::new(0.0, 0.6, 0.8)
                })
    ));
    assert!(!decoded
        .report()
        .losses
        .iter()
        .any(|loss| loss.message.contains("consolidated line-profile record(s)")));
}

#[test]
fn decode_routes_a_line_profile_only_nested_stream_to_a_wire() {
    let file = standard_catpart_from_streams(&b2_line_profile_stream(), &[]);
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode line-profile-only nested stream");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_CONSOLIDATED_LINE_PROFILE_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            (cadmpeg_ir::report::decode::CoverageKey::new("attached_standalone_wire_edge_count"))
                .as_str()
        ),
        1
    );
    assert_eq!(
        decoded.ir().geometry.edges[0]
            .param_range()
            .map(cadmpeg_ir::units::FiniteVector::get),
        Some([-4.0, 9.0])
    );
    assert_eq!(
        decoded.ir().geometry.bodies[0].kind,
        cadmpeg_ir::topology::BodyKind::Wire
    );
    assert!(cadmpeg_ir::validate_neutral(decoded.ir(), Vec::new())
        .expect("validate the neutral model")
        .is_ok());
}

#[test]
fn decode_routes_a_resolved_revolution_only_nested_stream_to_freeform() {
    let file = standard_catpart_from_streams(&b2_resolved_revolution_stream(), &[]);
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode revolution-only nested stream");
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::TRANSFERRED_CONSOLIDATED_REVOLUTION_COUNT.as_str()
        ),
        1
    );
    let revolution = decoded
        .ir()
        .geometry
        .procedural_surfaces
        .iter()
        .find(|surface| surface.id.as_str() == "catia:consolidated:surface-revolution#0")
        .expect("transferred freeform revolution");
    assert!(match revolution.definition() {
        cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Revolution(matched_payload) => matches!(
            (&matched_payload
                .parameter_interval()
                .map(cadmpeg_ir::topology::IncreasingParameterInterval::endpoints),),
            (Some([-4.0, 9.0]),)
        ),
        _ => false,
    });
    assert!(cadmpeg_ir::validate_neutral(decoded.ir(), Vec::new())
        .expect("validate the neutral model")
        .is_ok());
}

#[test]
fn transferred_line_profile_identities_retain_their_native_ordinals() {
    let mut file = standard_catpart();
    file.splice(
        16..16,
        [b2_line_profile_stream(), b2_line_profile_stream()].concat(),
    );
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode mixed-metric line profiles");
    let line_ids = decoded
        .ir()
        .geometry
        .curves
        .iter()
        .filter(|curve| {
            curve
                .id
                .as_str()
                .starts_with("catia:consolidated:line-profile-curve#")
        })
        .map(|curve| curve.id.as_str())
        .collect::<Vec<_>>();
    assert_eq!(
        line_ids,
        [
            "catia:consolidated:line-profile-curve#0",
            "catia:consolidated:line-profile-curve#1",
        ]
    );
}

#[test]
fn class23_scalar_deserialization_requires_nine_values() {
    use crate::families::consolidated::records::ConsolidatedEdgeDefinitionData;
    for count in 0..=11 {
        let wire = serde_json::json!({"kind": "scalar23", "operands": [1, 2, 3], "values": vec![0.0; count]});
        let result = serde_json::from_value::<ConsolidatedEdgeDefinitionData>(wire);
        assert_eq!(result.is_ok(), count == 9, "scalar23 {count}");
    }
}

#[test]
fn edge_use_resolution_ignores_unmatched_nodes() {
    let node = [
        0xb2, 0x03, 0x5e, 0x06, 0x05, 0x03, 0x09, 0x0f, 0x07, 0x0b, 0x21,
    ];
    let bytes = node.repeat(1024);
    let records = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(records.len(), 1024);
    let runs = super::consolidated_edge_use_runs_from_records(&bytes, &records)
        .expect("unmatched node windows parse");
    assert!(runs.is_empty());
}

#[test]
fn object_stream_vertex_record_reads_one_xyz_point() {
    let mut bytes = vec![0xb2, 0x03, 0x06, 0x00, 0x05, 0x05, 0x08, 0x01];
    for value in [1.0_f32, 2.0, 3.0] {
        bytes.extend_from_slice(&value.to_le_bytes());
    }

    let vertices = crate::families::consolidated::records::object_stream_vertices(&bytes)
        .expect("decode the object stream vertices");
    assert_eq!(vertices.len(), 1);
    assert_eq!(
        vertices[0].get(),
        cadmpeg_ir::math::Point3::new(1.0, 2.0, 3.0)
    );
}

#[test]
fn requested_edge_resolution_preserves_full_resolution_geometry() {
    use crate::families::consolidated::records::{
        resolve_consolidated_edge_blocks_from_records, resolve_selected_consolidated_edge_blocks,
    };
    let mut bytes = a5_cylinder_bound_edge_stream();
    bytes.extend(a5_cylinder_bound_edge_stream());
    let records = crate::wire::records::consolidated_records(&bytes);
    crate::test_support::with_service_context(|ctx| {
        let full = resolve_consolidated_edge_blocks_from_records(
            ctx,
            &bytes,
            &records,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("full resolution");
        assert_eq!(full.len(), 2);
        let selected = resolve_selected_consolidated_edge_blocks(
            ctx,
            &bytes,
            &records,
            |block| block.pcurves[0].pos == full[1].block.pcurves[0].pos,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("selected resolution");
        assert_eq!(selected.len(), 1);
        assert_eq!(selected[0].supports, full[1].supports);
        assert_eq!(selected[0].shared_loci, full[1].shared_loci);
        assert_eq!(selected[0].endpoint_loci, full[1].endpoint_loci);
        let empty = resolve_selected_consolidated_edge_blocks(
            ctx,
            &bytes,
            &records,
            |_| false,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("empty selection");
        assert!(empty.is_empty());
    });
}
