// SPDX-License-Identifier: Apache-2.0
//! Consolidated record framing and edge-resolution vocabulary.
//!
//! Inventories length-closed A/B-family records, groups consolidated edge runs
//! and their native incidence graph, and resolves edge-block side carriers
//! against typed analytic and NURBS charts.

use crate::math::{distance_at_most, distance_below};
use cadmpeg_core::decode::DecodeContext;
use cadmpeg_core::CodecError;
use cadmpeg_ir::eval::nurbs_surface_partials;
use cadmpeg_ir::features::FinitePoint3;
#[cfg(test)]
use cadmpeg_ir::geometry::{SolvedSurfaceGeometry, SurfaceGeometry};
use cadmpeg_ir::math::{Point3, Vector3};
use cadmpeg_ir::scalar::{FiniteReal, PositiveReal};
use cadmpeg_ir::topology::IncreasingParameterInterval;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::ops::Range;

use crate::families::a5a8::records::{a5_surfaces_from_records, FreeformSurface};
use crate::families::b2::records::{
    b2_adjacent_face_counted_owners_from_records, b2_circles_from_records,
    b2_class25_descriptors_from_records, b2_closed_owner_boundary_edges, b2_cone_point,
    b2_cones_from_records, b2_cylinder_point, b2_cylinders_from_records,
    b2_edge_nodes_from_records, b2_edge_parameters_from_records, b2_face_nodes_5f_from_records,
    b2_owner_identity_targets_from_records, b2_owner_packets_from_records,
    b2_plane_carriers_from_records, b2_plane_geometry, b2_sphere_geometry, b2_spheres_from_records,
    b2_tori_from_records, b2_torus_geometry, b2_use_metadata_from_records, B2Circle,
    B2Class25Descriptor, B2Cone, B2Cylinder, B2EdgeNode, B2EdgeParameters, B2FaceNode5f,
    B2PlaneCarrier, B2Sphere, B2Torus, B2UseMetadata, B2_SINGLE_CHILD_ALLOCATION_PAYLOAD,
};
use crate::wire::bytes::{
    compact_int, persistent_ref, read_f64_array, AllocationReferenceEncoding,
};
#[cfg(test)]
use crate::wire::records::consolidated_records;
use crate::wire::records::{
    family_pcurves_from_records, records_are_contiguous, scan_vertex_record_ranges,
    ConsolidatedFamily, ConsolidatedPcurve, ConsolidatedPcurveSite, ConsolidatedRawFrame,
    ConsolidatedRecord,
};

const EPS_TRANSVERSE_RESIDUAL: f64 = 1.0e-6;
const EPS_SAMPLE_AGREEMENT: f64 = 1.0e-6;
const EPS_ENDPOINT_RANGE: f64 = 1.0e-6;
const EPS_CIRCLE_ENDPOINT: f64 = 1.0e-9;

/// Serialized consolidated edge block formed by two pcurves and one range packet.
#[derive(Debug, Clone)]
pub(crate) struct ConsolidatedEdgeBlock {
    /// The two face-side UV definitions in serialization order.
    pub(crate) pcurves: [ConsolidatedPcurve; 2],
    /// Shared parameter range and tolerance packet.
    pub(crate) parameters: B2EdgeParameters,
}

/// Complete consolidated edge run serialized as two side pcurves, their shared
/// parameter packet, two oriented uses, and one native edge node.
#[derive(Debug, Clone)]
pub(crate) struct ConsolidatedTopologyEdgeRun {
    /// Co-parametric side definitions and shared range packet.
    pub(crate) edge: ConsolidatedEdgeBlock,
    /// Native edge node carrying curve, endpoint, and endpoint-parameter identities.
    pub(crate) node: B2EdgeNode,
}

/// Complete analytic-circle edge run serialized as a class-`0x18` descriptor,
/// circle carrier, scalar definition, two oriented uses, and one edge node.
#[derive(Debug, Clone)]
pub(crate) struct ConsolidatedAnalyticCircleEdgeRun {
    /// Class-`0x18` descriptor immediately preceding the circle carrier.
    pub(crate) descriptor: ConsolidatedRawFrame,
    /// Arc-length circle carrier.
    pub(crate) circle: B2Circle,
    /// Eight-scalar class-`0x23` edge definition.
    #[cfg(test)]
    pub(super) definition: ConsolidatedEdgeDefinition,
    /// Native edge node carrying curve, endpoint, and endpoint-parameter identities.
    pub(crate) node: B2EdgeNode,
}

/// Complete class-`0x25` edge run with its adjacent class-`0x18` descriptor.
#[derive(Debug, Clone)]
pub(crate) struct ConsolidatedClass25EdgeRun {
    /// Typed class-`0x18` descriptor.
    pub(crate) descriptor: B2Class25Descriptor,
    /// Native edge node carrying curve, endpoint, and endpoint-parameter identities.
    pub(crate) node: B2EdgeNode,
}

/// A native edge node and its two adjacent oriented uses.
#[derive(Debug, Clone)]
pub(crate) struct ConsolidatedEdgeUseRun {
    /// Adjacent source-closed edge-definition frame in classes `0x23..=0x25`.
    pub(crate) definition: Option<ConsolidatedEdgeDefinition>,
    /// The two serialized edge uses, in side order.
    pub(crate) uses: [B2UseMetadata; 2],
    /// Native edge node carrying curve, endpoint, and endpoint-parameter identities.
    pub(crate) node: B2EdgeNode,
}

/// Compact edge node selected by its zero-based ordinal in one face-owner allocation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ConsolidatedOwnedEdgeNode {
    /// Byte offset of the owning class-`0x62` packet.
    pub(crate) owner_pos: usize,
    /// Zero-based frame ordinal after the owner packet.
    pub(crate) allocation_ordinal: u32,
    /// Selected compact edge node.
    pub(crate) node: B2EdgeNode,
}

/// Compact edge endpoints resolved through structural allocation references.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ConsolidatedCompactEdgeEndpoints {
    /// Edge node whose endpoint references closed under the local allocation grammar.
    pub(crate) node: B2EdgeNode,
    /// Byte offsets of the resolved endpoint records, in edge order.
    pub(crate) endpoint_records: [usize; 2],
}

/// One fixed-nine owner boundary closed by four resolved class-`0x5e` edges.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ConsolidatedOwnerBoundaryCycle {
    /// Bounded record source containing the owner and its local targets.
    pub(crate) source_index: usize,
    /// Class-`0x62` owner-record offset.
    pub(crate) owner_pos: usize,
    /// Source-scoped class-`0x5f` face node associated with this boundary
    /// allocation, when the cycle prelude closes its checked identity.
    pub(crate) face_node: Option<B2FaceNode5f>,
    /// Four edge targets in fixed-nine slot order.
    pub(crate) edges: [crate::families::b2::records::B2OwnerBoundaryEdge; 4],
}

/// Class of a consolidated edge-definition frame.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum ConsolidatedEdgeDefinitionClass {
    Class23,
    Class24,
    Class25,
}

impl From<ConsolidatedEdgeDefinitionClass> for u8 {
    fn from(class: ConsolidatedEdgeDefinitionClass) -> Self {
        match class {
            ConsolidatedEdgeDefinitionClass::Class23 => 0x23,
            ConsolidatedEdgeDefinitionClass::Class24 => 0x24,
            ConsolidatedEdgeDefinitionClass::Class25 => 0x25,
        }
    }
}

impl TryFrom<u8> for ConsolidatedEdgeDefinitionClass {
    type Error = String;
    fn try_from(class: u8) -> Result<Self, Self::Error> {
        match class {
            0x23 => Ok(Self::Class23),
            0x24 => Ok(Self::Class24),
            0x25 => Ok(Self::Class25),
            _ => Err(format!(
                "edge-definition class {class:#x} is not 0x23, 0x24, or 0x25"
            )),
        }
    }
}

/// Framed edge definition structurally owned by an adjacent oriented-use run.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct ConsolidatedEdgeDefinition {
    /// Framed record.
    pub(crate) frame: ConsolidatedRawFrame,
    /// Edge-definition class in `0x23..=0x25`.
    pub(crate) class: ConsolidatedEdgeDefinitionClass,
}

#[cfg(test)]
impl ConsolidatedEdgeDefinition {
    fn data(&self) -> Option<ConsolidatedEdgeDefinitionData> {
        consolidated_edge_definition_data(self.class.into(), &self.frame.payload)
    }
}

/// The two serialized local-slot orders of a class-23 parameter map.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "[u32; 2]", into = "[u32; 2]")]
pub(crate) enum Class23Slots {
    OneTwo,
    TwoOne,
}

impl TryFrom<[u32; 2]> for Class23Slots {
    type Error = &'static str;

    fn try_from(slots: [u32; 2]) -> Result<Self, Self::Error> {
        match slots {
            [1, 2] => Ok(Self::OneTwo),
            [2, 1] => Ok(Self::TwoOne),
            _ => Err("class-23 local slots must be [1,2] or [2,1]"),
        }
    }
}

impl From<Class23Slots> for [u32; 2] {
    fn from(slots: Class23Slots) -> Self {
        match slots {
            Class23Slots::OneTwo => [1, 2],
            Class23Slots::TwoOne => [2, 1],
        }
    }
}

/// Closed payload grammar of a consolidated edge-definition frame.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "kind")]
pub(crate) enum ConsolidatedEdgeDefinitionData {
    /// Compact class-`0x24` payload `81 <operand> 0f 87`.
    Compact24 {
        /// Width-coded operand.
        operand: u32,
    },
    /// Eight-scalar class-`0x23` affine parameter map.
    Affine23 {
        /// Ordered local representation slots.
        slots: Class23Slots,
        /// Target representation's parameter interval.
        target_range: IncreasingParameterInterval,
        /// Source representation's parameter interval.
        source_range: IncreasingParameterInterval,
        /// Positive, repeated endpoint residual bound.
        tolerance: PositiveReal,
        /// Positive source-to-target multiplier.
        scale: PositiveReal,
        /// Source-to-target translation.
        offset: FiniteReal,
    },
    /// Class-`0x24` parameter-domain relation.
    Domain24 {
        #[serde(flatten)]
        relation: class24::Class24DomainRelation,
    },
    /// Nine class-`0x23` scalar lanes comprising three equal triples.
    Scalar23 {
        /// Two compact operands followed by one persistent operand.
        operands: [u32; 3],
        /// Complete finite scalar lane.
        values: [FiniteReal; 9],
    },
    /// Class-`0x25` affine or sampled parameter map.
    Domain25 {
        #[serde(flatten)]
        relation: class25::Class25ParameterMap,
    },
}

/// Decode a complete class-specific edge-definition payload with fixed storage.
#[must_use]
pub(crate) fn consolidated_edge_definition_data(
    class: u8,
    payload: &[u8],
) -> Option<ConsolidatedEdgeDefinitionData> {
    if class == 0x24 && payload.first() == Some(&0x81) {
        return Some(ConsolidatedEdgeDefinitionData::Compact24 {
            operand: class24_compact_operand(payload)?,
        });
    }
    if class == 0x24 {
        return Some(ConsolidatedEdgeDefinitionData::Domain24 {
            relation: class24::parse(payload)?,
        });
    }
    if class == 0x25 {
        return Some(ConsolidatedEdgeDefinitionData::Domain25 {
            relation: class25::parse(payload)?,
        });
    }
    if class != 0x23 || payload.first() != Some(&0x82) {
        return None;
    }
    let mut at = 1;
    let operands = [
        compact_int(payload, &mut at)?,
        compact_int(payload, &mut at)?,
        persistent_ref(payload, &mut at)?,
    ];
    let scalar_bytes = payload.get(at..)?;
    if !matches!(scalar_bytes.len(), 64 | 72) {
        return None;
    }
    if scalar_bytes.len() == 64 {
        return class23_affine_map_payload(payload);
    }
    let values = read_f64_array::<9>(scalar_bytes, 0)?;
    if !(values[0] == values[3]
        && values[0] == values[6]
        && values[1] == values[4]
        && values[1] == values[7]
        && values[2] == values[5]
        && values[2] == values[8]
        && values[5].get() == 1.0)
    {
        return None;
    }
    Some(ConsolidatedEdgeDefinitionData::Scalar23 { operands, values })
}

fn class24_compact_operand(payload: &[u8]) -> Option<u32> {
    if payload.first() != Some(&0x81) {
        return None;
    }
    let mut at = 1;
    let operand = compact_int(payload, &mut at)?;
    (payload.get(at..) == Some(&[0x0f, 0x87][..])).then_some(operand)
}

fn class23_affine_map_payload(payload: &[u8]) -> Option<ConsolidatedEdgeDefinitionData> {
    if payload.len() != 70 {
        return None;
    }
    let slots = match payload.get(..6)? {
        [0x82, 0x05, 0x09, 0x0a, 0x87, 0x0d] => Class23Slots::OneTwo,
        [0x82, 0x09, 0x05, 0x0a, 0x87, 0x0d] => Class23Slots::TwoOne,
        _ => return None,
    };
    let values = read_f64_array::<8>(payload, 6)?;
    if values[2] != values[7] {
        return None;
    }
    let target_range = IncreasingParameterInterval::between(values[0], values[1])?;
    let source_range = IncreasingParameterInterval::between(values[3], values[4])?;
    let tolerance = PositiveReal::new(values[2].get())?;
    let scale = PositiveReal::new(values[5].get())?;
    let offset = values[6];
    if slots == Class23Slots::TwoOne
        && (target_range != source_range || scale.get() != 1.0 || offset.get() != 0.0)
    {
        return None;
    }
    if !source_range
        .endpoints()
        .into_iter()
        .zip(target_range.endpoints())
        .all(|(source, target)| {
            (scale.get() * source + offset.get() - target).abs() <= tolerance.get()
        })
    {
        return None;
    }
    Some(ConsolidatedEdgeDefinitionData::Affine23 {
        slots,
        target_range,
        source_range,
        tolerance,
        scale,
        offset,
    })
}

/// Native endpoint-incidence graph of complete consolidated edge runs.
#[derive(Debug, Clone)]
#[cfg(test)]
struct ConsolidatedNativeEdgeGraph {
    /// Persistent native vertex identities in first-incidence order.
    pub(super) vertex_identities: Vec<u32>,
    /// Edge runs in serialization order, with endpoints indexing
    /// `vertex_identities`.
    pub(super) edges: Vec<ConsolidatedNativeGraphEdge>,
    /// Connected edge components, expressed as edge ordinals.
    pub(super) components: Vec<Vec<usize>>,
}

/// One edge in a consolidated native endpoint-incidence graph.
#[derive(Debug, Clone)]
#[cfg(test)]
struct ConsolidatedNativeGraphEdge {
    /// Compact endpoint indices into [`ConsolidatedNativeEdgeGraph::vertex_identities`].
    pub(super) vertices: [usize; 2],
}

/// Uniquely resolved carrier for one side of a consolidated edge block.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) enum ConsolidatedSupportBinding {
    /// Standalone `b2 03 28` cylinder record.
    Cylinder {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// `b2 03 19` circle selected by constant-V and exact arc range.
    Circle {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// `b2 03 29` cone selected by endpoint lifts.
    Cone {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// `b2 03 2a` sphere selected by endpoint lifts.
    Sphere {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// `b2 03 2b` torus selected by endpoint lifts through its scaled chart.
    Torus {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// Direction-bearing `b2/b3/b4 03 27` plane carrier selected by endpoint lifts.
    Plane {
        /// Carrier record byte offset.
        pos: usize,
    },
    /// Consolidated `a5 03 34` NURBS carrier, optionally at a constant normal offset.
    NurbsCarrier {
        /// Carrier record byte offset.
        pos: usize,
        /// Signed normal offset from the stored carrier to the shared 3D edge.
        offset: FiniteReal,
    },
}

/// Consolidated edge block with uniquely resolved side carriers.
#[derive(Debug, Clone)]
pub(crate) struct ResolvedConsolidatedEdgeBlock {
    /// Parsed pcurve pair and shared edge packet.
    pub(crate) block: ConsolidatedEdgeBlock,
    /// Carrier binding for each pcurve side.
    pub(crate) supports: [Option<ConsolidatedSupportBinding>; 2],
    /// Shared lifted 3D definition sites when every liftable side agrees
    /// pointwise in the common edge parameterization.
    pub(crate) shared_loci: Option<Vec<Point3>>,
    /// Unordered 3D endpoint loci when at least one uniquely bound side can be
    /// lifted and every liftable side agrees.
    pub(crate) endpoint_loci: Option<[Point3; 2]>,
}

struct ConsolidatedCarriers<'a> {
    cylinders: &'a [B2Cylinder],
    circles: &'a [B2Circle],
    cones: &'a [B2Cone],
    spheres: &'a [B2Sphere],
    tori: &'a [B2Torus],
    planes: &'a [B2PlaneCarrier],
    nurbs_surfaces: &'a [FreeformSurface],
}

/// Group ordered pairs of same-family class-`0x20` pcurves followed by one
/// B-family class-`0x23` range packet.
#[must_use]
#[cfg(test)]
fn consolidated_edge_blocks(data: &[u8]) -> Vec<ConsolidatedEdgeBlock> {
    let records = consolidated_records(data);
    consolidated_edge_blocks_from_records(data, &records)
}

fn consolidated_edge_blocks_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<ConsolidatedEdgeBlock> {
    let mut pcurves = BTreeMap::new();
    for family in [ConsolidatedFamily::A, ConsolidatedFamily::B] {
        for value in family_pcurves_from_records(data, records, family) {
            pcurves.insert(value.pos, value);
        }
    }
    let mut parameters = BTreeMap::new();
    for value in b2_edge_parameters_from_records(data, records) {
        parameters.insert(value.pos, value);
    }
    let mut blocks = Vec::new();
    for window in records.windows(3) {
        let [first_record, second_record, parameter_record] = window else {
            continue;
        };
        if records_are_contiguous(window)
            && first_record.class() == 0x20
            && second_record.class() == 0x20
            && first_record.family() == second_record.family()
            && parameter_record.family() == ConsolidatedFamily::B
            && parameter_record.class() == 0x23
        {
            if let (Some(first), Some(second), Some(parameter)) = (
                pcurves.get(&first_record.byte_offset()),
                pcurves.get(&second_record.byte_offset()),
                parameters.get(&parameter_record.byte_offset()),
            ) {
                let co_parametric = first.sites.len() == second.sites.len()
                    && first.range == second.range
                    && first.range == parameter.range;
                if co_parametric {
                    if let (Some(first), Some(second), Some(parameter)) = (
                        pcurves.remove(&first_record.byte_offset()),
                        pcurves.remove(&second_record.byte_offset()),
                        parameters.remove(&parameter_record.byte_offset()),
                    ) {
                        blocks.push(ConsolidatedEdgeBlock {
                            pcurves: [first, second],
                            parameters: parameter,
                        });
                    }
                }
            }
        }
    }
    blocks
}

/// Decode complete six-record consolidated edge runs. Records separated by any
/// other framed record do not form a run.
#[must_use]
#[cfg(test)]
fn consolidated_topology_edge_runs(data: &[u8]) -> Vec<ConsolidatedTopologyEdgeRun> {
    let records = consolidated_records(data);
    consolidated_topology_edge_runs_from_records(data, &records)
        .expect("decode the consolidated topology edge runs")
}

pub(crate) fn consolidated_topology_edge_runs_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<ConsolidatedTopologyEdgeRun>, CodecError> {
    let mut edges = BTreeMap::new();
    for edge in consolidated_edge_blocks_from_records(data, records) {
        edges.insert(edge.pcurves[0].pos, edge);
    }
    let mut use_runs = BTreeMap::new();
    for value in consolidated_edge_use_runs_from_records(data, records)? {
        use_runs.insert(value.uses[0].pos, value);
    }
    let mut runs = Vec::new();
    for window in records.windows(6) {
        let [pcurve0, pcurve1, parameters, use0, use1, node] = window else {
            continue;
        };
        if records_are_contiguous(window)
            && pcurve0.class() == 0x20
            && pcurve1.class() == 0x20
            && pcurve0.family() == pcurve1.family()
            && parameters.family() == ConsolidatedFamily::B
            && parameters.class() == 0x23
            && use0.family() == ConsolidatedFamily::B
            && use0.class() == 0x06
            && use1.family() == ConsolidatedFamily::B
            && use1.class() == 0x06
            && node.family() == ConsolidatedFamily::B
            && node.class() == 0x5e
        {
            if let (Some(edge), Some(use_run)) = (
                edges.remove(&pcurve0.byte_offset()),
                use_runs.remove(&use0.byte_offset()),
            ) {
                runs.push(ConsolidatedTopologyEdgeRun {
                    edge,
                    node: use_run.node,
                });
            }
        }
    }
    Ok(runs)
}

/// Decode adjacent `18,19,23,06,06,5e` analytic-circle edge runs. The
/// class-`0x23` definition must close under the eight-scalar grammar.
#[must_use]
#[cfg(test)]
fn consolidated_analytic_circle_edge_runs(data: &[u8]) -> Vec<ConsolidatedAnalyticCircleEdgeRun> {
    let records = consolidated_records(data);
    consolidated_analytic_circle_edge_runs_from_records(data, &records)
        .expect("decode the consolidated analytic circle edge runs")
}

pub(crate) fn consolidated_analytic_circle_edge_runs_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<ConsolidatedAnalyticCircleEdgeRun>, CodecError> {
    let mut circles = BTreeMap::new();
    for value in b2_circles_from_records(data, records) {
        circles.insert(value.pos, value);
    }
    let mut use_runs = BTreeMap::new();
    for value in consolidated_edge_use_runs_from_records(data, records)? {
        use_runs.insert(value.uses[0].pos, value);
    }
    let mut runs = Vec::new();
    for window in records.windows(6) {
        let candidate = (|| {
            let [parameter, circle, definition, use0, use1, node] = window else {
                return None;
            };
            if !records_are_contiguous(window) {
                return None;
            }
            if parameter.family() != ConsolidatedFamily::B
                || parameter.class() != 0x18
                || circle.family() != ConsolidatedFamily::B
                || circle.class() != 0x19
                || definition.family() != ConsolidatedFamily::B
                || definition.class() != 0x23
                || use0.family() != ConsolidatedFamily::B
                || use0.class() != 0x06
                || use1.family() != ConsolidatedFamily::B
                || use1.class() != 0x06
                || node.family() != ConsolidatedFamily::B
                || node.class() != 0x5e
            {
                return None;
            }
            let use_run = use_runs.get(&use0.byte_offset())?;
            let definition = use_run.definition.as_ref()?;
            let ConsolidatedEdgeDefinitionData::Affine23 {
                slots: Class23Slots::OneTwo,
                target_range,
                ..
            } = class23_affine_map_payload(&definition.frame.payload)?
            else {
                return None;
            };
            if use_run.uses[0].references() != Some(&[1, 2][..])
                || use_run.uses[1].references() != Some(&[2, 3][..])
            {
                return None;
            }
            let circle = circles.get(&circle.byte_offset())?;
            (target_range.endpoints().map(f64::to_bits)
                == circle.range.endpoints().map(f64::to_bits))
            .then_some((parameter, circle, use_run))
        })();
        let Some((parameter, circle, use_run)) = candidate else {
            continue;
        };
        let Some(payload) = parameter.payload() else {
            continue;
        };
        #[cfg(test)]
        let Some(definition) = use_run.definition.as_ref() else {
            continue;
        };
        #[cfg(test)]
        let definition = ConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::new(
                definition.frame.pos,
                definition.frame.width(),
                definition.frame.flag,
                definition.frame.header_token(),
                definition.frame.payload.to_vec(),
            )
            .map_err(CodecError::malformed)?,
            class: definition.class,
        };
        let descriptor = ConsolidatedRawFrame::from_record(parameter, data[payload].to_vec())?;
        runs.push(ConsolidatedAnalyticCircleEdgeRun {
            descriptor,
            circle: circle.clone(),
            #[cfg(test)]
            definition,
            node: use_run.node,
        });
    }
    Ok(runs)
}

/// Decode adjacent `18,25,06,06,5e` edge runs whose descriptor and definition
/// both close under their typed grammars.
#[must_use]
#[cfg(test)]
fn consolidated_class25_edge_runs(data: &[u8]) -> Vec<ConsolidatedClass25EdgeRun> {
    let records = consolidated_records(data);
    consolidated_class25_edge_runs_from_records(data, &records)
        .expect("decode the consolidated class 25 edge runs")
}

pub(crate) fn consolidated_class25_edge_runs_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<ConsolidatedClass25EdgeRun>, CodecError> {
    let mut descriptors = BTreeMap::new();
    for value in b2_class25_descriptors_from_records(data, records) {
        descriptors.insert(value.pos, value);
    }
    let mut use_runs = BTreeMap::new();
    for value in consolidated_edge_use_runs_from_records(data, records)? {
        use_runs.insert(value.uses[0].pos, value);
    }
    let mut runs = Vec::new();
    for window in records.windows(5) {
        let candidate = (|| {
            let [descriptor, definition, use0, use1, node] = window else {
                return None;
            };
            if !records_are_contiguous(window) {
                return None;
            }
            if descriptor.family() != ConsolidatedFamily::B
                || descriptor.class() != 0x18
                || definition.family() != ConsolidatedFamily::B
                || definition.class() != 0x25
                || use0.family() != ConsolidatedFamily::B
                || use0.class() != 0x06
                || use1.family() != ConsolidatedFamily::B
                || use1.class() != 0x06
                || node.family() != ConsolidatedFamily::B
                || node.class() != 0x5e
            {
                return None;
            }
            let use_run = use_runs.get(&use0.byte_offset())?;
            let definition = use_run.definition.as_ref()?;
            if definition.frame.flag != crate::wire::records::ConsolidatedFrameFlag::Flag03
                || class25::parse(&definition.frame.payload).is_none()
            {
                return None;
            }
            Some((descriptors.get(&descriptor.byte_offset())?, use_run.node))
        })();
        let Some((descriptor, node)) = candidate else {
            continue;
        };
        runs.push(ConsolidatedClass25EdgeRun {
            descriptor: B2Class25Descriptor {
                pos: descriptor.pos,
                record_id: descriptor.record_id,
                control: descriptor.control,
                values: descriptor.values.clone(),
            },
            node,
        });
    }
    Ok(runs)
}

/// Decode every adjacent `06,06,5e` edge-use run independently of pcurve
/// availability. Records separated by another framed record do not form a run.
#[must_use]
#[cfg(test)]
fn consolidated_edge_use_runs(data: &[u8]) -> Vec<ConsolidatedEdgeUseRun> {
    let records = consolidated_records(data);
    consolidated_edge_use_runs_from_records(data, &records)
        .expect("decode the consolidated edge use runs")
}

pub(crate) fn consolidated_edge_use_runs_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<ConsolidatedEdgeUseRun>, CodecError> {
    let mut runs = Vec::new();
    for (index, window) in records.windows(3).enumerate() {
        let [use0, use1, node_record] = window else {
            continue;
        };
        if !records_are_contiguous(window)
            || use0.family() != ConsolidatedFamily::B
            || use0.class() != 0x06
            || use1.family() != ConsolidatedFamily::B
            || use1.class() != 0x06
            || node_record.family() != ConsolidatedFamily::B
            || node_record.class() != 0x5e
        {
            continue;
        }

        let Some(node_value) =
            b2_edge_nodes_from_records(data, std::slice::from_ref(node_record)).next()
        else {
            continue;
        };
        let parsed_uses = b2_use_metadata_from_records(data, &window[..2]);
        let candidate = (|| {
            let node = node_value;
            let [first, second] = parsed_uses.as_slice() else {
                return None;
            };
            let uses = [first, second];
            let identity_chain_consistent = node
                .curve_ref
                .checked_sub(2)
                .zip(node.curve_ref.checked_sub(1))
                .is_some_and(|(first, second)| {
                    uses[0].references() == Some(&[first, second][..])
                        && uses[1].references() == Some(&[second, node.curve_ref][..])
                })
                && [node.start_parameter_ref, node.end_parameter_ref] == [2, 1];
            let definition = index
                .checked_sub(1)
                .and_then(|preceding| records.get(preceding))
                .filter(|record| {
                    record.source_index() == use0.source_index()
                        && record.source_range().end == use0.source_range().start
                        && record.family() == ConsolidatedFamily::B
                        && matches!(record.class(), 0x23..=0x25)
                });
            if let Some(operand) = definition
                .filter(|record| record.class() == 0x24)
                .and_then(ConsolidatedRecord::payload)
                .and_then(|payload| class24_compact_operand(&data[payload]))
            {
                let first = operand.checked_add(1)?;
                let second = operand.checked_add(2)?;
                if uses[0].references() != Some(&[1, first][..])
                    || uses[1].references() != Some(&[2, second][..])
                    || uses[0].sense() != Some(crate::families::b2::records::B2UseSense::Sense88)
                    || uses[1].sense() != Some(crate::families::b2::records::B2UseSense::Sense84)
                {
                    return None;
                }
            }
            identity_chain_consistent.then_some((definition, node))
        })();
        let Some((definition_record, node)) = candidate else {
            continue;
        };
        let definition = match definition_record.and_then(|record| {
            Some((
                record,
                record.payload()?,
                ConsolidatedEdgeDefinitionClass::try_from(record.class()).ok()?,
            ))
        }) {
            Some((record, payload, class)) => Some(ConsolidatedEdgeDefinition {
                frame: ConsolidatedRawFrame::from_record(record, data[payload].to_vec())?,
                class,
            }),
            None => None,
        };
        let uses = parsed_uses
            .try_into()
            .map_err(|_| CodecError::malformed("edge use chain must contain two uses"))?;
        runs.push(ConsolidatedEdgeUseRun {
            definition,
            uses,
            node,
        });
    }
    for window in records.windows(4) {
        let [node_record, definition_record, use0, use1] = window else {
            continue;
        };
        if !records_are_contiguous(window)
            || node_record.family() != ConsolidatedFamily::B
            || node_record.class() != 0x5e
            || definition_record.family() != ConsolidatedFamily::B
            || definition_record.class() != 0x24
            || use0.family() != ConsolidatedFamily::B
            || use0.class() != 0x06
            || use1.family() != ConsolidatedFamily::B
            || use1.class() != 0x06
        {
            continue;
        }

        let Some(node_value) =
            b2_edge_nodes_from_records(data, std::slice::from_ref(node_record)).next()
        else {
            continue;
        };
        let parsed_uses = b2_use_metadata_from_records(data, &window[2..]);
        let candidate = (|| {
            let node = node_value;
            let [first, second] = parsed_uses.as_slice() else {
                return None;
            };
            let uses = [first, second];
            let payload = &data[definition_record.payload()?];
            let operand = class24_compact_operand(payload)?;
            let identity_chain_consistent = operand
                .checked_add(1)
                .zip(operand.checked_add(2))
                .is_some_and(|(first, second)| {
                    uses[0].references() == Some(&[node.start_parameter_ref, first][..])
                        && uses[1].references() == Some(&[node.end_parameter_ref, second][..])
                })
                && [node.start_parameter_ref, node.end_parameter_ref] == [1, 2]
                && uses[0].sense() == Some(crate::families::b2::records::B2UseSense::Sense88)
                && uses[1].sense() == Some(crate::families::b2::records::B2UseSense::Sense84);
            if !identity_chain_consistent {
                return None;
            }
            Some((definition_record, node))
        })();
        let Some((definition_record, node)) = candidate else {
            continue;
        };
        let Some(payload) = definition_record.payload() else {
            continue;
        };
        let Ok(class) = ConsolidatedEdgeDefinitionClass::try_from(definition_record.class()) else {
            continue;
        };
        let definition = Some(ConsolidatedEdgeDefinition {
            frame: ConsolidatedRawFrame::from_record(definition_record, data[payload].to_vec())?,
            class,
        });
        let uses = parsed_uses
            .try_into()
            .map_err(|_| CodecError::malformed("edge use chain must contain two uses"))?;
        runs.push(ConsolidatedEdgeUseRun {
            definition,
            uses,
            node,
        });
    }
    Ok(runs)
}

/// Resolve compact owner references that land exactly on class-`0x5e` frames.
pub(crate) fn consolidated_owned_edge_nodes_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<ConsolidatedOwnedEdgeNode> {
    let mut indices = BTreeMap::new();
    for (index, record) in records.iter().enumerate() {
        indices.insert((record.source_index(), record.byte_offset()), index);
    }
    let mut nodes = BTreeMap::new();
    for node in b2_edge_nodes_from_records(data, records) {
        nodes.insert(node.pos, node);
    }
    let mut owned = Vec::new();
    for relation in b2_adjacent_face_counted_owners_from_records(data, records) {
        let Some(&owner_index) = indices.get(&(relation.owner.source_index, relation.owner.pos))
        else {
            continue;
        };
        let paired =
            relation.owner.references.len() >= 5 && relation.owner.references.len() % 2 == 1;
        for (slot, (allocation_ordinal, encoding)) in relation
            .owner
            .references
            .into_iter()
            .zip(relation.owner.reference_encodings)
            .enumerate()
        {
            if (paired && slot % 2 == 0) || encoding != AllocationReferenceEncoding::OwnedChild {
                continue;
            }
            let Some(target_index) = usize::try_from(allocation_ordinal)
                .ok()
                .and_then(|ordinal| owner_index.checked_add(1)?.checked_add(ordinal))
                .filter(|target| *target < records.len())
            else {
                continue;
            };
            if !records_are_contiguous(&records[owner_index..=target_index])
                || records[owner_index + 1..=target_index]
                    .iter()
                    .any(|record| counted_owner_allocation_reset(data, record))
            {
                continue;
            }
            let target = &records[target_index];
            if target.family() != ConsolidatedFamily::B || target.class() != 0x5e {
                continue;
            }
            let Some(&node) = nodes.get(&target.byte_offset()) else {
                continue;
            };
            if owned
                .last()
                .is_some_and(|previous: &ConsolidatedOwnedEdgeNode| {
                    previous.owner_pos == relation.owner.pos && previous.node.pos == node.pos
                })
            {
                continue;
            }
            owned.push(ConsolidatedOwnedEdgeNode {
                owner_pos: relation.owner.pos,
                allocation_ordinal,
                node,
            });
        }
    }
    owned
}

/// Resolve compact edge endpoint references through the framed allocation walk.
pub(crate) fn consolidated_compact_edge_endpoints_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<ConsolidatedCompactEdgeEndpoints> {
    struct EndpointResolver<'a> {
        records: &'a [ConsolidatedRecord],
        nodes: &'a HashMap<usize, B2EdgeNode>,
        allocation_locations: &'a HashMap<usize, (usize, usize)>,
        allocation_scopes: &'a [Vec<usize>],
        memo: HashMap<(usize, usize), Option<usize>>,
    }

    /// One endpoint reference: a vertex record, or an edge-use record whose
    /// end endpoint the reference defers to.
    enum EndpointStep {
        Vertex(usize),
        Through(usize),
    }

    impl EndpointResolver<'_> {
        /// Follow a chain of deferring edge-use records to its vertex. Every
        /// endpoint on the chain shares the chain's result; a chain that
        /// returns to one of its own endpoints resolves to `None`.
        fn resolve(&mut self, record_index: usize, endpoint: usize) -> Option<usize> {
            let mut chain = Vec::new();
            let mut on_chain = HashSet::new();
            let mut key = (record_index, endpoint);
            let result = loop {
                if let Some(&cached) = self.memo.get(&key) {
                    break cached;
                }
                if !on_chain.insert(key) {
                    break None;
                }
                chain.push(key);
                match self.step(key.0, key.1) {
                    Some(EndpointStep::Vertex(target)) => break Some(target),
                    Some(EndpointStep::Through(target)) => key = (target, 1),
                    None => break None,
                }
            };
            for key in chain {
                self.memo.insert(key, result);
            }
            result
        }

        fn step(&self, record_index: usize, endpoint: usize) -> Option<EndpointStep> {
            let node = self.nodes.get(&record_index)?;
            let reference = [node.start_vertex_ref, node.end_vertex_ref][endpoint];
            let encoding = node.reference_encodings[endpoint + 1];
            let &(scope, allocation_ordinal) = self.allocation_locations.get(&record_index)?;
            let target = match encoding {
                AllocationReferenceEncoding::OwnedChild => allocation_ordinal
                    .checked_add(1)?
                    .checked_add(usize::try_from(reference).ok()?)
                    .and_then(|target| self.allocation_scopes.get(scope)?.get(target))
                    .copied()?,
                AllocationReferenceEncoding::BackwardDistance => {
                    let target =
                        allocation_ordinal.checked_sub(usize::try_from(reference).ok()?)?;
                    *self.allocation_scopes.get(scope)?.get(target)?
                }
                AllocationReferenceEncoding::WidthCoded => {
                    let target = record_index.checked_add(usize::try_from(reference).ok()?)?;
                    let target_record = self.records.get(target)?;
                    if target_record.source_index()
                        != self.records.get(record_index)?.source_index()
                        || target_record.family() != ConsolidatedFamily::B
                        || target_record.class() != 0x18
                    {
                        return None;
                    }
                    return Some(EndpointStep::Vertex(target));
                }
                AllocationReferenceEncoding::Selector2
                | AllocationReferenceEncoding::TaggedU8
                | AllocationReferenceEncoding::TaggedU16 => return None,
            };
            let target_record = self.records.get(target)?;
            if target_record.family() != ConsolidatedFamily::B {
                return None;
            }
            match target_record.class() {
                0x5d => Some(EndpointStep::Vertex(target)),
                0x5e => Some(EndpointStep::Through(target)),
                _ => None,
            }
        }
    }

    let mut by_pos = HashMap::new();
    for node in b2_edge_nodes_from_records(data, records) {
        by_pos.insert(node.pos, node);
    }
    let mut nodes = HashMap::new();
    for (index, record) in records.iter().enumerate() {
        if let Some(node) = by_pos.get(&record.byte_offset()).copied() {
            nodes.insert(index, node);
        }
    }
    let mut allocation_scopes = Vec::new();
    allocation_scopes.push(Vec::new());
    let mut allocation_locations = HashMap::new();
    for (index, record) in records.iter().enumerate() {
        if index > 0
            && (records[index - 1].source_index() != record.source_index()
                || records[index - 1].source_range().end != record.source_range().start)
        {
            allocation_scopes.push(Vec::new());
        }
        if record.family() == ConsolidatedFamily::B && matches!(record.class(), 0x5d | 0x5e) {
            let scope = allocation_scopes.len() - 1;
            let ordinal = allocation_scopes[scope].len();
            allocation_scopes[scope].push(index);
            allocation_locations.insert(index, (scope, ordinal));
        }
    }
    let mut resolver = EndpointResolver {
        records,
        nodes: &nodes,
        allocation_locations: &allocation_locations,
        allocation_scopes: &allocation_scopes,
        memo: HashMap::new(),
    };
    let mut resolved = HashMap::new();
    for &record_index in nodes.keys() {
        let vertices = [
            resolver.resolve(record_index, 0),
            resolver.resolve(record_index, 1),
        ];
        let [Some(start), Some(end)] = vertices else {
            continue;
        };
        resolved.insert(record_index, [start, end]);
    }
    let CountedOwnerEndpointResolution {
        owned_nodes,
        cycles,
    } = counted_owner_endpoint_cycles(data, records, &nodes);
    let old_resolved = resolved.clone();
    resolved.retain(|index, _| !owned_nodes.contains(index));
    let mut claimed = HashSet::new();
    let mut ambiguous = HashSet::new();
    for CountedOwnerEndpointCycle { edges: cycle } in cycles {
        let old = cycle
            .iter()
            .map(|(index, _)| old_resolved.get(index).copied())
            .collect::<Option<Vec<_>>>();
        let conflict = old.as_ref().is_some_and(|old| {
            is_simple_endpoint_cycle(old) && old.iter().zip(&cycle).any(|(a, (_, b))| a != b)
        });
        for (index, vertices) in cycle {
            if conflict || !claimed.insert(index) {
                ambiguous.insert(index);
            } else {
                resolved.insert(index, vertices);
            }
        }
    }
    let mut endpoints = Vec::new();
    for (record_index, vertices) in resolved {
        if ambiguous.contains(&record_index) {
            continue;
        }
        endpoints.push(ConsolidatedCompactEdgeEndpoints {
            node: nodes[&record_index],
            endpoint_records: vertices.map(|index| records[index].byte_offset()),
        });
    }
    endpoints.sort_by_key(|left| left.node.pos);
    endpoints
}

fn is_simple_endpoint_cycle(edges: &[[usize; 2]]) -> bool {
    if edges.len() < 3 {
        return false;
    }
    let mut adjacency = HashMap::<usize, Vec<usize>>::new();
    for &[a, b] in edges {
        if a == b {
            return false;
        }
        adjacency.entry(a).or_default().push(b);
        adjacency.entry(b).or_default().push(a);
    }
    if adjacency.len() != edges.len() || adjacency.values().any(|neighbors| neighbors.len() != 2) {
        return false;
    }
    let mut visited = HashSet::new();
    let mut pending = vec![edges[0][0]];
    while let Some(vertex) = pending.pop() {
        if visited.insert(vertex) {
            pending.extend(adjacency[&vertex].iter().copied());
        }
    }
    visited.len() == adjacency.len()
}

struct CountedOwnerEndpointCycle {
    edges: Vec<(usize, [usize; 2])>,
}

struct CountedOwnerEndpointResolution {
    owned_nodes: HashSet<usize>,
    cycles: Vec<CountedOwnerEndpointCycle>,
}

fn counted_owner_allocation_reset(data: &[u8], record: &ConsolidatedRecord) -> bool {
    record.family() == ConsolidatedFamily::B
        && (matches!(record.class(), 0x5f | 0x62)
            || (record.class() == 0x65
                && record
                    .payload()
                    .and_then(|payload| data.get(payload))
                    .is_none_or(|payload| {
                        payload == B2_SINGLE_CHILD_ALLOCATION_PAYLOAD.as_slice()
                    })))
}

fn counted_owner_endpoint_cycles(
    data: &[u8],
    records: &[ConsolidatedRecord],
    nodes: &HashMap<usize, B2EdgeNode>,
) -> CountedOwnerEndpointResolution {
    let mut scopes = Vec::with_capacity(records.len());
    let mut scope = 0usize;
    let mut indices = HashMap::new();
    for (index, record) in records.iter().enumerate() {
        let reset = counted_owner_allocation_reset(data, record);
        if reset || (index > 0 && !records_are_contiguous(&records[index - 1..=index])) {
            scope += 1;
        }
        scopes.push(scope);
        indices.insert((record.source_index(), record.byte_offset()), index);
    }
    let mut owned_nodes = HashSet::new();
    let mut cycles = Vec::new();
    for relation in b2_adjacent_face_counted_owners_from_records(data, records) {
        let owner = &relation.owner;
        if owner.references.len() < 5 || owner.references.len() % 2 == 0 {
            continue;
        }
        let Some(&owner_index) = indices.get(&(owner.source_index, owner.pos)) else {
            continue;
        };
        let Some(first) = owner_index
            .checked_add(1)
            .filter(|index| *index < records.len())
        else {
            continue;
        };
        if scopes[first] != scopes[owner_index] {
            continue;
        }
        let allocation_scope = scopes[first];
        for (pair, encodings) in owner.references[..owner.references.len() - 1]
            .chunks_exact(2)
            .zip(owner.reference_encodings[..owner.reference_encodings.len() - 1].chunks_exact(2))
        {
            if encodings[1] == AllocationReferenceEncoding::OwnedChild {
                if let Some(index) = usize::try_from(pair[1])
                    .ok()
                    .and_then(|ordinal| first.checked_add(ordinal))
                    .filter(|index| scopes.get(*index) == Some(&allocation_scope))
                    .filter(|index| {
                        nodes.get(index).is_some_and(|node| {
                            node.reference_encodings[1..3].iter().all(|encoding| {
                                matches!(
                                    encoding,
                                    AllocationReferenceEncoding::OwnedChild
                                        | AllocationReferenceEncoding::BackwardDistance
                                )
                            })
                        })
                    })
                {
                    owned_nodes.insert(index);
                }
            }
        }
        let candidate = owner.references[..owner.references.len() - 1]
            .chunks_exact(2)
            .zip(owner.reference_encodings[..owner.reference_encodings.len() - 1].chunks_exact(2))
            .map(|(pair, encodings)| {
                if encodings[1] != AllocationReferenceEncoding::OwnedChild {
                    return None;
                }
                let index = first.checked_add(usize::try_from(pair[1]).ok()?)?;
                if *scopes.get(index)? != allocation_scope {
                    return None;
                }
                let node = nodes.get(&index)?;
                let mut vertices = [0; 2];
                for (endpoint, vertex) in vertices.iter_mut().enumerate() {
                    let value = [node.start_vertex_ref, node.end_vertex_ref][endpoint];
                    let distance = usize::try_from(value).ok()?;
                    let target = match node.reference_encodings[endpoint + 1] {
                        AllocationReferenceEncoding::OwnedChild => {
                            index.checked_add(1)?.checked_add(distance)?
                        }
                        AllocationReferenceEncoding::BackwardDistance => {
                            index.checked_sub(distance)?
                        }
                        _ => return None,
                    };
                    let target_record = records.get(target)?;
                    if target < first
                        || scopes[target] != allocation_scope
                        || target_record.family() != ConsolidatedFamily::B
                        || target_record.class() != 0x5d
                    {
                        return None;
                    }
                    *vertex = target;
                }
                Some((index, vertices))
            })
            .collect::<Option<Vec<_>>>();
        let Some(candidate) = candidate else {
            continue;
        };
        let unique = candidate
            .iter()
            .map(|(index, _)| *index)
            .collect::<HashSet<_>>();
        let edges = candidate.iter().map(|(_, edge)| *edge).collect::<Vec<_>>();
        if unique.len() == candidate.len() && is_simple_endpoint_cycle(&edges) {
            cycles.push(CountedOwnerEndpointCycle { edges: candidate });
        }
    }
    CountedOwnerEndpointResolution {
        owned_nodes,
        cycles,
    }
}

/// Derive owner-local four-edge boundary cycles from fixed-nine references.
/// Every returned endpoint is closed by the same bounded record source as its
/// owner. Other fixed-nine roles remain unclassified.
pub(crate) fn consolidated_owner_boundary_cycles_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<ConsolidatedOwnerBoundaryCycle> {
    let mut endpoint_records = HashMap::new();
    for binding in consolidated_compact_edge_endpoints_from_records(data, records) {
        endpoint_records.insert(binding.node.pos, binding.endpoint_records);
    }
    let mut face_nodes = BTreeMap::new();
    for node in b2_face_nodes_5f_from_records(data, records) {
        face_nodes.insert(node.pos, node);
    }
    let mut record_indices = BTreeMap::new();
    let mut record_sources = HashMap::new();
    for (index, record) in records.iter().enumerate() {
        record_indices.insert(record.byte_offset(), index);
        record_sources.insert(record.byte_offset(), record.source_index());
    }
    let mut targets_by_owner = BTreeMap::<(usize, usize), Vec<_>>::new();
    for target in b2_owner_identity_targets_from_records(data, records) {
        let key = (target.source_index, target.owner_pos);
        if let Some(targets) = targets_by_owner.get_mut(&key) {
            targets.push(target);
        } else {
            let targets = vec![target];
            targets_by_owner.insert(key, targets);
        }
    }
    let mut cycles = Vec::new();
    for packet in b2_owner_packets_from_records(data, records) {
        let Some(targets) = targets_by_owner.get(&(packet.source_index, packet.pos)) else {
            continue;
        };
        let Some(edges) = b2_closed_owner_boundary_edges(targets, &endpoint_records) else {
            continue;
        };
        let cycle = {
            let face_node = (|| {
                let first_edge_pos = edges.iter().map(|edge| edge.target_pos).min()?;
                let &first_edge_index = record_indices.get(&first_edge_pos)?;
                let node_index = first_edge_index.checked_sub(1)?;
                let node_record = records.get(node_index)?;
                let face_node = face_nodes.get(&node_record.byte_offset())?;
                if !matches!(face_node.terminal, [0x27, 0x03 | 0x05]) {
                    return None;
                }
                let &owner_index = record_indices.get(&packet.pos)?;
                if owner_index <= first_edge_index
                    || !records_are_contiguous(&records[node_index..=owner_index])
                {
                    return None;
                }
                let span = &records[first_edge_index..owner_index];
                if span.iter().any(|record| {
                    record.family() != ConsolidatedFamily::B
                        || !matches!(record.class(), 0x5d | 0x5e)
                }) || span.iter().filter(|record| record.class() == 0x5e).count() != 4
                {
                    return None;
                }
                if edges.iter().any(|edge| {
                    !span
                        .iter()
                        .any(|record| record.byte_offset() == edge.target_pos)
                }) {
                    return None;
                }
                (packet.references[8].checked_add(10) == Some(face_node.target))
                    .then_some(*face_node)
            })();
            edges
                .iter()
                .all(|edge| {
                    record_sources.get(&edge.target_pos) == Some(&packet.source_index)
                        && edge.endpoint_records.iter().all(|endpoint| {
                            record_sources.get(endpoint) == Some(&packet.source_index)
                        })
                })
                .then_some(ConsolidatedOwnerBoundaryCycle {
                    source_index: packet.source_index,
                    owner_pos: packet.pos,
                    face_node,
                    edges,
                })
        };
        if let Some(cycle) = cycle {
            cycles.push(cycle);
        }
    }
    cycles
}

/// Build the native endpoint-incidence graph for all complete consolidated
/// edge runs. A broken use/edge allocation chain invalidates the graph.
#[must_use]
#[cfg(test)]
fn consolidated_native_edge_graph(data: &[u8]) -> Option<ConsolidatedNativeEdgeGraph> {
    let runs = consolidated_topology_edge_runs(data);
    if runs.is_empty() {
        return None;
    }
    let mut vertex_indices = HashMap::new();
    let mut vertex_identities = Vec::new();
    let mut edges = Vec::with_capacity(runs.len());
    for run in runs {
        let vertices = [run.node.start_vertex_ref, run.node.end_vertex_ref].map(|identity| {
            *vertex_indices.entry(identity).or_insert_with(|| {
                let index = vertex_identities.len();
                vertex_identities.push(identity);
                index
            })
        });
        edges.push(ConsolidatedNativeGraphEdge { vertices });
    }
    let mut vertex_edges = vec![Vec::new(); vertex_identities.len()];
    for (edge, value) in edges.iter().enumerate() {
        for vertex in value.vertices {
            vertex_edges[vertex].push(edge);
        }
    }
    let mut unseen = (0..edges.len()).collect::<std::collections::BTreeSet<_>>();
    let mut components = Vec::new();
    while let Some(&first) = unseen.first() {
        let mut component = Vec::new();
        let mut stack = vec![first];
        unseen.remove(&first);
        while let Some(edge) = stack.pop() {
            component.push(edge);
            for vertex in edges[edge].vertices {
                for &neighbor in &vertex_edges[vertex] {
                    if unseen.remove(&neighbor) {
                        stack.push(neighbor);
                    }
                }
            }
        }
        component.sort_unstable();
        components.push(component);
    }
    Some(ConsolidatedNativeEdgeGraph {
        vertex_identities,
        edges,
        components,
    })
}

/// Resolve consolidated edge sides against typed cylinder, circle, cone, and
/// NURBS carriers.
///
/// A carrier binds only when record identity or chart geometry determines one
/// solution. Ambiguous candidates, including matches from different analytic
/// families, remain unresolved.
#[cfg(test)]
fn resolve_consolidated_edge_blocks(
    data: &[u8],
) -> Result<Vec<ResolvedConsolidatedEdgeBlock>, CodecError> {
    let records = consolidated_records(data);
    crate::test_support::with_service_context(|ctx| {
        resolve_consolidated_edge_blocks_from_records(
            ctx,
            data,
            &records,
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
}

pub(crate) fn resolve_consolidated_edge_blocks_from_records(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<ResolvedConsolidatedEdgeBlock>, cadmpeg_core::CodecError> {
    resolve_selected_consolidated_edge_blocks(ctx, data, records, |_| true, refusal)
}

pub(crate) fn resolve_selected_consolidated_edge_blocks(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    data: &[u8],
    records: &[ConsolidatedRecord],
    include: impl Fn(&ConsolidatedEdgeBlock) -> bool,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<ResolvedConsolidatedEdgeBlock>, cadmpeg_core::CodecError> {
    let surfaces = a5_surfaces_from_records(data, records, refusal)?;
    let points = object_stream_vertices_from_records(data, records);
    let standalone = (b2_cylinders_from_records(data, records)).collect::<Vec<_>>();
    let circles = (b2_circles_from_records(data, records)).collect::<Vec<_>>();
    let cones = (b2_cones_from_records(data, records)).collect::<Vec<_>>();
    let spheres = (b2_spheres_from_records(data, records)).collect::<Vec<_>>();
    let tori = (b2_tori_from_records(data, records)).collect::<Vec<_>>();
    let planes = b2_plane_carriers_from_records(data, records);
    let carriers = ConsolidatedCarriers {
        cylinders: &standalone,
        circles: &circles,
        cones: &cones,
        spheres: &spheres,
        tori: &tori,
        planes: &planes,
        nurbs_surfaces: &surfaces,
    };
    let mut resolved = Vec::new();
    for block in consolidated_edge_blocks_from_records(data, records)
        .into_iter()
        .filter(include)
    {
        let mut supports = [None, None];
        for side in [0, 1] {
            supports[side] = resolve_side_support(ctx, &block.pcurves[side], &points, &carriers)?;
        }
        for anchor_side in [0, 1] {
            let partner = 1 - anchor_side;
            if supports[partner].is_some() {
                continue;
            }
            let Some(binding) = supports[anchor_side].as_ref() else {
                continue;
            };
            let Some(anchor_points) =
                support_points(ctx, binding, &block.pcurves[anchor_side], &carriers)?
            else {
                continue;
            };
            let partner_points = block.pcurves[partner]
                .sites
                .iter()
                .map(|site| site.point.get())
                .collect::<Vec<_>>();
            let mut winners = Vec::new();
            for surface in &surfaces {
                if let Some(offset) = nurbs_carrier_offset_surface(
                    ctx,
                    &surface.geometry,
                    &partner_points,
                    &anchor_points,
                )? {
                    winners.push(ConsolidatedSupportBinding::NurbsCarrier {
                        pos: surface.pos,
                        offset,
                    });
                }
            }
            if let [winner] = winners.as_slice() {
                supports[partner] = Some(*winner);
            }
        }
        if supports.iter().all(Option::is_none) {
            if let Some(winner) = unique_agreeing_nurbs_pair(ctx, &block, &surfaces, &carriers)? {
                supports = winner.map(Some);
            }
        }
        let shared_loci = resolved_support_loci(ctx, &block, &supports, &carriers)?;
        let endpoint_loci = shared_loci
            .as_ref()
            .and_then(|points| Some([*points.first()?, *points.last()?]));
        resolved.push(ResolvedConsolidatedEdgeBlock {
            block,
            supports,
            shared_loci,
            endpoint_loci,
        });
    }
    Ok(resolved)
}

fn resolve_side_support(
    ctx: &DecodeContext<'_>,
    pcurve: &ConsolidatedPcurve,
    points: &[FinitePoint3],
    carriers: &ConsolidatedCarriers<'_>,
) -> Result<Option<ConsolidatedSupportBinding>, CodecError> {
    let circles = carriers
        .circles
        .iter()
        .filter(|circle| circle.record_id == pcurve.support_id);
    let identified_cylinders = carriers.cylinders.iter().filter(|value| {
        value
            .header
            .compact_operand()
            .is_some_and(|operand| operand.value() == pcurve.support_id)
    });
    let identity_count = circles.clone().count() + identified_cylinders.clone().count();
    if identity_count > 1 {
        return Ok(None);
    }
    if let Some(circle) = circles.clone().next() {
        return Ok(pcurve_matches_circle(pcurve, circle)
            .then_some(ConsolidatedSupportBinding::Circle { pos: circle.pos }));
    }
    if let Some(value) = identified_cylinders.clone().next() {
        return Ok(
            pcurve_endpoints_match(pcurve, points, |uv| Ok(b2_cylinder_point(value, uv)))?
                .then_some(ConsolidatedSupportBinding::Cylinder { pos: value.pos }),
        );
    }
    let mut winners = Vec::new();
    for cylinder in carriers.cylinders {
        if pcurve_endpoints_match(pcurve, points, |uv| Ok(b2_cylinder_point(cylinder, uv)))? {
            winners.push(ConsolidatedSupportBinding::Cylinder { pos: cylinder.pos });
        }
    }
    for circle in carriers.circles {
        if pcurve_matches_circle(pcurve, circle) {
            winners.push(ConsolidatedSupportBinding::Circle { pos: circle.pos });
        }
    }
    for cone in carriers.cones {
        if pcurve_endpoints_match(pcurve, points, |uv| Ok(b2_cone_point(cone, uv)))? {
            winners.push(ConsolidatedSupportBinding::Cone { pos: cone.pos });
        }
    }
    for sphere in carriers.spheres {
        let geometry = b2_sphere_geometry(sphere);
        if pcurve_endpoints_match(pcurve, points, |[u, v]| {
            match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
                ctx, &geometry, u, v,
            ))? {
                Ok(point) => Ok(Some(point.get())),
                Err(failure) => failure.non_finite(),
            }
        })? {
            winners.push(ConsolidatedSupportBinding::Sphere { pos: sphere.pos });
        }
    }
    for torus in carriers.tori {
        if pcurve_endpoints_match(pcurve, points, |uv| b2_torus_point(ctx, torus, uv))? {
            winners.push(ConsolidatedSupportBinding::Torus { pos: torus.pos });
        }
    }
    for plane in carriers.planes {
        if let Some(geometry) = b2_plane_geometry(plane) {
            if pcurve_endpoints_match(pcurve, points, |[u, v]| {
                match cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, &geometry, u, v),
                )? {
                    Ok(point) => Ok(Some(point.get())),
                    Err(failure) => failure.non_finite(),
                }
            })? {
                winners.push(ConsolidatedSupportBinding::Plane { pos: plane.pos });
            }
        }
    }
    Ok(match winners.as_slice() {
        [winner] => Some(*winner),
        _ => None,
    })
}

/// The one pair of NURBS carriers without offset, one for each side of
/// `block`, on which the two pcurves lift to points that agree.
///
/// Two lifts agree only if their first points agree. The complete lifts are
/// thus evaluated only for the pairs whose first points agree.
fn unique_agreeing_nurbs_pair(
    ctx: &DecodeContext<'_>,
    block: &ConsolidatedEdgeBlock,
    surfaces: &[FreeformSurface],
    carriers: &ConsolidatedCarriers<'_>,
) -> Result<Option<[ConsolidatedSupportBinding; 2]>, CodecError> {
    let [first_pcurve, second_pcurve] = &block.pcurves;
    if first_pcurve.sites.len() != second_pcurve.sites.len() {
        return Ok(None);
    }
    let bindings = surfaces
        .iter()
        .map(|surface| ConsolidatedSupportBinding::NurbsCarrier {
            pos: surface.pos,
            offset: FiniteReal::ZERO,
        })
        .collect::<Vec<_>>();
    let mut starts = [Vec::new(), Vec::new()];
    for (side, pcurve) in block.pcurves.iter().enumerate() {
        for binding in &bindings {
            let start = support_points_at(ctx, binding, &pcurve.sites[..1], carriers)?
                .and_then(|points| points.first().copied());
            starts[side].push(start);
        }
    }
    let mut lifts = [vec![None; bindings.len()], vec![None; bindings.len()]];
    let mut winner = None;
    for (first, first_start) in starts[0].iter().enumerate() {
        let Some(first_start) = first_start else {
            continue;
        };
        for (second, second_start) in starts[1].iter().enumerate() {
            let Some(second_start) = second_start else {
                continue;
            };
            if !distance_at_most(*first_start, *second_start, 2e-3) {
                continue;
            }
            for (side, index, pcurve) in [(0, first, first_pcurve), (1, second, second_pcurve)] {
                if lifts[side][index].is_none() {
                    lifts[side][index] =
                        Some(support_points(ctx, &bindings[index], pcurve, carriers)?);
                }
            }
            let (Some(Some(first_points)), Some(Some(second_points))) =
                (&lifts[0][first], &lifts[1][second])
            else {
                continue;
            };
            if !point_sequences_agree(first_points, second_points) {
                continue;
            }
            if winner.is_some() {
                return Ok(None);
            }
            winner = Some([bindings[first], bindings[second]]);
        }
    }
    Ok(winner)
}

fn point_sequences_agree(first: &[Point3], second: &[Point3]) -> bool {
    !first.is_empty()
        && first.len() == second.len()
        && first
            .iter()
            .zip(second)
            .all(|(&left, &right)| distance_at_most(left, right, 2e-3))
}

fn resolved_support_loci(
    ctx: &DecodeContext<'_>,
    block: &ConsolidatedEdgeBlock,
    supports: &[Option<ConsolidatedSupportBinding>; 2],
    carriers: &ConsolidatedCarriers<'_>,
) -> Result<Option<Vec<Point3>>, CodecError> {
    let mut first = None::<Vec<Point3>>;
    for (binding, pcurve) in supports.iter().zip(&block.pcurves) {
        let Some(binding) = binding.as_ref() else {
            continue;
        };
        let Some(points) = support_points(ctx, binding, pcurve, carriers)? else {
            continue;
        };
        if points.is_empty() {
            continue;
        }
        if let Some(previous) = first.as_ref() {
            if !point_sequences_agree(previous, &points) {
                return Ok(None);
            }
        } else {
            first = Some(points);
        }
    }
    Ok(first)
}

fn support_points(
    ctx: &DecodeContext<'_>,
    binding: &ConsolidatedSupportBinding,
    pcurve: &ConsolidatedPcurve,
    carriers: &ConsolidatedCarriers<'_>,
) -> Result<Option<Vec<Point3>>, CodecError> {
    let points = match binding {
        ConsolidatedSupportBinding::Cylinder { pos } => {
            let Some(carrier) = carriers.cylinders.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            (pcurve
                .sites
                .iter()
                .map(|site| b2_cylinder_point(carrier, site.point.get())))
            .collect::<Option<Vec<_>>>()
        }
        ConsolidatedSupportBinding::Cone { pos } => {
            let Some(carrier) = carriers.cones.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            (pcurve
                .sites
                .iter()
                .map(|site| b2_cone_point(carrier, site.point.get())))
            .collect::<Option<Vec<_>>>()
        }
        ConsolidatedSupportBinding::Sphere { pos } => {
            let Some(carrier) = carriers.spheres.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            (pcurve.sites.iter().map(|site| {
                let [u, v] = site.point.get();
                match cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(
                        ctx,
                        &b2_sphere_geometry(carrier),
                        u,
                        v,
                    ),
                )? {
                    Ok(point) => Ok(Some(point.get())),
                    Err(failure) => failure.non_finite(),
                }
            }))
            .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Torus { pos } => {
            let Some(carrier) = carriers.tori.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            (pcurve
                .sites
                .iter()
                .map(|site| b2_torus_point(ctx, carrier, site.point.get())))
            .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Plane { pos } => {
            let Some(carrier) = carriers.planes.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            let Some(geometry) = b2_plane_geometry(carrier) else {
                return Ok(None);
            };
            (pcurve.sites.iter().map(|site| {
                let [u, v] = site.point.get();
                match cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, &geometry, u, v),
                )? {
                    Ok(point) => Ok(Some(point.get())),
                    Err(failure) => failure.non_finite(),
                }
            }))
            .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::NurbsCarrier { pos, offset } => {
            let Some(surface) = carriers
                .nurbs_surfaces
                .iter()
                .find(|surface| surface.pos == *pos)
                .map(|surface| &surface.geometry)
            else {
                return Ok(None);
            };
            (pcurve.sites.iter().map(|site| {
                let [u, v] = site.point.get();
                let partials = match nurbs_surface_partials(ctx, surface, u, v) {
                    Ok(partials) => partials,
                    Err(failure) => return failure.non_finite(),
                };
                let Some(normal) = partials.du.cross(partials.dv.get()).unit() else {
                    return Ok(None);
                };
                Ok(Some(Point3::new(
                    partials.point.x + offset.get() * normal.x,
                    partials.point.y + offset.get() * normal.y,
                    partials.point.z + offset.get() * normal.z,
                )))
            }))
            .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Circle { .. } => None,
    };
    Ok(points)
}

/// The points of `binding` at `sites`, in site order.
fn support_points_at(
    ctx: &DecodeContext<'_>,
    binding: &ConsolidatedSupportBinding,
    sites: &[ConsolidatedPcurveSite],
    carriers: &ConsolidatedCarriers<'_>,
) -> Result<Option<Vec<Point3>>, CodecError> {
    let points = match binding {
        ConsolidatedSupportBinding::Cylinder { pos } => {
            let Some(carrier) = carriers.cylinders.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| b2_cylinder_point(carrier, site.point.get()))
                .collect::<Option<Vec<_>>>()
        }
        ConsolidatedSupportBinding::Cone { pos } => {
            let Some(carrier) = carriers.cones.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| b2_cone_point(carrier, site.point.get()))
                .collect::<Option<Vec<_>>>()
        }
        ConsolidatedSupportBinding::Sphere { pos } => {
            let Some(carrier) = carriers.spheres.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| {
                    let [u, v] = site.point.get();
                    match cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(
                            ctx,
                            &b2_sphere_geometry(carrier),
                            u,
                            v,
                        ),
                    )? {
                        Ok(point) => Ok(Some(point.get())),
                        Err(failure) => failure.non_finite(),
                    }
                })
                .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Torus { pos } => {
            let Some(carrier) = carriers.tori.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| b2_torus_point(ctx, carrier, site.point.get()))
                .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Plane { pos } => {
            let Some(carrier) = carriers.planes.iter().find(|value| value.pos == *pos) else {
                return Ok(None);
            };
            let Some(geometry) = b2_plane_geometry(carrier) else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| {
                    let [u, v] = site.point.get();
                    match cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(ctx, &geometry, u, v),
                    )? {
                        Ok(point) => Ok(Some(point.get())),
                        Err(failure) => failure.non_finite(),
                    }
                })
                .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::NurbsCarrier { pos, offset } => {
            let Some(surface) = carriers
                .nurbs_surfaces
                .iter()
                .find(|surface| surface.pos == *pos)
                .map(|surface| &surface.geometry)
            else {
                return Ok(None);
            };
            sites
                .iter()
                .map(|site| {
                    let [u, v] = site.point.get();
                    let partials = match nurbs_surface_partials(ctx, surface, u, v) {
                        Ok(partials) => partials,
                        Err(failure) => return failure.non_finite(),
                    };
                    let Some(normal) = partials.du.cross(partials.dv.get()).unit() else {
                        return Ok(None);
                    };
                    Ok(Some(Point3::new(
                        partials.point.x + offset.get() * normal.x,
                        partials.point.y + offset.get() * normal.y,
                        partials.point.z + offset.get() * normal.z,
                    )))
                })
                .collect::<Result<Option<Vec<_>>, _>>()?
        }
        ConsolidatedSupportBinding::Circle { .. } => None,
    };
    Ok(points)
}

/// The torus point at stored site `[u, v]`. A non-finite point is returned
/// as the evaluation reached it; the loci comparisons read it as a
/// disagreement.
fn b2_torus_point(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    torus: &B2Torus,
    [u, v]: [f64; 2],
) -> Result<Option<Point3>, cadmpeg_core::decode::ResourceLimit> {
    match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
        ctx,
        &b2_torus_geometry(torus),
        u / torus.major_scale.get(),
        v / torus.minor_scale.get(),
    ))? {
        Ok(point) => Ok(Some(point.get())),
        Err(failure) => failure.non_finite(),
    }
}

#[cfg(test)]
fn nurbs_carrier_offset(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    geometry: &SurfaceGeometry,
    parameters: &[[f64; 2]],
    anchors: &[Point3],
) -> Result<Option<FiniteReal>, cadmpeg_core::decode::ResourceLimit> {
    let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface)) = geometry else {
        return Ok(None);
    };
    nurbs_carrier_offset_surface(ctx, surface, parameters, anchors)
}

fn nurbs_carrier_offset_surface(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &cadmpeg_ir::geometry::nurbs::NurbsSurface,
    parameters: &[[f64; 2]],
    anchors: &[Point3],
) -> Result<Option<FiniteReal>, cadmpeg_core::decode::ResourceLimit> {
    if parameters.len() != anchors.len() || parameters.is_empty() {
        return Ok(None);
    }
    let mut first = None::<FiniteReal>;
    for (&[u, v], &anchor) in parameters.iter().zip(anchors) {
        let partials = match nurbs_surface_partials(ctx, surface, u, v) {
            Ok(partials) => partials,
            Err(cadmpeg_ir::eval::EvaluationFailure::ResourceLimit(limit)) => return Err(limit),
            Err(_) => return Ok(None),
        };
        let point = partials.point;
        let residual = Vector3::new(anchor.x - point.x, anchor.y - point.y, anchor.z - point.z);
        if residual == Vector3::new(0.0, 0.0, 0.0) {
            if first
                .is_some_and(|value| value.get().abs() > EPS_SAMPLE_AGREEMENT * value.get().abs())
            {
                return Ok(None);
            }
            first.get_or_insert(FiniteReal::ZERO);
            continue;
        }
        let residual_length = residual.x.hypot(residual.y).hypot(residual.z);
        let Some(normal) = partials.du.cross(partials.dv.get()).unit() else {
            return Ok(None);
        };
        let distance = residual.x * normal.x + residual.y * normal.y + residual.z * normal.z;
        let transverse = Vector3::new(
            residual.x - normal.x * distance,
            residual.y - normal.y * distance,
            residual.z - normal.z * distance,
        );
        let transverse_length = transverse.x.hypot(transverse.y).hypot(transverse.z);
        let Some(distance) = FiniteReal::new(distance) else {
            return Ok(None);
        };
        if !residual_length.is_finite()
            || !transverse_length.is_finite()
            || transverse_length > EPS_TRANSVERSE_RESIDUAL * residual_length
        {
            return Ok(None);
        }
        if let Some(value) = first {
            if (distance.get() - value.get()).abs()
                > EPS_SAMPLE_AGREEMENT * distance.get().abs().max(value.get().abs())
            {
                return Ok(None);
            }
        } else {
            first = Some(distance);
        }
    }
    Ok(first)
}

fn pcurve_matches_circle(pcurve: &ConsolidatedPcurve, circle: &B2Circle) -> bool {
    let (Some(first), Some(last)) = (
        pcurve.sites.first().map(|site| site.point.get()),
        pcurve.sites.last().map(|site| site.point.get()),
    ) else {
        return false;
    };
    let span = circle.range.upper() - circle.range.lower();
    span.is_finite()
        && (first[1] - last[1]).abs() <= EPS_ENDPOINT_RANGE * span
        && (first[0].min(last[0]) - circle.range.lower()).abs() <= EPS_CIRCLE_ENDPOINT * span
        && (first[0].max(last[0]) - circle.range.upper()).abs() <= EPS_CIRCLE_ENDPOINT * span
}

fn pcurve_endpoints_match(
    pcurve: &ConsolidatedPcurve,
    vertices: &[FinitePoint3],
    evaluate: impl Fn([f64; 2]) -> Result<Option<Point3>, cadmpeg_core::decode::ResourceLimit>,
) -> Result<bool, cadmpeg_core::decode::ResourceLimit> {
    let (Some(first), Some(last)) = (
        pcurve.sites.first().map(|site| site.point.get()),
        pcurve.sites.last().map(|site| site.point.get()),
    ) else {
        return Ok(false);
    };
    for uv in [first, last] {
        let matches = evaluate(uv)?.is_some_and(|point| {
            vertices
                .iter()
                .any(|vertex| distance_below(point, vertex.get(), 2e-3))
        });
        if !matches {
            return Ok(false);
        }
    }
    Ok(true)
}

/// Read `05 08 01` coordinate rows outside every length-closed consolidated
/// A/B or B5/A8 record. Marker-like bytes inside record payloads are not
/// vertices.
pub(in crate::families) fn object_stream_vertices(
    data: &[u8],
) -> Result<Vec<FinitePoint3>, CodecError> {
    let records = crate::wire::records::consolidated_records_in_sources(
        data,
        std::iter::once(std::iter::once(crate::wire::records::SourceExtent::whole(
            data,
        ))),
    )?;
    Ok(object_stream_vertices_from_records(data, &records))
}

fn object_stream_vertices_from_records(
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
) -> Vec<FinitePoint3> {
    let mut points = Vec::new();
    for range in object_stream_vertex_row_ranges_from_records(data, records) {
        for point in crate::wire::records::scan_vertex_records(&data[range]) {
            points.push(point);
        }
    }
    points
}

fn object_stream_vertex_row_ranges_from_records(
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
) -> Vec<Range<usize>> {
    let mut ranges = records
        .iter()
        .filter_map(crate::wire::records::ConsolidatedRecord::range)
        .chain(crate::families::b5::graph::framed_ranges(data))
        .collect::<Vec<_>>();
    if ranges.is_empty() {
        return Vec::new();
    }
    ranges.sort_unstable_by_key(|left| (left.start, left.end));
    let mut rows = Vec::new();
    let mut region_start = 0usize;
    for range in ranges {
        if range.end <= region_start {
            continue;
        }
        if range.start > region_start {
            for row in scan_vertex_record_ranges(&data[region_start..range.start]) {
                rows.push(row.start + region_start..row.end + region_start);
            }
        }
        region_start = region_start.max(range.end);
    }
    for row in scan_vertex_record_ranges(&data[region_start..]) {
        rows.push(row.start + region_start..row.end + region_start);
    }
    rows
}

#[cfg(test)]
mod tests {
    use cadmpeg_ir::geometry::{nurbs::NurbsSurface, SolvedSurfaceGeometry, SurfaceGeometry};
    use cadmpeg_ir::math::Point3;

    use crate::families::b2::records::B2Circle;
    use crate::wire::records::ConsolidatedPcurve;

    use super::{nurbs_carrier_offset, pcurve_matches_circle};

    #[test]
    fn nurbs_carrier_offset_preserves_tiny_nonzero_distance() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
            NurbsSurface::from_lanes(
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    false,
                ),
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    false,
                ),
                cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(
                    vec![
                        vec![Point3::new(0.0, 0.0, 0.0), Point3::new(0.0, 1.0, 0.0)],
                        vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 1.0, 0.0)],
                    ],
                    None,
                ),
                false,
            )
            .expect("valid unit-square surface"),
        ));
        let tiny = 1e-200;
        let offset = nurbs_carrier_offset(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &surface,
            &[[0.25, 0.25], [0.75, 0.75]],
            &[Point3::new(0.25, 0.25, tiny), Point3::new(0.75, 0.75, tiny)],
        )
        .expect("evaluator allocation succeeds")
        .expect("constant normal offset");
        assert_eq!(offset.get(), tiny);

        assert_eq!(
            nurbs_carrier_offset(
                &cadmpeg_core::decode::test_support::service_decode_context(),
                &surface,
                &[[0.25, 0.25], [0.75, 0.75]],
                &[
                    Point3::new(0.25, 0.25, tiny),
                    Point3::new(0.75, 0.75, 2.0 * tiny),
                ],
            )
            .expect("evaluator allocation succeeds"),
            None
        );
        assert_eq!(
            nurbs_carrier_offset(
                &cadmpeg_core::decode::test_support::service_decode_context(),
                &surface,
                &[[0.0, 0.0]],
                &[Point3::new(tiny, 0.0, tiny)],
            )
            .expect("evaluator allocation succeeds"),
            None
        );
        for invalid in [f64::NAN, f64::INFINITY] {
            assert_eq!(
                nurbs_carrier_offset(
                    &cadmpeg_core::decode::test_support::service_decode_context(),
                    &surface,
                    &[[0.25, 0.25], [0.75, 0.75]],
                    &[
                        Point3::new(0.25, 0.25, tiny),
                        Point3::new(0.75, 0.75, invalid),
                    ],
                )
                .expect("evaluator allocation succeeds"),
                None
            );
        }
    }

    #[test]
    fn circle_binding_is_relative_to_the_arc_length_span() {
        let span = 1e-200_f64;
        let circle = B2Circle {
            pos: 0,
            layout: crate::native::CatiaCircleLayout::PackedSix,
            record_id: 1,
            frame_token: 0,
            center_pair: crate::test_support::test_b5::finite_vector([0.0; 2]),
            radius: cadmpeg_ir::scalar::PositiveLength::new(span).expect("positive span"),
            range: cadmpeg_ir::topology::IncreasingParameterInterval::new([0.0, span])
                .expect("increasing span"),
            chart_shift: cadmpeg_ir::scalar::FiniteReal::ZERO,
        };
        let pcurve = |points: Vec<[f64; 2]>| ConsolidatedPcurve {
            pos: 0,
            support_id: 1,
            extrapolation_sites: 0,
            sites: points
                .into_iter()
                .enumerate()
                .map(
                    |(index, point)| crate::wire::records::ConsolidatedPcurveSite {
                        knot: crate::test_support::test_b5::finite(if index == 0 {
                            0.0
                        } else {
                            span
                        }),
                        point: crate::test_support::test_b5::finite_vector(point),
                        first_derivatives: crate::test_support::test_b5::finite_vector([0.0, 0.0]),
                        second_derivatives: crate::test_support::test_b5::finite_vector([0.0, 0.0]),
                    },
                )
                .collect::<Vec<_>>()
                .try_into()
                .expect("ordered fixture sites"),
            range: crate::test_support::test_b5::increasing([0.0, span]),
            tail: Vec::new(),
        };

        assert!(pcurve_matches_circle(
            &pcurve(vec![[0.0, span], [span, span]]),
            &circle
        ));
        assert!(!pcurve_matches_circle(
            &pcurve(vec![[0.0, span], [span, 2.0 * span]]),
            &circle
        ));
        assert!(!pcurve_matches_circle(
            &pcurve(vec![[0.0, span], [2.0 * span, span]]),
            &circle
        ));
    }
    #[test]
    fn support_loci_with_an_overflowing_site_do_not_agree() {
        // The plane's origin is the largest finite x coordinate: the site
        // u = MAX lifts to a point without a finite x, and u = -MAX lifts to
        // the model origin.
        let plane = crate::families::b2::records::B2PlaneCarrier {
            pos: 7,
            end: 0,
            width: crate::wire::records::ConsolidatedFrameWidth::One,
            flag: crate::wire::records::ConsolidatedFrameFlag::Flag03,
            header_token: 0,
            payload: crate::families::b2::records::B2PlaneCarrierPayload::Plane {
                layout: crate::families::b2::records::B2PlaneCarrierLayout::ImplicitX,
                point: cadmpeg_ir::units::FiniteVector::new([f64::MAX, 0.0])
                    .expect("finite origin"),
                direction: crate::checked::ExactHypotUnitVector3::new([1.0, 0.0, 0.0])
                    .expect("unit direction"),
                u_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
                v_range: crate::test_support::test_b5::increasing([-1.0, 1.0]),
                origin_z: None,
            },
        };
        let pcurve = |points: [[f64; 2]; 2]| ConsolidatedPcurve {
            pos: 0,
            support_id: 1,
            extrapolation_sites: 0,
            sites: points
                .into_iter()
                .enumerate()
                .map(
                    |(index, point)| crate::wire::records::ConsolidatedPcurveSite {
                        knot: crate::test_support::test_b5::finite(
                            cadmpeg_core::convert::f64_from_index(index)
                                .expect("fixture index is exactly representable"),
                        ),
                        point: crate::test_support::test_b5::finite_vector(point),
                        first_derivatives: crate::test_support::test_b5::finite_vector([0.0, 0.0]),
                        second_derivatives: crate::test_support::test_b5::finite_vector([0.0, 0.0]),
                    },
                )
                .collect::<Vec<_>>()
                .try_into()
                .expect("ordered fixture sites"),
            range: crate::test_support::test_b5::increasing([0.0, 1.0]),
            tail: Vec::new(),
        };
        let block = super::ConsolidatedEdgeBlock {
            pcurves: [
                pcurve([[f64::MAX, 0.0], [-f64::MAX, 0.0]]),
                pcurve([[-f64::MAX, 0.0], [-f64::MAX, 0.0]]),
            ],
            parameters: crate::families::b2::records::B2EdgeParameters {
                pos: 0,
                range: crate::test_support::test_b5::increasing([0.0, 1.0]),
                tolerance: cadmpeg_ir::scalar::FiniteReal::ZERO,
            },
        };
        let planes = [plane];
        let carriers = super::ConsolidatedCarriers {
            cylinders: &[],
            circles: &[],
            cones: &[],
            spheres: &[],
            tori: &[],
            planes: &planes,
            nurbs_surfaces: &[],
        };
        let binding = || Some(super::ConsolidatedSupportBinding::Plane { pos: 7 });
        assert_eq!(
            crate::test_support::with_service_context(|ctx| super::resolved_support_loci(
                ctx,
                &block,
                &[None, binding()],
                &carriers
            ))
            .expect("resolve the support loci"),
            Some(vec![Point3::new(0.0, 0.0, 0.0); 2])
        );
        assert_eq!(
            crate::test_support::with_service_context(|ctx| super::resolved_support_loci(
                ctx,
                &block,
                &[binding(), binding()],
                &carriers
            ))
            .expect("resolve the support loci"),
            None
        );
    }

    #[test]
    fn pcurve_on_its_cylinder_resolves_and_lifts_to_the_same_points() {
        let pcurve_bytes = crate::test_support::test_a5a8::a5_pcurve_stream();
        let pcurve_records = crate::wire::records::consolidated_records(&pcurve_bytes);
        let pcurves = crate::wire::records::family_pcurves_from_records(
            &pcurve_bytes,
            &pcurve_records,
            crate::wire::records::ConsolidatedFamily::A,
        );
        let pcurve = &pcurves[0];
        let cylinder_bytes = crate::test_support::test_b2::b2_cylinder_stream();
        let cylinder_records = crate::wire::records::consolidated_records(&cylinder_bytes);
        let cylinders: Vec<_> = crate::families::b2::records::b2_cylinders_from_records(
            &cylinder_bytes,
            &cylinder_records,
        )
        .collect();
        let carriers = super::ConsolidatedCarriers {
            cylinders: &cylinders,

            circles: &[],
            cones: &[],
            spheres: &[],
            tori: &[],
            planes: &[],
            nurbs_surfaces: &[],
        };
        let cylinder = &cylinders[0];
        let points: Vec<_> = pcurve
            .sites
            .iter()
            .map(|site| {
                let point = super::b2_cylinder_point(cylinder, site.point.get())
                    .expect("finite cylinder site");
                cadmpeg_ir::features::FinitePoint3::new(point).expect("finite point")
            })
            .collect();
        let binding = crate::test_support::with_service_context(|ctx| {
            super::resolve_side_support(ctx, pcurve, &points, &carriers)
        })
        .expect("resolve the side support")
        .expect("unique cylinder");
        let lifted = crate::test_support::with_service_context(|ctx| {
            super::support_points(ctx, &binding, pcurve, &carriers)
        })
        .expect("evaluate the support points")
        .expect("lifted cylinder sites");
        assert_eq!(
            lifted,
            points.iter().map(|point| point.get()).collect::<Vec<_>>()
        );
    }

    /// The pair search that lifts both pcurves in full on every carrier.
    fn exhaustive_nurbs_pair(
        ctx: &cadmpeg_core::decode::DecodeContext<'_>,
        block: &super::ConsolidatedEdgeBlock,
        carriers: &super::ConsolidatedCarriers<'_>,
    ) -> Option<[super::ConsolidatedSupportBinding; 2]> {
        let mut candidates = [Vec::new(), Vec::new()];
        for side in [0, 1] {
            for surface in carriers.nurbs_surfaces {
                let binding = super::ConsolidatedSupportBinding::NurbsCarrier {
                    pos: surface.pos,
                    offset: cadmpeg_ir::scalar::FiniteReal::ZERO,
                };
                if let Some(points) =
                    super::support_points(ctx, &binding, &block.pcurves[side], carriers)
                        .expect("lift within the test budget")
                {
                    candidates[side].push((binding, points));
                }
            }
        }
        let mut winner = None;
        for (first_binding, first_points) in &candidates[0] {
            for (second_binding, second_points) in &candidates[1] {
                if !super::point_sequences_agree(first_points, second_points) {
                    continue;
                }
                if winner.is_some() {
                    return None;
                }
                winner = Some([*first_binding, *second_binding]);
            }
        }
        winner
    }

    #[test]
    fn nurbs_pair_search_matches_the_exhaustive_search() {
        let offset =
            |point: [f64; 3], by: [f64; 3]| [point[0] + by[0], point[1] + by[1], point[2] + by[2]];
        let (p0, p1) = ([1.0, 2.0, 3.0], [4.0, 5.0, 6.0]);
        let along_u = [
            p0,
            offset(p0, [0.0, 0.0, 1.0]),
            p1,
            offset(p1, [0.0, 0.0, 1.0]),
        ];
        let along_v = [
            p0,
            p1,
            offset(p0, [0.0, 1.0, 0.0]),
            offset(p1, [0.0, 1.0, 0.0]),
        ];
        let same_start = [
            p0,
            offset(p1, [0.0, 0.0, 0.5]),
            offset(p1, [0.0, 0.5, 0.0]),
            offset(p1, [0.5, 0.0, 0.0]),
        ];
        let far = along_u.map(|point| offset(point, [100.0, 0.0, 0.0]));
        let cases: [(&[[[f64; 3]; 4]], bool); 6] = [
            (&[along_u, along_v], true),
            (&[along_u, along_v, along_u], false),
            (&[far, along_u, same_start, along_v, far], true),
            (&[same_start, along_u], false),
            (&[far], false),
            (&[], false),
        ];
        for (surfaces, unique) in cases {
            let bytes =
                crate::test_support::test_a5_bound::a5_nurbs_edge_stream_with_surfaces(surfaces);
            let records = crate::wire::records::consolidated_records(&bytes);
            let carriers_found = crate::families::a5a8::records::a5_surfaces_from_records(
                &bytes,
                &records,
                &mut crate::nurbs::LaneRefusals::new(),
            )
            .expect("decode the test surfaces");
            assert_eq!(carriers_found.len(), surfaces.len());
            let carriers = super::ConsolidatedCarriers {
                cylinders: &[],

                circles: &[],
                cones: &[],
                spheres: &[],
                tori: &[],
                planes: &[],
                nurbs_surfaces: &carriers_found,
            };
            let blocks = super::consolidated_edge_blocks_from_records(&bytes, &records);
            assert_eq!(blocks.len(), 1);
            let (found, expected) = crate::test_support::with_service_context(|ctx| {
                (
                    super::unique_agreeing_nurbs_pair(ctx, &blocks[0], &carriers_found, &carriers)
                        .expect("search within the test budget"),
                    exhaustive_nurbs_pair(ctx, &blocks[0], &carriers),
                )
            });
            assert_eq!(found, expected, "{surfaces:?}");
            assert_eq!(found.is_some(), unique, "{surfaces:?}");
        }
    }
}

#[cfg(test)]
mod decoder_tests;

#[cfg(test)]
mod parameter_maps;

pub(crate) mod class24;
pub(crate) mod class25;
pub(crate) mod parameter_relation;
