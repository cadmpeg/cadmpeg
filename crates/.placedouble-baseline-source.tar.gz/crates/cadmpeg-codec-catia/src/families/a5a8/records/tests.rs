// SPDX-License-Identifier: Apache-2.0
//! Record-decoder tests for the `a5a8` family over synthetic byte fixtures.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_test_support::EditableDecodeResult;

use std::io::Cursor;

use cadmpeg_ir::codec::DecodeOptions;
use cadmpeg_ir::geometry::{
    CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, SurfaceGeometry,
};
use cadmpeg_ir::math::Point3;
use cadmpeg_ir::units::FiniteVector;

use crate::test_support::test_a5a8::{
    a5_freeform_curve_stream, a5_freeform_curve_stream_with_count, a5_guide_curve_stream,
    a5_guide_curve_stream_with_count, a5_pcurve_stream, a5_pcurve_stream_with_count,
    a5_rational_surface_stream, a5_surface_extrapolated_short_tail, a5_surface_extrapolated_tail,
    a5_surface_short_tail, a5_surface_stream, a5_surface_stream_with_tail, a5_surface_tail,
    a6_freeform_curve_stream, a6_pcurve_stream, a6_surface_stream, a8_catpart,
    a8_freeform_curve_stream, a8_freeform_curve_stream_with_count, a8_inline_tail_surface_stream,
    a8_pcurve_stream, a8_pcurve_stream_with_count, a8_rational_surface_stream, a8_surface_stream,
    a8_surface_stream_with_pcurve, a8_surface_stream_with_u_count, a8_surface_tail,
    inner_no_directory_a8_catpart,
};
use crate::test_support::test_b5::a8_inline_surface_stream_with_native_vertex_chain;

mod spline_headers;

#[test]
fn surface_tail_scans_continuation_without_materializing_a_lane() {
    let mut short = a5_surface_short_tail();
    assert_eq!(
        super::parse_surface_tail(&short, 0, short.len(), false),
        Some(short.len())
    );
    short[71..79].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(
        super::parse_surface_tail(&short, 0, short.len(), false),
        None
    );
    let mut long = a5_surface_tail();
    long[71..79].copy_from_slice(&1.0f64.to_le_bytes());
    assert_eq!(
        super::parse_surface_tail(&long, 0, long.len(), false),
        Some(long.len())
    );
    long[71..79].copy_from_slice(&f64::NAN.to_le_bytes());
    assert_eq!(super::parse_surface_tail(&long, 0, long.len(), false), None);
}

#[test]
fn owned_surface_tail_retains_descending_v_limits() {
    use crate::layout::surface_terminal_span_tail as layout;

    let mut tail = a5_surface_tail();
    tail.truncate(layout::SUFFIX);
    tail.extend([0x01, 0, 0x09, 0x01, 0x05, 0x07, 0x07]);
    tail[layout::CONTROLS + 2] = 0x01;
    let v_start = layout::PARAMETERS + 16;
    tail[v_start..v_start + 8].copy_from_slice(&3.0_f64.to_le_bytes());
    tail[v_start + 8..v_start + 16].copy_from_slice(&1.0_f64.to_le_bytes());
    assert_eq!(super::parse_surface_tail(&tail, 0, tail.len(), false), None);
    assert_eq!(
        super::parse_surface_tail(&tail, 0, tail.len(), true),
        Some(tail.len())
    );
}
#[test]
fn owned_surface_tail_reads_compact_patch_identifiers() {
    for tail in [a5_surface_tail(), a5_surface_extrapolated_tail()] {
        for (u, v) in [(63u16, 63u16), (64, 5), (5, 256), (256, 64)] {
            let mut controls = vec![0x05];
            for (index, value) in [u, v].into_iter().enumerate() {
                if index == 1 {
                    controls.push(0x05);
                }
                match value {
                    0..=63 => controls.push(u8::try_from(value * 4 + 1).unwrap()),
                    64..=255 => controls.extend([0x04, u8::try_from(value).unwrap()]),
                    _ => {
                        controls.push(0x08);
                        controls.extend(value.to_le_bytes());
                    }
                }
            }
            let mut encoded = controls;
            encoded.extend_from_slice(&tail[4..]);
            assert_eq!(
                super::parse_surface_tail(&encoded, 0, encoded.len(), true),
                Some(encoded.len()),
                "patches {u}, {v}"
            );
            for truncated in [3, encoded.len() - 1] {
                assert_eq!(
                    super::parse_surface_tail(&encoded, 0, truncated, true),
                    None
                );
            }
        }
    }
}

use crate::test_support::test_bytes::le_f64;
use crate::test_support::test_container::object_main_catpart;
use crate::variant::Variant;
use crate::CatiaCodec;

#[test]
fn a8_surface_parser_reads_common_form_nurbs() {
    let surfaces = crate::families::a5a8::records::a8_surfaces(
        &a8_surface_stream(),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A8 surfaces");
    assert_eq!(surfaces.len(), 1);
    assert_eq!(surfaces[0].object_id(), Some(0xdeca_fbad));
    let surface = &surfaces[0].geometry;
    assert_eq!((surface.u_degree(), surface.v_degree()), (2, 2));
    assert_eq!((surface.u_count(), surface.v_count()), (3, 3));
    assert_eq!(surface.poles().into_iter().nth(8).unwrap().x, 8.0);
}

#[test]
fn selected_nested_a8_surface_frame_decodes_without_a_flat_rescan() {
    let inner = a8_surface_stream();
    let inner_object_id = u32::from_le_bytes(inner[7..11].try_into().unwrap());
    let mut bytes = vec![0xa8, 0x03, 0x62];
    bytes.extend_from_slice(&u32::try_from(inner.len()).unwrap().to_le_bytes());
    bytes.extend_from_slice(&0x1234_u32.to_le_bytes());
    let inner_start = bytes.len();
    bytes.extend_from_slice(&inner);
    let inner_end = bytes.len();

    assert!(crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("service decode")
    })
    .is_empty());
    let header = crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surface_header_from_object_frame(
            &bytes,
            inner_start,
            inner_end,
            inner_object_id,
        )
        .expect("service decode")
    });
    assert_eq!(
        (
            crate::test_support::with_service_context(|_ctx| header.u_count())
                .expect("pole count admission"),
            crate::test_support::with_service_context(|_ctx| header.v_count())
                .expect("pole count admission")
        ),
        (3, 3)
    );
    let surface = crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surface_from_object_frame(
            &bytes,
            inner_start,
            inner_end,
            inner_object_id,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("service decode")
    })
    .expect("selected nested surface");
    let surface = surface.geometry;
    assert_eq!(surface.poles().into_iter().nth(8).unwrap().x, 8.0);
    assert!(crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surface_from_object_frame(
            &bytes,
            inner_start,
            inner_end - 1,
            inner_object_id,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("service decode")
    })
    .is_none());
}

#[test]
fn a8_surface_parser_accepts_frame_bounded_knot_and_pole_counts() {
    let surfaces = crate::families::a5a8::records::a8_surfaces(
        &a8_surface_stream_with_u_count(20_001),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A8 surfaces");
    assert_eq!(surfaces.len(), 1);
    let surface = &surfaces[0].geometry;
    assert_eq!((surface.u_count(), surface.v_count()), (20_002, 3));
    assert_eq!(surface.poles().len(), 60_006);
}

#[test]
fn a8_surface_parser_rejects_unframed_trailing_bytes() {
    let mut bytes = a8_surface_stream();
    bytes.push(0);
    let payload_len = u32::try_from(bytes.len() - 11).unwrap();
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    assert!(crate::families::a5a8::records::a8_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
}

#[test]
fn a8_surface_parser_accepts_a_closed_nested_b5_run() {
    let a8 = a8_pcurve_stream();
    let payload = &a8[11..];
    let mut child = vec![0xb5, 0x03, 0x20, u8::try_from(payload.len()).unwrap()];
    child.extend_from_slice(&0x9abcu32.to_le_bytes());
    child.extend_from_slice(payload);

    let mut bytes = a8_surface_stream();
    bytes.extend_from_slice(&child);
    let payload_len = u32::try_from(bytes.len() - 11).unwrap();
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    assert_eq!(
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A8 surfaces")
            .len(),
        1
    );
}

#[test]
fn a8_surface_parser_accepts_a_valid_tail_after_inline_poles() {
    let bytes = a8_inline_tail_surface_stream();
    let [surface] =
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A8 surfaces")
            .try_into()
            .expect("one inline-tail surface");
    let surface = surface.geometry;
    assert_eq!(surface.poles().into_iter().nth(8).unwrap().x, 8.0);
}

#[test]
fn a8_logical_source_reconstruction_retains_physical_offsets() {
    use crate::wire::records::SourceExtent;

    let logical = a8_inline_tail_surface_stream();
    let split = 100;
    let mut bytes = logical[split..].to_vec();
    bytes.extend_from_slice(&logical[..split]);
    let header_start = logical.len() - split;
    let sources = [vec![
        SourceExtent::within(&bytes, header_start, bytes.len()).unwrap(),
        SourceExtent::within(&bytes, 0, header_start).unwrap(),
    ]];
    let decoded =
        super::a8_surfaces_in_sources(&bytes, &sources, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the reordered logical source");
    let [surface] = decoded.as_slice() else {
        panic!("one reconstructed surface")
    };
    assert_eq!(surface.pos, header_start);
    let expected = super::a8_surfaces(&logical, &mut crate::nurbs::LaneRefusals::new())
        .expect("decode the contiguous surface");
    assert_eq!(surface.geometry, expected[0].geometry);
    let independent_sources = [vec![sources[0][0].clone()], vec![sources[0][1].clone()]];
    assert!(super::a8_surfaces_in_sources(
        &bytes,
        &independent_sources,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the split sources independently")
    .is_empty());
}

#[test]
fn a8_surface_parser_accepts_a_valid_tail_after_inline_weights() {
    let mut bytes = a8_rational_surface_stream();
    bytes.extend_from_slice(&a8_surface_tail());
    let payload_len = u32::try_from(bytes.len() - 11).unwrap();
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    let [surface] =
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A8 surfaces")
            .try_into()
            .expect("one inline-weight-tail surface");
    let surface = surface.geometry;
    assert_eq!(
        surface.pole_grid().weights().map(|rows| rows.concat()),
        Some(vec![2.0; 9])
    );
}

#[test]
fn a8_surface_parser_accepts_inline_continuation_tail_variants() {
    let surface_with_tail = |tail: &[u8]| {
        let mut bytes = a8_surface_stream();
        bytes.extend_from_slice(tail);
        let payload_len = u32::try_from(bytes.len() - 11).unwrap();
        bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
        bytes
    };
    let mut finite_continuation = a8_surface_tail();
    for (index, value) in [2.0, -3.0, 5.0, 7.0, 11.0, 13.0, 17.0, 19.0]
        .into_iter()
        .enumerate()
    {
        let offset = 71 + index * 8;
        finite_continuation[offset..offset + 8].copy_from_slice(&le_f64(value));
    }
    let mut alternate_suffix = finite_continuation.clone();
    alternate_suffix[135..141].copy_from_slice(&[0x09, 0x00, 0x09, 0x00, 0x07, 0x07]);
    let mut extrapolated = alternate_suffix.clone();
    extrapolated.resize(142, 0);
    extrapolated[135..142].copy_from_slice(&[0x09, 0x00, 0x09, 0x01, 0x05, 0x07, 0x07]);
    let mut alternate_extrapolated = extrapolated.clone();
    alternate_extrapolated[68..71].copy_from_slice(&[0x05, 0x05, 0x01]);
    alternate_extrapolated[135] = 0x0d;

    for tail in [
        &finite_continuation,
        &alternate_suffix,
        &extrapolated,
        &alternate_extrapolated,
    ] {
        let bytes = surface_with_tail(tail);
        let [_surface] = crate::families::a5a8::records::a8_surfaces(
            &bytes,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the A8 surfaces")
        .try_into()
        .expect("one inline-tail surface");
        let [header] = crate::test_support::with_service_context(|_ctx| {
            crate::families::a5a8::records::a8_surface_headers(&bytes).collect::<Vec<_>>()
        })
        .try_into()
        .expect("one inline-tail header");
        assert_eq!(header.object_id, 0xdeca_fbad);
    }
}

#[test]
fn a8_surface_parser_rejects_a_malformed_tail_after_inline_poles() {
    let mut bytes = a8_inline_tail_surface_stream();
    let tail_start = bytes.len() - 141;
    bytes[tail_start + 68] = 0;
    assert!(crate::families::a5a8::records::a8_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
}

#[test]
fn a8_surface_parser_accepts_each_object_frame_flag() {
    for flag in [0x03, 0x13, 0x83] {
        let mut bytes = a8_surface_stream();
        bytes[1] = flag;
        assert_eq!(
            crate::families::a5a8::records::a8_surfaces(
                &bytes,
                &mut crate::nurbs::LaneRefusals::new()
            )
            .expect("decode the A8 surfaces")
            .len(),
            1,
            "flag {flag:#04x}"
        );
        assert_eq!(
            (crate::families::a5a8::records::a8_surface_headers(&bytes).collect::<Vec<_>>()).len(),
            1,
            "flag {flag:#04x}"
        );
    }

    let mut malformed = a8_surface_stream();
    malformed[1] = 0x23;
    assert!(crate::families::a5a8::records::a8_surfaces(
        &malformed,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
}

#[test]
fn a8_surface_header_rejects_nonfinite_and_repeated_distinct_knots() {
    for (start, value, label) in [
        (17, f64::INFINITY, "nonfinite U knot"),
        (25, 0.0, "repeated U knot"),
        (40, f64::INFINITY, "nonfinite V knot"),
        (48, 0.0, "repeated V knot"),
    ] {
        let mut bytes = a8_surface_stream();
        bytes[start..start + 8].copy_from_slice(&le_f64(value));
        assert!(
            crate::families::a5a8::records::a8_surfaces(
                &bytes,
                &mut crate::nurbs::LaneRefusals::new()
            )
            .expect("decode the A8 surfaces")
            .is_empty(),
            "{label} must not produce a resolved surface"
        );
        assert!(
            (crate::families::a5a8::records::a8_surface_headers(&bytes).collect::<Vec<_>>())
                .is_empty(),
            "{label} must not produce a surface header"
        );
    }
}

#[test]
fn a8_surface_header_survives_an_opaque_pole_representation() {
    let mut bytes = a8_surface_stream();
    bytes[59..67].copy_from_slice(&f64::NAN.to_le_bytes());
    assert!(crate::families::a5a8::records::a8_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
    let headers =
        { crate::families::a5a8::records::a8_surface_headers(&bytes).collect::<Vec<_>>() };
    assert_eq!(headers.len(), 1);
    assert_eq!(headers[0].object_id, 0xdeca_fbad);
    assert_eq!((headers[0].u_degree, headers[0].v_degree), (2, 2));
    assert_eq!(
        (
            headers[0]
                .u_count()
                .expect("fixture U lattice has a valid pole count"),
            headers[0]
                .v_count()
                .expect("fixture V lattice has a valid pole count")
        ),
        (3, 3)
    );
    assert_eq!(headers[0].u_knots.multiplicities(), [3, 3]);
    assert_eq!(headers[0].v_knots.multiplicities(), [3, 3]);
}

#[test]
fn a8_surface_header_retains_an_inline_parameter_tail() {
    let headers = crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surface_headers(&a8_inline_tail_surface_stream())
            .collect::<Vec<_>>()
    });
    let [_header] = headers.as_slice() else {
        panic!("one inline-tail header");
    };
}

#[test]
fn a8_inline_surface_accepts_all_peer_frame_flags() {
    for a8_flag in [0x03, 0x13, 0x83] {
        for child_flag in [0x03, 0x13, 0x83] {
            let mut bytes = a8_surface_stream_with_pcurve();
            bytes[1] = a8_flag;
            let pcurve = bytes
                .windows(3)
                .position(|value| value == [0xb5, 0x03, 0x21])
                .expect("peer pcurve");
            bytes[pcurve + 1] = child_flag;
            let successor = bytes
                .windows(3)
                .rposition(|value| value == [0xb5, 0x03, 0x5e])
                .expect("successor frame");
            bytes[successor + 1] = child_flag;

            assert_eq!(
                crate::test_support::with_service_context(|_ctx| {
                    crate::families::a5a8::records::a8_surfaces(
                        &bytes,
                        &mut crate::nurbs::LaneRefusals::new(),
                    )
                    .expect("service decode")
                })
                .len(),
                1,
                "a8 flag {a8_flag:#04x}, child flag {child_flag:#04x}"
            );
        }
    }
}

#[test]
fn a8_inline_surface_accepts_finite_large_poles() {
    let mut bytes = a8_surface_stream_with_pcurve();
    let pole_start = 59;
    bytes[pole_start..pole_start + 8].copy_from_slice(&le_f64(2e12));

    let [resolved] = crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("service decode")
    })
    .try_into()
    .expect("one resolved surface");
    let surface = resolved.geometry;
    assert_eq!(surface.poles().into_iter().next().unwrap().x, 2e12);

    bytes[pole_start..pole_start + 8].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::test_support::with_service_context(|_ctx| {
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("service decode")
    })
    .is_empty());
}

#[test]
fn a8_pcurve_parser_reads_degree5_uv_jet() {
    let pcurves = crate::families::a5a8::records::a8_pcurves(&a8_pcurve_stream());
    assert_eq!(pcurves.len(), 1);
    assert_eq!(
        (pcurves[0].object_id, pcurves[0].support_id),
        (0x5678, 0x1234)
    );
    assert_eq!(pcurves[0].points(), vec![[0.0, 0.0], [1.0, 1.0]]);
    assert_eq!(
        pcurves[0].range,
        crate::test_support::test_b5::finite_pair([0.0, 1.0])
    );
    assert_eq!(pcurves[0].mode, 0x01);
    let mut wrong_degree = a8_pcurve_stream();
    wrong_degree[15] = 17;
    assert!(crate::families::a5a8::records::a8_pcurves(&wrong_degree).is_empty());

    let mut repeated_knot = a8_pcurve_stream();
    repeated_knot[28..36].copy_from_slice(&le_f64(0.0));
    assert!(crate::families::a5a8::records::a8_pcurves(&repeated_knot).is_empty());

    let mut wrong_endpoint_multiplicity = a8_pcurve_stream();
    wrong_endpoint_multiplicity[36] = 21;
    assert!(crate::families::a5a8::records::a8_pcurves(&wrong_endpoint_multiplicity).is_empty());

    let mut trailing_byte = a8_pcurve_stream();
    trailing_byte.push(0);
    let payload_len = u32::try_from(trailing_byte.len() - 11).unwrap();
    trailing_byte[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert!(crate::families::a5a8::records::a8_pcurves(&trailing_byte).is_empty());
}

#[test]
fn a8_pcurve_jet_exposes_a_bspline() {
    let [jet] = crate::families::a5a8::records::a8_pcurves(&a8_pcurve_stream())
        .try_into()
        .expect("one A8 pcurve jet");
    assert!(jet.bspline().is_some());
}

#[test]
fn a8_pcurve_parser_accepts_frame_bounded_site_count() {
    let pcurves = crate::families::a5a8::records::a8_pcurves(&a8_pcurve_stream_with_count(8193));
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].knots().len(), 8193);
    assert_eq!(pcurves[0].points().len(), 8193);
}

#[test]
fn a8_pcurve_parser_accepts_finite_large_jet_values() {
    let mut bytes = a8_pcurve_stream();
    bytes[40..48].copy_from_slice(&le_f64(2e12));
    let [pcurve] = crate::families::a5a8::records::a8_pcurves(&bytes)
        .try_into()
        .expect("one pcurve");
    assert_eq!(pcurve.points()[0][0], 2e12);

    bytes[40..48].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a8_pcurves(&bytes).is_empty());
}

#[test]
fn a8_pcurve_parser_retains_mode_five_uv_jet() {
    let mut bytes = a8_pcurve_stream();
    bytes[39] = 0x05;
    let pcurves = crate::families::a5a8::records::a8_pcurves(&bytes);
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].mode, 0x05);
    assert_eq!(pcurves[0].points(), vec![[0.0, 0.0], [1.0, 1.0]]);
}

#[test]
fn b5_pcurve_parser_reads_degree5_uv_jet() {
    let a8 = a8_pcurve_stream();
    let payload = &a8[11..];
    let mut b5 = vec![0xb5, 0x03, 0x20, u8::try_from(payload.len()).unwrap()];
    b5.extend_from_slice(&0x5678u32.to_le_bytes());
    b5.extend_from_slice(payload);

    let pcurves = crate::families::a5a8::records::object_stream_pcurves(&b5);

    assert_eq!(pcurves.len(), 1);
    assert_eq!(
        (pcurves[0].object_id, pcurves[0].support_id),
        (0x5678, 0x1234)
    );
    assert_eq!(pcurves[0].points(), vec![[0.0, 0.0], [1.0, 1.0]]);
}

#[test]
fn object_stream_pcurve_parser_accepts_each_object_frame_flag() {
    let a8 = a8_pcurve_stream();
    let payload = &a8[11..];
    for flag in [0x03, 0x13, 0x83] {
        let mut stream = vec![
            0xa8,
            flag,
            0x20,
            u8::try_from(payload.len()).unwrap(),
            0,
            0,
            0,
        ];
        stream.extend_from_slice(&0x5678u32.to_le_bytes());
        stream.extend_from_slice(payload);
        let [pcurve] = crate::families::a5a8::records::object_stream_pcurves(&stream)
            .try_into()
            .expect("one pcurve");
        assert_eq!(pcurve.object_id, 0x5678);
    }

    let mut malformed = a8;
    malformed[1] = 0x23;
    assert!(crate::families::a5a8::records::object_stream_pcurves(&malformed).is_empty());
}

#[test]
fn object_stream_pcurve_parser_walks_nested_b5_records_inside_a8() {
    let a8 = a8_pcurve_stream();
    let payload = &a8[11..];
    let mut child = vec![0xb5, 0x03, 0x20, u8::try_from(payload.len()).unwrap()];
    child.extend_from_slice(&0x9abcu32.to_le_bytes());
    child.extend_from_slice(payload);

    let mut wrapper = a8_surface_stream();
    wrapper.extend_from_slice(&child);
    let payload_len = u32::try_from(wrapper.len() - 11).unwrap();
    wrapper[3..7].copy_from_slice(&payload_len.to_le_bytes());

    let [pcurve] = crate::families::a5a8::records::object_stream_pcurves(&wrapper)
        .try_into()
        .expect("one nested pcurve");
    assert_eq!(pcurve.object_id, 0x9abc);
}

#[test]
fn b5_pcurve_parser_accepts_split_24_bit_support_reference() {
    let a8 = a8_pcurve_stream();
    let mut payload = a8[11..].to_vec();
    payload.splice(1..4, [0x28, 0x34, 0x12]);
    let mut b5 = vec![0xb5, 0x03, 0x20, u8::try_from(payload.len()).unwrap()];
    b5.extend_from_slice(&0x5678u32.to_le_bytes());
    b5.extend_from_slice(&payload);

    let pcurves = crate::families::a5a8::records::object_stream_pcurves(&b5);

    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].support_id, 0x0012_0034);
}

#[test]
fn a5_pcurve_parser_reads_compact_support_and_uv_jet() {
    let pcurves = crate::families::a5a8::records::a5_pcurves(&a5_pcurve_stream());
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].support_id, 0x1234);
    assert_eq!(pcurves[0].extrapolation_sites, 2);
    assert_eq!(
        pcurves[0]
            .points()
            .into_iter()
            .map(FiniteVector::get)
            .collect::<Vec<_>>(),
        vec![[0.0, 0.0], [1.0, 1.0]]
    );
    assert_eq!(pcurves[0].range.endpoints(), [0.0, 1.0]);
    assert_eq!(pcurves[0].tail, [0x07]);

    let mut padded = a5_pcurve_stream();
    padded.push(0);
    let payload_len = u32::try_from(padded.len() - 8).unwrap();
    padded[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert_eq!(
        crate::families::a5a8::records::a5_pcurves(&padded)[0].tail,
        [0x07, 0]
    );

    let mut trailing = padded;
    trailing.push(1);
    let payload_len = u32::try_from(trailing.len() - 8).unwrap();
    trailing[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert!(crate::families::a5a8::records::a5_pcurves(&trailing).is_empty());
}

#[test]
fn consolidated_pcurve_parser_reads_width2_frame() {
    let pcurves = crate::families::a5a8::records::a5_pcurves(&a6_pcurve_stream());
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].support_id, 0x1234);
    assert_eq!(
        pcurves[0]
            .points()
            .into_iter()
            .map(FiniteVector::get)
            .collect::<Vec<_>>(),
        vec![[0.0, 0.0], [1.0, 1.0]]
    );
}

#[test]
fn a5_pcurve_parser_accepts_frame_bounded_site_count() {
    let pcurves = crate::families::a5a8::records::a5_pcurves(&a5_pcurve_stream_with_count(4097));
    assert_eq!(pcurves.len(), 1);
    assert_eq!(pcurves[0].knots().len(), 4097);
    assert_eq!(pcurves[0].points().len(), 4097);
}

#[test]
fn a8_surface_parser_reads_rational_weight_grid() {
    let surfaces = crate::families::a5a8::records::a8_surfaces(
        &a8_rational_surface_stream(),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A8 surfaces");
    assert_eq!(
        surfaces[0]
            .geometry
            .pole_grid()
            .weights()
            .map(|rows| rows.concat()),
        Some(vec![2.0; 9])
    );
}

#[test]
fn surface_parsers_require_finite_nonzero_weights() {
    let mut a5 = a5_rational_surface_stream();
    a5[146..154].copy_from_slice(&le_f64(2e12));
    let [surface] =
        crate::families::a5a8::records::a5_surfaces(&a5, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A5 surfaces")
            .try_into()
            .expect("one consolidated rational surface");
    let surface = surface.geometry;
    assert_eq!(
        surface
            .pole_weights()
            .expect("weights")
            .into_iter()
            .next()
            .unwrap()
            .get(),
        2e12
    );
    a5[146..154].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &a5,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());

    let mut a8 = a8_rational_surface_stream();
    a8[275..283].copy_from_slice(&le_f64(2e12));
    let [surface] =
        crate::families::a5a8::records::a8_surfaces(&a8, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A8 surfaces")
            .try_into()
            .expect("one common-form rational surface");
    let surface = surface.geometry;
    assert_eq!(
        surface
            .pole_weights()
            .expect("weights")
            .into_iter()
            .next()
            .unwrap()
            .get(),
        2e12
    );
    a8[275..283].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a8_surfaces(
        &a8,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
}

#[test]
fn a5_surface_parser_reads_consolidated_nurbs() {
    let surfaces = crate::families::a5a8::records::a5_surfaces(
        &a5_surface_stream(),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    assert_eq!(surfaces.len(), 1);
    assert_eq!(surfaces[0].identity, None);
    assert_eq!(surfaces[0].object_id(), None);
    let surface = &surfaces[0].geometry;
    assert_eq!((surface.u_degree(), surface.v_degree()), (1, 1));
    assert_eq!((surface.u_count(), surface.v_count()), (2, 2));
    assert_eq!(surface.poles().into_iter().nth(3).unwrap().x, 3.0);
}

#[test]
fn a5_surface_parser_reads_multispan_cubic_nurbs() {
    let mut bytes = vec![0xa5, 0x03, 0x34];
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.push(0x05);
    for offset in [0.0, 10.0] {
        bytes.extend_from_slice(&[0x0d, 0x0d, 0x0c]);
        bytes.extend(
            [offset, offset + 1.0, offset + 2.0]
                .into_iter()
                .flat_map(le_f64),
        );
    }
    bytes.push(0x01);
    for pole in 0..25 {
        bytes.extend(
            [f64::from(pole), f64::from(pole % 5), f64::from(pole / 5)]
                .into_iter()
                .flat_map(le_f64),
        );
    }
    bytes.extend_from_slice(&a5_surface_tail());
    let payload_len = u32::try_from(bytes.len() - 8).unwrap();
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    let [surface] =
        crate::families::a5a8::records::a5_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A5 surfaces")
            .try_into()
            .expect("one multispan cubic surface");
    let surface = surface.geometry;
    assert_eq!((surface.u_degree(), surface.v_degree()), (3, 3));
    assert_eq!((surface.u_count(), surface.v_count()), (5, 5));
    assert_eq!(
        surface.u_knots().as_slice(),
        vec![0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 2.0, 2.0, 2.0]
    );
    assert_eq!(surface.poles().len(), 25);
}

#[test]
fn surface_parsers_accept_finite_large_control_points() {
    let mut a5 = a5_surface_stream();
    a5[47..55].copy_from_slice(&le_f64(2e12));
    let [surface] =
        crate::families::a5a8::records::a5_surfaces(&a5, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A5 surfaces")
            .try_into()
            .expect("one consolidated surface");
    let surface = surface.geometry;
    assert_eq!(surface.poles().into_iter().next().unwrap().x, 2e12);

    let mut a8 = a8_surface_stream();
    a8[59..67].copy_from_slice(&le_f64(2e12));
    let [surface] =
        crate::families::a5a8::records::a8_surfaces(&a8, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A8 surfaces")
            .try_into()
            .expect("one common-form surface");
    let surface = surface.geometry;
    assert_eq!(surface.poles().into_iter().next().unwrap().x, 2e12);

    a5[47..55].copy_from_slice(&le_f64(f64::NAN));
    a8[59..67].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &a5,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());
    assert!(crate::families::a5a8::records::a8_surfaces(
        &a8,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A8 surfaces")
    .is_empty());
}

#[test]
fn a5_surface_parser_rejects_nonfinite_and_repeated_distinct_knots() {
    let mut nonfinite_u = a5_surface_stream();
    nonfinite_u[11..19].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &nonfinite_u,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());

    let mut repeated_u = a5_surface_stream();
    repeated_u[19..27].copy_from_slice(&le_f64(0.0));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &repeated_u,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());

    let mut nonfinite_v = a5_surface_stream();
    nonfinite_v[30..38].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &nonfinite_v,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());
}

#[test]
fn consolidated_surface_parser_reads_width2_frame() {
    let surfaces = crate::families::a5a8::records::a5_surfaces(
        &a6_surface_stream(),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    assert_eq!(surfaces.len(), 1);
    assert_eq!(
        (
            surfaces[0].geometry.u_count(),
            surfaces[0].geometry.v_count()
        ),
        (2, 2)
    );
}

#[test]
fn a5_surface_parser_reads_rational_weight_program() {
    let surfaces = crate::families::a5a8::records::a5_surfaces(
        &a5_rational_surface_stream(),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    assert_eq!(
        surfaces[0]
            .geometry
            .pole_grid()
            .weights()
            .map(|rows| rows.concat()),
        Some(vec![2.0; 4])
    );
}

#[test]
fn a5_surface_parser_rejects_zero_tail_codes_without_underflow() {
    for index in [1, 3] {
        let mut malformed = a5_surface_stream();
        let tail = malformed
            .windows(4)
            .position(|window| window == [0x05, 0x05, 0x05, 0x05])
            .expect("surface tail");
        malformed[tail + index] = 0;
        assert!(crate::families::a5a8::records::a5_surfaces(
            &malformed,
            &mut crate::nurbs::LaneRefusals::new()
        )
        .expect("decode the A5 surfaces")
        .is_empty());
    }
}

#[test]
fn a5_surface_parser_rejects_untagged_int_bytes_without_underflow() {
    let bytes = [
        0xa5, 0xa5, 0x03, 0x34, 0, 0, 0, 0, 0, 0, 0, 0xa5, 0xb3, 0xa5, 0xa5, 0xb3, 0xb3, 0xa5,
    ];
    assert!(crate::families::a5a8::records::a5_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());
}

#[test]
fn a5_surface_parser_accepts_each_structured_tail_variant() {
    for tail in [
        a5_surface_short_tail(),
        a5_surface_tail(),
        a5_surface_extrapolated_short_tail(),
        a5_surface_extrapolated_tail(),
    ] {
        let surfaces = crate::families::a5a8::records::a5_surfaces(
            &a5_surface_stream_with_tail(&tail),
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the A5 surfaces");
        assert_eq!(surfaces.len(), 1, "tail length {}", tail.len());
    }
}

#[test]
fn a5_surface_parser_accepts_additional_terminal_spans() {
    let mut short = a5_surface_tail();
    let short_suffix = short.len() - 6;
    short[short_suffix + 2] = 0x09;
    let mut extended = a5_surface_extrapolated_tail();
    let extended_suffix = extended.len() - 7;
    extended[extended_suffix..extended_suffix + 5].copy_from_slice(&[0x19, 0x00, 0x19, 0x01, 0x0d]);
    for tail in [short, extended] {
        let surfaces = crate::families::a5a8::records::a5_surfaces(
            &a5_surface_stream_with_tail(&tail),
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the A5 surfaces");
        assert_eq!(surfaces.len(), 1);
    }
}

#[test]
fn a5_surface_parser_reads_extended_array_marker_and_terminal() {
    let mut tail = a5_surface_extrapolated_tail();
    let terminal_index = tail.len() - 5;
    tail[terminal_index] = 0x01;
    let mut bytes = a5_surface_stream_with_tail(&tail);
    bytes.splice(10..11, [0x08, 0x0d]);
    let payload_len = u32::try_from(bytes.len() - 8).unwrap();
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    let surfaces =
        crate::families::a5a8::records::a5_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("decode the A5 surfaces");
    assert_eq!(surfaces.len(), 1);
    assert_eq!(
        (
            surfaces[0].geometry.u_count(),
            surfaces[0].geometry.v_count()
        ),
        (2, 2)
    );

    bytes[11] = 0x11;
    assert_eq!(crate::families::a5a8::records::a5_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces")
    .len(), 1);

    bytes[11] = 0x19;
    assert!(crate::families::a5a8::records::a5_surfaces(
        &bytes,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces")
    .is_empty());
}

#[test]
fn a5_sheet_surface_accepts_owned_array_marker() {
    let mut bytes = a5_surface_stream();
    bytes.splice(10..11, [0x08, 0x19]);
    let payload_len = u32::try_from(bytes.len() - 8).expect("test frame fits u32");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
    let mut refusal = crate::nurbs::LaneRefusals::new();
    let frames = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(
        super::a5_owned_surfaces_from_records(&bytes, &frames, &mut refusal)
            .expect("parse the sheet surface")
            .len(),
        1,
    );
    assert!(super::a5_surfaces(&bytes, &mut refusal)
        .expect("parse non-sheet records")
        .is_empty());
}

#[test]
fn a5_surface_parser_accepts_additional_bounded_array_markers() {
    for marker in [0x05, 0x15] {
        let mut bytes = a5_surface_stream();
        bytes.splice(10..11, [0x08, marker]);
        let payload_len = u32::try_from(bytes.len() - 8).expect("test length");
        bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
        let surfaces = crate::families::a5a8::records::a5_surfaces(
            &bytes,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the A5 surfaces");
        assert_eq!(surfaces.len(), 1);
    }
}

#[test]
fn a5_surface_parser_rejects_unclosed_or_nonfinite_tail_data() {
    let mut trailing = a5_surface_stream();
    trailing.push(0);
    let payload_len = u32::try_from(trailing.len() - 8).unwrap();
    trailing[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert!(crate::families::a5a8::records::a5_surfaces(
        &trailing,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());

    let mut nonfinite = a5_surface_stream();
    let tail = nonfinite
        .windows(4)
        .position(|window| window == [0x05, 0x05, 0x05, 0x05])
        .expect("surface tail");
    nonfinite[tail + 4..tail + 12].copy_from_slice(&le_f64(f64::NAN));
    assert!(crate::families::a5a8::records::a5_surfaces(
        &nonfinite,
        &mut crate::nurbs::LaneRefusals::new()
    )
    .expect("decode the A5 surfaces")
    .is_empty());
}

#[test]
fn a5_weight_program_reads_independent_palindromic_rows() {
    let mut bytes = Vec::new();
    for seed in [[1.0, 0.8], [0.9, 0.65]] {
        bytes.extend_from_slice(&[0x01, 0x03, 0x00]);
        bytes.extend(seed.into_iter().flat_map(le_f64));
    }
    bytes.push(0x02);
    bytes.extend_from_slice(&[0x01, 0x03, 0x00]);
    bytes.extend([1.0, 0.8].into_iter().flat_map(le_f64));
    let mut at = 0;
    assert_eq!(
        crate::families::a5a8::records::a5_weights(&bytes, &mut at, 4, 4, bytes.len()).map(
            |weights| weights
                .into_iter()
                .map(cadmpeg_ir::scalar::NonZeroReal::get)
                .collect::<Vec<_>>()
        ),
        Some(vec![
            1.0, 0.8, 0.8, 1.0, 0.9, 0.65, 0.65, 0.9, 0.9, 0.65, 0.65, 0.9, 1.0, 0.8, 0.8, 1.0,
        ])
    );
    assert_eq!(at, bytes.len());
}

#[test]
fn a5_weight_program_reads_zero_prefixed_complete_grid() {
    let expected = [
        1.0, 0.72, 1.31, 0.93, 0.84, 1.19, 0.67, 1.42, 1.27, 0.76, 1.08, 0.88, 0.69, 1.36, 0.81,
        1.14,
    ];
    let mut bytes = vec![0x00];
    bytes.extend(expected.into_iter().flat_map(le_f64));
    let mut at = 0;
    assert_eq!(
        crate::families::a5a8::records::a5_weights(&bytes, &mut at, 4, 4, bytes.len()).map(
            |weights| weights
                .into_iter()
                .map(cadmpeg_ir::scalar::NonZeroReal::get)
                .collect::<Vec<_>>()
        ),
        Some(expected.to_vec())
    );
    assert_eq!(at, bytes.len());
}

#[test]
fn a5_weight_program_does_not_cross_frame_boundary() {
    let mut bytes = vec![0x00];
    bytes.extend([1.0, 2.0, 3.0, 4.0].into_iter().flat_map(le_f64));
    bytes.extend([0u8; 8]);
    let mut at = 0;
    assert!(crate::families::a5a8::records::a5_weights(&bytes, &mut at, 2, 2, 1 + 3 * 8).is_none());
}

#[test]
fn a5_cubic_two_site_knots_are_clamped() {
    assert_eq!(
        crate::families::a5a8::records::a5_knots(&[0.0, 4.0], 3),
        Some((vec![0.0, 0.0, 0.0, 0.0, 4.0, 4.0, 4.0, 4.0], 4))
    );
}

#[test]
fn a5_curve_parser_reads_degree5_rolling_ball_jet() {
    let expected =
        crate::families::a5a8::records::a5_freeform_curves(&a5_freeform_curve_stream()).remove(0);
    for header_token in (1..=u8::MAX).step_by(4) {
        let mut bytes = a5_freeform_curve_stream();
        bytes[7] = header_token;
        let curves = crate::families::a5a8::records::a5_freeform_curves(&bytes);
        assert_eq!(curves.len(), 1);
        assert_eq!(curves[0].header_token, u32::from(header_token));
        assert_eq!(curves[0].sites, expected.sites);
        assert_eq!(
            crate::test_support::with_service_context(|_ctx| curves[0].knots()),
            vec![0.0, 1.0]
        );
        assert_eq!(curves[0].sites[1].site.radius(), 2.0);
    }

    let mut wrong_degree = a5_freeform_curve_stream();
    wrong_degree[9] = 17;
    assert!(crate::families::a5a8::records::a5_freeform_curves(&wrong_degree).is_empty());

    for header_token in (0..=u8::MAX).filter(|token| token % 4 != 1) {
        let mut invalid_header_token = a5_freeform_curve_stream();
        invalid_header_token[7] = header_token;
        assert!(
            crate::families::a5a8::records::a5_freeform_curves(&invalid_header_token).is_empty()
        );
    }
}

#[test]
fn a5_curve_parser_accepts_compact_array_marker_values() {
    let mut bytes = a5_freeform_curve_stream();
    bytes[7] = 17;
    bytes[11] = 0x08;
    bytes.insert(12, 0x11);
    let payload_len = u32::try_from(bytes.len() - 8).expect("test frame fits u32");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    let [curve] = crate::families::a5a8::records::a5_freeform_curves(&bytes)
        .try_into()
        .expect("one compact-marker rolling-ball jet");
    assert_eq!(curve.header_token, 17);
    assert_eq!(curve.sites.len(), 2);

    let mut invalid_marker = bytes;
    invalid_marker[12] = 0x12;
    assert!(crate::families::a5a8::records::a5_freeform_curves(&invalid_marker).is_empty());
}

#[test]
fn a5_curve_parser_accepts_owned_array_marker() {
    let mut bytes = a5_freeform_curve_stream();
    bytes[11] = 0x08;
    bytes.insert(12, 0x0f);
    let payload_len = u32::try_from(bytes.len() - 8).expect("test frame fits u32");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert_eq!(
        crate::families::a5a8::records::a5_freeform_curves(&bytes).len(),
        1
    );
}

#[test]
fn a5_owned_rolling_jet_accepts_alternate_compact_marker() {
    let mut bytes = a5_freeform_curve_stream();
    bytes.splice(11..12, [0x08, 0x1b]);
    let payload_len = u32::try_from(bytes.len() - 8).expect("test frame fits u32");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert!(super::a5_freeform_curves(&bytes).is_empty());
    let frames = crate::wire::records::consolidated_records(&bytes);
    assert_eq!(super::a5_owned_rolling_curves(&bytes, &frames).count(), 1);

    bytes[12] = 0x1a;
    assert_eq!(super::a5_owned_rolling_curves(&bytes, &frames).count(), 0);
}

#[test]
fn rolling_ball_radius_reports_only_actual_rail_movement() {
    let mut jet = super::a5_freeform_curves(&a5_freeform_curve_stream())
        .pop()
        .expect("rolling-ball fixture");
    jet.sites[1].site = jet.sites[0].site.clone();
    let (_, unchanged) = jet
        .clone()
        .definition_at_radius(1.0)
        .expect("matching radius");
    assert_eq!(unchanged, 0.0);

    let radius = 1.000_000_2;
    let (definition, moved) = jet
        .clone()
        .definition_at_radius(radius)
        .expect("nearby radius");
    assert_eq!(moved, radius - 1.0);
    let cadmpeg_ir::geometry::ProceduralSurfaceDefinition::RollingBallJet(stations) = definition
    else {
        panic!("rolling-ball definition");
    };
    let site = &stations.stations()[0].site;
    assert_eq!(site.first_limit.distance(site.center.get()), radius);
    assert_eq!(site.second_limit.distance(site.center.get()), radius);
    assert!(jet.definition_at_radius(1.001).is_none());
}

#[test]
fn a5_curve_parser_rejects_untyped_continuation() {
    let mut bytes = a5_freeform_curve_stream();
    bytes.extend(std::iter::repeat_n(0, 4097));
    let payload_len = u32::try_from(bytes.len() - 8).expect("test frame fits u32");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());

    assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
}

#[test]
fn a5_rolling_ball_tails_close_all_three_productions() {
    let original = a5_freeform_curve_stream();
    let tail_start = original.len() - 79;
    let mut no_map = original[tail_start..].to_vec();
    no_map[..8].copy_from_slice(&le_f64(0.25));
    no_map[8..16].copy_from_slice(&le_f64(0.75));
    let mut repeated = no_map.clone();
    repeated.extend_from_slice(&le_f64(2.0));
    let mut mapped = no_map[..57].to_vec();
    mapped.extend_from_slice(&[0x01, 0x01]);
    for value in [0.0, 1.0, 1.0, 1.0, 0.0, 0.0] {
        mapped.extend_from_slice(&le_f64(value));
    }
    mapped.extend_from_slice(&1u32.to_le_bytes());
    mapped.extend_from_slice(&no_map[63..]);
    mapped.extend_from_slice(&le_f64(2.0));
    assert_eq!(mapped.len(), 135);
    let mut mapped_zero_terminal = mapped.clone();
    mapped_zero_terminal[107..111].copy_from_slice(&0u32.to_le_bytes());
    let expected = crate::families::a5a8::records::a5_freeform_curves(&original).remove(0);
    for tail in [no_map, repeated, mapped, mapped_zero_terminal] {
        for width in 1..=3 {
            for marker in [vec![0x0c], vec![0x08, 0x05]] {
                let mut payload = original[8..11].to_vec();
                payload.extend_from_slice(&marker);
                payload.extend_from_slice(&original[12..tail_start]);
                payload.extend_from_slice(&tail);
                let mut bytes = vec![0xa4 + width, 0x03, 0x32];
                bytes.extend_from_slice(
                    &u32::try_from(payload.len())
                        .expect("test length")
                        .to_le_bytes(),
                );
                bytes.extend(std::iter::repeat_n(0x05, usize::from(width)));
                bytes.extend_from_slice(&payload);
                let [jet] = crate::families::a5a8::records::a5_freeform_curves(&bytes)
                    .try_into()
                    .expect("complete rolling-ball tail");
                assert_eq!(jet.sites, expected.sites);
            }
        }
    }
}

#[test]
fn a5_rolling_ball_extended_tail_admits_state_and_terminal() {
    let original = a5_freeform_curve_stream();
    let tail_start = original.len() - 79;
    for state in [0, 1] {
        let mut bytes = original.clone();
        bytes[tail_start + 60] = state;
        bytes.extend_from_slice(&original[tail_start + 32..tail_start + 40]);
        bytes.extend_from_slice(&[0, 0]);
        let payload_len = u32::try_from(bytes.len() - 8).expect("test length");
        bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
        assert_eq!(
            crate::families::a5a8::records::a5_freeform_curves(&bytes).len(),
            1
        );
        let terminal = bytes.len() - 1;
        bytes[terminal] = 1;
        assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
    }
    let mut bytes = original.clone();
    bytes[tail_start + 59] = 1;
    bytes[tail_start + 60] = 1;
    bytes.extend_from_slice(&original[tail_start + 32..tail_start + 40]);
    bytes.extend_from_slice(&[0, 0]);
    let payload_len = u32::try_from(bytes.len() - 8).expect("test length");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert_eq!(
        crate::families::a5a8::records::a5_freeform_curves(&bytes).len(),
        1
    );
    let trimmed_upper = bytes.len() - 18;
    bytes[trimmed_upper..trimmed_upper + 8].copy_from_slice(&0.75f64.to_le_bytes());
    assert_eq!(
        crate::families::a5a8::records::a5_freeform_curves(&bytes).len(),
        1
    );
    bytes[tail_start + 60] = 0;
    assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
}

#[test]
fn a5_rolling_ball_tail_refuses_truncation_and_invalid_lanes() {
    let original = a5_freeform_curve_stream();
    let tail_start = original.len() - 79;
    for length in 0..79 {
        let mut bytes = original[..tail_start + length].to_vec();
        let payload_len = u32::try_from(bytes.len() - 8).expect("test length");
        bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
        assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
    }
    for (offset, value) in [
        (0, -1.0),
        (8, 2.0),
        (16, 2.0),
        (24, 3.0),
        (32, 0.0),
        (41, 1.0),
        (49, 1.0),
        (63, 0.5),
        (71, 0.5),
    ] {
        let mut bytes = original.clone();
        bytes[tail_start + offset..tail_start + offset + 8].copy_from_slice(&le_f64(value));
        assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
    }
    for offset in [0, 8, 16, 24, 32, 41, 49, 63, 71] {
        let mut bytes = original.clone();
        bytes[tail_start + offset..tail_start + offset + 8].copy_from_slice(&le_f64(f64::NAN));
        assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
    }
    for offset in [40, 57, 58, 59, 60, 61, 62] {
        let mut bytes = original.clone();
        bytes[tail_start + offset] = 0x02;
        assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
    }
}

#[test]
fn owned_rolling_ball_uses_the_terminal_transverse_gauge() {
    let bytes = a5_freeform_curve_stream();
    let mut tail = bytes[bytes.len() - 79..].to_vec();
    tail[24..32].copy_from_slice(&le_f64(1.0));
    tail[49..57].copy_from_slice(&le_f64(1.0));
    tail.extend(le_f64(2.0));
    tail.extend([0, 0]);
    assert_eq!(
        super::a5_rolling_ball_tail(&tail, 2, [0.0, 1.0], true),
        Some(2.0)
    );
    assert_eq!(
        super::a5_rolling_ball_tail(&tail, 2, [0.0, 1.0], false),
        None
    );
    tail[63..71].copy_from_slice(&le_f64(0.25));
    assert_eq!(
        super::a5_rolling_ball_tail(&tail, 2, [0.0, 1.0], true),
        None
    );
    tail[59] = 1;
    assert_eq!(
        super::a5_rolling_ball_tail(&tail, 2, [0.0, 1.0], true),
        Some(2.0)
    );
}

#[test]
fn a5_rolling_ball_scalar_tail_refuses_invalid_jet_and_terminal() {
    let original = a5_freeform_curve_stream();
    let tail_start = original.len() - 79;
    let mut bytes = original[..tail_start + 57].to_vec();
    bytes.extend_from_slice(&[0x01, 0x01]);
    for value in [0.0, 1.0, 1.0, 1.0, 0.0, 0.0] {
        bytes.extend_from_slice(&le_f64(value));
    }
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&original[tail_start + 63..]);
    bytes.extend_from_slice(&le_f64(2.0));
    let payload_len = u32::try_from(bytes.len() - 8).expect("test length");
    bytes[3..7].copy_from_slice(&payload_len.to_le_bytes());
    assert_eq!(
        crate::families::a5a8::records::a5_freeform_curves(&bytes).len(),
        1
    );
    for offset in (59..107).step_by(8).chain(std::iter::once(127)) {
        let mut invalid = bytes.clone();
        invalid[tail_start + offset..tail_start + offset + 8].copy_from_slice(&le_f64(f64::NAN));
        assert!(crate::families::a5a8::records::a5_freeform_curves(&invalid).is_empty());
    }
    bytes[tail_start + 107..tail_start + 111].copy_from_slice(&2u32.to_le_bytes());
    assert!(crate::families::a5a8::records::a5_freeform_curves(&bytes).is_empty());
}

#[test]
fn a5_curve_parser_accepts_frame_bounded_site_count() {
    let curves = crate::families::a5a8::records::a5_freeform_curves(
        &a5_freeform_curve_stream_with_count(4097),
    );
    assert_eq!(curves.len(), 1);
    assert_eq!(curves[0].knots().len(), 4097);
    assert_eq!(curves[0].sites.len(), 4097);
}

#[test]
fn rolling_ball_limit_curves_reproduce_stored_endpoint_sites() {
    let [jet] = crate::families::a5a8::records::a5_freeform_curves(&a5_freeform_curve_stream())
        .try_into()
        .expect("one rolling-ball jet");
    for second_limit in [false, true] {
        let curve = crate::families::a5a8::records::rolling_ball_limit_curve(
            &jet,
            second_limit,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("exact limiting curve");
        let geometry = CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve));
        let expected = [jet.sites.first().unwrap(), jet.sites.last().unwrap()].map(|sample| {
            let point = if second_limit {
                sample.site.limit2
            } else {
                sample.site.limit1
            };
            point.get()
        });
        let knots = jet.knots();
        assert_eq!(
            cadmpeg_ir::eval::decode::curve_point(
                cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                &geometry,
                knots[0]
            )
            .map(cadmpeg_ir::features::FinitePoint3::get),
            Ok(expected[0])
        );
        assert_eq!(
            cadmpeg_ir::eval::decode::curve_point(
                cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                &geometry,
                knots[1]
            )
            .map(cadmpeg_ir::features::FinitePoint3::get),
            Ok(expected[1])
        );
    }
}

mod decode_transfer;

mod curve_and_guide_records;

#[test]
fn a8_surface_rejects_a_pole_grid_outside_its_declared_frame() {
    let mut bytes = a8_surface_stream_with_pcurve();
    let poles = bytes.drain(59..59 + 9 * 24).collect::<Vec<_>>();
    let payload_len = 48 + 141;
    bytes[3..7].copy_from_slice(&u32::try_from(payload_len).unwrap().to_le_bytes());
    let pcurve_start = 11 + payload_len;
    let pcurve_end = pcurve_start + 8 + usize::from(bytes[pcurve_start + 3]);
    bytes.splice(pcurve_end..pcurve_end, poles);
    assert!(crate::test_support::with_service_context(|_ctx| {
        super::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
    })
    .expect("bounded malformed surface")
    .is_empty());
    assert_eq!(
        super::a8_nested_b5_run_start(&bytes, 0, 11 + payload_len),
        None
    );
}

#[test]
fn a8_surface_header_does_not_read_mode_outside_its_declared_frame() {
    let mut bytes = a8_surface_stream();
    bytes[3..7].copy_from_slice(&47_u32.to_le_bytes());
    let headers = crate::test_support::with_service_context(|_ctx| {
        super::a8_surface_headers(&bytes).collect::<Vec<_>>()
    });
    assert!(headers.is_empty());
}

#[test]
fn a8_inline_pole_stream_decodes_one_surface() {
    let bytes = a8_surface_stream();
    let surfaces =
        crate::families::a5a8::records::a8_surfaces(&bytes, &mut crate::nurbs::LaneRefusals::new())
            .expect("compute the A8 surfaces");
    assert_eq!(surfaces.len(), 1);
}

#[test]
fn a8_surface_header_reads_the_frame_object_id() {
    let bytes = a8_surface_stream();
    let object_id = cadmpeg_core::decode::View::u32_le_at(&bytes, 7).expect("fixture object id");
    let header = crate::families::a5a8::records::a8_surface_header_from_object_frame(
        &bytes,
        0,
        bytes.len(),
        object_id,
    )
    .expect("complete surface header");
    assert_eq!(header.object_id, object_id);
}
