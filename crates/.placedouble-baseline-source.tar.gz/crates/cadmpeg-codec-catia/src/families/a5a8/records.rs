// SPDX-License-Identifier: Apache-2.0

use super::knot_lane::A8KnotLane;
use crate::math::distance;
use crate::wire::bytes::{compact_int, f64_le, f64_point, read_f64_array, u32_le_24};
#[cfg(test)]
use crate::wire::records::{consolidated_records, ConsolidatedPcurve};
use crate::wire::records::{
    ConsolidatedFamily, ConsolidatedFrame, ConsolidatedRecord, SourceExtent,
};
use cadmpeg_core::decode::{index_from_u32, View};
use cadmpeg_core::CodecError;
use cadmpeg_ir::features::{FinitePoint3, FiniteVector3};
use cadmpeg_ir::geometry::nurbs::NurbsError;
use cadmpeg_ir::geometry::{
    nurbs::{NurbsCurve, NurbsSurface},
    ProceduralSurfaceDefinition, RollingBallJetDerivative, RollingBallJetSite,
};
use cadmpeg_ir::math::Point3;
use cadmpeg_ir::scalar::{FiniteReal, NonZeroReal};
use cadmpeg_ir::units::FiniteVector;

const EPS_GUIDE_DIRECTION_UNIT: f64 = 1.0e-9;
const EPS_ROLLING_BALL_RADIUS: f64 = 1.0e-9;
const EPS_ROLLING_BALL_ANGLE: f64 = 1.0e-9;
const EPS_OWNED_ROLLING_BALL_RADIUS: f64 = 5.0e-7;
const EPS_OWNED_ROLLING_BALL_ANGLE: f64 = 5.0e-7;
const COLLAPSED_RAIL_TOLERANCE_MM: f64 = 0.00005;

/// A decoded common-form or consolidated freeform NURBS surface.
#[derive(Debug, Clone)]
pub(crate) struct FreeformSurface {
    /// Source offset of the framed record.
    pub(in crate::families) pos: usize,
    /// Inline persistent object id for an A8 carrier. `None` for an A5
    /// carrier identified only by [`Self::pos`].
    pub(in crate::families) identity: Option<u32>,
    /// The decoded NURBS carrier.
    pub(in crate::families) geometry: NurbsSurface,
}

impl FreeformSurface {
    /// Return the inline persistent object id when this is an A8 carrier.
    #[must_use]
    pub(in crate::families) fn object_id(&self) -> Option<u32> {
        self.identity
    }
}

#[derive(Clone, Copy)]
struct A8Frame {
    pos: usize,
    payload: usize,
    end: usize,
    object_id: u32,
}

#[derive(Clone, Copy)]
struct ObjectStreamFrame {
    payload: usize,
    end: usize,
    family: u8,
    class: u8,
    object_id: u32,
}

fn a8_frames(data: &[u8], class: u8) -> impl Iterator<Item = A8Frame> + '_ {
    let mut pos = 0usize;
    std::iter::from_fn(move || loop {
        if pos.checked_add(11).is_none_or(|end| end > data.len()) {
            return None;
        }
        if data[pos] != 0xa8 || !object_frame_flag(data[pos + 1]) {
            pos += 1;
            continue;
        }
        let Some(length) =
            View::u32_le_at(data, pos + 3).and_then(|value| usize::try_from(value).ok())
        else {
            pos += 1;
            continue;
        };
        let Some(end) = pos
            .checked_add(11)
            .and_then(|payload| payload.checked_add(length))
            .filter(|end| *end <= data.len())
        else {
            pos += 1;
            continue;
        };
        let Some(object_id) = View::u32_le_at(data, pos + 7) else {
            pos += 1;
            continue;
        };
        let frame = A8Frame {
            pos,
            payload: pos + 11,
            end,
            object_id,
        };
        pos = end;
        if data[frame.pos + 2] == class {
            return Some(frame);
        }
    })
}

fn object_frame_flag(flag: u8) -> bool {
    matches!(flag, 0x03 | 0x13 | 0x83)
}

fn object_stream_frame(data: &[u8], pos: usize) -> Option<ObjectStreamFrame> {
    if !object_frame_flag(*data.get(pos + 1)?) {
        return None;
    }
    let family = *data.get(pos)?;
    let class = *data.get(pos + 2)?;
    let (payload, length, object_id) = match family {
        0xb5 => (
            pos.checked_add(8)?,
            usize::from(*data.get(pos + 3)?),
            View::u32_le_at(data, pos + 4)?,
        ),
        0xa8 => (
            pos.checked_add(11)?,
            usize::try_from(View::u32_le_at(data, pos + 3)?).ok()?,
            View::u32_le_at(data, pos + 7)?,
        ),
        _ => return None,
    };
    let end = payload.checked_add(length)?;
    (end <= data.len()).then_some(ObjectStreamFrame {
        payload,
        end,
        family,
        class,
        object_id,
    })
}

fn closed_a8_child_run(data: &[u8], start: usize, end: usize) -> bool {
    let mut at = start;
    while at < end {
        let Some(frame) = object_stream_frame(data, at) else {
            return false;
        };
        if frame.family != 0xb5 || frame.end > end {
            return false;
        }
        at = frame.end;
    }
    at == end
}

/// Return the start of a length-closed B5 child run owned by an A8 frame.
///
/// Common-form surface frames may place their child run after the complete
/// inline pole representation and its optional surface tail. A marker
/// shaped byte sequence elsewhere in a surface payload is payload data and is
/// not a child run.
pub(in crate::families) fn a8_nested_b5_run_start(
    data: &[u8],
    frame_start: usize,
    frame_end: usize,
) -> Option<usize> {
    let payload_start = frame_start.checked_add(11)?;
    if frame_end > data.len() || payload_start > frame_end {
        return None;
    }
    if payload_start < frame_end && closed_a8_child_run(data, payload_start, frame_end) {
        return Some(payload_start);
    }
    let frame = object_stream_frame(data, frame_start)?;
    if frame.family != 0xa8 || frame.class != 0x34 || frame.end != frame_end {
        return None;
    }
    let layout = scan_a8_surface_layout(
        data,
        A8Frame {
            pos: frame_start,
            payload: payload_start,
            end: frame_end,
            object_id: frame.object_id,
        },
    )?;
    let poles = crate::nurbs_surface_control_count(
        usize::try_from(layout.u.poles).ok()?,
        usize::try_from(layout.v.poles).ok()?,
    )?;
    let pole_bytes = poles.checked_mul(24)?;
    let weight_bytes = if layout.rational {
        poles.checked_mul(8)?
    } else {
        0
    };
    let suffix_start = layout
        .pole_start
        .checked_add(pole_bytes)?
        .checked_add(weight_bytes)?;
    let child_start = a8_surface_suffix_start(data, suffix_start, frame_end)?;
    (child_start < frame_end).then_some(child_start)
}

fn parse_surface_tail(data: &[u8], at: usize, end: usize, owned: bool) -> Option<usize> {
    use crate::layout::surface_terminal_span_tail as layout;

    let tail = data.get(at..end)?;
    let mut cursor = layout::CONTROLS;
    let controls = [
        compact_int(tail, &mut cursor)?,
        compact_int(tail, &mut cursor)?,
        compact_int(tail, &mut cursor)?,
        compact_int(tail, &mut cursor)?,
    ];
    let extra = cursor.checked_sub(layout::PARAMETERS)?;
    if !owned && extra != 0 {
        return None;
    }
    let tail_len = tail.len().checked_sub(extra)?;
    let continuation_bytes = match tail_len {
        133 => 56,
        layout::LEN | 142 => layout::SUFFIX - layout::CONTINUATION,
        _ => return None,
    };
    if controls[0] != 1
        || !(controls[2] == 1 || owned && tail_len == 142 && controls[2] == 0)
        || !matches!(
            tail[layout::FLAGS + extra..layout::CONTINUATION + extra],
            [0x01, 0x01, 0x01] | [0x05, 0x05, 0x01]
        )
    {
        return None;
    }
    let parameters = read_f64_array::<8>(tail, cursor)?.map(FiniteReal::get);
    if parameters[0] >= parameters[1]
        || (if owned && tail_len == 142 {
            parameters[2] == parameters[3]
        } else {
            parameters[2] >= parameters[3]
        })
        || parameters[4] == 0.0
        || parameters[6] == 0.0
    {
        return None;
    }
    let continuation_start = layout::CONTINUATION + extra;
    let continuation_end = continuation_start + continuation_bytes;
    let continuation = tail.get(continuation_start..continuation_end)?;
    for index in 0..continuation_bytes / 8 {
        let value = f64_le(continuation, index * 8)?;
        if tail_len == 133 && value.get() != 0.0 {
            return None;
        }
    }
    let suffix = &tail[continuation_end..];
    let valid_suffix = match (
        tail_len,
        &tail[layout::FLAGS + extra..layout::CONTINUATION + extra],
    ) {
        (133, [0x01, 0x01, 0x01]) => suffix == [0x01, 0x00, 0x01, 0x00, 0x07, 0x07],
        (141, [0x01, 0x01, 0x01] | [0x05, 0x05, 0x01]) => {
            matches!(
                suffix,
                [0x01, 0x00, 0x01 | 0x09, 0x00, 0x07, 0x07] | [0x09, 0x00, 0x09, 0x00, 0x07, 0x07]
            ) || owned
                && matches!(
                    suffix,
                    [0x05, 0x00, 0x05 | 0x09, 0x00, 0x07, 0x07]
                        | [0x09, 0x00, 0x01, 0x00, 0x07, 0x07]
                )
        }
        (142, [0x01, 0x01, 0x01] | [0x05, 0x05, 0x01]) => {
            suffix.len() == 7
                && suffix[0] % 4 == 1
                && matches!(
                    suffix[1..4],
                    [0x00, 0x01 | 0x05 | 0x09 | 0x0d | 0x11 | 0x15 | 0x19, 0x01]
                )
                && suffix[4] % 4 == 1
                && suffix[5..] == [0x07, 0x07]
        }
        _ => false,
    };
    valid_suffix.then_some(end)
}

fn a8_inline_surface_tail(data: &[u8], at: usize, end: usize) -> Option<usize> {
    for tail_len in [133, 141, 142] {
        let Some(tail_end) = at.checked_add(tail_len).filter(|tail_end| *tail_end <= end) else {
            continue;
        };
        if parse_surface_tail(data, at, tail_end, false).is_some()
            && closed_a8_child_run(data, tail_end, end)
        {
            return Some(tail_end);
        }
    }
    None
}

fn a8_surface_suffix_start(data: &[u8], at: usize, end: usize) -> Option<usize> {
    if closed_a8_child_run(data, at, end) {
        return Some(at);
    }
    a8_inline_surface_tail(data, at, end)
}

fn object_stream_frames(data: &[u8]) -> impl Iterator<Item = ObjectStreamFrame> + '_ {
    let mut pos = 0usize;
    let mut child_end = None::<usize>;
    let mut resume = 0usize;
    std::iter::from_fn(move || loop {
        let limit = child_end.unwrap_or(data.len());
        if pos.checked_add(8).is_none_or(|end| end > limit) {
            if child_end.take().is_some() {
                pos = resume;
                continue;
            }
            return None;
        }
        let Some(frame) = object_stream_frame(data, pos).filter(|frame| frame.end <= limit) else {
            pos += 1;
            continue;
        };
        match frame.family {
            0xa8 if child_end.is_none() => {
                child_end = Some(frame.end);
                resume = frame.end;
                pos = frame.payload;
                return Some(frame);
            }
            0xb5 => {
                pos = frame.end;
                return Some(frame);
            }
            _ => pos += 1,
        }
    })
}

/// Parameter lattice decoded from an `a8 <flag> 34` surface record independently
/// of its pole representation.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct A8SurfaceHeader {
    /// Source offset of the framed record.
    pos: usize,
    /// Inline persistent object id.
    pub(in crate::families) object_id: u32,
    /// U degree.
    pub(super) u_degree: u32,
    /// V degree.
    pub(super) v_degree: u32,
    /// U knots and multiplicities.
    pub(super) u_knots: A8KnotLane,
    /// V knots and multiplicities.
    pub(super) v_knots: A8KnotLane,
    /// Whether the record selects rational weights.
    rational: bool,
}

impl A8SurfaceHeader {
    /// U pole count derived from degree and knot multiplicities.
    fn u_count(&self) -> Option<u32> {
        self.u_knots.pole_count(self.u_degree)
    }

    /// V pole count derived from degree and knot multiplicities.
    fn v_count(&self) -> Option<u32> {
        self.v_knots.pole_count(self.v_degree)
    }

    /// Expanded U and V knot vectors, or the carrier refusal for an axis whose
    /// pole count does not exceed its degree.
    fn expanded_knots(&self) -> Result<(Vec<f64>, Vec<f64>), NurbsError> {
        let axis = |name: &str, degree: u32, lane: &A8KnotLane| {
            lane.expanded(degree).ok_or_else(|| {
                NurbsError::Structure(format!(
                    "{name}_count must exceed {name}_degree {degree}, found {}",
                    lane.pole_count(degree).unwrap_or(0)
                ))
            })
        };
        Ok((
            axis("u", self.u_degree, &self.u_knots)?,
            axis("v", self.v_degree, &self.v_knots)?,
        ))
    }
}

#[derive(Debug, Clone)]
/// Degree-5 UV jet stored in an `a8 <flag> 20` object record.
pub(in crate::families) struct A8Pcurve {
    /// Inline object identifier.
    pub(in crate::families) object_id: u32,
    /// Referenced support-surface object identifier.
    pub(in crate::families) support_id: u32,
    /// Stored UV-jet channel-mode byte.
    #[cfg(test)]
    pub(super) mode: u8,
    /// Knot-aligned UV jet sites.
    pub(in crate::families) sites: Vec<A8PcurveSite>,
    /// Native parameter range.
    pub(in crate::families) range: [FiniteReal; 2],
}

/// One knot and its complete UV jet.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct A8PcurveSite {
    knot: FiniteReal,
    point: FiniteVector<2>,
    first_derivative: FiniteVector<2>,
    second_derivative: FiniteVector<2>,
}

impl A8Pcurve {
    pub(in crate::families) const DEGREE: u32 = 5;

    pub(in crate::families) fn knots(&self) -> Vec<FiniteReal> {
        self.sites.iter().map(|site| site.knot).collect()
    }

    #[cfg(test)]
    fn points(&self) -> Vec<[f64; 2]> {
        self.sites.iter().map(|site| site.point.get()).collect()
    }

    pub(in crate::families) fn bspline(&self) -> Option<(Vec<f64>, Vec<FiniteVector<2>>)> {
        let mut knots = Vec::new();
        let mut points = Vec::new();
        let mut first = Vec::new();
        let mut second = Vec::new();

        for site in &self.sites {
            knots.push(site.knot.get());
            points.push(site.point.get());
            first.push(site.first_derivative.get());
            second.push(site.second_derivative.get());
        }
        crate::nurbs::quintic_jet_bspline(Self::DEGREE, &knots, &points, &first, &second)
    }
}

/// Decode framed `a5 03 20` consolidated UV jets.
#[must_use]
#[cfg(test)]
fn a5_pcurves(data: &[u8]) -> Vec<ConsolidatedPcurve> {
    let records = consolidated_records(data);
    crate::wire::records::family_pcurves_from_records(data, &records, ConsolidatedFamily::A)
}

/// One knot-site value in an `a5 03 32` rolling-ball program.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct RollingBallSite {
    /// First limiting curve point.
    pub(in crate::families) limit1: FinitePoint3,
    /// Second limiting curve point.
    pub(in crate::families) limit2: FinitePoint3,
    /// Rolling-ball centre.
    pub(in crate::families) center: FinitePoint3,
    /// Stored opening angle.
    pub(in crate::families) theta: FiniteReal,
}

#[cfg(test)]
impl RollingBallSite {
    /// Radius from the centre to the first limit.
    fn radius(&self) -> f64 {
        distance(self.center.get(), self.limit1.get())
    }
}

/// One knot of a degree-5 rolling-ball jet.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct A5FreeformJet {
    /// Distinct knot.
    pub(in crate::families) knot: FiniteReal,
    /// Position channels at this knot.
    pub(in crate::families) site: RollingBallSite,
    /// Ten first-derivative channels.
    pub(in crate::families) first_derivatives: [FiniteReal; 10],
    /// Ten second-derivative channels.
    pub(in crate::families) second_derivatives: [FiniteReal; 10],
}

/// Consolidated degree-5 rolling-ball jet.
#[derive(Debug, Clone)]
pub(in crate::families) struct A5FreeformCurve {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Schema token immediately before the payload.
    pub(in crate::families) header_token: u32,
    /// Knot-aligned jet samples.
    pub(in crate::families) sites: Vec<A5FreeformJet>,
    pub(in crate::families) chart_v_end: f64,
}

impl A5FreeformCurve {
    pub(in crate::families) const DEGREE: u32 = 5;

    fn knots(&self) -> Vec<f64> {
        self.sites.iter().map(|site| site.knot.get()).collect()
    }

    pub(in crate::families) fn definition(&self) -> Option<ProceduralSurfaceDefinition> {
        let stations = self
            .sites
            .iter()
            .map(|sample| cadmpeg_ir::geometry::RollingBallJetStation {
                knot: sample.knot,
                multiplicity: Self::DEGREE + 1,
                site: rolling_ball_jet_site(
                    &sample.site,
                    sample.first_derivatives,
                    sample.second_derivatives,
                ),
            })
            .collect();
        cadmpeg_ir::geometry::RollingBallJetStations::from_parts(Self::DEGREE, stations)
            .ok()
            .map(ProceduralSurfaceDefinition::RollingBallJet)
    }

    pub(in crate::families) fn definition_at_radius(
        mut self,
        radius: f64,
    ) -> Option<(ProceduralSurfaceDefinition, f64)> {
        let mut max_shift_mm = 0.0_f64;
        for sample in &mut self.sites {
            let site = &mut sample.site;
            let center = site.center.get();
            let tolerance = if site.theta.get() == 0.0 {
                COLLAPSED_RAIL_TOLERANCE_MM
            } else {
                radius * EPS_OWNED_ROLLING_BALL_RADIUS
            };
            for rail in [&mut site.limit1, &mut site.limit2] {
                let observed = rail.distance(center);
                if observed <= 0.0 || (observed - radius).abs() > tolerance {
                    return None;
                }
                if (observed - radius).abs() > EPS_ROLLING_BALL_RADIUS {
                    let adjusted = FinitePoint3::new(
                        center.translated(rail.get().vector_from(center), radius / observed),
                    )?;
                    max_shift_mm = max_shift_mm.max(rail.distance(adjusted.get()));
                    *rail = adjusted;
                }
            }
        }
        Some((self.definition()?, max_shift_mm))
    }
}

/// Lower either limiting locus of a complete rolling-ball jet to its exact
/// degree-5 NURBS representation.
pub(in crate::families) fn rolling_ball_limit_curve(
    jet: &A5FreeformCurve,
    second_limit: bool,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<NurbsCurve> {
    let offset = usize::from(second_limit) * 3;
    let mut positions = Vec::new();
    let mut first = Vec::new();
    let mut second = Vec::new();

    for sample in &jet.sites {
        let limit = if second_limit {
            sample.site.limit2
        } else {
            sample.site.limit1
        };
        positions.push(limit.get().into());
        let values = FiniteReal::raw_array(sample.first_derivatives);
        first.push([values[offset], values[offset + 1], values[offset + 2]]);
        let values = FiniteReal::raw_array(sample.second_derivatives);
        second.push([values[offset], values[offset + 1], values[offset + 2]]);
    }
    let knots = jet.knots();
    let Some((knots, control_points)) = crate::nurbs::quintic_jet_bspline(
        A5FreeformCurve::DEGREE,
        &knots,
        &positions,
        &first,
        &second,
    ) else {
        refusal.push_solver(
            format_args!(
                "consolidated_a5_03_32 rolling-ball limit curve at byte {}",
                jet.pos
            ),
            "states knot-aligned jet samples the degree-5 B-spline lowering does not close",
        );
        return None;
    };
    let mut poles = Vec::new();

    poles.extend(
        control_points
            .into_iter()
            .map(|point| Point3::new(point[0], point[1], point[2])),
    );
    crate::nurbs::note_refusal(
        cadmpeg_ir::geometry::nurbs::NurbsCurve::from_lanes(
            A5FreeformCurve::DEGREE,
            knots,
            poles,
            None,
            false,
        ),
        refusal,
        format_args!(
            "consolidated_a5_03_32 rolling-ball limit curve at byte {}",
            jet.pos
        ),
    )
}

/// One position in an `a5/a6/a7 03 39` jet.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct GuideCurveSite {
    /// Parameter knot.
    knot: FiniteReal,
    /// Six first-derivative channels.
    pub(in crate::families) first_derivative: FiniteVector<6>,
    /// Six second-derivative channels.
    pub(in crate::families) second_derivative: FiniteVector<6>,
    /// Guide-curve point.
    pub(in crate::families) point: FiniteVector<3>,
    pub(in crate::families) reference_point: FiniteVector<3>,
}

/// Width-coded guide-curve and reference-direction jet.
#[derive(Debug, Clone)]
pub(in crate::families) struct A5GuideCurve {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Width-coded header token.
    pub(in crate::families) header_token: u32,
    /// Parametric degree.
    pub(in crate::families) degree: u32,
    /// Positions whose source triples pass the unit-direction gate.
    pub(in crate::families) sites: Vec<GuideCurveSite>,
}

impl A5GuideCurve {
    pub(in crate::families) fn knots(&self) -> Vec<f64> {
        self.sites.iter().map(|site| site.knot.get()).collect()
    }
}

/// One non-rational degree-5 NURBS curve stored in an `a5 13 16` frame.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct A5NurbsCurve {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Width-coded record token.
    pub(in crate::families) header_token: u32,
    /// Exact neutral curve.
    pub(in crate::families) geometry: NurbsCurve,
}

/// Decode length-closed `a5/a6/a7 13 16` non-rational NURBS curves.
#[cfg(test)]
fn a5_nurbs_curves(data: &[u8]) -> Vec<A5NurbsCurve> {
    let records = consolidated_records(data);
    a5_nurbs_curves_from_records(data, &records, &mut crate::nurbs::LaneRefusals::new())
}

pub(in crate::families) fn a5_nurbs_curves_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Vec<A5NurbsCurve> {
    let mut curves = Vec::new();

    for record in records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::A && record.class() == 0x16)
    {
        let (Some(payload), Some(end)) = (record.payload(), record.range()) else {
            continue;
        };
        let frame = ConsolidatedFrame {
            pos: record.byte_offset(),
            payload: payload.start,
            end: end.end,
            header_token: record.header_token(),
        };
        if let Some(curve) = parse_a5_nurbs_curve(data, frame, refusal) {
            curves.push(curve);
        }
    }
    curves
}

fn parse_a5_nurbs_curve(
    data: &[u8],
    frame: ConsolidatedFrame,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<A5NurbsCurve> {
    data.get(frame.payload..frame.end)?;

    let (degree, knot_count, control_count, knot_start, control_start) = (|| {
        let mut at = frame.payload;
        let degree = compact_int(data, &mut at)?;
        let knot_count = usize::try_from(compact_int(data, &mut at)?).ok()?;
        if degree != 5 || knot_count < 2 || data.get(at) != Some(&0x0c) {
            return None;
        }
        at += 1;
        let control_count = 6usize.checked_add(knot_count.checked_sub(2)?.checked_mul(3)?)?;
        let known_bytes = knot_count
            .checked_mul(8)?
            .checked_add(control_count.checked_mul(24)?)?
            .checked_add(36)?;
        if at.checked_add(known_bytes)? > frame.end {
            return None;
        }
        let knot_start = at;
        let mut previous_knot = None;
        for _ in 0..knot_count {
            let knot = f64_le(data, at)?.get();
            if previous_knot.is_some_and(|previous| knot <= previous) {
                return None;
            }
            previous_knot = Some(knot);
            at += 8;
        }
        if data.get(at) != Some(&0x01) {
            return None;
        }
        at += 1;
        let control_start = at;
        for _ in 0..control_count {
            f64_point(data, at)?;
            at += 24;
        }
        if compact_int(data, &mut at)? != 1 || compact_int(data, &mut at)? != 2 {
            return None;
        }
        let range_origin = f64_le(data, at)?.get();
        let repeated_end = f64_le(data, at + 8)?.get();
        let scale = f64_le(data, at + 16)?.get();
        let offset = f64_le(data, at + 24)?.get();
        at += 32;
        if range_origin.to_bits() != 0.0f64.to_bits()
            || repeated_end.to_bits() != previous_knot?.to_bits()
            || scale.to_bits() != 1.0f64.to_bits()
            || offset.to_bits() != 0.0f64.to_bits()
            || data.get(at..frame.end) != Some(&[0x00, 0x07])
        {
            return None;
        }
        Some((degree, knot_count, control_count, knot_start, control_start))
    })()?;
    let mut distinct_knots = Vec::new();

    for index in 0..knot_count {
        let at = knot_start.checked_add(index * 8)?;
        let knot = f64_le(data, at)?;
        distinct_knots.push(knot.get());
    }
    let mut control_points = Vec::new();

    for index in 0..control_count {
        let at = control_start.checked_add(index * 24)?;
        let point = f64_point(data, at)?;
        control_points.push(point);
    }
    let mut knots = Vec::new();

    for (index, knot) in distinct_knots.into_iter().enumerate() {
        let multiplicity = if index == 0 || index + 1 == knot_count {
            6
        } else {
            3
        };
        knots.extend(std::iter::repeat_with(|| knot).take(multiplicity));
    }
    crate::nurbs::note_refusal(
        cadmpeg_ir::geometry::nurbs::NurbsCurve::from_lanes(
            degree,
            knots,
            control_points,
            None,
            false,
        ),
        refusal,
        format_args!("a5 NURBS curve record at byte {}", frame.pos),
    )
    .map(|geometry| A5NurbsCurve {
        pos: frame.pos,
        header_token: frame.header_token,
        geometry,
    })
}

/// Decode `a5/a6/a7 03 39` guide-curve and unit-direction jets.
#[cfg(test)]
fn a5_guide_curves(data: &[u8]) -> Vec<A5GuideCurve> {
    let records = consolidated_records(data);
    a5_guide_curves_from_records(data, &records)
}

pub(in crate::families) fn a5_guide_curves_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<A5GuideCurve> {
    a5_guides_from_records(data, records, true)
}

pub(in crate::families) fn a5_ruled_guides_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<A5GuideCurve> {
    a5_guides_from_records(data, records, false)
}

fn a5_guides_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
    unit: bool,
) -> Vec<A5GuideCurve> {
    let mut curves = Vec::new();

    for record in records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::A && record.class() == 0x39)
    {
        let (Some(payload), Some(end)) = (record.payload(), record.range()) else {
            continue;
        };
        let frame = ConsolidatedFrame {
            pos: record.byte_offset(),
            payload: payload.start,
            end: end.end,
            header_token: record.header_token(),
        };
        if let Some(curve) = parse_a5_guide_curve(data, frame, unit) {
            curves.push(curve);
        }
    }
    curves
}

fn parse_a5_guide_curve(data: &[u8], frame: ConsolidatedFrame, unit: bool) -> Option<A5GuideCurve> {
    let mut at = frame.payload;
    let count = compact_int(data, &mut at).and_then(|value| usize::try_from(value).ok())?;
    let degree = compact_int(data, &mut at)?;
    if compact_int(data, &mut at).and_then(|value| usize::try_from(value).ok()) != Some(count)
        || count < 2
        || !(1..=9).contains(&degree)
    {
        return None;
    }
    let next = consume_array_marker(data, at)?;
    at = next;
    let block_bytes = count.checked_mul(48)?;
    let known_bytes = count
        .checked_mul(8)
        .and_then(|bytes| {
            block_bytes
                .checked_mul(3)
                .and_then(|blocks| bytes.checked_add(blocks))
        })
        .and_then(|bytes| bytes.checked_add(48))?;
    if at
        .checked_add(known_bytes)
        .is_none_or(|last| last > frame.end)
    {
        return None;
    }
    let knot_start = at;
    let first_block = at.checked_add(count * 8)?;
    let second_block = first_block.checked_add(block_bytes)?;
    let third_block = second_block.checked_add(block_bytes)?;
    if third_block
        .checked_add(block_bytes)
        .and_then(|last| last.checked_add(48))
        != Some(frame.end)
    {
        return None;
    }

    let mut previous = None;
    for index in 0..count {
        let knot = f64_le(data, knot_start + index * 8)?;
        if previous.is_some_and(|value| value >= knot.get()) {
            return None;
        }
        previous = Some(knot.get());
    }
    let mut sites = Vec::new();

    for index in 0..count {
        let offset = index * 48;
        let (Some(value), Some(first_derivative), Some(second_derivative), Some(knot)) = (
            read_f64_array::<6>(data, first_block + offset),
            read_f64_array::<6>(data, second_block + offset),
            read_f64_array::<6>(data, third_block + offset),
            f64_le(data, knot_start + index * 8),
        ) else {
            return None;
        };
        let direction = [
            value[3].get() - value[0].get(),
            value[4].get() - value[1].get(),
            value[5].get() - value[2].get(),
        ];
        let length = (direction[0].powi(2) + direction[1].powi(2) + direction[2].powi(2)).sqrt();
        if !length.is_finite()
            || length == 0.0
            || (unit && (length - 1.0).abs() >= EPS_GUIDE_DIRECTION_UNIT)
        {
            return None;
        }
        sites.push(GuideCurveSite {
            knot,
            first_derivative: first_derivative.into(),
            second_derivative: second_derivative.into(),
            point: [value[0], value[1], value[2]].into(),
            reference_point: [value[3], value[4], value[5]].into(),
        });
    }
    Some(A5GuideCurve {
        pos: frame.pos,
        header_token: frame.header_token,
        degree,
        sites,
    })
}

/// One knot of a common-form degree-5 rolling-ball jet.
#[derive(Debug, Clone, PartialEq)]
struct A8FreeformJet {
    /// Distinct knot.
    knot: FiniteReal,
    /// Multiplicity of this distinct knot.
    multiplicity: u32,
    /// Position channels at this knot.
    pub(super) site: RollingBallSite,
    /// Ten first-derivative channels.
    first_derivatives: [FiniteReal; 10],
    /// Ten second-derivative channels.
    second_derivatives: [FiniteReal; 10],
}

/// Common-form degree-5 rolling-ball jet stored in an `a8 <flag> 32` object record.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct A8FreeformCurve {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Inline persistent object identifier.
    pub(in crate::families) object_id: u32,
    /// Knot-aligned jet samples.
    sites: Vec<A8FreeformJet>,
}

impl A8FreeformCurve {
    const DEGREE: u32 = 5;

    pub(in crate::families) fn multiplicities(&self) -> Vec<u32> {
        let mut multiplicities = Vec::new();

        multiplicities.extend(self.sites.iter().map(|site| site.multiplicity));
        multiplicities
    }
}

/// Convert a complete common-form rolling-ball jet to its exact neutral
/// procedural carrier.
pub(in crate::families) fn rolling_ball_jet_definition(
    jet: &A8FreeformCurve,
) -> Option<ProceduralSurfaceDefinition> {
    if jet.sites.is_empty() {
        return None;
    }
    let mut stations = Vec::new();

    stations.extend(
        jet.sites
            .iter()
            .map(|sample| cadmpeg_ir::geometry::RollingBallJetStation {
                knot: sample.knot,
                multiplicity: sample.multiplicity,
                site: rolling_ball_jet_site(
                    &sample.site,
                    sample.first_derivatives,
                    sample.second_derivatives,
                ),
            }),
    );
    cadmpeg_ir::geometry::RollingBallJetStations::from_parts(A8FreeformCurve::DEGREE, stations)
        .ok()
        .map(ProceduralSurfaceDefinition::RollingBallJet)
}

/// The admitted neutral jet site of one decoded rolling-ball site and its two
/// ten-channel derivative rows.
pub(in crate::families) fn rolling_ball_jet_site(
    site: &RollingBallSite,
    first_derivatives: [FiniteReal; 10],
    second_derivatives: [FiniteReal; 10],
) -> RollingBallJetSite<FiniteReal, FiniteVector3, FinitePoint3> {
    RollingBallJetSite {
        first_limit: site.limit1,
        second_limit: site.limit2,
        center: site.center,
        angle: site.theta,
        first_derivative: rolling_ball_jet_derivative(first_derivatives),
        second_derivative: rolling_ball_jet_derivative(second_derivatives),
    }
}

pub(in crate::families) fn rolling_ball_jet_derivative(
    values: [FiniteReal; 10],
) -> RollingBallJetDerivative<FiniteReal, FiniteVector3> {
    RollingBallJetDerivative {
        first_limit: FiniteVector3::from_components(values[0], values[1], values[2]),
        second_limit: FiniteVector3::from_components(values[3], values[4], values[5]),
        center: FiniteVector3::from_components(values[6], values[7], values[8]),
        angle: values[9],
    }
}

/// Decode framed `a8 <flag> 32` common-form rolling-ball jet records.
pub(in crate::families) fn a8_freeform_curves(data: &[u8]) -> Vec<A8FreeformCurve> {
    let mut curves = Vec::new();
    for frame in a8_frames(data, 0x32) {
        if let Some(curve) = parse_a8_curve(data, frame) {
            curves.push(curve);
        }
    }
    curves
}

fn parse_a8_curve(data: &[u8], frame: A8Frame) -> Option<A8FreeformCurve> {
    let A8Frame {
        pos,
        payload,
        end,
        object_id,
    } = frame;
    data.get(frame.payload..frame.end)?;

    let (count, knot_start, multiplicity_start, block_start, block_bytes) = (|| {
        let mut at = payload.checked_add(1)?;
        let count = usize::try_from(compact_int(data, &mut at)?).ok()?;
        let degree = compact_int(data, &mut at)?;
        at = at.checked_add(2)?;
        if usize::try_from(compact_int(data, &mut at)?).ok()? != count || count < 2 || degree != 5 {
            return None;
        }
        at = at.checked_add(if data.get(at) == Some(&0x08) { 2 } else { 1 })?;
        let knot_bytes = count.checked_mul(8)?;
        let block_bytes = count.checked_mul(80)?;
        let known_bytes = knot_bytes
            .checked_add(count)?
            .checked_add(block_bytes.checked_mul(3)?)?
            .checked_add(59)?;
        if at.checked_add(known_bytes)? > end {
            return None;
        }
        let knot_start = at;
        let mut previous_knot = None;
        for _ in 0..count {
            let knot = f64_le(data, at)?.get();
            if previous_knot.is_some_and(|previous| knot <= previous) {
                return None;
            }
            previous_knot = Some(knot);
            at += 8;
        }
        let multiplicity_start = at;
        for index in 0..count {
            let multiplicity = compact_int(data, &mut at)?;
            if (index == 0 || index + 1 == count) && multiplicity != 6 {
                return None;
            }
            if index != 0 && index + 1 != count && !matches!(multiplicity, 1 | 3) {
                return None;
            }
        }
        let block_start = at;
        let blocks_end = at.checked_add(block_bytes.checked_mul(3)?)?;
        if blocks_end > end || end - blocks_end != 59 {
            return None;
        }
        Some((
            count,
            knot_start,
            multiplicity_start,
            block_start,
            block_bytes,
        ))
    })()?;
    let mut sites = Vec::new();

    let mut multiplicity_at = multiplicity_start;
    for index in 0..count {
        let offset = index * 80;
        let (
            Some(knot),
            Some(multiplicity),
            Some(positions),
            Some(first_derivatives),
            Some(second_derivatives),
        ) = (
            f64_le(data, knot_start + index * 8),
            compact_int(data, &mut multiplicity_at),
            read_f64_array::<10>(data, block_start + offset),
            read_f64_array::<10>(data, block_start + block_bytes + offset),
            read_f64_array::<10>(data, block_start + 2 * block_bytes + offset),
        )
        else {
            return None;
        };
        let site = rolling_ball_site(positions, false)?;
        sites.push(A8FreeformJet {
            knot,
            multiplicity,
            site,
            first_derivatives,
            second_derivatives,
        });
    }
    Some(A8FreeformCurve {
        pos,
        object_id,
        sites,
    })
}

/// Decode framed `a5 03 32` rolling-ball jet records.
#[cfg(test)]
fn a5_freeform_curves(data: &[u8]) -> Vec<A5FreeformCurve> {
    let records = consolidated_records(data);
    a5_freeform_curves_from_records(data, &records)
}

pub(in crate::families) fn a5_freeform_curves_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<A5FreeformCurve> {
    a5_rolling_curves(data, records, false).collect()
}

pub(in crate::families) fn a5_owned_rolling_curves<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = A5FreeformCurve> + 'a {
    a5_rolling_curves(data, records, true)
}

fn a5_rolling_curves<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
    owned: bool,
) -> impl Iterator<Item = A5FreeformCurve> + 'a {
    records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::A && record.class() == 0x32)
        .filter_map(move |record| {
            let frame = ConsolidatedFrame {
                pos: record.byte_offset(),
                payload: record.payload()?.start,
                end: record.range()?.end,
                header_token: record.header_token(),
            };
            parse_a5_curve(data, frame, owned)
        })
}

fn parse_a5_curve(data: &[u8], frame: ConsolidatedFrame, owned: bool) -> Option<A5FreeformCurve> {
    let ConsolidatedFrame {
        pos,
        payload,
        end,
        header_token,
    } = frame;
    data.get(frame.payload..frame.end)?;

    let (count, knot_start, block_start, block_bytes, chart_v_end) = (|| {
        if data.get(pos) == Some(&0xa5) {
            let header_byte = u8::try_from(header_token).ok()?;
            a5_int(header_byte)?;
        }
        let mut at = payload;
        let count = usize::try_from(compact_int(data, &mut at)?).ok()?;
        let degree = compact_int(data, &mut at)?;
        if usize::try_from(compact_int(data, &mut at)?).ok()? != count || count < 2 || degree != 5 {
            return None;
        }
        match data.get(at..at + 2) {
            Some([0x0c, _]) => at += 1,
            Some([0x08, marker])
                if a5_int(*marker).is_some() || *marker == 0x0f || owned && *marker % 4 == 3 =>
            {
                at += 2;
            }
            _ => return None,
        }
        let knot_bytes = count.checked_mul(8)?;
        let block_bytes = count.checked_mul(80)?;
        let known_bytes = knot_bytes.checked_add(block_bytes.checked_mul(3)?)?;
        if at.checked_add(known_bytes)? > end {
            return None;
        }
        let knot_start = at;
        let mut previous_knot = None;
        for _ in 0..count {
            let knot = f64_le(data, at)?.get();
            if previous_knot.is_some_and(|previous| knot <= previous) {
                return None;
            }
            previous_knot = Some(knot);
            at += 8;
        }
        let tail_start = at.checked_add(block_bytes.checked_mul(3)?)?;
        let chart_v_end = a5_rolling_ball_tail(
            data.get(tail_start..end)?,
            count,
            [f64_le(data, knot_start)?.get(), previous_knot?],
            owned,
        )?;
        Some((count, knot_start, at, block_bytes, chart_v_end))
    })()?;
    let mut sites = Vec::new();

    for index in 0..count {
        let offset = index * 80;
        let (Some(knot), Some(positions), Some(first_derivatives), Some(second_derivatives)) = (
            f64_le(data, knot_start + index * 8),
            read_f64_array::<10>(data, block_start + offset),
            read_f64_array::<10>(data, block_start + block_bytes + offset),
            read_f64_array::<10>(data, block_start + 2 * block_bytes + offset),
        ) else {
            return None;
        };
        let site = rolling_ball_site(positions, owned)?;
        sites.push(A5FreeformJet {
            knot,
            site,
            first_derivatives,
            second_derivatives,
        });
    }
    Some(A5FreeformCurve {
        pos,
        header_token,
        sites,
        chart_v_end,
    })
}

/// Validate the complete consolidated rolling-ball tail before retaining sites.
/// Scalar jets and the raw control remain in the source record; neither supplies
/// a source-curve identity or a neutral orientation.
fn a5_rolling_ball_tail(
    data: &[u8],
    count: usize,
    knot_range: [f64; 2],
    owned: bool,
) -> Option<f64> {
    use crate::layout::{
        rolling_ball_tail_prefix as prefix, rolling_ball_tail_unmapped_suffix as suffix,
    };

    let no_map_length = prefix::LEN + suffix::LEN;
    let repeated_length = no_map_length + 8;
    let extended_length = repeated_length + 2;
    let sheet_limits = owned && data.len() == extended_length;
    let current = read_f64_array::<5>(data, prefix::PARAMETERS)?.map(FiniteReal::get);
    let maximal_v = read_f64_array::<2>(data, prefix::MAXIMAL_V)?.map(FiniteReal::get);
    if !matches!(data.get(prefix::CONTROL), Some(0x03 | 0x05))
        || current[0] >= current[1]
        || current[2] >= current[3]
        || current[4] <= 0.0
        || (!sheet_limits && current[3].to_bits() != current[4].to_bits())
        || maximal_v[0] > current[2]
        || maximal_v[1] < current[3]
    {
        return None;
    }
    let mut trimmed_u = [false; 2];
    let mut at = match data.len() {
        length
            if length == no_map_length
                || length == repeated_length
                || length == extended_length =>
        {
            let branch = data.get(prefix::LEN + suffix::BRANCH..prefix::LEN + suffix::MAXIMAL_U)?;
            if length == extended_length {
                if branch.len() != suffix::BRANCH_VALUE.len()
                    || branch[0..2] != suffix::BRANCH_VALUE[0..2]
                    || branch[2] > 1
                    || branch[3] > 1
                    || branch[4..6] != suffix::BRANCH_VALUE[4..6]
                    || data.get(repeated_length..extended_length) != Some(&[0, 0][..])
                {
                    return None;
                }
                trimmed_u = [sheet_limits && branch[2] == 1, branch[3] == 1];
            } else if branch != suffix::BRANCH_VALUE {
                return None;
            }
            prefix::LEN + suffix::MAXIMAL_U
        }
        length if length == repeated_length.checked_add(count.checked_mul(24)?)? => {
            if data.get(prefix::LEN..prefix::LEN + 2) != Some(&[0x01, 0x01]) {
                return None;
            }
            let mut at = prefix::LEN + 2;
            for _ in 0..count.checked_mul(3)? {
                f64_le(data, at)?;
                at += 8;
            }
            if View::u32_le_at(data, at)? > 1 {
                return None;
            }
            at + 4
        }
        _ => return None,
    };
    let maximal_u = read_f64_array::<2>(data, at)?.map(FiniteReal::get);
    at += 16;
    if maximal_u[0] < knot_range[0]
        || (!trimmed_u[0] && maximal_u[0] > current[0])
        || maximal_u[0] >= maximal_u[1]
        || (!trimmed_u[1] && maximal_u[1] < current[1])
        || maximal_u[1] > knot_range[1]
    {
        return None;
    }
    let mut v_end = current[4];
    if data.len() != no_map_length {
        let terminal_v = f64_le(data, at)?.get();
        if sheet_limits {
            v_end = terminal_v;
            if terminal_v <= 0.0 {
                return None;
            }
        } else if terminal_v.to_bits() != current[4].to_bits() {
            return None;
        }
        at += 8;
    }
    if data.len() == extended_length {
        at += 2;
    }
    (at == data.len()).then_some(v_end)
}

fn rolling_ball_site(values: [FiniteReal; 10], owned: bool) -> Option<RollingBallSite> {
    let limit1 = FinitePoint3::from_coordinates(values[0], values[1], values[2]);
    let limit2 = FinitePoint3::from_coordinates(values[3], values[4], values[5]);
    let center = FinitePoint3::from_coordinates(values[6], values[7], values[8]);
    let theta = values[9];
    let radius = distance(center.get(), limit1.get());
    let other = distance(center.get(), limit2.get());
    let chord = distance(limit1.get(), limit2.get());
    let radius_scale = radius.max(other);
    let relative_radius_difference = ((radius / radius_scale) - (other / radius_scale)).abs();
    let tolerance = if owned {
        EPS_OWNED_ROLLING_BALL_RADIUS
    } else {
        EPS_ROLLING_BALL_RADIUS
    };
    let angle_tolerance = if owned {
        EPS_OWNED_ROLLING_BALL_ANGLE
    } else {
        EPS_ROLLING_BALL_ANGLE
    };
    if !radius.is_finite()
        || radius <= 0.0
        || !other.is_finite()
        || relative_radius_difference > tolerance
        || (theta.get() - 2.0 * ((chord / radius) * 0.5).clamp(-1.0, 1.0).asin()).abs()
            > angle_tolerance
    {
        return None;
    }
    Some(RollingBallSite {
        limit1,
        limit2,
        center,
        theta,
    })
}

/// Decode framed `a8 <flag> 20` UV jet records.
#[cfg(test)]
fn a8_pcurves(data: &[u8]) -> Vec<A8Pcurve> {
    let mut pcurves = Vec::new();
    for frame in
        object_stream_frames(data).filter(|frame| frame.class == 0x20 && frame.family == 0xa8)
    {
        if let Some(pcurve) =
            parse_object_stream_pcurve(data, frame.payload, frame.end, frame.object_id)
        {
            pcurves.push(pcurve);
        }
    }
    pcurves
}

/// Decode framed `a8 <flag> 20` and `b5 <flag> 20` object-stream UV jet records.
pub(in crate::families) fn object_stream_pcurves(data: &[u8]) -> Vec<A8Pcurve> {
    let mut pcurves = Vec::new();
    for frame in object_stream_frames(data).filter(|frame| frame.class == 0x20) {
        if let Some(pcurve) =
            parse_object_stream_pcurve(data, frame.payload, frame.end, frame.object_id)
        {
            pcurves.push(pcurve);
        }
    }
    pcurves
}

fn parse_object_stream_pcurve(
    data: &[u8],
    payload: usize,
    end: usize,
    object_id: u32,
) -> Option<A8Pcurve> {
    data.get(payload..end)?;

    let parsed = (|| {
        let mut at = payload + 1;
        let support_id = object_stream_reference(data, &mut at)?;
        let degree = compact_int(data, &mut at)?;
        at += 2;
        data.get(..at)?;
        let count = usize::try_from(compact_int(data, &mut at)?).ok()?;
        at += if data.get(at) == Some(&0x08) { 2 } else { 1 };
        if count < 2 || degree != A8Pcurve::DEGREE {
            return None;
        }
        let knot_bytes = count.checked_mul(8)?;
        let array_bytes = count.checked_mul(8)?.checked_mul(6)?;
        let known_bytes = knot_bytes
            .checked_add(count)?
            .checked_add(array_bytes)?
            .checked_add(20)?;
        if at.checked_add(known_bytes)? > end {
            return None;
        }
        let scan_finite = |at: &mut usize| -> Option<usize> {
            let start = *at;
            for _ in 0..count {
                f64_le(data, *at)?;
                *at += 8;
            }
            Some(start)
        };
        let knot_start = at;
        let mut previous_knot = None;
        for _ in 0..count {
            let knot = f64_le(data, at)?;
            if previous_knot.is_some_and(|previous| knot <= previous) {
                return None;
            }
            previous_knot = Some(knot);
            at += 8;
        }
        for index in 0..count {
            let multiplicity = compact_int(data, &mut at)?;
            if (index == 0 || index + 1 == count) && multiplicity != 6 {
                return None;
            }
            if index != 0 && index + 1 != count && multiplicity != 3 {
                return None;
            }
        }
        if usize::try_from(compact_int(data, &mut at)?).ok()? != count {
            return None;
        }
        let mode = *data.get(at)?;
        at += 1;
        if at.checked_add(array_bytes.checked_add(18)?)? > end {
            return None;
        }
        let u = scan_finite(&mut at)?;
        let v = scan_finite(&mut at)?;
        let du = scan_finite(&mut at)?;
        let dv = scan_finite(&mut at)?;
        if data.get(at) != Some(&0x05) {
            return None;
        }
        at += 1;
        let ddu = scan_finite(&mut at)?;
        let ddv = scan_finite(&mut at)?;
        let range = [f64_le(data, at)?, f64_le(data, at + 8)?];
        at += 16;
        if data.get(at) != Some(&0x07) || mode % 4 != 1 || range[0] >= range[1] || end != at + 1 {
            return None;
        }
        Some((
            support_id,
            mode,
            count,
            knot_start,
            [u, v, du, dv, ddu, ddv],
            range,
        ))
    })()?;
    #[cfg(test)]
    let mode = parsed.1;
    let (support_id, _, count, knot_start, array_starts, range) = parsed;
    let mut sites = Vec::new();

    for index in 0..count {
        let offset = index * 8;
        let knot = f64_le(data, knot_start + offset)?;
        let mut values = [knot; 6];
        for (slot, start) in values.iter_mut().zip(array_starts) {
            let value = f64_le(data, start + offset)?;
            *slot = value;
        }
        sites.push(A8PcurveSite {
            knot,
            point: [values[0], values[1]].into(),
            first_derivative: [values[2], values[3]].into(),
            second_derivative: [values[4], values[5]].into(),
        });
    }
    Some(A8Pcurve {
        object_id,
        support_id,
        #[cfg(test)]
        mode,
        sites,
        range,
    })
}

/// Decode common-form object-stream NURBS surfaces.  Every variable-length
/// field is bounded by the record's `payload_len`, so signature collisions do
/// not become carriers.
pub(crate) fn a8_surfaces(
    data: &[u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurface>, CodecError> {
    let mut surfaces = Vec::new();
    for frame in a8_frames(data, 0x34) {
        let Some(parsed) = parse_a8_surface_header(data, frame) else {
            continue;
        };
        if let Some(surface) = a8_surface_from_parsed(data, parsed, refusal)? {
            surfaces.push(surface);
        }
    }
    Ok(surfaces)
}

/// Decode A8 carriers within each logical source and retain physical frame offsets.
pub(in crate::families) fn a8_surfaces_in_sources(
    data: &[u8],
    sources: &[Vec<SourceExtent>],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurface>, CodecError> {
    let mut surfaces = Vec::new();
    for source in sources {
        let mut length = 0usize;
        let mut contiguous = true;
        let mut physical_end = None;
        for extent in source {
            let range = extent.range();
            if data.get(range.clone()).is_none() {
                return Err(CodecError::malformed(
                    "A8 source extent is outside the image",
                ));
            }
            contiguous &= physical_end.is_none_or(|end| end == range.start);
            physical_end = Some(range.end);
            length = length
                .checked_add(range.len())
                .ok_or_else(|| CodecError::malformed("A8 logical source length overflow"))?;
        }
        let Some(first) = source.first() else {
            continue;
        };
        let decoded = if contiguous {
            a8_surfaces(
                &data[first.range().start..physical_end.unwrap_or(first.range().start)],
                refusal,
            )?
        } else {
            let mut bytes = Vec::new();
            for extent in source {
                bytes.extend_from_slice(&data[extent.range()]);
            }
            a8_surfaces(&bytes, refusal)?
        };
        for mut surface in decoded {
            let mut offset = surface.pos;
            for extent in source {
                let range = extent.range();
                if offset < range.len() {
                    surface.pos = range.start + offset;
                    break;
                }
                offset -= range.len();
            }
            surfaces.push(surface);
        }
    }
    Ok(surfaces)
}

/// Decode every structurally complete `a8 <flag> 34` parameter lattice, including
/// records whose pole representation is not inline.
#[cfg(test)]
fn a8_surface_headers(data: &[u8]) -> impl Iterator<Item = A8SurfaceHeader> + '_ {
    a8_frames(data, 0x34).filter_map(move |frame| {
        a8_surface_header_from_object_frame(data, frame.pos, frame.end, frame.object_id)
    })
}

/// Decode one selected `a8 <flag> 34` frame's parameter lattice.
pub(in crate::families) fn a8_surface_header_from_object_frame(
    data: &[u8],
    start: usize,
    end: usize,
    object_id: u32,
) -> Option<A8SurfaceHeader> {
    parse_selected_a8_surface_header(data, start, end, object_id).map(|parsed| parsed.header)
}

/// Decode one selected `a8 <flag> 34` frame and its complete pole grid.
pub(in crate::families) fn a8_surface_from_object_frame(
    data: &[u8],
    start: usize,
    end: usize,
    object_id: u32,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<FreeformSurface>, CodecError> {
    let Some(parsed) = parse_selected_a8_surface_header(data, start, end, object_id) else {
        return Ok(None);
    };
    a8_surface_from_parsed(data, parsed, refusal)
}

fn grid_rows<T>(values: Vec<T>, row_len: usize) -> Result<Vec<Vec<T>>, CodecError> {
    if row_len == 0 {
        return Err(CodecError::malformed("zero NURBS grid row width"));
    }
    let rows = values.len() / row_len;

    let mut result = Vec::new();

    let mut values = values.into_iter();
    for _ in 0..rows {
        let mut row = Vec::new();

        row.extend(values.by_ref().take(row_len));
        result.push(row);
    }
    Ok(result)
}

/// Decode consolidated `a5 03 34` NURBS surface carriers.  This family uses
/// implicit clamped multiplicities instead of the explicit `a8` vectors.
pub(crate) fn a5_surfaces(
    data: &[u8],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurface>, CodecError> {
    let records = crate::wire::records::consolidated_records_in_sources(
        data,
        std::iter::once(std::iter::once(crate::wire::records::SourceExtent::whole(
            data,
        ))),
    )?;
    a5_surfaces_from_records(data, &records, refusal)
}

pub(in crate::families) fn a5_surfaces_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurface>, CodecError> {
    a5_surfaces_in_scope(data, records, refusal, false)
}

pub(in crate::families) fn a5_owned_surfaces_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurface>, CodecError> {
    a5_surfaces_in_scope(data, records, refusal, true)
}

fn a5_surfaces_in_scope(
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
    owned: bool,
) -> Result<Vec<FreeformSurface>, CodecError> {
    let mut surfaces = Vec::new();

    for record in records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::A && record.class() == 0x34)
    {
        let (Some(payload), Some(end)) = (record.payload(), record.range()) else {
            continue;
        };
        let frame = ConsolidatedFrame {
            pos: record.byte_offset(),
            payload: payload.start,
            end: end.end,
            header_token: record.header_token(),
        };
        if let Some(surface) = a5_surface(data, frame, refusal, owned)? {
            surfaces.push(surface);
        }
    }
    Ok(surfaces)
}

fn a5_surface(
    data: &[u8],
    frame: ConsolidatedFrame,
    refusal: &mut crate::nurbs::LaneRefusals,
    owned: bool,
) -> Result<Option<FreeformSurface>, CodecError> {
    let ConsolidatedFrame {
        pos, payload, end, ..
    } = frame;
    let mut at = payload;
    let Some(u_degree) = data.get(at).and_then(|&byte| a5_int(byte)) else {
        return Ok(None);
    };
    at += 1;
    let Some(u_distinct_count) = a5_distinct_count(data, &mut at, owned) else {
        return Ok(None);
    };
    let Some(next) = a5_array_marker(data, at, owned) else {
        return Ok(None);
    };
    at = next;
    let Some(u_distinct) = a5_distinct_values(data, &mut at, u_distinct_count, end) else {
        return Ok(None);
    };
    let Some(v_degree) = data.get(at).and_then(|&byte| a5_int(byte)) else {
        return Ok(None);
    };
    at += 1;
    let Some(v_distinct_count) = a5_distinct_count(data, &mut at, owned) else {
        return Ok(None);
    };
    let Some(next) = a5_array_marker(data, at, owned) else {
        return Ok(None);
    };
    at = next;
    let Some(v_distinct) = a5_distinct_values(data, &mut at, v_distinct_count, end) else {
        return Ok(None);
    };
    let Some(&mode) = data.get(at) else {
        return Ok(None);
    };
    at += 1;
    if !cadmpeg_ir::geometry::nurbs::knots_strictly_increasing(&u_distinct)
        || !cadmpeg_ir::geometry::nurbs::knots_strictly_increasing(&v_distinct)
    {
        return Ok(None);
    }
    let Some((u_knots, u_count)) = a5_knots(&u_distinct, u_degree) else {
        return Ok(None);
    };
    let Some((v_knots, v_count)) = a5_knots(&v_distinct, v_degree) else {
        return Ok(None);
    };
    let (Some(u_count), Some(v_count)) =
        (usize::try_from(u_count).ok(), usize::try_from(v_count).ok())
    else {
        return Ok(None);
    };
    let Some(poles) = crate::nurbs_surface_control_count(u_count, v_count) else {
        return Ok(None);
    };
    if poles
        .checked_mul(24)
        .and_then(|bytes| at.checked_add(bytes))
        .is_none_or(|end_poles| end_poles > end)
    {
        return Ok(None);
    }
    let mut control_points = Vec::new();

    for _ in 0..poles {
        let Some(point) = f64_point(data, at) else {
            return Ok(None);
        };
        control_points.push(point);
        at += 24;
    }
    let weights = match mode {
        0x01 => None,
        0x05 => {
            let Some(weights) = a5_weights(data, &mut at, u_count, v_count, end) else {
                return Ok(None);
            };
            Some(weights)
        }
        _ => return Ok(None),
    };
    if parse_surface_tail(data, at, end, owned).is_none() {
        return Ok(None);
    }
    let control_points = grid_rows(control_points, v_count)?;
    let weights = weights
        .map(|values| grid_rows(values, v_count))
        .transpose()?;
    Ok(crate::nurbs::note_refusal(
        NurbsSurface::from_checked_lanes(
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(u_degree, u_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(v_degree, v_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(control_points, weights),
            false,
        ),
        refusal,
        format_args!("a5 NURBS surface record at byte {pos}"),
    )
    .map(|geometry| FreeformSurface {
        pos,
        identity: None,
        geometry,
    }))
}

struct ParsedA8SurfaceHeader {
    header: A8SurfaceHeader,
    pole_start: usize,
    end: usize,
}

fn parse_selected_a8_surface_header(
    data: &[u8],
    start: usize,
    end: usize,
    object_id: u32,
) -> Option<ParsedA8SurfaceHeader> {
    let frame = object_stream_frame(data, start)?;
    if !(frame.family == 0xa8
        && frame.class == 0x34
        && frame.end == end
        && frame.object_id == object_id)
    {
        return None;
    }
    parse_a8_surface_header(
        data,
        A8Frame {
            pos: start,
            payload: frame.payload,
            end,
            object_id,
        },
    )
}

#[derive(Clone, Copy)]
struct A8LaneLayout {
    distinct_start: usize,
    multiplicity_start: usize,
    count: usize,
    poles: u32,
}

struct A8SurfaceLayout {
    u_degree: u32,
    v_degree: u32,
    u: A8LaneLayout,
    v: A8LaneLayout,
    pole_start: usize,
    rational: bool,
}

fn scan_a8_lane(
    data: &[u8],
    at: &mut usize,
    count: usize,
    degree: u32,
    end: usize,
) -> Option<A8LaneLayout> {
    let distinct_start = *at;
    if at.checked_add(count.checked_mul(8)?)? > end {
        return None;
    }
    let mut last = None;
    for _ in 0..count {
        let value = f64_le(data, *at)?.get();
        if last.is_some_and(|previous| previous >= value) {
            return None;
        }
        last = Some(value);
        *at += 8;
    }
    let multiplicity_start = *at;
    let mut total = 0u32;
    for _ in 0..count {
        let multiplicity = compact_int(data, at)?;
        if multiplicity == 0 {
            return None;
        }
        total = total.checked_add(multiplicity)?;
    }
    let poles = total.checked_sub(degree.checked_add(1)?)?;
    Some(A8LaneLayout {
        distinct_start,
        multiplicity_start,
        count,
        poles,
    })
}

fn scan_a8_surface_layout(data: &[u8], frame: A8Frame) -> Option<A8SurfaceLayout> {
    let A8Frame { payload, end, .. } = frame;
    if end.checked_sub(payload)? < 20 {
        return None;
    }
    let data = data.get(..end)?;
    let mut at = payload.checked_add(1)?;
    let u_degree = compact_int(data, &mut at)?;
    at = at.checked_add(2)?;
    let u_count = usize::try_from(compact_int(data, &mut at)?).ok()?;
    at = consume_array_marker(data, at)?;
    let u = scan_a8_lane(data, &mut at, u_count, u_degree, end)?;
    let v_degree = compact_int(data, &mut at)?;
    at = at.checked_add(2)?;
    let v_count = usize::try_from(compact_int(data, &mut at)?).ok()?;
    at = consume_array_marker(data, at)?;
    let v = scan_a8_lane(data, &mut at, v_count, v_degree, end)?;
    let mode = *data.get(at)?;
    at += 1;
    if !(1..=9).contains(&u_degree)
        || !(1..=9).contains(&v_degree)
        || u_count < 2
        || v_count < 2
        || !matches!(mode, 0x01 | 0x05)
        || u.poles == 0
        || v.poles == 0
    {
        return None;
    }
    Some(A8SurfaceLayout {
        u_degree,
        v_degree,
        u,
        v,
        pole_start: at,
        rational: mode == 0x05,
    })
}

fn materialize_a8_lane(data: &[u8], layout: A8LaneLayout) -> Option<A8KnotLane> {
    let mut distinct = Vec::new();

    let mut at = layout.distinct_start;
    for _ in 0..layout.count {
        let value = f64_le(data, at)?;
        distinct.push(value);
        at += 8;
    }
    let mut multiplicities = Vec::new();

    at = layout.multiplicity_start;
    for _ in 0..layout.count {
        let value = compact_int(data, &mut at)?;
        multiplicities.push(value);
    }
    A8KnotLane::try_new(distinct, multiplicities)
}

fn parse_a8_surface_header(data: &[u8], frame: A8Frame) -> Option<ParsedA8SurfaceHeader> {
    data.get(frame.payload..frame.end)?;

    let layout = scan_a8_surface_layout(data, frame)?;
    let u_knots = materialize_a8_lane(data, layout.u)?;
    let v_knots = materialize_a8_lane(data, layout.v)?;
    Some(ParsedA8SurfaceHeader {
        header: A8SurfaceHeader {
            pos: frame.pos,
            object_id: frame.object_id,
            u_degree: layout.u_degree,
            v_degree: layout.v_degree,
            u_knots,
            v_knots,
            rational: layout.rational,
        },
        pole_start: layout.pole_start,
        end: frame.end,
    })
}

fn a8_surface_from_parsed(
    data: &[u8],
    parsed: ParsedA8SurfaceHeader,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<FreeformSurface>, CodecError> {
    let ParsedA8SurfaceHeader {
        header,
        mut pole_start,
        end,
    } = parsed;
    let Some(u_count) = header
        .u_count()
        .and_then(|count| usize::try_from(count).ok())
    else {
        return Ok(None);
    };
    let Some(v_count) = header
        .v_count()
        .and_then(|count| usize::try_from(count).ok())
    else {
        return Ok(None);
    };
    let A8SurfaceHeader {
        pos,
        object_id,
        u_degree,
        v_degree,
        rational,
        ..
    } = header;
    let Some(poles) = crate::nurbs_surface_control_count(u_count, v_count) else {
        return Ok(None);
    };
    let Some(pole_bytes) = poles.checked_mul(24) else {
        return Ok(None);
    };
    if pole_start
        .checked_add(pole_bytes)
        .is_none_or(|end_poles| end_poles > end)
    {
        return Ok(None);
    }
    let mut control_points = Vec::new();

    for _ in 0..poles {
        let Some(point) = f64_point(data, pole_start) else {
            return Ok(None);
        };
        control_points.push(point);
        pole_start += 24;
    }
    let weights = if rational {
        if poles
            .checked_mul(8)
            .and_then(|bytes| pole_start.checked_add(bytes))
            .is_none_or(|end_weights| end_weights > end)
        {
            return Ok(None);
        }
        let mut weights = Vec::new();

        for _ in 0..poles {
            let Some(weight) =
                f64_le(data, pole_start).and_then(|value| NonZeroReal::new(value.get()))
            else {
                return Ok(None);
            };
            weights.push(weight);
            pole_start += 8;
        }
        weights
    } else {
        Vec::new()
    };
    if data.get(pole_start..end).is_none() {
        return Ok(None);
    }

    if a8_surface_suffix_start(data, pole_start, end).is_none() {
        return Ok(None);
    }
    // The pole count is bounded by the record bytes only after the pole and
    // weight lanes are read, so the knot vectors are expanded here.
    let (u_knots, v_knots) = match header.expanded_knots() {
        Ok(knots) => knots,
        Err(error) => {
            return Ok(crate::nurbs::note_refusal(
                Err(error),
                refusal,
                format_args!("a8 NURBS surface record #{object_id} at byte {pos}"),
            ))
        }
    };
    let control_points = grid_rows(control_points, v_count)?;
    let weights = rational.then(|| grid_rows(weights, v_count)).transpose()?;
    Ok(crate::nurbs::note_refusal(
        NurbsSurface::from_checked_lanes(
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(u_degree, u_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(v_degree, v_knots, false),
            cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(control_points, weights),
            false,
        ),
        refusal,
        format_args!("a8 NURBS surface record #{object_id} at byte {pos}"),
    )
    .map(|geometry| FreeformSurface {
        pos,
        identity: Some(object_id),
        geometry,
    }))
}

fn object_stream_reference(bytes: &[u8], at: &mut usize) -> Option<u32> {
    let lead = *bytes.get(*at)?;
    let (value, width) = match lead {
        0x38 => (u32_le_24(bytes, *at + 1)?, 4),
        0x30 => (u32::from(View::u16_le_at(bytes, *at + 1)?) << 8, 3),
        0x28 => (
            u32::from(*bytes.get(*at + 1)?) | (u32::from(*bytes.get(*at + 2)?) << 16),
            3,
        ),
        0x20 => (u32::from(*bytes.get(*at + 1)?) << 16, 2),
        0x18 => (u32::from(View::u16_le_at(bytes, *at + 1)?), 3),
        0x10 => (u32::from(*bytes.get(*at + 1)?) << 8, 2),
        0x08 => (u32::from(*bytes.get(*at + 1)?), 2),
        0x80..=0xff => (u32::from(lead - 0x80), 1),
        _ => return None,
    };
    *at += width;
    Some(value)
}

fn consume_array_marker(bytes: &[u8], at: usize) -> Option<usize> {
    if *bytes.get(at)? == 0x08 {
        bytes.get(at + 1).map(|_| at + 2)
    } else {
        Some(at + 1)
    }
}

fn a5_int(byte: u8) -> Option<u32> {
    (byte % 4 == 1).then(|| u32::from((byte - 1) / 4))
}

fn a5_distinct_count(bytes: &[u8], at: &mut usize, owned: bool) -> Option<usize> {
    if owned {
        return usize::try_from(compact_int(bytes, at)?).ok();
    }
    let count = usize::try_from(a5_int(*bytes.get(*at)?)?).ok()?;
    *at += 1;
    Some(count)
}

fn a5_array_marker(bytes: &[u8], at: usize, owned: bool) -> Option<usize> {
    match bytes.get(at..at + 2) {
        Some([0x0c, ..]) => Some(at + 1),
        Some([0x08, 0x05 | 0x09 | 0x0d | 0x11 | 0x15]) => Some(at + 2),
        Some([0x08, 0x19]) if owned => Some(at + 2),
        _ => None,
    }
}

fn a5_distinct_values(bytes: &[u8], at: &mut usize, count: usize, end: usize) -> Option<Vec<f64>> {
    if count
        .checked_mul(8)
        .and_then(|width| at.checked_add(width))
        .is_none_or(|last| last > end)
    {
        return None;
    }
    let mut values = Vec::new();

    for _ in 0..count {
        let value = f64_le(bytes, *at)?;
        values.push(value.get());
        *at += 8;
    }
    Some(values)
}

fn a5_knots(distinct: &[f64], degree: u32) -> Option<(Vec<f64>, u32)> {
    let (endpoint, interior) = match degree {
        degree if degree > 0 && distinct.len() == 2 => (degree.checked_add(1)?, 1u32),
        1 | 3 if distinct.len() >= 2 => (degree + 1, 1u32),
        5 if distinct.len() >= 2 => (6u32, 3u32),
        _ => return None,
    };
    let mut multiplicities = Vec::new();
    multiplicities.push(endpoint);
    multiplicities.extend(std::iter::repeat_with(|| interior).take(distinct.len() - 2));
    multiplicities.push(endpoint);
    let expanded_count = multiplicities
        .iter()
        .map(|&value| index_from_u32(value))
        .sum::<usize>();
    let count = u32::try_from(expanded_count.checked_sub(index_from_u32(degree) + 1)?).ok()?;
    let mut knots = Vec::new();
    for (&knot, &multiplicity) in distinct.iter().zip(&multiplicities) {
        knots.extend(std::iter::repeat_with(|| knot).take(index_from_u32(multiplicity)));
    }
    Some((knots, count))
}

fn a5_weights(
    bytes: &[u8],
    at: &mut usize,
    rows: usize,
    cols: usize,
    end: usize,
) -> Option<Vec<NonZeroReal>> {
    let count = rows.checked_mul(cols)?;
    if bytes.get(*at) == Some(&0x00) {
        *at += 1;
        if count
            .checked_mul(8)
            .and_then(|width| at.checked_add(width))
            .is_none_or(|last| last > end)
        {
            return None;
        }
        let mut weights = Vec::new();

        for _ in 0..count {
            let weight = f64_le(bytes, *at).and_then(|value| NonZeroReal::new(value.get()))?;
            weights.push(weight);
            *at += 8;
        }
        return Some(weights);
    }
    if bytes.get(*at) != Some(&0x01) {
        return None;
    }
    let seed_count = cols.div_ceil(2);
    let mut weights = Vec::new();

    for _ in 0..rows {
        if bytes.get(*at) == Some(&0x02) {
            *at += 1;
            let previous_start = weights.len().checked_sub(cols)?;

            for index in 0..cols {
                let value = weights[previous_start + index];
                weights.push(value);
            }
            continue;
        }
        if !matches!(bytes.get(*at..*at + 3), Some([0x01, 0x03 | 0x07, 0x00])) {
            return None;
        }
        *at += 3;
        if seed_count
            .checked_mul(8)
            .and_then(|width| at.checked_add(width))
            .is_none_or(|last| last > end)
        {
            return None;
        }
        let row_start = weights.len();

        for _ in 0..seed_count {
            let weight = f64_le(bytes, *at).and_then(|value| NonZeroReal::new(value.get()))?;
            weights.push(weight);
            *at += 8;
        }

        for offset in (0..cols / 2).rev() {
            weights.push(weights[row_start + offset]);
        }
        if weights.len() != row_start + cols {
            return None;
        }
    }
    Some(weights)
}

#[cfg(test)]
mod tests;
