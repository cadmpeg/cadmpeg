// SPDX-License-Identifier: Apache-2.0
//! B2/B3/B4-family consolidated record vocabulary.
//!
//! Decodes analytic circle, cylinder, cone, and revolution charts, offset and
//! construction-use supports, class-`0x5e`/`0x62` owner and link records,
//! parameter-space packets, consolidated plane carriers, and consolidated UV
//! pcurves.

#[cfg(test)]
use crate::wire::records::ConsolidatedPcurve;
use cadmpeg_core::decode::View;
use cadmpeg_core::CodecError;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::analytic::ConeSurface;
use cadmpeg_ir::geometry::{nurbs::NurbsCurve, SolvedSurfaceGeometry, SurfaceGeometry};
use cadmpeg_ir::math::{Point3, Vector3};
use cadmpeg_ir::scalar::{
    Angle, FiniteReal, NonNegativeLength, NonZeroLength, NonZeroReal, PositiveLength, PositiveReal,
};
use cadmpeg_ir::topology::IncreasingParameterInterval;
use cadmpeg_ir::units::{FiniteVector, OrthonormalFrame3};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::mem::size_of;

use crate::analytic::{periodic_angular_range_is_valid, sphere_angular_ranges_are_valid};
use crate::checked::{
    ExactDeviation, ExactHypotUnitVector3, ExactNormUnitVector3, ExactUnitVector3, HypotLength,
    RelaxedDeviation, RelaxedUnitVector2, RelaxedUnitVector3, SquaredLength, UnitFrame3,
};
use crate::families::a5a8::records::FreeformSurface;
use crate::native::owner_chart::{CatiaOwnerChartMiddleControl, CatiaOwnerChartTerminalControl};
use crate::native::owner_numeric_tail::CatiaOwnerNumericTail;
use crate::wire::bytes::persistent_ref;
use crate::wire::bytes::{
    allocation_reference, compact_int, f64_le, f64_point, finite_f64_lane, read_f64_array,
    u32_le_24, AllocationReferenceEncoding,
};
use crate::wire::compact_unsigned::CompactUnsigned;
#[cfg(test)]
use crate::wire::records::{b_family_frames, consolidated_records};
use crate::wire::records::{
    family_frames_from_records, records_are_contiguous, ConsolidatedFamily, ConsolidatedFrame,
    ConsolidatedFrameFlag, ConsolidatedFrameWidth, ConsolidatedRawFrame, ConsolidatedRecord,
};

const EPS_B2_RECORD_COARSE_GEOMETRY: f64 = 1.0e-6;
const EPS_B2_RECORD_EXACT_GEOMETRY: f64 = 1.0e-12;
const EPS_PARAMETER_LINE: f64 = 1.0e-12;
pub(crate) const B2_SINGLE_CHILD_ALLOCATION_PAYLOAD: &[u8; 4] = &[0x81, 0x03, 0x05, 0x0d];

/// Offset-surface constructor stored in a `b2 03 31` support record or a
/// kind-`0x01` `b2 03 30` construction-use record.
#[derive(Debug, Clone)]
pub(in crate::families) struct B2OffsetSupport {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Referenced carrier-surface identifier.
    pub(in crate::families) support_id: u32,
    /// Signed normal offset distance in millimetres.
    pub(in crate::families) distance: FiniteReal,
    /// Carrier U sub-interval.
    pub(in crate::families) u_range: IncreasingParameterInterval,
    /// Carrier V sub-interval.
    pub(in crate::families) v_range: IncreasingParameterInterval,
}

/// Parameter-space data stored in a `b2/b3/b4 03 18` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2ParameterPoint {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Exclusive end of the complete framed record.
    pub(crate) end: usize,
    /// Source-local representation operand with its compact encoding.
    pub(crate) operand: CompactUnsigned,
    /// Scalar control immediately following the operand.
    pub(crate) control: u8,
    /// Layout-specific finite scalar lane.
    pub(crate) payload: B2ParameterPointPayload,
}

impl B2ParameterPoint {
    pub(in crate::families) fn axis_line(&self) -> Option<[[f64; 2]; 2]> {
        let axis = self.control & 3;
        if self.control >= 0x20 || !matches!(axis, 1 | 2) {
            return None;
        }
        let (scalars, count) = self.payload.scalars();
        let mut values = scalars.get(..count)?.iter().copied();
        let [fixed, first, last] = [0x10, 0x04, 0x08].map(|mask| {
            if self.control & mask == 0 {
                values.next()
            } else {
                Some(0.0)
            }
        });
        let (fixed, first, last) = (fixed?, first?, last?);
        if first == last {
            return None;
        }
        Some(if axis == 1 {
            [[fixed, first], [fixed, last]]
        } else {
            [[first, fixed], [last, fixed]]
        })
    }
}

/// Layout-specific scalar lane of a class-`0x18` parameter-space record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub(crate) enum B2ParameterPointPayload {
    /// One retained scalar after two zero tuple fields are elided.
    Scalar {
        /// Stored scalar.
        value: FiniteReal,
    },
    /// Two stored scalars in source order.
    TwoScalars {
        /// Ordered finite scalar lane.
        values: FiniteVector<2>,
    },
    /// Three stored scalars in source order.
    ThreeScalars {
        /// Ordered finite scalar lane.
        values: FiniteVector<3>,
    },
    /// Unsplit five-scalar layout.
    FiveScalars {
        /// Stored scalar payload.
        values: FiniteVector<5>,
    },
}

impl B2ParameterPointPayload {
    pub(crate) const fn byte_len(&self, operand: CompactUnsigned) -> u8 {
        let count = match self {
            Self::Scalar { .. } => 1,
            Self::TwoScalars { .. } => 2,
            Self::ThreeScalars { .. } => 3,
            Self::FiveScalars { .. } => 5,
        };
        operand.byte_len() + 1 + 8 * count
    }

    pub(in crate::families::b2) fn scalars(&self) -> ([f64; 5], usize) {
        match self {
            Self::Scalar { value } => ([value.get(), 0.0, 0.0, 0.0, 0.0], 1),
            Self::TwoScalars { values } => ([values[0], values[1], 0.0, 0.0, 0.0], 2),
            Self::ThreeScalars { values } => ([values[0], values[1], values[2], 0.0, 0.0], 3),
            Self::FiveScalars { values } => {
                ([values[0], values[1], values[2], values[3], values[4]], 5)
            }
        }
    }

    /// Whether the scalar count and direction satisfy the stored control.
    pub(crate) fn matches_control(&self, control: u8) -> bool {
        let (values, len) = self.scalars();
        match control {
            0x08 => {
                len == 5
                    && values[0] < 0.0
                    && (values[3].hypot(values[4]) - 1.0).abs() <= EPS_PARAMETER_LINE
            }
            0x48 | 0x88 => len == 3 && values[0] < 0.0,
            control if control < 0x20 && matches!(control & 3, 1 | 2) => {
                usize::try_from((control & 0x1c).count_ones())
                    .is_ok_and(|omitted| len + omitted == 3)
            }
            _ => false,
        }
    }
}

/// Stored scalar layout of a consolidated class-`0x27` plane.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum B2PlaneCarrierLayout {
    /// Point and bounds; U is implicit +X.
    ImplicitX,
    /// Point, stored U-X component, and bounds; U-Y is zero.
    DirectionX,
    /// Point, both stored XY components of U, and bounds.
    DirectionXY,
    /// Point and bounds; U is implicit +Y.
    ImplicitY,
    /// Point, stored U-Y component, and bounds; U-X is zero.
    DirectionY,
    /// Origin XYZ and bounds; U is implicit +Y.
    SpatialImplicitY,
}

impl B2PlaneCarrierLayout {
    pub(crate) const fn scalar_count(self) -> usize {
        match self {
            Self::ImplicitX | Self::ImplicitY => 6,
            Self::DirectionX | Self::DirectionY | Self::SpatialImplicitY => 7,
            Self::DirectionXY => 8,
        }
    }

    fn admits_direction(self, [x, y, z]: [f64; 3]) -> bool {
        z == 0.0
            && match self {
                Self::ImplicitX => x == 1.0 && y == 0.0,
                Self::ImplicitY | Self::SpatialImplicitY => x == 0.0 && y == 1.0,
                Self::DirectionX => y == 0.0,
                Self::DirectionY => x == 0.0,
                Self::DirectionXY => true,
            }
    }
}

impl From<B2PlaneCarrierLayout> for u8 {
    fn from(value: B2PlaneCarrierLayout) -> Self {
        match value {
            B2PlaneCarrierLayout::ImplicitX => 0xec,
            B2PlaneCarrierLayout::DirectionX => 0xe4,
            B2PlaneCarrierLayout::DirectionXY => 0xc4,
            B2PlaneCarrierLayout::ImplicitY => 0xdc,
            B2PlaneCarrierLayout::DirectionY => 0xd4,
            B2PlaneCarrierLayout::SpatialImplicitY => 0xd8,
        }
    }
}

impl TryFrom<u8> for B2PlaneCarrierLayout {
    type Error = String;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0xec => Ok(Self::ImplicitX),
            0xe4 => Ok(Self::DirectionX),
            0xc4 => Ok(Self::DirectionXY),
            0xdc => Ok(Self::ImplicitY),
            0xd4 => Ok(Self::DirectionY),
            0xd8 => Ok(Self::SpatialImplicitY),
            other => Err(format!("unknown plane selector {other:#04x}")),
        }
    }
}

/// Exact stored plane chart or an unclassified finite scalar lane.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub(crate) enum B2PlaneCarrierPayload {
    /// Point, unit U direction and increasing parameter bounds.
    Plane {
        /// Source scalar layout; omitted direction components are implicit.
        layout: B2PlaneCarrierLayout,
        /// Stored XY point; model-space Z is zero for planar XY layouts.
        point: FiniteVector<2>,
        /// Stored or implicit horizontal U direction.
        direction: ExactHypotUnitVector3,
        /// Stored U bounds.
        u_range: IncreasingParameterInterval,
        /// Stored V bounds; V is global +Z.
        v_range: IncreasingParameterInterval,
        /// Stored origin Z coordinate when present on the selector.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        origin_z: Option<FiniteReal>,
    },
    /// Complete finite lane for an unassigned selector.
    ScalarLane {
        /// Source selector, carried separately by the native record wire view.
        #[serde(skip, default)]
        selector: u8,
        /// Complete source-order scalar lane.
        values: Vec<FiniteReal>,
    },
}

impl B2PlaneCarrierPayload {
    pub(crate) fn selector(&self) -> u8 {
        match self {
            Self::Plane { layout, .. } => u8::from(*layout),
            Self::ScalarLane { selector, .. } => *selector,
        }
    }

    pub(crate) fn valid_plane(&self) -> bool {
        match self {
            Self::Plane {
                layout,
                direction,
                origin_z,
                ..
            } => {
                if *layout == B2PlaneCarrierLayout::SpatialImplicitY {
                    origin_z.is_some() && layout.admits_direction(direction.get())
                } else {
                    origin_z.is_none() && layout.admits_direction(direction.get())
                }
            }
            Self::ScalarLane { .. } => false,
        }
    }
}

/// One complete consolidated `b2/b3/b4 03 27` plane-carrier record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2PlaneCarrier {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Exclusive end of the complete framed record.
    pub(crate) end: usize,
    /// Header-token width in bytes.
    pub(crate) width: ConsolidatedFrameWidth,
    /// Independent frame flag.
    pub(crate) flag: ConsolidatedFrameFlag,
    /// Width-coded frame header token.
    pub(crate) header_token: u32,
    /// Selector-specific finite scalar payload.
    pub(crate) payload: B2PlaneCarrierPayload,
}

/// Persistent-tag reference list stored in a `b2/b3/b4 03 37` record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct B2ReferenceList {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Compact persistent-tag references in serialization order.
    pub(crate) references: Vec<u32>,
}

/// Nine-reference owner packet stored in a `b2/b3/b4 03 62` record with a
/// structurally decoded numeric tail.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2OwnerPacket {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Zero-based bounded record-source ordinal.
    pub(crate) source_index: usize,
    /// Width-coded header token.
    pub(crate) header_token: u32,
    /// Reference grammar selected by the complete fixed-nine reference lane.
    pub(crate) reference_encoding: B2OwnerReferenceEncoding,
    /// Nine compact persistent identities following the `0x89` count.
    pub(crate) references: [u32; 9],
    /// Exact wire addressing form of each identity in source order.
    pub(crate) identity_encodings: [B2OwnerIdentityEncoding; 9],
    /// Fixed-width class-specific numeric tail.
    pub(crate) numeric_tail: CatiaOwnerNumericTail,
}

/// One fixed-nine owner identity resolved by its backward-distance token.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct B2OwnerIdentityTarget {
    /// Owning class-`0x62` packet offset.
    pub(crate) owner_pos: usize,
    /// Zero-based bounded record-source ordinal.
    pub(crate) source_index: usize,
    /// Zero-based identity slot in the fixed-nine packet.
    pub(crate) slot: u8,
    /// Decoded backward distance.
    pub(crate) distance: u32,
    /// Selected class-`0x5d` or class-`0x5e` record offset.
    pub(crate) target_pos: usize,
    /// Selected record class.
    pub(crate) target_class: crate::native::CatiaOwnerIdentityClass,
}

/// One fixed-nine identity that resolves to a closed owner-boundary edge.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct B2OwnerBoundaryEdge {
    /// Identity slot in the fixed-nine packet.
    pub(crate) slot: u8,
    /// Resolved class-`0x5e` edge-record offset.
    pub(crate) target_pos: usize,
    /// Resolved class-`0x5d` endpoint-record offsets, in edge order.
    pub(crate) endpoint_records: [usize; 2],
}

/// Carrier production that opens a fixed owner chart.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum B2OwnerChartCarrier {
    /// B-family class-`0x28` cylinder carrier.
    B28,
    /// B-family class-`0x2b` torus carrier.
    B2b,
    /// A-family class-`0x32` carrier.
    A32,
}

/// One allocation-local reference in a class-`0x37` owner-chart bridge.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct B2OwnerChartBridgeReference {
    /// Decoded allocation-local value.
    pub(crate) value: u32,
    /// Wire addressing form retained from the allocation-reference token.
    pub(crate) encoding: AllocationReferenceEncoding,
}

/// Structurally complete class-`0x37` owner-chart bridge.
#[derive(Debug, Clone, PartialEq)]
pub(crate) enum B2OwnerChartBridge {
    /// Five-reference supported-surface construction.
    SupportedSurface {
        /// Record byte offset.
        pos: usize,
        /// Constructed carrier surface.
        carrier_surface: B2OwnerChartBridgeReference,
        /// Two supporting surfaces.
        support_surfaces: [B2OwnerChartBridgeReference; 2],
        /// Pcurves on the two supporting surfaces.
        support_pcurves: [B2OwnerChartBridgeReference; 2],
        /// Independent middle construction controls.
        middle_controls: [CatiaOwnerChartMiddleControl; 2],
        /// Independent terminal control.
        terminal_control: CatiaOwnerChartTerminalControl,
        /// Positive construction radius.
        construction_radius: PositiveLength,
    },
    /// Eight-reference A-family production without an assigned object role.
    Extended {
        /// Record byte offset.
        pos: usize,
        /// Counted allocation references in storage order.
        references: [B2OwnerChartBridgeReference; 8],
    },
}

/// A rolling-ball construction whose five source-local references resolve to
/// its carrier, support surfaces, and support pcurves.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2RollingBallConstruction {
    pub(crate) pos: usize,
    pub(crate) source_index: usize,
    pub(crate) carrier_pos: usize,
    pub(crate) support_surface_positions: [usize; 2],
    pub(crate) support_pcurve_positions: [usize; 2],
    pub(crate) middle_controls: [CatiaOwnerChartMiddleControl; 2],
    pub(crate) terminal_control: CatiaOwnerChartTerminalControl,
    pub(crate) construction_radius: PositiveLength,
}

/// One source-closed carrier chart terminated by a fixed-nine owner packet.
///
/// The relation is admitted only when the four ordered class-`0x18` records
/// reproduce the owner's complete parameter rectangle.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2OwnerChart {
    /// Fixed-nine owner packet offset.
    pub(crate) owner_pos: usize,
    /// Zero-based bounded record-source ordinal.
    pub(crate) source_index: usize,
    /// Carrier record offset.
    pub(crate) carrier_pos: usize,
    /// Family-and-class carrier production.
    pub(crate) carrier: B2OwnerChartCarrier,
    /// Immediately following class-`0x37` bridge record.
    pub(crate) bridge: B2OwnerChartBridge,
    parameter_points: [usize; 4],
}

impl B2OwnerChart {
    /// Parameter point offsets in selector-prefix order.
    pub(crate) fn parameter_point_offsets(&self) -> [usize; 4] {
        self.parameter_points
    }
}

/// Count-framed class-`0x62` owner record with a class-specific tail.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct B2CountedOwner {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Zero-based bounded record-source ordinal.
    pub(crate) source_index: usize,
    /// Width-coded header token.
    pub(crate) header_token: u32,
    /// Persistent identities selected by the leading `0x80+n` count.
    pub(crate) references: Vec<u32>,
    /// Addressing form of each count-selected reference.
    pub(crate) reference_encodings: Vec<AllocationReferenceEncoding>,
    /// Nonempty class-specific bytes after the reference lane.
    pub(crate) tail: super::counted_owner_tail::CountedOwnerTail,
}

/// Reference dialect used by a nine-reference class-`0x62` owner packet.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum B2OwnerReferenceEncoding {
    /// Strong identities use `0x0a <u16le>` and weak identities use compact integers.
    TaggedU16Strong,
    /// Strong identities use width-coded compact integers and weak identities
    /// are raw one-byte values.
    WidthCodedStrong,
    /// All nine identities use the compact-integer reference grammar.
    AllCompact,
}

/// Wire addressing form of one identity in a fixed-nine owner packet.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum B2OwnerIdentityEncoding {
    /// One token from the allocation-reference grammar.
    Allocation(AllocationReferenceEncoding),
    /// Raw one-byte weak identity in the width-coded alternating dialect.
    RawU8,
}

/// Structurally complete consolidated class-`0x5b` or class-`0x5c` record.
///
/// The complete payload is retained as an opaque body. No field role is
/// assigned until a source-closed relation establishes one.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct B2Class5b5cRecord {
    /// Framed record.
    pub(crate) frame: ConsolidatedRawFrame,
    /// Zero-based bounded record-source ordinal.
    pub(crate) source_index: usize,
    /// Logical offset within the bounded record source.
    pub(crate) source_offset: usize,
    /// Record class.
    pub(crate) class: crate::native::class5b5c::CatiaClass5b5c,
}

/// Target encoding of a structurally complete class-`0x5f` node.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum B2FaceNode5fTargetEncoding {
    /// Width-coded compact target.
    Compact,
    /// Zero-based ordinal in the face node's owned allocation.
    OwnedChild,
    /// Strong persistent target encoded as `0x0a <u16le>`.
    TaggedU16Strong,
}

/// Structurally complete class-`0x5f` node.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct B2FaceNode5f {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Width-coded header token.
    pub(crate) header_token: u32,
    /// Target encoding selected after the `0x82` lead.
    pub(crate) target_encoding: B2FaceNode5fTargetEncoding,
    /// Persistent target between the `0x82` lead and the terminal pair.
    pub(crate) target: u32,
    /// Two terminal bytes that exhaust the complete payload.
    pub(crate) terminal: [u8; 2],
}

/// Derived adjacent class-`0x5f` node and class-`0x62` packet relation.
///
/// This relation retains source adjacency and the successor identity. It does
/// not assign a higher-level object or allocation role to either record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2AdjacentFaceOwner {
    /// Class-`0x5f` node immediately preceding the class-`0x62` packet.
    pub(crate) face_node: B2FaceNode5f,
    /// Nine-reference owner packet.
    pub(crate) owner: B2OwnerPacket,
}

/// Derived adjacent class-`0x5f` node and count-framed class-`0x62` packet
/// relation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct B2AdjacentFaceCountedOwner {
    /// Class-`0x5f` node immediately preceding the class-`0x62` packet.
    pub(crate) face_node: B2FaceNode5f,
    /// Count-framed owner packet.
    pub(crate) owner: B2CountedOwner,
}

/// Settled terminal sense code in a class-`0x06` consolidated use record.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum B2UseSense {
    /// Terminal byte `0x84`.
    Sense84,
    /// Terminal byte `0x88`.
    Sense88,
}

/// Closed payload grammar of a class-`0x06` consolidated use record.
#[derive(Debug, Clone, PartialEq, Eq)]
enum B2UsePayload {
    /// Compact references and a terminal sense that exhaust the payload.
    Closed {
        sense: B2UseSense,
        references: Vec<u32>,
    },
    /// Terminal sense without a closed compact-reference lane.
    SenseOnly(B2UseSense),
    /// Payload that does not end in a settled sense.
    Opaque,
}

/// Byte-level metadata from a class-`0x06` consolidated use record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct B2UseMetadata {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Complete payload bytes.
    pub(super) payload: Vec<u8>,
    /// Closed payload grammar.
    kind: B2UsePayload,
}

impl B2UseMetadata {
    pub(crate) fn sense(&self) -> Option<B2UseSense> {
        match self.kind {
            B2UsePayload::Closed { sense, .. } | B2UsePayload::SenseOnly(sense) => Some(sense),
            B2UsePayload::Opaque => None,
        }
    }

    pub(crate) fn references(&self) -> Option<&[u32]> {
        match &self.kind {
            B2UsePayload::Closed { references, .. } => Some(references.as_slice()),
            B2UsePayload::SenseOnly(_) | B2UsePayload::Opaque => None,
        }
    }
}

/// Byte-level metadata from a class-`0x5e` consolidated record.
#[derive(Debug, Clone, PartialEq, Eq)]
#[cfg(test)]
struct B2EdgeMetadata {
    /// Record byte offset.
    pos: usize,
    /// Complete payload bytes.
    pub(super) payload: Vec<u8>,
    /// Values carried by each `0x0a <u16le>` reference token.
    pub(super) references: Vec<u16>,
}

/// Structurally decoded width-coded class-`0x5e` edge node.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct B2EdgeNode {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Width-coded header token following the payload length.
    pub(crate) header_token: u32,
    /// Allocation-local curve-support reference terminating the use chain.
    pub(crate) curve_ref: u32,
    /// Native start-vertex identity.
    pub(crate) start_vertex_ref: u32,
    /// Native end-vertex identity.
    pub(crate) end_vertex_ref: u32,
    /// Allocation-local start-parameter selector.
    pub(crate) start_parameter_ref: u32,
    /// Allocation-local end-parameter selector.
    pub(crate) end_parameter_ref: u32,
    /// Addressing forms of the five references in payload order.
    pub(crate) reference_encodings: [AllocationReferenceEncoding; 5],
    /// Decoded value of the one-byte terminal allocation reference.
    pub(crate) terminal_value: u32,
    /// Wire addressing form of the terminal allocation reference.
    pub(crate) terminal_encoding: AllocationReferenceEncoding,
    /// Terminal byte following the five references.
    pub(crate) tail: u8,
}

/// Decode class-`0x06` payloads and their settled terminal sense codes.
#[must_use]
#[cfg(test)]
pub(in crate::families) fn b2_use_metadata(data: &[u8]) -> Vec<B2UseMetadata> {
    let records = consolidated_records(data);
    b2_use_metadata_from_records(data, &records)
}

pub(in crate::families) fn b2_use_metadata_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2UseMetadata> {
    let mut uses = Vec::new();
    for frame in family_frames_from_records(records, ConsolidatedFamily::B, 0x06) {
        let payload = data[frame.payload..frame.end].to_vec();
        let sense = match payload.last() {
            Some(0x84) => Some(B2UseSense::Sense84),
            Some(0x88) => Some(B2UseSense::Sense88),
            _ => None,
        };
        let kind = match sense {
            None => B2UsePayload::Opaque,
            Some(sense) => {
                let references = if let Some((end, count)) = frame.end.checked_sub(1).zip(
                    data.get(frame.payload)
                        .and_then(|byte| byte.checked_sub(0x80)),
                ) {
                    let count = usize::from(count);
                    let mut at = frame.payload + 1;
                    let mut parsed = [0u32; 127];
                    let mut valid = true;
                    for value in parsed.iter_mut().take(count) {
                        let Some(reference) = compact_int(data, &mut at) else {
                            valid = false;
                            break;
                        };
                        *value = reference;
                    }
                    if valid && at == end {
                        Some(parsed[..count].to_vec())
                    } else {
                        None
                    }
                } else {
                    None
                };
                match references {
                    Some(references) => B2UsePayload::Closed { sense, references },
                    None => B2UsePayload::SenseOnly(sense),
                }
            }
        };
        uses.push(B2UseMetadata {
            pos: frame.pos,
            payload,
            kind,
        });
    }
    uses
}

/// Decode class-`0x5e` payloads and their `0x0a <u16le>` reference tokens.
#[must_use]
#[cfg(test)]
fn b2_edge_metadata(data: &[u8]) -> Vec<B2EdgeMetadata> {
    b_family_frames(data, 0x5e)
        .into_iter()
        .map(|frame| {
            let payload = data[frame.payload..frame.end].to_vec();
            let mut references = Vec::new();
            let mut at = 0;
            while at < payload.len() {
                if let Some(value) = payload
                    .get(at)
                    .copied()
                    .filter(|byte| *byte == 0x0a)
                    .and_then(|_| View::u16_le_at(&payload, at + 1))
                {
                    references.push(value);
                    at += 3;
                } else {
                    at += 1;
                }
            }
            B2EdgeMetadata {
                pos: frame.pos,
                payload,
                references,
            }
        })
        .collect()
}

/// Decode length-closed `b2/b3/b4 03 5e` records containing five
/// allocation-local references and one terminal byte.
#[must_use]
#[cfg(test)]
pub(in crate::families) fn b2_edge_nodes(data: &[u8]) -> Vec<B2EdgeNode> {
    let records = consolidated_records(data);
    b2_edge_nodes_from_records(data, &records).collect()
}

pub(crate) fn b2_edge_nodes_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2EdgeNode> + 'a {
    edge_nodes(data, records, false)
}

pub(in crate::families) fn owned_edge_nodes<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2EdgeNode> + 'a {
    edge_nodes(data, records, true)
}

fn edge_nodes<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
    owned: bool,
) -> impl Iterator<Item = B2EdgeNode> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x5e).filter_map(move |frame| {
        let token_start = frame.pos.checked_add(4)?;
        let mut token_end = token_start;
        let header_value = compact_int(data, &mut token_end)?;
        let canonical_token_width = match header_value {
            0..=0x3f => 1,
            0x40..=0xff => 2,
            0x100..=0xffff => 3,
            _ if owned => 4,
            _ => 3,
        };
        if token_end != frame.payload
            || frame.payload.checked_sub(token_start)? != canonical_token_width
        {
            return None;
        }
        let mut at = frame.payload;
        let references = [
            allocation_reference(data, &mut at)?,
            allocation_reference(data, &mut at)?,
            allocation_reference(data, &mut at)?,
            allocation_reference(data, &mut at)?,
            allocation_reference(data, &mut at)?,
        ];
        let [curve_ref, start_vertex_ref, end_vertex_ref, start_parameter_ref, end_parameter_ref] =
            references.map(|reference| reference.value);
        let reference_encodings = references.map(|reference| reference.encoding);
        let terminal_at = at;
        let tail = *data.get(terminal_at)?;
        let terminal = allocation_reference(data, &mut at)?;
        let terminal_allowed = at == frame.end
            && at == terminal_at + 1
            && (matches!(
                (terminal.encoding, terminal.value),
                (
                    AllocationReferenceEncoding::BackwardDistance,
                    0 | 8 | 9 | 10
                ) | (AllocationReferenceEncoding::Selector2, 0 | 8 | 10)
            ) || owned
                && matches!(
                    (terminal.encoding, terminal.value),
                    (AllocationReferenceEncoding::Selector2, 4 | 6)
                ));
        terminal_allowed.then_some(B2EdgeNode {
            pos: frame.pos,
            header_token: frame.header_token,
            curve_ref,
            start_vertex_ref,
            end_vertex_ref,
            start_parameter_ref,
            end_parameter_ref,
            reference_encodings,
            terminal_value: terminal.value,
            terminal_encoding: terminal.encoding,
            tail,
        })
    })
}

pub(crate) fn b2_two_edge_owner_relation(
    data: &[u8],
    owner: &ConsolidatedRecord,
    edges: &[B2EdgeNode],
) -> Option<bool> {
    let [first, second] = edges else { return None };
    if owner.family() != ConsolidatedFamily::B || owner.class() != 0x62 {
        return None;
    }
    let payload = owner.payload()?;
    let mut view = View::over_retained(data).child(payload.start, payload.end)?;
    view.skip(4)?;
    let token = view.u8()?;
    if token & 3 != 3 {
        return None;
    }
    for edge in edges {
        for encoding in &edge.reference_encodings[1..3] {
            if !matches!(
                encoding,
                AllocationReferenceEncoding::BackwardDistance
                    | AllocationReferenceEncoding::OwnedChild
            ) {
                return None;
            }
        }
    }
    let complement = u32::from(token >> 2).checked_sub(1)?;
    two_edge_complement_relation(
        complement,
        [first.start_vertex_ref, first.end_vertex_ref],
        [second.start_vertex_ref, second.end_vertex_ref],
    )
}

fn two_edge_complement_relation(
    complement: u32,
    first: [u32; 2],
    second: [u32; 2],
) -> Option<bool> {
    let same = first[0].checked_add(second[0]) == Some(complement)
        && first[1].checked_add(second[1]) == Some(complement);
    let opposite = first[0].checked_add(second[1]) == Some(complement)
        && first[1].checked_add(second[0]) == Some(complement);
    (same != opposite).then_some(same)
}

/// Decode `b2/b3/b4 03 37` compact reference lists with their unit tail.
#[must_use]
#[cfg(test)]
fn b2_reference_lists(data: &[u8]) -> Vec<B2ReferenceList> {
    let records = consolidated_records(data);
    b2_reference_lists_from_records(data, &records)
}

pub(crate) fn b2_reference_lists_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2ReferenceList> {
    let mut lists = Vec::new();
    for frame in family_frames_from_records(records, ConsolidatedFamily::B, 0x37) {
        if frame.header_token != 5
            || !matches!(frame.end - frame.payload, 0x22 | 0x24 | 0x26)
            || frame.end.checked_sub(8).and_then(|at| f64_le(data, at)) != Some(FiniteReal::ONE)
        {
            continue;
        }
        let refs_end = frame.end - 8;
        let mut at = frame.payload;
        let mut references = Vec::new();
        let mut valid = true;
        while at < refs_end {
            let Some(reference) = compact_int(data, &mut at) else {
                valid = false;
                break;
            };
            references.push(reference);
        }
        if valid && at == refs_end {
            lists.push(B2ReferenceList {
                pos: frame.pos,
                references,
            });
        }
    }
    lists
}

/// Decode class-`0x62` owner packets whose leading count fixes the persistent
/// reference lane and leaves a nonempty class-specific tail.
#[must_use]
#[cfg(test)]
fn b2_counted_owners(data: &[u8]) -> Vec<B2CountedOwner> {
    let records = consolidated_records(data);
    b2_counted_owners_from_records(data, &records)
}

pub(crate) fn b2_counted_owners_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2CountedOwner> {
    let mut owners = Vec::new();
    for (frame, source_index) in b2_owner_frames(records) {
        if b2_owner_packet_from_frame(data, frame, source_index).is_some() {
            continue;
        }
        let Some(count) = data
            .get(frame.payload)
            .and_then(|lead| lead.checked_sub(0x80))
        else {
            continue;
        };
        if count == 0 {
            continue;
        }
        let mut at = frame.payload + 1;
        let mut references = Vec::new();
        let mut reference_encodings = Vec::new();
        let mut valid = true;
        for _ in 0..count {
            let Some(reference) = allocation_reference(data, &mut at) else {
                valid = false;
                break;
            };
            references.push(reference.value);
            reference_encodings.push(reference.encoding);
        }
        if !valid || at >= frame.end {
            continue;
        }
        let Some(tail) =
            super::counted_owner_tail::CountedOwnerTail::new(data[at..frame.end].to_vec())
        else {
            continue;
        };
        owners.push(B2CountedOwner {
            pos: frame.pos,
            source_index,
            header_token: frame.header_token,
            references,
            reference_encodings,
            tail,
        });
    }
    owners
}

/// Decode fixed-nine class-`0x62` owner packets whose references and numeric
/// tail consume the complete frame.
#[must_use]
#[cfg(test)]
fn b2_owner_packets(data: &[u8]) -> Vec<B2OwnerPacket> {
    let records = consolidated_records(data);
    b2_owner_packets_from_records(data, &records).collect()
}

pub(crate) fn b2_owner_packets_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2OwnerPacket> + 'a {
    b2_owner_frames(records)
        .filter_map(|(frame, source_index)| b2_owner_packet_from_frame(data, frame, source_index))
}

/// Decode exactly one fixed-nine reference dialect from a complete payload.
pub(crate) fn b2_owner_packet_from_frame(
    data: &[u8],
    frame: ConsolidatedFrame,
    source_index: usize,
) -> Option<B2OwnerPacket> {
    let mut candidates = [
        B2OwnerReferenceEncoding::TaggedU16Strong,
        B2OwnerReferenceEncoding::WidthCodedStrong,
        B2OwnerReferenceEncoding::AllCompact,
    ]
    .into_iter()
    .filter_map(|encoding| b2_fixed_owner_packet(data, frame, source_index, encoding));
    let packet = candidates.next()?;
    candidates.next().is_none().then_some(packet)
}

/// Resolve backward-distance identities in fixed-nine owner packets within
/// one contiguous record source and its local class-`0x5d`/`0x5e` allocation
/// sequence. The explicit class-`0x65` group separator starts a new
/// allocation sequence even when its frame is physically contiguous.
pub(crate) fn b2_owner_identity_targets_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2OwnerIdentityTarget> {
    let mut packets = BTreeMap::new();
    for packet in b2_owner_packets_from_records(data, records) {
        packets.insert((packet.source_index, packet.pos), packet);
    }
    let mut allocation = Vec::<usize>::new();
    let mut targets = Vec::new();
    for (index, record) in records.iter().enumerate() {
        if index > 0 && !crate::wire::records::records_are_contiguous(&records[index - 1..=index]) {
            allocation.clear();
        }
        if record.family() == crate::wire::records::ConsolidatedFamily::B
            && record.class() == 0x65
            && record
                .payload()
                .and_then(|payload| data.get(payload))
                .is_some_and(|payload| payload == B2_SINGLE_CHILD_ALLOCATION_PAYLOAD.as_slice())
        {
            allocation.clear();
            continue;
        }
        if record.family() == crate::wire::records::ConsolidatedFamily::B
            && matches!(record.class(), 0x5d | 0x5e)
        {
            allocation.push(index);
        }
        let Some(packet) = packets.get(&(record.source_index(), record.byte_offset())) else {
            continue;
        };
        for (slot, (distance, encoding)) in (0u8..).zip(
            packet
                .references
                .iter()
                .copied()
                .zip(packet.identity_encodings),
        ) {
            if encoding
                != B2OwnerIdentityEncoding::Allocation(
                    AllocationReferenceEncoding::BackwardDistance,
                )
            {
                continue;
            }
            let Some(target_index) = usize::try_from(distance)
                .ok()
                .and_then(|distance| allocation.len().checked_sub(distance))
                .and_then(|ordinal| allocation.get(ordinal))
                .copied()
            else {
                continue;
            };
            let target = &records[target_index];
            let Ok(target_class) = crate::native::CatiaOwnerIdentityClass::try_from(target.class())
            else {
                continue;
            };
            targets.push(B2OwnerIdentityTarget {
                owner_pos: packet.pos,
                source_index: packet.source_index,
                slot,
                distance,
                target_pos: target.byte_offset(),
                target_class,
            });
        }
    }
    targets
}

/// Select a fixed-nine boundary only when its complete resolved target set is
/// one simple four-edge cycle. The endpoint records remain allocation-local;
/// this predicate does not assign a face or promote the records to a global
/// identity namespace.
pub(in crate::families) fn b2_closed_owner_boundary_edges(
    targets: &[B2OwnerIdentityTarget],
    endpoint_records: &HashMap<usize, [usize; 2]>,
) -> Option<[B2OwnerBoundaryEdge; 4]> {
    let [first, second, third, fourth] = targets else {
        return None;
    };
    if targets
        .iter()
        .any(|target| target.target_class != crate::native::CatiaOwnerIdentityClass::Edge)
    {
        return None;
    }
    let edge = |target: &B2OwnerIdentityTarget| {
        Some(B2OwnerBoundaryEdge {
            slot: target.slot,
            target_pos: target.target_pos,
            endpoint_records: *endpoint_records.get(&target.target_pos)?,
        })
    };
    let (Some(first), Some(second), Some(third), Some(fourth)) =
        (edge(first), edge(second), edge(third), edge(fourth))
    else {
        return None;
    };
    let mut edges = [first, second, third, fourth];
    edges.sort_unstable_by_key(|left| left.slot);
    if edges.windows(2).any(|pair| pair[0].slot == pair[1].slot)
        || edges
            .iter()
            .any(|edge| edge.endpoint_records[0] == edge.endpoint_records[1])
    {
        return None;
    }

    let mut edge_keys = edges.map(|edge| {
        let [start, end] = edge.endpoint_records;
        if start < end {
            [start, end]
        } else {
            [end, start]
        }
    });
    edge_keys.sort_unstable_by(Ord::cmp);
    if edge_keys.windows(2).any(|pair| pair[0] == pair[1]) {
        return None;
    }
    let mut vertices = [
        edges[0].endpoint_records[0],
        edges[0].endpoint_records[1],
        edges[1].endpoint_records[0],
        edges[1].endpoint_records[1],
        edges[2].endpoint_records[0],
        edges[2].endpoint_records[1],
        edges[3].endpoint_records[0],
        edges[3].endpoint_records[1],
    ];
    vertices.sort_unstable_by(Ord::cmp);
    (vertices[0] == vertices[1]
        && vertices[1] != vertices[2]
        && vertices[2] == vertices[3]
        && vertices[3] != vertices[4]
        && vertices[4] == vertices[5]
        && vertices[5] != vertices[6]
        && vertices[6] == vertices[7])
        .then_some(edges)
}

/// Decode source-closed carrier/reference/side/owner chart productions.
pub(crate) fn b2_owner_charts_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2OwnerChart> {
    let mut owners = BTreeMap::new();
    for owner in b2_owner_packets_from_records(data, records) {
        owners.insert((owner.source_index, owner.pos), owner);
    }
    let mut parameter_points = BTreeMap::new();
    for point in b2_parameter_points_from_records(data, records) {
        parameter_points.insert(point.pos, point);
    }
    let mut charts = Vec::new();
    for window in records.windows(7) {
        let chart = (|| {
            let [carrier, references, side_05, side_09, side_0d, side_11, owner_record] = window
            else {
                return None;
            };
            let carrier_kind = match (carrier.family(), carrier.class()) {
                (ConsolidatedFamily::B, 0x28) => B2OwnerChartCarrier::B28,
                (ConsolidatedFamily::B, 0x2b) => B2OwnerChartCarrier::B2b,
                (ConsolidatedFamily::A, 0x32) => B2OwnerChartCarrier::A32,
                _ => return None,
            };
            if !crate::wire::records::records_are_contiguous(window)
                || window.iter().any(|record| record.range().is_none())
                || window[1..]
                    .iter()
                    .any(|record| record.family() != ConsolidatedFamily::B)
                || references.class() != 0x37
                || [
                    side_05.class(),
                    side_09.class(),
                    side_0d.class(),
                    side_11.class(),
                ] != [0x18; 4]
                || owner_record.class() != 0x62
            {
                return None;
            }
            let owner = owners.get(&(owner_record.source_index(), owner_record.byte_offset()))?;
            let bridge = owner_chart_bridge(data, references, carrier_kind)?;
            let points = [
                parameter_points.get(&side_05.byte_offset())?,
                parameter_points.get(&side_09.byte_offset())?,
                parameter_points.get(&side_0d.byte_offset())?,
                parameter_points.get(&side_11.byte_offset())?,
            ];
            if points.map(|point| point.operand.value()) != [1, 2, 3, 4]
                || !owner_chart_bounds_match(carrier_kind, &points, &owner.numeric_tail)
            {
                return None;
            }
            Some(B2OwnerChart {
                owner_pos: owner.pos,
                source_index: owner.source_index,
                carrier_pos: carrier.byte_offset(),
                carrier: carrier_kind,
                bridge,
                parameter_points: points.map(|point| point.pos),
            })
        })();
        if let Some(chart) = chart {
            charts.push(chart);
        }
    }
    charts
}

fn owner_chart_bridge(
    data: &[u8],
    record: &ConsolidatedRecord,
    carrier: B2OwnerChartCarrier,
) -> Option<B2OwnerChartBridge> {
    let mut frames =
        family_frames_from_records(std::slice::from_ref(record), ConsolidatedFamily::B, 0x37);
    let frame = frames.next()?;
    if frames.next().is_some() {
        return None;
    }
    if frame.header_token != 5 {
        return None;
    }
    let count = match *data.get(frame.payload)? {
        0x85 => 5,
        0x88 => 8,
        _ => return None,
    };
    let mut at = frame.payload + 1;
    let mut references = [None; 8];
    for slot in references.iter_mut().take(count) {
        let reference = allocation_reference(data, &mut at)?;
        *slot = Some(B2OwnerChartBridgeReference {
            value: reference.value,
            encoding: reference.encoding,
        });
    }
    let carrier_reference = references[0]?;
    if carrier_reference.value != 1
        || (count == 8
            && carrier_reference.encoding != AllocationReferenceEncoding::BackwardDistance)
    {
        return None;
    }
    let carrier_selector = *data.get(at)?;
    let expected_selector = match carrier {
        B2OwnerChartCarrier::B28 => 0x05,
        B2OwnerChartCarrier::B2b => 0x09,
        B2OwnerChartCarrier::A32 => 0x11,
    };
    if carrier_selector != expected_selector {
        return None;
    }
    at += 1;
    if count == 5 {
        let unit_token = *data.get(at)?;
        let construction_radius = PositiveLength::new(f64_le(data, at + 1)?.get())?;
        let middle_controls = [
            CatiaOwnerChartMiddleControl::from_byte(*data.get(at + 9)?)?,
            CatiaOwnerChartMiddleControl::from_byte(*data.get(at + 10)?)?,
        ];
        let zeros = data.get(at + 11..at + 19)?;
        let terminal_control = CatiaOwnerChartTerminalControl::from_byte(*data.get(at + 19)?)?;
        if unit_token != 0x05
            || zeros != [0; 8]
            || data.get(at + 20) != Some(&0x05)
            || at + 21 != frame.end
        {
            return None;
        }
        let [Some(carrier_surface), Some(support_surface_0), Some(support_surface_1), Some(support_pcurve_0), Some(support_pcurve_1), ..] =
            references
        else {
            return None;
        };
        Some(B2OwnerChartBridge::SupportedSurface {
            pos: frame.pos,
            carrier_surface,
            support_surfaces: [support_surface_0, support_surface_1],
            support_pcurves: [support_pcurve_0, support_pcurve_1],
            middle_controls,
            terminal_control,
            construction_radius,
        })
    } else {
        let control_tokens: [u8; 3] = data.get(at..at + 3)?.try_into().ok()?;
        let zeros = data.get(at + 3..at + 11)?;
        let terminal_control = *data.get(at + 11)?;
        if control_tokens != [0x09, 0x05, 0x05]
            || zeros != [0; 8]
            || terminal_control != 0x01
            || data.get(at + 12) != Some(&0x05)
            || at + 13 != frame.end
        {
            return None;
        }
        let [Some(first), Some(second), Some(third), Some(fourth), Some(fifth), Some(sixth), Some(seventh), Some(eighth)] =
            references
        else {
            return None;
        };
        Some(B2OwnerChartBridge::Extended {
            pos: frame.pos,
            references: [first, second, third, fourth, fifth, sixth, seventh, eighth],
        })
    }
}

pub(crate) fn b2_rolling_ball_constructions_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2RollingBallConstruction> {
    let mut constructions = Vec::new();
    for (index, record) in records.iter().enumerate() {
        let candidate = (|| {
            if record.family() != ConsolidatedFamily::B
                || record.class() != 0x37
                || record.header_token() != 5
            {
                return None;
            }
            let payload = record.payload()?;
            if payload.len() != 28 || data.get(payload.start) != Some(&0x85) {
                return None;
            }
            let mut at = payload.start + 1;
            let references = [
                allocation_reference(data, &mut at)?,
                allocation_reference(data, &mut at)?,
                allocation_reference(data, &mut at)?,
                allocation_reference(data, &mut at)?,
                allocation_reference(data, &mut at)?,
            ];
            if references.iter().any(|reference| {
                reference.encoding != AllocationReferenceEncoding::BackwardDistance
                    || reference.value == 0
            }) {
                return None;
            }
            if data.get(at..at + 2) != Some(&[0x11, 0x05][..])
                || data.get(at + 12..at + 20) != Some(&[0; 8][..])
                || data.get(at + 20..at + 22) != Some(&[0x01, 0x05][..])
                || at + 22 != payload.end
            {
                return None;
            }
            let construction_radius = PositiveLength::new(f64_le(data, at + 2)?.get())?;
            let middle_controls = [
                CatiaOwnerChartMiddleControl::from_byte(*data.get(at + 10)?)?,
                CatiaOwnerChartMiddleControl::from_byte(*data.get(at + 11)?)?,
            ];
            let terminal_control = CatiaOwnerChartTerminalControl::from_byte(*data.get(at + 20)?)?;
            let target = |slot: usize, family: ConsolidatedFamily, class: u8| {
                let distance = usize::try_from(references[slot].value).ok()?;
                let target_index = index.checked_sub(distance)?;
                let target = records.get(target_index)?;
                (target.family() == family
                    && target.class() == class
                    && target.source_index() == record.source_index()
                    && records_are_contiguous(records.get(target_index..=index)?))
                .then_some(target.byte_offset())
            };
            Some(B2RollingBallConstruction {
                pos: record.byte_offset(),
                source_index: record.source_index(),
                carrier_pos: target(0, ConsolidatedFamily::A, 0x32)?,
                support_surface_positions: [
                    target(1, ConsolidatedFamily::B, 0x30)
                        .or_else(|| target(1, ConsolidatedFamily::B, 0x2e))?,
                    target(2, ConsolidatedFamily::B, 0x30)
                        .or_else(|| target(2, ConsolidatedFamily::B, 0x2e))?,
                ],
                support_pcurve_positions: [
                    target(3, ConsolidatedFamily::B, 0x20)
                        .or_else(|| target(3, ConsolidatedFamily::A, 0x20))?,
                    target(4, ConsolidatedFamily::B, 0x20)
                        .or_else(|| target(4, ConsolidatedFamily::A, 0x20))?,
                ],
                middle_controls,
                terminal_control,
                construction_radius,
            })
        })();
        if let Some(construction) = candidate {
            constructions.push(construction);
        }
    }
    constructions
}

fn owner_chart_bounds_match(
    carrier: B2OwnerChartCarrier,
    points: &[&B2ParameterPoint; 4],
    tail: &CatiaOwnerNumericTail,
) -> bool {
    let (axis, lower, upper) = if carrier == B2OwnerChartCarrier::B28 {
        (1, tail.lower(), tail.upper())
    } else {
        (
            2,
            [tail.lower()[1], tail.lower()[0]],
            [tail.upper()[1], tail.upper()[0]],
        )
    };
    let side_lower = [lower[0], lower[1], upper[1]];
    let side_upper = [upper[0], lower[1], upper[1]];
    let sides_match = (parameter_point_matches_tuple(points[0], axis, side_lower)
        && parameter_point_matches_tuple(points[1], axis, side_upper))
        || (parameter_point_matches_tuple(points[0], axis, side_upper)
            && parameter_point_matches_tuple(points[1], axis, side_lower));
    sides_match
        && parameter_point_matches_boundary(points[2], axis, lower[1], [lower[0], upper[0]])
        && parameter_point_matches_boundary(points[3], axis, upper[1], [lower[0], upper[0]])
}

fn parameter_point_matches_tuple(point: &B2ParameterPoint, axis: u8, expected: [f64; 3]) -> bool {
    let control = expected
        .iter()
        .zip([0x10, 0x04, 0x08])
        .fold(axis, |control, (value, bit)| {
            if *value == 0.0 {
                control | bit
            } else {
                control
            }
        });
    let (values, len) = point.payload.scalars();
    point.control == control
        && expected
            .into_iter()
            .filter(|value| *value != 0.0)
            .eq(values[..len].iter().copied())
}

fn parameter_point_matches_boundary(
    point: &B2ParameterPoint,
    side_axis: u8,
    boundary: f64,
    range: [f64; 2],
) -> bool {
    if parameter_point_matches_tuple(point, 3 - side_axis, [boundary, range[0], range[1]]) {
        return true;
    }
    let half_span = range[1] * 0.5 - range[0] * 0.5;
    let midpoint = range[0] * 0.5 + range[1] * 0.5;
    let (control, expected) = if side_axis == 1 {
        (0x88, [-half_span, midpoint, boundary])
    } else {
        (0x48, [-half_span, boundary, midpoint])
    };
    let (values, len) = point.payload.scalars();
    point.control == control
        && len == 3
        && values[..3].iter().zip(expected).all(|(actual, expected)| {
            (*actual - expected).abs() <= EPS_PARAMETER_LINE * expected.abs().max(1.0)
        })
}

fn b2_fixed_owner_packet(
    data: &[u8],
    frame: ConsolidatedFrame,
    source_index: usize,
    reference_encoding: B2OwnerReferenceEncoding,
) -> Option<B2OwnerPacket> {
    if data.get(frame.payload) != Some(&0x89) {
        return None;
    }
    let mut at = frame.payload + 1;
    let mut references = [0u32; 9];
    let mut identity_encodings = [B2OwnerIdentityEncoding::RawU8; 9];
    for (index, (reference, identity_encoding)) in references
        .iter_mut()
        .zip(&mut identity_encodings)
        .enumerate()
    {
        (*reference, *identity_encoding) = match reference_encoding {
            B2OwnerReferenceEncoding::TaggedU16Strong if index % 2 == 0 => (
                tagged_u16_ref(data, &mut at)?,
                B2OwnerIdentityEncoding::Allocation(AllocationReferenceEncoding::TaggedU16),
            ),
            B2OwnerReferenceEncoding::TaggedU16Strong => compact_owner_identity(data, &mut at)?,
            B2OwnerReferenceEncoding::WidthCodedStrong if index % 2 == 0 => {
                compact_owner_identity(data, &mut at)?
            }
            B2OwnerReferenceEncoding::WidthCodedStrong => {
                let value = u32::from(*data.get(at)?);
                at += 1;
                (value, B2OwnerIdentityEncoding::RawU8)
            }
            B2OwnerReferenceEncoding::AllCompact => compact_owner_identity(data, &mut at)?,
        };
    }
    let numeric_tail = b2_owner_numeric_tail(data.get(at..frame.end)?)?;
    Some(B2OwnerPacket {
        pos: frame.pos,
        source_index,
        header_token: frame.header_token,
        reference_encoding,
        references,
        identity_encodings,
        numeric_tail,
    })
}

fn b2_owner_frames(
    records: &[ConsolidatedRecord],
) -> impl Iterator<Item = (ConsolidatedFrame, usize)> + '_ {
    records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::B && record.class() == 0x62)
        .filter_map(|record| {
            Some((
                ConsolidatedFrame {
                    pos: record.byte_offset(),
                    payload: record.payload()?.start,
                    end: record.range()?.end,
                    header_token: record.header_token(),
                },
                record.source_index(),
            ))
        })
}

fn compact_owner_identity(data: &[u8], at: &mut usize) -> Option<(u32, B2OwnerIdentityEncoding)> {
    let lead = *data.get(*at)?;
    let encoding = match lead % 4 {
        1 => AllocationReferenceEncoding::BackwardDistance,
        0 if lead != 0 => AllocationReferenceEncoding::WidthCoded,
        _ => return None,
    };
    Some((
        compact_int(data, at)?,
        B2OwnerIdentityEncoding::Allocation(encoding),
    ))
}

fn tagged_u16_ref(data: &[u8], at: &mut usize) -> Option<u32> {
    (data.get(*at) == Some(&0x0a)).then_some(())?;
    persistent_ref(data, at)
}

fn b2_owner_numeric_tail(data: &[u8]) -> Option<CatiaOwnerNumericTail> {
    if data.len() != 62 {
        return None;
    }
    let header: [u8; 5] = data.get(..5)?.try_into().ok()?;
    if header[0] != 0x84 || !matches!(header[1], 0x41 | 0xc1) || header[4] != 0x0d {
        return None;
    }

    let values = read_f64_array::<4>(data, 5)?.map(FiniteReal::get);
    let lower = [values[0], values[1]];
    let upper = [values[2], values[3]];
    if data.get(37) != Some(&0x01) {
        return None;
    }
    let mut view = View::over_retained(data);
    view.seek(38)?;
    let mut bounds = [[0.0; 2]; 3];
    for bound in &mut bounds {
        bound[0] = view.f32_le()?;
        bound[1] = view.f32_le()?;
    }
    CatiaOwnerNumericTail::new(header, lower, upper, bounds)
}

/// Decode complete B-family class-`0x5b` and class-`0x5c` control records.
///
/// The B-family length byte closes the frame. The complete payload stays
/// opaque until a source-closed field relation is established.
#[must_use]
#[cfg(test)]
fn b2_class5b5c_records(data: &[u8]) -> Vec<B2Class5b5cRecord> {
    let records = consolidated_records(data);
    b2_class5b5c_records_from_records(data, &records)
        .expect("decode the B2 class 5B and 5C control records")
}

pub(crate) fn b2_class5b5c_records_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<B2Class5b5cRecord>, CodecError> {
    let mut output = Vec::new();
    for record in records {
        if record.family() != ConsolidatedFamily::B {
            continue;
        }
        let Ok(class) = crate::native::class5b5c::CatiaClass5b5c::try_from(record.class()) else {
            continue;
        };
        let Some(payload) = record.payload().and_then(|range| data.get(range)) else {
            continue;
        };
        let payload = payload.to_vec();
        output.push(B2Class5b5cRecord {
            frame: ConsolidatedRawFrame::from_record(record, payload)?,
            source_index: record.source_index(),
            source_offset: record.source_range().start,
            class,
        });
    }
    Ok(output)
}

/// Decode structurally complete class-`0x5f` nodes.
#[must_use]
#[cfg(test)]
fn b2_face_nodes_5f(data: &[u8]) -> Vec<B2FaceNode5f> {
    let records = consolidated_records(data);
    b2_face_nodes_5f_from_records(data, &records).collect()
}

pub(in crate::families) fn b2_face_nodes_5f_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2FaceNode5f> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x5f).filter_map(|frame| {
        if data.get(frame.payload) != Some(&0x82) {
            return None;
        }
        let mut at = frame.payload + 1;
        let (target_encoding, target) = if data.get(at) == Some(&0x0a) {
            (
                B2FaceNode5fTargetEncoding::TaggedU16Strong,
                persistent_ref(data, &mut at)?,
            )
        } else if data.get(at).is_some_and(|byte| byte % 4 == 3) {
            let reference = allocation_reference(data, &mut at)?;
            (B2FaceNode5fTargetEncoding::OwnedChild, reference.value)
        } else {
            (
                B2FaceNode5fTargetEncoding::Compact,
                compact_int(data, &mut at)?,
            )
        };
        let terminal = <[u8; 2]>::try_from(data.get(at..frame.end)?).ok()?;
        Some(B2FaceNode5f {
            pos: frame.pos,
            header_token: frame.header_token,
            target_encoding,
            target,
            terminal,
        })
    })
}

/// Bind immediately adjacent `5f,62` records when the terminal admits the
/// packet dialect and its ninth identity is the checked successor of the node
/// target.
#[must_use]
#[cfg(test)]
fn b2_adjacent_face_owners(data: &[u8]) -> Vec<B2AdjacentFaceOwner> {
    let records = consolidated_records(data);
    b2_adjacent_face_owners_from_records(data, &records)
}

pub(crate) fn b2_adjacent_face_owners_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2AdjacentFaceOwner> {
    let mut nodes = BTreeMap::new();
    for record in records {
        for value in b2_face_nodes_5f_from_records(data, std::slice::from_ref(record)) {
            nodes.insert((record.source_index(), value.pos), value);
        }
    }
    let mut owners = BTreeMap::new();
    for value in b2_owner_packets_from_records(data, records) {
        owners.insert((value.source_index, value.pos), value);
    }
    let mut adjacent = Vec::new();
    for window in records.windows(2) {
        if !records_are_contiguous(window) {
            continue;
        }
        let [link_record, owner_record] = window else {
            continue;
        };
        let Some(face_node) = nodes.get(&(link_record.source_index(), link_record.byte_offset()))
        else {
            continue;
        };
        let Some(owner) = owners.get(&(owner_record.source_index(), owner_record.byte_offset()))
        else {
            continue;
        };
        let terminal_is_admitted = face_node.terminal == [0x03, 0x05]
            || (face_node.terminal == [0x03, 0x03]
                && owner.reference_encoding == B2OwnerReferenceEncoding::AllCompact);
        if terminal_is_admitted && face_node.target.checked_add(1) == Some(owner.references[8]) {
            adjacent.push(B2AdjacentFaceOwner {
                face_node: *face_node,
                owner: owner.clone(),
            });
        }
    }
    adjacent
}

/// Bind immediately adjacent `5f,62` records when the count-framed packet's
/// final identity is the checked successor of the node target.
#[must_use]
#[cfg(test)]
fn b2_adjacent_face_counted_owners(data: &[u8]) -> Vec<B2AdjacentFaceCountedOwner> {
    let records = consolidated_records(data);
    b2_adjacent_face_counted_owners_from_records(data, &records)
}

pub(crate) fn b2_adjacent_face_counted_owners_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2AdjacentFaceCountedOwner> {
    let mut nodes = BTreeMap::new();
    for (record_index, record) in records.iter().enumerate() {
        for value in b2_face_nodes_5f_from_records(data, std::slice::from_ref(record)) {
            nodes.insert(
                (record.source_index(), record.byte_offset()),
                (record_index, value),
            );
        }
    }
    let mut owners = BTreeMap::new();
    for (record_index, record) in records.iter().enumerate() {
        for value in b2_counted_owners_from_records(data, std::slice::from_ref(record)) {
            owners.insert((value.source_index, value.pos), (record_index, value));
        }
    }
    let mut adjacent = Vec::new();
    for (&(source_index, _), &(face_index, face_node)) in &nodes {
        if let Some(next_record) = records.get(face_index + 1) {
            if next_record.source_index() == source_index
                && records_are_contiguous(&records[face_index..=face_index + 1])
            {
                let owner_pos = (source_index, next_record.byte_offset());
                if let Some((_, owner)) = owners.get(&owner_pos) {
                    if (face_node.terminal == [0x03, 0x05]
                        || face_node.terminal == [0x03, 0x03]
                            && face_node.target_encoding == B2FaceNode5fTargetEncoding::Compact
                            && owner.reference_encodings.last()
                                == Some(&AllocationReferenceEncoding::WidthCoded))
                        && face_node.target.checked_add(1) == owner.references.last().copied()
                    {
                        if let Some((_, owner)) = owners.remove(&owner_pos) {
                            adjacent.push(B2AdjacentFaceCountedOwner { face_node, owner });
                            continue;
                        }
                    }
                }
            }
        }
        if face_node.target_encoding == B2FaceNode5fTargetEncoding::OwnedChild
            && face_node.terminal[0] % 4 == 3
            && face_node.terminal[1] == 0x03
        {
            let loop_ordinal = usize::from(face_node.terminal[0] >> 2);
            if let Some(target_loop_idx) = face_index.checked_add(1 + loop_ordinal) {
                if let Some(target_record) = records.get(target_loop_idx) {
                    let owner_pos = (source_index, target_record.byte_offset());
                    if target_record.source_index() != source_index
                        || target_record.family() != ConsolidatedFamily::B
                        || target_record.class() != 0x62
                        || !records_are_contiguous(&records[face_index..=target_loop_idx])
                    {
                        continue;
                    }
                    if let Some((_, owner)) = owners.get(&owner_pos) {
                        if owner.reference_encodings.last()
                            != Some(&AllocationReferenceEncoding::BackwardDistance)
                        {
                            continue;
                        }
                        let surf_ordinal = usize::try_from(face_node.target).ok();
                        let target_surf_idx =
                            surf_ordinal.and_then(|ordinal| face_index.checked_add(1 + ordinal));
                        let owner_surf_dist = owner
                            .references
                            .last()
                            .copied()
                            .and_then(|dist| usize::try_from(dist).ok());
                        let owner_surf_idx =
                            owner_surf_dist.and_then(|dist| target_loop_idx.checked_sub(dist));
                        if target_surf_idx.is_some()
                            && target_surf_idx == owner_surf_idx
                            && target_surf_idx.is_some_and(|index| {
                                records.get(index).is_some_and(|record| {
                                    record.source_index() == source_index
                                        && record.family() == ConsolidatedFamily::B
                                        && record.class() == 0x37
                                })
                            })
                        {
                            if let Some((_, owner)) = owners.remove(&owner_pos) {
                                adjacent.push(B2AdjacentFaceCountedOwner { face_node, owner });
                            }
                        }
                    }
                }
            }
        }
    }
    adjacent
}

/// Decode width-coded `b2/b3/b4 03 18` parameter-space records.
#[must_use]
#[cfg(test)]
fn b2_parameter_points(data: &[u8]) -> Vec<B2ParameterPoint> {
    let records = consolidated_records(data);
    b2_parameter_points_from_records(data, &records).collect()
}

pub(crate) fn b2_parameter_points_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2ParameterPoint> + 'a {
    parameter_points(data, records, false)
}

pub(in crate::families) fn owned_parameter_points<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2ParameterPoint> + 'a {
    parameter_points(data, records, true)
}

fn parameter_points<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
    owned: bool,
) -> impl Iterator<Item = B2ParameterPoint> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x18).filter_map(move |frame| {
        if frame.header_token != 5 && !owned {
            return None;
        }
        let bytes = data.get(frame.payload..frame.end)?;
        let mut at = 0;
        let operand = CompactUnsigned::read(bytes, &mut at)?;
        let control = *bytes.get(at)?;
        at += 1;
        let payload = match bytes.len() - at {
            8 => B2ParameterPointPayload::Scalar {
                value: f64_le(bytes, at)?,
            },
            16 => B2ParameterPointPayload::TwoScalars {
                values: read_f64_array::<2>(bytes, at)?.into(),
            },
            24 => B2ParameterPointPayload::ThreeScalars {
                values: read_f64_array::<3>(bytes, at)?.into(),
            },
            40 => B2ParameterPointPayload::FiveScalars {
                values: read_f64_array::<5>(bytes, at)?.into(),
            },
            _ => return None,
        };
        if !payload.matches_control(control) {
            return None;
        }
        Some(B2ParameterPoint {
            pos: frame.pos,
            end: frame.end,
            operand,
            control,
            payload,
        })
    })
}

/// Decode complete consolidated class-`0x27` plane-carrier records.
#[must_use]
#[cfg(test)]
pub(crate) fn b2_plane_carriers(data: &[u8]) -> Vec<B2PlaneCarrier> {
    let records = consolidated_records(data);
    b2_plane_carriers_from_records(data, &records)
}

pub(crate) fn b2_plane_carriers_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2PlaneCarrier> {
    let mut carriers = Vec::new();
    for record in records
        .iter()
        .filter(|record| record.family() == ConsolidatedFamily::B && record.class() == 0x27)
    {
        let Some(range) = record.payload() else {
            continue;
        };
        let Some(&marker) = data.get(range.start) else {
            continue;
        };
        let Some(&selector) = data.get(range.start + 1) else {
            continue;
        };
        if marker != 0xb4 {
            continue;
        }
        let Some(lane) = data.get(range.start + 2..range.end) else {
            continue;
        };
        let payload = if let Ok(layout) = B2PlaneCarrierLayout::try_from(selector) {
            let count = layout.scalar_count();
            if lane.len() != count * size_of::<f64>() {
                continue;
            }
            let parsed = match layout {
                B2PlaneCarrierLayout::ImplicitX | B2PlaneCarrierLayout::ImplicitY => {
                    read_f64_array::<6>(lane, 0).map(|values| {
                        let direction = if layout == B2PlaneCarrierLayout::ImplicitX {
                            [1.0, 0.0, 0.0]
                        } else {
                            [0.0, 1.0, 0.0]
                        };
                        (
                            [values[0], values[1]],
                            None,
                            direction,
                            [values[2], values[3], values[4], values[5]],
                        )
                    })
                }
                B2PlaneCarrierLayout::DirectionX | B2PlaneCarrierLayout::DirectionY => {
                    read_f64_array::<7>(lane, 0).map(|values| {
                        let direction = if layout == B2PlaneCarrierLayout::DirectionX {
                            [values[2].get(), 0.0, 0.0]
                        } else {
                            [0.0, values[2].get(), 0.0]
                        };
                        (
                            [values[0], values[1]],
                            None,
                            direction,
                            [values[3], values[4], values[5], values[6]],
                        )
                    })
                }
                B2PlaneCarrierLayout::DirectionXY => read_f64_array::<8>(lane, 0).map(|values| {
                    (
                        [values[0], values[1]],
                        None,
                        [values[2].get(), values[3].get(), 0.0],
                        [values[4], values[5], values[6], values[7]],
                    )
                }),
                B2PlaneCarrierLayout::SpatialImplicitY => {
                    read_f64_array::<7>(lane, 0).map(|values| {
                        (
                            [values[0], values[1]],
                            Some(values[2]),
                            [0.0, 1.0, 0.0],
                            [values[3], values[4], values[5], values[6]],
                        )
                    })
                }
            };
            let Some((point, origin_z, direction, bounds)) = parsed else {
                continue;
            };
            let (Some(direction), Some(u_range), Some(v_range)) = (
                ExactHypotUnitVector3::new(direction),
                IncreasingParameterInterval::new([bounds[0].get(), bounds[1].get()]),
                IncreasingParameterInterval::new([bounds[2].get(), bounds[3].get()]),
            ) else {
                continue;
            };
            B2PlaneCarrierPayload::Plane {
                layout,
                point: point.into(),
                direction,
                u_range,
                v_range,
                origin_z,
            }
        } else {
            let Some(values) = finite_f64_lane(lane) else {
                continue;
            };
            if values.is_empty() {
                continue;
            }
            B2PlaneCarrierPayload::ScalarLane { selector, values }
        };
        let Some(record_range) = record.range() else {
            continue;
        };
        carriers.push(B2PlaneCarrier {
            pos: record.byte_offset(),
            end: record_range.end,
            width: record.width(),
            flag: record.flag(),
            header_token: record.header_token(),
            payload,
        });
    }
    carriers
}

/// Return the plane chart of a known selector. U is the stored or implicit
/// horizontal direction, V is global +Z, and the normal is `unit(U × V)`.
pub(in crate::families) fn b2_plane_geometry(carrier: &B2PlaneCarrier) -> Option<SurfaceGeometry> {
    let B2PlaneCarrierPayload::Plane {
        point,
        direction,
        origin_z,
        ..
    } = &carrier.payload
    else {
        return None;
    };
    if !carrier.payload.valid_plane() {
        return None;
    }
    let z = origin_z.map_or(0.0, FiniteReal::get);
    let origin = FinitePoint3::new(Point3::new(point[0], point[1], z))?;
    let frame = OrthonormalFrame3::about_horizontal_normal((*direction).into())?;
    Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::new(origin, frame),
    )))
}

/// Decode class-`0x18` descriptors that prefix class-`0x25` edge definitions.
pub(in crate::families) fn b2_class25_descriptors_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2Class25Descriptor> {
    let mut descriptors = Vec::new();
    for frame in family_frames_from_records(records, ConsolidatedFamily::B, 0x18) {
        let parsed = (|| {
            if frame.header_token != 5 {
                return None;
            }
            let mut at = frame.payload;
            let record_id = compact_int(data, &mut at)?;
            let control = *data.get(at)?;
            at += 1;
            if !matches!(control, 0x02 | 0x0a) {
                return None;
            }
            let lane = data.get(at..frame.end)?;
            matches!(lane.len(), 16 | 24).then_some((record_id, control, lane))
        })();
        let Some((record_id, control, lane)) = parsed else {
            continue;
        };
        let Some(values) = finite_f64_lane(lane) else {
            continue;
        };
        descriptors.push(B2Class25Descriptor {
            pos: frame.pos,
            record_id,
            control,
            values,
        });
    }
    descriptors
}

/// Shared-edge parameter range stored in a `b2 03 23` packet.
#[derive(Debug, Clone)]
pub(crate) struct B2EdgeParameters {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Native shared-edge parameter range.
    pub(crate) range: IncreasingParameterInterval,
    /// Shared-edge geometric tolerance.
    pub(crate) tolerance: FiniteReal,
}

/// Typed class-`0x18` descriptor immediately preceding a class-`0x25` edge.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2Class25Descriptor {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Width-coded allocation identity.
    pub(crate) record_id: u32,
    /// Descriptor control byte (`0x02` or `0x0a`).
    pub(crate) control: u8,
    /// Complete finite scalar lane containing two or three values.
    pub(crate) values: Vec<FiniteReal>,
}

fn parameter_in_closed_range(value: f64, range: [f64; 2]) -> bool {
    range[0] < range[1]
        && cadmpeg_ir::math::parameter_in_domain(value, range, EPS_B2_RECORD_COARSE_GEOMETRY)
}

pub(in crate::families) fn b2_cone_point(cone: &B2Cone, uv: [f64; 2]) -> Option<Point3> {
    if !parameter_in_closed_range(uv[1], cone.slant_range.endpoints()) {
        return None;
    }
    let phi = uv[0] / cone.angular_scale.get();
    let (t1, t2, axis) = (
        cone.frame.reference().get(),
        cone.t2.get(),
        cone.frame.axis().get(),
    );
    let radial = [
        phi.cos() * t1[0] + phi.sin() * t2[0],
        phi.cos() * t1[1] + phi.sin() * t2[1],
        phi.cos() * t1[2] + phi.sin() * t2[2],
    ];
    let axial = cone.half_angle.get().cos();
    let transverse = cone.half_angle.get().sin();
    let apex = cone.apex.get();
    Some(Point3::new(
        apex.x + uv[1] * (axial * axis[0] + transverse * radial[0]),
        apex.y + uv[1] * (axial * axis[1] + transverse * radial[1]),
        apex.z + uv[1] * (axial * axis[2] + transverse * radial[2]),
    ))
}

pub(in crate::families) fn b2_cylinder_point(
    cylinder: &B2Cylinder,
    uv: [f64; 2],
) -> Option<Point3> {
    if !parameter_in_closed_range(uv[0], cylinder.u_range.endpoints())
        || !parameter_in_closed_range(uv[1], cylinder.v_range.endpoints())
    {
        return None;
    }
    let radius = cylinder.radius.get();
    let angle = uv[0] / radius;
    let axis = Vector3::from(cylinder.frame.axis().get());
    let ref_direction = Vector3::from(cylinder.frame.reference().get());
    let perpendicular = axis.cross(ref_direction);
    let origin = cylinder.origin.get();
    Some(Point3::new(
        origin.x
            + uv[1] * axis.x
            + radius * (angle.cos() * ref_direction.x + angle.sin() * perpendicular.x),
        origin.y
            + uv[1] * axis.y
            + radius * (angle.cos() * ref_direction.y + angle.sin() * perpendicular.y),
        origin.z
            + uv[1] * axis.z
            + radius * (angle.cos() * ref_direction.z + angle.sin() * perpendicular.z),
    ))
}

/// Arc-length circle support stored in a `b2 03 19` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2Circle {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Payload-layout discriminator.
    pub(crate) layout: crate::native::CatiaCircleLayout,
    /// Compact persistent record identifier.
    pub(crate) record_id: u32,
    /// Frame token following the record length.
    pub(crate) frame_token: u8,
    /// Two center coordinates in the host-implied carrier plane.
    pub(crate) center_pair: FiniteVector<2>,
    /// Circle radius in millimetres.
    pub(crate) radius: PositiveLength,
    /// Arc-length parameter interval.
    pub(crate) range: IncreasingParameterInterval,
    /// Length-valued angular chart shift.
    pub(crate) chart_shift: FiniteReal,
}

#[cfg(test)]
impl B2Circle {
    /// Whether the interval spans one complete circumference.
    fn full_circle(&self) -> bool {
        circle_range_is_full_turn(self.radius.get(), self.range.endpoints())
    }
}

/// One clamped rational NURBS curve stored in a `b2 03 16` record.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B2NurbsCurve {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Width-coded record token.
    pub(in crate::families) header_token: u32,
    /// Exact neutral rational curve.
    pub(in crate::families) geometry: NurbsCurve,
}

/// One spatial circle carrier stored in a `b2 03 0f` record.
#[derive(Debug, Clone, PartialEq)]
pub(in crate::families) struct B2SpatialCircle {
    /// Record byte offset.
    pub(in crate::families) pos: usize,
    /// Width-coded record token.
    pub(in crate::families) header_token: u32,
    /// Circle centre.
    pub(in crate::families) center: FinitePoint3,
    /// Unit circle-plane normal and unit radial reference direction.
    pub(in crate::families) frame: OrthonormalFrame3,
    /// Positive radius in millimetres.
    pub(in crate::families) radius: PositiveLength,
    /// Stored arc-length interval.
    pub(in crate::families) range: IncreasingParameterInterval,
    /// Stored chart shift.
    pub(in crate::families) chart_shift: FiniteReal,
}

/// Decode length-closed `b2/b3/b4 03 0f` spatial circles.
#[must_use]
#[cfg(test)]
fn b2_spatial_circles(data: &[u8]) -> Vec<B2SpatialCircle> {
    let records = consolidated_records(data);
    b2_spatial_circles_from_records(data, &records).collect()
}

pub(in crate::families) fn b2_spatial_circles_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2SpatialCircle> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x0f)
        .filter_map(|frame| parse_b2_spatial_circle(data, frame))
}

fn parse_b2_spatial_circle(data: &[u8], frame: ConsolidatedFrame) -> Option<B2SpatialCircle> {
    let values = read_f64_array::<14>(data, frame.payload)?;
    if frame.end.checked_sub(frame.payload)? != 14 * size_of::<f64>() {
        return None;
    }
    let center = FinitePoint3::from_coordinates(values[0], values[1], values[2]);
    let chart_shift_value = values[13];
    let values = values.map(FiniteReal::get);
    let radius = values[9];
    let range = [values[10], values[11]];
    if values[12].to_bits() != 1.0f64.to_bits() {
        return None;
    }
    let reference = ExactNormUnitVector3::new([values[3], values[4], values[5]])?;
    let transverse = ExactHypotUnitVector3::new([values[6], values[7], values[8]])?;
    let circle_frame = OrthonormalFrame3::completing(reference.into(), transverse.into())?;
    let radius = PositiveLength::new(radius)?;
    let range = IncreasingParameterInterval::new(range)?;
    Some(B2SpatialCircle {
        pos: frame.pos,
        header_token: frame.header_token,
        center,
        frame: circle_frame,
        radius,
        range,
        chart_shift: chart_shift_value,
    })
}

/// Decode length-closed `b2 03 16` rational NURBS curves.
///
/// The record stores one clamped span. The first compact integer is the degree,
/// so the control-point and weight cardinalities are both `degree + 1`. The two
/// knot limits occur twice and the second pair must reproduce the first pair.
#[cfg(test)]
fn b2_nurbs_curves(data: &[u8]) -> Vec<B2NurbsCurve> {
    let records = consolidated_records(data);
    b2_nurbs_curves_from_records(data, &records, &mut crate::nurbs::LaneRefusals::new())
}

pub(in crate::families) fn b2_nurbs_curves_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Vec<B2NurbsCurve> {
    let mut curves = Vec::new();
    for frame in family_frames_from_records(records, ConsolidatedFamily::B, 0x16) {
        if let Some(curve) = parse_b2_nurbs_curve(data, frame, refusal) {
            curves.push(curve);
        }
    }
    curves
}

fn parse_b2_nurbs_curve(
    data: &[u8],
    frame: ConsolidatedFrame,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<B2NurbsCurve> {
    let (degree, control_count, knot_start, knot_end, point_start, weight_start) = (|| {
        let mut at = frame.payload;
        let degree = compact_int(data, &mut at)?;
        let control_count = usize::try_from(degree.checked_add(1)?).ok()?;
        if !(1..=64).contains(&degree) || compact_int(data, &mut at)? != 2 {
            return None;
        }
        if data.get(at) != Some(&0x0c) {
            return None;
        }
        at += 1;
        let knot_start = f64_le(data, at)?.get();
        let knot_end = f64_le(data, at + 8)?.get();
        at += 16;
        if knot_start >= knot_end || compact_int(data, &mut at)? != 1 {
            return None;
        }
        let point_start = at;
        for _ in 0..control_count {
            f64_point(data, at)?;
            at += 24;
        }
        let weight_start = at;
        for _ in 0..control_count {
            PositiveReal::new(f64_le(data, at)?.get())?;
            at += 8;
        }
        if compact_int(data, &mut at)? != 1 || compact_int(data, &mut at)? != 1 {
            return None;
        }
        let repeated_start = f64_le(data, at)?.get();
        let repeated_end = f64_le(data, at + 8)?.get();
        let scale = f64_le(data, at + 16)?.get();
        let offset = f64_le(data, at + 24)?.get();
        at += 32;
        if repeated_start.to_bits() != knot_start.to_bits()
            || repeated_end.to_bits() != knot_end.to_bits()
            || scale.to_bits() != 1.0f64.to_bits()
            || offset.to_bits() != 0.0f64.to_bits()
            || data.get(at..frame.end) != Some(&[0x00, 0x07])
        {
            return None;
        }
        Some((
            degree,
            control_count,
            knot_start,
            knot_end,
            point_start,
            weight_start,
        ))
    })()?;
    let mut control_points = Vec::new();

    for index in 0..control_count {
        let point = f64_point(data, point_start + index * 24)?;
        control_points.push(point);
    }
    let mut weights = Vec::new();

    for index in 0..control_count {
        let weight = f64_le(data, weight_start + index * 8)
            .and_then(|weight| PositiveReal::new(weight.get()))?;
        weights.push(NonZeroReal::from(weight));
    }
    let mut knots = Vec::new();

    knots.extend(std::iter::repeat_with(|| knot_start).take(control_count));
    knots.extend(std::iter::repeat_with(|| knot_end).take(control_count));
    crate::nurbs::note_refusal(
        NurbsCurve::from_checked_lanes(degree, knots, control_points, Some(weights), false),
        refusal,
        format_args!("b2 NURBS curve record at byte {}", frame.pos),
    )
    .map(|geometry| B2NurbsCurve {
        pos: frame.pos,
        header_token: frame.header_token,
        geometry,
    })
}

/// Analytic cylinder support stored in a `b2 03 28` record.
#[derive(Debug, Clone)]
pub(crate) struct B2Cylinder {
    /// Complete packed frame token with its declared width.
    pub(crate) header: crate::wire::records::WidthCodedToken,
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Cylinder-axis origin.
    pub(crate) origin: FinitePoint3,
    /// Cylinder-axis unit direction and the unit direction from which the
    /// circumferential parameter is measured.
    pub(crate) frame: UnitFrame3<RelaxedDeviation, HypotLength>,
    /// Cylinder radius.
    pub(crate) radius: PositiveLength,
    /// Arc-length circumferential range.
    pub(crate) u_range: IncreasingParameterInterval,
    /// Axial range.
    pub(crate) v_range: IncreasingParameterInterval,
    /// Layout-specific frame data.
    pub(crate) layout: B2CylinderLayout,
}

/// Layout of a consolidated `B:28` cylinder chart.
#[derive(Debug, Clone, PartialEq)]
pub(crate) enum B2CylinderLayout {
    /// Layout `0x5a` with a stored frame token.
    Full5a { frame_token: u8 },
    /// Layout `0x52` with a fixed X-axis frame.
    Full52,
    /// Layout `0x62` with a stored planar vector.
    RangeOrigin { stored_vector: RelaxedUnitVector2 },
}

impl B2Cylinder {
    pub(crate) fn frame_token(&self) -> u8 {
        match self.layout {
            B2CylinderLayout::Full5a { frame_token } => frame_token,
            B2CylinderLayout::Full52 => 0x1d,
            B2CylinderLayout::RangeOrigin { .. } => 0x0e,
        }
    }

    pub(crate) fn range_origin(&self) -> Option<f64> {
        matches!(self.layout, B2CylinderLayout::RangeOrigin { .. })
            .then(|| cylinder_range_origin(self.radius.get(), self.u_range.endpoints()))
    }

    pub(in crate::families) fn surface_geometry(&self) -> SurfaceGeometry {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::new(
                self.origin,
                self.frame.into(),
                self.radius,
            ),
        ))
    }
}

/// Slant-coordinate cone chart stored in a `b2 03 29` record.
#[derive(Debug, Clone)]
pub(crate) struct B2Cone {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Cone apex.
    pub(crate) apex: FinitePoint3,
    /// Cone-axis unit direction and the first transverse unit direction.
    pub(crate) frame: UnitFrame3<RelaxedDeviation, SquaredLength>,
    /// Second transverse unit direction.
    pub(crate) t2: RelaxedUnitVector3,
    /// Cone half-angle in radians.
    pub(crate) half_angle: Angle,
    /// Reference radius of the conical surface, independent of the active chart ranges.
    pub(crate) reference_radius: FiniteReal,
    /// Active azimuth interval.
    pub(crate) angular_range: IncreasingParameterInterval,
    /// Native slant-coordinate range.
    pub(crate) slant_range: IncreasingParameterInterval,
    /// Divisor mapping the stored U coordinate to azimuth.
    pub(crate) angular_scale: PositiveReal,
    /// Full-turn azimuth chart domain.
    pub(crate) angular_domain: IncreasingParameterInterval,
    /// Neutral carrier: its origin is the axis point at the slant-interval
    /// start and its radius is the cross-section radius there.
    pub(crate) surface: ConeSurface,
}

/// Axis-and-profile surface of revolution stored in a `b2 03 2d` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2Revolution {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Reference-token dialect.
    pub(crate) reference_token: crate::native::CatiaRevolutionReferenceToken,
    /// Stored nonzero profile reference; its namespace is unresolved.
    pub(crate) profile_reference: u16,
    /// Axis-frame origin.
    pub(crate) origin: FinitePoint3,
    /// First transverse unit direction, the profile-circle normal, as the
    /// first direction and the second transverse unit direction, the
    /// profile-circle zero-angle direction, as the second.
    pub(crate) profile_frame: UnitFrame3<ExactDeviation, SquaredLength>,
    /// Revolution-axis direction.
    pub(crate) axis: ExactUnitVector3,
    /// Stored angular parameter interval.
    pub(crate) angular_range: IncreasingParameterInterval,
    /// Revolution-angle interval in radians: the stored angular parameter
    /// interval divided by the angular scale.
    pub(crate) angular_interval: IncreasingParameterInterval,
    /// Stored profile parameter interval.
    pub(crate) profile_range: IncreasingParameterInterval,
    /// Positive angular chart scale.
    pub(crate) angular_scale: PositiveReal,
}

/// One revolution record whose profile interval identifies exactly one
/// consolidated circle record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2ResolvedRevolution {
    /// Ordinal among all decoded revolution records.
    pub(in crate::families) revolution_index: usize,
    /// Surface-of-revolution record.
    pub(crate) revolution: B2Revolution,
    /// Unique profile circle with the same stored parameter interval.
    pub(crate) profile: B2Circle,
}

/// Metric line profile stored in a `b2/b3/b4 03 0e` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2LineProfile {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Stored line origin.
    pub(crate) origin: FinitePoint3,
    /// Unit line direction.
    pub(crate) direction: ExactUnitVector3,
    /// Increasing stored parameter interval.
    pub(crate) range: IncreasingParameterInterval,
}

/// Radius-scaled sphere chart stored in a `b2 03 2a` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2Sphere {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Sphere centre.
    pub(crate) center: FinitePoint3,
    /// Sphere-axis unit direction and the first transverse unit direction.
    pub(crate) frame: UnitFrame3<ExactDeviation, HypotLength>,
    /// Second transverse unit direction.
    pub(crate) direction_y: ExactHypotUnitVector3,
    /// Sphere radius.
    pub(crate) radius: PositiveLength,
    /// Active azimuth interval.
    pub(crate) azimuth_range: IncreasingParameterInterval,
    /// Active latitude interval.
    pub(crate) latitude_range: IncreasingParameterInterval,
}

/// Doubly periodic torus chart stored in a `b2 03 2b` record.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct B2Torus {
    /// Record byte offset.
    pub(crate) pos: usize,
    /// Torus centre.
    pub(crate) center: FinitePoint3,
    /// Torus-axis unit direction and the first transverse unit direction.
    pub(crate) frame: UnitFrame3<ExactDeviation, SquaredLength>,
    /// Second transverse unit direction.
    pub(crate) direction_y: ExactUnitVector3,
    /// Major radius.
    pub(crate) major_radius: PositiveLength,
    /// Minor radius.
    pub(crate) minor_radius: PositiveLength,
    /// Active major-angle interval.
    pub(crate) major_angular_range: IncreasingParameterInterval,
    /// Full-turn major-angle chart domain.
    pub(crate) major_angular_domain: IncreasingParameterInterval,
    /// Active minor-angle interval.
    pub(crate) minor_angular_range: IncreasingParameterInterval,
    /// Full-turn minor-angle chart domain.
    pub(crate) minor_angular_domain: IncreasingParameterInterval,
    /// Scale from major angle to stored U parameter.
    pub(crate) major_scale: PositiveReal,
    /// Scale from minor angle to stored V parameter.
    pub(crate) minor_scale: PositiveReal,
}

fn b2_construction_offset_supports_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2OffsetSupport> {
    let mut out = Vec::new();
    for frame in family_frames_from_records(records, ConsolidatedFamily::B, 0x30) {
        let pos = frame.pos;
        let payload = frame.payload;
        if frame.header_token != 5 || data.get(payload) != Some(&0x05) {
            continue;
        }
        let (support_id, at) = match data.get(payload + 1) {
            Some(0x08) => {
                let Some(value) = View::u16_le_at(data, payload + 2) else {
                    continue;
                };
                (u32::from(value), payload + 4)
            }
            Some(0x0c) => {
                let Some(value) = u32_le_24(data, payload + 2) else {
                    continue;
                };
                (value, payload + 5)
            }
            _ => continue,
        };
        let Some(distance) = f64_le(data, at) else {
            continue;
        };
        let Some(&kind) = data.get(at + 8) else {
            continue;
        };
        let Some(fields) = read_f64_array::<4>(data, at + 9) else {
            continue;
        };
        if kind != 0x01 || at + 41 != frame.end {
            continue;
        }
        let fields = fields.map(FiniteReal::get);
        let (Some(u_range), Some(v_range)) = (
            IncreasingParameterInterval::new([fields[0], fields[1]]),
            IncreasingParameterInterval::new([fields[2], fields[3]]),
        ) else {
            continue;
        };
        out.push(B2OffsetSupport {
            pos,
            support_id,
            distance,
            u_range,
            v_range,
        });
    }
    out
}

/// Decode `b2 03 29` analytic cone charts.
#[must_use]
#[cfg(test)]
fn b2_cones(data: &[u8]) -> Vec<B2Cone> {
    let records = consolidated_records(data);
    b2_cones_from_records(data, &records).collect()
}

pub(crate) fn b2_cones_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Cone> + 'a {
    cone_charts(data, records, false).map(|(cone, _)| cone)
}

pub(in crate::families) fn owned_cone_charts<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = (B2Cone, bool)> + 'a {
    cone_charts(data, records, true)
}

fn cone_charts<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
    owned: bool,
) -> impl Iterator<Item = (B2Cone, bool)> + 'a {
    let mut frames = family_frames_from_records(records, ConsolidatedFamily::B, 0x29);
    std::iter::from_fn(move || loop {
        let frame = frames.next()?;
        let pos = frame.pos;
        let p = frame.payload;
        if frame.end - p != 0xb8 {
            continue;
        }
        let Some(stored) = read_f64_array::<23>(data, p) else {
            continue;
        };
        let apex = FinitePoint3::from_coordinates(stored[0], stored[1], stored[2]);
        let half_angle = Angle::from_assigned_real(stored[12]);
        let reference_radius = stored[13];
        let values = stored.map(FiniteReal::get);
        let t1: [f64; 3] = [values[3], values[4], values[5]];
        let t2: [f64; 3] = [values[6], values[7], values[8]];
        let axis: [f64; 3] = [values[9], values[10], values[11]];
        let angular_range = [values[14], values[15]];
        let mut slant_range = [values[16], values[17]];
        let angular_scale = values[18];
        let angular_domain = [values[21], values[22]];
        if slant_range[0].abs() <= EPS_B2_RECORD_EXACT_GEOMETRY {
            slant_range[0] = 0.0;
        }
        let unit = RelaxedUnitVector3::new;
        let (Some(t1), Some(t2), Some(axis)) = (unit(t1), unit(t2), unit(axis)) else {
            continue;
        };
        let (Some(slant_range), Some(angular_scale)) = (
            IncreasingParameterInterval::new(slant_range),
            PositiveReal::new(angular_scale),
        ) else {
            continue;
        };
        let frame = UnitFrame3::right_handed(axis, t1, t2)
            .map(|f| (f, false))
            .or_else(|| {
                if !owned {
                    return None;
                }
                let flipped = unit(t2.get().map(|value| -value))?;
                Some((UnitFrame3::right_handed(axis, t1, flipped)?, true))
            });
        let Some((frame, reversed)) = frame else {
            continue;
        };
        if !(0.0 < half_angle.get()
            && half_angle.get() < std::f64::consts::FRAC_PI_2
            && (periodic_angular_range_is_valid(angular_range, angular_domain)
                || owned
                    && periodic_angular_range_is_valid(angular_domain, angular_domain)
                    && angular_domain[0] <= angular_range[0]
                    && angular_range[0] < angular_range[1]
                    && angular_range[1] <= angular_domain[1])
            && values[19] == 1.0
            && values[20] == 0.0)
        {
            continue;
        }
        // The angular check admits a strictly increasing range inside a
        // strictly increasing full-turn domain.
        let (Some(angular_range), Some(angular_domain)) = (
            IncreasingParameterInterval::new(angular_range),
            IncreasingParameterInterval::new(angular_domain),
        ) else {
            continue;
        };
        let (axial, radius, axis_angle) = if owned {
            let angle = Angle::new(std::f64::consts::FRAC_PI_2 - half_angle.get())?;
            let slant_start = slant_range.lower();
            let axial = slant_start * half_angle.get().sin();
            let radius = NonNegativeLength::new(
                slant_start.mul_add(half_angle.get().cos(), reference_radius.get()),
            )?;
            (axial, radius, angle)
        } else {
            let Some(slant_start) = NonNegativeLength::new(slant_range.lower()) else {
                continue;
            };
            (
                slant_start.get() * half_angle.get().cos(),
                slant_start.scaled_by_sine(half_angle),
                half_angle,
            )
        };
        let (apex_point, axis) = (apex.get(), axis.get());
        let Some(origin) = FinitePoint3::new(Point3::new(
            apex_point.x + axial * axis[0],
            apex_point.y + axial * axis[1],
            apex_point.z + axial * axis[2],
        )) else {
            continue;
        };
        return Some((
            B2Cone {
                pos,
                apex,
                frame,
                t2,
                half_angle,
                reference_radius,
                angular_range,
                slant_range,
                angular_scale,
                angular_domain,
                surface: ConeSurface::new(
                    origin,
                    frame.into(),
                    radius,
                    PositiveReal::ONE,
                    axis_angle,
                ),
            },
            reversed,
        ));
    })
}

/// Decode `b2 03 2d` axis-and-profile surfaces of revolution.
#[must_use]
#[cfg(test)]
fn b2_revolutions(data: &[u8]) -> Vec<B2Revolution> {
    let records = consolidated_records(data);
    b2_revolutions_from_records(data, &records).collect()
}

pub(crate) fn b2_revolutions_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Revolution> + 'a {
    let mut frames = family_frames_from_records(records, ConsolidatedFamily::B, 0x2d);
    std::iter::from_fn(move || loop {
        let frame = frames.next()?;
        let p = frame.payload;
        let Ok(reference_token) = data.get(p).copied().ok_or(()).and_then(|token| {
            crate::native::CatiaRevolutionReferenceToken::try_from(token).map_err(|_| ())
        }) else {
            continue;
        };
        if frame.end - p != 0xae
            || data.get(p + 131..p + 133) != Some(&[0x05, 0x05])
            || f64_le(data, p + 141) != Some(FiniteReal::ONE)
            || f64_le(data, p + 149) != Some(FiniteReal::ONE)
            || f64_le(data, p + 157) != Some(FiniteReal::ZERO)
            || data.get(p + 165) != Some(&0x01)
        {
            continue;
        }
        let Some(profile_reference) = View::u16_le_at(data, p + 1) else {
            continue;
        };
        let Some(axis_frame) = read_f64_array::<12>(data, p + 3) else {
            continue;
        };
        let Some(bounds) = read_f64_array::<4>(data, p + 99) else {
            continue;
        };
        let Some(angular_scale) = f64_le(data, p + 133) else {
            continue;
        };
        let Some(mean_angle_parameter) = f64_le(data, p + 166) else {
            continue;
        };
        let origin = FinitePoint3::from_coordinates(axis_frame[0], axis_frame[1], axis_frame[2]);
        let axis_frame = axis_frame.map(FiniteReal::get);
        let bounds = bounds.map(FiniteReal::get);
        let mean_angle_parameter = mean_angle_parameter.get();
        let direction_x: [f64; 3] = [axis_frame[3], axis_frame[4], axis_frame[5]];
        let direction_y: [f64; 3] = [axis_frame[6], axis_frame[7], axis_frame[8]];
        let axis: [f64; 3] = [axis_frame[9], axis_frame[10], axis_frame[11]];
        let unit = ExactUnitVector3::new;
        let (Some(direction_x), Some(direction_y), Some(axis)) =
            (unit(direction_x), unit(direction_y), unit(axis))
        else {
            continue;
        };
        // The cyclic form of the right-handed frame (direction_x,
        // direction_y, axis): direction_y is perpendicular to the axis and
        // their cross product is direction_x.
        let Some(profile_frame) = UnitFrame3::right_handed(direction_x, direction_y, axis) else {
            continue;
        };
        let (Some(angular_range), Some(profile_range), Some(angular_scale)) = (
            IncreasingParameterInterval::new([bounds[0], bounds[1]]),
            IncreasingParameterInterval::new([bounds[2], bounds[3]]),
            PositiveReal::new(angular_scale.get()),
        ) else {
            continue;
        };
        let Some(angular_interval) = IncreasingParameterInterval::new([
            bounds[0] / angular_scale.get(),
            bounds[1] / angular_scale.get(),
        ]) else {
            continue;
        };
        if profile_reference == 0
            || angular_interval.lower() != 0.5
            || (bounds[1] - bounds[0]) / angular_scale.get() != std::f64::consts::TAU
            || mean_angle_parameter / angular_scale.get() != std::f64::consts::PI + 0.5
        {
            continue;
        }
        return Some(B2Revolution {
            pos: frame.pos,
            reference_token,
            profile_reference,
            origin,
            profile_frame,
            axis,
            angular_range,
            angular_interval,
            profile_range,
            angular_scale,
        });
    })
}

/// Bind revolution profiles only by an exact, unique stored parameter interval.
#[must_use]
#[cfg(test)]
fn b2_resolved_revolutions(data: &[u8]) -> Vec<B2ResolvedRevolution> {
    let records = consolidated_records(data);
    b2_resolved_revolutions_from_records(data, &records)
}

pub(crate) fn b2_resolved_revolutions_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2ResolvedRevolution> {
    let circles = b2_circles_from_records(data, records).collect::<Vec<_>>();
    b2_revolutions_from_records(data, records)
        .enumerate()
        .filter_map(|(revolution_index, revolution)| {
            let mut profiles = circles.iter().filter(|circle| {
                circle.range.lower().to_bits() == revolution.profile_range.lower().to_bits()
                    && circle.range.upper().to_bits() == revolution.profile_range.upper().to_bits()
            });
            let profile = profiles.next()?;
            if profiles.next().is_some() {
                return None;
            }
            Some(B2ResolvedRevolution {
                revolution_index,
                revolution,
                profile: profile.clone(),
            })
        })
        .collect()
}

/// Decode exact B-family metric line profiles.
#[must_use]
#[cfg(test)]
fn b2_line_profiles(data: &[u8]) -> Vec<B2LineProfile> {
    let records = consolidated_records(data);
    b2_line_profiles_from_records(data, &records).collect()
}

pub(crate) fn b2_line_profiles_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2LineProfile> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x0e).filter_map(|frame| {
        if frame.end - frame.payload != 9 * 8 {
            return None;
        }
        let values = read_f64_array::<9>(data, frame.payload)?;
        let origin = FinitePoint3::from_coordinates(values[0], values[1], values[2]);
        let values = values.map(FiniteReal::get);
        let direction: [f64; 3] = [values[3], values[4], values[5]];
        let direction = ExactUnitVector3::new(direction)?;
        let range = IncreasingParameterInterval::new([values[7], values[8]])?;
        (values[6].to_bits() == 1.0_f64.to_bits()).then_some(B2LineProfile {
            pos: frame.pos,
            origin,
            direction,
            range,
        })
    })
}

/// Decode `b2 03 2b` doubly periodic torus charts.
#[must_use]
#[cfg(test)]
fn b2_tori(data: &[u8]) -> Vec<B2Torus> {
    let records = consolidated_records(data);
    b2_tori_from_records(data, &records).collect()
}

pub(crate) fn b2_tori_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Torus> + 'a {
    torus_charts(data, records, false).map(|(torus, _)| torus)
}

pub(in crate::families) fn owned_torus_charts<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = (B2Torus, bool)> + 'a {
    torus_charts(data, records, true)
}

fn torus_charts<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
    allow_reversed: bool,
) -> impl Iterator<Item = (B2Torus, bool)> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x2b).filter_map(move |frame| {
        let p = frame.payload;
        (frame.end.checked_sub(p) == Some(200)).then_some(())?;
        let values = read_f64_array::<25>(data, p)?;
        let center = FinitePoint3::from_coordinates(values[0], values[1], values[2]);
        let values = values.map(FiniteReal::get);
        let direction_x: [f64; 3] = [values[3], values[4], values[5]];
        let direction_y: [f64; 3] = [values[6], values[7], values[8]];
        let axis: [f64; 3] = [values[9], values[10], values[11]];
        let major_radius = values[12];
        let minor_radius = values[13];
        let major_angular_range = [values[14], values[15]];
        let major_angular_domain = [values[16], values[17]];
        let minor_angular_range = [values[18], values[19]];
        let minor_angular_domain = [values[20], values[21]];
        let major_scale = values[22];
        let minor_scale = values[23];
        let direction_x = ExactUnitVector3::new(direction_x)?;
        let direction_y = ExactUnitVector3::new(direction_y)?;
        let axis = ExactUnitVector3::new(axis)?;
        let (axis_frame, reversed) = UnitFrame3::right_handed(axis, direction_x, direction_y)
            .map(|frame| (frame, false))
            .or_else(|| {
                if !allow_reversed {
                    return None;
                }
                let flipped = ExactUnitVector3::new(direction_y.get().map(|value| -value))?;
                Some((UnitFrame3::right_handed(axis, direction_x, flipped)?, true))
            })?;
        let major_radius = PositiveLength::new(major_radius)?;
        let minor_radius = PositiveLength::new(minor_radius)?;
        let major_scale = PositiveReal::new(major_scale)?;
        let minor_scale = PositiveReal::new(minor_scale)?;
        (periodic_angular_range_is_valid(major_angular_range, major_angular_domain)
            && periodic_angular_range_is_valid(minor_angular_range, minor_angular_domain)
            && values[24] == 0.0)
            .then_some(())?;
        // Each angular check admits a strictly increasing range inside a
        // strictly increasing full-turn domain.
        Some((
            B2Torus {
                pos: frame.pos,
                center,
                frame: axis_frame,
                direction_y,
                major_radius,
                minor_radius,
                major_angular_range: IncreasingParameterInterval::new(major_angular_range)?,
                major_angular_domain: IncreasingParameterInterval::new(major_angular_domain)?,
                minor_angular_range: IncreasingParameterInterval::new(minor_angular_range)?,
                minor_angular_domain: IncreasingParameterInterval::new(minor_angular_domain)?,
                major_scale,
                minor_scale,
            },
            reversed,
        ))
    })
}

/// Decode `b2 03 2a` radius-scaled sphere charts.
#[must_use]
#[cfg(test)]
fn b2_spheres(data: &[u8]) -> Vec<B2Sphere> {
    let records = consolidated_records(data);
    b2_spheres_from_records(data, &records).collect()
}

pub(crate) fn b2_spheres_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Sphere> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x2a).filter_map(move |frame| {
        let p = frame.payload;
        (frame.end.checked_sub(p) == Some(152)).then_some(())?;
        let values = read_f64_array::<19>(data, p)?;
        let center = FinitePoint3::from_coordinates(values[0], values[1], values[2]);
        let values = values.map(FiniteReal::get);
        let stored_x: [f64; 3] = [values[3], values[4], values[5]];
        let stored_y: [f64; 3] = [values[6], values[7], values[8]];
        let stored_axis: [f64; 3] = [values[9], values[10], values[11]];
        let radius = values[12];
        let azimuth_range = [values[13], values[14]];
        let latitude_range = [values[15], values[16]];
        let construction_radius = values[17];
        let chart_origin = values[18];
        (sphere_angular_ranges_are_valid(azimuth_range, latitude_range)
            && construction_radius.to_bits() == radius.to_bits()
            && chart_origin.to_bits()
                == (radius * ((azimuth_range[0] + azimuth_range[1]) * 0.5 - std::f64::consts::PI))
                    .to_bits())
        .then_some(())?;
        let radius = PositiveLength::new(radius)?;
        let unit_direction =
            |stored: [f64; 3]| ExactHypotUnitVector3::from_scaled(stored, radius.get());
        let direction_x = unit_direction(stored_x)?;
        let direction_y = unit_direction(stored_y)?;
        let axis = unit_direction(stored_axis)?;
        Some(B2Sphere {
            pos: frame.pos,
            center,
            frame: UnitFrame3::right_handed(axis, direction_x, direction_y)?,
            direction_y,
            radius,
            // The sphere chart check admits strictly increasing azimuth
            // and latitude ranges.
            azimuth_range: IncreasingParameterInterval::new(azimuth_range)?,
            latitude_range: IncreasingParameterInterval::new(latitude_range)?,
        })
    })
}

/// Return the neutral carrier of a decoded B2 slant-coordinate cone chart.
#[must_use]
pub(in crate::families) fn b2_cone_geometry(cone: &B2Cone) -> SurfaceGeometry {
    SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone.surface))
}

/// Build the exact neutral carrier of a validated radius-scaled sphere chart.
#[must_use]
pub(in crate::families) fn b2_sphere_geometry(sphere: &B2Sphere) -> SurfaceGeometry {
    SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(
        cadmpeg_ir::geometry::analytic::SphereSurface::new(
            sphere.center,
            sphere.frame.into(),
            NonZeroLength::from(sphere.radius),
        ),
    ))
}

/// Build the exact neutral carrier of a validated doubly periodic torus chart.
#[must_use]
pub(in crate::families) fn b2_torus_geometry(torus: &B2Torus) -> SurfaceGeometry {
    SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(
        cadmpeg_ir::geometry::analytic::TorusSurface::new(
            torus.center,
            torus.frame.into(),
            torus.major_radius,
            NonZeroLength::from(torus.minor_radius),
        ),
    ))
}

/// Decode standalone `b2 03 28` analytic cylinder supports.
#[must_use]
#[cfg(test)]
pub(in crate::families) fn b2_cylinders(data: &[u8]) -> Vec<B2Cylinder> {
    let records = consolidated_records(data);
    b2_cylinders_from_records(data, &records).collect()
}

pub(crate) fn b2_cylinders_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Cylinder> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x28)
        .filter_map(move |frame| parse_b2_cylinder(data, frame))
}

fn parse_b2_cylinder(data: &[u8], frame: ConsolidatedFrame) -> Option<B2Cylinder> {
    let width = u8::try_from(frame.payload.checked_sub(frame.pos.checked_add(4)?)?).ok()?;
    let width = ConsolidatedFrameWidth::try_from(width).ok()?;
    let header = crate::wire::records::WidthCodedToken::new(width, frame.header_token).ok()?;
    let pos = frame.pos;
    let layout = u8::try_from(frame.end.checked_sub(frame.payload)?).ok()?;
    let p = frame.payload;
    let origin = f64_point(data, p)?;
    let frame_token = *data.get(p + 24)?;
    match layout {
        0x5a => {
            if data.get(p + 89) != Some(&0x07) {
                return None;
            }
            let vector = read_f64_array::<2>(data, p + 25)?.map(FiniteReal::get);
            let one = f64_le(data, p + 41)?.get();
            let radius = f64_le(data, p + 49)?.get();
            let u_range = read_f64_array::<2>(data, p + 57)?.map(FiniteReal::get);
            let v_range = read_f64_array::<2>(data, p + 73)?.map(FiniteReal::get);
            if one != 1.0 || !circle_range_is_full_turn(radius, u_range) {
                return None;
            }
            let vector = RelaxedUnitVector2::from_hypot(vector)?;
            let radius = PositiveLength::new(radius)?;
            let u_range = IncreasingParameterInterval::new(u_range)?;
            let v_range = IncreasingParameterInterval::new(v_range)?;
            let axis = match frame_token {
                0x19 => vector,
                0x1c => vector.reverse_quarter_turn(),
                _ => return None,
            };
            Some(B2Cylinder {
                header,
                pos,
                origin,
                frame: UnitFrame3::in_xy_plane(axis),
                radius,
                u_range,
                v_range,
                layout: B2CylinderLayout::Full5a { frame_token },
            })
        }
        0x52 => {
            if frame_token != 0x1d
                || f64_le(data, p + 25)? != FiniteReal::ONE
                || f64_le(data, p + 33)? != FiniteReal::ONE
                || data.get(p + 81) != Some(&0x07)
            {
                return None;
            }
            let radius = f64_le(data, p + 41)?.get();
            let u_range = read_f64_array::<2>(data, p + 49)?.map(FiniteReal::get);
            let v_range = read_f64_array::<2>(data, p + 65)?.map(FiniteReal::get);
            if !circle_range_is_full_turn(radius, u_range) {
                return None;
            }
            let radius = PositiveLength::new(radius)?;
            let u_range = IncreasingParameterInterval::new(u_range)?;
            let v_range = IncreasingParameterInterval::new(v_range)?;
            Some(B2Cylinder {
                header,
                pos,
                origin,
                frame: UnitFrame3::X_AXIS_Y_REFERENCE,
                radius,
                u_range,
                v_range,
                layout: B2CylinderLayout::Full52,
            })
        }
        0x62 if frame_token == 0x0e && data.get(p + 89) == Some(&0x03) => {
            let vector = read_f64_array::<2>(data, p + 25)?.map(FiniteReal::get);
            let one = f64_le(data, p + 41)?.get();
            let radius = f64_le(data, p + 49)?.get();
            let u_range = read_f64_array::<2>(data, p + 57)?.map(FiniteReal::get);
            let v_range = read_f64_array::<2>(data, p + 73)?.map(FiniteReal::get);
            let range_origin = f64_le(data, p + 90)?.get();
            let expected_range_origin = cylinder_range_origin(radius, u_range);
            if one != 1.0
                || range_origin.to_bits() != expected_range_origin.to_bits()
                || !circle_range_is_within_full_turn(radius, u_range)
            {
                return None;
            }
            let vector = RelaxedUnitVector2::from_hypot(vector)?;
            let radius = PositiveLength::new(radius)?;
            let u_range = IncreasingParameterInterval::new(u_range)?;
            let v_range = IncreasingParameterInterval::new(v_range)?;
            Some(B2Cylinder {
                header,
                pos,
                origin,
                frame: UnitFrame3::about_y_axis(vector),
                radius,
                u_range,
                v_range,
                layout: B2CylinderLayout::RangeOrigin {
                    stored_vector: vector,
                },
            })
        }
        _ => None,
    }
}

pub(crate) fn cylinder_range_origin(radius: f64, u_range: [f64; 2]) -> f64 {
    (u_range[0] + u_range[1]) * 0.5 - std::f64::consts::PI * radius
}

/// Decode `b2 03 19` arc-length circle supports.
#[must_use]
#[cfg(test)]
fn b2_circles(data: &[u8]) -> Vec<B2Circle> {
    let records = consolidated_records(data);
    b2_circles_from_records(data, &records).collect()
}

pub(crate) fn b2_circles_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2Circle> + 'a {
    let mut frames = family_frames_from_records(records, ConsolidatedFamily::B, 0x19);
    std::iter::from_fn(move || loop {
        let frame = frames.next()?;
        let pos = frame.pos;
        let Some(layout) = u8::try_from(frame.end - frame.payload)
            .ok()
            .and_then(|layout| crate::native::CatiaCircleLayout::try_from(layout).ok())
        else {
            continue;
        };
        let Ok(frame_token) = u8::try_from(frame.header_token) else {
            continue;
        };
        let mut at = frame.payload;
        let Some(record_id) = compact_int(data, &mut at) else {
            continue;
        };
        let Some(values) = read_f64_array::<5>(data, at) else {
            continue;
        };
        let values_end = at + 5 * size_of::<f64>();
        if values_end + 9 != frame.end || data.get(values_end) != Some(&0x01) {
            continue;
        }
        let Some(chart_shift) = f64_le(data, values_end + 1) else {
            continue;
        };
        let center_pair = FiniteVector::from([values[0], values[1]]);
        let [c1, c2, radius, lo, hi] = values.map(FiniteReal::get);
        let (Some(radius), Some(range)) = (
            PositiveLength::new(radius),
            IncreasingParameterInterval::new([lo, hi]),
        ) else {
            continue;
        };
        if c1.abs() <= 1e6 && c2.abs() <= 1e6 {
            return Some(B2Circle {
                pos,
                layout,
                record_id,
                frame_token,
                center_pair,
                radius,
                range,
                chart_shift,
            });
        }
    })
}

pub(crate) fn circle_range_is_full_turn(radius: f64, range: [f64; 2]) -> bool {
    let error = circle_half_turn_error(radius, range);
    error.is_finite() && error.abs() <= EPS_B2_RECORD_COARSE_GEOMETRY * 0.5
}

pub(crate) fn circle_range_is_within_full_turn(radius: f64, range: [f64; 2]) -> bool {
    let error = circle_half_turn_error(radius, range);
    error.is_finite() && error <= EPS_B2_RECORD_COARSE_GEOMETRY * 0.5
}

fn circle_half_turn_error(radius: f64, range: [f64; 2]) -> f64 {
    (range[1] * 0.5 - range[0] * 0.5) - std::f64::consts::PI * radius
}

/// Decode structurally repeated `b2 03 23` edge-range packets.
#[must_use]
#[cfg(test)]
fn b2_edge_parameters(data: &[u8]) -> Vec<B2EdgeParameters> {
    let records = consolidated_records(data);
    b2_edge_parameters_from_records(data, &records).collect()
}

pub(in crate::families) fn b2_edge_parameters_from_records<'a>(
    data: &'a [u8],
    records: &'a [ConsolidatedRecord],
) -> impl Iterator<Item = B2EdgeParameters> + 'a {
    family_frames_from_records(records, ConsolidatedFamily::B, 0x23).filter_map(move |frame| {
        let pos = frame.pos;
        if frame.end - frame.payload != 0x4e {
            return None;
        }
        let values = read_f64_array::<9>(data, frame.payload + 6)?;
        let tolerance = values[2];
        let values = values.map(FiniteReal::get);
        let range = IncreasingParameterInterval::new([values[0], values[1]])?;
        if values[0] == values[3]
            && values[0] == values[6]
            && values[1] == values[4]
            && values[1] == values[7]
            && values[5] == 1.0
            && values[2] == values[8]
        {
            Some(B2EdgeParameters {
                pos,
                range,
                tolerance,
            })
        } else {
            None
        }
    })
}

/// Decode `b2 03 31` offset-surface constructors.
#[must_use]
#[cfg(test)]
fn b2_offset_supports(data: &[u8]) -> Vec<B2OffsetSupport> {
    let records = consolidated_records(data);
    b2_offset_supports_from_records(data, &records)
}

pub(in crate::families) fn b2_offset_supports_from_records(
    data: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<B2OffsetSupport> {
    let mut offsets = family_frames_from_records(records, ConsolidatedFamily::B, 0x31)
        .filter_map(|frame| {
            if frame.header_token != 5 {
                return None;
            }
            let length = frame.end - frame.payload;
            let (support_id, at) = match data.get(frame.payload) {
                Some(0x08) if length == 0x2b => (
                    u32::from(View::u16_le_at(data, frame.payload + 1)?),
                    frame.payload + 3,
                ),
                Some(0x0c) if length == 0x2c => {
                    (u32_le_24(data, frame.payload + 1)?, frame.payload + 4)
                }
                _ => return None,
            };
            let [distance, u0, v0, u1, v1] = read_f64_array::<5>(data, at)?;
            Some(B2OffsetSupport {
                pos: frame.pos,
                support_id,
                distance,
                u_range: IncreasingParameterInterval::new([u0.get(), u1.get()])?,
                v_range: IncreasingParameterInterval::new([v0.get(), v1.get()])?,
            })
        })
        .collect::<Vec<_>>();
    let extra = b2_construction_offset_supports_from_records(data, records);

    offsets.extend(extra);
    offsets.sort_unstable_by_key(|left| left.pos);
    offsets
}

/// Bind each offset constructor to the unique consolidated NURBS carrier whose
/// parameter domain contains the offset box and whose V-knot lane contains both
/// serialized V limits.
pub(in crate::families) fn offset_support_carriers(
    offsets: &[B2OffsetSupport],
    carriers: &[FreeformSurface],
) -> Vec<Option<usize>> {
    const RELATIVE_PARAMETER_TOLERANCE: f64 = 1e-3;
    let mut bindings = Vec::new();
    for offset in offsets {
        let [u0, u1] = offset.u_range.endpoints();
        let [v0, v1] = offset.v_range.endpoints();
        let mut selected = None;
        let mut ambiguous = false;
        for (index, carrier) in carriers.iter().enumerate() {
            let surface = &carrier.geometry;
            let (Some(&u_min), Some(&u_max), Some(&v_min), Some(&v_max)) = (
                surface.u_knots().first(),
                surface.u_knots().last(),
                surface.v_knots().first(),
                surface.v_knots().last(),
            ) else {
                continue;
            };
            let u_span = u_max - u_min;
            let v_span = v_max - v_min;
            if !u_span.is_finite() || u_span <= 0.0 || !v_span.is_finite() || v_span <= 0.0 {
                continue;
            }
            let u_tolerance = RELATIVE_PARAMETER_TOLERANCE * u_span;
            let v_tolerance = RELATIVE_PARAMETER_TOLERANCE * v_span;
            let contains = u0 >= u_min - u_tolerance
                && u1 <= u_max + u_tolerance
                && v0 >= v_min - v_tolerance
                && v1 <= v_max + v_tolerance;
            let has_v_limit = |limit: f64| {
                surface
                    .v_knots()
                    .iter()
                    .any(|knot| (*knot - limit).abs() <= v_tolerance)
            };
            if contains && has_v_limit(v0) && has_v_limit(v1) && selected.replace(index).is_some() {
                ambiguous = true;
            }
        }
        bindings.push(if ambiguous { None } else { selected });
    }
    bindings
}

/// Decode width-coded `b2/b3/b4 03 20` consolidated UV jets.
#[must_use]
#[cfg(test)]
fn b2_pcurves(data: &[u8]) -> Vec<ConsolidatedPcurve> {
    let records = consolidated_records(data);
    crate::wire::records::family_pcurves_from_records(data, &records, ConsolidatedFamily::B)
}

#[cfg(test)]
mod tests;
