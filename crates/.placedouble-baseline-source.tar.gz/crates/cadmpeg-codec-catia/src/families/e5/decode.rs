// SPDX-License-Identifier: Apache-2.0
//! E5-stream decode route: analytic carriers, plane fitting, and topology transfer.

use cadmpeg_core::decode::u64_from_index;

type E5PcurveLiftOutput =
    Result<Option<(PcurveGeometry, [f64; 2], [Point3; 2])>, cadmpeg_core::CodecError>;
type E5CurvePlans<'a> = (
    &'a BTreeMap<u32, IntcurveSupportContext>,
    &'a BTreeMap<u32, (SurfaceId, PcurveGeometry, [f64; 2])>,
);

use cadmpeg_ir::codec::DecodeBody;
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve,
    pcurve::{Pcurve, PcurveGeometry, PcurveNurbs},
    Curve, CurveGeometry, DirectedParameterRange, IntcurveSupportContext, IntcurveSupportSide,
    ProceduralCurve, ProceduralCurveDefinition, ProceduralSurface, SolvedCurveGeometry,
    SolvedSurfaceGeometry, SupportPcurve, Surface, SurfaceCurveFamily, SurfaceGeometry,
};
use cadmpeg_ir::ids::{
    BodyId, CoedgeId, CurveId, EdgeId, FaceId, LoopId, PcurveId, PointId, ProceduralCurveId,
    ProceduralSurfaceId, RegionId, ShellId, SurfaceId, VertexId,
};
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::scalar::FiniteReal;
use cadmpeg_ir::topology::{
    AnchoredVertexUse, Body, BodyKind, Coedge, Edge, Face, Loop, Point, Region, Sense, Shell,
    Vertex,
};
use cadmpeg_ir::units::{FinitePoint2, FiniteVector, OrthonormalFrame3, UnitVector3};
use cadmpeg_ir::AnnotationBuilder;
use cadmpeg_ir::Exactness;
use std::collections::{BTreeMap, HashMap, HashSet};

use crate::assemble::{
    annotate, circle_parameter_range_from_surface_branch, insert_unresolved_carrier_loss,
    link_payload_carriers, neutral_model_is_admissible, ordered_range, preserve_raw_payload,
    quintic_jet_pcurve, rational_pcurve_arc,
};
use crate::container::ContainerScan;
use crate::families::{FamilyEntityAdmission, FamilyOutput};
use crate::loss::CatiaLossCode;
use crate::math::{distance, unit_vector};
use crate::solve::union_find::UnionFind;

const EPS_E5_DECODE_COARSE_GEOMETRY: f64 = 1.0e-6;
const EPS_E5_DECODE_POSITION: f64 = 1.0e-8;
const EPS_E5_DECODE_GEOMETRY: f64 = 1.0e-9;
const EPS_E5_DECODE_DEGENERATE: f64 = 1.0e-10;
const EPS_E5_DECODE_EXACT_GEOMETRY: f64 = 1.0e-12;

const E5_ENDPOINT_MATCH_TOLERANCE: f64 = 2e-3;
const EPS_AXIS_ALIGN: f64 = EPS_E5_DECODE_POSITION;
const E5_ISOPARAMETRIC_DIRECTION_TOLERANCE: f64 = EPS_E5_DECODE_POSITION;
const E5_PARAMETER_RELATIVE_TOLERANCE: f64 = EPS_E5_DECODE_GEOMETRY;
const E5_CARRIER_AXIS_COSINE_TOLERANCE: f64 = EPS_E5_DECODE_GEOMETRY;

#[derive(Clone, Copy)]
enum E5IsoparametricDirection {
    ConstantU,
    ConstantV,
}

fn e5_isoparametric_direction(direction: Point2) -> Option<E5IsoparametricDirection> {
    let scale = direction.u.abs().max(direction.v.abs());
    if !scale.is_finite() || scale == 0.0 {
        return None;
    }
    let normalized = Point2::new(direction.u / scale, direction.v / scale);
    match (
        normalized.u.abs() <= E5_ISOPARAMETRIC_DIRECTION_TOLERANCE,
        normalized.v.abs() <= E5_ISOPARAMETRIC_DIRECTION_TOLERANCE,
    ) {
        (true, false) => Some(E5IsoparametricDirection::ConstantU),
        (false, true) => Some(E5IsoparametricDirection::ConstantV),
        (true, true) | (false, false) => None,
    }
}

/// Decode direct E5 circle carriers.  Their edge and face references are a
/// separate record layer, so curves remain unattached until that layer is
/// decoded rather than being assigned speculatively.
pub(in crate::families) fn try_decode_e5(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<FamilyOutput>, cadmpeg_core::CodecError> {
    let Some(stream_range) = scan.e5_record_range.clone() else {
        return Ok(None);
    };
    let stream = &scan.data[stream_range];
    let circles = crate::families::e5::records::e5_circles(stream);
    let mut surfaces = crate::families::e5::records::e5_surfaces(stream, refusal)?;
    let rolling_ball_jets = crate::families::e5::records::e5_rolling_ball_jets(stream);
    (|| -> Option<Result<FamilyOutput, cadmpeg_core::CodecError>> {
        macro_rules! admitted {
            ($value:expr) => {
                match $value {
                    Ok(value) => value,
                    Err(error) => return Some(Err(error)),
                }
            };
        }
        let topology = crate::families::e5::graph::parse_topology(stream);
        let vertex_count = if let Some(topology) = topology.as_ref() {
            topology.vertex_refs.len()
        } else {
            let edges = crate::families::e5::records::e5_edges(stream);
            let mut vertices = HashSet::new();
            for edge in edges {
                for vertex in [edge.start_vertex, edge.end_vertex] {
                    vertices.insert(vertex);
                }
            }
            vertices.len()
        };
        let points = {
            let roster = crate::families::e5::records::e5_vertices(&scan.data, vertex_count);
            if roster.len() == vertex_count {
                roster
            } else {
                match topology.as_ref() {
                    Some(topology) => match derive_e5_vertices(ctx, topology, &surfaces, refusal) {
                        Ok(Some(derived)) => {
                            let mut points = Vec::new();
                            for point in derived {
                                // A derived vertex that is not finite states no point,
                                // so the decode refuses it where the vertex list is admitted.
                                let point = FinitePoint3::new(point)?;
                                points.push(point);
                            }
                            points
                        }
                        Ok(None) => Vec::new(),
                        Err(error) => return Some(Err(error)),
                    },
                    None => Vec::new(),
                }
            }
        };
        if let Some(topology) = &topology {
            if let Err(error) = append_e5_planes(ctx, stream, topology, &points, &mut surfaces) {
                return Some(Err(error));
            }
        }
        if circles.is_empty()
            && surfaces.is_empty()
            && rolling_ball_jets.is_empty()
            && points.is_empty()
        {
            return None;
        }
        let mut ir = CadIr::empty();
        let mut admission = FamilyEntityAdmission::new(ctx);
        let mut annotations = AnnotationBuilder::new();
        let mut unknowns = Vec::new();
        let payload_index = match preserve_raw_payload(
            ctx,
            &mut unknowns,
            &mut annotations,
            scan,
            admitted!(cadmpeg_ir::ids::UnknownId::mint("catia:payload:unknown#e5".to_owned()).map_err(cadmpeg_core::CodecError::malformed)),
        ) {
            Ok(index) => index,
            Err(error) => return Some(Err(error)),
        };
        for (index, point) in points.iter().enumerate() {
            let point_id = admitted!(crate::resource::compose_index_id(&cadmpeg_ir::identity_namespace!("catia", "e5", "pt"), index, PointId::mint));
            admitted!(annotate(&mut annotations, &point_id, "e5_0d_03", 0, "vertex_05_08_01", Exactness::ByteExact));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry
                .points
                .push(Point::new(point_id.clone(), *point, None));
            let vertex_id = admitted!(crate::resource::compose_index_id(&cadmpeg_ir::identity_namespace!("catia", "e5", "v"), index, VertexId::mint));
            admitted!(annotate(&mut annotations, &vertex_id, "MainDataStream+SurfacicReps", 0, "vertex_05_08_01", Exactness::ByteExact));
            admitted!(annotations.derived(&vertex_id, "point").map(|_| ()).map_err(cadmpeg_core::CodecError::from));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry.vertices.push(Vertex {
                id: vertex_id,
                point: point_id,
                tolerance: None,
                native_ref: None,
            });
        }
        for (index, circle) in circles.iter().enumerate() {
            let id = admitted!(crate::resource::compose_index_id(&cadmpeg_ir::identity_namespace!("catia", "e5", "curve"), index, CurveId::mint));
            admitted!(annotate(&mut annotations, &id, "e5_0d_03", u64_from_index(circle.pos), "circle_carrier", Exactness::ByteExact));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry.curves.push(Curve {
parameter_range: None,
                id,
                geometry: circle.geometry.clone(),
                source_object: None,
                native_ref: None,
            });
        }
        for (index, surface) in surfaces.iter().enumerate() {
            let id = admitted!(crate::resource::compose_index_id(&cadmpeg_ir::identity_namespace!("catia", "e5", "surf"), index, SurfaceId::mint));
            admitted!(annotate(&mut annotations, &id, "e5_0d_03", u64_from_index(surface.pos), "analytic_surface", if matches!(
                    surface.geometry,
                    SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_))
                ) {
                    Exactness::Derived
                } else {
                    Exactness::ByteExact
                }));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry.surfaces.push(Surface {
                id,
                geometry: surface.geometry.clone(),
                source_object: None,
                native_ref: None,
            });
        }
        for (index, jet) in rolling_ball_jets.iter().enumerate() {
            let surface_index = surfaces.len() + index;
            let surface_id = admitted!(crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "surf"),
                surface_index,
                SurfaceId::mint
            ));
            let procedural_id
                = admitted!(
                    crate::resource::compose_index_id(
                        &cadmpeg_ir::identity_namespace!("catia", "e5", "procedural-surf"),
                        surface_index,
                        ProceduralSurfaceId::mint
                    )
                );
            admitted!(annotate(&mut annotations, &surface_id, "e5_0d_03", u64_from_index(jet.pos), "rolling_ball_jet_carrier", Exactness::ByteExact));
            admitted!(annotations.derived(&surface_id, "geometry").map(|_| ()).map_err(cadmpeg_core::CodecError::from));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            ir.geometry.surfaces.push(Surface {
                id: surface_id.clone(),
                geometry: SurfaceGeometry::Procedural {
                    construction: procedural_id.clone(),
                    cache: None,
                },
                source_object: None,
                native_ref: None,
            });
            admitted!(annotate(&mut annotations, &procedural_id, "e5_0d_03", u64_from_index(jet.pos), "rolling_ball_jet_definition", Exactness::ByteExact));
            admitted!(annotations.derived(&procedural_id, "surface").map(|_| ()).map_err(cadmpeg_core::CodecError::from));
            admitted!(annotations.derived(&procedural_id, "definition").map(|_| ()).map_err(cadmpeg_core::CodecError::from));
            if let Err(error) = admission.charge() {
                return Some(Err(error));
            }
            let definition = jet.definition()?;
            ir.geometry.procedural_surfaces.push(ProceduralSurface::new(
                procedural_id,
                definition,
                None,
            ));
        }
        let mut topology_ir = std::mem::replace(&mut ir, CadIr::empty());
        let mut topology_annotations = annotations.copy_transaction();
        let mut original_curves = Vec::new();
        let mut unused_surfaces = Vec::new();
        let topology_transferred = if let Some(topology) = topology.as_ref() {
            original_curves = std::mem::take(&mut topology_ir.geometry.curves);
            for curve in &original_curves {
                topology_annotations.remove_entity(curve.id.as_str());
            }
            let transferred = match transfer_e5_topology(ctx,
(&mut topology_ir, &mut topology_annotations),
topology,
&surfaces,
refusal,
&mut admission,
&mut unused_surfaces) {
                Ok(transferred) => transferred,
                Err(error) => return Some(Err(error)),
            };
            if transferred {
                match neutral_model_is_admissible(ctx, &mut topology_ir, &unknowns) {
                    Ok(admissible) => admissible,
                    Err(limit) => return Some(Err(limit)),
                }
            } else {
                false
            }
        } else {
            false
        };
        if topology_transferred {
            ir = topology_ir;
            annotations = topology_annotations.into_retained();
        } else {
            if topology.is_some() {
                topology_ir.geometry.bodies.clear();
                topology_ir.geometry.regions.clear();
                topology_ir.geometry.shells.clear();
                topology_ir.geometry.faces.clear();
                topology_ir.geometry.loops.clear();
                topology_ir.geometry.coedges.clear();
                topology_ir.geometry.edges.clear();
                topology_ir.geometry.pcurves.clear();
                topology_ir.geometry.procedural_curves.clear();
                topology_ir.geometry.curves = original_curves;
                topology_ir.geometry.surfaces.append(&mut unused_surfaces);
                topology_ir.geometry.surfaces.sort_unstable_by_key(|left| e5_source_ordinal(left.id.as_str()));
                topology_ir.geometry.points.sort_unstable_by_key(|left| e5_source_ordinal(left.id.as_str()));
                topology_ir.geometry.vertices.sort_unstable_by_key(|left| e5_source_ordinal(left.id.as_str()));
            }
            ir = topology_ir;
            if !ir.geometry.vertices.is_empty() {
                if let Err(error) = attach_e5_free_vertices(&mut ir, &mut annotations, &mut admission) {
                    return Some(Err(error));
                }
            }
        }
        let mut losses = Vec::new();
        if !topology_transferred {
            losses.push((CatiaLossCode::TopologyE5GraphUnclosed).note("E5 carriers were decoded, but the reference graph could not be transferred with a closed surface/pcurve/vertex binding.".to_string()));
        }
        insert_unresolved_carrier_loss(&ir, &mut losses);
        if let Err(error) = link_payload_carriers(&ir, &mut unknowns[payload_index], &mut annotations) {
            return Some(Err(error));
        }
        let annotations = annotations.build();
        Some(Ok(FamilyOutput {
            ir,
            report: DecodeBody {
                transfer: cadmpeg_ir::report::decode::DecodeTransfer::full(true),
                coverage: cadmpeg_ir::report::decode::Coverage::default(),
                losses,
                notes: Vec::new(),
                transfer_ledger: cadmpeg_ir::report::decode::TransferLedger::default(),
            },
            annotations,
            unknowns,
            admitted_model_entities: admission.admitted(),
        }))
    })()
    .transpose()
}

fn e5_source_ordinal(id: &str) -> (bool, usize) {
    match id
        .rsplit_once('#')
        .and_then(|(_, ordinal)| ordinal.parse().ok())
    {
        Some(ordinal) => (false, ordinal),
        None => (true, 0),
    }
}

fn derive_e5_vertices(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    topology: &crate::families::e5::graph::E5Topology,
    surfaces: &[crate::families::e5::records::E5Surface],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<Vec<Point3>>, cadmpeg_core::CodecError> {
    let mut surface_for_ref = HashMap::new();
    for surface in surfaces {
        surface_for_ref.insert(surface.record_id, surface);
    }
    let mut candidates = HashMap::<u32, Vec<Point3>>::new();
    for face in &topology.faces {
        for loop_ in &face.loops {
            for member in &loop_.members {
                let pcurve_ref = member.pcurve;
                let edge_ref = member.edge_use;
                let Some(edge) = topology.edges.get(&edge_ref) else {
                    return Ok(None);
                };
                let Some(pcurve) = topology.pcurves.get(&pcurve_ref) else {
                    return Ok(None);
                };
                let surface_ref = match pcurve {
                    crate::families::e5::graph::E5Pcurve::Line { surface, .. }
                    | crate::families::e5::graph::E5Pcurve::Circle { surface, .. }
                    | crate::families::e5::graph::E5Pcurve::Jet { surface, .. }
                    | crate::families::e5::graph::E5Pcurve::Nurbs { surface, .. } => *surface,
                };
                let Some(surface) = surface_for_ref.get(&surface_ref) else {
                    return Ok(None);
                };
                let Some((_, range, endpoints)) =
                    e5_pcurve_on_surface(ctx, pcurve, surface, refusal)?
                else {
                    return Ok(None);
                };
                let Some(reversed) =
                    e5_stored_pcurve_reversed(topology, edge_ref, pcurve_ref, range)
                else {
                    return Ok(None);
                };
                let endpoints = if reversed {
                    [endpoints[1], endpoints[0]]
                } else {
                    endpoints
                };
                for (vertex, point) in [
                    (edge.start_vertex, endpoints[0]),
                    (edge.end_vertex, endpoints[1]),
                ] {
                    candidates.entry(vertex).or_default().push(point);
                }
            }
        }
    }
    let mut points = Vec::new();
    for vertex in &topology.vertex_refs {
        let Some(values) = candidates.get(vertex) else {
            return Ok(None);
        };
        let Some(point) = values.first().copied() else {
            return Ok(None);
        };
        if values
            .iter()
            .any(|candidate| candidate.distance(point) > E5_ENDPOINT_MATCH_TOLERANCE)
        {
            return Ok(None);
        }
        points.push(point);
    }
    Ok(Some(points))
}

fn append_e5_planes(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    stream: &[u8],
    topology: &crate::families::e5::graph::E5Topology,
    points: &[FinitePoint3],
    surfaces: &mut Vec<crate::families::e5::records::E5Surface>,
) -> Result<(), cadmpeg_core::CodecError> {
    let mut carrier_axes = HashMap::new();
    for surface in surfaces.iter() {
        let (axis,) = match surface.geometry {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) => {
                let axis = *cylinder_surface.frame().axis().as_raw();
                (axis,)
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)) => {
                let axis = *cone_surface.frame().axis().as_raw();
                (axis,)
            }
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)) => {
                let axis = *torus_surface.frame().axis().as_raw();
                (axis,)
            }
            _ => {
                continue;
            }
        };
        carrier_axes.insert(surface.record_id, axis);
    }
    for plane in crate::families::e5::records::e5_planes(stream) {
        let mut normal: Option<Vector3> = None;
        let mut consistent = true;
        for face in topology
            .faces
            .iter()
            .filter(|face| face.surface == plane.record_id)
        {
            for loop_ in &face.loops {
                for member in &loop_.members {
                    let Some(edge) = topology.edges.get(&member.edge_use) else {
                        consistent = false;
                        continue;
                    };
                    let Some(support) = topology.curve_supports.get(&edge.support) else {
                        consistent = false;
                        continue;
                    };
                    for pcurve_ref in support.pcurves() {
                        let Some(crate::families::e5::graph::E5Pcurve::Line {
                            surface,
                            direction,
                            ..
                        }) = topology.pcurves.get(pcurve_ref)
                        else {
                            continue;
                        };
                        if direction[0].get().abs() <= EPS_E5_DECODE_GEOMETRY
                            || direction[1].get().abs() > EPS_E5_DECODE_GEOMETRY
                        {
                            continue;
                        }
                        let Some(&candidate) = carrier_axes.get(surface) else {
                            continue;
                        };
                        let candidate = canonical_direction(candidate);
                        if normal.is_some_and(|value| {
                            value.x * candidate.x + value.y * candidate.y + value.z * candidate.z
                                < 1.0 - EPS_E5_DECODE_DEGENERATE
                        }) {
                            consistent = false;
                        } else {
                            normal = Some(candidate);
                        }
                    }
                }
            }
        }
        let expected_normal = normal.filter(|_| consistent);
        let Some((normal, u_axis, uv_scale)) = solve_e5_plane_frame(
            ctx,
            plane.record_id,
            plane.origin,
            topology,
            points,
            expected_normal,
        )?
        else {
            continue;
        };
        let Some(frame) = OrthonormalFrame3::from_units(normal, u_axis) else {
            continue;
        };
        let payload = cadmpeg_ir::geometry::analytic::PlaneSurface::new(plane.origin, frame);
        surfaces.push(crate::families::e5::records::E5Surface {
            pos: plane.pos,
            record_id: plane.record_id,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(payload)),
            uv_scale,
        });
    }
    Ok(())
}

/// Classify two UV vectors by a scale-normalized determinant.
///
/// A tiny transverse component is common after a circular or spline boundary
/// is serialized as a line-like endpoint tape. Treating that roundoff as a
/// second rank would send plane fitting through an ill-conditioned 2D solve;
/// the known geometric normal must select the rank-one path instead.
fn e5_uv_vectors_are_independent(left: FiniteVector<2>, right: FiniteVector<2>) -> bool {
    const RANK_TOLERANCE: f64 = EPS_E5_DECODE_EXACT_GEOMETRY;
    let scale = left
        .into_iter()
        .chain(right)
        .map(f64::abs)
        .fold(0.0_f64, f64::max);
    if scale == 0.0 {
        return false;
    }
    let left = [left[0] / scale, left[1] / scale];
    let right = [right[0] / scale, right[1] / scale];
    (left[0] * right[1] - left[1] * right[0]).abs() > RANK_TOLERANCE
}

fn solve_e5_plane_frame(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface_ref: u32,
    origin: FinitePoint3,
    topology: &crate::families::e5::graph::E5Topology,
    points: &[FinitePoint3],
    expected_normal: Option<Vector3>,
) -> Result<Option<(UnitVector3, UnitVector3, [FiniteReal; 2])>, cadmpeg_core::CodecError> {
    if topology.vertex_refs.len() != points.len() {
        return Ok(None);
    }
    let mut point_by_ref = HashMap::new();
    for (reference, point) in topology
        .vertex_refs
        .iter()
        .copied()
        .zip(points.iter().copied())
    {
        point_by_ref.insert(reference, point);
    }
    let mut segments = Vec::new();
    for face in topology
        .faces
        .iter()
        .filter(|face| face.surface == surface_ref)
    {
        for loop_ in &face.loops {
            for member in &loop_.members {
                let pcurve_ref = member.pcurve;
                let edge_ref = member.edge_use;
                let Some(edge) = topology.edges.get(&edge_ref) else {
                    return Ok(None);
                };
                let Some(pcurve) = topology.pcurves.get(&pcurve_ref) else {
                    return Ok(None);
                };
                let Some(uv) = e5_native_uv_endpoints(ctx, pcurve)? else {
                    return Ok(None);
                };
                let (Some(start), Some(end)) = (
                    point_by_ref.get(&edge.start_vertex),
                    point_by_ref.get(&edge.end_vertex),
                ) else {
                    return Ok(None);
                };
                segments.push((uv, [*start, *end]));
            }
        }
    }
    if segments.is_empty() {
        return Ok(None);
    }

    let anchors = 'find_anchors: {
        let mut basis = None;
        for (index, (uv, _)) in segments.iter().enumerate() {
            for endpoint in uv {
                if let Some((basis_index, basis_uv)) = basis {
                    if e5_uv_vectors_are_independent(basis_uv, *endpoint) {
                        break 'find_anchors Some((
                            [basis_index, index],
                            if basis_index == index { 1 } else { 2 },
                        ));
                    }
                } else if endpoint[0] != 0.0 || endpoint[1] != 0.0 {
                    basis = Some((index, *endpoint));
                }
            }
        }
        None
    };
    let endpoint_pairs = |segment: &([FiniteVector<2>; 2], [FinitePoint3; 2]), reversed: bool| {
        let points = if reversed {
            [segment.1[1], segment.1[0]]
        } else {
            segment.1
        };
        [(segment.0[0], points[0]), (segment.0[1], points[1])]
    };
    let endpoint_error = |axes: (Vector3, Vector3),
                          segment: &([FiniteVector<2>; 2], [FinitePoint3; 2]),
                          reversed: bool| {
        plane_frame_residual(
            origin.get().into(),
            &endpoint_pairs(segment, reversed),
            axes.0,
            axes.1,
        )
    };

    let mut fitted_axes = Vec::new();
    if let Some((anchor_indices, anchor_count)) = anchors {
        let anchors = &anchor_indices[..anchor_count];
        for mask in 0usize..(1usize << anchors.len()) {
            let mut orientations =
                ctx.alloc_filled(segments.len(), false, "catia_e5_plane_orientations")?;
            for (bit, &index) in anchors.iter().enumerate() {
                orientations[index] = mask & (1 << bit) != 0;
            }
            let mut seed_pairs = Vec::new();

            for &index in anchors {
                seed_pairs.extend(endpoint_pairs(&segments[index], orientations[index]));
            }
            let Some((seed_u, seed_v, _)) = fit_e5_plane_axes(origin, &seed_pairs) else {
                continue;
            };
            for (index, segment) in segments.iter().enumerate() {
                if anchors.contains(&index) {
                    continue;
                }
                orientations[index] = endpoint_error((seed_u, seed_v), segment, true)
                    < endpoint_error((seed_u, seed_v), segment, false);
            }
            let mut pairs = Vec::new();

            for (segment, &reversed) in segments.iter().zip(&orientations) {
                pairs.extend(endpoint_pairs(segment, reversed));
            }
            if let Some(fit) = fit_e5_plane_axes(origin, &pairs) {
                fitted_axes.push((fit, pairs));
            }
        }
    } else {
        let Some(normal) = expected_normal else {
            return Ok(None);
        };
        let Some(seed_index) = segments.iter().enumerate().find_map(|(index, (uv, _))| {
            uv.iter()
                .any(|point| point[0] != 0.0 || point[1] != 0.0)
                .then_some(index)
        }) else {
            return Ok(None);
        };
        for seed_reversed in [false, true] {
            let seed_pairs = endpoint_pairs(&segments[seed_index], seed_reversed);
            let Some((seed_u, seed_v, _)) = fit_rank_one_e5_plane_axes(origin, &seed_pairs, normal)
            else {
                continue;
            };
            let mut orientations =
                ctx.alloc_filled(segments.len(), false, "catia_e5_plane_orientations")?;
            orientations[seed_index] = seed_reversed;
            for (index, segment) in segments.iter().enumerate() {
                if index == seed_index {
                    continue;
                }
                orientations[index] = endpoint_error((seed_u, seed_v), segment, true)
                    < endpoint_error((seed_u, seed_v), segment, false);
            }
            let mut pairs = Vec::new();

            for (segment, &reversed) in segments.iter().zip(&orientations) {
                pairs.extend(endpoint_pairs(segment, reversed));
            }
            if let Some(fit) = fit_rank_one_e5_plane_axes(origin, &pairs, normal) {
                fitted_axes.push((fit, pairs));
            }
        }
    }

    let mut candidates: Vec<(UnitVector3, UnitVector3)> = Vec::new();
    for ((u_axis, v_axis, residual), pairs) in fitted_axes {
        let Some(u_axis) = unit_vector(u_axis) else {
            continue;
        };
        let Some(v_axis) = unit_vector(v_axis) else {
            continue;
        };
        let orthogonality = u_axis.as_raw().dot(*v_axis.as_raw());
        if !residual.is_finite()
            || !orthogonality.is_finite()
            || residual > 2e-3
            || orthogonality.abs() > EPS_E5_DECODE_COARSE_GEOMETRY
        {
            continue;
        }
        let (u, v) = (u_axis.as_raw(), v_axis.as_raw());
        let Some(normal) = unit_vector(Vector3::new(
            u.y * v.z - u.z * v.y,
            u.z * v.x - u.x * v.z,
            u.x * v.y - u.y * v.x,
        )) else {
            continue;
        };
        // The returned chart uses unit axes and derives v from normal x u.
        // Validate that chart, not the unrestricted least-squares fit.
        let residual = plane_frame_residual(
            origin.get().into(),
            &pairs,
            *u_axis.as_raw(),
            normal.as_raw().cross(*u_axis.as_raw()),
        );
        if !residual.is_finite() || residual > E5_ENDPOINT_MATCH_TOLERANCE {
            continue;
        }
        if expected_normal.is_some_and(|expected| {
            let alignment = normal.as_raw().dot(expected);
            !alignment.is_finite() || alignment.abs() < 1.0 - EPS_E5_DECODE_COARSE_GEOMETRY
        }) {
            continue;
        }
        if !candidates.iter().any(|(existing_normal, existing_u)| {
            existing_normal.as_raw().dot(*normal.as_raw()) > 1.0 - EPS_AXIS_ALIGN
                && existing_u.as_raw().dot(*u_axis.as_raw()) > 1.0 - EPS_AXIS_ALIGN
        }) {
            candidates.push((normal, u_axis));
        }
    }
    let mut canonical: Vec<(UnitVector3, UnitVector3, [FiniteReal; 2])> = Vec::new();
    for (normal, mut u_axis) in candidates {
        let Some(first) = [u_axis.as_raw().x, u_axis.as_raw().y, u_axis.as_raw().z]
            .into_iter()
            .find(|value| value.abs() > EPS_E5_DECODE_EXACT_GEOMETRY)
        else {
            return Ok(None);
        };
        let uv_scale = if first < 0.0 {
            u_axis = u_axis.reversed();
            [FiniteReal::ONE.negated(); 2]
        } else {
            [FiniteReal::ONE; 2]
        };
        if !canonical.iter().any(|(existing_normal, existing_u, _)| {
            existing_normal.as_raw().dot(*normal.as_raw()) > 1.0 - EPS_AXIS_ALIGN
                && existing_u.as_raw().dot(*u_axis.as_raw()) > 1.0 - EPS_AXIS_ALIGN
        }) {
            canonical.push((normal, u_axis, uv_scale));
        }
    }
    Ok((canonical.len() == 1).then(|| canonical[0]))
}

fn e5_native_uv_endpoints(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    pcurve: &crate::families::e5::graph::E5Pcurve,
) -> Result<Option<[FiniteVector<2>; 2]>, cadmpeg_core::CodecError> {
    let finite = |[start, end]: [[f64; 2]; 2]| {
        let (Some(start), Some(end)) = (FiniteVector::new(start), FiniteVector::new(end)) else {
            return None;
        };
        Some([start, end])
    };
    match pcurve {
        crate::families::e5::graph::E5Pcurve::Line {
            origin,
            direction,
            range,
            ..
        } => Ok(finite(range.map(|parameter| {
            [
                origin[0].get() + parameter.get() * direction[0].get(),
                origin[1].get() + parameter.get() * direction[1].get(),
            ]
        }))),
        crate::families::e5::graph::E5Pcurve::Circle {
            center,
            radius,
            range,
            ..
        } => Ok(finite(range.map(|parameter| {
            let radius = radius.get();
            let angle = parameter.get() / radius;
            [
                center[0].get() + radius * angle.cos(),
                center[1].get() + radius * angle.sin(),
            ]
        }))),
        crate::families::e5::graph::E5Pcurve::Jet { sites, .. } => {
            Ok(sites.first().zip(sites.last()).map(|(first, last)| {
                [
                    FiniteVector::from(first.point),
                    FiniteVector::from(last.point),
                ]
            }))
        }
        crate::families::e5::graph::E5Pcurve::Nurbs {
            degree,
            knots,
            control_points,
            range,
            ..
        } => {
            let mut scalar_knots = Vec::new();

            scalar_knots.extend(knots.iter().copied().map(FiniteReal::get));
            let mut scalar_controls = Vec::new();

            scalar_controls.extend(
                control_points
                    .iter()
                    .map(|[u, v]| Point2::new(u.get(), v.get())),
            );
            let start = cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::nurbs_pcurve_uv(
                ctx,
                *degree,
                &scalar_knots,
                &scalar_controls,
                None,
                range[0].get(),
            ))?;
            let end = cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::nurbs_pcurve_uv(
                ctx,
                *degree,
                &scalar_knots,
                &scalar_controls,
                None,
                range[1].get(),
            ))?;
            Ok(start
                .zip(end)
                .map(|(start, end)| [start.into(), end.into()]))
        }
    }
}

fn fit_e5_plane_axes(
    origin: FinitePoint3,
    pairs: &[(FiniteVector<2>, FinitePoint3)],
) -> Option<(Vector3, Vector3, f64)> {
    let origin: [f64; 3] = origin.get().into();
    let uv_scale = pairs
        .iter()
        .flat_map(|(uv, _)| uv.iter())
        .map(|value| value.abs())
        .fold(0.0_f64, f64::max);
    if !uv_scale.is_finite() || uv_scale == 0.0 {
        return None;
    }
    let normalized_uv = |uv: FiniteVector<2>| [uv[0] / uv_scale, uv[1] / uv_scale];
    let suu = pairs
        .iter()
        .map(|(uv, _)| normalized_uv(*uv)[0].powi(2))
        .sum::<f64>();
    let suv = pairs
        .iter()
        .map(|(uv, _)| {
            let uv = normalized_uv(*uv);
            uv[0] * uv[1]
        })
        .sum::<f64>();
    let svv = pairs
        .iter()
        .map(|(uv, _)| normalized_uv(*uv)[1].powi(2))
        .sum::<f64>();
    let determinant = suu * svv - suv * suv;
    let covariance_scale = suu.max(svv);
    let rank_tolerance = f64::EPSILON * covariance_scale * covariance_scale;
    if !determinant.is_finite()
        || !covariance_scale.is_finite()
        || covariance_scale == 0.0
        || determinant <= rank_tolerance
    {
        return None;
    }
    let mut u = [0.0; 3];
    let mut v = [0.0; 3];
    for axis in 0..3 {
        let bu = pairs
            .iter()
            .map(|(uv, point)| {
                normalized_uv(*uv)[0] * ([point.x, point.y, point.z][axis] - origin[axis])
            })
            .sum::<f64>();
        let bv = pairs
            .iter()
            .map(|(uv, point)| {
                normalized_uv(*uv)[1] * ([point.x, point.y, point.z][axis] - origin[axis])
            })
            .sum::<f64>();
        u[axis] = (bu * svv - bv * suv) / determinant / uv_scale;
        v[axis] = (suu * bv - suv * bu) / determinant / uv_scale;
    }
    if u.into_iter().chain(v).any(|value| !value.is_finite()) {
        return None;
    }
    let u_axis = Vector3::from(u);
    let v_axis = Vector3::from(v);
    let residual = plane_frame_residual(origin, pairs, u_axis, v_axis);
    residual.is_finite().then_some((u_axis, v_axis, residual))
}

fn fit_rank_one_e5_plane_axes(
    origin: FinitePoint3,
    pairs: &[(FiniteVector<2>, FinitePoint3)],
    normal: Vector3,
) -> Option<(Vector3, Vector3, f64)> {
    let origin: [f64; 3] = origin.get().into();
    let (uv, point) = pairs.iter().find(|(uv, _)| {
        let norm = uv[0].hypot(uv[1]);
        norm.is_finite() && norm != 0.0
    })?;
    let uv_norm = uv[0].hypot(uv[1]);
    let q = [uv[0] / uv_norm, uv[1] / uv_norm];
    let displacement = Vector3::new(
        point.x - origin[0],
        point.y - origin[1],
        point.z - origin[2],
    );
    let displacement_norm = displacement.x.hypot(displacement.y).hypot(displacement.z);
    if (displacement_norm - uv_norm).abs() > 2e-3 {
        return None;
    }
    let mapped_q = unit_vector(displacement)?;
    let q_direction = mapped_q.as_raw();
    let mapped_r = unit_vector(Vector3::new(
        normal.y * q_direction.z - normal.z * q_direction.y,
        normal.z * q_direction.x - normal.x * q_direction.z,
        normal.x * q_direction.y - normal.y * q_direction.x,
    ))?;
    let r_direction = mapped_r.as_raw();
    let u_axis = Vector3::new(
        q[0] * q_direction.x - q[1] * r_direction.x,
        q[0] * q_direction.y - q[1] * r_direction.y,
        q[0] * q_direction.z - q[1] * r_direction.z,
    );
    let v_axis = Vector3::new(
        q[1] * q_direction.x + q[0] * r_direction.x,
        q[1] * q_direction.y + q[0] * r_direction.y,
        q[1] * q_direction.z + q[0] * r_direction.z,
    );
    let residual = plane_frame_residual(origin, pairs, u_axis, v_axis);
    residual.is_finite().then_some((u_axis, v_axis, residual))
}

fn plane_frame_residual(
    origin: [f64; 3],
    pairs: &[(FiniteVector<2>, FinitePoint3)],
    u_axis: Vector3,
    v_axis: Vector3,
) -> f64 {
    pairs.iter().fold(0.0f64, |residual, (uv, point)| {
        let predicted = [
            origin[0] + uv[0] * u_axis.x + uv[1] * v_axis.x,
            origin[1] + uv[0] * u_axis.y + uv[1] * v_axis.y,
            origin[2] + uv[0] * u_axis.z + uv[1] * v_axis.z,
        ];
        let error = distance(predicted, point.get().into());
        if error.is_finite() {
            residual.max(error)
        } else {
            f64::INFINITY
        }
    })
}

fn canonical_direction(mut direction: Vector3) -> Vector3 {
    let first = [direction.x, direction.y, direction.z]
        .into_iter()
        .find(|value| value.abs() > EPS_E5_DECODE_EXACT_GEOMETRY)
        .unwrap_or(1.0);
    if first < 0.0 {
        direction = Vector3::new(-direction.x, -direction.y, -direction.z);
    }
    direction
}

fn attach_e5_free_vertices(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    let body_id = BodyId::mint("catia:e5:body#unbound-points".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let region_id = RegionId::mint("catia:e5:region#unbound-points".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let shell_id = ShellId::mint("catia:e5:shell#unbound-points".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    for id in [body_id.as_str(), region_id.as_str(), shell_id.as_str()] {
        annotate(
            annotations,
            id,
            "e5_0d_03",
            0,
            "unbound_point_owner",
            Exactness::Inferred,
        )?;
    }
    let shells = vec![shell_id.clone()];
    let free_vertices = ir
        .geometry
        .vertices
        .iter()
        .map(|vertex| vertex.id.clone())
        .collect::<Vec<_>>();
    admission.charge()?;
    ir.geometry.bodies.push(Body {
        id: body_id.clone(),
        kind: BodyKind::Wire,
        transform: None,
        name: None,
        color: None,
        visible: None,
        native_ref: None,
    });
    admission.charge()?;
    ir.geometry.regions.push(Region {
        id: region_id.clone(),
        body: body_id,
        shells,
        native_ref: None,
    });
    admission.charge()?;
    if free_vertices.is_empty() {
        return Ok(());
    }
    ir.geometry.shells.push(Shell::with_members(
        shell_id,
        region_id,
        Vec::new(),
        free_vertices,
    ));
    Ok(())
}

struct E5IntersectionSidePlan {
    surface: SurfaceId,
    pcurve: PcurveGeometry,
    pcurve_range: [f64; 2],
    curve: CurveGeometry,
    curve_range: [f64; 2],
}

#[derive(Clone)]
struct E5OccurrenceIntersectionSide {
    pcurve_record: u32,
    surface: SurfaceId,
    pcurve: PcurveGeometry,
    pcurve_range: [f64; 2],
    curve: Option<(CurveGeometry, [f64; 2])>,
}

/// Boundary lowering plan built by [`plan_e5_boundary`].
struct E5BoundaryPlan<'a> {
    faces: Vec<E5FacePlan<'a>>,
    pcurves: BTreeMap<u32, (PcurveGeometry, [f64; 2])>,
    /// Whether each native pcurve occurrence runs opposite to its edge's
    /// stored endpoint order.
    pcurve_use_reversed: BTreeMap<(u32, usize), bool>,
    edge_curves: BTreeMap<u32, (CurveGeometry, [f64; 2])>,
    surface_curves: BTreeMap<u32, (SurfaceId, PcurveGeometry, [f64; 2])>,
    intersections: BTreeMap<u32, IntcurveSupportContext>,
}

struct E5FacePlan<'a> {
    source: &'a crate::families::e5::graph::E5Face,
    loops: Vec<E5LoopPlan<'a>>,
    sense: Sense,
}

struct E5LoopPlan<'a> {
    source: &'a crate::families::e5::graph::E5Loop,
    members: Vec<E5MemberPlan<'a>>,
}

struct E5MemberPlan<'a> {
    source: &'a crate::families::e5::graph::E5LoopMember,
    orientation: &'a crate::families::e5::graph::E5OrientedMember,
    id: CoedgeId,
}

impl<'a> E5LoopPlan<'a> {
    fn admit(source: &'a crate::families::e5::graph::E5Loop) -> Option<Self> {
        let oriented = source.resolved_members()?;
        if source.members.is_empty() || oriented.len() != source.members.len() {
            return None;
        }
        let mut seen = HashSet::new();
        let mut members = Vec::new();
        for orientation in oriented {
            let member = source.members.get(orientation.serialized_index)?;
            if !seen.insert(orientation.serialized_index) {
                return None;
            }
            members.push(E5MemberPlan {
                source: member,
                orientation,
                id: CoedgeId::compose(
                    &cadmpeg_ir::identity_namespace!("catia", "e5", "coedge"),
                    cadmpeg_ir::ids::IdentityKey::from(source.record_id)
                        .dash(orientation.serialized_index),
                ),
            });
        }
        Some(Self { source, members })
    }
}

/// Body/region/shell ownership resolved by [`resolve_e5_ownership`].
struct E5Ownership {
    bodies: Vec<E5BodyPlan>,
    face_shell: HashMap<u32, ShellId>,
}

fn transfer_e5_topology(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    (ir, annotations): (
        &mut CadIr,
        &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    ),
    topology: &crate::families::e5::graph::E5Topology,
    decoded_surfaces: &[crate::families::e5::records::E5Surface],
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
    unused_surfaces: &mut Vec<Surface>,
) -> Result<bool, cadmpeg_core::CodecError> {
    if topology.vertex_refs.len() != ir.geometry.vertices.len()
        || topology.vertex_refs.len() != ir.geometry.points.len()
        || topology.vertex_refs.is_empty()
    {
        return Ok(false);
    }

    for curve in ir.geometry.curves.drain(..) {
        annotations.remove_entity(curve.id.as_str());
    }

    let mut surface_for_ref = HashMap::new();
    for (index, surface) in decoded_surfaces.iter().enumerate() {
        surface_for_ref.insert(
            surface.record_id,
            (
                crate::resource::compose_index_id(
                    &cadmpeg_ir::identity_namespace!("catia", "e5", "surf"),
                    index,
                    SurfaceId::mint,
                )?,
                surface,
            ),
        );
    }
    let mut vertex_for_ref = HashMap::new();
    for (index, reference) in topology.vertex_refs.iter().copied().enumerate() {
        vertex_for_ref.insert(
            reference,
            crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "v"),
                index,
                VertexId::mint,
            )?,
        );
    }
    let mut point_for_ref = HashMap::new();
    for (reference, point) in topology
        .vertex_refs
        .iter()
        .copied()
        .zip(&ir.geometry.points)
    {
        point_for_ref.insert(reference, point.position().get());
    }

    let Some(mut boundary) =
        plan_e5_boundary(ctx, topology, &surface_for_ref, &point_for_ref, refusal)?
    else {
        return Ok(false);
    };
    for face in &mut boundary.faces {
        for _body in &topology.bodies {}
        let Some(root) = topology
            .bodies
            .iter()
            .flat_map(|body| &body.faces)
            .find(|occurrence| occurrence.record_id == face.source.record_id)
        else {
            return Ok(false);
        };
        if root.orientation == crate::families::e5::graph::Sign::Negative {
            face.sense = match face.sense {
                Sense::Forward => Sense::Reversed,
                Sense::Reversed => Sense::Forward,
            };
        }
        let Some((_, decoded_surface)) = surface_for_ref.get(&face.source.surface) else {
            return Ok(false);
        };
        if let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane)) =
            &decoded_surface.geometry
        {
            let mut face_sense = None;
            for loop_ in &face.loops {
                let Some(sense) = e5_plane_boundary_sense(plane, loop_, &boundary.edge_curves)
                else {
                    return Ok(false);
                };
                if face_sense.is_some_and(|existing| existing != sense) {
                    return Ok(false);
                }
                face_sense = Some(sense);
            }
            let Some(sense) = face_sense else {
                return Ok(false);
            };
            face.sense = sense;
        }
    }
    prune_e5_unused_surfaces(
        ir,
        annotations,
        topology,
        &surface_for_ref,
        (&boundary.intersections, &boundary.surface_curves),
        unused_surfaces,
    );

    let Some(e5_ownership) = resolve_e5_ownership(ctx, topology)? else {
        return Ok(false);
    };
    let E5Ownership { bodies, face_shell } = e5_ownership;

    let mut edge_ids = HashMap::new();
    for record_id in topology.edges.keys().copied() {
        edge_ids.insert(
            record_id,
            crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "edge"),
                record_id,
                EdgeId::mint,
            )?,
        );
    }
    if let Err(error) =
        emit_e5_curves_and_edges(crate::families::e5::decode::EmitE5CurvesAndEdgesInputs {
            ir,
            annotations,
            topology,
            vertex_for_ref: &vertex_for_ref,
            edge_ids: &edge_ids,
            edge_curves: &boundary.edge_curves,
            intersections: &boundary.intersections,
            surface_curves: &boundary.surface_curves,
            admission,
        })
    {
        return match error {
            cadmpeg_core::CodecError::ResourceLimit(_) => Err(error),
            _ => Ok(false),
        };
    }
    if let Err(error) = emit_e5_pcurves(ir, annotations, &boundary.pcurves, admission) {
        return match error {
            cadmpeg_core::CodecError::ResourceLimit(_) => Err(error),
            _ => Ok(false),
        };
    }
    if let Err(error) = emit_e5_bodies(ir, annotations, &bodies, admission) {
        return match error {
            cadmpeg_core::CodecError::ResourceLimit(_) => Err(error),
            _ => Ok(false),
        };
    }
    if !emit_e5_faces_loops_coedges(crate::families::e5::decode::EmitE5FacesLoopsCoedgesInputs {
        ir,
        annotations,
        topology,
        surface_for_ref: &surface_for_ref,
        face_shell: &face_shell,
        edge_ids: &edge_ids,
        vertex_for_ref: &vertex_for_ref,
        boundary: &boundary,
        admission,
    })? {
        return Ok(false);
    }
    Ok(true)
}

/// Lowers every face loop to boundary curves, pcurves, and intersection contexts,
/// or returns `None` when any binding fails admission.
fn plan_e5_boundary<'a>(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    topology: &'a crate::families::e5::graph::E5Topology,
    surface_for_ref: &HashMap<u32, (SurfaceId, &crate::families::e5::records::E5Surface)>,
    point_for_ref: &HashMap<u32, Point3>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<E5BoundaryPlan<'a>>, cadmpeg_core::CodecError> {
    let mut faces = Vec::new();
    for face in &topology.faces {
        let mut loops = Vec::new();
        for source in &face.loops {
            let Some(loop_plan) = E5LoopPlan::admit(source) else {
                return Ok(None);
            };
            loops.push(loop_plan);
        }
        faces.push(E5FacePlan {
            source: face,
            loops,
            sense: if face.trailer_sign == crate::families::e5::graph::Sign::Positive {
                Sense::Forward
            } else {
                Sense::Reversed
            },
        });
    }
    let mut pcurves = BTreeMap::<u32, (PcurveGeometry, [f64; 2])>::new();
    let mut pcurve_use_reversed = BTreeMap::<(u32, usize), bool>::new();
    let mut edge_curves = BTreeMap::<u32, (CurveGeometry, [f64; 2])>::new();
    let mut surface_curves = BTreeMap::<u32, (SurfaceId, PcurveGeometry, [f64; 2])>::new();
    let mut occurrence_intersection_sides =
        BTreeMap::<u32, Vec<E5OccurrenceIntersectionSide>>::new();
    for face in &topology.faces {
        let Some((_, decoded_surface)) = surface_for_ref.get(&face.surface) else {
            return Ok(None);
        };
        for loop_ in &face.loops {
            for (member_index, member) in loop_.members.iter().enumerate() {
                let pcurve_ref = member.pcurve;
                let edge_ref = member.edge_use;
                let Some(edge) = topology.edges.get(&edge_ref) else {
                    return Ok(None);
                };
                let Some(support) = topology.curve_supports.get(&edge.support) else {
                    return Ok(None);
                };
                let Some(pcurve) = topology.pcurves.get(&pcurve_ref) else {
                    return Ok(None);
                };
                let Some((geometry, range, endpoints)) =
                    e5_pcurve_on_surface(ctx, pcurve, decoded_surface, refusal)?
                else {
                    return Ok(None);
                };
                let (Some(start), Some(end)) = (
                    point_for_ref.get(&edge.start_vertex),
                    point_for_ref.get(&edge.end_vertex),
                ) else {
                    return Ok(None);
                };
                let forward = endpoints[0]
                    .distance(*start)
                    .max(endpoints[1].distance(*end));
                let reverse_error = endpoints[0]
                    .distance(*end)
                    .max(endpoints[1].distance(*start));
                // A degenerate native bound has no parameter sign. Endpoint
                // positions are an independent constraint, but they only
                // select a direction when exactly one order meets the model
                // tolerance. Never choose the smaller of two failing errors.
                let reversed = e5_stored_pcurve_reversed(topology, edge_ref, pcurve_ref, range)
                    .or_else(|| unique_endpoint_direction(forward, reverse_error));
                let Some(reversed) = reversed else {
                    return Ok(None);
                };
                if pcurve_use_reversed
                    .insert((loop_.record_id, member_index), reversed)
                    .is_some()
                {
                    return Ok(None);
                }
                if if reversed { reverse_error } else { forward } > E5_ENDPOINT_MATCH_TOLERANCE {
                    return Ok(None);
                }
                let oriented_pcurve = if reversed {
                    let record = format!(
                        "e5 boundary pcurve of loop record {} member {member_index}",
                        loop_.record_id
                    );
                    let Some(reversed) =
                        crate::nurbs::reverse_pcurve_geometry(&geometry, range, refusal, &record)
                    else {
                        return Ok(None);
                    };
                    reversed
                } else {
                    geometry.clone()
                };
                let lifted_curve = if let Some((mut curve, mut curve_range)) = e5_boundary_curve(
                    ctx,
                    &decoded_surface.geometry,
                    pcurve,
                    &geometry,
                    (range, endpoints),
                    decoded_surface.uv_scale,
                    refusal,
                )? {
                    if reversed {
                        let record = format!(
                            "e5 boundary curve of loop record {} member {member_index}",
                            loop_.record_id
                        );
                        let Some(reversed_curve) = crate::nurbs::reverse_curve_geometry(
                            &curve,
                            curve_range,
                            refusal,
                            &record,
                        ) else {
                            return Ok(None);
                        };
                        (curve, curve_range) = reversed_curve;
                    }
                    Some((curve, curve_range))
                } else {
                    None
                };
                if support.is_intersection() {
                    let side = E5OccurrenceIntersectionSide {
                        pcurve_record: pcurve_ref,
                        surface: surface_for_ref[&face.surface].0.clone(),
                        pcurve: oriented_pcurve.clone(),
                        pcurve_range: range,
                        curve: lifted_curve
                            .as_ref()
                            .map(|(curve, range)| (curve.clone(), *range)),
                    };

                    let sides = occurrence_intersection_sides.entry(edge_ref).or_default();
                    if !sides.iter().any(|existing| {
                        existing.pcurve_record == side.pcurve_record
                            && existing.surface == side.surface
                            && existing.pcurve == side.pcurve
                            && existing.pcurve_range == side.pcurve_range
                    }) {
                        sides.push(side);
                    }
                }
                if let Some((curve, curve_range)) = lifted_curve {
                    if !support.is_intersection() {
                        if let Some(existing) = edge_curves.get(&edge_ref) {
                            if existing != &(curve, curve_range) {
                                return Ok(None);
                            }
                        } else {
                            edge_curves.insert(edge_ref, (curve, curve_range));
                        }
                    }
                } else if !support.is_intersection() && !surface_curves.contains_key(&edge_ref) {
                    let surface_id = surface_for_ref[&face.surface].0.clone();
                    surface_curves.insert(edge_ref, (surface_id, oriented_pcurve, range));
                }
                if let Some((existing, existing_range)) = pcurves.get(&pcurve_ref) {
                    if existing != &geometry || existing_range != &range {
                        return Ok(None);
                    }
                } else {
                    pcurves.insert(pcurve_ref, (geometry, range));
                }
            }
        }
    }
    let mut intersection_sides = BTreeMap::<u32, BTreeMap<u32, E5IntersectionSidePlan>>::new();
    for (&edge_ref, edge) in &topology.edges {
        let Some(support) = topology.curve_supports.get(&edge.support) else {
            return Ok(None);
        };
        if !support.is_intersection() {
            continue;
        }
        let (Some(start), Some(end)) = (
            point_for_ref.get(&edge.start_vertex),
            point_for_ref.get(&edge.end_vertex),
        ) else {
            return Ok(None);
        };
        for pcurve_ref in support.pcurves() {
            let Some(pcurve) = topology.pcurves.get(pcurve_ref) else {
                continue;
            };
            let surface_ref = match pcurve {
                crate::families::e5::graph::E5Pcurve::Line { surface, .. }
                | crate::families::e5::graph::E5Pcurve::Circle { surface, .. }
                | crate::families::e5::graph::E5Pcurve::Jet { surface, .. }
                | crate::families::e5::graph::E5Pcurve::Nurbs { surface, .. } => *surface,
            };
            let Some((surface_id, decoded_surface)) = surface_for_ref.get(&surface_ref) else {
                continue;
            };
            let Some((geometry, range, endpoints)) =
                e5_pcurve_on_surface(ctx, pcurve, decoded_surface, refusal)?
            else {
                // A known intersection pcurve that cannot be normalized must
                // reject the topology route; omitting one side would claim a
                // closed graph with incomplete carrier geometry.
                return Ok(None);
            };
            let forward = endpoints[0]
                .distance(*start)
                .max(endpoints[1].distance(*end));
            let reverse_error = endpoints[0]
                .distance(*end)
                .max(endpoints[1].distance(*start));
            let reversed = e5_stored_pcurve_reversed(topology, edge_ref, *pcurve_ref, range)
                .or_else(|| unique_endpoint_direction(forward, reverse_error));
            let Some(reversed) = reversed else {
                continue;
            };
            if if reversed { reverse_error } else { forward } > E5_ENDPOINT_MATCH_TOLERANCE {
                continue;
            }
            let Some((mut curve, mut curve_range)) = e5_boundary_curve(
                ctx,
                &decoded_surface.geometry,
                pcurve,
                &geometry,
                (range, endpoints),
                decoded_surface.uv_scale,
                refusal,
            )?
            else {
                continue;
            };
            if reversed {
                let record = format!("e5 boundary curve of edge {edge_ref} pcurve {pcurve_ref}");
                let Some(reversed_curve) =
                    crate::nurbs::reverse_curve_geometry(&curve, curve_range, refusal, &record)
                else {
                    continue;
                };
                (curve, curve_range) = reversed_curve;
            }
            let pcurve = if reversed {
                let record = format!("e5 boundary pcurve of edge {edge_ref} pcurve {pcurve_ref}");
                let Some(reversed) =
                    crate::nurbs::reverse_pcurve_geometry(&geometry, range, refusal, &record)
                else {
                    continue;
                };
                reversed
            } else {
                geometry
            };

            intersection_sides.entry(edge_ref).or_default().insert(
                *pcurve_ref,
                E5IntersectionSidePlan {
                    surface: surface_id.clone(),
                    pcurve,
                    pcurve_range: range,
                    curve,
                    curve_range,
                },
            );
        }
    }

    let mut intersections = BTreeMap::<u32, IntcurveSupportContext>::new();
    for (&edge_ref, sides) in &intersection_sides {
        let Some(edge) = topology.edges.get(&edge_ref) else {
            return Ok(None);
        };
        let Some(support) = topology.curve_supports.get(&edge.support) else {
            return Ok(None);
        };
        let [left_ref, right_ref] = support.pcurves() else {
            continue;
        };
        let (Some(left), Some(right)) = (sides.get(left_ref), sides.get(right_ref)) else {
            continue;
        };
        // Rational UV arcs and spline facets do not have an affine angle
        // parameterization, even when their lifted locus is a circle.
        if !matches!(left.pcurve, PcurveGeometry::Line(_))
            || !matches!(right.pcurve, PcurveGeometry::Line(_))
        {
            continue;
        }
        let same_parameterization =
            parameter_range_agreement_tolerance(left.curve_range, right.curve_range).is_some();
        let same_carrier = equivalent_e5_curve_carriers(&left.curve, &right.curve);
        let same_ordered_sweep = e5_circle_carriers_have_same_ordered_sweep(
            ctx,
            &left.curve,
            left.curve_range,
            &right.curve,
            right.curve_range,
        )?;
        if !(same_carrier && same_parameterization || same_ordered_sweep) {
            continue;
        }
        edge_curves.insert(edge_ref, (left.curve.clone(), left.curve_range));
        let sides = [left, right].map(|side| IntcurveSupportSide {
            surface: Some(side.surface.clone()),
            pcurve: Some(SupportPcurve::new(
                side.pcurve.clone(),
                DirectedParameterRange::new(side.pcurve_range).ok(),
            )),
        });
        let Some(context) = IntcurveSupportContext::try_new(
            sides,
            left.curve_range,
            std::array::from_fn(|_| Vec::new()),
        )
        .ok() else {
            return Ok(None);
        };
        intersections.insert(edge_ref, context);
    }
    for (&edge_ref, sides) in &occurrence_intersection_sides {
        if intersections.contains_key(&edge_ref) {
            continue;
        }
        let Some(edge) = topology.edges.get(&edge_ref) else {
            return Ok(None);
        };
        let Some(support) = topology.curve_supports.get(&edge.support) else {
            return Ok(None);
        };
        // A common analytic locus is a cache proof, independently of the
        // correspondence interpolation. It does not create a second map.
        if let [left, right] = sides.as_slice() {
            if let (Some((left_curve, left_range)), Some((right_curve, right_range))) =
                (&left.curve, &right.curve)
            {
                if (equivalent_e5_curve_carriers(left_curve, right_curve)
                    && parameter_range_agreement_tolerance(*left_range, *right_range).is_some())
                    || e5_circle_carriers_have_same_ordered_sweep(
                        ctx,
                        left_curve,
                        *left_range,
                        right_curve,
                        *right_range,
                    )?
                {
                    edge_curves.insert(edge_ref, (left_curve.clone(), *left_range));
                }
            }
        }
        // The first facet defines the curve's reference parameterization.
        // Sample sites alone do not define an interpolation between facets.
        let mut reference = support.pcurves()[0];
        for _ in 0..=topology.curve_supports.len() {
            let Some(wrapper) = topology.curve_supports.get(&reference) else {
                break;
            };
            reference = wrapper.pcurves()[0];
        }
        let mut selected = sides.iter().filter(|side| side.pcurve_record == reference);
        let Some(side) = selected.next() else {
            continue;
        };
        if selected.next().is_some() {
            continue;
        }
        if let Some((curve, range)) = &side.curve {
            edge_curves.insert(edge_ref, (curve.clone(), *range));
        } else {
            surface_curves.insert(
                edge_ref,
                (side.surface.clone(), side.pcurve.clone(), side.pcurve_range),
            );
        }
    }

    for (&edge_ref, (_, _, range)) in &surface_curves {
        edge_curves.entry(edge_ref).or_insert((
            CurveGeometry::Solved(SolvedCurveGeometry::Unknown { record: None }),
            *range,
        ));
    }
    Ok(Some(E5BoundaryPlan {
        faces,
        pcurves,
        pcurve_use_reversed,
        edge_curves,
        surface_curves,
        intersections,
    }))
}

/// Orient a plane face from its exact line/circle boundary area.
fn e5_plane_boundary_sense(
    plane: &cadmpeg_ir::geometry::analytic::PlaneSurface,
    loop_: &E5LoopPlan<'_>,
    curves: &BTreeMap<u32, (CurveGeometry, [f64; 2])>,
) -> Option<Sense> {
    let origin = plane.origin().get();
    let normal = *plane.frame().axis().as_raw();
    let mut area: f64 = 0.0;
    let mut magnitude: f64 = 0.0;
    for member in &loop_.members {
        let (curve, range) = curves.get(&member.source.edge_use)?;
        let range = if member.orientation.reversed {
            [range[1], range[0]]
        } else {
            *range
        };
        let integral = match curve {
            CurveGeometry::Solved(SolvedCurveGeometry::Line(line)) => {
                let start = line
                    .origin()
                    .get()
                    .translated(*line.direction().as_raw(), range[0]);
                let end = line
                    .origin()
                    .get()
                    .translated(*line.direction().as_raw(), range[1]);
                start
                    .vector_from(origin)
                    .cross(end.vector_from(origin))
                    .dot(normal)
            }
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle)) => {
                let center = circle.center().get();
                let x = *circle.frame().reference().as_raw();
                let axis = *circle.frame().axis().as_raw();
                let y = axis.cross(x);
                let radius = circle.radius().get();
                let at = |t: f64| {
                    center
                        .translated(x, radius * t.cos())
                        .translated(y, radius * t.sin())
                };
                center
                    .vector_from(origin)
                    .cross(at(range[1]).vector_from(at(range[0])))
                    .dot(normal)
                    + radius * radius * (range[1] - range[0]) * axis.dot(normal)
            }
            _ => return None,
        };
        if !integral.is_finite() {
            return None;
        }
        area += integral;
        magnitude += integral.abs();
    }
    if !area.is_finite()
        || !magnitude.is_finite()
        || area.abs() <= EPS_E5_DECODE_EXACT_GEOMETRY * magnitude
    {
        return None;
    }
    let outer = loop_.source.outer;
    Some(if (area > 0.0) == outer {
        Sense::Forward
    } else {
        Sense::Reversed
    })
}

/// Drops surfaces no face, intersection side, or surface curve references.
fn prune_e5_unused_surfaces(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    topology: &crate::families::e5::graph::E5Topology,
    surface_for_ref: &HashMap<u32, (SurfaceId, &crate::families::e5::records::E5Surface)>,
    (intersections, surface_curves): E5CurvePlans<'_>,
    unused_surfaces: &mut Vec<Surface>,
) {
    let mut used_surfaces = HashSet::new();
    for id in topology
        .faces
        .iter()
        .filter_map(|face| surface_for_ref.get(&face.surface))
        .map(|(id, _)| id.as_str())
        .chain(intersections.values().flat_map(|context| {
            context
                .sides()
                .iter()
                .filter_map(|side| side.surface.as_ref().map(SurfaceId::as_str))
        }))
        .chain(
            surface_curves
                .values()
                .map(|(surface, _, _)| surface.as_str()),
        )
    {
        used_surfaces.insert(id);
    }
    for surface in ir
        .geometry
        .surfaces
        .extract_if(.., |surface| !used_surfaces.contains(surface.id.as_str()))
    {
        annotations.remove_entity(surface.id.as_str());
        unused_surfaces.push(surface);
    }
}

/// Resolves body face groupings into region/shell components, or `None` on failure.
fn resolve_e5_ownership(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    topology: &crate::families::e5::graph::E5Topology,
) -> Result<Option<E5Ownership>, cadmpeg_core::CodecError> {
    let mut body_faces = Vec::new();
    for body in &topology.bodies {
        let mut faces = Vec::new();
        for face in &body.faces {
            faces.push(face.record_id);
        }
        body_faces.push((body.record_id, faces));
    }
    let Some(bodies) = e5_ownership_plan(ctx, topology, &body_faces)? else {
        return Ok(None);
    };
    let mut face_shell = HashMap::new();
    for (body, plan) in bodies.iter().enumerate() {
        for (component, faces) in plan.components.iter().enumerate() {
            let shell = ShellId::mint(format!("catia:e5:shell#{body}-{component}"))
                .map_err(cadmpeg_core::CodecError::malformed)?;
            for face in faces {
                face_shell.insert(*face, shell.clone());
            }
        }
    }
    Ok(Some(E5Ownership { bodies, face_shell }))
}

/// Emits the boundary curve, intersection/surface-curve procedural, and edge layers.
struct EmitE5CurvesAndEdgesInputs<
    'input0,
    'input1,
    'input2,
    'input3,
    'input4,
    'input5,
    'input6,
    'input7,
    'input8,
    'input9,
    'input10,
    AnnotationAccount,
> {
    ir: &'input0 mut CadIr,
    annotations: &'input1 mut AnnotationBuilder<AnnotationAccount>,
    topology: &'input2 crate::families::e5::graph::E5Topology,
    vertex_for_ref: &'input3 HashMap<u32, VertexId>,
    edge_ids: &'input4 HashMap<u32, EdgeId>,
    edge_curves: &'input5 BTreeMap<u32, (CurveGeometry, [f64; 2])>,
    intersections: &'input6 BTreeMap<u32, IntcurveSupportContext>,
    surface_curves: &'input7 BTreeMap<u32, (SurfaceId, PcurveGeometry, [f64; 2])>,
    admission: &'input10 mut FamilyEntityAdmission<'input8, 'input9>,
}

fn emit_e5_curves_and_edges(
    inputs: EmitE5CurvesAndEdgesInputs<
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        impl cadmpeg_ir::annotations::AnnotationStorage,
    >,
) -> Result<(), cadmpeg_core::CodecError> {
    let EmitE5CurvesAndEdgesInputs {
        ir,
        annotations,
        topology,
        vertex_for_ref,
        edge_ids,
        edge_curves,
        intersections,
        surface_curves,
        admission,
    } = inputs;

    let mut edge_curve_ids = HashMap::new();
    for record_id in edge_curves.keys().copied() {
        edge_curve_ids.insert(
            record_id,
            crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "curve"),
                record_id,
                CurveId::mint,
            )?,
        );
    }
    for (&record_id, (geometry, _)) in edge_curves {
        let id = edge_curve_ids[&record_id].clone();
        annotate(
            annotations,
            &id,
            "e5_0d_03",
            0,
            "lifted_boundary_curve",
            Exactness::Derived,
        )?;
        annotations.derived(&id, "geometry")?;
        admission.charge()?;
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id,
            geometry: (geometry).clone(),
            source_object: None,
            native_ref: None,
        });
    }
    for (&record_id, context) in intersections {
        let curve = edge_curve_ids[&record_id].clone();
        let id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "e5", "intersection"),
            record_id,
            ProceduralCurveId::mint,
        )?;
        annotate(
            annotations,
            &id,
            "e5_0d_03",
            0,
            "c1_surface_intersection",
            Exactness::Derived,
        )?;
        annotations.derived(&id, "curve")?;
        annotations.derived(&id, "definition")?;
        admission.charge()?;
        let _attached = ir.geometry.add_procedural_curve(
            &curve,
            ProceduralCurve::new(
                id,
                ProceduralCurveDefinition::Intersection {
                    context: context.clone(),
                    discontinuity_flag: false,
                    cache: None,
                },
            ),
        );
    }
    for (&record_id, (surface, pcurve, range)) in surface_curves {
        if intersections.contains_key(&record_id) {
            continue;
        }
        let curve = edge_curve_ids[&record_id].clone();
        let id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "e5", "surface-curve"),
            record_id,
            ProceduralCurveId::mint,
        )?;
        annotate(
            annotations,
            &id,
            "e5_0d_03",
            0,
            "parametric_surface_curve",
            Exactness::Derived,
        )?;
        annotations.derived(&id, "curve")?;
        annotations.derived(&id, "definition")?;
        admission.charge()?;
        let _attached = ir.geometry.add_procedural_curve(
            &curve,
            ProceduralCurve::new(
                id,
                ProceduralCurveDefinition::SurfaceCurve {
                    family: SurfaceCurveFamily::Parametric {
                        context: IntcurveSupportContext::try_new(
                            [
                                IntcurveSupportSide {
                                    surface: Some(surface.clone()),
                                    pcurve: Some(SupportPcurve::new(pcurve.clone(), None)),
                                },
                                IntcurveSupportSide {
                                    surface: None,
                                    pcurve: None,
                                },
                            ],
                            *range,
                            std::array::from_fn(|_| Vec::new()),
                        )
                        .map_err(cadmpeg_core::CodecError::malformed)?,
                        tail: None,
                    },
                },
            ),
        );
    }
    for (&record_id, edge) in &topology.edges {
        let id = edge_ids[&record_id].clone();
        annotate(
            annotations,
            &id,
            "e5_0d_03",
            0,
            "ff_edge_use",
            Exactness::ByteExact,
        )?;
        for field in ["ends.start", "ends.end"] {
            annotations.derived(&id, field)?;
        }
        if edge_curve_ids.contains_key(&record_id) {
            annotations.derived(&id, "curve")?;
            annotations.derived(&id, "param_range")?;
        }
        admission.charge()?;
        ir.geometry.edges.push(Edge {
            id,
            carrier: cadmpeg_ir::topology::EdgeCarrier::new(
                edge_curve_ids.get(&record_id).cloned(),
                edge_curves.get(&record_id).map(|(_, range)| *range),
            )
            .map_err(cadmpeg_core::CodecError::malformed)?,
            ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                vertex_for_ref[&edge.start_vertex].clone(),
                vertex_for_ref[&edge.end_vertex].clone(),
            )),
            tolerance: None,
            native_ref: None,
        });
    }
    Ok(())
}

/// Emits the surface pcurve layer.
fn emit_e5_pcurves(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    pcurves: &BTreeMap<u32, (PcurveGeometry, [f64; 2])>,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    for (&record_id, (geometry, range)) in pcurves {
        let id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "e5", "pcurve"),
            record_id,
            PcurveId::mint,
        )?;
        annotate(
            annotations,
            &id,
            "e5_0d_03",
            0,
            "surface_parameter_curve",
            Exactness::ByteExact,
        )?;
        annotations.derived(&id, "geometry")?;
        admission.charge()?;
        ir.geometry.pcurves.push(Pcurve {
            id,
            geometry: geometry.clone(),
            metadata: cadmpeg_ir::geometry::pcurve::PcurveMetadata::general(
                None,
                Some(
                    cadmpeg_ir::units::FiniteVector::new(*range)
                        .ok_or(
                            cadmpeg_ir::geometry::pcurve::PcurveMetadata::NON_FINITE_PARAMETER_RANGE,
                        )
                        .map_err(cadmpeg_core::CodecError::malformed)?,
                ),
                None,
            ),
            native_ref: None,
        });
    }
    Ok(())
}

/// Emits the body/region/shell layer.
fn emit_e5_bodies(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    bodies: &[E5BodyPlan],
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    for (body_index, plan) in bodies.iter().enumerate() {
        let body_id = BodyId::mint(format!("catia:e5:body#{}", plan.record_id))
            .map_err(cadmpeg_core::CodecError::malformed)?;
        let mut region_ids = Vec::new();

        for component in 0..plan.components.len() {
            region_ids.push(
                RegionId::mint(format!("catia:e5:region#{body_index}-{component}"))
                    .map_err(cadmpeg_core::CodecError::malformed)?,
            );
        }
        annotate(
            annotations,
            &body_id,
            "e5_0d_03",
            0,
            "01_body",
            Exactness::ByteExact,
        )?;
        annotations.derived(&body_id, "kind")?;
        admission.charge()?;
        ir.geometry.bodies.push(Body {
            id: body_id.clone(),
            kind: plan.kind,
            transform: None,
            name: None,
            color: None,
            visible: None,
            native_ref: None,
        });
        for (component, component_faces) in plan.components.iter().enumerate() {
            let region_id = region_ids[component].clone();
            let shell_id = ShellId::mint(format!("catia:e5:shell#{body_index}-{component}"))
                .map_err(cadmpeg_core::CodecError::malformed)?;
            annotate(
                annotations,
                &region_id,
                "e5_0d_03",
                0,
                "derived_region",
                Exactness::Inferred,
            )?;
            annotations.derived(&region_id, "body")?;
            annotations.derived(&region_id, "shells")?;
            let shells = vec![shell_id.clone()];
            admission.charge()?;
            ir.geometry.regions.push(Region {
                id: region_id.clone(),
                body: body_id.clone(),
                shells,
                native_ref: None,
            });
            annotate(
                annotations,
                &shell_id,
                "e5_0d_03",
                0,
                "derived_shell",
                Exactness::Inferred,
            )?;
            annotations.derived(&shell_id, "region")?;
            admission.charge()?;
            let mut face_ids = Vec::new();

            for face in component_faces {
                face_ids.push(crate::resource::compose_u32_id(
                    &cadmpeg_ir::identity_namespace!("catia", "e5", "face"),
                    *face,
                    FaceId::mint,
                )?);
            }
            if face_ids.is_empty() {
                return Err(cadmpeg_core::CodecError::malformed(
                    "shell owns no topology",
                ));
            }
            ir.geometry.shells.push(Shell::new(shell_id, region_id));
        }
    }
    Ok(())
}

/// Emits the face/loop/coedge layer and the radial-next fixup.
///
/// Returns `false` when the lowering plan is not total for a serialized loop
/// member.
struct EmitE5FacesLoopsCoedgesInputs<
    'input0,
    'input1,
    'input2,
    'input3,
    'input4,
    'input5,
    'input6,
    'input7,
    'input8,
    'input9,
    'input10,
    'input11,
    'input12,
    AnnotationAccount,
> {
    ir: &'input0 mut CadIr,
    annotations: &'input1 mut AnnotationBuilder<AnnotationAccount>,
    topology: &'input2 crate::families::e5::graph::E5Topology,
    surface_for_ref:
        &'input3 HashMap<u32, (SurfaceId, &'input4 crate::families::e5::records::E5Surface)>,
    face_shell: &'input5 HashMap<u32, ShellId>,
    edge_ids: &'input6 HashMap<u32, EdgeId>,
    vertex_for_ref: &'input7 HashMap<u32, VertexId>,
    boundary: &'input9 E5BoundaryPlan<'input8>,
    admission: &'input12 mut FamilyEntityAdmission<'input10, 'input11>,
}

fn emit_e5_faces_loops_coedges(
    inputs: EmitE5FacesLoopsCoedgesInputs<
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        '_,
        impl cadmpeg_ir::annotations::AnnotationStorage,
    >,
) -> Result<bool, cadmpeg_core::CodecError> {
    let EmitE5FacesLoopsCoedgesInputs {
        ir,
        annotations,
        topology,
        surface_for_ref,
        face_shell,
        edge_ids,
        vertex_for_ref,
        boundary,
        admission,
    } = inputs;

    let mut coedges_by_edge = HashMap::<u32, Vec<usize>>::new();
    for face_plan in &boundary.faces {
        let face = face_plan.source;
        let face_id = crate::resource::compose_u32_id(
            &cadmpeg_ir::identity_namespace!("catia", "e5", "face"),
            face.record_id,
            FaceId::mint,
        )?;
        let mut loop_ids = Vec::new();

        for loop_ in &face.loops {
            loop_ids.push(crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "loop"),
                loop_.record_id,
                LoopId::mint,
            )?);
        }
        annotate(
            annotations,
            &face_id,
            "e5_0d_03",
            0,
            "00_advanced_face",
            Exactness::ByteExact,
        )?;
        for field in ["shell", "surface", "sense", "loops"] {
            annotations.derived(&face_id, field)?;
        }
        admission.charge()?;
        ir.geometry.faces.push(Face {
            id: face_id.clone(),
            shell: face_shell[&face.record_id].clone(),
            surface: surface_for_ref[&face.surface].0.clone(),
            sense: face_plan.sense,
            loops: match loop_ids.split_first() {
                // The source states the outer boundary first.
                Some((outer, inner)) => {
                    cadmpeg_ir::topology::FaceLoops::classified(outer.clone(), inner.to_vec())
                }
                None => cadmpeg_ir::topology::FaceLoops::unspecified(Vec::new()),
            },
            name: None,
            color: None,
            tolerance: None,
            native_ref: None,
        });

        for loop_plan in &face_plan.loops {
            let loop_ = loop_plan.source;
            let loop_id = crate::resource::compose_u32_id(
                &cadmpeg_ir::identity_namespace!("catia", "e5", "loop"),
                loop_.record_id,
                LoopId::mint,
            )?;
            let members = &loop_plan.members;
            let mut coedge_ids = Vec::new();
            let mut vertex_uses = Vec::new();
            for member in members {
                coedge_ids.push(member.id.clone());
                let edge_ref = member.source.edge_use;
                let Some(edge) = topology.edges.get(&edge_ref) else {
                    return Ok(false);
                };
                let endpoint_ref = if member.orientation.reversed {
                    edge.start_vertex
                } else {
                    edge.end_vertex
                };
                let Some(vertex_id) = vertex_for_ref.get(&endpoint_ref) else {
                    return Ok(false);
                };
                let vertex_use = AnchoredVertexUse {
                    vertex: vertex_id.clone(),
                    after: member.id.clone(),
                    pcurves: Vec::new(),
                };
                vertex_uses.push(vertex_use);
            }
            annotate(
                annotations,
                &loop_id,
                "e5_0d_03",
                0,
                "09_loop",
                Exactness::ByteExact,
            )?;
            for field in ["face", "coedges", "vertex_uses"] {
                annotations.derived(&loop_id, field)?;
            }
            let Ok(ring) = cadmpeg_ir::topology::LoopRing::new(coedge_ids, vertex_uses) else {
                return Ok(false);
            };
            admission.charge()?;
            ir.geometry.loops.push(Loop {
                id: loop_id.clone(),
                face: face_id.clone(),
                boundary: cadmpeg_ir::topology::LoopBoundary::Ring(ring),
                native_ref: None,
            });
            for member in members {
                let index = member.orientation.serialized_index;
                let edge_ref = member.source.edge_use;
                let pcurve_ref = member.source.pcurve;
                let Some(&pcurve_reversed) =
                    boundary.pcurve_use_reversed.get(&(loop_.record_id, index))
                else {
                    return Ok(false);
                };
                let Some((_, range)) = boundary.pcurves.get(&pcurve_ref) else {
                    return Ok(false);
                };
                let pcurve_parameter_range =
                    (member.orientation.reversed ^ pcurve_reversed).then_some([range[1], range[0]]);
                let id = member.id.clone();
                annotate(
                    annotations,
                    &id,
                    "e5_0d_03",
                    0,
                    "serialized_loop_member",
                    Exactness::ByteExact,
                )?;
                for field in ["owner_loop", "edge", "sense", "pcurves"] {
                    annotations.derived(&id, field)?;
                }
                let arena_index = ir.geometry.coedges.len();

                coedges_by_edge
                    .entry(edge_ref)
                    .or_default()
                    .push(arena_index);
                let Ok(parameter_range) = pcurve_parameter_range
                    .map(cadmpeg_ir::geometry::DirectedParameterRange::new)
                    .transpose()
                else {
                    return Ok(false);
                };
                let mut pcurves = Vec::new();
                pcurves.push(cadmpeg_ir::topology::PcurveUse {
                    pcurve: crate::resource::compose_u32_id(
                        &cadmpeg_ir::identity_namespace!("catia", "e5", "pcurve"),
                        pcurve_ref,
                        PcurveId::mint,
                    )?,
                    isoparametric: None,
                    parameter_range,
                });
                admission.charge()?;
                ir.geometry.coedges.push(Coedge {
                    id: id.clone(),
                    owner_loop: loop_id.clone(),
                    edge: edge_ids[&edge_ref].clone(),
                    radial_next: id,
                    sense: if member.orientation.reversed {
                        Sense::Reversed
                    } else {
                        Sense::Forward
                    },
                    pcurves,
                    use_curve: None,
                    native_ref: None,
                });
            }
        }
    }
    for occurrences in coedges_by_edge.values() {
        for (position, &arena_index) in occurrences.iter().enumerate() {
            let radial = occurrences[(position + 1) % occurrences.len()];
            let next = ir.geometry.coedges[radial].id.clone();
            ir.geometry.coedges[arena_index].radial_next = next;
        }
    }
    Ok(true)
}

fn e5_stored_pcurve_reversed(
    topology: &crate::families::e5::graph::E5Topology,
    edge_ref: u32,
    pcurve_ref: u32,
    native_range: [f64; 2],
) -> Option<bool> {
    topology
        .edge_representation_parameters(edge_ref, pcurve_ref)
        .and_then(|parameters| {
            parameter_ranges_reversed(parameters.map(FiniteReal::get), native_range)
        })
}

fn unique_endpoint_direction(forward_error: f64, reverse_error: f64) -> Option<bool> {
    match (
        forward_error.is_finite() && forward_error <= E5_ENDPOINT_MATCH_TOLERANCE,
        reverse_error.is_finite() && reverse_error <= E5_ENDPOINT_MATCH_TOLERANCE,
    ) {
        (true, false) => Some(false),
        (false, true) => Some(true),
        (true, true) | (false, false) => None,
    }
}

fn parameter_ranges_reversed(parameters: [f64; 2], native_range: [f64; 2]) -> Option<bool> {
    if !parameters
        .into_iter()
        .chain(native_range)
        .all(f64::is_finite)
        || parameters[0] == parameters[1]
        || native_range[0] == native_range[1]
    {
        return None;
    }
    Some((parameters[1] < parameters[0]) != (native_range[1] < native_range[0]))
}

fn e5_pcurve_on_surface(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    pcurve: &crate::families::e5::graph::E5Pcurve,
    decoded_surface: &crate::families::e5::records::E5Surface,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> E5PcurveLiftOutput {
    let surface = &decoded_surface.geometry;
    match pcurve {
        crate::families::e5::graph::E5Pcurve::Line {
            origin: raw_origin,
            direction,
            range,
            ..
        } => {
            let range = range.map(FiniteReal::get);
            let origin = e5_surface_uv(decoded_surface, *raw_origin);
            let direction = Point2::new(
                direction[0].get() * decoded_surface.uv_scale[0].get(),
                direction[1].get() * decoded_surface.uv_scale[1].get(),
            );
            if !origin.is_finite() || !direction.is_finite() {
                return Ok(None);
            }
            let uv = range.map(|parameter| {
                Point2::new(
                    origin.u + parameter * direction.u,
                    origin.v + parameter * direction.v,
                )
            });
            if !uv.iter().copied().all(|point| point.is_finite()) {
                return Ok(None);
            }
            let Some(start) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv[0].u, uv[0].v),
                )?)?
            else {
                return Ok(None);
            };
            let Some(end) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv[1].u, uv[1].v),
                )?)?
            else {
                return Ok(None);
            };
            let Ok(line) = cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(origin, direction)
            else {
                return Ok(None);
            };
            Ok(Some((
                PcurveGeometry::Line(line),
                range,
                [start.get(), end.get()],
            )))
        }
        crate::families::e5::graph::E5Pcurve::Circle {
            center,
            radius,
            range,
            ..
        } => {
            let (center, radius) = (center.map(FiniteReal::get), radius.get());
            let angular_range = ordered_range([range[0].get() / radius, range[1].get() / radius]);
            if !angular_range.into_iter().all(f64::is_finite) {
                return Ok(None);
            }
            let Some(geometry) = rational_pcurve_arc(
                center,
                radius,
                angular_range,
                refusal,
                "e5 arc pcurve record",
            ) else {
                return Ok(None);
            };
            {
                let PcurveGeometry::Nurbs { mut nurbs } = geometry else {
                    return Ok(None);
                };
                let scale = decoded_surface.uv_scale.map(FiniteReal::get);
                if nurbs
                    .try_map_control_points(|_, point| {
                        let point = point.get();
                        FinitePoint2::new(Point2::new(point.u * scale[0], point.v * scale[1]))
                            .ok_or(())
                    })
                    .is_err()
                {
                    return Ok(None);
                }
                let geometry = PcurveGeometry::Nurbs { nurbs };
                let start_angle = angular_range[0];
                let end_angle = angular_range[1];
                let Some(start) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(
                            ctx,
                            surface,
                            (center[0] + radius * start_angle.cos()) * scale[0],
                            (center[1] + radius * start_angle.sin()) * scale[1],
                        ),
                    )?)?
                else {
                    return Ok(None);
                };
                let Some(end) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(
                            ctx,
                            surface,
                            (center[0] + radius * end_angle.cos()) * scale[0],
                            (center[1] + radius * end_angle.sin()) * scale[1],
                        ),
                    )?)?
                else {
                    return Ok(None);
                };
                Ok(Some((geometry, angular_range, [start.get(), end.get()])))
            }
        }
        crate::families::e5::graph::E5Pcurve::Jet { sites, range, .. } => {
            let scale = decoded_surface.uv_scale.map(FiniteReal::get);
            let mut knots = Vec::new();
            let mut points = Vec::new();
            let mut first_derivatives = Vec::new();
            let mut second_derivatives = Vec::new();
            let scaled =
                |values: [FiniteReal; 2]| [values[0].get() * scale[0], values[1].get() * scale[1]];
            for site in sites {
                knots.push(site.knot.get());
                points.push(scaled(site.point));
                first_derivatives.push(scaled(site.first_derivatives));
                second_derivatives.push(scaled(site.second_derivatives));
            }
            if !points.iter().flatten().copied().all(f64::is_finite)
                || !first_derivatives
                    .iter()
                    .flatten()
                    .copied()
                    .all(f64::is_finite)
                || !second_derivatives
                    .iter()
                    .flatten()
                    .copied()
                    .all(f64::is_finite)
            {
                return Ok(None);
            }
            let Some(geometry) = quintic_jet_pcurve(
                crate::families::e5::graph::E5Pcurve::JET_DEGREE,
                &knots,
                &points,
                (&first_derivatives, &second_derivatives),
                refusal,
                format_args!(
                    "e5 quintic-jet pcurve on surface record {} at byte {}",
                    decoded_surface.record_id, decoded_surface.pos
                ),
            ) else {
                return Ok(None);
            };
            let (Some(first), Some(last)) = (points.first(), points.last()) else {
                return Ok(None);
            };
            let Some(start) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, first[0], first[1]),
                )?)?
            else {
                return Ok(None);
            };
            let Some(end) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, last[0], last[1]),
                )?)?
            else {
                return Ok(None);
            };
            Ok(Some((
                geometry,
                range.map(FiniteReal::get),
                [start.get(), end.get()],
            )))
        }
        crate::families::e5::graph::E5Pcurve::Nurbs {
            degree,
            knots,
            control_points,
            range,
            ..
        } => {
            let scale = decoded_surface.uv_scale.map(FiniteReal::get);
            let mut knot_values = Vec::new();

            knot_values.extend(knots.iter().copied().map(FiniteReal::get));
            let mut scaled_points = Vec::new();

            scaled_points.extend(
                control_points
                    .iter()
                    .map(|[u, v]| Point2::new(u.get() * scale[0], v.get() * scale[1])),
            );
            if !scale.into_iter().all(|value| value != 0.0)
                || !scaled_points.iter().copied().all(|point| point.is_finite())
            {
                return Ok(None);
            }
            let Some(nurbs) = crate::nurbs::note_refusal(
                PcurveNurbs::from_lanes(*degree, knot_values, scaled_points, None, false),
                refusal,
                format_args!(
                    "e5 NURBS pcurve on surface record {} at byte {}",
                    decoded_surface.record_id, decoded_surface.pos
                ),
            ) else {
                return Ok(None);
            };
            let geometry = PcurveGeometry::Nurbs { nurbs };
            {
                let range = range.map(FiniteReal::get);
                let Some(start_uv) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::pcurve_uv(ctx, &geometry, range[0]),
                    )?)?
                else {
                    return Ok(None);
                };
                let Some(end_uv) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::pcurve_uv(ctx, &geometry, range[1]),
                    )?)?
                else {
                    return Ok(None);
                };
                let Some(start) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(
                            ctx, surface, start_uv.u, start_uv.v,
                        ),
                    )?)?
                else {
                    return Ok(None);
                };
                let Some(end) =
                    cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                        cadmpeg_ir::eval::decode::surface_point(ctx, surface, end_uv.u, end_uv.v),
                    )?)?
                else {
                    return Ok(None);
                };
                Ok(Some((geometry, range, [start.get(), end.get()])))
            }
        }
    }
}

fn e5_lift_plane_nurbs(
    plane: &cadmpeg_ir::geometry::analytic::PlaneSurface,
    nurbs: &PcurveNurbs,
    surface_record_id: u32,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<NurbsCurve> {
    use cadmpeg_ir::geometry::nurbs::{NurbsPoles3, WeightedPole3};
    use cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles;

    let origin = plane.origin().get();
    let normal = plane.frame().axis().as_raw();
    let u_axis = plane.frame().reference().as_raw();
    let v_axis = (*normal).cross(*u_axis);
    if !v_axis.is_finite() {
        return None;
    }
    let lift = |point: FinitePoint2| {
        let point = point.get();
        FinitePoint3::new(
            origin
                .translated(*u_axis, point.u)
                .translated(v_axis, point.v),
        )
    };
    let poles = match nurbs.pole_rows() {
        PcurveNurbsPoles::Polynomial { points } => {
            let points = points
                .iter()
                .copied()
                .map(lift)
                .collect::<Option<Vec<_>>>()?;
            NurbsPoles3::Polynomial { points }
        }
        PcurveNurbsPoles::Rational { points } => {
            let points = points
                .iter()
                .map(|pole| {
                    Some(WeightedPole3 {
                        point: lift(pole.point)?,
                        weight: pole.weight,
                    })
                })
                .collect::<Option<Vec<_>>>()?;
            NurbsPoles3::Rational { points }
        }
    };
    let knots = nurbs.knots().clone();
    crate::nurbs::note_refusal(
        NurbsCurve::new(nurbs.degree(), knots, poles, nurbs.periodic()),
        refusal,
        format_args!(
            "e5 boundary curve lifted from the pcurve on surface record {surface_record_id}"
        ),
    )
}

fn e5_boundary_curve(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    surface: &SurfaceGeometry,
    native_pcurve: &crate::families::e5::graph::E5Pcurve,
    pcurve: &PcurveGeometry,
    (range, endpoints): ([f64; 2], [Point3; 2]),
    uv_scale: [FiniteReal; 2],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<(CurveGeometry, [f64; 2])>, cadmpeg_core::CodecError> {
    (|| -> Option<Result<(CurveGeometry, [f64; 2]), cadmpeg_core::CodecError>> {
        let uv_scale = uv_scale.map(FiniteReal::get);
        if !uv_scale.into_iter().all(|value| value != 0.0)
            || !range.into_iter().all(f64::is_finite)
            || !endpoints.iter().copied().all(|point| point.is_finite())
        {
            return None;
        }
        if let (
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)),
            crate::families::e5::graph::E5Pcurve::Circle { center, radius, .. },
        ) = (surface, native_pcurve)
        {
            let origin = plane_surface.origin().get();
            let normal = plane_surface.frame().axis().as_raw();
            let u_axis = plane_surface.frame().reference().as_raw();
            let v_axis = (*normal).cross(*u_axis);
            let center = origin
                .translated(*u_axis, center[0].get() * uv_scale[0])
                .translated(v_axis, center[1].get() * uv_scale[1]);
            if !center.is_finite() || !v_axis.is_finite() {
                return None;
            }
            return Some(Ok((
                CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                    cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                        center,
                        *normal,
                        u_axis.scale(uv_scale[0]),
                        radius.get(),
                    )
                    .ok()?,
                )),
                crate::nurbs::canonical_periodic_range(range)?,
            )));
        }
        if let (
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface)),
            crate::families::e5::graph::E5Pcurve::Jet { .. }
            | crate::families::e5::graph::E5Pcurve::Nurbs { .. },
            PcurveGeometry::Nurbs { nurbs },
        ) = (surface, native_pcurve, pcurve)
        {
            let nurbs = e5_lift_plane_nurbs(
                plane_surface,
                nurbs,
                native_pcurve.surface_record_id(),
                refusal,
            )?;
            return Some(Ok((
                CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(nurbs)),
                range,
            )));
        }
        let PcurveGeometry::Line(line_pcurve) = pcurve else {
            return None;
        };
        let direction = line_pcurve.direction().as_raw();
        let start_uv = match cadmpeg_ir::eval::finite_or_refusal(
            match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::pcurve_uv(
                ctx, pcurve, range[0],
            )) {
                Ok(value) => value,
                Err(error) => return Some(Err(error.into())),
            },
        ) {
            Ok(Some(point)) => point,
            Ok(None) => return None,
            Err(limit) => return Some(Err(limit.into())),
        };
        let end_uv = match cadmpeg_ir::eval::finite_or_refusal(
            match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::pcurve_uv(
                ctx, pcurve, range[1],
            )) {
                Ok(value) => value,
                Err(error) => return Some(Err(error.into())),
            },
        ) {
            Ok(Some(point)) => point,
            Ok(None) => return None,
            Err(limit) => return Some(Err(limit.into())),
        };

        let circle = match e5_isoparametric_direction(*direction) {
            Some(E5IsoparametricDirection::ConstantV) => {
                e5_constant_v_circle(surface, start_uv.as_raw().v)
            }
            Some(E5IsoparametricDirection::ConstantU) => {
                e5_constant_u_circle(surface, start_uv.as_raw().u)
            }
            None => None,
        };
        if let Some((center, radius, axis)) = circle {
            if !center.is_finite() || !axis.is_finite() || !radius.is_finite() || radius <= 0.0 {
                return None;
            }
            let span_direction = FinitePoint2::new(Point2::new(
                end_uv.as_raw().u - start_uv.as_raw().u,
                end_uv.as_raw().v - start_uv.as_raw().v,
            ))?;
            let mut choices = [None, None];
            for (index, axis) in [axis, axis.scale(-1.0)].into_iter().enumerate() {
                let ref_direction = cadmpeg_ir::geometry::derive_reference_direction(axis);
                let range = match circle_parameter_range_from_surface_branch(
                    ctx,
                    crate::assemble::CircleParameterRangeFromSurfaceBranchInputs {
                        surface,
                        center,
                        radius,
                        axis,
                        ref_direction,
                        start: endpoints[0],
                        end: endpoints[1],
                        pcurve_origin: start_uv,
                        pcurve_direction: span_direction,
                    },
                ) {
                    Ok(Some(range)) => range,
                    Ok(None) => continue,
                    Err(limit) => return Some(Err(limit.into())),
                };
                let Some(range) = crate::nurbs::canonical_periodic_range(range) else {
                    continue;
                };
                choices[index] = Some((axis, ref_direction, range));
            }
            let [first, second] = choices;
            let ((Some((axis, ref_direction, curve_range)), None)
            | (None, Some((axis, ref_direction, curve_range)))) = (first, second)
            else {
                return None;
            };
            return Some(Ok((
                CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                    cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                        center,
                        axis,
                        ref_direction,
                        radius,
                    )
                    .ok()?,
                )),
                curve_range,
            )));
        }

        if !(matches!(
            surface,
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_))
        ) || (direction.u == 0.0
            && matches!(
                surface,
                SurfaceGeometry::Solved(
                    SolvedSurfaceGeometry::Cylinder(_) | SolvedSurfaceGeometry::Cone(_)
                )
            )))
        {
            return None;
        }
        let delta = endpoints[1].vector_from(endpoints[0]);
        let length = delta.x.hypot(delta.y).hypot(delta.z);
        if !length.is_finite() || length <= 0.0 {
            return None;
        }
        let direction = Vector3::new(delta.x / length, delta.y / length, delta.z / length);
        Some(Ok((
            CurveGeometry::Solved(SolvedCurveGeometry::Line(
                cadmpeg_ir::geometry::analytic::LineCurve::try_new(endpoints[0], direction).ok()?,
            )),
            [0.0, length],
        )))
    })()
    .transpose()
}

#[cfg(test)]
fn e5_occurrence_intersection_context(
    sides: &[(SurfaceId, PcurveGeometry, [f64; 2])],
) -> Option<IntcurveSupportContext> {
    let [left, right] = sides else {
        return None;
    };
    let tolerance = parameter_range_agreement_tolerance(left.2, right.2)?;
    if (left.2[0] - right.2[0]).abs() > tolerance || (left.2[1] - right.2[1]).abs() > tolerance {
        return None;
    }
    IntcurveSupportContext::try_new(
        [left, right].map(|side| IntcurveSupportSide {
            surface: Some(side.0.clone()),
            pcurve: Some(SupportPcurve::new(side.1.clone(), None)),
        }),
        left.2,
        std::array::from_fn(|_| Vec::new()),
    )
    .ok()
}

fn e5_parameter_range_is_valid(range: [f64; 2]) -> bool {
    range.into_iter().all(f64::is_finite) && range[0] != range[1]
}

fn parameter_span_magnitudes(left: [f64; 2], right: [f64; 2]) -> (f64, f64, f64) {
    let left_span = (left[1] - left[0]).abs();
    let right_span = (right[1] - right[0]).abs();
    if left_span.is_finite() && right_span.is_finite() {
        (left_span, right_span, 1.0)
    } else {
        (
            (left[1] * 0.5 - left[0] * 0.5).abs(),
            (right[1] * 0.5 - right[0] * 0.5).abs(),
            2.0,
        )
    }
}

fn parameter_span_agreement(left: [f64; 2], right: [f64; 2]) -> Option<f64> {
    if !e5_parameter_range_is_valid(left) || !e5_parameter_range_is_valid(right) {
        return None;
    }
    let (left_span, right_span, scale_factor) = parameter_span_magnitudes(left, right);
    let parameter_scale = left_span.max(right_span);
    if parameter_scale == 0.0
        || (left_span - right_span).abs() > E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale
    {
        return None;
    }
    Some(E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale * scale_factor)
}

fn parameter_range_agreement_tolerance(left: [f64; 2], right: [f64; 2]) -> Option<f64> {
    if !left.into_iter().chain(right).all(f64::is_finite) {
        return None;
    }
    let (left_span, right_span, scale_factor) = parameter_span_magnitudes(left, right);
    let parameter_scale = left_span.max(right_span);
    if parameter_scale == 0.0
        || (left_span - right_span).abs() > E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale
        || (left[0] - right[0]).abs()
            > E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale * scale_factor
        || (left[1] - right[1]).abs()
            > E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale * scale_factor
    {
        return None;
    }
    Some(E5_PARAMETER_RELATIVE_TOLERANCE * parameter_scale * scale_factor)
}

fn e5_circle_carriers_have_same_ordered_sweep(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    left: &CurveGeometry,
    left_range: [f64; 2],
    right: &CurveGeometry,
    right_range: [f64; 2],
) -> Result<bool, cadmpeg_core::decode::ResourceLimit> {
    let (
        CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)),
        CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve_2)),
    ) = (left, right)
    else {
        return Ok(false);
    };
    let left_center = circle_curve.center().get();
    let left_axis = circle_curve.frame().axis().as_raw();
    let left_radius = circle_curve.radius().get();
    let right_center = circle_curve_2.center().get();
    let right_axis = circle_curve_2.frame().axis().as_raw();
    let right_radius = circle_curve_2.radius().get();
    if (left_center).distance(right_center) > E5_ENDPOINT_MATCH_TOLERANCE
        || (left_radius - right_radius).abs() > E5_ENDPOINT_MATCH_TOLERANCE
        || (*left_axis).dot(*right_axis) < 1.0 - E5_CARRIER_AXIS_COSINE_TOLERANCE
    {
        return Ok(false);
    }
    let left_span = left_range[1] - left_range[0];
    let right_span = right_range[1] - right_range[0];
    if left_span.signum() != right_span.signum()
        || parameter_span_agreement(left_range, right_range).is_none()
    {
        return Ok(false);
    }
    let Some(left_start) =
        cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::curve_point(ctx, left, left_range[0]),
        )?)?
    else {
        return Ok(false);
    };
    let Some(left_end) =
        cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::curve_point(ctx, left, left_range[1]),
        )?)?
    else {
        return Ok(false);
    };
    let Some(right_start) =
        cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::curve_point(ctx, right, right_range[0]),
        )?)?
    else {
        return Ok(false);
    };
    let Some(right_end) =
        cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::curve_point(ctx, right, right_range[1]),
        )?)?
    else {
        return Ok(false);
    };
    Ok(
        left_start.distance(right_start.get()) <= E5_ENDPOINT_MATCH_TOLERANCE
            && left_end.distance(right_end.get()) <= E5_ENDPOINT_MATCH_TOLERANCE,
    )
}

fn equivalent_e5_curve_carriers(left: &CurveGeometry, right: &CurveGeometry) -> bool {
    match (left, right) {
        (
            CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve)),
            CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve_2)),
        ) => {
            let left_origin = line_curve.origin().get();
            let left_direction = *line_curve.direction().as_raw();
            let right_origin = line_curve_2.origin().get();
            let right_direction = *line_curve_2.direction().as_raw();
            left_origin.distance(right_origin) <= 2e-3
                && left_direction.dot(right_direction) >= 1.0 - EPS_E5_DECODE_GEOMETRY
        }
        (
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)),
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve_2)),
        ) => {
            let left_center = circle_curve.center().get();
            let left_axis = circle_curve.frame().axis().as_raw();
            let left_ref_direction = circle_curve.frame().reference().as_raw();
            let left_radius = circle_curve.radius().get();
            let right_center = circle_curve_2.center().get();
            let right_axis = circle_curve_2.frame().axis().as_raw();
            let right_ref_direction = circle_curve_2.frame().reference().as_raw();
            let right_radius = circle_curve_2.radius().get();
            (left_center).distance(right_center) <= 2e-3
                && (left_radius - right_radius).abs() <= 2e-3
                && (*left_axis).dot(*right_axis) >= 1.0 - EPS_E5_DECODE_GEOMETRY
                && (*left_ref_direction).dot(*right_ref_direction) >= 1.0 - EPS_E5_DECODE_GEOMETRY
        }
        (
            CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(left)),
            CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(right)),
        ) => left == right,
        _ => false,
    }
}

fn e5_constant_v_circle(surface: &SurfaceGeometry, v: f64) -> Option<(Point3, f64, Vector3)> {
    match surface {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) => {
            let origin = cylinder_surface.origin().get();
            let axis = cylinder_surface.frame().axis().as_raw();
            let radius = cylinder_surface.radius().get();
            Some((origin.translated(*axis, v), radius, *axis))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)) => {
            let origin = cone_surface.origin().get();
            let axis = cone_surface.frame().axis().as_raw();
            let radius = cone_surface.radius().get();
            let half_angle = cone_surface.half_angle().get();
            Some((
                origin.translated(*axis, v),
                (radius + v * half_angle.tan()).abs(),
                *axis,
            ))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(sphere_surface)) => {
            let center = sphere_surface.center().get();
            let axis = sphere_surface.frame().axis().as_raw();
            let radius = sphere_surface.radius().get();
            Some((
                center.translated(*axis, radius * v.sin()),
                radius * v.cos().abs(),
                *axis,
            ))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)) => {
            let center = torus_surface.center().get();
            let axis = torus_surface.frame().axis().as_raw();
            let major_radius = torus_surface.major_radius().get();
            let minor_radius = torus_surface.minor_radius().get();
            Some((
                center.translated(*axis, minor_radius * v.sin()),
                (major_radius + minor_radius * v.cos()).abs(),
                *axis,
            ))
        }
        _ => None,
    }
}

fn e5_constant_u_circle(surface: &SurfaceGeometry, u: f64) -> Option<(Point3, f64, Vector3)> {
    match surface {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(sphere_surface)) => {
            let center = sphere_surface.center().get();
            let axis = sphere_surface.frame().axis().as_raw();
            let ref_direction = sphere_surface.frame().reference().as_raw();
            let radius = sphere_surface.radius().get();
            let tangent = (*axis).cross(*ref_direction);
            let radial = (*ref_direction).scale(u.cos()) + tangent.scale(u.sin());
            Some((center, radius, (*axis).cross(radial)))
        }
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus_surface)) => {
            let center = torus_surface.center().get();
            let axis = torus_surface.frame().axis().as_raw();
            let ref_direction = torus_surface.frame().reference().as_raw();
            let major_radius = torus_surface.major_radius().get();
            let minor_radius = torus_surface.minor_radius().get();
            let tangent = (*axis).cross(*ref_direction);
            let radial = (*ref_direction).scale(u.cos()) + tangent.scale(u.sin());
            Some((
                center.translated(radial, major_radius),
                minor_radius,
                (*axis).cross(radial),
            ))
        }
        _ => None,
    }
}

fn e5_surface_uv(
    surface: &crate::families::e5::records::E5Surface,
    raw: [FiniteReal; 2],
) -> Point2 {
    Point2::new(
        raw[0].get() * surface.uv_scale[0].get(),
        raw[1].get() * surface.uv_scale[1].get(),
    )
}

struct E5BodyPlan {
    record_id: u32,
    kind: BodyKind,
    components: Vec<Vec<u32>>,
}

fn e5_ownership_plan(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    topology: &crate::families::e5::graph::E5Topology,
    body_faces: &[(u32, Vec<u32>)],
) -> Result<Option<Vec<E5BodyPlan>>, cadmpeg_core::CodecError> {
    if body_faces.is_empty() || body_faces.iter().any(|(_, faces)| faces.is_empty()) {
        return Ok(None);
    }
    let mut body_by_face = HashMap::new();
    for (body, (_, faces)) in body_faces.iter().enumerate() {
        for face in faces {
            if body_by_face.contains_key(face) {
                return Ok(None);
            }
            body_by_face.insert(*face, body);
        }
    }
    let mut uses = ctx.alloc_filled(
        body_faces.len(),
        HashMap::<u32, usize>::new(),
        "catia_e5_body_uses",
    )?;
    let mut faces_by_body =
        ctx.alloc_filled(body_faces.len(), Vec::new(), "catia_e5_body_faces")?;
    let mut bodies_by_edge = HashMap::new();
    for &edge in topology.edges.keys() {
        bodies_by_edge.insert(edge, HashSet::new());
    }
    for face in &topology.faces {
        let Some(&body) = body_by_face.get(&face.record_id) else {
            return Ok(None);
        };
        faces_by_body[body].push(face);
        for edge in face
            .loops
            .iter()
            .flat_map(|loop_| loop_.members.iter().map(|member| member.edge_use))
        {
            let Some(edge_bodies) = bodies_by_edge.get_mut(&edge) else {
                return Ok(None);
            };
            edge_bodies.insert(body);
            if let Some(count) = uses[body].get_mut(&edge) {
                *count += 1;
            } else {
                uses[body].insert(edge, 1usize);
            }
        }
    }
    if body_by_face.len() != topology.faces.len()
        || bodies_by_edge.values().any(|bodies| bodies.len() != 1)
    {
        return Ok(None);
    }
    let mut plans = Vec::new();
    for (body, (record_id, faces)) in body_faces.iter().enumerate() {
        let mut face_indices = HashMap::new();
        for (index, &face) in faces.iter().enumerate() {
            face_indices.insert(face, index);
        }
        if face_indices.len() != faces.len() {
            return Ok(None);
        }
        let mut parents = UnionFind::new(faces.len());
        let mut first_face_by_edge = HashMap::<u32, usize>::new();
        for face in &faces_by_body[body] {
            let face_index = face_indices[&face.record_id];
            for edge in face
                .loops
                .iter()
                .flat_map(|loop_| loop_.members.iter().map(|member| member.edge_use))
            {
                if let Some(other) = first_face_by_edge.get_mut(&edge) {
                    parents.union(face_index, *other)?;
                    *other = face_index;
                } else {
                    first_face_by_edge.insert(edge, face_index);
                }
            }
        }
        let mut labels = HashMap::<usize, usize>::new();
        let mut components = Vec::<Vec<u32>>::new();
        let mut face_components = Vec::new();
        for (face_index, face) in faces.iter().copied().enumerate() {
            let root = parents.find(face_index)?;
            let component = if let Some(&existing) = labels.get(&root) {
                existing
            } else {
                let next = labels.len();
                labels.insert(root, next);
                next
            };
            face_components.push(component);
            if component == components.len() {
                components.push(Vec::new());
            }
            components[component].push(face);
        }
        let body_uses = &uses[body];
        let mut closed_components =
            ctx.alloc_filled(components.len(), true, "catia_e5_closed_components")?;
        let mut component_has_edges =
            ctx.alloc_filled(components.len(), false, "catia_e5_component_edges")?;
        for (&edge, &count) in body_uses {
            let component = face_components[first_face_by_edge[&edge]];
            component_has_edges[component] = true;
            closed_components[component] &= count == 2;
        }
        let closed_component_count = closed_components
            .iter()
            .zip(component_has_edges)
            .filter(|(closed, has_edges)| **closed && *has_edges)
            .count();
        let kind = if body_uses.values().any(|count| *count > 2)
            || (closed_component_count != 0 && closed_component_count != components.len())
        {
            BodyKind::General
        } else if closed_component_count == components.len() && !components.is_empty() {
            BodyKind::Solid
        } else {
            BodyKind::Sheet
        };
        plans.push(E5BodyPlan {
            record_id: *record_id,
            kind,
            components,
        });
    }
    Ok(Some(plans))
}

#[cfg(test)]
mod route_tests {
    mod body_ownership;
    mod loop_admission;
    mod occurrence_ranges;
    mod plane_frames;

    use crate::assemble::{quintic_jet_pcurve, rational_pcurve_arc};
    use crate::families::e5::decode::{
        e5_boundary_curve, e5_circle_carriers_have_same_ordered_sweep, e5_native_uv_endpoints,
        e5_occurrence_intersection_context, e5_ownership_plan, e5_pcurve_on_surface,
        e5_stored_pcurve_reversed, equivalent_e5_curve_carriers, parameter_ranges_reversed,
        plan_e5_boundary, solve_e5_plane_frame, EPS_E5_DECODE_EXACT_GEOMETRY,
        EPS_E5_DECODE_POSITION,
    };
    use crate::families::e5::tests::e5_loop_members;

    use crate::families::e5::graph::{
        E5BoundEntry, E5Bounds, E5Edge, E5Face, E5Loop, E5OrientedMember, E5Pcurve,
        E5PcurveJetSite, E5Topology,
    };
    use crate::families::e5::records::E5Surface;
    use crate::families::e5::support::{E5CurveSupport, E5CurveSupportKind};
    use crate::test_support::test_e5::affine_support;

    use cadmpeg_ir::document::CadIr;

    use cadmpeg_ir::geometry::{
        nurbs::NurbsSurface,
        pcurve::{PcurveGeometry, PcurveNurbs},
        CurveGeometry, SolvedCurveGeometry, SolvedSurfaceGeometry, SurfaceGeometry,
    };
    use cadmpeg_ir::ids::{PointId, SurfaceId, VertexId};
    use cadmpeg_ir::math::{Point2, Point3, Vector3};
    use cadmpeg_ir::topology::{BodyKind, Point, Vertex};
    use cadmpeg_ir::AnnotationBuilder;

    use crate::test_support::test_b5::{finite, finite_lane, finite_pair, point, positive};
    use std::collections::{BTreeMap, HashMap};

    #[test]
    fn e5_plane_boundary_area_composes_traversal_and_role() {
        let origin = Point3::new(1.0e12, -1.0e12, 0.0);
        let plane = cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            origin,
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("plane frame");
        let curve = || {
            CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
                    origin,
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                    2.0,
                )
                .expect("circle frame"),
            ))
        };
        let curves = BTreeMap::from([
            (10, (curve(), [0.0, std::f64::consts::PI])),
            (11, (curve(), [std::f64::consts::PI, std::f64::consts::TAU])),
        ]);
        for (outer, reversed, expected) in [
            (true, false, cadmpeg_ir::topology::Sense::Forward),
            (true, true, cadmpeg_ir::topology::Sense::Reversed),
            (false, false, cadmpeg_ir::topology::Sense::Reversed),
            (false, true, cadmpeg_ir::topology::Sense::Forward),
        ] {
            let loop_ = E5Loop {
                record_id: 1,
                surface: 2,
                members: e5_loop_members(&[20, 21], &[10, 11], &[false; 2]),
                oriented_members: Some(
                    (0..2)
                        .map(|serialized_index| E5OrientedMember {
                            serialized_index,
                            reversed,
                        })
                        .collect(),
                ),
                outer,
                absolute_orientation: crate::families::e5::graph::Sign::Positive,
            };
            let plan =
                crate::test_support::with_service_context(|_ctx| super::E5LoopPlan::admit(&loop_))
                    .expect("service budget");
            assert_eq!(
                super::e5_plane_boundary_sense(&plane, &plan, &curves),
                Some(expected)
            );
            let degenerate =
                BTreeMap::from([(10, (curve(), [0.0, 0.0])), (11, (curve(), [0.0, 0.0]))]);
            assert_eq!(
                super::e5_plane_boundary_sense(&plane, &plan, &degenerate),
                None
            );
        }
    }

    fn fixture_pcurve_on_surface(
        pcurve: &E5Pcurve,
        surface: &E5Surface,
        refusal: &mut crate::nurbs::LaneRefusals,
    ) -> Option<(PcurveGeometry, [f64; 2], [Point3; 2])> {
        crate::test_support::with_service_context(|ctx| {
            e5_pcurve_on_surface(ctx, pcurve, surface, refusal)
        })
        .expect("compute the E5 pcurve on surface")
    }

    fn jet_pcurve(
        surface: u32,
        knots: Vec<f64>,
        multiplicities: Vec<u32>,
        points: Vec<[f64; 2]>,
        first_derivatives: Vec<[f64; 2]>,
        second_derivatives: Vec<[f64; 2]>,
        range: [f64; 2],
    ) -> E5Pcurve {
        E5Pcurve::Jet {
            surface,
            sites: E5PcurveJetSite::zip(
                knots.into_iter().map(finite).collect(),
                multiplicities,
                points.into_iter().map(finite_pair).collect(),
                first_derivatives.into_iter().map(finite_pair).collect(),
                second_derivatives.into_iter().map(finite_pair).collect(),
            ),
            range: finite_pair(range),
        }
    }

    #[test]
    fn e5_native_uv_endpoints_reject_nonfinite_results() {
        let line = E5Pcurve::Line {
            surface: 0,
            origin: finite_pair([f64::MAX, 0.0]),
            direction: finite_pair([f64::MAX, 0.0]),
            range: finite_pair([1.0, 2.0]),
        };
        assert!(
            crate::test_support::with_service_context(|ctx| e5_native_uv_endpoints(ctx, &line))
                .expect("compute the E5 native UV endpoints")
                .is_none()
        );

        let circle = E5Pcurve::Circle {
            surface: 0,
            center: finite_pair([f64::MAX, 0.0]),
            codes: [0, 0],
            radius: positive(f64::MAX),
            range: finite_pair([0.0, 1.0]),
            tail: finite_pair([0.0, 0.0]),
        };
        assert!(
            crate::test_support::with_service_context(|ctx| e5_native_uv_endpoints(ctx, &circle))
                .expect("compute the E5 native UV endpoints")
                .is_none()
        );
    }

    #[test]
    fn e5_plane_frame_solver_has_no_boundary_segment_cutoff() {
        let segment_count = 17;
        let mut edges = BTreeMap::new();
        let mut pcurves = BTreeMap::new();
        let mut vertex_refs = Vec::with_capacity(2 * segment_count);
        let mut points = Vec::with_capacity(2 * segment_count);
        let mut pcurve_refs = Vec::with_capacity(segment_count);
        let mut edge_refs = Vec::with_capacity(segment_count);

        for index in 0..segment_count {
            let (start_uv, end_uv) = match index {
                0 => ([0.0, 0.0], [1.0, 0.0]),
                1 => ([0.0, 0.0], [0.0, 1.0]),
                _ => {
                    let offset = cadmpeg_core::convert::f64_from_index(index)
                        .expect("fixture index is exactly representable");
                    ([offset, 0.0], [offset + 0.5, 0.0])
                }
            };
            let start_vertex = 1000 + 2 * u32::try_from(index).expect("fixture value fits u32");
            let end_vertex = start_vertex + 1;
            let edge_ref = 3000 + u32::try_from(index).expect("fixture value fits u32");
            let pcurve_ref = 2000 + u32::try_from(index).expect("fixture value fits u32");
            vertex_refs.extend([start_vertex, end_vertex]);
            points.extend([
                point([start_uv[0], start_uv[1], 0.0]),
                point([end_uv[0], end_uv[1], 0.0]),
            ]);
            pcurve_refs.push(pcurve_ref);
            edge_refs.push(edge_ref);
            edges.insert(
                edge_ref,
                E5Edge {
                    support: 0,
                    start_vertex,
                    end_vertex,
                    parameter_start: 0,
                    parameter_end: 0,
                },
            );
            pcurves.insert(
                pcurve_ref,
                E5Pcurve::Line {
                    surface: 100,
                    origin: finite_pair(start_uv),
                    direction: finite_pair([end_uv[0] - start_uv[0], end_uv[1] - start_uv[1]]),
                    range: finite_pair([0.0, 1.0]),
                },
            );
        }

        let topology = E5Topology {
            bodies: Vec::new(),
            faces: vec![E5Face {
                record_id: 1,
                surface: 100,
                trailer_sign: crate::families::e5::graph::Sign::Positive,
                loops: vec![E5Loop {
                    record_id: 2,
                    surface: 100,
                    members: e5_loop_members(&pcurve_refs, &edge_refs, &vec![false; segment_count]),
                    oriented_members: None,
                    outer: true,
                    absolute_orientation: crate::families::e5::graph::Sign::Positive,
                }],
            }],
            edges,
            pcurves,
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::new(),
            vertex_refs,
        };

        let (normal, u_axis, uv_scale) = crate::test_support::with_service_context(|ctx| {
            solve_e5_plane_frame(ctx, 100, point([0.0, 0.0, 0.0]), &topology, &points, None)
        })
        .expect("solve E5 plane frame")
        .expect("17-segment plane frame");
        assert!(normal.as_raw().dot(Vector3::new(0.0, 0.0, 1.0)) > 1.0 - EPS_E5_DECODE_POSITION);
        assert!(u_axis.as_raw().dot(Vector3::new(1.0, 0.0, 0.0)) > 1.0 - EPS_E5_DECODE_POSITION);
        assert_eq!(uv_scale, finite_pair([1.0, 1.0]));
        assert!(
            crate::test_support::with_service_context(|ctx| solve_e5_plane_frame(
                ctx,
                100,
                point([0.0, 0.0, 0.0]),
                &topology,
                &points,
                Some(Vector3::new(f64::NAN, 0.0, 1.0)),
            ))
            .expect("solve E5 plane frame")
            .is_none()
        );
    }

    #[test]
    fn e5_plane_frame_solver_reflects_native_chart_for_canonical_u_sign() {
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: vec![E5Face {
                record_id: 1,
                surface: 100,
                trailer_sign: crate::families::e5::graph::Sign::Positive,
                loops: vec![E5Loop {
                    record_id: 2,
                    surface: 100,
                    members: e5_loop_members(&[20, 21], &[10, 11], &[false, false]),
                    oriented_members: None,
                    outer: true,
                    absolute_orientation: crate::families::e5::graph::Sign::Positive,
                }],
            }],
            edges: BTreeMap::from([
                (
                    10,
                    E5Edge {
                        support: 0,
                        start_vertex: 1,
                        end_vertex: 2,
                        parameter_start: 0,
                        parameter_end: 0,
                    },
                ),
                (
                    11,
                    E5Edge {
                        support: 0,
                        start_vertex: 1,
                        end_vertex: 3,
                        parameter_start: 0,
                        parameter_end: 0,
                    },
                ),
            ]),
            pcurves: BTreeMap::from([
                (
                    20,
                    E5Pcurve::Line {
                        surface: 100,
                        origin: finite_pair([0.0, 0.0]),
                        direction: finite_pair([1.0, 0.0]),
                        range: finite_pair([0.0, 1.0]),
                    },
                ),
                (
                    21,
                    E5Pcurve::Line {
                        surface: 100,
                        origin: finite_pair([0.0, 0.0]),
                        direction: finite_pair([0.0, 1.0]),
                        range: finite_pair([0.0, 1.0]),
                    },
                ),
            ]),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::new(),
            vertex_refs: vec![1, 2, 3],
        };
        let points = vec![
            point([0.0, 0.0, 0.0]),
            point([-1.0, 0.0, 0.0]),
            point([0.0, -1.0, 0.0]),
        ];
        let (normal, u_axis, uv_scale) = crate::test_support::with_service_context(|ctx| {
            solve_e5_plane_frame(ctx, 100, point([0.0, 0.0, 0.0]), &topology, &points, None)
        })
        .expect("solve E5 plane frame")
        .expect("negative native chart frame");
        assert!(
            normal.as_raw().dot(Vector3::new(0.0, 0.0, 1.0)) > 1.0 - EPS_E5_DECODE_EXACT_GEOMETRY
        );
        assert!(
            u_axis.as_raw().dot(Vector3::new(1.0, 0.0, 0.0)) > 1.0 - EPS_E5_DECODE_EXACT_GEOMETRY
        );
        assert_eq!(uv_scale, finite_pair([-1.0, -1.0]));

        let surface = E5Surface {
            pos: 0,
            record_id: 100,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    *normal.as_raw(),
                    *u_axis.as_raw(),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            uv_scale,
        };
        let (pcurve, range, endpoints) = fixture_pcurve_on_surface(
            &E5Pcurve::Line {
                surface: 100,
                origin: finite_pair([0.0, 0.0]),
                direction: finite_pair([1.0, 0.0]),
                range: finite_pair([0.0, 1.0]),
            },
            &surface,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("reflected plane pcurve");
        assert_eq!(
            endpoints,
            [Point3::new(0.0, 0.0, 0.0), Point3::new(-1.0, 0.0, 0.0)]
        );
        let PcurveGeometry::Line(line_pcurve) = pcurve else {
            panic!("expected reflected line pcurve");
        };
        let direction = line_pcurve.direction().as_raw();
        assert_eq!(*direction, Point2::new(-1.0, 0.0));
        let (curve, _) = crate::test_support::with_service_context(|ctx| {
            e5_boundary_curve(
                ctx,
                &surface.geometry,
                &E5Pcurve::Line {
                    surface: 100,
                    origin: finite_pair([0.0, 0.0]),
                    direction: finite_pair([1.0, 0.0]),
                    range: finite_pair([0.0, 1.0]),
                },
                &PcurveGeometry::Line(
                    cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                        Point2::new(0.0, 0.0),
                        Point2::new(-1.0, 0.0),
                    )
                    .expect("valid LinePcurve fixture"),
                ),
                (range, endpoints),
                uv_scale,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("build the E5 boundary curve")
        .expect("reflected plane boundary");
        assert!(
            matches!(curve, CurveGeometry::Solved(SolvedCurveGeometry::Line(line_curve))
            if {
                let direction = *line_curve.direction().as_raw();
                direction == Vector3::new(-1.0, 0.0, 0.0)
            })
        );
    }

    #[test]
    fn affine_bound_parameters_preserve_or_reverse_native_direction() {
        assert_eq!(
            parameter_ranges_reversed([0.0, 13.0], [0.0, 122.0]),
            Some(false)
        );
        assert_eq!(
            parameter_ranges_reversed([13.0, 0.0], [0.0, 122.0]),
            Some(true)
        );
        assert_eq!(
            parameter_ranges_reversed([0.0, 1e-200], [0.0, 1e-200]),
            Some(false)
        );
        assert_eq!(parameter_ranges_reversed([1.0, 1.0], [0.0, 1.0]), None);
        assert_eq!(
            parameter_ranges_reversed([0.0, f64::INFINITY], [0.0, 1.0]),
            None
        );
    }

    #[test]
    fn affine_bound_parameters_keep_direction_across_finite_wide_ranges() {
        assert_eq!(
            parameter_ranges_reversed([-f64::MAX, f64::MAX], [-f64::MAX, f64::MAX]),
            Some(false)
        );
        assert_eq!(
            parameter_ranges_reversed([f64::MAX, -f64::MAX], [-f64::MAX, f64::MAX]),
            Some(true)
        );
    }

    #[test]
    fn degenerate_bound_parameters_do_not_select_pcurve_direction() {
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: Vec::new(),
            edges: BTreeMap::from([(
                1,
                E5Edge {
                    support: 0,
                    start_vertex: 0,
                    end_vertex: 0,
                    parameter_start: 10,
                    parameter_end: 11,
                },
            )]),
            pcurves: BTreeMap::from([(
                20,
                E5Pcurve::Line {
                    surface: 1,
                    origin: finite_pair([0.0, 0.0]),
                    direction: finite_pair([1.0, 0.0]),
                    range: finite_pair([0.0, 1.0]),
                },
            )]),
            bounds: BTreeMap::from([
                (
                    10,
                    E5Bounds {
                        entries: vec![E5BoundEntry {
                            representation: 20,
                            parameter: crate::test_support::test_b5::finite(1.0),
                            code: 1,
                        }],
                    },
                ),
                (
                    11,
                    E5Bounds {
                        entries: vec![E5BoundEntry {
                            representation: 20,
                            parameter: crate::test_support::test_b5::finite(1.0),
                            code: 1,
                        }],
                    },
                ),
            ]),
            curve_supports: BTreeMap::new(),
            vertex_refs: Vec::new(),
        };

        assert_eq!(
            crate::test_support::with_service_context(|_ctx| e5_stored_pcurve_reversed(
                &topology,
                1,
                20,
                [0.0, 1.0]
            )),
            None
        );
    }

    #[test]
    fn boundary_planning_rejects_degenerate_occurrence_direction() {
        let surface = E5Surface {
            pos: 0,
            record_id: 100,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            uv_scale: finite_pair([1.0, 1.0]),
        };
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: vec![E5Face {
                record_id: 1,
                surface: 100,
                trailer_sign: crate::families::e5::graph::Sign::Positive,
                loops: vec![E5Loop {
                    record_id: 2,
                    surface: 100,
                    members: e5_loop_members(&[20], &[200], &[false]),
                    oriented_members: Some(vec![E5OrientedMember {
                        serialized_index: 0,
                        reversed: false,
                    }]),
                    outer: true,
                    absolute_orientation: crate::families::e5::graph::Sign::Positive,
                }],
            }],
            edges: BTreeMap::from([(
                200,
                E5Edge {
                    support: 300,
                    start_vertex: 400,
                    end_vertex: 401,
                    parameter_start: 500,
                    parameter_end: 501,
                },
            )]),
            pcurves: BTreeMap::from([(
                20,
                E5Pcurve::Line {
                    surface: 100,
                    origin: finite_pair([0.0, 0.0]),
                    direction: finite_pair([1.0, 0.0]),
                    range: finite_pair([0.0, 1.0]),
                },
            )]),
            bounds: BTreeMap::from([
                (
                    500,
                    E5Bounds {
                        entries: vec![E5BoundEntry {
                            representation: 20,
                            parameter: crate::test_support::test_b5::finite(0.0),
                            code: 1,
                        }],
                    },
                ),
                (
                    501,
                    E5Bounds {
                        entries: vec![E5BoundEntry {
                            representation: 20,
                            parameter: crate::test_support::test_b5::finite(0.0),
                            code: 1,
                        }],
                    },
                ),
            ]),
            curve_supports: BTreeMap::from([(
                300,
                E5CurveSupport {
                    kind: E5CurveSupportKind::Boundary {
                        reference_curve: 20,
                    },
                    range: finite_pair([0.0, 1.0]),
                },
            )]),
            vertex_refs: vec![400, 401],
        };
        let surfaces = HashMap::from([(
            100,
            (
                SurfaceId::mint("catia:test:surface#surface".to_string())
                    .expect("identity grammar"),
                &surface,
            ),
        )]);
        let points = HashMap::from([
            (400, Point3::new(0.0, 0.0, 0.0)),
            (401, Point3::new(0.0, 0.0, 0.0)),
        ]);

        assert!(
            crate::test_support::with_service_context(|ctx| plan_e5_boundary(
                ctx,
                &topology,
                &surfaces,
                &points,
                &mut crate::nurbs::LaneRefusals::new()
            ))
            .expect("plan E5 boundary")
            .is_none()
        );
    }

    #[test]
    fn intersection_side_planning_withholds_ambiguous_degenerate_direction() {
        let surface = E5Surface {
            pos: 0,
            record_id: 100,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            uv_scale: finite_pair([1.0, 1.0]),
        };
        let line = || E5Pcurve::Line {
            surface: 100,
            origin: finite_pair([0.0, 0.0]),
            direction: finite_pair([0.001, 0.0]),
            range: finite_pair([0.0, 1.0]),
        };
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: Vec::new(),
            edges: BTreeMap::from([(
                200,
                E5Edge {
                    support: 300,
                    start_vertex: 400,
                    end_vertex: 401,
                    parameter_start: 500,
                    parameter_end: 501,
                },
            )]),
            pcurves: BTreeMap::from([(20, line()), (21, line())]),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::from([(
                300,
                affine_support([20, 21], finite_pair([0.0, 1.0])),
            )]),
            vertex_refs: vec![400, 401],
        };
        let surfaces = HashMap::from([(
            100,
            (
                SurfaceId::mint("catia:test:surface#surface".to_string())
                    .expect("identity grammar"),
                &surface,
            ),
        )]);
        let points = HashMap::from([
            (400, Point3::new(0.0001, 0.0, 0.0)),
            (401, Point3::new(0.0004, 0.0, 0.0)),
        ]);

        let plan = crate::test_support::with_service_context(|ctx| {
            plan_e5_boundary(
                ctx,
                &topology,
                &surfaces,
                &points,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("plan E5 boundary")
        .expect("boundary plan");
        assert!(plan.intersections.is_empty());
        assert!(plan.edge_curves.is_empty());
    }

    #[test]
    fn intersection_side_planning_retains_reference_facet_without_conflicting_intersection() {
        let surface = E5Surface {
            pos: 0,
            record_id: 100,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            uv_scale: finite_pair([1.0, 1.0]),
        };
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: vec![
                E5Face {
                    record_id: 1,
                    surface: 100,
                    trailer_sign: crate::families::e5::graph::Sign::Positive,
                    loops: vec![E5Loop {
                        record_id: 2,
                        surface: 100,
                        members: e5_loop_members(&[20], &[200], &[false]),
                        oriented_members: Some(vec![E5OrientedMember {
                            serialized_index: 0,
                            reversed: false,
                        }]),
                        outer: true,
                        absolute_orientation: crate::families::e5::graph::Sign::Positive,
                    }],
                },
                E5Face {
                    record_id: 3,
                    surface: 100,
                    trailer_sign: crate::families::e5::graph::Sign::Positive,
                    loops: vec![E5Loop {
                        record_id: 4,
                        surface: 100,
                        members: e5_loop_members(&[21], &[200], &[false]),
                        oriented_members: Some(vec![E5OrientedMember {
                            serialized_index: 0,
                            reversed: false,
                        }]),
                        outer: true,
                        absolute_orientation: crate::families::e5::graph::Sign::Positive,
                    }],
                },
            ],
            edges: BTreeMap::from([(
                200,
                E5Edge {
                    support: 300,
                    start_vertex: 400,
                    end_vertex: 401,
                    parameter_start: 500,
                    parameter_end: 501,
                },
            )]),
            pcurves: BTreeMap::from([
                (
                    20,
                    E5Pcurve::Line {
                        surface: 100,
                        origin: finite_pair([0.0, 0.0]),
                        direction: finite_pair([1.0, 0.0]),
                        range: finite_pair([0.0, 1.0]),
                    },
                ),
                (
                    21,
                    E5Pcurve::Circle {
                        surface: 100,
                        center: finite_pair([0.5, 0.0]),
                        codes: [0, 0],
                        radius: positive(0.5),
                        range: finite_pair([0.0, std::f64::consts::FRAC_PI_2]),
                        tail: finite_pair([0.0, 0.0]),
                    },
                ),
            ]),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::from([(
                300,
                affine_support([20, 21], finite_pair([0.0, 1.0])),
            )]),
            vertex_refs: vec![400, 401],
        };
        let surfaces = HashMap::from([(
            100,
            (
                SurfaceId::mint("catia:test:surface#surface".to_string())
                    .expect("identity grammar"),
                &surface,
            ),
        )]);
        let points = HashMap::from([
            (400, Point3::new(0.0, 0.0, 0.0)),
            (401, Point3::new(1.0, 0.0, 0.0)),
        ]);

        let plan = crate::test_support::with_service_context(|ctx| {
            plan_e5_boundary(
                ctx,
                &topology,
                &surfaces,
                &points,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("service resource budget")
        .expect("boundary plan");
        assert!(plan.intersections.is_empty());
        assert!(!plan.surface_curves.contains_key(&200));
        let (reference, range) = plan.edge_curves.get(&200).expect("source reference facet");
        assert_eq!(*range, [0.0, 1.0]);
        assert!(matches!(
            reference,
            CurveGeometry::Solved(SolvedCurveGeometry::Line(_))
        ));

        // Equal circular loci do not make their rational UV parameters
        // affine in the exact analytic circle's angle parameter.
        let mut circular = topology;
        let circle = E5Pcurve::Circle {
            surface: 100,
            center: finite_pair([0.0, 0.0]),
            codes: [0, 0],
            radius: positive(1.0),
            range: finite_pair([0.0, std::f64::consts::FRAC_PI_2]),
            tail: finite_pair([0.0, 0.0]),
        };
        circular.pcurves.insert(20, circle.clone());
        circular.pcurves.insert(21, circle);
        let points = HashMap::from([
            (400, Point3::new(1.0, 0.0, 0.0)),
            (401, Point3::new(0.0, 1.0, 0.0)),
        ]);
        let plan = crate::test_support::with_service_context(|ctx| {
            plan_e5_boundary(
                ctx,
                &circular,
                &surfaces,
                &points,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("service budget")
        .expect("circular boundary plan");
        assert!(plan.intersections.is_empty());
        assert!(matches!(
            plan.edge_curves.get(&200),
            Some((CurveGeometry::Solved(SolvedCurveGeometry::Circle(_)), _))
        ));
    }

    #[test]
    fn e5_coedge_pcurve_use_composes_native_and_edge_direction() {
        let mut topology = E5Topology {
            bodies: Vec::new(),
            faces: vec![E5Face {
                record_id: 1,
                surface: 100,
                trailer_sign: crate::families::e5::graph::Sign::Positive,
                loops: vec![E5Loop {
                    record_id: 2,
                    surface: 100,
                    members: e5_loop_members(&[30], &[20], &[false]),
                    oriented_members: Some(vec![crate::families::e5::graph::E5OrientedMember {
                        serialized_index: 0,
                        reversed: false,
                    }]),
                    outer: true,
                    absolute_orientation: crate::families::e5::graph::Sign::Positive,
                }],
            }],
            edges: BTreeMap::from([(
                20,
                E5Edge {
                    support: 40,
                    start_vertex: 10,
                    end_vertex: 11,
                    parameter_start: 0,
                    parameter_end: 0,
                },
            )]),
            pcurves: BTreeMap::from([(
                30,
                E5Pcurve::Line {
                    surface: 100,
                    origin: finite_pair([1.0, 0.0]),
                    direction: finite_pair([-1.0, 0.0]),
                    range: finite_pair([0.0, 1.0]),
                },
            )]),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::from([(
                40,
                E5CurveSupport {
                    kind: E5CurveSupportKind::Boundary {
                        reference_curve: 30,
                    },
                    range: finite_pair([0.0, 1.0]),
                },
            )]),
            vertex_refs: vec![10, 11],
        };
        for (edge, start, end, pcurve, origin, direction) in [
            (21, 11, 12, 31, [1.0, 0.0], [-1.0, 1.0]),
            (22, 12, 10, 32, [0.0, 1.0], [0.0, -1.0]),
        ] {
            topology.edges.insert(
                edge,
                E5Edge {
                    support: pcurve + 10,
                    start_vertex: start,
                    end_vertex: end,
                    parameter_start: 0,
                    parameter_end: 0,
                },
            );
            topology.pcurves.insert(
                pcurve,
                E5Pcurve::Line {
                    surface: 100,
                    origin: finite_pair(origin),
                    direction: finite_pair(direction),
                    range: finite_pair([0.0, 1.0]),
                },
            );
            topology.curve_supports.insert(
                pcurve + 10,
                E5CurveSupport {
                    kind: E5CurveSupportKind::Boundary {
                        reference_curve: pcurve,
                    },
                    range: finite_pair([0.0, 1.0]),
                },
            );
        }
        topology.bodies.push(crate::families::e5::graph::E5Body {
            record_id: 99,
            faces: vec![crate::families::e5::graph::E5BodyFace {
                record_id: 1,
                orientation: crate::families::e5::graph::Sign::Positive,
            }],
        });
        topology.vertex_refs.push(12);
        topology.faces[0].loops[0].members =
            e5_loop_members(&[30, 31, 32], &[20, 21, 22], &[false; 3]);
        topology.faces[0].loops[0].oriented_members = Some(
            (0..3)
                .map(|serialized_index| E5OrientedMember {
                    serialized_index,
                    reversed: false,
                })
                .collect(),
        );
        let mut ir = CadIr::empty();
        ir.geometry.points.extend([
            Point::new(
                PointId::mint("catia:test:point#point-10".to_string()).expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(0.0, 0.0, 0.0))
                    .expect("a finite position is a point"),
                None,
            ),
            Point::new(
                PointId::mint("catia:test:point#point-11".to_string()).expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.0, 0.0, 0.0))
                    .expect("a finite position is a point"),
                None,
            ),
        ]);
        ir.geometry.vertices.extend([
            Vertex {
                id: VertexId::mint("catia:test:vertex#vertex-10".to_string())
                    .expect("identity grammar"),
                point: PointId::mint("catia:test:point#point-10".to_string())
                    .expect("identity grammar"),
                tolerance: None,
                native_ref: None,
            },
            Vertex {
                id: VertexId::mint("catia:test:vertex#vertex-11".to_string())
                    .expect("identity grammar"),
                point: PointId::mint("catia:test:point#point-11".to_string())
                    .expect("identity grammar"),
                tolerance: None,
                native_ref: None,
            },
        ]);
        ir.geometry.points.push(Point::new(
            PointId::mint("catia:test:point#point-12".to_string()).expect("identity grammar"),
            point([0.0, 1.0, 0.0]),
            None,
        ));
        ir.geometry.vertices.push(Vertex {
            id: VertexId::mint("catia:test:vertex#vertex-12".to_string())
                .expect("identity grammar"),
            point: PointId::mint("catia:test:point#point-12".to_string())
                .expect("identity grammar"),
            tolerance: None,
            native_ref: None,
        });
        let surface = crate::families::e5::records::E5Surface {
            pos: 0,
            record_id: 100,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            uv_scale: finite_pair([1.0, 1.0]),
        };
        let mut annotations = AnnotationBuilder::new();
        crate::test_support::with_service_context(|ctx| {
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            assert!(super::transfer_e5_topology(
                ctx,
                (&mut ir, &mut annotations),
                &topology,
                &[surface],
                &mut crate::nurbs::LaneRefusals::new(),
                &mut admission,
                &mut Vec::new()
            )
            .expect("transfer E5 topology"));
        });
        assert_eq!(
            ir.geometry.coedges[0].pcurves[0]
                .parameter_range
                .map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints),
            Some([1.0, 0.0])
        );
        let vertex_uses = ir.geometry.loops[0].anchored_vertex_uses();
        assert_eq!(vertex_uses.len(), 3);
        let vertex_use = &vertex_uses[0];
        assert_eq!(
            vertex_use.vertex,
            VertexId::mint("catia:e5:v#1".to_string()).expect("identity grammar")
        );
        assert_eq!(vertex_use.after.as_str(), "catia:e5:coedge#2-0");
    }

    #[test]
    fn e5_ownership_requires_complete_bodies_and_partitions_face_components() {
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let policy = cadmpeg_core::decode::DecodePolicy::service();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
            .expect("fixture fits input limit");
        let face = |record_id, edge_use| E5Face {
            record_id,
            surface: 100 + record_id,
            trailer_sign: crate::families::e5::graph::Sign::Positive,
            loops: vec![E5Loop {
                record_id: 200 + record_id,
                surface: 100 + record_id,
                members: e5_loop_members(&[300 + record_id], &[edge_use], &[false]),
                oriented_members: Some(vec![crate::families::e5::graph::E5OrientedMember {
                    serialized_index: 0,
                    reversed: false,
                }]),
                outer: true,
                absolute_orientation: crate::families::e5::graph::Sign::Positive,
            }],
        };
        let edge = || E5Edge {
            support: 20,
            start_vertex: 30,
            end_vertex: 31,
            parameter_start: 40,
            parameter_end: 41,
        };
        let topology = |faces: Vec<E5Face>, edges: Vec<u32>| E5Topology {
            bodies: Vec::new(),
            faces,
            edges: edges
                .into_iter()
                .map(|record_id| (record_id, edge()))
                .collect(),
            pcurves: BTreeMap::new(),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::new(),
            vertex_refs: Vec::new(),
        };

        let plan = e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10)], vec![10]),
            &[(1, vec![1])],
        )
        .expect("build the E5 ownership plan")
        .expect("required invariant");
        assert_eq!(plan[0].kind, BodyKind::Sheet);
        assert_eq!(plan[0].components, vec![vec![1]]);

        let plan = e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10), face(2, 10)], vec![10]),
            &[(1, vec![1, 2])],
        )
        .expect("build the E5 ownership plan")
        .expect("required invariant");
        assert_eq!(plan[0].kind, BodyKind::Solid);
        assert_eq!(plan[0].components, vec![vec![1, 2]]);

        let plan = e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10), face(2, 11)], vec![10, 11]),
            &[(1, vec![1, 2])],
        )
        .expect("build the E5 ownership plan")
        .expect("required invariant");
        assert_eq!(plan[0].kind, BodyKind::Sheet);
        assert_eq!(plan[0].components, vec![vec![1], vec![2]]);

        let plan = e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10), face(2, 10), face(3, 11)], vec![10, 11]),
            &[(1, vec![1, 2, 3])],
        )
        .expect("build the E5 ownership plan")
        .expect("required invariant");
        assert_eq!(plan[0].kind, BodyKind::General);
        assert_eq!(plan[0].components, vec![vec![1, 2], vec![3]]);

        assert!(e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10), face(2, 10)], vec![10]),
            &[(1, vec![1]), (2, vec![2])],
        )
        .expect("build the E5 ownership plan")
        .is_none());
        assert!(e5_ownership_plan(
            &ctx,
            &topology(vec![face(1, 10)], vec![10, 11]),
            &[(1, vec![1])],
        )
        .expect("build the E5 ownership plan")
        .is_none());
        assert!(
            e5_ownership_plan(&ctx, &topology(Vec::new(), Vec::new()), &[])
                .expect("build the E5 ownership plan")
                .is_none()
        );
    }

    #[test]
    fn rational_arc_preserves_angular_parameterization() {
        let arc = rational_pcurve_arc(
            [2.0, -3.0],
            4.0,
            [0.0, std::f64::consts::PI],
            &mut crate::nurbs::LaneRefusals::new(),
            "test record",
        )
        .expect("semicircle");
        for (parameter, expected) in [
            (0.0, [6.0, -3.0]),
            (std::f64::consts::FRAC_PI_2, [2.0, 1.0]),
            (std::f64::consts::PI, [-2.0, -3.0]),
        ] {
            let point = cadmpeg_ir::eval::decode::pcurve_uv(
                cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                &arc,
                parameter,
            )
            .expect("arc evaluation");
            assert!((point.u - expected[0]).abs() < EPS_E5_DECODE_EXACT_GEOMETRY);
            assert!((point.v - expected[1]).abs() < EPS_E5_DECODE_EXACT_GEOMETRY);
        }
    }

    #[test]
    fn rational_arc_rejects_unbounded_subdivision_counts() {
        assert!(rational_pcurve_arc(
            [0.0, 0.0],
            1.0,
            [0.0, 1.0e300],
            &mut crate::nurbs::LaneRefusals::new(),
            "test record"
        )
        .is_none());
    }

    #[test]
    fn e5_cylinder_isoparametric_boundary_lifts_to_circle_carrier() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
            )
            .expect("valid CylinderSurface fixture"),
        ));
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                cadmpeg_ir::math::Point2::new(0.0, 3.0),
                cadmpeg_ir::math::Point2::new(1.0, 0.0),
            )
            .expect("valid LinePcurve fixture"),
        );
        let native = crate::families::e5::graph::E5Pcurve::Line {
            surface: 0,
            origin: finite_pair([0.0, 3.0]),
            direction: finite_pair([1.0, 0.0]),
            range: finite_pair([0.0, std::f64::consts::FRAC_PI_2]),
        };
        let (curve, range) = crate::test_support::with_service_context(|ctx| {
            e5_boundary_curve(
                ctx,
                &surface,
                &native,
                &pcurve,
                (
                    [0.0, std::f64::consts::FRAC_PI_2],
                    [Point3::new(2.0, 0.0, 3.0), Point3::new(0.0, 2.0, 3.0)],
                ),
                finite_pair([1.0, 1.0]),
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("build the E5 boundary curve")
        .expect("cylinder boundary circle");
        assert!(
            matches!(curve, CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve))
                    if {
                        let center = circle_curve.center().get();
            let radius = circle_curve.radius().get();
                        center == Point3::new(0.0, 0.0, 3.0) && radius == 2.0
                    })
        );
        assert!(
            (range[1] - range[0] - std::f64::consts::FRAC_PI_2).abs()
                < EPS_E5_DECODE_EXACT_GEOMETRY
        );
    }

    #[test]
    fn e5_nearly_isoparametric_boundary_lifts_to_circle_carrier() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
            )
            .expect("valid CylinderSurface fixture"),
        ));
        let transverse_noise = f64::EPSILON;
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, 3.0),
                Point2::new(1.0, transverse_noise),
            )
            .expect("valid LinePcurve fixture"),
        );
        let native = crate::families::e5::graph::E5Pcurve::Line {
            surface: 0,
            origin: finite_pair([0.0, 3.0]),
            direction: finite_pair([1.0, transverse_noise]),
            range: finite_pair([0.0, std::f64::consts::FRAC_PI_2]),
        };
        let (curve, _) = crate::test_support::with_service_context(|ctx| {
            e5_boundary_curve(
                ctx,
                &surface,
                &native,
                &pcurve,
                (
                    [0.0, std::f64::consts::FRAC_PI_2],
                    [Point3::new(2.0, 0.0, 3.0), Point3::new(0.0, 2.0, 3.0)],
                ),
                finite_pair([1.0, 1.0]),
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("build the E5 boundary curve")
        .expect("near-isoparametric cylinder boundary circle");
        assert!(
            matches!(curve, CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)) if { circle_curve.radius().get() == 2.0 })
        );
    }

    #[test]
    fn e5_boundary_classification_is_scale_independent() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
            )
            .expect("valid CylinderSurface fixture"),
        ));
        let direction = 1e-200;
        let parameter_end = 1e200;
        assert!(matches!(
            super::e5_isoparametric_direction(Point2::new(direction, 0.0)),
            Some(super::E5IsoparametricDirection::ConstantV)
        ));
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, 3.0),
                Point2::new(1.0, 0.0),
            )
            .expect("valid LinePcurve fixture"),
        );
        let native = crate::families::e5::graph::E5Pcurve::Line {
            surface: 0,
            origin: finite_pair([0.0, 3.0]),
            direction: finite_pair([direction, 0.0]),
            range: finite_pair([0.0, parameter_end]),
        };
        let (curve, _) = crate::test_support::with_service_context(|ctx| {
            e5_boundary_curve(
                ctx,
                &surface,
                &native,
                &pcurve,
                (
                    [0.0, direction * parameter_end],
                    [
                        Point3::new(2.0, 0.0, 3.0),
                        Point3::new(2.0 * 1.0f64.cos(), 2.0 * 1.0f64.sin(), 3.0),
                    ],
                ),
                finite_pair([1.0, 1.0]),
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("build the E5 boundary curve")
        .expect("cylinder boundary circle");
        assert!(
            matches!(curve, CurveGeometry::Solved(SolvedCurveGeometry::Circle(circle_curve)) if { circle_curve.radius().get() == 2.0 })
        );

        let plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        ));
        let plane_pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, 0.0),
                Point2::new(1.0, 0.0),
            )
            .expect("valid LinePcurve fixture"),
        );
        let plane_native = crate::families::e5::graph::E5Pcurve::Line {
            surface: 0,
            origin: finite_pair([0.0, 0.0]),
            direction: finite_pair([direction, 0.0]),
            range: finite_pair([0.0, 1.0]),
        };
        let tiny_endpoint = Point3::new(direction, 0.0, 0.0);
        let (curve, range) = crate::test_support::with_service_context(|ctx| {
            e5_boundary_curve(
                ctx,
                &plane,
                &plane_native,
                &plane_pcurve,
                (
                    [0.0, direction],
                    [Point3::new(0.0, 0.0, 0.0), tiny_endpoint],
                ),
                finite_pair([1.0, 1.0]),
                &mut crate::nurbs::LaneRefusals::new(),
            )
        })
        .expect("build the E5 boundary curve")
        .expect("finite nonzero plane line");
        assert!(matches!(
            curve,
            CurveGeometry::Solved(SolvedCurveGeometry::Line(_))
        ));
        assert_eq!(range, [0.0, direction]);
    }

    mod boundary_cases;

    #[test]
    fn unreferenced_e5_surface_moves_to_the_unused_list() {
        let topology = E5Topology {
            bodies: Vec::new(),
            faces: Vec::new(),
            edges: BTreeMap::new(),
            pcurves: BTreeMap::new(),
            bounds: BTreeMap::new(),
            curve_supports: BTreeMap::new(),
            vertex_refs: Vec::new(),
        };
        let run = |_: &cadmpeg_core::decode::DecodeContext<'_>| {
            let mut ir = CadIr::empty();
            ir.geometry.surfaces.push(super::Surface {
                id: SurfaceId::compose(
                    &cadmpeg_ir::identity_namespace!("catia", "e5", "surf"),
                    0usize,
                ),
                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid test plane"),
                )),
                source_object: None,
                native_ref: None,
            });
            let mut unused = Vec::new();
            super::prune_e5_unused_surfaces(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &topology,
                &HashMap::new(),
                (&BTreeMap::new(), &BTreeMap::new()),
                &mut unused,
            );
            Ok::<_, cadmpeg_core::CodecError>((ir.geometry.surfaces, unused))
        };
        let (surfaces, unused) =
            crate::test_support::with_service_context(run).expect("prune the unused E5 surfaces");
        assert!(surfaces.is_empty());
        assert_eq!(unused.len(), 1);
    }

    #[test]
    fn e5_jet_pcurve_lowers_onto_a_plane() {
        let surface = E5Surface {
            pos: 0,
            record_id: 7,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid plane fixture"),
            )),
            uv_scale: finite_pair([1.0, 1.0]),
        };
        let pcurve = jet_pcurve(
            7,
            vec![0.0, 1.0],
            vec![6, 6],
            vec![[0.0, 0.0], [1.0, 0.0]],
            vec![[1.0, 0.0]; 2],
            vec![[0.0, 0.0]; 2],
            [0.0, 1.0],
        );
        let run = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
            e5_pcurve_on_surface(
                ctx,
                &pcurve,
                &surface,
                &mut crate::nurbs::LaneRefusals::new(),
            )
        };
        assert!(crate::test_support::with_service_context(run)
            .expect("compute the E5 pcurve on surface")
            .is_some());
    }
}
