// SPDX-License-Identifier: Apache-2.0
//! Standard-family dump tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_test_support::wire;

use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, DecodeOptions};

use cadmpeg_ir::geometry::{
    ProceduralCurveDefinition, SolvedCurveGeometry, SolvedSurfaceGeometry, SurfaceGeometry,
};

use cadmpeg_ir::math::{Point3, Vector3};

use crate::coverage::{
    STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_BOUNDARY_RECONSTRUCTION_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_NO_ASSIGNMENT_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_CHOICE_PRUNING_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_COMPOSITION_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_DOMAIN_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_FIXED_ASSIGNMENT_COUNT,
    STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_INPUT_SHAPE_COUNT,
};
use crate::test_support::test_a5_bound::{a5_native_edge_run_stream, a5_nurbs_bound_edge_stream};
use crate::test_support::test_a5a8::{
    a5_freeform_curve_stream, a5_guide_curve_stream, a5_native_edge_identity_stream,
    a5_pcurve_stream, a5_pcurve_stream_with_uv, a5_surface_stream,
};
use crate::test_support::test_b2::{
    b2_cone_stream, b2_construction_use_stream_for, b2_cylinder_stream,
    b2_edge_parameter_stream_for, b2_offset_support_stream_for,
};
use crate::test_support::test_bytes::{be32, be_f32, le_f64};
use crate::test_support::test_container::{
    fbb_only_catpart, main_stream, standard_catpart, standard_catpart_from_streams, surf_stream,
    tetrahedron_topology_catpart,
};
use crate::variant::Variant;
use crate::CatiaCodec;

const EPS_TRANSFER_PLANE_FRAME: f64 = 1.0e-6;

#[test]
fn standard_population_scope_preserves_a_body_name_that_spells_its_identity() {
    use super::super::StandardPopulationScope;
    use cadmpeg_ir::document::EntityRewrite;
    use cadmpeg_ir::ids::BodyId;
    use cadmpeg_ir::topology::{Body, BodyKind};
    let source_id = "catia:standard:body#source";
    let body = Body {
        id: BodyId::mint(source_id).unwrap(),
        kind: BodyKind::Solid,
        transform: None,
        name: Some(source_id.into()),
        color: None,
        visible: None,
        native_ref: None,
    };
    let scoped = crate::test_support::with_service_context(|ctx| {
        StandardPopulationScope {
            scope: "population-1",
            ctx,
        }
        .rewrite(body)
    })
    .unwrap();
    assert_eq!(
        scoped.id.as_str(),
        "catia:standard:population-1/body#source"
    );
    assert_eq!(scoped.name.as_deref(), Some(source_id));
}

#[test]
fn standard_decode_retains_native_surface_carrier_tags() {
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart()),
            &DecodeOptions::default(),
        )
        .expect("standard decode");
    let identities = decoded
        .ir()
        .geometry
        .surfaces
        .iter()
        .filter_map(|surface| {
            surface
                .source_object
                .as_ref()
                .map(|source| (source.format.as_str(), source.object_id.as_str()))
        })
        .collect::<Vec<_>>();
    assert_eq!(
        identities,
        [
            ("catia", "cgm-carrier:ccbbaa"),
            ("catia", "cgm-carrier:332211"),
        ]
    );
}

#[test]
fn standard_decode_distinguishes_consolidated_surface_frames() {
    let mut payload = a5_surface_stream();
    payload.extend_from_slice(&a5_surface_stream());
    let mut file = standard_catpart();
    file.splice(16..16, payload);
    let file_len = u32::try_from(file.len()).unwrap();
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("standard decode");
    let identities = decoded
        .ir()
        .geometry
        .surfaces
        .iter()
        .filter_map(|surface| surface.source_object.as_ref())
        .map(|source| source.object_id.as_str())
        .collect::<Vec<_>>();
    let frame_identities = identities
        .iter()
        .copied()
        .filter(|identity| identity.starts_with("cgm-a5-surface-frame:"))
        .collect::<std::collections::HashSet<_>>();

    assert_eq!(frame_identities.len(), 2);
    assert!(!identities.contains(&"cgm-surface:000000"));
}

#[test]
fn standard_decode_retains_vertex_allocation_tags() {
    let mut surf = surf_stream();
    for identity in [0x01_0203u32, 0x01_0206, 0x01_0209] {
        surf.push(0x54);
        surf.extend_from_slice(&identity.to_le_bytes()[..3]);
        surf.extend_from_slice(&[0, 0, 0]);
    }
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_from_streams(&main_stream(), &surf)),
            &DecodeOptions::default(),
        )
        .expect("standard decode");
    let identities = decoded
        .ir()
        .geometry
        .points
        .iter()
        .map(|point| {
            point
                .source_object
                .as_ref()
                .map(|source| (source.format.as_str(), source.object_id.as_str()))
        })
        .collect::<Vec<_>>();
    assert_eq!(
        identities,
        [
            Some(("catia", "cgm-vertex:010203")),
            Some(("catia", "cgm-vertex:010206")),
            Some(("catia", "cgm-vertex:010209")),
        ]
    );
}

#[test]
fn decode_standard_transfers_vertices_and_cylinder() {
    let f = standard_catpart();
    let mut cur = Cursor::new(f);
    let result = CatiaCodec
        .decode(&mut cur, &DecodeOptions::default())
        .unwrap();

    assert!(result.report().geometry_transferred());
    // Three vertex records → three points and three vertices.
    assert_eq!(result.ir().geometry.points.len(), 3);
    assert_eq!(result.ir().geometry.vertices.len(), 3);
    // A vertex coordinate is transferred verbatim in millimetres (no scaling).
    assert!(result
        .ir()
        .geometry
        .points
        .iter()
        .any(|p| (p.position().get().x - 10.0).abs() < 1.0e-6));

    // Cylinder and tag-bridged plane carriers are decoded from their stored
    // parameters.
    assert_eq!(result.ir().geometry.surfaces.len(), 2);
    assert_eq!(result.ir().geometry.curves.len(), 1);
    let unknowns = result.ir().native_unknowns("catia").unwrap();
    assert_eq!(unknowns.len(), 1);
    assert_eq!(unknowns[0].id.as_str(), "catia:payload:unknown#brep-stream");
    assert!(unknowns[0]
        .links
        .iter()
        .any(|link| link.as_str() == "catia:standard:circle#0"));
    match &result.ir().geometry.surfaces[0].geometry {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) => {
            let axis = cylinder_surface.frame().axis().as_raw();
            let radius = cylinder_surface.radius().get();
            assert!((radius - 5.0).abs() < 1.0e-6);
            assert!((axis.z - 1.0).abs() < 1.0e-6);
        }
        other => panic!("expected cylinder, got {other:?}"),
    }
    assert!(result.ir().geometry.surfaces.iter().any(
        |surface| matches!(&surface.geometry, SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(plane_surface))
                if {
                    let origin = plane_surface.origin();
        let normal = plane_surface.frame().axis().as_raw();
        let u_axis = plane_surface.frame().reference().as_raw();
                    (origin.x - 1.0).abs() < EPS_TRANSFER_PLANE_FRAME
                        && (origin.y - 2.0).abs() < EPS_TRANSFER_PLANE_FRAME
                        && (origin.z - 3.0).abs() < EPS_TRANSFER_PLANE_FRAME
                        && normal.x.abs() < EPS_TRANSFER_PLANE_FRAME
                        && normal.y.abs() < EPS_TRANSFER_PLANE_FRAME
                        && (normal.z.abs() - 1.0).abs() < EPS_TRANSFER_PLANE_FRAME
                        && (u_axis.x * u_axis.x + u_axis.y * u_axis.y + u_axis.z * u_axis.z - 1.0)
                            .abs()
                            < EPS_TRANSFER_PLANE_FRAME
                        && (u_axis.x * normal.x + u_axis.y * normal.y + u_axis.z * normal.z).abs()
                            < EPS_TRANSFER_PLANE_FRAME
                })
    ));

    // Stored face/carrier rows do not establish a B-rep without a complete
    // trim and edge graph. Carriers remain free and vertices receive only the
    // neutral ownership required for a disconnected point set.
    assert!(result.ir().geometry.faces.is_empty());
    assert_eq!(result.ir().geometry.bodies.len(), 1);
    assert_eq!(
        result.ir().geometry.bodies[0].kind,
        cadmpeg_ir::topology::BodyKind::Wire
    );
    assert_eq!(result.ir().geometry.shells[0].free_vertices().count(), 3);
    assert!(result.ir().geometry.edges.is_empty());
    assert!(result
        .report()
        .losses
        .iter()
        .any(|l| l.code.category() == cadmpeg_ir::report::loss::LossCategory::Topology));
    assert_eq!(
        wire::coverage_count(
            result.report(),
            crate::coverage::ATTEMPTED_STANDARD_TOPOLOGY_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            result.report(),
            crate::coverage::ATTACHED_STANDARD_TOPOLOGY_COUNT.as_str()
        ),
        0
    );
    assert_eq!(
        wire::coverage(result.report())
            .iter()
            .filter(|(key, _)| key.starts_with("standard_topology_failure_"))
            .map(|(_, count)| count)
            .sum::<usize>(),
        1
    );
    assert_eq!(
        [
            "standard_topology_mesh_ambiguity_coordinate_root_closure_count",
            "standard_topology_mesh_ambiguity_endpoint_resolution_count",
            "standard_topology_mesh_ambiguity_distinct_topology_solutions_count",
        ]
        .into_iter()
        .map(|key| wire::coverage(result.report())
            .get(key)
            .copied()
            .unwrap_or(0))
        .sum::<usize>(),
        wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_FAILURE_AMBIGUOUS_SOLUTION_COUNT.as_str()
        )
    );
    assert_eq!(
        wire::coverage(result.report())
            .get("standard_topology_mesh_exhaustion_quotient_preparation_count"),
        Some(&0)
    );
    assert_eq!(
        [
            "standard_topology_mesh_exhaustion_quotient_preparation_count",
            "standard_topology_mesh_exhaustion_incidence_enumeration_count",
            "standard_topology_mesh_exhaustion_endpoint_resolution_count",
        ]
        .into_iter()
        .map(|key| wire::coverage(result.report())
            .get(key)
            .copied()
            .unwrap_or(0))
        .sum::<usize>(),
        wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_FAILURE_SEARCH_EXHAUSTED_COUNT.as_str()
        )
    );
    assert_eq!(
        wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_EMPTY_ENDPOINT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_SINGLETON_ENDPOINT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_MULTIPLE_ENDPOINT_DOMAIN_COUNT.as_str()
        ),
        wire::coverage_count(
            result.report(),
            crate::coverage::STANDARD_TOPOLOGY_CURVE_SUPPORT_COUNT.as_str()
        )
    );
    assert!(
        wire::coverage(result.report())
            .iter()
            .filter(|(key, _)| {
                key.starts_with("standard_topology_mesh_rejection_")
                    && !key.starts_with("standard_topology_mesh_rejection_incidence_")
                    && (!key.contains("endpoint_incidence_")
                        || key.ends_with("endpoint_incidence_count"))
            })
            .map(|(_, count)| count)
            .sum::<usize>()
            <= 1
    );
    assert_eq!(
        wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_COUNT.as_str()
        ),
        wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_NO_ASSIGNMENT_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_BOUNDARY_RECONSTRUCTION_COUNT
                .as_str()
        )
    );
    assert_eq!(
        wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_NO_ASSIGNMENT_COUNT.as_str()
        ),
        wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_INPUT_SHAPE_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_CHOICE_PRUNING_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_FIXED_ASSIGNMENT_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            result.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_COMPOSITION_COUNT.as_str()
        )
    );

    // The produced IR validates (free carriers, no dangling references).
    let report = cadmpeg_ir::validate::validate_neutral(result.ir(), Vec::new())
        .expect("validate the neutral model");
    assert!(report.is_ok(), "findings: {:?}", report.findings);
}

#[test]
fn decode_standard_retains_unresolved_roster_carrier_without_fabricating_a_face() {
    let mut surf = surf_stream();
    let plane = [0x11, 0x22, 0x33, 0x00, 0x02, 0x00, 0x33, 0x32];
    let plane_start = surf
        .windows(plane.len())
        .position(|bytes| bytes == plane)
        .expect("complete plane record");
    // Zero bounds retain the framed carrier but provide no valid plane parameters.
    surf[plane_start + plane.len()..plane_start + plane.len() + 40].fill(0);
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(standard_catpart_from_streams(&main_stream(), &surf)),
            &DecodeOptions::default(),
        )
        .expect("decode unresolved roster carrier");

    assert_eq!(decoded.ir().geometry.surfaces.len(), 2);
    assert!(decoded.ir().geometry.faces.is_empty());
    assert!(matches!(
        decoded.ir().geometry.surfaces[1].geometry,
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: Some(_) })
    ));
    assert!(decoded.report().losses.iter().any(|loss| {
        loss.code.category() == cadmpeg_ir::report::loss::LossCategory::Geometry
            && loss.severity == cadmpeg_ir::report::Severity::Blocking
            && loss.message.contains("1 unresolved surface carriers")
            && loss
                .message
                .contains(decoded.ir().geometry.surfaces[1].id.as_str())
    }));
}

#[test]
fn decode_standard_builds_surface_bound_topology_graph() {
    let decoded = CatiaCodec
        .decode(
            &mut Cursor::new(tetrahedron_topology_catpart()),
            &DecodeOptions::default(),
        )
        .expect("decode generated topology part");

    assert_eq!(decoded.ir().geometry.faces.len(), 4);
    assert_eq!(decoded.ir().geometry.loops.len(), 4);
    assert_eq!(decoded.ir().geometry.edges.len(), 6);
    assert_eq!(decoded.ir().geometry.coedges.len(), 12);
    assert!(decoded
        .ir()
        .geometry
        .faces
        .iter()
        .all(|face| face.loops.len() == 1));
    assert!(decoded
        .ir()
        .geometry
        .coedges
        .iter()
        .all(|coedge| coedge.radial_next != coedge.id));
    assert!(decoded
        .ir()
        .geometry
        .edges
        .iter()
        .all(|edge| edge.curve().is_some()));
    assert_eq!(
        decoded
            .ir()
            .geometry
            .curves
            .iter()
            .map(|curve| curve
                .source_object
                .as_ref()
                .map(|source| source.object_id.as_str()))
            .collect::<Vec<_>>(),
        (1..=6)
            .map(|tag| format!("cgm-edge-support:{tag:06x}"))
            .collect::<Vec<_>>()
            .iter()
            .map(|object_id| Some(object_id.as_str()))
            .collect::<Vec<_>>()
    );
    assert!(!decoded.report().losses.iter().any(|loss| {
        matches!(
            loss.code.category(),
            cadmpeg_ir::report::loss::LossCategory::Geometry
                | cadmpeg_ir::report::loss::LossCategory::Topology
        ) && loss.severity == cadmpeg_ir::report::Severity::Blocking
    }));
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::ATTEMPTED_STANDARD_TOPOLOGY_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::ATTACHED_STANDARD_TOPOLOGY_COUNT.as_str()
        ),
        1
    );
    assert_eq!(
        wire::coverage(decoded.report())
            .iter()
            .filter(|(key, _)| key.starts_with("standard_topology_failure_"))
            .map(|(_, count)| count)
            .sum::<usize>(),
        0
    );
    assert_eq!(
        [
            "standard_topology_mesh_ambiguity_coordinate_root_closure_count",
            "standard_topology_mesh_ambiguity_endpoint_resolution_count",
            "standard_topology_mesh_ambiguity_distinct_topology_solutions_count",
        ]
        .into_iter()
        .map(|key| wire::coverage(decoded.report())
            .get(key)
            .copied()
            .unwrap_or(0))
        .sum::<usize>(),
        wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_FAILURE_AMBIGUOUS_SOLUTION_COUNT.as_str()
        )
    );
    assert_eq!(
        wire::coverage(decoded.report())
            .get("standard_topology_mesh_exhaustion_quotient_preparation_count"),
        Some(&0)
    );
    assert_eq!(
        [
            "standard_topology_mesh_exhaustion_quotient_preparation_count",
            "standard_topology_mesh_exhaustion_incidence_enumeration_count",
            "standard_topology_mesh_exhaustion_endpoint_resolution_count",
        ]
        .into_iter()
        .map(|key| wire::coverage(decoded.report())
            .get(key)
            .copied()
            .unwrap_or(0))
        .sum::<usize>(),
        wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_FAILURE_SEARCH_EXHAUSTED_COUNT.as_str()
        )
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_EMPTY_ENDPOINT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_SINGLETON_ENDPOINT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_MULTIPLE_ENDPOINT_DOMAIN_COUNT.as_str()
        ),
        wire::coverage_count(
            decoded.report(),
            crate::coverage::STANDARD_TOPOLOGY_CURVE_SUPPORT_COUNT.as_str()
        )
    );
    assert_eq!(
        wire::coverage(decoded.report())
            .iter()
            .filter(|(key, _)| {
                key.starts_with("standard_topology_mesh_rejection_")
                    && !key.starts_with("standard_topology_mesh_rejection_incidence_")
                    && (!key.contains("endpoint_incidence_")
                        || key.ends_with("endpoint_incidence_count"))
            })
            .map(|(_, count)| count)
            .sum::<usize>(),
        0
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_COUNT.as_str()
        ),
        wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_NO_ASSIGNMENT_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_BOUNDARY_RECONSTRUCTION_COUNT
                .as_str()
        )
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_ENDPOINT_INCIDENCE_NO_ASSIGNMENT_COUNT.as_str()
        ),
        wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_INPUT_SHAPE_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_CHOICE_PRUNING_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_FIXED_ASSIGNMENT_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_DOMAIN_COUNT.as_str()
        ) + wire::coverage_count(
            decoded.report(),
            STANDARD_TOPOLOGY_MESH_REJECTION_INCIDENCE_COMPONENT_COMPOSITION_COUNT.as_str()
        )
    );
}

#[test]
fn decode_fbb_only_without_parseable_counted_table_transfers_only_carriers() {
    assert_eq!(
        crate::test_support::with_service_context(|ctx| crate::container::scan_bytes(
            ctx,
            fbb_only_catpart()
        ))
        .expect("scan the container")
        .variant,
        Variant::FbbOnly
    );
    let mut cur = Cursor::new(fbb_only_catpart());
    let result = CatiaCodec
        .decode(&mut cur, &DecodeOptions::default())
        .unwrap();
    assert!(result.ir().geometry.points.is_empty());
    assert_eq!(result.ir().geometry.surfaces.len(), 2);
}

#[test]
fn decode_standard_does_not_promote_unbound_consolidated_pcurve() {
    let mut file = standard_catpart();
    file.splice(16..16, a5_pcurve_stream());
    let file_len = u32::try_from(file.len()).expect("pcurve fixture length");
    file[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode consolidated pcurve");
    assert!(decoded.ir().geometry.pcurves.is_empty());
    assert!(!decoded.ir().native_unknowns("catia").unwrap().is_empty());
}

#[test]
fn standard_decode_refines_a_unique_quantized_analytic_carrier() {
    let exact_x = 1.000_000_01_f64;
    let mut surf = surf_stream();
    for (index, value) in [
        cadmpeg_core::convert::f32_from_f64(exact_x).expect("fixture value fits f32"),
        2.0_f32,
        3.0_f32,
        1.0_f32,
        0.0_f32,
        2.0_f32,
    ]
    .into_iter()
    .enumerate()
    {
        surf[8 + 4 * index..12 + 4 * index].copy_from_slice(&be_f32(value));
    }
    let mut consolidated = b2_cylinder_stream();
    consolidated[5..13].copy_from_slice(&le_f64(exact_x));
    let mut file = standard_catpart_from_streams(&main_stream(), &surf);
    file.splice(16..16, consolidated);
    let file_len = u32::try_from(file.len()).expect("bounded CATPart fixture");
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode exact consolidated analytic refinement");
    let surface = decoded
        .ir()
        .geometry
        .surfaces
        .iter()
        .find(|surface| surface.id.as_str() == "catia:standard:surf#0")
        .expect("refined standard cylinder");
    assert!(
        matches!(surface.geometry, cadmpeg_ir::geometry::SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface))
                if {
                    let origin = cylinder_surface.origin();
        let axis = cylinder_surface.frame().axis().as_raw();
                    origin.x == exact_x && *axis == cadmpeg_ir::math::Vector3::new(1.0, 0.0, 0.0)
                })
    );
    assert_eq!(
        wire::coverage_count(
            decoded.report(),
            crate::coverage::REFINED_CONSOLIDATED_ANALYTIC_SURFACE_COUNT.as_str()
        ),
        1
    );
}

#[test]
fn standard_decode_transfers_resolved_consolidated_cylinder_surface_curve() {
    let mut records = b2_cylinder_stream();
    for point in [
        [1.0f32, 4.0, 3.0],
        [2.0, 2.0 + 2.0 * 0.5f32.cos(), 3.0 + 2.0 * 0.5f32.sin()],
    ] {
        records.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in point {
            records.extend_from_slice(&value.to_le_bytes());
        }
    }
    records.extend_from_slice(&a5_native_edge_run_stream(6, 139, 142));
    let mut file = standard_catpart();
    file.splice(16..16, records);
    let file_len = u32::try_from(file.len()).expect("consolidated fixture length");
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode resolved consolidated edge");
    let procedural = decoded
        .ir()
        .geometry
        .procedural_curves
        .iter()
        .find(|curve| {
            curve
                .id
                .as_str()
                .starts_with("catia:consolidated:construction#")
        })
        .expect("resolved consolidated construction");
    let ProceduralCurveDefinition::Intersection { context, .. } = procedural.definition() else {
        panic!("two resolved support sides form an intersection");
    };
    assert!(context.sides().iter().all(|side| side.surface.is_some()));
    let pcurve = context.sides()[0].pcurve.as_ref().expect("cylinder pcurve");
    let start = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &pcurve.geometry,
        0.0,
    )
    .expect("pcurve start");
    let end = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &pcurve.geometry,
        1.0,
    )
    .expect("pcurve end");
    assert_eq!([start.u, start.v], [0.0, 0.0]);
    assert_eq!([end.u, end.v], [0.5, 1.0]);
}

#[test]
fn standard_decode_transfers_resolved_consolidated_cone_surface_curve() {
    let u = [0.0f64, 1.0];
    let v = [2.0f64, 3.0];
    let mut records = a5_pcurve_stream_with_uv(u, v);
    records.extend_from_slice(&a5_pcurve_stream_with_uv(u, v));
    records.extend_from_slice(&b2_edge_parameter_stream_for(0.0, 1.0));
    records.extend_from_slice(&a5_native_edge_identity_stream(6, 139, 142));
    records.extend_from_slice(&b2_cone_stream());
    for (u, v) in u.into_iter().zip(v) {
        let phi = u / 3.0;
        let point = [
            1.0 + v * 0.25f64.sin() * phi.cos(),
            2.0 + v * 0.25f64.sin() * phi.sin(),
            3.0 + v * 0.25f64.cos(),
        ];
        records.extend_from_slice(&[0x05, 0x08, 0x01]);
        for value in point {
            records.extend_from_slice(
                &(cadmpeg_core::convert::f32_from_f64(value).expect("fixture value fits f32"))
                    .to_le_bytes(),
            );
        }
    }
    let mut file = standard_catpart();
    file.splice(16..16, records);
    let file_len = u32::try_from(file.len()).expect("consolidated fixture length");
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("decode resolved consolidated cone edge");
    let procedural = decoded
        .ir()
        .geometry
        .procedural_curves
        .iter()
        .find(|curve| {
            curve
                .id
                .as_str()
                .starts_with("catia:consolidated:construction#")
        })
        .expect("resolved consolidated construction");
    let ProceduralCurveDefinition::Intersection { context, .. } = procedural.definition() else {
        panic!("two resolved support sides form an intersection");
    };
    assert!(context.sides().iter().all(|side| side.surface.is_some()));
    let pcurve = context.sides()[0].pcurve.as_ref().expect("cone pcurve");
    let start = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &pcurve.geometry,
        0.0,
    )
    .expect("pcurve start");
    let end = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &pcurve.geometry,
        1.0,
    )
    .expect("pcurve end");
    assert_eq!([start.u, start.v], [0.0, 0.0]);
    assert_eq!([end.u, end.v], [1.0 / 3.0, 0.25f64.cos()]);
}

#[test]
fn standard_decode_transfers_resolved_consolidated_nurbs_surface_curves() {
    for offset in [0.0, 1.25] {
        let mut file = standard_catpart();
        file.splice(16..16, a5_nurbs_bound_edge_stream(offset));
        let file_len = u32::try_from(file.len()).expect("consolidated fixture length");
        file[8..12].copy_from_slice(&be32(file_len));

        let decoded = CatiaCodec
            .decode(&mut Cursor::new(file), &DecodeOptions::default())
            .expect("decode resolved consolidated NURBS edge");
        let procedural = decoded
            .ir()
            .geometry
            .procedural_curves
            .iter()
            .find(|curve| {
                curve
                    .id
                    .as_str()
                    .starts_with("catia:consolidated:construction#")
            })
            .expect("resolved consolidated construction");
        let ProceduralCurveDefinition::Intersection { context, .. } = procedural.definition()
        else {
            panic!("two resolved support sides form an intersection");
        };
        let surface_id = context.sides()[1]
            .surface
            .as_ref()
            .expect("resolved NURBS support");
        let pcurve = context.sides()[1].pcurve.as_ref().expect("NURBS pcurve");
        let start = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &pcurve.geometry,
            0.0,
        )
        .expect("pcurve start");
        let end = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &pcurve.geometry,
            1.0,
        )
        .expect("pcurve end");
        assert_eq!([start.u, start.v], [0.0, 0.0]);
        assert_eq!([end.u, end.v], [1.0, 0.0]);

        if offset == 0.0 {
            let surface = decoded
                .ir()
                .geometry
                .surfaces
                .iter()
                .find(|surface| &surface.id == surface_id)
                .expect("direct NURBS carrier");
            assert!(matches!(
                surface.geometry,
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(_))
            ));
        } else {
            let construction = decoded
                .ir()
                .geometry
                .procedural_surfaces
                .iter()
                .find(|surface| {
                    decoded.ir().geometry.procedural_surface_owner(&surface.id) == Some(surface_id)
                })
                .expect("offset NURBS construction");
            let cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Offset(definition_payload) =
                construction.definition()
            else {
                panic!("resolved normal offset is retained as an offset construction");
            };
            let support = definition_payload.support();
            let distance = definition_payload.distance();
            assert!((distance.get() - offset).abs() < 1.0e-12);
            assert!(decoded.ir().geometry.surfaces.iter().any(|surface| {
                surface.id == *support
                    && matches!(
                        surface.geometry,
                        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(_))
                    )
            }));
        }
    }
}

#[test]
fn decode_standard_transfers_exact_offset_construction() {
    let surface_bytes = a5_surface_stream();
    let carriers = crate::families::a5a8::records::a5_surfaces(
        &surface_bytes,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    let surface = &carriers[0].geometry;
    let domain = [
        surface.u_knots()[0],
        surface.v_knots()[0],
        *surface.u_knots().last().unwrap(),
        *surface.v_knots().last().unwrap(),
    ];
    let mut payload = surface_bytes;
    payload.extend_from_slice(&b2_offset_support_stream_for(domain));
    let mut file = standard_catpart();
    file.splice(16..16, payload);
    let file_len = u32::try_from(file.len()).unwrap();
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("standard decode");
    let [procedural] = decoded.ir().geometry.procedural_surfaces.as_slice() else {
        panic!("one offset construction");
    };
    let cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Offset(definition_payload) =
        procedural.definition()
    else {
        panic!("offset construction");
    };
    let support = definition_payload.support();
    let distance = definition_payload.distance();
    let u_sense = definition_payload.u_sense();
    let v_sense = definition_payload.v_sense();
    let extension = definition_payload.extension();
    assert!(decoded
        .ir()
        .geometry
        .surfaces
        .iter()
        .any(|surface| surface.id == *support));
    assert_eq!(distance.get(), 2.5);
    assert_eq!([*u_sense, *v_sense], [None, None]);
    assert_eq!(
        *extension,
        cadmpeg_ir::geometry::OffsetExtension::Legacy {
            flags: cadmpeg_ir::geometry::LegacyExtensionFlags::Absent {},
            cache: None,
        }
    );
    let Some(bounds) = procedural.record_bounds() else {
        panic!("offset parameter bounds");
    };
    for (actual, expected) in bounds.get().into_iter().zip(domain) {
        let Some(actual) = actual else {
            panic!("offset parameter bound");
        };
        assert!((actual - expected).abs() < 1.0e-12);
    }
}

#[test]
fn decode_standard_transfers_construction_use_offset() {
    let surface_bytes = a5_surface_stream();
    let carriers = crate::families::a5a8::records::a5_surfaces(
        &surface_bytes,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    let surface = &carriers[0].geometry;
    let domain = [
        surface.u_knots()[0],
        surface.v_knots()[0],
        *surface.u_knots().last().unwrap(),
        *surface.v_knots().last().unwrap(),
    ];
    let mut payload = surface_bytes;
    payload.extend_from_slice(&b2_construction_use_stream_for(domain));
    let mut file = standard_catpart();
    file.splice(16..16, payload);
    let file_len = u32::try_from(file.len()).unwrap();
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("standard decode");
    let [procedural] = decoded.ir().geometry.procedural_surfaces.as_slice() else {
        panic!("one offset construction");
    };
    let cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Offset(definition_payload) =
        procedural.definition()
    else {
        panic!("offset construction");
    };
    let distance = definition_payload.distance();
    assert_eq!(distance.get(), -2.0);
    let Some(bounds) = procedural.record_bounds() else {
        panic!("offset parameter bounds");
    };
    for (actual, expected) in bounds.get().into_iter().zip(domain) {
        let Some(actual) = actual else {
            panic!("offset parameter bound");
        };
        assert!((actual - expected).abs() < 1.0e-12);
    }
}

#[test]
fn decode_standard_transfers_exact_rolling_ball_jet() {
    let mut file = standard_catpart();
    file.splice(16..16, a5_freeform_curve_stream());
    let file_len = u32::try_from(file.len()).unwrap();
    file[8..12].copy_from_slice(&be32(file_len));

    let decoded = CatiaCodec
        .decode(&mut Cursor::new(file), &DecodeOptions::default())
        .expect("standard decode");
    let [procedural] = decoded.ir().geometry.procedural_surfaces.as_slice() else {
        panic!("one rolling-ball construction");
    };
    let surface = decoded
        .ir()
        .geometry
        .surfaces
        .iter()
        .find(|surface| {
            decoded
                .ir()
                .geometry
                .procedural_surface_owner(&procedural.id)
                == Some(&surface.id)
        })
        .expect("rolling-ball surface");
    assert!(matches!(
        &surface.geometry,
        SurfaceGeometry::Procedural { construction, .. } if construction == &procedural.id
    ));
    let cadmpeg_ir::geometry::ProceduralSurfaceDefinition::RollingBallJet(jet) =
        procedural.definition()
    else {
        panic!("rolling-ball jet");
    };
    let degree = jet.degree();
    let stations = jet.stations();
    let knots: Vec<_> = stations.iter().map(|station| station.knot.get()).collect();
    let multiplicities: Vec<_> = stations
        .iter()
        .map(|station| station.multiplicity)
        .collect();
    let sites: Vec<_> = stations.iter().map(|station| &station.site).collect();
    assert_eq!(degree, 5);
    assert_eq!(knots, &[0.0, 1.0]);
    assert_eq!(multiplicities, &[6, 6]);
    assert_eq!(sites.len(), 2);
    assert_eq!(sites[0].first_limit, Point3::new(1.0, 0.0, 0.0));
    assert_eq!(sites[1].second_limit, Point3::new(0.0, 2.0, 0.0));
    assert_eq!(sites[0].angle.get(), std::f64::consts::FRAC_PI_2);
    assert_eq!(
        sites[0].first_derivative.center,
        Vector3::new(0.0, 0.0, 0.0)
    );
}

#[test]
fn standard_decode_transfers_consolidated_guide_curve() {
    let mut bytes = standard_catpart();
    bytes.splice(16..16, a5_guide_curve_stream());
    let file_len = u32::try_from(bytes.len()).expect("guide fixture length");
    bytes[8..12].copy_from_slice(&be32(file_len));
    let decoded = CatiaCodec
        .decode(&mut Cursor::new(bytes), &DecodeOptions::default())
        .expect("decode guide fixture");
    let guide = decoded
        .ir()
        .geometry
        .curves
        .iter()
        .find(|curve| curve.id.as_str().starts_with("catia:guide:curve#"))
        .expect("typed guide curve");
    let Some(SolvedCurveGeometry::Nurbs(nurbs)) = guide.geometry.solved() else {
        panic!("guide curve must be NURBS");
    };
    assert_eq!(nurbs.degree(), 5);
    assert_eq!(nurbs.control_points().first().unwrap().x, 0.0);
    assert_eq!(nurbs.control_points().last().unwrap().z, 4.0);
}

#[test]
fn population_scope_prefixes_rewritten_body_ids() {
    use super::super::StandardPopulationScope;
    use cadmpeg_ir::document::EntityRewrite;
    use cadmpeg_ir::ids::BodyId;
    use cadmpeg_ir::topology::{Body, BodyKind};
    let body = Body {
        id: BodyId::mint("catia:standard:body#0").expect("identity"),
        kind: BodyKind::Solid,
        transform: None,
        name: None,
        color: None,
        visible: None,
        native_ref: None,
    };
    let admitted = crate::test_support::with_service_context(|ctx| {
        StandardPopulationScope {
            scope: "population-1",
            ctx,
        }
        .rewrite(body)
    })
    .expect("rewrite the body into the population scope");
    assert_eq!(admitted.id.as_str(), "catia:standard:population-1/body#0");
}

#[test]
fn standard_catpart_decodes_as_a_standard_population() {
    let file = standard_catpart();
    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, file.clone())
    })
    .expect("scan the container");
    let decode = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
        super::super::try_decode_standard_population(
            ctx,
            &scan,
            None,
            &mut crate::nurbs::LaneRefusals::new(),
            &[],
            &std::collections::HashMap::new(),
        )
    };
    assert!(crate::test_support::with_service_context(decode)
        .expect("decode standard population")
        .is_some());
}

#[test]
fn copying_a_revolution_procedure_preserves_it() {
    let directrix = cadmpeg_ir::geometry::nurbs::NurbsCurve::from_lanes(
        1,
        vec![0.0, 0.0, 1.0, 1.0],
        vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
        None,
        false,
    )
    .expect("valid directrix");
    let procedure = super::super::StandardSurfaceProcedure::Revolution(Box::new(
        crate::families::b5::transfer::ResolvedRevolutionSurface {
            directrix,
            axis_origin: cadmpeg_ir::features::FinitePoint3::new(Point3::new(0.0, 0.0, 0.0))
                .expect("finite origin"),
            axis_direction: cadmpeg_ir::units::UnitVector3::new(Vector3::new(0.0, 0.0, 1.0))
                .expect("unit axis"),
            angular_interval: [0.0, 1.0],
            angular_parameter_interval: [0.0, 1.0],
            parameter_interval: [0.0, 1.0],
        },
    ));
    let service =
        super::super::copy_standard_procedure(&procedure).expect("copy standard procedure");
    assert!(service == procedure);
}
