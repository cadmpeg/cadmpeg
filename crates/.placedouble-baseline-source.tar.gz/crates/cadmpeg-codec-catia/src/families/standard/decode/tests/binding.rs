use crate::assemble::circle_parameter_range_from_surface_branch;
use crate::assemble::ordered_range;
use crate::assemble::rational_pcurve_arc;
use crate::families::b2::records::B2OwnerReferenceEncoding;
use crate::families::b5::graph::B5LogicalVertex;
use crate::families::standard::decode::associate_standard_freeform_e5_rolling_ball_jets;
use crate::families::standard::decode::associate_standard_freeform_e5_surfaces;
use crate::families::standard::decode::bind_standard_a5_owner_surfaces;
use crate::families::standard::decode::combine_propagated_endpoint_pairs;
use crate::families::standard::decode::corroborate_successor_endpoint_points;
use crate::families::standard::decode::edge_geometry::build_standard_edge_curve;
use crate::families::standard::decode::edge_geometry::plane_intersection_line;
use crate::families::standard::decode::edge_geometry::standard_analytic_curve_parameter_range;
use crate::families::standard::decode::edge_geometry::standard_oriented_analytic_curve_parameter_range;
use crate::families::standard::decode::edge_geometry::witness_arc_end;
use crate::families::standard::decode::emit_standard_topology;
use crate::families::standard::decode::include_native_endpoint_pairs;
use crate::families::standard::decode::intersection_line_direction;
use crate::families::standard::decode::invariant_face_carrier_bindings;
use crate::families::standard::decode::merge_derived_endpoint_pair;
use crate::families::standard::decode::merge_native_endpoint_evidence;
use crate::families::standard::decode::merge_standard_edge_vertex_references;
use crate::families::standard::decode::owner_contains_face_bounds;
use crate::families::standard::decode::owner_matches_a5_carrier;
use crate::families::standard::decode::point_on_standard_face;
use crate::families::standard::decode::same_cone_generator_pair;
use crate::families::standard::decode::standard_circle_endpoint_candidates;
use crate::families::standard::decode::standard_curve_edge_classes;
use crate::families::standard::decode::standard_curve_geometry_gauge_keys;
use crate::families::standard::decode::standard_face_boundary_witnesses;
use crate::families::standard::decode::standard_face_point_membership;
use crate::families::standard::decode::standard_freeform_e5_carrier_ids;
use crate::families::standard::decode::standard_id;
use crate::families::standard::decode::standard_serialized_endpoint_pairs;
use crate::families::standard::decode::standard_successor_endpoint_points;
use crate::families::standard::decode::unique_native_identity_points;
use crate::families::standard::decode::StandardConsolidatedSource;
use crate::families::standard::decode::StandardRollingBallSource;
use crate::families::standard::decode::StandardSurfaceProcedure;
use crate::families::standard::records::StandardCurveGeometry;
use crate::families::standard::records::StandardCurveSupport;
use crate::families::standard::records::StandardFaceBounds;
use crate::families::standard::records::StandardSurfaceRecord;
use crate::native::owner_numeric_tail::CatiaOwnerNumericTail;
use crate::test_support::test_e5::{append_e5_record, e5_d8_rolling_ball_stream, e5_torus_stream};
use cadmpeg_ir::document::CadIr;

use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::nurbs::NurbsSurface;
use cadmpeg_ir::geometry::pcurve::PcurveGeometry;
use cadmpeg_ir::geometry::Curve;
use cadmpeg_ir::geometry::CurveGeometry;
use cadmpeg_ir::geometry::ProceduralSurfaceDefinition;
use cadmpeg_ir::geometry::SolvedCurveGeometry;
use cadmpeg_ir::geometry::SolvedSurfaceGeometry;
use cadmpeg_ir::geometry::Surface;
use cadmpeg_ir::geometry::SurfaceGeometry;
use cadmpeg_ir::ids::FaceId;
use cadmpeg_ir::ids::PointId;
use cadmpeg_ir::ids::ShellId;
use cadmpeg_ir::ids::SurfaceId;
use cadmpeg_ir::ids::VertexId;
use cadmpeg_ir::math::Point2;
use cadmpeg_ir::math::Point3;
use cadmpeg_ir::math::Vector3;
use cadmpeg_ir::topology::Face;
use cadmpeg_ir::topology::Point;
use cadmpeg_ir::topology::Sense;
use cadmpeg_ir::AnnotationBuilder;
use std::collections::BTreeMap;
use std::collections::HashMap;

fn standard_pcurve_geometry(
    surface: &SurfaceGeometry,
    support: &StandardCurveSupport,
    start: Point3,
    end: Point3,
    witness: Option<FinitePoint3>,
    edge_curve: Option<&CurveGeometry>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<(PcurveGeometry, [f64; 2])> {
    crate::test_support::with_service_context(|ctx| {
        crate::families::standard::decode::edge_geometry::standard_pcurve_geometry(
            ctx,
            surface,
            support,
            (start, end),
            witness,
            edge_curve,
            refusal,
        )
    })
    .expect("compute the standard pcurve geometry")
}

fn standard_endpoint_pair_supports_topology(
    surface: &SurfaceGeometry,
    support: &StandardCurveSupport,
    start: Point3,
    end: Point3,
    witness: Option<FinitePoint3>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> bool {
    crate::test_support::with_service_context(|ctx| {
        crate::families::standard::decode::standard_endpoint_pair_supports_topology(
            ctx, surface, support, start, end, witness, refusal,
        )
    })
    .expect("compute the standard endpoint pair supports topology")
}

fn unit_square_surface() -> NurbsSurface {
    NurbsSurface::from_lanes(
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceAxis::new(1, vec![0.0, 0.0, 1.0, 1.0], false),
        cadmpeg_ir::geometry::nurbs::NurbsSurfaceLanes::new(
            vec![
                vec![Point3::new(0.0, 0.0, 0.0), Point3::new(0.0, 1.0, 0.0)],
                vec![Point3::new(1.0, 0.0, 0.0), Point3::new(1.0, 1.0, 0.0)],
            ],
            None,
        ),
        false,
    )
    .expect("valid unit-square surface")
}

fn owner_tail(lower: [f64; 2], upper: [f64; 2], bounds: [[f32; 2]; 3]) -> CatiaOwnerNumericTail {
    CatiaOwnerNumericTail::new([0x84, 0x41, 0, 0, 0x0d], lower, upper, bounds)
        .expect("increasing owner numeric tail")
}

#[test]
fn owner_carrier_candidate_requires_parameter_and_model_space_containment() {
    let surface = unit_square_surface();
    let admitted = owner_tail(
        [0.25, 0.25],
        [0.75, 0.75],
        [[0.2, 0.8], [0.2, 0.8], [-0.1, 0.1]],
    );
    let outside_parameter_domain = owner_tail(
        [-0.25, 0.25],
        [0.75, 0.75],
        [[-0.3, 0.8], [0.2, 0.8], [-0.1, 0.1]],
    );
    let clipped_model_bounds = owner_tail(
        [0.25, 0.25],
        [0.75, 0.75],
        [[0.3, 0.8], [0.2, 0.8], [-0.1, 0.1]],
    );

    assert_eq!(
        owner_matches_a5_carrier(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &admitted,
            &surface
        ),
        Ok(true)
    );
    assert_eq!(
        owner_matches_a5_carrier(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &outside_parameter_domain,
            &surface
        ),
        Ok(false)
    );
    assert_eq!(
        owner_matches_a5_carrier(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &clipped_model_bounds,
            &surface
        ),
        Ok(false)
    );
}

#[test]
fn owner_face_candidate_requires_complete_trimmed_bounds_containment() {
    let owner = owner_tail(
        [0.0, 0.0],
        [1.0, 1.0],
        [[-1.0, 1.0], [-2.0, 2.0], [-3.0, 3.0]],
    );
    let contained = StandardFaceBounds {
        aabb_center: [
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        aabb_half_extents: [
            crate::test_support::test_b5::nonnegative_length(0.5),
            crate::test_support::test_b5::nonnegative_length(1.5),
            crate::test_support::test_b5::nonnegative_length(2.5),
        ],
        sphere_center: [
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        sphere_radius: crate::test_support::test_b5::nonnegative_length(3.0),
    };
    let protruding = StandardFaceBounds {
        aabb_half_extents: [
            crate::test_support::test_b5::nonnegative_length(1.5),
            crate::test_support::test_b5::nonnegative_length(1.5),
            crate::test_support::test_b5::nonnegative_length(2.5),
        ],
        ..contained
    };

    assert!(owner_contains_face_bounds(
        B2OwnerReferenceEncoding::AllCompact,
        &owner,
        contained,
    ));
    assert!(!owner_contains_face_bounds(
        B2OwnerReferenceEncoding::AllCompact,
        &owner,
        protruding,
    ));
}

#[test]
fn owner_face_bounds_are_not_a_witness_for_other_fixed_nine_dialects() {
    let owner = owner_tail(
        [0.0, 0.0],
        [1.0, 1.0],
        [[-1.0, 1.0], [-2.0, 2.0], [-3.0, 3.0]],
    );
    let face = StandardFaceBounds {
        aabb_center: [
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        aabb_half_extents: [
            crate::test_support::test_b5::nonnegative_length(0.5),
            crate::test_support::test_b5::nonnegative_length(1.5),
            crate::test_support::test_b5::nonnegative_length(2.5),
        ],
        sphere_center: [
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        sphere_radius: crate::test_support::test_b5::nonnegative_length(3.0),
    };

    for encoding in [
        B2OwnerReferenceEncoding::TaggedU16Strong,
        B2OwnerReferenceEncoding::WidthCodedStrong,
    ] {
        assert!(!owner_contains_face_bounds(encoding, &owner, face));
    }
}

#[test]
fn owner_face_swaps_bind_when_every_complete_matching_has_one_carrier() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[0],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    let domains = vec![
        vec![(0, vec![7]), (1, vec![7]), (2, vec![7])],
        vec![(0, vec![7]), (1, vec![7])],
    ];

    assert_eq!(
        invariant_face_carrier_bindings(&ctx, &domains, 3, None)
            .expect("compute the invariant face carrier bindings"),
        Some(vec![Some(7), Some(7)])
    );
}

#[test]
fn owner_face_matching_withholds_carrier_labels_that_change_under_a_swap() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[0],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    let domains = vec![
        vec![(0, vec![7]), (1, vec![9])],
        vec![(0, vec![9]), (1, vec![7])],
    ];

    assert_eq!(
        invariant_face_carrier_bindings(&ctx, &domains, 2, None)
            .expect("compute the invariant face carrier bindings"),
        Some(vec![None, None])
    );
}

#[test]
fn owner_face_matching_removes_labels_outside_every_complete_matching() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[0],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    let domains = vec![vec![(0, vec![7]), (1, vec![99])], vec![(1, vec![11])]];

    assert_eq!(
        invariant_face_carrier_bindings(&ctx, &domains, 2, None)
            .expect("compute the invariant face carrier bindings"),
        Some(vec![Some(7), Some(11)])
    );
}

#[test]
fn owner_face_matching_requires_every_face_to_have_a_distinct_owner() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[0],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    let domains = vec![vec![(0, vec![7])], Vec::new()];

    assert_eq!(
        invariant_face_carrier_bindings(&ctx, &domains, 2, None)
            .expect("compute the invariant face carrier bindings"),
        None
    );
}

#[test]
fn standard_object_journal_binds_ordered_edge_endpoints_through_roster_position() {
    let supports = [70, 90, 110].map(|tag| StandardCurveSupport {
        pos: usize::try_from(tag).expect("fixture tag"),
        tag,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Line,
    });
    let native_edges = BTreeMap::from([(70, [500, 300]), (90, [100, 500])]);
    let roster = [100, 300, 500];

    assert_eq!(
        standard_serialized_endpoint_pairs(&supports, &native_edges, &roster),
        Some(vec![Some([2, 1]), Some([0, 2]), None])
    );

    assert!(
        standard_serialized_endpoint_pairs(&supports, &native_edges, &[100, 300, 100]).is_none()
    );
}

#[test]
fn standard_object_journal_merges_matching_edge_dialects_and_rejects_conflicts() {
    let mut edges = BTreeMap::from([(70, [500, 300])]);
    assert!(merge_standard_edge_vertex_references(
        &mut edges,
        [(70, [500, 300]), (90, [100, 500])],
    ));
    assert_eq!(edges, BTreeMap::from([(70, [500, 300]), (90, [100, 500])]));
    assert!(!merge_standard_edge_vertex_references(
        &mut edges,
        [(70, [300, 500])],
    ));
}

#[test]
fn same_cone_generator_requires_an_apex_collinear_endpoint_pair() {
    let cone = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
        cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            1.0,
            1.0,
            std::f64::consts::FRAC_PI_4,
        )
        .expect("valid ConeSurface fixture"),
    ));
    assert!(same_cone_generator_pair(
        &cone,
        &cone,
        Point3::new(1.0, 0.0, 0.0),
        Point3::new(2.0, 0.0, 1.0),
    ));
    assert!(!same_cone_generator_pair(
        &cone,
        &cone,
        Point3::new(1.0, 0.0, 0.0),
        Point3::new(0.0, 2.0, 1.0),
    ));
}

#[test]
fn standard_edge_successor_points_are_only_domain_corroboration() {
    let supports = [
        StandardCurveSupport {
            pos: 8,
            tag: 100,
            faces: [1, 2],
            geometry: StandardCurveGeometry::Bspline,
        },
        StandardCurveSupport {
            pos: 9,
            tag: u32::MAX,
            faces: [2, 3],
            geometry: StandardCurveGeometry::Bspline,
        },
    ];

    assert_eq!(
        standard_successor_endpoint_points(&supports, &[99, 101, 102]),
        [[Some(1), Some(2)], [None, None]]
    );
}

#[test]
fn successor_endpoint_points_filter_independently_and_jointly() {
    let mut options = [
        vec![[2, 4], [2, 5], [3, 5]],
        vec![[7, 8], [7, 9]],
        vec![[10, 11]],
    ];

    corroborate_successor_endpoint_points(
        &mut options,
        &[[None, Some(5)], [Some(6), None], [None, None]],
    );

    assert_eq!(
        options,
        [vec![[2, 5], [3, 5]], vec![[7, 8], [7, 9]], vec![[10, 11]],]
    );

    let mut joint_options = vec![vec![[2, 4], [2, 5], [3, 5]]];
    corroborate_successor_endpoint_points(&mut joint_options, &[[Some(2), Some(5)]]);
    assert_eq!(joint_options, [vec![[2, 5]]]);
}

#[test]
fn standard_circle_endpoint_domain_uses_the_explicit_curve_carrier() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let points = [
        Point::new(
            PointId::mint("catia:test:point#on".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, 4.0, 7.0))
                .expect("a finite position is a point"),
            None,
        ),
        Point::new(
            PointId::mint("catia:test:point#off".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, 4.01, 7.0))
                .expect("a finite position is a point"),
            None,
        ),
    ];
    assert_eq!(
        standard_circle_endpoint_candidates(&ctx, &points, Point3::new(0.0, 0.0, 7.0), 5.0, None,)
            .expect("compute the standard circle endpoint candidates"),
        [0]
    );
}

#[test]
fn standard_circle_endpoint_domain_requires_both_face_carriers() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let points = [
        Point::new(
            PointId::mint("catia:test:point#incident".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, 4.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
        Point::new(
            PointId::mint("catia:test:point#other-occurrence".to_string())
                .expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, -4.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
    ];
    let left = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 4.0, 0.0),
            Vector3::new(0.0, 1.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let right = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
    assert_eq!(
        standard_circle_endpoint_candidates(
            &ctx,
            &points,
            Point3::new(0.0, 0.0, 0.0),
            5.0,
            Some([(&left, None), (&right, None)]),
        )
        .expect("compute the standard circle endpoint candidates"),
        [0]
    );
}

#[test]
fn standard_circle_endpoint_domain_requires_both_trimmed_face_bounds() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let points = [
        Point::new(
            PointId::mint("catia:test:point#incident".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, 4.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
        Point::new(
            PointId::mint("catia:test:point#other-occurrence".to_string())
                .expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(3.0, -4.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
    ];
    let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
    let bounds = crate::families::standard::records::StandardFaceBounds {
        aabb_center: [
            crate::test_support::test_b5::finite(3.0),
            crate::test_support::test_b5::finite(4.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        aabb_half_extents: [
            crate::test_support::test_b5::nonnegative_length(0.1),
            crate::test_support::test_b5::nonnegative_length(0.1),
            crate::test_support::test_b5::nonnegative_length(0.1),
        ],
        sphere_center: [
            crate::test_support::test_b5::finite(3.0),
            crate::test_support::test_b5::finite(4.0),
            crate::test_support::test_b5::finite(0.0),
        ],
        sphere_radius: crate::test_support::test_b5::nonnegative_length(0.2),
    };

    assert_eq!(
        standard_circle_endpoint_candidates(
            &ctx,
            &points,
            Point3::new(0.0, 0.0, 0.0),
            5.0,
            Some([(&surface, Some(bounds)), (&surface, Some(bounds))]),
        )
        .expect("compute the standard circle endpoint candidates"),
        [0]
    );
}

#[test]
fn native_endpoint_pairs_extend_geometric_candidate_domains() {
    let mut candidates = vec![vec![1], Vec::new()];
    include_native_endpoint_pairs(&mut candidates, &[Some([1, 2]), Some([3, 4])]);
    assert_eq!(candidates, [vec![1, 2], vec![3, 4]]);
}

#[test]
fn native_endpoint_evidence_rejects_directed_pair_conflicts() {
    let graph = [Some([0, 1]), None];
    let roster = [Some([0, 1]), Some([2, 3])];
    assert_eq!(
        merge_native_endpoint_evidence(Some(&graph), Some(&roster)),
        Ok(Some(vec![Some([0, 1]), Some([2, 3])]))
    );
    assert_eq!(
        merge_native_endpoint_evidence(Some(&graph), Some(&[Some([1, 0]), None])),
        Err("conflicting native endpoint evidence")
    );
}

#[test]
fn derived_endpoint_sources_corroborate_reversed_native_direction() {
    let mut pairs = vec![Some([34, 33])];
    assert!(merge_derived_endpoint_pair(&mut pairs, 0, [33, 34]));
    assert_eq!(pairs, [Some([34, 33])]);
    assert!(!merge_derived_endpoint_pair(&mut pairs, 0, [33, 35]));
}

#[test]
fn complete_vertex_roster_supersedes_partial_graph_coordinates() {
    let graph = [Some([4, 5]), None];
    let roster = [Some([0, 1]), Some([2, 3])];
    assert_eq!(
        merge_native_endpoint_evidence(Some(&graph), Some(&roster)),
        Ok(Some(roster.to_vec()))
    );
}

#[test]
fn complete_mesh_endpoint_quotient_overrides_table_local_ports() {
    let raw = Some(vec![Some([0, 1]), Some([2, 3])]);
    let mesh = Some(vec![Some([0, 1]), Some([1, 2])]);
    assert_eq!(
        combine_propagated_endpoint_pairs(raw, mesh),
        Some(vec![Some([0, 1]), Some([1, 2])])
    );
}

#[test]
fn propagated_endpoint_sources_reject_mismatched_edge_counts() {
    let raw = Some(vec![Some([0, 1]), None]);
    let mesh = Some(vec![None]);
    assert_eq!(combine_propagated_endpoint_pairs(raw, mesh), None);
}

#[test]
fn native_identity_locus_binds_only_one_coordinate_row_within_tolerance() {
    let points = [
        Point::new(
            PointId::mint("catia:test:point#a".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.0, 0.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
        Point::new(
            PointId::mint("catia:test:point#b".to_string()).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.01, 0.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
    ];
    let tolerances = [(2usize, crate::test_support::test_b5::positive(0.02))]
        .into_iter()
        .collect();
    let vertices = [B5LogicalVertex {
        object_id: 7,
        point: crate::test_support::test_b5::point([1.0, 0.0, 0.0]),
    }];
    let ambiguous = unique_native_identity_points(&vertices, 2, &tolerances, &points);
    assert!(ambiguous.is_empty());

    let exact = unique_native_identity_points(&vertices, 2, &BTreeMap::new(), &points);
    assert_eq!(exact.get(&7), Some(&0));
}

#[test]
fn reverse_angular_interval_becomes_an_increasing_nurbs_domain() {
    let range = ordered_range([0.0, -std::f64::consts::PI]);
    let arc = rational_pcurve_arc(
        [0.0, 0.0],
        2.0,
        range,
        &mut crate::nurbs::LaneRefusals::new(),
        "test record",
    )
    .expect("reverse semicircle");
    let PcurveGeometry::Nurbs { nurbs } = &arc else {
        panic!("expected rational NURBS arc");
    };
    assert!(nurbs.knots().windows(2).all(|pair| pair[0] <= pair[1]));
    assert_eq!(range, [-std::f64::consts::PI, 0.0]);
    let start = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &arc,
        range[0],
    )
    .expect("start evaluation");
    let end = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &arc,
        range[1],
    )
    .expect("end evaluation");
    assert!((start.u + 2.0).abs() < 1.0e-12);
    assert!(start.v.abs() < 1.0e-12);
    assert!((end.u - 2.0).abs() < 1.0e-12);
    assert!(end.v.abs() < 1.0e-12);
}

#[test]
fn canonical_periodic_range_snaps_roundoff_at_the_turn_seam() {
    let tau = std::f64::consts::TAU;
    let range = crate::nurbs::canonical_periodic_range([tau - 1e-14, tau + 0.25])
        .expect("canonical seam range");
    assert_eq!(range[0], 0.0);
    assert!((range[1] - 0.25).abs() < 2e-14);
}

#[test]
fn coincident_planes_do_not_impose_a_line_direction() {
    let plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    assert!(intersection_line_direction(&plane, &plane).is_none());
}

#[test]
fn plane_intersection_preserves_tiny_nonzero_direction() {
    let left = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
            Vector3::new(0.0, 1.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let right = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(1.0, 1e-200, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    assert_eq!(
        intersection_line_direction(&left, &right),
        Some(Vector3::new(0.0, 0.0, 1e-200))
    );
}

#[test]
fn plane_intersection_preserves_tiny_nonzero_angle_and_finite_origin() {
    let tiny = 1e-200;
    assert_eq!(
        plane_intersection_line(
            Point3::new(1.0, 0.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
            Point3::new(1.0, 0.0, 0.0),
            Vector3::new(1.0, tiny, 0.0),
        ),
        Some((Point3::new(1.0, 0.0, 0.0), Vector3::new(0.0, 0.0, 1.0),))
    );
}

#[test]
fn cylinder_generator_direction_requires_compatible_support_axes() {
    let cylinder = |axis| {
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                axis,
                Vector3::new(1.0, 0.0, 0.0),
                1.0,
            )
            .expect("valid CylinderSurface fixture"),
        ))
    };
    let containing_plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 1.0, 0.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let transverse_plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let axial = cylinder(Vector3::new(0.0, 0.0, 1.0));
    let oblique = cylinder(Vector3::new(0.0, 1.0, 0.0));

    assert_eq!(
        intersection_line_direction(&containing_plane, &axial),
        Some(Vector3::new(0.0, 0.0, 1.0))
    );
    assert!(intersection_line_direction(&transverse_plane, &axial).is_none());
    assert!(intersection_line_direction(&axial, &oblique).is_none());
}

#[test]
fn unknown_surface_membership_stays_open_but_nurbs_membership_is_geometric() {
    assert!(point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(100.0, -50.0, 7.0),
        &SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
        None,
    )
    .expect("surface evaluator accepts the fixture"));
    let nurbs = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(unit_square_surface()));
    assert!(point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(0.5, 0.5, 0.0),
        &nurbs,
        None,
    )
    .expect("surface evaluator accepts the fixture"));
    assert!(!point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(0.5, 0.5, 0.1),
        &nurbs,
        None,
    )
    .expect("surface evaluator accepts the fixture"));
    assert!(!point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(100.0, -50.0, 7.0),
        &nurbs,
        None,
    )
    .expect("surface evaluator accepts the fixture"));
}

#[test]
fn standard_freeform_face_uses_exact_e5_surface_wrapper_identity() {
    let mut stream = e5_torus_stream();
    let mut wrapper = vec![0x85, 0x80, 0x81, 0x82, 0x83, 0x84];
    wrapper.extend_from_slice(&[0; 38]);
    append_e5_record(&mut stream, 0xf1, 8, &wrapper);
    append_e5_record(&mut stream, 0x00, 7, &[0x82, 0x88, 0x89, 1, 0]);

    let records = [StandardSurfaceRecord::Freeform {
        pos: 0,
        tag: 7,
        bounds: StandardFaceBounds {
            aabb_center: [
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
            ],
            aabb_half_extents: [
                crate::test_support::test_b5::nonnegative_length(1.0),
                crate::test_support::test_b5::nonnegative_length(1.0),
                crate::test_support::test_b5::nonnegative_length(1.0),
            ],
            sphere_center: [
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
            ],
            sphere_radius: crate::test_support::test_b5::nonnegative_length(1.0),
        },
        forward: true,
    }];

    let associated = associate_standard_freeform_e5_surfaces(
        &records,
        &stream,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("associate standard freeform E5 surfaces");
    assert!(matches!(
        associated.get(&7),
        Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(_)))
    ));
}

#[test]
fn standard_freeform_face_uses_exact_e5_d8_rolling_ball_identity() {
    let mut stream = e5_d8_rolling_ball_stream();
    let mut wrapper = vec![0x85, 0xaa, 0x81, 0x82, 0x83, 0x84];
    wrapper.extend_from_slice(&[0; 38]);
    append_e5_record(&mut stream, 0xf1, 8, &wrapper);
    append_e5_record(&mut stream, 0x00, 7, &[0x82, 0x88, 0x89, 1, 0]);

    let records = [StandardSurfaceRecord::Freeform {
        pos: 0,
        tag: 7,
        bounds: StandardFaceBounds {
            aabb_center: [
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
            ],
            aabb_half_extents: [
                crate::test_support::test_b5::nonnegative_length(1.0),
                crate::test_support::test_b5::nonnegative_length(1.0),
                crate::test_support::test_b5::nonnegative_length(1.0),
            ],
            sphere_center: [
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
                crate::test_support::test_b5::finite(0.0),
            ],
            sphere_radius: crate::test_support::test_b5::nonnegative_length(1.0),
        },
        forward: true,
    }];

    let jets = crate::families::e5::records::e5_rolling_ball_jets(&stream);
    let associated = associate_standard_freeform_e5_rolling_ball_jets(&records, &stream, &jets);
    assert!(matches!(
        associated.get(&7),
        Some(StandardSurfaceProcedure::RollingBall {
            carrier_object_id: 42,
            source: StandardRollingBallSource::E5D8,
            definition,
    }) if matches!(
        definition.as_ref(),
        ProceduralSurfaceDefinition::RollingBallJet(jet)
            if jet.degree() == 5
            && jet.stations().iter().map(|station| station.knot.get()).collect::<Vec<_>>()
            == vec![2.0, 5.0]
            && jet.stations().iter().map(|station| station.multiplicity).collect::<Vec<_>>() == vec![6, 6]
            && jet.stations().len() == 2)));

    let mut opposite_records = records;
    let StandardSurfaceRecord::Freeform { forward, .. } = &mut opposite_records[0] else {
        unreachable!("synthetic D8 face record");
    };
    *forward = false;
    assert!(
        associate_standard_freeform_e5_rolling_ball_jets(&opposite_records, &stream, &jets)
            .is_empty()
    );

    let mut reverse_stream = stream.clone();
    let d8_payload_size = usize::from(u16::from_le_bytes(
        reverse_stream[5..7].try_into().expect("D8 payload size"),
    ));
    let sense_offset = 13 + d8_payload_size - 63 + 5 * std::mem::size_of::<f64>();
    let encoded_sense_offset = reverse_stream
        .windows(std::mem::size_of::<i32>())
        .position(|bytes| bytes == (-1_i32).to_le_bytes());
    assert_eq!(Some(sense_offset), encoded_sense_offset);
    reverse_stream[sense_offset..sense_offset + std::mem::size_of::<i32>()]
        .copy_from_slice(&1_i32.to_le_bytes());
    let reverse_jets = crate::families::e5::records::e5_rolling_ball_jets(&reverse_stream);
    assert_eq!(
        reverse_jets[0].sense,
        crate::families::e5::graph::Sign::Positive
    );
    assert!(associate_standard_freeform_e5_rolling_ball_jets(
        &opposite_records,
        &reverse_stream,
        &reverse_jets
    )
    .contains_key(&7));
}

#[test]
fn cached_face_point_membership_matches_the_source_predicate() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
        &[0],
        &arena,
        &cadmpeg_core::decode::DecodePolicy::service(),
    )
    .expect("build the decode context");
    let mut ir = CadIr::empty();
    ir.geometry.points.extend([
        Point::new(
            PointId::mint("catia:test:point#point-0").expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.0, 2.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ),
        Point::new(
            PointId::mint("catia:test:point#point-1").expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.0, 2.0, 1.0))
                .expect("a finite position is a point"),
            None,
        ),
    ]);
    let surface_id = SurfaceId::mint("catia:test:surface#surface-0").expect("identity grammar");
    ir.geometry.surfaces.push(Surface {
        id: surface_id.clone(),
        geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        )),
        source_object: None,
        native_ref: None,
    });
    let bindings = [(surface_id.clone(), false, 0)];
    let surface_indices = HashMap::from([(surface_id, 0)]);
    let membership = standard_face_point_membership(&ctx, &ir, &bindings, &surface_indices, None)
        .expect("build the face point membership cache");

    assert_eq!(membership[0], [0]);
    assert!(membership[1].is_empty());
    assert!(membership.iter().enumerate().all(|(point, faces)| {
        faces.contains(&0)
            == point_on_standard_face(
                &ctx,
                ir.geometry.points[point].position().get(),
                &ir.geometry.surfaces[0].geometry,
                None,
            )
            .expect("surface evaluator accepts the fixture")
    }));
}

#[test]
fn point_face_membership_matches_a_dense_face_point_table() {
    let ctx = cadmpeg_core::decode::test_support::service_decode_context();
    let finite = crate::test_support::test_b5::finite;
    let length = crate::test_support::test_b5::nonnegative_length;
    let mut ir = CadIr::empty();
    ir.geometry.points.extend(
        [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 2.0],
            [2.0, 0.0, 0.0],
            [2.0, 4.0, 6.0],
            [5.0, 5.0, 5.0],
            [0.0, -1.0, 0.5],
        ]
        .into_iter()
        .enumerate()
        .map(|(point, [x, y, z])| {
            Point::new(
                PointId::mint(format!("catia:test:point#point-{point}")).expect("identity grammar"),
                FinitePoint3::new(Point3::new(x, y, z)).expect("a finite position is a point"),
                None,
            )
        }),
    );
    let geometries = [
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        )),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
            cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                1.0,
            )
            .expect("valid CylinderSurface fixture"),
        )),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Sphere(
            cadmpeg_ir::geometry::analytic::SphereSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
                2.0,
            )
            .expect("valid SphereSurface fixture"),
        )),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
    ];
    let surface_ids = (0..=geometries.len())
        .map(|surface| {
            SurfaceId::mint(format!("catia:test:surface#surface-{surface}"))
                .expect("identity grammar")
        })
        .collect::<Vec<_>>();
    for (id, geometry) in surface_ids.iter().zip(geometries) {
        ir.geometry.surfaces.push(Surface {
            id: id.clone(),
            geometry,
            source_object: None,
            native_ref: None,
        });
    }
    let surface_indices = surface_ids
        .iter()
        .take(ir.geometry.surfaces.len())
        .cloned()
        .enumerate()
        .map(|(index, id)| (id, index))
        .collect::<HashMap<_, _>>();
    // Face 2 names a surface the model does not hold.
    let bindings = [0, 1, 4, 2, 3, 0, 3]
        .map(|surface| (surface_ids[surface].clone(), false, 0))
        .to_vec();
    let bounds = |center: [f64; 3], half_extents: [f64; 3], radius: f64| StandardFaceBounds {
        aabb_center: center.map(finite),
        aabb_half_extents: half_extents.map(length),
        sphere_center: center.map(finite),
        sphere_radius: length(radius),
    };
    let face_bounds = [
        None,
        None,
        None,
        None,
        Some(bounds([2.0, 3.0, 4.0], [1.0, 2.0, 3.0], 3.5)),
        Some(bounds([1.0, 0.0, 0.0], [0.5, 0.5, 0.5], 1.0)),
        None,
    ];

    let dense = bindings
        .iter()
        .zip(face_bounds)
        .map(|((surface_id, ..), bounds)| {
            let Some(surface) = surface_indices
                .get(surface_id)
                .map(|index| &ir.geometry.surfaces[*index])
            else {
                return Vec::new();
            };
            ir.geometry
                .points
                .iter()
                .map(|point| {
                    point_on_standard_face(&ctx, point.position().get(), &surface.geometry, bounds)
                        .expect("surface evaluator accepts the fixture")
                })
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    let membership = standard_face_point_membership(
        &ctx,
        &ir,
        &bindings,
        &surface_indices,
        Some(face_bounds.as_slice()),
    )
    .expect("build the face point membership cache");

    assert_eq!(membership.len(), ir.geometry.points.len());
    for (point, faces) in membership.iter().enumerate() {
        let dense_faces = (0..dense.len())
            .filter(|face| dense[*face].get(point) == Some(&true))
            .collect::<Vec<_>>();
        assert_eq!(*faces, dense_faces, "point {point}");
    }
    assert!(membership.iter().any(|faces| faces.len() > 2));
    assert!(membership.iter().any(|faces| faces == &[6]));
}

#[test]
fn freeform_face_bounds_constrain_unknown_surface_endpoints() {
    let bounds = StandardFaceBounds {
        aabb_center: [
            crate::test_support::test_b5::finite(2.0),
            crate::test_support::test_b5::finite(3.0),
            crate::test_support::test_b5::finite(4.0),
        ],
        aabb_half_extents: [
            crate::test_support::test_b5::nonnegative_length(1.0),
            crate::test_support::test_b5::nonnegative_length(2.0),
            crate::test_support::test_b5::nonnegative_length(3.0),
        ],
        sphere_center: [
            crate::test_support::test_b5::finite(2.0),
            crate::test_support::test_b5::finite(3.0),
            crate::test_support::test_b5::finite(4.0),
        ],
        sphere_radius: crate::test_support::test_b5::nonnegative_length(3.5),
    };
    let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
    assert!(point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(2.0, 4.0, 6.0),
        &surface,
        Some(bounds),
    )
    .expect("surface evaluator accepts the fixture"));
    assert!(!point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(3.01, 3.0, 4.0),
        &surface,
        Some(bounds),
    )
    .expect("surface evaluator accepts the fixture"));
    assert!(!point_on_standard_face(
        &cadmpeg_core::decode::test_support::service_decode_context(),
        Point3::new(3.0, 5.0, 7.0),
        &surface,
        Some(bounds),
    )
    .expect("surface evaluator accepts the fixture"));
}

#[test]
fn standard_plane_line_inverts_to_exact_parameter_line() {
    let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(1.0, 2.0, 3.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Line,
    };
    let (geometry, range) = standard_pcurve_geometry(
        &surface,
        &support,
        Point3::new(2.0, 4.0, 3.0),
        Point3::new(5.0, 8.0, 3.0),
        None,
        None,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("plane line pcurve");
    assert_eq!(range, [0.0, 1.0]);
    assert_eq!(
        geometry,
        PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                cadmpeg_ir::math::Point2::new(1.0, 2.0),
                cadmpeg_ir::math::Point2::new(3.0, 4.0)
            )
            .expect("valid LinePcurve fixture")
        )
    );
}

#[test]
fn standard_emission_reverses_face_pcurve_range() {
    for reversed in [false, true] {
        let mut ir = CadIr::empty();
        ir.geometry.points.extend([
            Point::new(
                PointId::mint("catia:test:point#point-0").expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(0.0, 0.0, 0.0))
                    .expect("a finite position is a point"),
                None,
            ),
            Point::new(
                PointId::mint("catia:test:point#point-1").expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(1.0, 0.0, 0.0))
                    .expect("a finite position is a point"),
                None,
            ),
        ]);
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint("catia:test:surface#surface-0").expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
        ir.geometry.faces.push(Face {
            id: FaceId::mint("catia:standard:face#0").expect("identity grammar"),
            shell: ShellId::mint("catia:test:shell#shell-0").expect("identity grammar"),
            surface: SurfaceId::mint("catia:test:surface#surface-0").expect("identity grammar"),
            sense: Sense::Forward,
            loops: cadmpeg_ir::topology::FaceLoops::unspecified(Vec::new()),
            name: None,
            color: None,
            tolerance: None,
            native_ref: None,
        });
        let bindings = [(
            SurfaceId::mint("catia:test:surface#surface-0").expect("identity grammar"),
            false,
            0,
        )];
        let surface_indices = HashMap::from([(bindings[0].0.clone(), 0)]);
        let supports = [StandardCurveSupport {
            pos: 0,
            tag: 1,
            faces: [0, 0],
            geometry: StandardCurveGeometry::Line,
        }];
        let topology = crate::families::standard::topology::StandardTopologyDraft {
            faces: vec![crate::families::standard::topology::FaceTopologyDraft {
                boundaries: vec![
                    crate::families::standard::topology::BoundaryDraft::new(vec![
                        crate::families::standard::topology::CoedgeUse {
                            edge_row: 0,
                            reversed,
                            start_vertex: 0,
                            end_vertex: 1,
                        },
                        crate::families::standard::topology::CoedgeUse {
                            edge_row: 0,
                            reversed: !reversed,
                            start_vertex: 1,
                            end_vertex: 0,
                        },
                    ])
                    .expect("nonempty topology boundary"),
                ],
            }],
            edge_rows: vec![crate::families::standard::topology::EdgeRow::new(
                1,
                vec![0, 1],
                crate::families::standard::topology::EdgeBoundaryLayout::CompleteBoundaryRun,
            )
            .expect("admitted edge row")],
            vertex_points: vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            logical_vertex_count: 2,
        };
        let topology =
            { crate::families::standard::topology::admitted::StandardTopology::new(topology) }
                .expect("closed topology");
        let mut annotations = AnnotationBuilder::new();
        crate::test_support::with_service_context(|ctx| {
            let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
            emit_standard_topology(
                ctx,
                crate::families::standard::decode::EmitStandardTopologyInputs {
                    ir: &mut ir,
                    annotations: &mut annotations,
                    bindings: &bindings,
                    brep: &[],
                    face_bounds: &[],
                    surface_indices: &surface_indices,
                    supports: &supports,
                    edge_vertices: &[[0, 1]],
                    point_assignment: &[0, 1],
                    topology: &topology,
                    native_edge_supports: &[None],
                    limit_curve_bindings: &[None],
                    limit_curves: &[],
                    refusal: &mut crate::nurbs::LaneRefusals::new(),
                    admission: &mut admission,
                },
            )
        })
        .expect("valid source object identity");

        let [loop_] = ir.geometry.loops.as_slice() else {
            panic!("standard edge emission must create one loop");
        };
        let [vertex_use, closing_use] = loop_.anchored_vertex_uses() else {
            panic!("standard edge emission must retain both closed-cycle vertex uses");
        };
        assert_eq!(
            vertex_use.vertex,
            VertexId::mint("catia:standard:v#1".to_string()).expect("identity grammar")
        );
        assert_eq!(
            vertex_use.after,
            cadmpeg_ir::ids::CoedgeId::mint("catia:standard:coedge#0:0:0".to_string())
                .expect("identity grammar")
        );

        assert_eq!(
            closing_use.vertex,
            VertexId::mint("catia:standard:v#0".to_string()).expect("identity grammar")
        );
        assert_eq!(
            closing_use.after,
            cadmpeg_ir::ids::CoedgeId::mint("catia:standard:coedge#0:0:1".to_string())
                .expect("identity grammar")
        );

        let [pcurve] = ir.geometry.coedges[0].pcurves.as_slice() else {
            panic!("standard line occurrence must retain its pcurve");
        };
        assert_eq!(
            pcurve
                .parameter_range
                .map(cadmpeg_ir::geometry::DirectedParameterRange::endpoints),
            reversed.then_some([1.0, 0.0])
        );
    }
}

#[test]
fn standard_planar_solid_emission_preserves_native_face_sense() {
    use crate::families::standard::topology::{
        admitted::StandardTopology, BoundaryDraft, CoedgeUse, EdgeBoundaryLayout, EdgeRow,
        FaceTopologyDraft, StandardTopologyDraft,
    };
    use cadmpeg_ir::ids::BodyId;
    use cadmpeg_ir::topology::{Body, BodyKind};
    let mut ir = CadIr::empty();
    let points = [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]];
    for (index, [x, y, z]) in points.into_iter().enumerate() {
        ir.geometry.points.push(Point::new(
            PointId::mint(format!("catia:test:point#{index}")).expect("fixture point id"),
            FinitePoint3::new(Point3::new(x, y, z)).expect("finite fixture point"),
            None,
        ));
    }
    let surface_id = SurfaceId::mint("catia:test:surface#0").expect("fixture surface id");
    ir.geometry.surfaces.push(Surface {
        id: surface_id.clone(),
        geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("fixture plane"),
        )),
        source_object: None,
        native_ref: None,
    });
    ir.geometry.bodies.push(Body {
        id: BodyId::mint("catia:test:body#0").expect("fixture body id"),
        kind: BodyKind::Solid,
        transform: None,
        name: None,
        color: None,
        visible: None,
        native_ref: None,
    });
    ir.geometry.faces.push(Face {
        id: FaceId::mint("catia:standard:face#0").expect("fixture face id"),
        shell: ShellId::mint("catia:test:shell#0").expect("fixture shell id"),
        surface: surface_id.clone(),
        sense: Sense::Reversed,
        loops: cadmpeg_ir::topology::FaceLoops::unspecified(Vec::new()),
        name: None,
        color: None,
        tolerance: None,
        native_ref: None,
    });
    let edge_vertices = [[0, 1], [1, 2], [2, 0]];
    let supports = [1, 2, 3].map(|tag| StandardCurveSupport {
        pos: 0,
        tag,
        faces: [0, 0],
        geometry: StandardCurveGeometry::Line,
    });
    let topology = StandardTopology::new(StandardTopologyDraft {
        faces: vec![FaceTopologyDraft {
            boundaries: vec![BoundaryDraft::new(
                edge_vertices
                    .into_iter()
                    .enumerate()
                    .map(|(edge_row, [start_vertex, end_vertex])| CoedgeUse {
                        edge_row,
                        reversed: false,
                        start_vertex,
                        end_vertex,
                    })
                    .collect(),
            )
            .expect("closed triangular boundary")],
        }],
        edge_rows: [[1, 2], [2, 3], [3, 1]]
            .map(|handles| {
                EdgeRow::new(1, handles.to_vec(), EdgeBoundaryLayout::CompleteBoundaryRun)
                    .expect("fixture edge row")
            })
            .to_vec(),
        vertex_points: points.to_vec(),
        logical_vertex_count: points.len(),
    })
    .expect("admitted fixture topology");
    crate::test_support::with_service_context(|ctx| {
        emit_standard_topology(
            ctx,
            super::super::EmitStandardTopologyInputs {
                ir: &mut ir,
                annotations: &mut AnnotationBuilder::new(),
                bindings: &[(surface_id.clone(), false, 0)],
                brep: &[],
                face_bounds: &[],
                surface_indices: &HashMap::from([(surface_id, 0)]),
                supports: &supports,
                edge_vertices: &edge_vertices,
                point_assignment: &[0, 1, 2],
                topology: &topology,
                native_edge_supports: &[None; 3],
                limit_curve_bindings: &[None; 3],
                limit_curves: &[],
                refusal: &mut crate::nurbs::LaneRefusals::new(),
                admission: &mut crate::families::FamilyEntityAdmission::new(ctx),
            },
        )
    })
    .expect("emit planar solid face");

    assert_eq!(ir.geometry.faces[0].sense, Sense::Reversed);
    assert_eq!(
        ir.geometry.faces[0].loops.role(&ir.geometry.loops[0].id),
        cadmpeg_ir::topology::LoopBoundaryRole::Outer
    );
}

#[test]
fn standard_plane_circle_pcurve_preserves_contained_carrier() {
    let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let center = Point3::new(0.0, 0.0, 0.0);
    let radius = 2.0;
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: super::checked_circle(center, radius),
    };
    let carrier = CurveGeometry::Solved(SolvedCurveGeometry::Circle(
        cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
            center,
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            radius,
        )
        .expect("valid CircleCurve fixture"),
    ));
    let start = Point3::new(radius, 0.0, 0.0);
    let end = Point3::new(0.0, radius, 0.0);
    let (geometry, range) = standard_pcurve_geometry(
        &surface,
        &support,
        start,
        end,
        None,
        Some(&carrier),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("contained plane circle pcurve");
    let mapped = range.map(|parameter| {
        let uv = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &geometry,
            parameter,
        )
        .expect("plane circle pcurve endpoint");
        cadmpeg_ir::eval::decode::surface_point(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &surface,
            uv.u,
            uv.v,
        )
        .expect("plane circle surface endpoint")
    });
    assert!(mapped[0].distance(start) <= 1.0e-9);
    assert!(mapped[1].distance(end) <= 1.0e-9);
}

#[test]
fn standard_plane_full_circle_pcurve_preserves_closed_carrier() {
    let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
        cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
        )
        .expect("valid PlaneSurface fixture"),
    ));
    let center = Point3::new(0.0, 0.0, 0.0);
    let radius = 2.0;
    let start = Point3::new(radius, 0.0, 0.0);
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: super::checked_circle(center, radius),
    };
    let carrier = CurveGeometry::Solved(SolvedCurveGeometry::Circle(
        cadmpeg_ir::geometry::analytic::CircleCurve::try_new(
            center,
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            radius,
        )
        .expect("valid CircleCurve fixture"),
    ));
    let (geometry, range) = standard_pcurve_geometry(
        &surface,
        &support,
        start,
        start,
        None,
        Some(&carrier),
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("closed contained plane circle pcurve");
    assert_eq!(range, [0.0, std::f64::consts::TAU]);
    let PcurveGeometry::Nurbs { nurbs } = &geometry else {
        panic!("closed plane circle must use a rational arc");
    };
    assert_eq!(nurbs.degree(), 2);
    assert_eq!(nurbs.knots().len(), 12);
    assert_eq!(nurbs.control_points().len(), 9);
    assert_eq!(nurbs.weights().map(|weights| weights.len()), Some(9));
    for parameter in [range[0], range[1]] {
        let uv = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &geometry,
            parameter,
        )
        .expect("closed pcurve endpoint");
        let point = cadmpeg_ir::eval::decode::surface_point(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &surface,
            uv.u,
            uv.v,
        )
        .expect("closed surface endpoint");
        assert!(point.distance(start) <= 1.0e-9);
    }
    let midpoint_uv = cadmpeg_ir::eval::decode::pcurve_uv(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &geometry,
        std::f64::consts::PI,
    )
    .expect("closed pcurve midpoint");
    let midpoint = cadmpeg_ir::eval::decode::surface_point(
        cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
        &surface,
        midpoint_uv.u,
        midpoint_uv.v,
    )
    .expect("closed surface midpoint");
    assert!(midpoint.distance(Point3::new(-radius, 0.0, 0.0)) <= 1.0e-9);
}

mod curve_bindings;
mod cylindrical_arcs;

#[test]
fn owner_carrier_helper_preserves_session_depth_refusal() {
    let surface = unit_square_surface();
    let tail = owner_tail(
        [0.25, 0.25],
        [0.75, 0.75],
        [[0.2, 0.8], [0.2, 0.8], [-0.1, 0.1]],
    );
    crate::test_support::with_depth_limit(0, |ctx| {
        assert_eq!(owner_matches_a5_carrier(ctx, &tail, &surface), Ok(true));
        let original = ctx
            .enter_nested_limit("owner test outer frame")
            .expect_err("outer frame refuses");
        let limit = owner_matches_a5_carrier(ctx, &tail, &surface)
            .expect_err("first evaluator frame refuses");
        assert_eq!(limit, original);
        assert_eq!(
            limit.dimension,
            cadmpeg_core::decode::ResourceDimension::RecursionDepth
        );
        assert_eq!((limit.limit, limit.used, limit.additional), (0, 0, 1));
        assert_eq!(ctx.resource_refusal(), Some(limit));
        assert_eq!(owner_matches_a5_carrier(ctx, &tail, &surface), Err(limit));
    });
}

#[test]
fn freeform_e5_carrier_ids_resolve_a_record_to_its_wrapped_surface() {
    let mut stream = e5_torus_stream();
    let mut wrapper = vec![0x85, 0xaa, 0x81, 0x82, 0x83, 0x84];
    wrapper.extend_from_slice(&[0; 38]);
    append_e5_record(&mut stream, 0xf1, 8, &wrapper);
    append_e5_record(&mut stream, 0x00, 7, &[0x82, 0x88, 0x89, 1, 0]);
    assert_eq!(standard_freeform_e5_carrier_ids(&stream).get(&7), Some(&42));
}

#[test]
fn invariant_face_carrier_binding_selects_a_sole_candidate() {
    let domains = vec![vec![(0, vec![7])]];
    assert_eq!(
        crate::test_support::with_service_context(|ctx| {
            invariant_face_carrier_bindings(ctx, &domains, 1, None)
        })
        .expect("compute the invariant face carrier bindings"),
        Some(vec![Some(7)])
    );
}

#[test]
fn face_boundary_witnesses_are_empty_without_faces() {
    let mut ir = CadIr::empty();
    ir.geometry.points.push(Point::new(
        PointId::mint("catia:test:point#a5-witness").expect("identity grammar"),
        FinitePoint3::new(Point3::new(1.0, 0.0, 0.0)).expect("finite point"),
        None,
    ));
    assert!(crate::test_support::with_service_context(|ctx| {
        standard_face_boundary_witnesses(ctx, &ir)
    })
    .expect("compute the standard face boundary witnesses")
    .is_empty());
}

#[test]
fn a5_owner_binding_binds_no_surface_without_face_bounds() {
    let mut bytes = crate::test_support::test_a5a8::a5_surface_stream();
    bytes.extend(crate::test_support::test_b2::b2_all_compact_owner_packet_stream());
    let records = crate::wire::records::consolidated_records(&bytes);
    let carriers = crate::families::a5a8::records::a5_surfaces_from_records(
        &bytes,
        &records,
        &mut crate::nurbs::LaneRefusals::new(),
    )
    .expect("decode the A5 surfaces");
    assert!(!carriers.is_empty());
    assert!(
        !crate::families::b2::records::b2_owner_packets_from_records(&bytes, &records)
            .collect::<Vec<_>>()
            .is_empty()
    );
    let mut ir = CadIr::empty();
    let surface_id = SurfaceId::mint("catia:standard:surface#a5-limit").expect("identity grammar");
    ir.geometry.surfaces.push(Surface {
        id: surface_id.clone(),
        geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
        source_object: None,
        native_ref: None,
    });
    ir.geometry.faces.push(Face {
        id: FaceId::mint("catia:standard:face#0").expect("identity grammar"),
        shell: ShellId::mint("catia:standard:shell#0").expect("identity grammar"),
        surface: surface_id,
        sense: Sense::Forward,
        loops: cadmpeg_ir::topology::FaceLoops::unspecified(Vec::new()),
        name: None,
        color: None,
        tolerance: None,
        native_ref: None,
    });
    let source = StandardConsolidatedSource {
        data: &bytes,
        records: &records,
    };
    assert_eq!(
        crate::test_support::with_service_context(|ctx| {
            bind_standard_a5_owner_surfaces(
                ctx,
                &mut ir,
                &mut AnnotationBuilder::new(),
                source,
                &[],
                &cadmpeg_core::decode::WorkBudget::new(100),
                &carriers,
            )
        })
        .expect("bind standard A5 owner surfaces"),
        0
    );
}

#[test]
fn one_line_support_yields_one_edge_class_and_one_gauge_key() {
    let support = StandardCurveSupport {
        pos: 0,
        tag: 7,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Line,
    };
    let supports = [support];

    assert_eq!(standard_curve_edge_classes(&supports), [0]);
    assert_eq!(standard_curve_geometry_gauge_keys(&supports).len(), 1);
}

#[test]
fn propagated_endpoint_pairs_fill_gaps_from_either_source() {
    assert_eq!(
        combine_propagated_endpoint_pairs(
            Some(vec![Some([0, 1]), None]),
            Some(vec![None, Some([2, 3])])
        ),
        Some(vec![Some([0, 1]), Some([2, 3])])
    );
}

#[test]
fn standard_loop_id_uses_the_catia_standard_namespace() {
    use cadmpeg_ir::ids::LoopId;
    let admitted =
        standard_id("loop", format_args!("0:0"), LoopId::mint).expect("valid loop identity");
    assert_eq!(admitted.as_str(), "catia:standard:loop#0:0");
}
