// SPDX-License-Identifier: Apache-2.0
//! face evidence tests.

use super::{
    attach_free_vertices, native_support_circle_param_range, resolve_standard_endpoint_pairs,
    standard_native_support_endpoint_pair, AnnotationBuilder, CadIr, PcurveGeometry, Point, Point2,
    Point3, PointId, SolvedSurfaceGeometry, StandardCurveGeometry, StandardCurveSupport,
    StandardEdgeSupport, Surface, SurfaceGeometry, SurfaceId, Vector3, Vertex, VertexId,
};
use crate::families::standard::decode::copy_standard_extrusion_definition;
use crate::families::standard::decode::standard_extrusion_support_id;
use crate::families::standard::records::AnalyticSurfaceKind;
use crate::families::standard::records::StandardSurfaceRecord;
use crate::families::standard::records::SurfacePrefix;

#[test]
fn standard_empty_vertex_population_creates_no_owner_or_annotations() {
    let mut ir = CadIr::empty();
    let before = ir.clone();
    let mut annotations = AnnotationBuilder::new();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        attach_free_vertices(&mut ir, &mut annotations, &mut admission)
    })
    .expect("attach free vertices");
    assert_eq!(ir, before);
    assert_eq!(annotations.build(), AnnotationBuilder::new().build());
}

#[test]
fn standard_surface_entity_limit_refuses_before_first_surface_append() {
    let bytes = crate::test_support::test_container::standard_catpart();
    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, bytes.clone())
    })
    .expect("scan the container");
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let mut policy = cadmpeg_core::decode::DecodePolicy::service();
    policy.limits.max_entities = 1;
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&bytes, &arena, &policy)
        .expect("standard fixture fits the input-byte limit");
    let result = crate::families::standard::decode::try_decode_standard(
        &ctx,
        &scan,
        &mut crate::nurbs::LaneRefusals::new(),
    );
    let Err(cadmpeg_core::CodecError::ResourceLimit(limit)) = result else {
        panic!("first standard surface must exceed the entity limit");
    };
    assert_eq!(
        limit.dimension,
        cadmpeg_core::decode::ResourceDimension::Entities
    );
    assert_eq!(limit.used, 1);
    assert_eq!(limit.operation, "admit CATIA family model entity");
}

#[test]
fn standard_free_vertex_owner_limit_refuses_before_shell_creation() {
    let mut ir = CadIr::empty();
    ir.geometry.vertices.push(Vertex {
        id: VertexId::mint("catia:test:vertex#v").expect("identity grammar"),
        point: PointId::mint("catia:test:point#p").expect("identity grammar"),
        tolerance: None,
        native_ref: None,
    });
    let mut annotations = AnnotationBuilder::new();
    crate::test_support::with_entity_limit(0, |ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        let Err(cadmpeg_core::CodecError::ResourceLimit(limit)) =
            attach_free_vertices(&mut ir, &mut annotations, &mut admission)
        else {
            panic!("free-vertex owner must exceed the entity limit");
        };
        assert_eq!(
            limit.dimension,
            cadmpeg_core::decode::ResourceDimension::Entities
        );
        assert_eq!(limit.operation, "admit CATIA family model entity");
    });
    assert!(ir.geometry.bodies.is_empty());
    assert!(ir.geometry.regions.is_empty());
    assert!(ir.geometry.shells.is_empty());
}

#[test]
fn standard_unbound_vertices_receive_one_free_vertex_owner() {
    let mut ir = CadIr::empty();
    ir.geometry.vertices.push(Vertex {
        id: VertexId::mint("catia:test:vertex#v".to_string()).expect("identity grammar"),
        point: PointId::mint("catia:test:point#p".to_string()).expect("identity grammar"),
        tolerance: None,
        native_ref: None,
    });
    let mut annotations = AnnotationBuilder::new();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        attach_free_vertices(&mut ir, &mut annotations, &mut admission)
    })
    .expect("attach free vertices");
    assert_eq!(ir.geometry.bodies.len(), 1);
    assert_eq!(ir.geometry.regions.len(), 1);
    assert_eq!(ir.geometry.shells.len(), 1);
    assert_eq!(
        ir.geometry.shells[0]
            .free_vertices()
            .cloned()
            .collect::<Vec<_>>(),
        [VertexId::mint("catia:test:vertex#v".to_string()).expect("identity grammar")]
    );
}

#[test]
fn standard_spline_retains_complete_surface_incidence_pair_domain() {
    let mut ir = CadIr::empty();
    for index in 0..138 {
        ir.geometry.points.push(Point::new(
            PointId::mint(format!("catia:test:point#p{index}")).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(Point3::new(f64::from(index), 0.0, 0.0))
                .expect("a finite position is a point"),
            None,
        ));
    }
    for index in 0..2 {
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint(format!("catia:test:surface#s{index}")).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });
    }
    let bindings = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            true,
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            true,
            0,
        ),
    ];
    let indices = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            1,
        ),
    ]
    .into_iter()
    .collect();
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Bspline,
    };
    let choices = crate::test_support::with_service_context(|ctx| {
        resolve_standard_endpoint_pairs(
            ctx,
            &ir,
            &bindings,
            &indices,
            &[support],
            &[(0..138).collect()],
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("resolve standard endpoint pairs")
    .expect("endpoint option pass");
    assert_eq!(choices[0].len(), 9_453);
    assert_eq!(choices[0].first(), Some(&[0, 1]));
    assert_eq!(choices[0].last(), Some(&[136, 137]));
}

#[test]
fn endpoint_pair_relation_bounds_leave_rows_empty_with_a_loss() {
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Bspline,
    };
    // 400 points state 79,800 relations, past the per-row bound. Two rows of
    // 300 points state 44,850 each, and the second exceeds the shared remainder.
    let candidates = [400, 300, 300].map(|count| (0..count).collect::<Vec<_>>());
    let mut refusal = crate::nurbs::LaneRefusals::new();
    let choices = crate::test_support::with_service_context(|ctx| {
        resolve_standard_endpoint_pairs(
            ctx,
            &CadIr::empty(),
            &[],
            &std::collections::HashMap::new(),
            &[support; 3],
            &candidates,
            &mut refusal,
        )
    })
    .expect("a bounded enumeration is not a decode error")
    .expect("endpoint option pass");

    assert_eq!(
        choices.iter().map(Vec::len).collect::<Vec<_>>(),
        [0, 44_850, 0]
    );
    let notes = refusal.take_notes();
    let [note] = notes.as_slice() else {
        panic!("one note for the bounded rows");
    };
    assert_eq!(
        note.code,
        crate::loss::CatiaLossCode::TopologyStandardSearchBounded.kind()
    );
    assert!(note
        .message
        .contains("bound of 65536 relations per edge row"));
    assert!(note.message.contains("edge rows [0, 2] keep no"));
}

#[test]
fn standard_planar_intersection_spline_uses_the_common_line_domain() {
    let mut ir = CadIr::empty();
    for (index, position) in [
        Point3::new(-2.0, 0.0, 0.0),
        Point3::new(3.0, 0.0, 0.0),
        Point3::new(0.0, 1.0, 0.0),
        Point3::new(0.0, 0.0, 1.0),
    ]
    .into_iter()
    .enumerate()
    {
        ir.geometry.points.push(Point::new(
            PointId::mint(format!("catia:test:point#p{index}")).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(position)
                .expect("a finite position is a point"),
            None,
        ));
    }
    for (index, normal) in [Vector3::new(0.0, 0.0, 1.0), Vector3::new(0.0, 1.0, 0.0)]
        .into_iter()
        .enumerate()
    {
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint(format!("catia:test:surface#s{index}")).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    normal,
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
    }
    let bindings = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            true,
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            true,
            0,
        ),
    ];
    let indices = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            1,
        ),
    ]
    .into_iter()
    .collect();
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Bspline,
    };

    let choices = crate::test_support::with_service_context(|ctx| {
        resolve_standard_endpoint_pairs(
            ctx,
            &ir,
            &bindings,
            &indices,
            &[support],
            &[vec![0, 1, 2, 3]],
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("resolve standard endpoint pairs")
    .expect("endpoint option pass");

    assert_eq!(choices, [vec![[0, 1]]]);
}

#[test]
fn standard_antipodal_circle_candidates_admit_full_circle_seams() {
    let mut ir = CadIr::empty();
    for (index, position) in [Point3::new(5.0, 0.0, 0.0), Point3::new(-5.0, 0.0, 0.0)]
        .into_iter()
        .enumerate()
    {
        ir.geometry.points.push(Point::new(
            PointId::mint(format!("catia:test:point#p{index}")).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(position)
                .expect("a finite position is a point"),
            None,
        ));
    }
    for index in 0..2 {
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint(format!("catia:test:surface#s{index}")).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
    }
    let bindings = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            true,
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            true,
            0,
        ),
    ];
    let indices = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            1,
        ),
    ]
    .into_iter()
    .collect();
    let support = StandardCurveSupport {
        pos: 0,
        tag: 1,
        faces: [0, 1],
        geometry: super::super::checked_circle(Point3::new(0.0, 0.0, 0.0), 5.0),
    };

    let choices = crate::test_support::with_service_context(|ctx| {
        resolve_standard_endpoint_pairs(
            ctx,
            &ir,
            &bindings,
            &indices,
            &[support],
            &[vec![0, 1]],
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("resolve standard endpoint pairs")
    .expect("endpoint option pass");

    assert_eq!(choices, [vec![[0, 0], [0, 1], [1, 1]]]);
}

#[test]
fn standard_parallel_line_rows_retain_domains_independent_of_allocation_order() {
    let mut ir = CadIr::empty();
    for (index, position) in [
        Point3::new(-2.0, 0.0, 0.0),
        Point3::new(2.0, 0.0, 0.0),
        Point3::new(-2.0, 0.0, 1.0),
        Point3::new(2.0, 0.0, 1.0),
    ]
    .into_iter()
    .enumerate()
    {
        ir.geometry.points.push(Point::new(
            PointId::mint(format!("catia:test:point#p{index}")).expect("identity grammar"),
            cadmpeg_ir::features::FinitePoint3::new(position)
                .expect("a finite position is a point"),
            None,
        ));
    }
    for index in 0..2 {
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint(format!("catia:test:surface#s{index}")).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(
                cadmpeg_ir::geometry::analytic::CylinderSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                    2.0,
                )
                .expect("valid CylinderSurface fixture"),
            )),
            source_object: None,
            native_ref: None,
        });
    }
    let bindings = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            true,
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            true,
            0,
        ),
    ];
    let indices = [
        (
            SurfaceId::mint("catia:test:surface#s0".to_string()).expect("identity grammar"),
            0,
        ),
        (
            SurfaceId::mint("catia:test:surface#s1".to_string()).expect("identity grammar"),
            1,
        ),
    ]
    .into_iter()
    .collect();
    let supports = [(90, 900), (10, 100)].map(|(pos, tag)| StandardCurveSupport {
        pos,
        tag,
        faces: [0, 1],
        geometry: StandardCurveGeometry::Line,
    });

    let choices = crate::test_support::with_service_context(|ctx| {
        resolve_standard_endpoint_pairs(
            ctx,
            &ir,
            &bindings,
            &indices,
            &supports,
            &[vec![0, 1, 2, 3], vec![0, 1, 2, 3]],
            &mut crate::nurbs::LaneRefusals::new(),
        )
    })
    .expect("resolve standard endpoint pairs")
    .expect("endpoint option pass");

    assert_eq!(choices, [vec![[0, 2], [1, 3]], vec![[0, 2], [1, 3]]]);
}

#[test]
fn fallback_pair_relation_allowance_grows_with_candidate_points() {
    use crate::families::standard::decode::fallback_pair_relation_allowance;

    assert_eq!(fallback_pair_relation_allowance(&[vec![0, 1, 2]]), 65_536);
    assert_eq!(
        fallback_pair_relation_allowance(&vec![vec![0; 512]; 4]),
        2048 * 64
    );
}

#[test]
fn line_pair_constraint_rejects_pairs_beyond_edge_roles() {
    let constraint = super::super::super::StandardLinePairConstraint::new(&[], &[], &[]);
    assert!(constraint.edge_pairs(&[None]).is_none());
}

/// A unit-radius cone about +Z whose cross-section radius overflows at
/// v = 1e308, with the pcurve that lifts onto its unit circle and the pcurve
/// that lifts to points without finite coordinates.
fn overflowing_cone_support(parameter_range: [f64; 2]) -> StandardEdgeSupport {
    let cone = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
        cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
            Point3::new(0.0, 0.0, 0.0),
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            1.0,
            1.0,
            1.5,
        )
        .expect("valid ConeSurface fixture"),
    ));
    let line = |origin_v: f64| {
        PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, origin_v),
                Point2::new(1.0, 0.0),
            )
            .expect("valid LinePcurve fixture"),
        )
    };
    StandardEdgeSupport {
        surface_object_ids: [20, 21],
        carriers: [
            crate::families::b5::transfer::ResolvedPcurveSurface::Geometry(cone.clone()),
            crate::families::b5::transfer::ResolvedPcurveSurface::Geometry(cone),
        ],
        pcurves: [line(0.0), line(1.0e308)],
        parameter_range,
    }
}

#[test]
fn a_native_circle_range_reads_from_the_finite_support_when_its_partner_overflows() {
    let native = overflowing_cone_support([0.0, 1.5 * std::f64::consts::PI]);
    assert_eq!(
        native_support_circle_param_range(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &native,
            Point3::new(0.0, 0.0, 0.0),
            1.0,
            Vector3::new(0.0, 0.0, 1.0),
            Vector3::new(1.0, 0.0, 0.0),
            [Point3::new(1.0, 0.0, 0.0), Point3::new(0.0, -1.0, 0.0)],
        ),
        Ok(Some([0.0, 1.5 * std::f64::consts::PI]))
    );
}

#[test]
fn a_native_endpoint_pair_reads_from_the_finite_support_when_its_partner_overflows() {
    let native = overflowing_cone_support([1.0, 4.0]);
    let points = [1.0_f64, 4.0]
        .into_iter()
        .enumerate()
        .map(|(index, angle)| {
            Point::new(
                PointId::mint(format!("catia:test:point#overflow-{index}"))
                    .expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(angle.cos(), angle.sin(), 0.0))
                    .expect("a finite position is a point"),
                None,
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        standard_native_support_endpoint_pair(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &native,
            &points,
            &[0, 1],
            None
        ),
        Ok(Some([0, 1]))
    );
}

#[test]
fn a_native_endpoint_pair_reads_from_the_finite_support_when_its_placed_partner_overflows() {
    let mut native = overflowing_cone_support([1.0, 4.0]);
    native.carriers = native.carriers.map(|carrier| match carrier {
        crate::families::b5::transfer::ResolvedPcurveSurface::Geometry(
            SurfaceGeometry::Solved(cone),
        ) => crate::families::b5::transfer::ResolvedPcurveSurface::Geometry(
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Transformed(
                cadmpeg_ir::geometry::PlacedSurface::try_new(
                    Box::new(cone),
                    cadmpeg_ir::transform::Transform::identity(),
                )
                .expect("valid PlacedSurface fixture"),
            )),
        ),
        carrier => carrier,
    });
    let points = [1.0_f64, 4.0]
        .into_iter()
        .enumerate()
        .map(|(index, angle)| {
            Point::new(
                PointId::mint(format!("catia:test:point#placed-overflow-{index}"))
                    .expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(Point3::new(angle.cos(), angle.sin(), 0.0))
                    .expect("a finite position is a point"),
                None,
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        standard_native_support_endpoint_pair(
            &cadmpeg_core::decode::test_support::service_decode_context(),
            &native,
            &points,
            &[0, 1],
            None
        ),
        Ok(Some([0, 1]))
    );
}

#[test]
fn free_vertices_attach_to_a_shell() {
    let mut ir = CadIr::empty();
    ir.geometry.vertices.push(Vertex {
        id: VertexId::mint("catia:test:vertex#limit").expect("identity grammar"),
        point: PointId::mint("catia:test:point#limit").expect("identity grammar"),
        tolerance: None,
        native_ref: None,
    });
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        attach_free_vertices(&mut ir, &mut AnnotationBuilder::new(), &mut admission)
    })
    .expect("attach free vertices");
    assert_eq!(ir.geometry.shells[0].free_vertices().count(), 1);
}

#[test]
fn extrusion_support_adds_one_surface_and_support_entry() {
    use std::collections::HashMap;
    let mut surfaces = Vec::new();
    let mut supports = HashMap::new();
    let geometry = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        standard_extrusion_support_id(
            &mut AnnotationBuilder::new(),
            &mut surfaces,
            &mut supports,
            7,
            geometry,
            &mut admission,
        )
    })
    .expect("compute the standard extrusion support ID");
    assert_eq!(surfaces.len(), 1);
    assert_eq!(supports.len(), 1);
}

#[test]
fn native_edge_faces_take_the_surface_owning_the_support_tag() {
    use std::collections::HashMap;
    use std::collections::HashSet;
    let supports = [StandardCurveSupport {
        pos: 0,
        tag: 700,
        faces: [0, 0],
        geometry: StandardCurveGeometry::Bspline,
    }];
    let records = [10u32, 20].map(|target| {
        StandardSurfaceRecord::Analytic(SurfacePrefix {
            pos: 0,
            target,
            kind: AnalyticSurfaceKind::Cylinder,
        })
    });
    let owners = HashMap::from([(700, HashSet::from([20]))]);
    let mut faces = [[0, 0]];
    crate::families::standard::decode::apply_standard_native_edge_faces(
        &mut faces, &supports, &records, &owners,
    );
    assert_eq!(faces, [[0, 1]]);
}

#[test]
fn standard_face_attachment_mints_face_body_region_and_shell_ids() {
    let brep = crate::test_support::test_topology::standard_quad_topology_stream();
    let bindings = [(
        SurfaceId::mint("catia:test:surface#face").expect("identity grammar"),
        true,
        0,
    )];
    let mut ir = CadIr::empty();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        crate::families::standard::decode::attach_standard_faces(
            ctx,
            &mut ir,
            &mut AnnotationBuilder::new(),
            &bindings,
            &brep,
            &mut admission,
        )
    })
    .expect("attach standard faces");
    assert_eq!(ir.geometry.faces[0].id.as_str(), "catia:standard:face#0");
    assert_eq!(ir.geometry.bodies[0].id.as_str(), "catia:standard:body#0");
    assert_eq!(
        ir.geometry.regions[0].id.as_str(),
        "catia:standard:region#0-0"
    );
    assert_eq!(
        ir.geometry.shells[0].id.as_str(),
        "catia:standard:shell#0-0"
    );
    assert_eq!(
        ir.geometry.shell_faces(&ir.geometry.shells[0].id).count(),
        1
    );
}

#[test]
fn face_partition_splits_components_into_separate_regions_and_shells() {
    let brep = crate::test_support::test_topology::standard_quad_topology_stream();
    let bindings = [(
        SurfaceId::mint("catia:test:surface#partition").expect("identity grammar"),
        true,
        0,
    )];
    let mut base_ir = CadIr::empty();
    let mut base_annotations = AnnotationBuilder::new();
    crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        crate::families::standard::decode::attach_standard_faces(
            ctx,
            &mut base_ir,
            &mut base_annotations,
            &bindings,
            &brep,
            &mut admission,
        )
    })
    .expect("attach standard faces");
    let mut second = base_ir.geometry.faces[0].clone();
    second.id = cadmpeg_ir::ids::FaceId::mint("catia:standard:face#1").expect("identity grammar");
    crate::assemble::annotate(
        &mut base_annotations,
        &second.id,
        "MainDataStream+SurfacicReps",
        0,
        "surfacic_reps_face_sense",
        cadmpeg_ir::Exactness::ByteExact,
    )
    .expect("annotate the entity");
    base_ir.geometry.faces.push(second);
    let components = [vec![0], vec![1]];
    let result = crate::test_support::with_service_context(|ctx| {
        let mut admission = crate::families::FamilyEntityAdmission::new(ctx);
        crate::families::standard::decode::partition_standard_face_components(
            &mut base_ir,
            &mut base_annotations,
            &components,
            &mut admission,
        )
    })
    .expect("partition standard face components");
    assert!(result);
    assert_eq!(base_ir.geometry.regions.len(), 2);
    assert_eq!(
        base_ir.geometry.regions[1].id.as_str(),
        "catia:standard:region#0-1"
    );
    assert_eq!(
        base_ir.geometry.shells[1].id.as_str(),
        "catia:standard:shell#0-1"
    );
    assert_eq!(
        base_ir
            .geometry
            .shell_faces(&base_ir.geometry.shells[1].id)
            .next()
            .expect("shell face")
            .id
            .as_str(),
        "catia:standard:face#1"
    );
}

#[test]
fn extrusion_definition_copy_equals_the_source_definition() {
    let directrix =
        cadmpeg_ir::ids::CurveId::mint("catia:test:directrix#7").expect("identity grammar");
    let direction =
        cadmpeg_ir::features::FiniteVector3::new(cadmpeg_ir::math::Vector3::new(0.0, 0.0, 1.0))
            .expect("finite direction");
    let definition = cadmpeg_ir::geometry::surface_payloads::ExtrusionSurfaceConstruction::legacy(
        directrix, None, direction, None, None,
    );
    let copied = { copy_standard_extrusion_definition(&definition) };
    assert_eq!(
        copied,
        cadmpeg_ir::geometry::ProceduralSurfaceDefinition::Extrusion(definition),
    );
}
