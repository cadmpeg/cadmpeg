//! Byte-level parsing for standard nested CATIA V5 B-rep (`FBB`) streams:
//! edge/vertex tables, trim records, packet triangles, and face parsers.

type FbbEdgeTableOutput = Option<(Vec<EdgeRow>, Vec<usize>, usize, usize)>;
type ScopedEdgeTableOutput = Option<(Vec<EdgeRow>, Vec<usize>, usize)>;

use cadmpeg_core::decode::{DecodeContext, View, WorkBudget};
use cadmpeg_core::CodecError;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::scalar::FiniteReal;
use cadmpeg_ir::units::FiniteVector;

use crate::families::standard::topology::{
    reconstruct, reconstruct_incidence, reconstruct_incidence_with_edge_classes_and_mesh,
    BoundaryDraft, CoedgeUse, EdgeBoundaryLayout, EdgeRow, StandardIncidenceSearch,
    StandardTopologyDraft, TrimRecord,
};
use crate::families::standard::trim_packet::TrimPacket;
use crate::layout::fbb_face_row as fbb_row;
use crate::solve::incidence::{reconstruct_incidence_candidates, IncidenceEndpointDomains};
use crate::solve::mesh_quotient::MeshQuotient;
use crate::solve::missing_edge::{expand_deferred_edge_port_components, motif_port_points};
use crate::solve::union_find::UnionFind;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

pub(super) const EDGE_DELIMITER: [u8; 8] = [0x10, 0x24, 0x04, 0xff, 0xff, 0x00, 0x00, 0x00];
const VERTEX_RECORD_BYTES: usize = 3 + 3 * size_of::<f32>();
const TRIM_KINDS: [u8; 14] = [
    0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
];

// A unit vector is stored as three binary32 values. Rounding a unit
// direction to binary32 changes its squared norm by less than 2.1e-7; this
// bound leaves room for binary32 arithmetic used by a writer without
// admitting a materially non-unit frame.
const FRAME_VECTOR_NORM2_TOLERANCE: f64 = 1.0e-6;

/// Number of face rows in the governing standard topology spine. The spine is
/// the unique largest contiguous stride-eight FBB run; shorter marker runs are
/// not members of this face population. Equal-largest runs leave ownership
/// unresolved.
pub(super) fn standard_face_count(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<usize>, CodecError> {
    let Some(selected) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let layouts = fbb_population_layouts(bytes);
    if layouts.is_empty() || layouts.iter().any(|layout| layout.face_run == selected) {
        Ok(Some(selected.face_count()))
    } else {
        Ok(None)
    }
}

/// Number of physical edge rows in the admitted standard edge-table form.
///
/// The count is available without solving trim incidence or mesh topology,
/// so it can gate the independent `0x60` support-table walk.
pub(crate) fn standard_edge_count(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<usize>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let after_faces = face_run.after_faces();
    Ok(parse_standard_edge_tables(bytes, after_faces).map(|(rows, _)| rows.len()))
}

/// Number of physical edge rows in the width-selected FBB-only tables.
pub(crate) fn fbb_only_edge_count(bytes: &[u8]) -> Option<usize> {
    let face_run = largest_fbb_run(bytes)?;
    let after_faces = face_run.after_faces();
    parse_fbb_edge_tables(bytes, after_faces).map(|(rows, _, _, _)| rows.len())
}

/// RGBA display color for each positional standard face row.
pub(crate) fn standard_face_colors(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<Vec<[u8; 4]>>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let start = face_run.face_start();
    let count = face_run.face_count();
    let Some(marker) = bytes
        .get(start..start + fbb_row::ALPHA)
        .and_then(|bytes| <[u8; 4]>::try_from(bytes).ok())
    else {
        return Ok(None);
    };
    let mut colors = Vec::new();
    for index in 0..count {
        let Some(row) = bytes.get(start + index * fbb_row::LEN..start + (index + 1) * fbb_row::LEN)
        else {
            return Ok(None);
        };
        if row[..fbb_row::ALPHA] != marker {
            return Ok(None);
        }
        colors.push([
            row[fbb_row::RED],
            row[fbb_row::GREEN],
            row[fbb_row::BLUE],
            row[fbb_row::ALPHA],
        ]);
    }
    Ok(Some(colors))
}

fn trim_frame_vectors(
    bytes: &[u8],
    face_start: usize,
    face_count: usize,
) -> Option<Vec<Option<FiniteVector<3>>>> {
    let mut solutions = Vec::new();
    for width in [1, 2, 3] {
        if let Some(records) = parse_trim_chain(bytes, face_start, face_count, width) {
            solutions.push(records);
        }
    }
    let Ok([records]) = <[Vec<TrimRecord>; 1]>::try_from(solutions) else {
        return None;
    };
    let mut vectors = Vec::new();

    for record in records {
        vectors.push(record.frame_vector);
    }
    Some(vectors)
}

/// Unit frame vector for each positional standard trim packet. The result is
/// index-aligned with the expected face-roster population; packets without the
/// optional vector retain an empty slot. When every detected FBB population
/// has one unique trim chain and their concatenated length equals
/// `expected_face_count`, the result concatenates those population-local
/// vectors in source order; otherwise it uses the established
/// single-population selection.
pub(super) fn standard_face_frame_vectors(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    expected_face_count: usize,
) -> Result<Vec<Option<FiniteVector<3>>>, CodecError> {
    let runs = crate::container::fbb_run_ranges(bytes);
    if runs.len() > 1 {
        let mut combined = Vec::new();
        let mut complete = true;
        for range in &runs {
            let Some(vectors) = trim_frame_vectors(bytes, range.start, range.len() / fbb_row::LEN)
            else {
                complete = false;
                break;
            };
            combined.push(vectors);
        }
        if complete && combined.iter().map(Vec::len).sum::<usize>() == expected_face_count {
            let mut vectors = Vec::new();

            for population in combined {
                vectors.extend(population);
            }
            return Ok(vectors);
        }
    }
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(Vec::new());
    };
    Ok(trim_frame_vectors(bytes, face_run.face_start(), face_run.face_count()).unwrap_or_default())
}

/// Return the counted vertex table of an admitted standard nested spine.
pub(super) fn standard_vertex_points(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<Vec<FinitePoint3>>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let after_faces = face_run.after_faces();
    let Some((_, vertex_header)) = parse_standard_edge_tables(bytes, after_faces) else {
        return Ok(None);
    };
    Ok(parse_vertex_points(bytes, vertex_header))
}

/// Coordinates from the counted vertex table following a complete FBB-only
/// edge-table walk.
pub(super) fn fbb_only_vertex_points(bytes: &[u8]) -> Option<Vec<FinitePoint3>> {
    let face_run = largest_fbb_run(bytes)?;
    let after_faces = face_run.after_faces();
    let (_, _, vertex_header, _) = parse_fbb_edge_tables(bytes, after_faces)?;
    parse_vertex_points(bytes, vertex_header)
}

/// Parses the counted standard spine, positional trim packets, mesh boundary
/// cycles, physical edge uses, and port/corner vertex equivalence classes.
/// Returns `None` unless every positional face boundary is unambiguous.
pub(crate) fn parse_standard(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<StandardTopologyDraft>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let face_start = face_run.face_start();
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header, handle_width)) =
        parse_standard_edge_tables_with_width(bytes, after_faces)
    else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    let Some(trims) = parse_trim_chain(bytes, face_start, face_count, handle_width) else {
        return Ok(None);
    };
    reconstruct(ctx, edge_rows, vertex_points, &trims)
}

/// Reconstruct regular-motif standard topology by replaying the trim packet's
/// vertex-allocation program. The allocation is accepted only when it covers
/// the complete vertex table and reproduces every supplied circle endpoint
/// anchor.
pub(super) fn parse_standard_motif(
    ctx: &DecodeContext<'_>,
    topology_budget: &WorkBudget,
    bytes: &[u8],
    edge_faces: &[[usize; 2]],
    circle_anchors: &[Option<[usize; 2]>],
) -> Result<Option<StandardTopologyDraft>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let face_start = face_run.face_start();
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header, handle_width)) =
        parse_standard_edge_tables_with_width(bytes, after_faces)
    else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    if edge_rows.len() != edge_faces.len() || edge_rows.len() != circle_anchors.len() {
        return Ok(None);
    }
    let Some(trims) = parse_trim_chain(bytes, face_start, face_count, handle_width) else {
        return Ok(None);
    };
    let Some(port_points) = motif_port_points(&trims, vertex_points.len()) else {
        return Ok(None);
    };
    let mut edge_points = Vec::new();
    for row in &edge_rows {
        let Some(first) = row
            .handles()
            .first()
            .and_then(|handle| port_points.get(handle))
        else {
            return Ok(None);
        };
        let Some(last) = row
            .handles()
            .last()
            .and_then(|handle| port_points.get(handle))
        else {
            return Ok(None);
        };
        edge_points.push([*first, *last]);
    }
    for (points, anchor) in edge_points.iter().zip(circle_anchors) {
        let Some(mut anchor) = anchor else {
            continue;
        };
        anchor.sort_unstable_by(Ord::cmp);
        let mut points = *points;
        points.sort_unstable_by(Ord::cmp);
        if points != anchor {
            return Ok(None);
        }
    }
    reconstruct_incidence(
        ctx,
        topology_budget,
        edge_rows,
        vertex_points,
        edge_faces,
        &edge_points,
        face_count,
    )
}

/// Reconstruct standard topology while treating equal curve-class identifiers
/// as interchangeable serialized edge rows during incidence-slot completion.
pub(super) fn parse_standard_endpoints_with_edge_classes(
    ctx: &DecodeContext<'_>,
    topology_budget: &WorkBudget,
    bytes: &[u8],
    edge_faces: &[[usize; 2]],
    edge_points: &[[usize; 2]],
    edge_classes: Option<&[usize]>,
) -> Result<Option<StandardTopologyDraft>, CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header)) = parse_standard_edge_tables(bytes, after_faces) else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    if edge_rows.len() != edge_faces.len()
        || edge_rows.len() != edge_points.len()
        || edge_classes.is_some_and(|classes| classes.len() != edge_rows.len())
        || edge_points
            .iter()
            .flatten()
            .any(|point| *point >= vertex_points.len())
    {
        return Ok(None);
    }
    reconstruct_incidence_with_edge_classes_and_mesh(
        ctx,
        edge_rows,
        vertex_points,
        edge_faces,
        edge_points,
        face_count,
        StandardIncidenceSearch {
            budget: topology_budget,
            edge_classes,
            mesh_bytes: Some(bytes),
        },
    )
}

/// Collapse equal endpoint identities and propagate correlated edge-pair
/// support to a fixpoint. Only serialized pairs supported by both resulting
/// port domains are retained.
pub(super) fn prune_edge_candidates_by_port_domains(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    edge_ports: &[[u32; 2]],
    edge_candidates: &[Vec<[usize; 2]>],
) -> Result<Option<Vec<Vec<[usize; 2]>>>, cadmpeg_core::CodecError> {
    prune_edge_candidates_by_port_domains_with_deferred(ctx, edge_ports, edge_candidates, &[])
}

/// Apply trim-port equality to endpoint candidates whose duplicate face slot
/// is settled. Rows with an open duplicate-face domain do not contribute their
/// candidate set to port-domain propagation; their candidates are filtered by
/// the settled neighbouring ports after that propagation completes.
pub(super) fn prune_edge_candidates_by_port_domains_with_deferred(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    edge_ports: &[[u32; 2]],
    edge_candidates: &[Vec<[usize; 2]>],
    deferred_edges: &[bool],
) -> Result<Option<Vec<Vec<[usize; 2]>>>, cadmpeg_core::CodecError> {
    if edge_ports.len() != edge_candidates.len() || edge_candidates.iter().any(Vec::is_empty) {
        return Ok(None);
    }
    if !deferred_edges.is_empty() && deferred_edges.len() != edge_candidates.len() {
        return Ok(None);
    }
    let mut effective_deferred = if deferred_edges.is_empty() {
        ctx.alloc_filled(
            edge_candidates.len(),
            false,
            "catia_port_effective_deferred",
        )?
    } else {
        deferred_edges.to_vec()
    };
    if !expand_deferred_edge_port_components(edge_ports, &mut effective_deferred) {
        return Ok(None);
    }
    let is_deferred = |edge: usize| effective_deferred[edge];
    let mut all_points = HashSet::new();
    for &point in edge_candidates.iter().flatten().flatten() {
        all_points.insert(point);
    }
    let mut domains = Vec::new();
    for (edge, candidates) in edge_candidates.iter().enumerate() {
        let domain = Arc::new(if is_deferred(edge) {
            let mut copy = HashSet::new();

            copy.extend(all_points.iter().copied());
            copy
        } else {
            let mut points = HashSet::new();
            for &point in candidates.iter().flatten() {
                points.insert(point);
            }
            points
        });
        domains.push(domain.clone());
        domains.push(domain);
    }
    let mut quotient = MeshQuotient::new(domains);
    let mut node_by_port = HashMap::new();
    for (edge, ports) in edge_ports.iter().enumerate() {
        for (endpoint, port) in ports.iter().copied().enumerate() {
            let node = edge * 2 + endpoint;
            if let Some(&previous) = node_by_port.get(&port) {
                if quotient.merge(previous, node)?.is_none() {
                    return Ok(None);
                }
            } else {
                node_by_port.insert(port, node);
            }
        }
    }
    let mut constrained_candidates = Vec::new();

    for candidates in edge_candidates {
        constrained_candidates.push(candidates.clone());
    }
    for (edge, candidates) in constrained_candidates.iter_mut().enumerate() {
        if is_deferred(edge) {
            candidates.clear();
        }
    }
    if !quotient.edge_domains_viable(&constrained_candidates)? {
        return Ok(None);
    }
    let mut result = Vec::new();
    for (edge, candidates) in edge_candidates.iter().enumerate() {
        let left = quotient.find(edge * 2)?;
        let right = quotient.find(edge * 2 + 1)?;
        let mut filtered = Vec::new();
        for &pair in candidates {
            let supported = if left == right {
                pair[0] == pair[1] && quotient.domains()[left].contains(&pair[0])
            } else {
                (quotient.domains()[left].contains(&pair[0])
                    && quotient.domains()[right].contains(&pair[1]))
                    || (quotient.domains()[left].contains(&pair[1])
                        && quotient.domains()[right].contains(&pair[0]))
            };
            if supported {
                filtered.push(pair);
            }
        }
        for pair in &mut filtered {
            pair.sort_unstable_by(Ord::cmp);
        }
        filtered.sort_unstable_by(Ord::cmp);
        filtered.dedup();
        if filtered.is_empty() {
            return Ok(None);
        }
        result.push(filtered);
    }
    Ok(Some(result))
}

/// Reconstruct standard topology while resolving edges that have multiple
/// geometrically valid endpoint pairs. Candidate pairs and edge rows use their
/// serialized order as the stable gauge when equivalent assignments permute
/// indistinguishable line rows. The selected assignment must close every face
/// cycle and satisfy radial orientation. Search charges the supplied topology
/// phase budget.
pub(super) fn parse_standard_endpoint_candidates(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    bytes: &[u8],
    edge_faces: &[[usize; 2]],
    edge_candidates: &[Vec<[usize; 2]>],
    budget: &WorkBudget,
) -> Result<Option<StandardTopologyDraft>, cadmpeg_core::CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header)) = parse_standard_edge_tables(bytes, after_faces) else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    if edge_rows.len() != edge_faces.len()
        || edge_rows.len() != edge_candidates.len()
        || edge_candidates.iter().any(Vec::is_empty)
        || edge_candidates
            .iter()
            .flatten()
            .flatten()
            .any(|point| *point >= vertex_points.len())
    {
        return Ok(None);
    }

    reconstruct_incidence_candidates(
        ctx,
        &edge_rows,
        &vertex_points,
        edge_faces,
        IncidenceEndpointDomains {
            candidates: edge_candidates,
            ports: None,
        },
        face_count,
        budget,
    )
}

/// Reconstruct standard topology from geometric endpoint candidates while
/// enforcing the serialized endpoint-port equality quotient during search.
/// Search charges the supplied topology phase budget.
pub(super) fn parse_standard_port_endpoint_candidates(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    bytes: &[u8],
    edge_faces: &[[usize; 2]],
    edge_candidates: &[Vec<[usize; 2]>],
    edge_ports: &[[u32; 2]],
    budget: &WorkBudget,
) -> Result<Option<StandardTopologyDraft>, cadmpeg_core::CodecError> {
    let Some(face_run) = selected_standard_run(ctx, bytes)? else {
        return Ok(None);
    };
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header)) = parse_standard_edge_tables(bytes, after_faces) else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    if edge_rows.len() != edge_faces.len()
        || edge_rows.len() != edge_candidates.len()
        || edge_rows.len() != edge_ports.len()
        || edge_candidates.iter().any(Vec::is_empty)
        || edge_candidates
            .iter()
            .flatten()
            .flatten()
            .any(|point| *point >= vertex_points.len())
    {
        return Ok(None);
    }
    reconstruct_incidence_candidates(
        ctx,
        &edge_rows,
        &vertex_points,
        edge_faces,
        IncidenceEndpointDomains {
            candidates: edge_candidates,
            ports: Some(edge_ports),
        },
        face_count,
        budget,
    )
}

/// Reconstruct an FBB-only topology from one exact endpoint pair per edge row.
///
/// The FBB-only carrier uses its own two-table delimiter walk rather than the
/// standard edge-table grammar. Those counted tables provide the physical edge
/// rows and the counted vertex table provides the coordinate population. When
/// the native endpoint registry has already selected every pair, face
/// incidence can be closed directly. This path does not infer endpoint
/// identities from trim order.
pub(super) fn parse_fbb_endpoints_with_edge_classes(
    ctx: &DecodeContext<'_>,
    topology_budget: &WorkBudget,
    bytes: &[u8],
    edge_faces: &[[usize; 2]],
    edge_points: &[[usize; 2]],
    edge_classes: Option<&[usize]>,
) -> Result<Option<StandardTopologyDraft>, CodecError> {
    let Some(face_run) = largest_fbb_run(bytes) else {
        return Ok(None);
    };
    let face_count = face_run.face_count();
    let after_faces = face_run.after_faces();
    let Some((edge_rows, _, vertex_header, _)) = parse_fbb_edge_tables(bytes, after_faces) else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    if edge_rows.len() != edge_faces.len()
        || edge_rows.len() != edge_points.len()
        || edge_classes.is_some_and(|classes| classes.len() != edge_rows.len())
        || edge_points
            .iter()
            .flatten()
            .any(|point| *point >= vertex_points.len())
    {
        return Ok(None);
    }
    reconstruct_incidence_with_edge_classes_and_mesh(
        ctx,
        edge_rows,
        vertex_points,
        edge_faces,
        edge_points,
        face_count,
        StandardIncidenceSearch {
            budget: topology_budget,
            edge_classes,
            mesh_bytes: Some(bytes),
        },
    )
}

pub(crate) fn parse_fbb_edge_tables(bytes: &[u8], position: usize) -> FbbEdgeTableOutput {
    // FBB-only tables select one width by the complete table-and-vertex walk;
    // accepting the first delimiter match would assign a wrong handle grammar.
    let mut solutions = Vec::new();
    for handle_width in [1, 2, 3] {
        let Some(parsed) = parse_fbb_edge_tables_width(bytes, position, handle_width) else {
            continue;
        };
        if vertex_table_end(bytes, parsed.2).is_some() {
            solutions.push(parsed);
        }
    }
    <[_; 1]>::try_from(solutions)
        .ok()
        .map(|[solution]| solution)
}

fn read_handle(bytes: &[u8], position: usize, width: usize) -> Option<u32> {
    match width {
        1 => bytes.get(position).copied().map(u32::from),
        2 => View::u16_be_at(bytes, position).map(u32::from),
        3 => View::u24_be_at(bytes, position),
        _ => None,
    }
}

pub(super) fn parse_fbb_edge_tables_width(
    bytes: &[u8],
    mut position: usize,
    handle_width: usize,
) -> FbbEdgeTableOutput {
    let mut rows = Vec::new();
    let mut scopes = Vec::new();
    let mut table_count = 0;
    let mut delimiter_family = None;
    loop {
        if bytes.get(position) != Some(&0x01) {
            return None;
        }
        let kind = *bytes.get(position + 1)?;
        let expected_kind = u8::try_from(table_count + 1).ok()?;
        if kind != expected_kind {
            return None;
        }
        position += 2;
        let count = parse_count(bytes, &mut position)?;
        for _ in 0..count {
            if bytes.get(position) != Some(&0x02) {
                return None;
            }
            position += 1;
            let arity = parse_count(bytes, &mut position)?;
            if arity < 2 {
                return None;
            }
            if arity > bytes.get(position..).map_or(0, <[u8]>::len) / handle_width {
                return None;
            }
            let mut handles = Vec::new();
            for _ in 0..arity {
                handles.push(read_handle(bytes, position, handle_width)?);
                position += handle_width;
            }
            rows.push(EdgeRow::new(
                kind,
                handles,
                EdgeBoundaryLayout::CompleteBoundaryRun,
            )?);
            scopes.push(table_count);
        }
        table_count += 1;
        let delimiter = bytes.get(position..position + EDGE_DELIMITER.len())?;
        let family = match handle_width {
            2 if delimiter[0] == 0x10
                && delimiter[1] >= 0x14
                && delimiter[1] != 0x24
                && delimiter[1] & 0x0f == 0x04
                && delimiter[2..] == EDGE_DELIMITER[2..] =>
            {
                delimiter[1] >> 4
            }
            1 | 3 if delimiter == EDGE_DELIMITER => 0x02,
            _ => return None,
        };
        if delimiter_family
            .replace(family)
            .is_some_and(|value| value != family)
        {
            return None;
        }
        position += EDGE_DELIMITER.len();
        if bytes.get(position..position + 2) == Some(&[0x01, 0x06]) {
            break;
        }
    }
    (table_count == 2).then_some((rows, scopes, position, handle_width))
}

/// Recover the row layout used by an FBB-only table from its trim boundaries.
///
/// Complete rows remain complete whenever their stored sequence occurs on a
/// recovered cycle. Some mixed FBB tables store flanking corner handles around
/// an interior sample sequence instead; that form is admitted only when the
/// complete sequence has no occurrence and the interior sequence has at most
/// one occurrence per cycle. Rows with no boundary match remain complete so
/// their fixed unmatched span is preserved for the later placement solver.
pub(super) fn classify_fbb_edge_layouts(rows: &mut [EdgeRow], trims: &[TrimRecord]) -> Option<()> {
    let mut cycles = Vec::new();
    for trim in trims {
        let face = boundary_cycles(trim.packet.triangles())?;
        cycles.push(face);
    }
    for row in rows {
        let complete_matches = cycles
            .iter()
            .flat_map(|face| face.iter())
            .map(|cycle| pattern_match_count(cycle, row.handles()))
            .sum::<usize>();
        if complete_matches != 0 {
            continue;
        }
        let end = row.handles().len().checked_sub(1)?;
        let Some(interior) = row.handles().get(1..end) else {
            continue;
        };
        if interior.is_empty() {
            continue;
        }
        let mut matched = false;
        let mut unique_per_cycle = true;
        for cycle in cycles.iter().flat_map(|face| face.iter()) {
            let count = pattern_match_count(cycle, interior);
            matched |= count != 0;
            unique_per_cycle &= count <= 1;
        }
        if matched && unique_per_cycle && !row.select_flanking_corners() {
            return None;
        }
    }
    Some(())
}

fn pattern_match_count(cycle: &[u32], pattern: &[u32]) -> usize {
    if pattern.is_empty() || pattern.len() > cycle.len() {
        return 0;
    }
    (0..cycle.len())
        .filter(|start| {
            let forward = pattern
                .iter()
                .enumerate()
                .all(|(offset, handle)| cycle[(*start + offset) % cycle.len()] == *handle);
            let reversed = pattern
                .iter()
                .rev()
                .enumerate()
                .all(|(offset, handle)| cycle[(*start + offset) % cycle.len()] == *handle);
            forward || reversed
        })
        .count()
}

/// Contiguous fixed-width FBB face rows.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct FbbFaceRun {
    face_start: usize,
    after_faces: usize,
}
impl FbbFaceRun {
    /// Constructs a face run with representable byte bounds.
    pub(super) fn try_new(face_start: usize, face_count: usize) -> Option<Self> {
        let after_faces = face_start.checked_add(face_count.checked_mul(fbb_row::LEN)?)?;
        Some(Self {
            face_start,
            after_faces,
        })
    }

    /// Byte offset of the first face row.
    pub(crate) fn face_start(&self) -> usize {
        self.face_start
    }

    /// Number of fixed-width face rows.
    pub(crate) fn face_count(&self) -> usize {
        (self.after_faces - self.face_start) / fbb_row::LEN
    }

    pub(crate) fn after_faces(&self) -> usize {
        self.after_faces
    }
}

/// Find every independently source-closed standard FBB population.
///
/// The result is intentionally not reduced to the largest run. A caller that
/// has a single result may select it; a caller that has multiple results must
/// bind their carrier and incidence rosters before creating neutral bodies.
pub(super) fn standard_fbb_groups(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Vec<FbbFaceRun>, CodecError> {
    let mut groups = Vec::new();
    for range in crate::container::fbb_run_ranges(bytes) {
        if let Some(group) =
            parse_standard_group(ctx, bytes, range.start, range.len() / fbb_row::LEN)?
        {
            groups.push(group);
        }
    }
    Ok(groups)
}

/// Grammar of a population's edge tables.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum EdgeTableForm {
    Standard,
    FbbOnly,
}

/// A source-closed FBB layout whose topology may still require the global
/// endpoint solver. The edge and vertex counts are structural population
/// keys; they are not body selection by themselves.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) struct FbbPopulationLayout {
    pub(super) face_run: FbbFaceRun,
    pub(super) edge_count: usize,
    pub(super) vertex_count: usize,
    pub(super) edge_table_form: EdgeTableForm,
}

fn vertex_table_end(bytes: &[u8], position: usize) -> Option<usize> {
    if bytes.get(position..position + 2) != Some(&[0x01, 0x06]) {
        return None;
    }
    let mut cursor = position + 2;
    let count = parse_count(bytes, &mut cursor)?;
    let end = cursor.checked_add(count.checked_mul(VERTEX_RECORD_BYTES)?)?;
    let records = bytes.get(cursor..end)?;
    for record in records.chunks_exact(VERTEX_RECORD_BYTES) {
        if record.get(..3) != Some(&[0x05, 0x08, 0x01][..]) {
            return None;
        }
        for offset in [3, 7, 11] {
            let value = View::f32_le_at(record, offset)?;
            FiniteReal::new(f64::from(value))?;
        }
    }
    Some(end)
}

/// Return one source-closed FBB population as a self-contained topology
/// spine. The slice starts at its complete trim chain and ends after its
/// counted vertex table, so the existing single-population parsers can be
/// reused without seeing neighboring populations.
pub(super) fn population_spine<'a>(
    bytes: &'a [u8],
    layout: &FbbPopulationLayout,
) -> Option<&'a [u8]> {
    let parsed = match layout.edge_table_form {
        EdgeTableForm::Standard => {
            parse_standard_edge_tables_with_width(bytes, layout.face_run.after_faces())
        }
        EdgeTableForm::FbbOnly => parse_fbb_edge_tables(bytes, layout.face_run.after_faces())
            .map(|(_, _, vertex_header, handle_width)| (Vec::new(), vertex_header, handle_width)),
    };
    let (_, vertex_header, handle_width) = parsed?;
    let (trim_start, _) = parse_trim_chain_start(
        bytes,
        layout.face_run.face_start(),
        layout.face_run.face_count(),
        handle_width,
    )?;
    let end = vertex_table_end(bytes, vertex_header)?;
    bytes.get(trim_start..end)
}

/// Find every FBB face run with a complete local trim, edge-table, and vertex
/// walk, without requiring endpoint incidence to be solved.
pub(super) fn fbb_population_layouts(bytes: &[u8]) -> Vec<FbbPopulationLayout> {
    let mut layouts = Vec::new();
    for range in crate::container::fbb_run_ranges(bytes) {
        let Some(face_run) = FbbFaceRun::try_new(range.start, range.len() / fbb_row::LEN) else {
            continue;
        };
        let after_faces = face_run.after_faces();
        let parsed = parse_standard_edge_tables_with_width(bytes, after_faces).map(
            |(rows, vertex_header, handle_width)| {
                (rows, vertex_header, handle_width, EdgeTableForm::Standard)
            },
        );
        let parsed = if parsed.is_some() {
            parsed
        } else {
            parse_fbb_edge_tables(bytes, after_faces).map(
                |(rows, _, vertex_header, handle_width)| {
                    (rows, vertex_header, handle_width, EdgeTableForm::FbbOnly)
                },
            )
        };
        let Some((edge_rows, vertex_header, handle_width, edge_table_form)) = parsed else {
            continue;
        };
        if vertex_table_end(bytes, vertex_header).is_none() {
            continue;
        }
        let mut count_position = vertex_header + 2;
        let Some(vertex_count) = parse_count(bytes, &mut count_position) else {
            continue;
        };
        if parse_trim_chain(
            bytes,
            face_run.face_start(),
            face_run.face_count(),
            handle_width,
        )
        .is_none()
        {
            continue;
        }
        layouts.push(FbbPopulationLayout {
            face_run,
            edge_count: edge_rows.len(),
            vertex_count,
            edge_table_form,
        });
    }
    layouts
}

fn parse_standard_group(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
    face_start: usize,
    face_count: usize,
) -> Result<Option<FbbFaceRun>, CodecError> {
    let Some(face_run) = FbbFaceRun::try_new(face_start, face_count) else {
        return Ok(None);
    };
    let after_faces = face_run.after_faces();
    let Some((edge_rows, vertex_header, handle_width)) =
        parse_standard_edge_tables_with_width(bytes, after_faces)
    else {
        return Ok(None);
    };
    let Some(vertex_points) = parse_vertex_table(bytes, vertex_header) else {
        return Ok(None);
    };
    let Some(trims) = parse_trim_chain(bytes, face_start, face_count, handle_width) else {
        return Ok(None);
    };
    Ok(reconstruct(ctx, edge_rows, vertex_points, &trims)?.map(|_| face_run))
}

pub(crate) fn selected_standard_run(
    ctx: &DecodeContext<'_>,
    bytes: &[u8],
) -> Result<Option<FbbFaceRun>, CodecError> {
    let ranges = crate::container::fbb_run_ranges(bytes);
    if let [range] = ranges.as_slice() {
        // A single marker run has no competing population to disambiguate.
        return Ok(FbbFaceRun::try_new(range.start, range.len() / fbb_row::LEN));
    }
    let groups = standard_fbb_groups(ctx, bytes)?;
    Ok(match groups.as_slice() {
        [group] => Some(*group),
        [] => largest_fbb_run(bytes),
        _ => None,
    })
}

pub(crate) fn largest_fbb_run(bytes: &[u8]) -> Option<FbbFaceRun> {
    let mut best: Option<FbbFaceRun> = None;
    let mut tied = false;
    let mut position = 0;
    while position + fbb_row::LEN <= bytes.len() {
        if crate::container::is_fbb_row(&bytes[position..]) {
            let start = position;
            let mut count = 0;
            while position + fbb_row::LEN <= bytes.len()
                && crate::container::is_fbb_row(&bytes[position..])
            {
                count += 1;
                position += fbb_row::LEN;
            }
            if best.is_none_or(|run| count > run.face_count()) {
                best = Some(FbbFaceRun::try_new(start, count)?);
                tied = false;
            } else if best.is_some_and(|run| count == run.face_count()) {
                tied = true;
            }
        } else {
            position += 1;
        }
    }
    if tied {
        None
    } else {
        best
    }
}

#[cfg(test)]
mod appearance_tests {
    use super::standard_face_colors;

    #[test]
    fn face_colors_are_abgr_and_require_one_marker_family() {
        let bytes = [
            0xb0, 4, 4, 0xff, 0x99, 0x1f, 0x1a, 0xd1, 0xb0, 4, 4, 0xff, 0xff, 0xe0, 0x3d, 0x14,
        ];
        assert_eq!(
            crate::test_support::with_service_context(|ctx| standard_face_colors(ctx, &bytes))
                .expect("compute the standard face colors"),
            Some(vec![[0xd1, 0x1a, 0x1f, 0x99], [0x14, 0x3d, 0xe0, 0xff]])
        );
        let mut mixed = bytes;
        mixed[8] = 0x30;
        assert_eq!(
            crate::test_support::with_service_context(|ctx| standard_face_colors(ctx, &mixed))
                .expect("compute the standard face colors"),
            None
        );
    }
}

fn parse_count(bytes: &[u8], position: &mut usize) -> Option<usize> {
    let first = *bytes.get(*position)?;
    *position += 1;
    if first != 0xff {
        return Some(usize::from(first));
    }
    let value = View::u32_le_at(bytes, *position)?;
    *position += 4;
    usize::try_from(value).ok()
}

pub(crate) fn parse_edge_tables(bytes: &[u8], position: usize) -> Option<(Vec<EdgeRow>, usize)> {
    parse_standard_edge_tables(bytes, position).or_else(|| {
        parse_fbb_edge_tables(bytes, position)
            .map(|(rows, _, vertex_header, _)| (rows, vertex_header))
    })
}

fn parse_standard_edge_tables(bytes: &[u8], position: usize) -> Option<(Vec<EdgeRow>, usize)> {
    parse_standard_edge_tables_with_width(bytes, position)
        .map(|(rows, vertex_header, _)| (rows, vertex_header))
}

pub(crate) fn parse_standard_edge_tables_with_width(
    bytes: &[u8],
    position: usize,
) -> Option<(Vec<EdgeRow>, usize, usize)> {
    parse_standard_edge_tables_scoped(bytes, position)
        .map(|(rows, _, vertex_header, handle_width)| (rows, vertex_header, handle_width))
}

pub(crate) fn parse_standard_edge_tables_scoped(
    bytes: &[u8],
    position: usize,
) -> FbbEdgeTableOutput {
    // The full standard spine uses u16be rows and may contain one or more
    // counted tables. Keep that grammar first so a malformed standard walk
    // cannot silently enter the compact form below.
    if let Some((rows, scopes, vertex_header)) = parse_edge_tables_scoped_width(bytes, position, 2)
    {
        if vertex_table_end(bytes, vertex_header).is_some() {
            return Some((rows, scopes, vertex_header, 2));
        }
    }

    // CATIA also emits a compact standard spine with one kind-01 table. Its
    // rows use one selected width and the table is closed directly by the
    // counted vertex table. A two-table walk belongs to the separate FBB-only
    // family and must not be admitted through this fallback.
    if bytes.get(position..position + 2) != Some(&[0x01, 0x01]) {
        return None;
    }
    let (rows, scopes, vertex_header, handle_width) =
        parse_edge_tables_scoped_at_with_width(bytes, position)?;
    (!rows.is_empty()
        && scopes.iter().all(|scope| *scope == 0)
        && rows
            .iter()
            .all(|row| row.boundary_layout() == EdgeBoundaryLayout::CompleteBoundaryRun))
    .then_some((rows, scopes, vertex_header, handle_width))
}

#[cfg(test)]
pub(super) fn parse_edge_tables_at(bytes: &[u8], position: usize) -> Option<(Vec<EdgeRow>, usize)> {
    parse_edge_tables_scoped_at(bytes, position)
        .map(|(rows, _, vertex_header)| (rows, vertex_header))
}

#[cfg(test)]
pub(super) fn parse_edge_tables_scoped_at(bytes: &[u8], position: usize) -> ScopedEdgeTableOutput {
    parse_edge_tables_scoped_at_with_width(bytes, position)
        .map(|(rows, scopes, vertex_header, _)| (rows, scopes, vertex_header))
}

fn parse_edge_tables_scoped_at_with_width(bytes: &[u8], position: usize) -> FbbEdgeTableOutput {
    let mut solutions = Vec::new();
    for handle_width in [1, 2, 3] {
        let Some(parsed) = parse_edge_tables_scoped_width(bytes, position, handle_width) else {
            continue;
        };
        if vertex_table_end(bytes, parsed.2).is_some() {
            solutions.push((parsed.0, parsed.1, parsed.2, handle_width));
        }
    }
    <[_; 1]>::try_from(solutions)
        .ok()
        .map(|[solution]| solution)
}

fn parse_edge_tables_scoped_width(
    bytes: &[u8],
    mut position: usize,
    handle_width: usize,
) -> ScopedEdgeTableOutput {
    let mut rows = Vec::new();
    let mut scopes = Vec::new();
    let mut scope = 0usize;
    loop {
        if bytes.get(position) != Some(&0x01) {
            return None;
        }
        let kind = *bytes.get(position + 1)?;
        if !matches!(kind, 0x01 | 0x02) {
            return None;
        }
        position += 2;
        let count = parse_count(bytes, &mut position)?;
        for _ in 0..count {
            if bytes.get(position) != Some(&0x02) {
                return None;
            }
            position += 1;
            let arity = parse_count(bytes, &mut position)?;
            if arity < 2 {
                return None;
            }
            if arity > bytes.get(position..).map_or(0, <[u8]>::len) / handle_width {
                return None;
            }
            let mut handles = Vec::new();
            for _ in 0..arity {
                handles.push(read_handle(bytes, position, handle_width)?);
                position += handle_width;
            }
            rows.push(EdgeRow::new(
                kind,
                handles,
                if arity == 2 {
                    EdgeBoundaryLayout::CompleteBoundaryRun
                } else {
                    EdgeBoundaryLayout::InteriorWithFlankingCorners
                },
            )?);
            scopes.push(scope);
        }
        let mut saw_delimiter = false;
        while bytes.get(position..)?.starts_with(&EDGE_DELIMITER) {
            saw_delimiter = true;
            position += EDGE_DELIMITER.len();
        }
        if !saw_delimiter {
            return None;
        }
        if bytes.get(position..position + 2) == Some(&[0x01, 0x06]) {
            break;
        }
        scope = scope.checked_add(1)?;
    }
    Some((rows, scopes, position))
}

pub(crate) fn parse_vertex_table(bytes: &[u8], position: usize) -> Option<Vec<[f64; 3]>> {
    let points = parse_vertex_points(bytes, position)?;

    let mut coordinates = Vec::new();

    for point in points {
        let coordinate: [f64; 3] = point.get().into();
        coordinates.push(coordinate);
    }
    Some(coordinates)
}

/// The counted `05 08 01` vertex table at `position`, every coordinate
/// admitted finite.
fn parse_vertex_points(bytes: &[u8], mut position: usize) -> Option<Vec<FinitePoint3>> {
    let rest = bytes.get(position..)?;
    if !rest.starts_with(&[0x01, 0x06]) {
        return None;
    }
    position += 2;
    let count = parse_count(bytes, &mut position)?;
    if count > bytes.get(position..).map_or(0, <[u8]>::len) / VERTEX_RECORD_BYTES {
        return None;
    }
    let mut points = Vec::new();

    for _ in 0..count {
        if bytes.get(position..position + 3) != Some(&[0x05, 0x08, 0x01][..]) {
            return None;
        }
        position += 3;
        let mut coordinates = [FiniteReal::ZERO; 3];
        for coordinate in &mut coordinates {
            let value = View::f32_le_at(bytes, position)?;
            let finite = FiniteReal::new(f64::from(value))?;
            *coordinate = finite;
            position += 4;
        }
        let [x, y, z] = coordinates;
        points.push(FinitePoint3::from_coordinates(x, y, z));
    }
    Some(points)
}

pub(crate) fn parse_trim_chain(
    bytes: &[u8],
    end: usize,
    record_count: usize,
    width: usize,
) -> Option<Vec<TrimRecord>> {
    parse_trim_chain_start(bytes, end, record_count, width).map(|(_, records)| records)
}

fn parse_trim_chain_start(
    bytes: &[u8],
    end: usize,
    record_count: usize,
    width: usize,
) -> Option<(usize, Vec<TrimRecord>)> {
    let compact = parse_trim_chain_with_length_encoding(bytes, end, record_count, width, false);
    let wide_u16be = if width == 2 {
        parse_trim_chain_with_length_encoding(bytes, end, record_count, width, true)
    } else {
        None
    };
    match (compact, wide_u16be) {
        (Some((compact_start, compact)), Some((wide_start, wide)))
            if compact_start == wide_start && compact == wide =>
        {
            Some((compact_start, compact))
        }
        (Some(records), None) | (None, Some(records)) => Some(records),
        (None, None) | (Some(_), Some(_)) => None,
    }
}

fn parse_trim_chain_with_length_encoding(
    bytes: &[u8],
    end: usize,
    record_count: usize,
    width: usize,
    wide_u16be: bool,
) -> Option<(usize, Vec<TrimRecord>)> {
    struct Frame {
        end: usize,
        remaining: usize,
        next_predecessor: usize,
    }

    fn backtrack(frames: &mut Vec<Frame>, reversed: &mut Vec<TrimRecord>) {
        let had_parent = frames.len() > 1;
        frames.pop();
        if had_parent {
            reversed.pop();
        }
    }

    let prefix = bytes.get(..end)?;
    let mut predecessors = HashMap::<usize, Vec<usize>>::new();
    for (start, marker) in prefix.windows(2).enumerate() {
        if marker[0] != 0x01 || !TRIM_KINDS.contains(&marker[1]) {
            continue;
        }
        if let Some(layout) =
            parse_trim_record_layout_with_length_encoding(prefix, start, width, wide_u16be)
        {
            let starts = predecessors.entry(layout.end).or_default();
            starts.push(start);
        }
    }

    let mut solutions = Vec::new();
    let mut reversed = Vec::<TrimRecord>::new();

    let mut frames = Vec::new();
    frames.push(Frame {
        end,
        remaining: record_count,
        next_predecessor: 0,
    });
    while !frames.is_empty() && solutions.len() <= 1 {
        let frame = frames.len() - 1;
        if frames[frame].remaining == 0 {
            let chain_start = frames[frame].end;
            let mut records = Vec::new();

            for record in &reversed {
                records.push(TrimRecord {
                    packet: record.packet.clone(),
                    frame_vector: record.frame_vector,
                    kind: record.kind,
                });
            }
            records.reverse();
            solutions.push((chain_start, records));
            backtrack(&mut frames, &mut reversed);
            continue;
        }
        let predecessor = predecessors
            .get(&frames[frame].end)
            .and_then(|records| records.get(frames[frame].next_predecessor))
            .copied();
        let Some(start) = predecessor else {
            backtrack(&mut frames, &mut reversed);
            continue;
        };
        frames[frame].next_predecessor += 1;
        let Some(record) = parse_trim_record_with_length_encoding(prefix, start, width, wide_u16be)
        else {
            continue;
        };
        let remaining = frames[frame].remaining - 1;
        reversed.push(record);
        frames.push(Frame {
            end: start,
            remaining,
            next_predecessor: 0,
        });
    }
    <[(usize, Vec<TrimRecord>); 1]>::try_from(solutions)
        .ok()
        .map(|[solution]| solution)
}

#[derive(Debug, Clone, PartialEq)]
enum TrimLengthLane {
    Encoded {
        start: usize,
        count: usize,
        wide_u16be: bool,
    },
    PackedTwoStrip,
}

#[derive(Debug, Clone, PartialEq)]
pub(in crate::families::standard) struct TrimRecordLayout {
    kind: u8,
    independent_count: usize,
    strip_count: usize,
    lane: TrimLengthLane,
    frame_vector: Option<FiniteVector<3>>,
    pub(super) handle_offset: usize,
    pub(super) handle_count: usize,
    pub(super) end: usize,
}

#[cfg(test)]
pub(super) fn parse_trim_record_layout(
    bytes: &[u8],
    start: usize,
    width: usize,
) -> Option<TrimRecordLayout> {
    let compact = parse_trim_record_layout_with_length_encoding(bytes, start, width, false);
    let wide_u16be = if width == 2 {
        parse_trim_record_layout_with_length_encoding(bytes, start, width, true)
    } else {
        None
    };
    let equivalent = match (&compact, &wide_u16be) {
        (Some(compact), Some(wide)) => {
            let mut normalized = wide.clone();
            normalized.lane = compact.lane.clone();
            if *compact == normalized {
                match (&compact.lane, &wide.lane) {
                    (TrimLengthLane::PackedTwoStrip, TrimLengthLane::PackedTwoStrip) => true,
                    (
                        TrimLengthLane::Encoded {
                            start: left,
                            count: left_count,
                            wide_u16be: left_wide,
                        },
                        TrimLengthLane::Encoded {
                            start: right,
                            count: right_count,
                            wide_u16be: right_wide,
                        },
                    ) => {
                        let (mut left, mut right) = (*left, *right);
                        let mut same = left_count == right_count;
                        for _ in 0..*left_count {
                            if !same {
                                break;
                            }

                            same = read_trim_length(bytes, &mut left, *left_wide)
                                == read_trim_length(bytes, &mut right, *right_wide);
                        }
                        same
                    }
                    _ => false,
                }
            } else {
                false
            }
        }
        _ => false,
    };
    match (compact, wide_u16be) {
        (Some(compact), Some(_)) if equivalent => Some(compact),
        (Some(layout), None) | (None, Some(layout)) => Some(layout),
        (None, None) | (Some(_), Some(_)) => None,
    }
}

fn read_trim_length(bytes: &[u8], position: &mut usize, wide_u16be: bool) -> Option<usize> {
    if wide_u16be {
        let value = View::u16_be_at(bytes, *position)?;
        *position += 2;
        Some(usize::from(value))
    } else {
        parse_count(bytes, position)
    }
}

fn parse_trim_record_layout_with_length_encoding(
    bytes: &[u8],
    start: usize,
    width: usize,
    wide_u16be: bool,
) -> Option<TrimRecordLayout> {
    if wide_u16be && width != 2 {
        return None;
    }
    if bytes.get(start) != Some(&0x01) {
        return None;
    }
    let kind = *bytes.get(start + 1)?;
    if !TRIM_KINDS.contains(&kind) {
        return None;
    }
    let mask = kind & 0x0f;
    let mut position = start + 2;
    let a = if mask & 1 != 0 {
        parse_count(bytes, &mut position)?
    } else {
        0
    };
    let b_start = position;
    let b = if mask & 2 != 0 {
        parse_count(bytes, &mut position)?
    } else {
        0
    };
    let c = if mask & 4 != 0 {
        parse_count(bytes, &mut position)?
    } else {
        0
    };
    if bytes.get(position) != Some(&0xff) {
        return None;
    }
    position += 1;
    let handle_count = usize::try_from(View::u32_le_at(bytes, position)?).ok()?;
    position += 4;
    if handle_count == 0 {
        return None;
    }
    let frame_vector = if mask & 8 != 0 {
        let components = [
            f64::from(View::f32_le_at(bytes, position)?),
            f64::from(View::f32_le_at(bytes, position + 4)?),
            f64::from(View::f32_le_at(bytes, position + 8)?),
        ];
        position += 12;
        let norm2 = components.iter().map(|value| value * value).sum::<f64>();
        let components = FiniteVector::new(components)?;
        if (norm2 - 1.0).abs() >= FRAME_VECTOR_NORM2_TOLERANCE {
            return None;
        }
        Some(components)
    } else {
        None
    };

    // A two-strip packet stores K0 and K1 as two raw bytes before the H lane.
    // The bytes are not a handle.  At width two they happen to occupy one
    // handle-sized slot; at width three they do not, so sizing the lane as
    // `(N + 1) * width` would consume one byte from the next packet.
    let packed_two_strip_lengths =
        kind == 0x42 && b == 2 && bytes.get(b_start).is_some_and(|encoded| *encoded == 2);
    let primitive_count = b.checked_add(c)?;
    if !packed_two_strip_lengths && primitive_count > bytes.get(position..).map_or(0, <[u8]>::len) {
        return None;
    }
    let lengths_start = position;
    if !packed_two_strip_lengths {
        let mut expected_handles = 3usize.checked_mul(a)?;
        for _ in 0..primitive_count {
            let length = read_trim_length(bytes, &mut position, wide_u16be)?;
            expected_handles = expected_handles.checked_add(length)?;
        }
        if expected_handles != handle_count {
            return None;
        }
    }
    let handle_offset = position;
    let byte_count = if packed_two_strip_lengths {
        2usize.checked_add(handle_count.checked_mul(width)?)?
    } else {
        handle_count.checked_mul(width)?
    };
    let end = handle_offset.checked_add(byte_count)?;
    bytes.get(handle_offset..end)?;
    // Marker candidates become packet layouts only after both the partition
    // and the complete handle lane close. Reject false headers without
    // allocating their declared primitive count.
    let lane = if packed_two_strip_lengths {
        TrimLengthLane::PackedTwoStrip
    } else {
        TrimLengthLane::Encoded {
            start: lengths_start,
            count: primitive_count,
            wide_u16be,
        }
    };
    Some(TrimRecordLayout {
        kind,
        independent_count: a,
        strip_count: b,
        lane,
        frame_vector,
        handle_offset,
        handle_count,
        end,
    })
}

#[cfg(test)]
pub(super) fn parse_trim_record(bytes: &[u8], start: usize, width: usize) -> Option<TrimRecord> {
    let compact = parse_trim_record_with_length_encoding(bytes, start, width, false);
    let wide_u16be = if width == 2 {
        parse_trim_record_with_length_encoding(bytes, start, width, true)
    } else {
        None
    };
    match (compact, wide_u16be) {
        (Some(compact), Some(wide)) if compact == wide => Some(compact),
        (Some(record), None) | (None, Some(record)) => Some(record),
        (None, None) | (Some(_), Some(_)) => None,
    }
}

fn parse_trim_record_with_length_encoding(
    bytes: &[u8],
    start: usize,
    width: usize,
    wide_u16be: bool,
) -> Option<TrimRecord> {
    let layout = parse_trim_record_layout_with_length_encoding(bytes, start, width, wide_u16be)?;
    let mut position = layout.handle_offset;
    let lengths = match layout.lane {
        TrimLengthLane::Encoded {
            start,
            count,
            wide_u16be,
        } => {
            let mut length_position = start;
            let mut lengths = Vec::new();
            for _ in 0..count {
                let length = read_trim_length(bytes, &mut length_position, wide_u16be)?;
                lengths.push(length);
            }
            lengths
        }
        TrimLengthLane::PackedTwoStrip => {
            let packed = bytes.get(position..position + 2)?;
            position += 2;
            let lengths = vec![usize::from(packed[0]), usize::from(packed[1])];
            if lengths.iter().sum::<usize>() != layout.handle_count {
                return None;
            }
            lengths
        }
    };
    let mut handles = Vec::new();
    for _ in 0..layout.handle_count {
        let handle = read_handle(bytes, position, width)?;
        handles.push(handle);
        position += width;
    }

    let (strip_lengths, fan_lengths) = lengths.split_at_checked(layout.strip_count)?;
    let strip_lengths = strip_lengths.to_vec();
    let fan_lengths = fan_lengths.to_vec();
    let packet = TrimPacket::from_lanes(
        layout.independent_count,
        strip_lengths,
        fan_lengths,
        handles,
    )?;
    Some(TrimRecord {
        packet,
        frame_vector: layout.frame_vector,
        kind: layout.kind,
    })
}

pub(crate) fn boundary_cycles(triangles: &[[u32; 3]]) -> Option<Vec<Vec<u32>>> {
    let mut edge_directions = HashMap::<(u32, u32), u8>::new();
    for &[a, b, c] in triangles {
        for (start, end) in [(a, b), (b, c), (c, a)] {
            if start == end {
                return None;
            }
            let (edge, direction) = if start < end {
                ((start, end), 1)
            } else {
                ((end, start), 2)
            };
            if let Some(directions) = edge_directions.get_mut(&edge) {
                if *directions & direction != 0 {
                    return None;
                }
                *directions |= direction;
            } else {
                edge_directions.insert(edge, direction);
            }
        }
    }
    let mut successors = HashMap::new();
    for (&(low, high), &directions) in &edge_directions {
        let boundary = match directions {
            1 => Some((low, high)),
            2 => Some((high, low)),
            3 => None,
            _ => return None,
        };
        if let Some((start, end)) = boundary {
            if successors.contains_key(&start) {
                return None;
            }
            successors.insert(start, end);
        }
    }
    let mut seen = HashSet::new();
    let mut cycles = Vec::new();
    for &start in successors.keys() {
        if seen.contains(&start) {
            continue;
        }
        let mut cycle = Vec::new();
        cycle.push(start);
        seen.insert(start);
        let &mut_current = successors.get(&start)?;
        let mut current = mut_current;
        while current != start {
            if !seen.insert(current) {
                return None;
            }
            cycle.push(current);
            let &next = successors.get(&current)?;
            current = next;
        }
        let minimum = cycle
            .iter()
            .enumerate()
            .min_by_key(|(_, handle)| *handle)
            .map(|(index, _)| index);
        let minimum = minimum?;
        cycle.rotate_left(minimum);
        cycles.push(cycle);
    }
    cycles.sort_by(Ord::cmp);
    (!cycles.is_empty()).then_some(cycles)
}

pub(super) fn cover_cycle(
    ctx: &DecodeContext<'_>,
    cycle: &[u32],
    rows: &[EdgeRow],
    union: &mut UnionFind,
) -> Result<Option<BoundaryDraft>, CodecError> {
    cover_cycle_by_rows(ctx, cycle, rows, union)
}

fn cover_cycle_by_rows(
    ctx: &DecodeContext<'_>,
    cycle: &[u32],
    rows: &[EdgeRow],
    union: &mut UnionFind,
) -> Result<Option<BoundaryDraft>, CodecError> {
    let length = cycle.len();
    let mut matches = Vec::new();
    for (edge_row, row) in rows.iter().enumerate() {
        let Some(pattern) = row.boundary_pattern() else {
            continue;
        };
        let mut row_match = None;
        for start in 0..length {
            let forward = pattern
                .iter()
                .enumerate()
                .all(|(offset, handle)| cycle[(start + offset) % length] == *handle);
            let reversed = pattern
                .iter()
                .rev()
                .enumerate()
                .all(|(offset, handle)| cycle[(start + offset) % length] == *handle);
            if forward {
                if row_match.replace((start, false)).is_some() {
                    return Ok(None);
                }
            } else if reversed && row_match.replace((start, true)).is_some() {
                return Ok(None);
            }
        }
        if let Some((start, reversed)) = row_match {
            let Some((boundary_start, segment_count)) = row.boundary_span(start, length) else {
                return Ok(None);
            };
            matches.push((boundary_start, segment_count, edge_row, reversed));
        }
    }
    if matches.is_empty() {
        return Ok(None);
    }
    let mut coverage = ctx.alloc_filled(length, 0_u8, "catia FBB boundary coverage")?;
    for &(start, edge_count, _, _) in &matches {
        for offset in 0..edge_count {
            let index = (start + offset) % length;
            let Some(count) = coverage[index].checked_add(1) else {
                return Ok(None);
            };
            coverage[index] = count;
        }
    }
    if coverage.iter().any(|count| *count != 1) {
        return Ok(None);
    }
    matches.sort_by_key(|left| left.0 % length);
    let mut corner_nodes = HashMap::new();
    for &(start, edge_count, _, _) in &matches {
        let end = (start + edge_count) % length;
        for corner in [start % length, end] {
            corner_nodes.entry(corner).or_insert_with(|| union.push());
        }
    }
    let mut coedges = Vec::new();

    for (start, edge_count, edge_row, reversed) in matches {
        let start_node = corner_nodes[&(start % length)];
        let end_node = corner_nodes[&((start + edge_count) % length)];
        let edge_start = edge_row * 2;
        let edge_end = edge_start + 1;
        if reversed {
            union.union(edge_end, start_node)?;
            union.union(edge_start, end_node)?;
        } else {
            union.union(edge_start, start_node)?;
            union.union(edge_end, end_node)?;
        }
        coedges.push(CoedgeUse {
            edge_row,
            reversed,
            start_vertex: start_node,
            end_vertex: end_node,
        });
    }
    Ok(BoundaryDraft::new(coedges))
}

#[cfg(test)]
mod endpoint_tests {
    use super::parse_fbb_endpoints_with_edge_classes;

    fn synthetic_fbb_triangle() -> Vec<u8> {
        let mut bytes = vec![0x01, 0x41, 0x01, 0xff];
        bytes.extend_from_slice(&3u32.to_le_bytes());
        bytes.extend_from_slice(&[0, 1, 2]);

        bytes.extend_from_slice(&[0x30, 0x04, 0x04, 0xff, 0, 0, 0, 0]);
        bytes.extend_from_slice(&[0x30, 0x04, 0x04, 0xff, 0, 0, 0, 0]);

        bytes.extend_from_slice(&[0x01, 0x01, 0x03]);
        for handles in [[0, 1], [1, 2], [2, 0]] {
            bytes.extend_from_slice(&[0x02, 0x02]);
            bytes.extend_from_slice(&handles);
        }
        bytes.extend_from_slice(&[
            0x10, 0x24, 0x04, 0xff, 0xff, 0x00, 0x00, 0x00, 0x01, 0x02, 0x00, 0x10, 0x24, 0x04,
            0xff, 0xff, 0x00, 0x00, 0x00, 0x01, 0x06, 0x03,
        ]);
        for point in [[0.0_f32, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]] {
            bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
            for coordinate in point {
                bytes.extend_from_slice(&coordinate.to_le_bytes());
            }
        }
        bytes
    }

    #[test]
    fn fbb_endpoint_reconstruction_uses_the_native_edge_pairs() {
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let policy = cadmpeg_core::decode::DecodePolicy::service();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
            .expect("fixture fits the input limit");
        let bytes = synthetic_fbb_triangle();
        let topology = parse_fbb_endpoints_with_edge_classes(
            &ctx,
            &crate::test_support::topology_budget(),
            &bytes,
            &[[0, 1], [0, 1], [0, 1]],
            &[[0, 1], [1, 2], [0, 2]],
            Some(&[0, 1, 2]),
        )
        .expect("parse FBB endpoints with edge classes")
        .expect("native endpoint pairs close the FBB face");

        assert_eq!(topology.face_count(), 2);
        assert_eq!(topology.edge_rows().len(), 3);
        assert_eq!(
            topology.vertex_points(),
            &[[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
        );
        assert_eq!(
            topology
                .edge_vertices(&ctx)
                .expect("resolve the edge vertices"),
            Some(vec![[0, 1], [1, 2], [0, 2]])
        );
    }
}

#[cfg(test)]
mod tests {
    use super::{boundary_cycles, fbb_row, FbbFaceRun};

    #[test]
    fn face_run_admission_checks_byte_bounds() {
        assert!(FbbFaceRun::try_new(0, usize::MAX).is_none());
        assert!(FbbFaceRun::try_new(usize::MAX, 1).is_none());
        let run = FbbFaceRun::try_new(7, 2).expect("bounded face run");
        assert_eq!(run.face_start(), 7);
        assert_eq!(run.face_count(), 2);
        assert_eq!(run.after_faces(), 7 + 2 * fbb_row::LEN);
        let empty = FbbFaceRun::try_new(usize::MAX, 0).expect("empty face run");
        assert_eq!(empty.face_count(), 0);
        assert_eq!(empty.after_faces(), usize::MAX);
    }

    #[test]
    fn boundary_cycles_cancel_opposite_triangle_edges() {
        let triangles = [[0, 1, 2], [0, 2, 3]];
        assert_eq!(boundary_cycles(&triangles), Some(vec![vec![0, 1, 2, 3]]));
    }

    #[test]
    fn boundary_cycles_reject_duplicate_directed_edges() {
        let triangles = [[0, 1, 2], [0, 1, 3]];
        assert_eq!(boundary_cycles(&triangles), None);
    }
}

#[cfg(test)]
mod trim_admission_tests {
    use super::{parse_trim_record_layout, parse_trim_record_layout_with_length_encoding};

    #[test]
    fn false_trim_partition_is_rejected() {
        let mut bytes = vec![0x01, 0x43, 0, 64, 0xff, 1, 0, 0, 0];
        bytes.extend_from_slice(&[0; 64]);
        assert!(parse_trim_record_layout_with_length_encoding(&bytes, 0, 2, false).is_none());
    }

    #[test]
    fn truncated_trim_handles_are_rejected() {
        let bytes = [0x01, 0x43, 0, 1, 0xff, 3, 0, 0, 0, 3, 0, 1];
        assert!(parse_trim_record_layout_with_length_encoding(&bytes, 0, 2, false).is_none());
    }

    #[test]
    fn complete_trim_layout_keeps_lengths_in_the_source_lane() {
        let bytes = [0x01, 0x43, 0x00, 0x01, 0xff, 3, 0, 0, 0, 3, 0, 1, 2];
        let layout = parse_trim_record_layout(&bytes, 0, 1).expect("complete partition");
        assert_eq!(layout.handle_count, 3);
        assert_eq!(layout.end, bytes.len());
    }
}
