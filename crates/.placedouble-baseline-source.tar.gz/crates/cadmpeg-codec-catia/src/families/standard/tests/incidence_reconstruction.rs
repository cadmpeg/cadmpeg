use crate::families::standard::topology::reconstruct_incidence;
use crate::families::standard::topology::EdgeBoundaryLayout;
use crate::families::standard::topology::EdgeRow;

#[test]
fn endpoint_incidence_builds_oriented_tetrahedron_cycles() {
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[0], &arena, &policy)
        .expect("build the decode context");
    let rows: Vec<_> = (0..6)
        .map(|edge| {
            assert!(EdgeRow::new(
                1,
                vec![edge * 2, edge * 2 + 1],
                EdgeBoundaryLayout::InteriorWithFlankingCorners
            )
            .is_none());
            EdgeRow::new(
                1,
                vec![edge * 2, edge * 2, edge * 2 + 1],
                EdgeBoundaryLayout::InteriorWithFlankingCorners,
            )
            .expect("admitted edge row")
        })
        .collect();
    let points = vec![
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
    ];
    let edge_faces = [[0, 1], [0, 2], [0, 3], [1, 3], [1, 2], [2, 3]];
    let edge_points = [[0, 1], [1, 2], [2, 0], [0, 3], [3, 1], [2, 3]];
    let topology = reconstruct_incidence(
        &ctx,
        &crate::test_support::topology_budget(),
        rows,
        points,
        &edge_faces,
        &edge_points,
        4,
    )
    .expect("reconstruct incidence")
    .expect("closed oriented incidence");
    assert_eq!(topology.face_count(), 4);
    assert!(topology
        .faces
        .iter()
        .all(|face| { face.boundaries.len() == 1 && face.boundaries[0].coedges.len() == 3 }));
    let mut uses = vec![Vec::new(); 6];
    for face in topology.faces {
        for coedge in &face.boundaries[0].coedges {
            uses[coedge.edge_row].push(coedge.reversed);
        }
    }
    assert!(uses
        .iter()
        .all(|senses| senses == &[false, true] || senses == &[true, false]));
}
