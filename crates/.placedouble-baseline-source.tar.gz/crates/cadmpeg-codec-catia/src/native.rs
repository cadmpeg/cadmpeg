// SPDX-License-Identifier: Apache-2.0
//! CATIA-native ownership and design records retained outside the neutral model.

use cadmpeg_ir::native::bytes::NativeBytes;

use cadmpeg_core::decode::u64_from_index;

use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::ops::Range;

use crate::checked::extents_overlap;
use cadmpeg_core::decode::{DecodeContext, View};
use cadmpeg_core::CodecError;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::native::catalogue::{Catalogue, FamilyRow, Phase};
use cadmpeg_ir::scalar::FiniteReal;
use cadmpeg_ir::units::FiniteVector;

pub(crate) mod projection;
use projection::{
    consolidated_edge_nodes, consolidated_edge_runs, consolidated_owner_packets,
    containing_finjpl_segment, external_reference_views, finjpl_family, native_object_graph,
    preview_views, resolve_alias_surface_tags, resolve_owner_chart_support_aliases,
    zero_entity_record, zero_entity_vertex_owner,
};

pub(crate) mod class5b5c;
mod class60;
mod rolling_ball_continuation;
use rolling_ball_continuation::CatiaRollingBallContinuation;
mod four_reference_edge;
use four_reference_edge::CatiaConsolidatedFourReferenceEdge;
pub(crate) mod class61;
mod owner_frames;
use class5b5c::CatiaConsolidatedClass5b5cRecord;
use class60::CatiaConsolidatedClass60Record;

pub(crate) mod edge_definition;

pub(crate) mod chamfer;
use chamfer::{
    consolidated_chamfers, object_chamfers, CatiaConsolidatedChamfer, CatiaObjectChamfer,
};

mod parameter_map;
use parameter_map::CatiaSampledParameterMap;

mod domain_relation;
use domain_relation::CatiaConsolidatedDomainRelation;

mod a_class25_map;
use a_class25_map::CatiaConsolidatedAClass25Map;

pub(crate) mod a5_chart;
use a5_chart::CatiaConsolidatedA5Chart;

mod edge_node;
use edge_node::{
    consolidated_vertex_identities, edge_node_wires, load_edge_nodes, CatiaConsolidatedEdgeNode,
    CatiaConsolidatedEdgeNodeWire,
};

mod e5_curve_support;
mod e5_edge;
mod e5_nurbs_limits;
use e5_curve_support::CatiaE5CurveSupportRecord;
use e5_edge::CatiaE5EdgeRecord;
use e5_nurbs_limits::CatiaE5NurbsLimitRecord;

pub(crate) mod entity_record;
use entity_record::{
    CatiaEntityObjectProduction, CatiaEntityRecord, CatiaEntityRecordBody, CatiaEntityRecordWire,
    CatiaEntityValueProduction,
};

pub(crate) mod zero_entity_allocation;
use zero_entity_allocation::CatiaZeroEntityAllocationEdge;

pub(crate) mod inline_field;
use inline_field::CatiaInlineField;

mod paired_records;
pub(crate) mod project_range;
pub(crate) mod schema_configuration_chain;
pub(crate) mod schema_configuration_roles;
pub(crate) mod sketch_bindings;
use schema_configuration_chain::{
    derive_schema_configuration_row_chains, CatiaSchemaConfigurationRowChain,
};

pub(crate) mod owner_chart;
pub(crate) mod owner_numeric_tail;
use owner_chart::{
    CatiaOwnerChartAddress, CatiaOwnerChartAliasBinding, CatiaOwnerChartBridge,
    CatiaOwnerChartBridgeReference, CatiaOwnerChartCarrier, CatiaOwnerChartRelation,
};
use owner_numeric_tail::CatiaOwnerNumericTail;

use crate::catalog;
use crate::container;
use crate::entity_table;
use crate::families::b2::records::B2ParameterPointPayload;
use crate::legacy_entity;
use crate::object_graph::{
    self, AliasGroupMembership, AliasLead, HeadToken, ListItem, ObjectPayload, PayloadField,
    PayloadSubtype,
};
use crate::storage_property::{self, CatiaStoragePropertyMember};
use crate::value_block;
use crate::wire::records::{ConsolidatedFrameFlag, ConsolidatedFrameWidth, ConsolidatedRecord};

mod wire_views;

/// Collects source records with fallible growth, charging each on arrival.
fn admit_records<T>(
    ctx: &DecodeContext<'_>,
    records: impl Iterator<Item = Result<T, CodecError>>,
    operation: &'static str,
) -> Result<Vec<T>, CodecError> {
    let mut admitted = Vec::new();
    for record in records {
        ctx.charge_entities(1, operation)?;
        admitted.try_reserve(1).map_err(|_| {
            CodecError::ResourceLimit(cadmpeg_core::decode::ResourceLimit::allocation_failed(
                cadmpeg_core::decode::ResourceDimension::RetainedBytes,
                ctx.policy().limits.max_retained_bytes,
                1,
                operation,
            ))
        })?;
        admitted.push(record?);
    }
    Ok(admitted)
}

fn slice_is_empty<T>(values: &&[T]) -> bool {
    values.is_empty()
}

/// Consolidated pcurve framing family.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaConsolidatedFamily {
    /// A-family frame with a u32 payload length.
    A,
    /// B-family frame with a u8 payload length.
    B,
}

/// Reference dialect used by a consolidated class-`0x62` owner packet.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaOwnerReferenceEncoding {
    /// Strong identities use tagged little-endian `u16` values.
    TaggedU16Strong,
    /// Strong identities use width-coded compact integers.
    WidthCodedStrong,
    /// All nine identities use the compact-integer reference grammar.
    AllCompact,
}

impl From<crate::families::b2::records::B2OwnerReferenceEncoding> for CatiaOwnerReferenceEncoding {
    fn from(value: crate::families::b2::records::B2OwnerReferenceEncoding) -> Self {
        match value {
            crate::families::b2::records::B2OwnerReferenceEncoding::TaggedU16Strong => {
                Self::TaggedU16Strong
            }
            crate::families::b2::records::B2OwnerReferenceEncoding::WidthCodedStrong => {
                Self::WidthCodedStrong
            }
            crate::families::b2::records::B2OwnerReferenceEncoding::AllCompact => Self::AllCompact,
        }
    }
}

/// Target encoding of a consolidated class-`0x5f` face node.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaFaceNodeTargetEncoding {
    /// Width-coded compact target.
    Compact,
    /// Zero-based ordinal in the face node's owned allocation.
    OwnedChild,
    /// Strong persistent target encoded as `0x0a <u16le>`.
    TaggedU16Strong,
}

/// Source-local class-`0x5f` occurrence within its owner's bounded source.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "CatiaFaceNodeRelationWire")]
struct CatiaFaceNodeRelation {
    source_offset: u64,
    frame: crate::wire::records::ConsolidatedRawFrame<u64>,
    target_encoding: CatiaFaceNodeTargetEncoding,
    target: u32,
    terminal: NativeBytes<[u8; 2]>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CatiaFaceNodeRelationWire {
    source_offset: u64,
    frame: crate::wire::records::ConsolidatedRawFrame<u64>,
    target_encoding: CatiaFaceNodeTargetEncoding,
    target: u32,
    terminal: NativeBytes<[u8; 2]>,
}

impl TryFrom<CatiaFaceNodeRelationWire> for CatiaFaceNodeRelation {
    type Error = &'static str;
    fn try_from(wire: CatiaFaceNodeRelationWire) -> Result<Self, Self::Error> {
        let record = Self {
            source_offset: wire.source_offset,
            frame: wire.frame,
            target_encoding: wire.target_encoding,
            target: wire.target,
            terminal: wire.terminal,
        };
        if !owner_frames::valid_face_node(&record) {
            return Err("face-node fields disagree with the complete frame");
        }
        Ok(record)
    }
}

/// Selected class of a fixed-nine owner identity target.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum CatiaOwnerIdentityClass {
    /// Class-`0x5d` vertex record.
    Vertex,
    /// Class-`0x5e` edge record.
    Edge,
}

impl From<CatiaOwnerIdentityClass> for u8 {
    fn from(value: CatiaOwnerIdentityClass) -> Self {
        match value {
            CatiaOwnerIdentityClass::Vertex => 0x5d,
            CatiaOwnerIdentityClass::Edge => 0x5e,
        }
    }
}

impl TryFrom<u8> for CatiaOwnerIdentityClass {
    type Error = String;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0x5d => Ok(Self::Vertex),
            0x5e => Ok(Self::Edge),
            other => Err(format!("target_class {other:#x} is not 0x5d or 0x5e")),
        }
    }
}

/// One fixed-nine owner identity resolved within its allocation source.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
struct CatiaOwnerIdentityTarget {
    /// Zero-based identity slot in the fixed-nine packet.
    slot: u8,
    /// Decoded backward distance.
    distance: u32,
    /// Byte offset of the selected class-`0x5d` or class-`0x5e` record.
    target_byte_offset: u64,
    /// Selected record class.
    target_class: CatiaOwnerIdentityClass,
}

/// Structurally decoded payload of a class-`0x62` consolidated owner packet.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum CatiaOwnerPacketPayload {
    /// Nine alternating strong/weak identities followed by a fixed numeric tail.
    FixedNine {
        /// Reference encoding selected by the packet.
        reference_encoding: CatiaOwnerReferenceEncoding,
        /// Nine persistent identities in serialization order.
        references: [u32; 9],
        /// Exact wire addressing form of each identity in source order.
        identity_encodings: [CatiaOwnerIdentityEncoding; 9],
        /// Structurally decoded 62-byte class-specific numeric tail.
        numeric_tail: CatiaOwnerNumericTail,
        /// Backward-distance identities resolved within this packet's contiguous
        /// class-`0x5d`/`0x5e` allocation sequence.
        #[serde(default, skip_serializing_if = "Vec::is_empty")]
        identity_targets: Vec<CatiaOwnerIdentityTarget>,
        /// Complete carrier/reference/side chart that this packet terminates.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        owner_chart: Option<Box<CatiaOwnerChartRelation>>,
        /// Closed owner-local four-edge boundary, when all four resolved targets
        /// form one simple cycle in the bounded record source.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        boundary_cycle: Option<Box<CatiaOwnerBoundaryCycle>>,
    },
    /// Count-selected persistent identities followed by a nonempty tail.
    Counted {
        /// Persistent identities in serialization order.
        references: Vec<u32>,
        /// Addressing form of each serialized occurrence.
        reference_encodings: Vec<CatiaAllocationReferenceEncoding>,
        /// Complete nonempty class-specific tail.
        tail: crate::families::b2::counted_owner_tail::CountedOwnerTail,
        /// Parameter rectangle and Cartesian bounds in a complete numeric tail.
        #[serde(default, skip_serializing_if = "Option::is_none")]
        numeric_bounds: Option<crate::families::b2::counted_owner_tail::CountedOwnerBounds>,
    },
}

impl CatiaOwnerPacketPayload {
    fn final_reference(&self) -> Option<u32> {
        match self {
            Self::FixedNine { references, .. } => references.last().copied(),
            Self::Counted { references, .. } => references.last().copied(),
        }
    }
}

/// One fixed-nine boundary edge retained when four resolved class-`0x5e`
/// targets close one simple owner-local cycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
struct CatiaOwnerBoundaryEdge {
    /// Identity slot in the fixed-nine packet.
    slot: u8,
    /// Resolved class-`0x5e` edge-record offset.
    byte_offset: u64,
    /// Resolved class-`0x5d` endpoint-record offsets, in edge order.
    endpoint_records: [u64; 2],
}

/// Owner-local boundary evidence derived from a closed fixed-nine cycle.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
struct CatiaOwnerBoundaryCycle {
    /// Source-scoped class-`0x5f` face node that precedes this boundary
    /// allocation and closes its checked identity, when present.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    face_node: Option<CatiaFaceNodeRelation>,
    /// Four edge targets in fixed-nine slot order.
    edges: [CatiaOwnerBoundaryEdge; 4],
}

/// Exact class-`0x62` consolidated owner packet.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "CatiaConsolidatedOwnerPacketWire")]
pub(crate) struct CatiaConsolidatedOwnerPacket {
    /// Stable source identity.
    id: String,
    /// Logical offset within the bounded record source.
    source_offset: u64,
    /// Complete source frame.
    frame: crate::wire::records::ConsolidatedRawFrame<u64>,
    /// Zero-based bounded record-source ordinal.
    source_index: usize,
    /// Count-specific reference lane and tail.
    payload: CatiaOwnerPacketPayload,
    /// Source-scoped class-`0x5f` face node, when the packet relation closes.
    face_node: Option<CatiaFaceNodeRelation>,
}

impl CatiaConsolidatedOwnerPacket {
    #[cfg(test)]
    fn identity_targets(&self) -> &[CatiaOwnerIdentityTarget] {
        match &self.payload {
            CatiaOwnerPacketPayload::FixedNine {
                identity_targets, ..
            } => identity_targets,
            CatiaOwnerPacketPayload::Counted { .. } => &[],
        }
    }

    #[cfg(test)]
    pub(crate) fn owner_chart(&self) -> Option<&CatiaOwnerChartRelation> {
        match &self.payload {
            CatiaOwnerPacketPayload::FixedNine { owner_chart, .. } => owner_chart.as_deref(),
            CatiaOwnerPacketPayload::Counted { .. } => None,
        }
    }

    fn owner_chart_mut(&mut self) -> Option<&mut CatiaOwnerChartRelation> {
        match &mut self.payload {
            CatiaOwnerPacketPayload::FixedNine { owner_chart, .. } => owner_chart.as_deref_mut(),
            CatiaOwnerPacketPayload::Counted { .. } => None,
        }
    }

    #[cfg(test)]
    fn boundary_cycle(&self) -> Option<&CatiaOwnerBoundaryCycle> {
        match &self.payload {
            CatiaOwnerPacketPayload::FixedNine { boundary_cycle, .. } => boundary_cycle.as_deref(),
            CatiaOwnerPacketPayload::Counted { .. } => None,
        }
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaConsolidatedOwnerPacketWire {
    id: String,
    source_offset: u64,
    source_index: usize,
    frame: crate::wire::records::ConsolidatedRawFrame<u64>,
    payload: CatiaOwnerPacketPayload,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    identity_targets: Vec<CatiaOwnerIdentityTarget>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    face_node: Option<CatiaFaceNodeRelation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    owner_chart: Option<CatiaOwnerChartRelation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    boundary_cycle: Option<CatiaOwnerBoundaryCycle>,
}

#[cfg(test)]
impl From<CatiaConsolidatedOwnerPacket> for CatiaConsolidatedOwnerPacketWire {
    fn from(value: CatiaConsolidatedOwnerPacket) -> Self {
        let (identity_targets, owner_chart, boundary_cycle, payload) = match value.payload {
            CatiaOwnerPacketPayload::FixedNine {
                reference_encoding,
                references,
                identity_encodings,
                numeric_tail,
                identity_targets,
                owner_chart,
                boundary_cycle,
            } => (
                identity_targets,
                owner_chart.map(|chart| *chart),
                boundary_cycle.map(|cycle| *cycle),
                CatiaOwnerPacketPayload::FixedNine {
                    reference_encoding,
                    references,
                    identity_encodings,
                    numeric_tail,
                    identity_targets: Vec::new(),
                    owner_chart: None,
                    boundary_cycle: None,
                },
            ),
            payload @ CatiaOwnerPacketPayload::Counted { .. } => (Vec::new(), None, None, payload),
        };
        Self {
            id: value.id,
            source_offset: value.source_offset,
            source_index: value.source_index,
            frame: value.frame,
            payload,
            identity_targets,
            face_node: value.face_node,
            owner_chart,
            boundary_cycle,
        }
    }
}

impl TryFrom<CatiaConsolidatedOwnerPacketWire> for CatiaConsolidatedOwnerPacket {
    type Error = String;

    fn try_from(wire: CatiaConsolidatedOwnerPacketWire) -> Result<Self, Self::Error> {
        let payload = match wire.payload {
            CatiaOwnerPacketPayload::FixedNine {
                reference_encoding,
                references,
                identity_encodings,
                numeric_tail,
                identity_targets,
                owner_chart,
                boundary_cycle,
            } => {
                if !identity_targets.is_empty() || owner_chart.is_some() || boundary_cycle.is_some()
                {
                    return Err(
                        "fixed-nine metadata must occur only at the packet level".to_owned()
                    );
                }
                CatiaOwnerPacketPayload::FixedNine {
                    reference_encoding,
                    references,
                    identity_encodings,
                    numeric_tail,
                    identity_targets: wire.identity_targets,
                    owner_chart: wire.owner_chart.map(Box::new),
                    boundary_cycle: wire.boundary_cycle.map(Box::new),
                }
            }
            counted @ CatiaOwnerPacketPayload::Counted { .. } => {
                if !wire.identity_targets.is_empty()
                    || wire.owner_chart.is_some()
                    || wire.boundary_cycle.is_some()
                {
                    return Err(
                        "counted owner packets cannot carry fixed-nine chart or boundary data"
                            .to_owned(),
                    );
                }
                counted
            }
        };
        let record = Self {
            id: wire.id,
            source_offset: wire.source_offset,
            source_index: wire.source_index,
            frame: wire.frame,
            payload,
            face_node: wire.face_node,
        };
        if !owner_frames::valid_owner_packet(&record) {
            return Err(
                "owner fields or incidence disagree with the complete source frames".into(),
            );
        }
        Ok(record)
    }
}

/// One structurally complete consolidated `B:29` cone chart.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(try_from = "CatiaConsolidatedConeWire")]
pub(crate) struct CatiaConsolidatedCone {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Cone apex.
    apex: FiniteVector<3>,
    /// First transverse unit direction.
    direction_x: crate::checked::RelaxedUnitVector3,
    /// Second transverse unit direction.
    direction_y: crate::checked::RelaxedUnitVector3,
    /// Cone-axis unit direction.
    axis: crate::checked::RelaxedUnitVector3,
    /// Cone half-angle in radians.
    half_angle: cadmpeg_ir::scalar::Angle,
    /// Reference radius of the conical surface, independent of the active chart ranges.
    reference_radius: FiniteReal,
    /// Active azimuth interval.
    angular_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Native slant-coordinate interval, including zero at the apex.
    slant_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Scale from azimuth to stored U parameter.
    angular_scale: cadmpeg_ir::scalar::PositiveReal,
    /// Full-turn azimuth chart domain.
    angular_domain: cadmpeg_ir::topology::IncreasingParameterInterval,
}

#[derive(Deserialize)]
struct CatiaConsolidatedConeWire {
    id: String,
    byte_offset: u64,
    apex: FiniteVector<3>,
    direction_x: crate::checked::RelaxedUnitVector3,
    direction_y: crate::checked::RelaxedUnitVector3,
    axis: crate::checked::RelaxedUnitVector3,
    half_angle: cadmpeg_ir::scalar::Angle,
    reference_radius: FiniteReal,
    angular_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    slant_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    angular_scale: cadmpeg_ir::scalar::PositiveReal,
    angular_domain: cadmpeg_ir::topology::IncreasingParameterInterval,
}

impl TryFrom<CatiaConsolidatedConeWire> for CatiaConsolidatedCone {
    type Error = &'static str;

    fn try_from(wire: CatiaConsolidatedConeWire) -> Result<Self, Self::Error> {
        if crate::checked::UnitFrame3::right_handed(wire.axis, wire.direction_x, wire.direction_y)
            .is_none()
            || !(0.0 < wire.half_angle.get() && wire.half_angle.get() < std::f64::consts::FRAC_PI_2)
            || !crate::analytic::periodic_angular_range_is_valid(
                wire.angular_range.endpoints(),
                wire.angular_domain.endpoints(),
            )
            || wire.slant_range.lower() < 0.0
        {
            return Err("invalid consolidated cone frame or chart");
        }
        Ok(Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            apex: wire.apex,
            direction_x: wire.direction_x,
            direction_y: wire.direction_y,
            axis: wire.axis,
            half_angle: wire.half_angle,
            reference_radius: wire.reference_radius,
            angular_range: wire.angular_range,
            slant_range: wire.slant_range,
            angular_scale: wire.angular_scale,
            angular_domain: wire.angular_domain,
        })
    }
}

/// Payload-layout discriminator of a consolidated arc-length circle.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum CatiaCircleLayout {
    /// Identity packed in six bits (`0x32`).
    PackedSix,
    /// Identity packed in one byte (`0x33`).
    Byte,
    /// Identity packed in two bytes (`0x34`).
    Word,
}

impl From<CatiaCircleLayout> for u8 {
    fn from(value: CatiaCircleLayout) -> Self {
        match value {
            CatiaCircleLayout::PackedSix => 0x32,
            CatiaCircleLayout::Byte => 0x33,
            CatiaCircleLayout::Word => 0x34,
        }
    }
}

impl TryFrom<u8> for CatiaCircleLayout {
    type Error = String;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0x32 => Ok(Self::PackedSix),
            0x33 => Ok(Self::Byte),
            0x34 => Ok(Self::Word),
            other => Err(format!("layout {other:#x} is not 0x32..=0x34")),
        }
    }
}

/// One complete consolidated `B:19` arc-length circle support.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "CatiaConsolidatedCircleWire")]
pub(crate) struct CatiaConsolidatedCircle {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Payload-layout discriminator.
    layout: CatiaCircleLayout,
    /// Compact persistent record identity.
    record_id: u32,
    /// Width-coded frame token.
    frame_token: u8,
    /// Two centre coordinates in the host-implied carrier plane.
    pub(crate) center_pair: FiniteVector<2>,
    /// Circle radius in millimetres.
    radius: cadmpeg_ir::scalar::PositiveLength,
    /// Arc-length parameter interval.
    pub(crate) range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Length-valued angular chart shift.
    chart_shift: FiniteReal,
}

impl CatiaConsolidatedCircle {
    /// Whether the interval spans one complete circumference.
    fn full_circle(&self) -> bool {
        crate::families::b2::records::circle_range_is_full_turn(
            self.radius.get(),
            self.range.endpoints(),
        )
    }
}
#[derive(Serialize, Deserialize)]
struct CatiaConsolidatedCircleWire {
    id: String,
    byte_offset: u64,
    layout: CatiaCircleLayout,
    record_id: u32,
    frame_token: u8,
    center_pair: FiniteVector<2>,
    radius: cadmpeg_ir::scalar::PositiveLength,
    range: cadmpeg_ir::topology::IncreasingParameterInterval,
    full_circle: bool,
    chart_shift: FiniteReal,
}
impl TryFrom<CatiaConsolidatedCircleWire> for CatiaConsolidatedCircle {
    type Error = String;
    fn try_from(wire: CatiaConsolidatedCircleWire) -> Result<Self, Self::Error> {
        let circle = Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            layout: wire.layout,
            record_id: wire.record_id,
            frame_token: wire.frame_token,
            center_pair: wire.center_pair,
            radius: wire.radius,
            range: wire.range,
            chart_shift: wire.chart_shift,
        };
        if wire.full_circle != circle.full_circle() {
            return Err("full_circle does not match radius and range".into());
        }
        Ok(circle)
    }
}
#[cfg(test)]
impl From<CatiaConsolidatedCircle> for CatiaConsolidatedCircleWire {
    fn from(circle: CatiaConsolidatedCircle) -> Self {
        let full_circle = circle.full_circle();
        Self {
            full_circle,
            id: circle.id,
            byte_offset: circle.byte_offset,
            layout: circle.layout,
            record_id: circle.record_id,
            frame_token: circle.frame_token,
            center_pair: circle.center_pair,
            radius: circle.radius,
            range: circle.range,
            chart_shift: circle.chart_shift,
        }
    }
}

/// Frame-specific payload of one consolidated `B:28` cylinder chart.
#[derive(Debug, Clone, PartialEq)]
enum CatiaConsolidatedCylinderPayload {
    /// Complete three-dimensional frame reconstructed from layout `0x52`.
    Layout52 {
        /// Token selecting the serialized frame-vector role.
        frame_token: u8,
        /// Cylinder-axis unit direction.
        axis: crate::checked::RelaxedHypotUnitVector3,
        /// Unit direction from which the circumferential parameter is measured.
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
    },
    /// Complete three-dimensional frame reconstructed from layout `0x5a`.
    Layout5a {
        /// Token selecting the serialized frame-vector role.
        frame_token: u8,
        /// Cylinder-axis unit direction.
        axis: crate::checked::RelaxedHypotUnitVector3,
        /// Unit direction from which the circumferential parameter is measured.
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
    },
    /// Complete layout-`0x62` frame and its redundant range origin.
    RangeOrigin {
        /// Stored unit vector in the token-defined carrier plane.
        stored_vector: crate::checked::RelaxedUnitVector2,
        /// Cylinder-axis unit direction.
        axis: crate::checked::RelaxedHypotUnitVector3,
        /// Unit direction from which the circumferential parameter is measured.
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
        /// Origin of the stored partial circumferential interval.
        range_origin: f64,
    },
}

impl CatiaConsolidatedCylinderPayload {
    const fn layout(&self) -> u8 {
        match self {
            Self::Layout52 { .. } => 0x52,
            Self::Layout5a { .. } => 0x5a,
            Self::RangeOrigin { .. } => 0x62,
        }
    }

    fn resolved_5a(
        radius: cadmpeg_ir::scalar::PositiveLength,
        u_range: cadmpeg_ir::topology::IncreasingParameterInterval,
        frame_token: u8,
        axis: crate::checked::RelaxedHypotUnitVector3,
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
    ) -> Result<Self, String> {
        let direction = axis.get();
        if !matches!(frame_token, 0x19 | 0x1c)
            || direction[2] != 0.0
            || reference_direction.get() != [-direction[1], direction[0], 0.0]
            || !crate::families::b2::records::circle_range_is_full_turn(
                radius.get(),
                u_range.endpoints(),
            )
        {
            return Err("invalid layout-0x5a cylinder chart".to_owned());
        }
        Ok(Self::Layout5a {
            frame_token,
            axis,
            reference_direction,
        })
    }
}

/// One structurally complete consolidated `B:28` cylinder chart.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "CatiaConsolidatedCylinderWire")]
pub(crate) struct CatiaConsolidatedCylinder {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    header: crate::wire::records::WidthCodedToken,
    /// Cylinder-axis origin.
    origin: FiniteVector<3>,
    /// Cylinder radius.
    radius: cadmpeg_ir::scalar::PositiveLength,
    /// Arc-length circumferential interval.
    u_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Axial interval.
    v_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Layout-specific frame data.
    payload: CatiaConsolidatedCylinderPayload,
}

#[derive(Serialize, Deserialize)]
struct CatiaConsolidatedCylinderWire {
    id: String,
    byte_offset: u64,
    header: crate::wire::records::WidthCodedToken,
    layout: u8,
    origin: FiniteVector<3>,
    radius: cadmpeg_ir::scalar::PositiveLength,
    u_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    v_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    payload: CatiaConsolidatedCylinderPayloadWire,
}

#[derive(Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum CatiaConsolidatedCylinderPayloadWire {
    Resolved {
        frame_token: u8,
        axis: crate::checked::RelaxedHypotUnitVector3,
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
    },
    RangeOrigin {
        stored_vector: crate::checked::RelaxedUnitVector2,
        axis: crate::checked::RelaxedHypotUnitVector3,
        reference_direction: crate::checked::RelaxedHypotUnitVector3,
        range_origin: f64,
    },
}

#[cfg(test)]
impl From<CatiaConsolidatedCylinder> for CatiaConsolidatedCylinderWire {
    fn from(value: CatiaConsolidatedCylinder) -> Self {
        let layout = value.payload.layout();
        let payload = match value.payload {
            CatiaConsolidatedCylinderPayload::Layout52 {
                frame_token,
                axis,
                reference_direction,
            }
            | CatiaConsolidatedCylinderPayload::Layout5a {
                frame_token,
                axis,
                reference_direction,
            } => CatiaConsolidatedCylinderPayloadWire::Resolved {
                frame_token,
                axis,
                reference_direction,
            },
            CatiaConsolidatedCylinderPayload::RangeOrigin {
                stored_vector,
                axis,
                reference_direction,
                range_origin,
            } => CatiaConsolidatedCylinderPayloadWire::RangeOrigin {
                stored_vector,
                axis,
                reference_direction,
                range_origin,
            },
        };
        Self {
            id: value.id,
            byte_offset: value.byte_offset,
            header: value.header,
            layout,
            origin: value.origin,
            radius: value.radius,
            u_range: value.u_range,
            v_range: value.v_range,
            payload,
        }
    }
}

impl TryFrom<CatiaConsolidatedCylinderWire> for CatiaConsolidatedCylinder {
    type Error = String;

    fn try_from(wire: CatiaConsolidatedCylinderWire) -> Result<Self, Self::Error> {
        let payload = match (wire.layout, wire.payload) {
            (
                0x52,
                CatiaConsolidatedCylinderPayloadWire::Resolved {
                    frame_token,
                    axis,
                    reference_direction,
                },
            ) => {
                if frame_token != 0x1d
                    || axis.get() != [1.0, 0.0, 0.0]
                    || reference_direction.get() != [0.0, 1.0, 0.0]
                    || !crate::families::b2::records::circle_range_is_full_turn(
                        wire.radius.get(),
                        wire.u_range.endpoints(),
                    )
                {
                    return Err("invalid layout-0x52 cylinder chart".to_owned());
                }
                CatiaConsolidatedCylinderPayload::Layout52 {
                    frame_token,
                    axis,
                    reference_direction,
                }
            }
            (
                0x5a,
                CatiaConsolidatedCylinderPayloadWire::Resolved {
                    frame_token,
                    axis,
                    reference_direction,
                },
            ) => CatiaConsolidatedCylinderPayload::resolved_5a(
                wire.radius,
                wire.u_range,
                frame_token,
                axis,
                reference_direction,
            )?,
            (
                0x62,
                CatiaConsolidatedCylinderPayloadWire::RangeOrigin {
                    stored_vector,
                    axis,
                    reference_direction,
                    range_origin,
                },
            ) => {
                let vector = stored_vector.get();
                if axis.get() != [0.0, 1.0, 0.0]
                    || reference_direction.get() != [vector[0], 0.0, vector[1]]
                    || !crate::families::b2::records::circle_range_is_within_full_turn(
                        wire.radius.get(),
                        wire.u_range.endpoints(),
                    )
                    || !range_origin.is_finite()
                    || range_origin.to_bits()
                        != crate::families::b2::records::cylinder_range_origin(
                            wire.radius.get(),
                            wire.u_range.endpoints(),
                        )
                        .to_bits()
                {
                    return Err("invalid layout-0x62 cylinder chart".to_owned());
                }
                CatiaConsolidatedCylinderPayload::RangeOrigin {
                    stored_vector,
                    axis,
                    reference_direction,
                    range_origin,
                }
            }
            (layout, _) => {
                return Err(format!(
                    "cylinder layout {layout:#04x} does not match payload"
                ));
            }
        };
        Ok(Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            header: wire.header,
            origin: wire.origin,
            radius: wire.radius,
            u_range: wire.u_range,
            v_range: wire.v_range,
            payload,
        })
    }
}

/// One complete consolidated `B:18` parameter-space record.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "CatiaConsolidatedParameterPointWire")]
pub(crate) struct CatiaConsolidatedParameterPoint {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Complete framed-record length.
    byte_len: u64,
    /// Source-local representation operand with its compact encoding.
    operand: crate::wire::compact_unsigned::CompactUnsigned,
    /// Scalar control immediately following the operand.
    control: u8,
    /// Layout-specific finite scalar lane.
    payload: B2ParameterPointPayload,
}

#[derive(Serialize, Deserialize)]
struct CatiaConsolidatedParameterPointWire {
    id: String,
    byte_offset: u64,
    byte_len: u64,
    operand: crate::wire::compact_unsigned::CompactUnsigned,
    control: u8,
    payload: B2ParameterPointPayload,
}

#[cfg(test)]
impl From<CatiaConsolidatedParameterPoint> for CatiaConsolidatedParameterPointWire {
    fn from(value: CatiaConsolidatedParameterPoint) -> Self {
        Self {
            id: value.id,
            byte_offset: value.byte_offset,
            byte_len: value.byte_len,
            operand: value.operand,
            control: value.control,
            payload: value.payload,
        }
    }
}

impl TryFrom<CatiaConsolidatedParameterPointWire> for CatiaConsolidatedParameterPoint {
    type Error = String;

    fn try_from(wire: CatiaConsolidatedParameterPointWire) -> Result<Self, Self::Error> {
        let overhead = wire
            .byte_len
            .checked_sub(u64::from(wire.payload.byte_len(wire.operand)));
        if !matches!(overhead, Some(5..=7)) || !wire.payload.matches_control(wire.control) {
            return Err("parameter-point frame length or control does not match payload".into());
        }
        Ok(Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            byte_len: wire.byte_len,
            operand: wire.operand,
            control: wire.control,
            payload: wire.payload,
        })
    }
}

/// One complete consolidated `B:27` plane-carrier record.
#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(try_from = "CatiaConsolidatedPlaneCarrierWire")]
pub(crate) struct CatiaConsolidatedPlaneCarrier {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Complete framed-record length.
    byte_len: u64,
    /// Header-token width in bytes.
    width: ConsolidatedFrameWidth,
    /// Independent frame flag.
    flag: ConsolidatedFrameFlag,
    /// Width-coded frame header token.
    header_token: u32,
    /// Selector-specific finite scalar payload.
    payload: crate::families::b2::records::B2PlaneCarrierPayload,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct CatiaConsolidatedPlaneCarrierWire {
    id: String,
    byte_offset: u64,
    byte_len: u64,
    width: ConsolidatedFrameWidth,
    flag: ConsolidatedFrameFlag,
    header_token: u32,
    selector: u8,
    payload: crate::families::b2::records::B2PlaneCarrierPayload,
}

#[cfg(test)]
impl From<CatiaConsolidatedPlaneCarrier> for CatiaConsolidatedPlaneCarrierWire {
    fn from(value: CatiaConsolidatedPlaneCarrier) -> Self {
        Self {
            id: value.id,
            byte_offset: value.byte_offset,
            byte_len: value.byte_len,
            width: value.width,
            flag: value.flag,
            header_token: value.header_token,
            selector: value.payload.selector(),
            payload: value.payload,
        }
    }
}

impl TryFrom<CatiaConsolidatedPlaneCarrierWire> for CatiaConsolidatedPlaneCarrier {
    type Error = String;

    fn try_from(mut wire: CatiaConsolidatedPlaneCarrierWire) -> Result<Self, Self::Error> {
        if let crate::families::b2::records::B2PlaneCarrierPayload::ScalarLane {
            selector, ..
        } = &mut wire.payload
        {
            *selector = wire.selector;
            if crate::families::b2::records::B2PlaneCarrierLayout::try_from(*selector).is_ok() {
                return Err("known plane selector requires a plane payload".to_owned());
            }
        } else if wire.payload.selector() != wire.selector {
            return Err(format!(
                "plane-carrier selector {:#04x} does not match payload",
                wire.selector
            ));
        }
        if matches!(
            wire.payload,
            crate::families::b2::records::B2PlaneCarrierPayload::Plane { .. }
        ) && !wire.payload.valid_plane()
        {
            return Err("plane direction does not match its scalar layout".to_owned());
        }
        Ok(Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            byte_len: wire.byte_len,
            width: wire.width,
            flag: wire.flag,
            header_token: wire.header_token,
            payload: wire.payload,
        })
    }
}

/// One complete consolidated `B:37` persistent-reference list.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedReferenceList {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Compact persistent identities in serialization order.
    references: Vec<u32>,
}

/// One structurally complete consolidated `A/B:20` pcurve jet whose support
/// identity has not necessarily been resolved to a native surface record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedPcurve {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Consolidated framing family.
    family: CatiaConsolidatedFamily,
    /// Absolute persistent support-surface identity.
    support_id: u32,
    /// Parametric curve degree.
    degree: u32,
    /// Number of leading extrapolation sites.
    extrapolation_sites: u32,
    /// Native parameter sites; the decoder stores them strictly increasing.
    knots: Vec<FiniteReal>,
    /// Surface-chart positions at the parameter sites.
    points: Vec<FiniteVector<2>>,
    /// First derivatives at the parameter sites.
    first_derivatives: Vec<FiniteVector<2>>,
    /// Second derivatives at the parameter sites.
    second_derivatives: Vec<FiniteVector<2>>,
    /// Native evaluation interval.
    range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Bytes following the evaluation interval in the framed payload.
    tail: NativeBytes<Vec<u8>>,
}

/// One source-closed five-reference rolling-ball construction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedRollingBallConstruction {
    id: String,
    byte_offset: u64,
    source_index: u64,
    carrier_byte_offset: u64,
    support_surface_byte_offsets: [u64; 2],
    support_pcurve_byte_offsets: [u64; 2],
    construction_radius: cadmpeg_ir::scalar::PositiveLength,
}

/// One structurally complete consolidated `B:2a` sphere chart.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedSphere {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Sphere centre.
    center: FiniteVector<3>,
    /// First transverse unit direction.
    direction_x: crate::checked::ExactHypotUnitVector3,
    /// Second transverse unit direction.
    direction_y: crate::checked::ExactHypotUnitVector3,
    /// Sphere-axis unit direction.
    axis: crate::checked::ExactHypotUnitVector3,
    /// Sphere radius.
    radius: cadmpeg_ir::scalar::PositiveLength,
    /// Active azimuth interval.
    azimuth_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Active latitude interval.
    latitude_range: cadmpeg_ir::topology::IncreasingParameterInterval,
}

/// One structurally complete consolidated `B:2b` torus chart.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedTorus {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Torus centre.
    center: FiniteVector<3>,
    /// First transverse unit direction.
    direction_x: crate::checked::ExactUnitVector3,
    /// Second transverse unit direction.
    direction_y: crate::checked::ExactUnitVector3,
    /// Torus-axis unit direction.
    axis: crate::checked::ExactUnitVector3,
    /// Major radius.
    major_radius: cadmpeg_ir::scalar::PositiveLength,
    /// Minor radius.
    minor_radius: cadmpeg_ir::scalar::PositiveLength,
    /// Active major-angle interval.
    major_angular_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Full-turn major-angle chart domain.
    major_angular_domain: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Active minor-angle interval.
    minor_angular_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Full-turn minor-angle chart domain.
    minor_angular_domain: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Scale from major angle to stored U parameter.
    major_scale: cadmpeg_ir::scalar::PositiveReal,
    /// Scale from minor angle to stored V parameter.
    minor_scale: cadmpeg_ir::scalar::PositiveReal,
}

/// One exact consolidated B-family metric line profile.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedLineProfile {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Stored line origin.
    origin: FiniteVector<3>,
    /// Unit line direction.
    direction: crate::checked::ExactUnitVector3,
    /// Increasing stored parameter interval.
    range: cadmpeg_ir::topology::IncreasingParameterInterval,
}

/// Reference-token dialect of a consolidated surface of revolution.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "u8", into = "u8")]
pub(crate) enum CatiaRevolutionReferenceToken {
    /// Reference lead `0x08` followed by a two-byte value.
    Lead08,
    /// Reference lead `0x0a` followed by a two-byte value.
    Lead0a,
}

impl From<CatiaRevolutionReferenceToken> for u8 {
    fn from(value: CatiaRevolutionReferenceToken) -> Self {
        match value {
            CatiaRevolutionReferenceToken::Lead08 => 0x08,
            CatiaRevolutionReferenceToken::Lead0a => 0x0a,
        }
    }
}

impl TryFrom<u8> for CatiaRevolutionReferenceToken {
    type Error = String;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0x08 => Ok(Self::Lead08),
            0x0a => Ok(Self::Lead0a),
            other => Err(format!("reference_token {other:#x} is not 0x08 or 0x0a")),
        }
    }
}

/// One structurally complete consolidated `B:2d` surface-of-revolution record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct CatiaConsolidatedRevolution {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// Reference-token dialect.
    reference_token: CatiaRevolutionReferenceToken,
    /// Stored nonzero profile reference; its namespace is unresolved.
    profile_reference: u16,
    /// Axis-frame origin.
    origin: FiniteVector<3>,
    /// First transverse unit direction.
    direction_x: crate::checked::ExactUnitVector3,
    /// Second transverse unit direction.
    direction_y: crate::checked::ExactUnitVector3,
    /// Revolution-axis unit direction.
    axis: crate::checked::ExactUnitVector3,
    /// Stored full-turn angular parameter interval.
    angular_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Stored profile parameter interval.
    profile_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Unique consolidated circle with the same stored profile interval.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    profile_circle: Option<String>,
    /// Positive scale from revolution angle to stored angular parameter.
    angular_scale: cadmpeg_ir::scalar::PositiveReal,
}

/// One complete consolidated historical edge run referencing two retained
/// pcurve records.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedEdgeRun {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the first pcurve frame.
    byte_offset: u64,
    /// Retained pcurve identities in serialized side order.
    pcurves: [String; 2],
    /// Shared native parameter interval.
    parameter_range: cadmpeg_ir::topology::IncreasingParameterInterval,
    /// Shared geometric tolerance.
    tolerance: FiniteReal,
    /// Exact terminal edge node.
    node: String,
    /// Uniquely resolved support carrier for each pcurve side.
    #[serde(default)]
    pub(crate) support_bindings: [Option<CatiaConsolidatedSupportBinding>; 2],
    /// Index-aligned 3D loci shared by every resolved support side.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) shared_loci: Option<Vec<[f64; 3]>>,
    /// First and last shared loci in endpoint pair direction.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) endpoint_loci: Option<[[f64; 3]; 2]>,
}

/// Wire addressing form of one width-coded allocation reference.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaAllocationReferenceEncoding {
    /// `4n+1` backward framed-record distance.
    BackwardDistance,
    /// `4n+3` zero-based ordinal in the immediately owned allocation.
    OwnedChild,
    /// `4w` followed by a `w`-byte little-endian value.
    WidthCoded,
    /// Untagged `4n+2` selector form.
    Selector2,
    /// `06 <u8>`.
    TaggedU8,
    /// `0a <u16le>`.
    TaggedU16,
}

/// Wire addressing form of one fixed-nine owner identity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaOwnerIdentityEncoding {
    /// One token from the allocation-reference grammar.
    Allocation(CatiaAllocationReferenceEncoding),
    /// Raw one-byte weak identity in the width-coded alternating dialect.
    RawU8,
}

impl From<crate::families::b2::records::B2OwnerIdentityEncoding> for CatiaOwnerIdentityEncoding {
    fn from(value: crate::families::b2::records::B2OwnerIdentityEncoding) -> Self {
        match value {
            crate::families::b2::records::B2OwnerIdentityEncoding::Allocation(encoding) => {
                Self::Allocation(projection::native_allocation_reference_encoding(encoding))
            }
            crate::families::b2::records::B2OwnerIdentityEncoding::RawU8 => Self::RawU8,
        }
    }
}

/// Typed class-`0x18` descriptor bound to a class-`0x25` edge definition.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedClass25Descriptor {
    /// Record byte offset.
    byte_offset: u64,
    /// Width-coded allocation identity.
    record_id: u32,
    /// Descriptor control byte.
    pub(crate) control: u8,
    /// Complete finite scalar lane.
    values: Vec<FiniteReal>,
}

/// Descriptor and circle relation structurally bound to an analytic edge.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedAnalyticCircleBinding {
    /// Exact class-`0x18` descriptor frame.
    descriptor: crate::wire::records::ConsolidatedRawFrame<u64>,
    /// Referenced consolidated circle support.
    pub(crate) circle: String,
}

/// Exact oriented-use allocation chain owned by one consolidated edge node.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(
    try_from = "CatiaConsolidatedEdgeUsesWire",
    into = "CatiaConsolidatedEdgeUsesWire"
)]
struct CatiaConsolidatedEdgeUses {
    /// Counted allocation-reference vectors in side order.
    references: [[u32; 2]; 2],
}

#[derive(Serialize, Deserialize)]
struct CatiaConsolidatedEdgeUsesWire {
    references: [[u32; 2]; 2],
    senses: NativeBytes<[u8; 2]>,
}

impl From<CatiaConsolidatedEdgeUses> for CatiaConsolidatedEdgeUsesWire {
    fn from(value: CatiaConsolidatedEdgeUses) -> Self {
        Self {
            references: value.references,
            senses: ([0x88, 0x84]).into(),
        }
    }
}

impl TryFrom<CatiaConsolidatedEdgeUsesWire> for CatiaConsolidatedEdgeUses {
    type Error = String;

    fn try_from(wire: CatiaConsolidatedEdgeUsesWire) -> Result<Self, Self::Error> {
        if wire.senses != [0x88, 0x84] {
            return Err("consolidated edge uses require senses [0x88, 0x84]".to_owned());
        }
        Ok(Self {
            references: wire.references,
        })
    }
}

/// One endpoint identity retained by consolidated topology edge nodes.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaConsolidatedVertexIdentity {
    /// Stable native-record identity assigned in first-incidence order.
    id: String,
    /// First raw endpoint-address operand associated with this identity.
    identity: u32,
    /// Bounded record source that owns this identity namespace.
    source_index: usize,
    /// Resolved structural endpoint record, when available.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    endpoint_record: Option<u64>,
    /// Raw endpoint-address operands associated with this identity.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    reference_values: Vec<u32>,
    /// Compact allocation scope for the identity.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    allocation_owner: Option<String>,
    /// Incident consolidated edge nodes in source order.
    incident_edge_nodes: Vec<String>,
}

/// Exact carrier selected for one side of a consolidated historical edge.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "kind")]
pub(crate) enum CatiaConsolidatedSupportBinding {
    /// Standalone `b2 03 28` cylinder.
    Cylinder {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// Arc-length `b2 03 19` circle.
    Circle {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// `b2 03 29` cone.
    Cone {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// `b2 03 2a` sphere.
    Sphere {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// Doubly periodic `b2 03 2b` torus.
    Torus {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// Direction-bearing consolidated `b2/b3/b4 03 27` plane carrier.
    Plane {
        /// Carrier record byte offset.
        byte_offset: u64,
    },
    /// Consolidated NURBS carrier with an optional constant normal offset.
    NurbsCarrier {
        /// Carrier record byte offset.
        byte_offset: u64,
        /// Signed normal offset in millimetres.
        offset: FiniteReal,
    },
}

/// One complete outer FINJPL segment retained with its framing identity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaFinjplSegment {
    /// Globally unique segment identity.
    pub(crate) id: String,
    /// FINJPL marker offset in the complete file.
    pub(crate) byte_offset: u64,
    /// Complete segment byte length.
    pub(crate) byte_len: u64,
    /// Big-endian segment type word.
    type_word: u32,
    /// Structural type family.
    family: String,
    /// Stored primary name, when the printable-ASCII name form is present.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    name: Option<String>,
    /// Complete segment bytes from marker through the byte before the next segment.
    data: NativeBytes<Vec<u8>>,
}

/// One external CATIA document selected by a storage-property record.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaExternalReference {
    /// Globally unique reference identity.
    id: String,
    /// File offset of the length-prefixed target string.
    pub(crate) byte_offset: u64,
    /// Referenced CATIA document name or path.
    pub(crate) target: String,
    /// Containing project-flags FINJPL segment.
    pub(crate) segment: String,
}

/// One exact JPEG preview from the outer summary-information segment.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaPreviewImage {
    /// Globally unique preview identity.
    id: String,
    /// JPEG SOI byte offset in the complete file.
    byte_offset: u64,
    /// Exact encoded length through JPEG EOI.
    byte_len: u64,
    /// Pixel width from the JPEG start-of-frame segment.
    width: u16,
    /// Pixel height from the JPEG start-of-frame segment.
    height: u16,
    /// JPEG component count.
    components: u8,
    /// Exact JPEG byte stream.
    data: NativeBytes<Vec<u8>>,
}

/// One exact outer `01 00 04 00` alias-row core.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(try_from = "CatiaAliasRowWire")]
pub(crate) struct CatiaAliasRow {
    /// Globally unique alias-row identity.
    id: String,
    /// Byte offset of the four-byte alias marker.
    byte_offset: u64,
    /// Complete preceding four-byte word.
    lead_raw: u32,
    /// Complete stored tag word.
    tag_raw: u32,
    /// Single-byte row flag.
    flag: u8,
    /// Complete three-byte F1 field.
    f1: NativeBytes<[u8; 3]>,
    /// Primary object graph selected by the valid F1 ordinal.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    object_graph: Option<String>,
    /// One-based F1 ordinal resolved to its exact `7C09` record.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    object_record: Option<String>,
    /// Design object owning the selected record.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    design_object: Option<String>,
    /// First trailing fixed-width field.
    f2: u32,
    /// Second trailing fixed-width field.
    f3: u32,
    /// Group-allocation header immediately preceding this alias core.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    group: Option<AliasGroupMembership>,
    /// Canonical persistent surface-roster tag selected by this alias row.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    canonical_surface_tag: Option<u32>,
}

impl CatiaAliasRow {
    /// Classification of the stored alias lead word.
    fn lead(&self) -> AliasLead {
        AliasLead::from_raw(self.lead_raw)
    }
    /// Low 24 bits of the stored tag word.
    fn tag(&self) -> u32 {
        self.tag_raw & 0x00ff_ffff
    }
    /// Entity-table ordinal from the F1 field.
    fn entity_record_ordinal(&self) -> u8 {
        self.f1[2]
    }

    /// Byte offset of the 24-byte row frame.
    ///
    /// `byte_offset` names the four-byte marker, which sits at
    /// `outer_alias_row::MARKER` inside the row. A marker inside the first
    /// `MARKER` bytes of the image has no row frame, so this answers `None`
    /// instead of aliasing the frame with the head of the file.
    fn row_byte_offset(&self) -> Option<u64> {
        self.byte_offset
            .checked_sub(u64_from_index(crate::layout::outer_alias_row::MARKER))
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaAliasRowWire {
    id: String,
    byte_offset: u64,
    lead: AliasLead,
    lead_raw: u32,
    tag: u32,
    tag_raw: u32,
    flag: u8,
    f1: NativeBytes<[u8; 3]>,
    entity_record_ordinal: u8,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    object_graph: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    object_record: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    design_object: Option<String>,
    f2: u32,
    f3: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    group: Option<AliasGroupMembership>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    canonical_surface_tag: Option<u32>,
}

#[derive(Serialize)]
struct CatiaAliasRowWireRef<'a> {
    id: &'a str,
    byte_offset: u64,
    lead: AliasLead,
    lead_raw: u32,
    tag: u32,
    tag_raw: u32,
    flag: u8,
    f1: NativeBytes<[u8; 3]>,
    entity_record_ordinal: u8,
    #[serde(skip_serializing_if = "Option::is_none")]
    object_graph: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    object_record: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    design_object: Option<&'a str>,
    f2: u32,
    f3: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    group: &'a Option<AliasGroupMembership>,
    #[serde(skip_serializing_if = "Option::is_none")]
    canonical_surface_tag: Option<u32>,
}

impl Serialize for CatiaAliasRow {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        CatiaAliasRowWireRef {
            id: &self.id,
            byte_offset: self.byte_offset,
            lead: self.lead(),
            lead_raw: self.lead_raw,
            tag: self.tag(),
            tag_raw: self.tag_raw,
            flag: self.flag,
            f1: (self.f1),
            entity_record_ordinal: self.entity_record_ordinal(),
            object_graph: self.object_graph.as_deref(),
            object_record: self.object_record.as_deref(),
            design_object: self.design_object.as_deref(),
            f2: self.f2,
            f3: self.f3,
            group: &self.group,
            canonical_surface_tag: self.canonical_surface_tag,
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaAliasRow> for CatiaAliasRowWire {
    fn from(value: CatiaAliasRow) -> Self {
        Self {
            lead: value.lead(),
            tag: value.tag(),
            entity_record_ordinal: value.entity_record_ordinal(),
            id: value.id,
            byte_offset: value.byte_offset,
            lead_raw: value.lead_raw,
            tag_raw: value.tag_raw,
            flag: value.flag,
            f1: (value.f1),
            object_graph: value.object_graph,
            object_record: value.object_record,
            design_object: value.design_object,
            f2: value.f2,
            f3: value.f3,
            group: value.group,
            canonical_surface_tag: value.canonical_surface_tag,
        }
    }
}

impl TryFrom<CatiaAliasRowWire> for CatiaAliasRow {
    type Error = &'static str;
    fn try_from(wire: CatiaAliasRowWire) -> Result<Self, Self::Error> {
        if wire.lead != AliasLead::from_raw(wire.lead_raw) {
            return Err("lead disagrees with source bytes");
        }
        if wire.tag != wire.tag_raw & 0x00ff_ffff {
            return Err("tag disagrees with source bytes");
        }
        if wire.entity_record_ordinal != wire.f1[2] {
            return Err("entity_record_ordinal disagrees with source bytes");
        }
        if wire.byte_offset < u64_from_index(crate::layout::outer_alias_row::MARKER) {
            return Err("byte_offset places the alias marker before its row frame");
        }
        Ok(Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            lead_raw: wire.lead_raw,
            tag_raw: wire.tag_raw,
            flag: wire.flag,
            f1: (wire.f1),
            object_graph: wire.object_graph,
            object_record: wire.object_record,
            design_object: wire.design_object,
            f2: wire.f2,
            f3: wire.f3,
            group: wire.group,
            canonical_surface_tag: wire.canonical_surface_tag,
        })
    }
}

/// One exact `7C0B` value block adjacent to its source-schema catalog.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "CatiaValueBlockWire", into = "CatiaValueBlockWire")]
pub(crate) struct CatiaValueBlock {
    /// Globally unique value-block identity.
    pub(crate) id: String,
    /// Byte offset of the `7C0B` marker.
    pub(crate) byte_offset: u64,
    /// Object graph ending exactly where this value block begins.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) object_graph: Option<String>,
    /// Source-schema catalog that begins immediately after this block.
    pub(crate) catalog: String,
    /// Value payload in serialized order.
    pub(crate) payload: Vec<u8>,
    /// Schema selectors in payload order, resolved against the adjacent catalog.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) schema_selections: Vec<CatiaValueSchemaSelection>,
}

impl CatiaValueBlock {
    fn declared_len(&self) -> u64 {
        u64_from_index(self.payload.len()) + u64_from_index(crate::layout::value_block_7c0b::LEN)
    }

    fn byte_len(&self) -> u64 {
        self.declared_len() + 1
    }

    pub(crate) fn fields(&self) -> Vec<value_block::ValueField> {
        value_block::tokenize(&self.payload)
    }
}

// Compatibility fields are derived on output and checked once on input.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
struct CatiaValueBlockWire {
    /// Globally unique value-block identity.
    id: String,
    /// Byte offset of the `7C0B` marker.
    byte_offset: u64,
    /// Complete framed extent including the trailing terminator.
    byte_len: u64,
    /// Stored length from the marker through the byte before the terminator.
    declared_len: u64,
    /// Object graph ending exactly where this value block begins.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    object_graph: Option<String>,
    /// Source-schema catalog that begins immediately after this block.
    catalog: String,
    /// Value payload in serialized order.
    payload: NativeBytes<Vec<u8>>,
    /// Lossless typed fields in payload order.
    #[serde(default)]
    fields: Vec<value_block::ValueField>,
    /// Schema selectors in payload order, resolved against the adjacent catalog.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    schema_selections: Vec<CatiaValueSchemaSelection>,
}

impl From<CatiaValueBlock> for CatiaValueBlockWire {
    fn from(block: CatiaValueBlock) -> Self {
        Self {
            byte_len: block.byte_len(),
            declared_len: block.declared_len(),
            fields: block.fields(),
            id: block.id,
            byte_offset: block.byte_offset,
            object_graph: block.object_graph,
            catalog: block.catalog,
            payload: (block.payload).into(),
            schema_selections: block.schema_selections,
        }
    }
}

impl TryFrom<CatiaValueBlockWire> for CatiaValueBlock {
    type Error = &'static str;

    fn try_from(wire: CatiaValueBlockWire) -> Result<Self, Self::Error> {
        let block = Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            object_graph: wire.object_graph,
            catalog: wire.catalog,
            payload: wire.payload.into_inner(),
            schema_selections: wire.schema_selections,
        };
        if wire.byte_len != block.byte_len()
            || wire.declared_len != block.declared_len()
            || wire.fields != block.fields()
        {
            return Err("value block lengths or fields disagree with payload");
        }
        Ok(block)
    }
}

/// Catalog class and encoded payload of a selected value-block schema selector.
#[derive(Debug, Clone, PartialEq, Eq)]
struct CatiaValueSchemaSelectionValue {
    /// Selected catalog class.
    class: CatiaDesignClass,
    /// Complete encoded value after this selector and before the next selector.
    encoded_value: Vec<value_block::ValueField>,
}

/// One `0x32` selector from a value block.
#[derive(Debug, Clone, PartialEq, Eq)]
enum CatiaValueSchemaSelectionKind {
    /// Catalog class selected by the stored ordinal.
    Selected(CatiaValueSchemaSelectionValue),
    /// Terminal absent-schema sentinel.
    Terminal,
}

/// One `0x32` selector from a value block.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(try_from = "CatiaValueSchemaSelectionWire")]
pub(crate) struct CatiaValueSchemaSelection {
    /// Globally unique schema-selection identity.
    id: String,
    /// Containing [`CatiaValueBlock`] identity.
    parent: String,
    /// Byte offset within the value payload.
    offset: u64,
    /// Stored zero-based ordinal or terminal absent-schema sentinel.
    ordinal: u32,
    /// Selected class or terminal sentinel.
    kind: CatiaValueSchemaSelectionKind,
}

impl CatiaValueSchemaSelection {
    #[cfg(test)]
    fn entry(&self) -> Option<&str> {
        match &self.kind {
            CatiaValueSchemaSelectionKind::Selected(value) => Some(value.class.entry.as_str()),
            CatiaValueSchemaSelectionKind::Terminal => None,
        }
    }

    #[cfg(test)]
    fn name(&self) -> Option<&str> {
        match &self.kind {
            CatiaValueSchemaSelectionKind::Selected(value) => Some(value.class.name.as_str()),
            CatiaValueSchemaSelectionKind::Terminal => None,
        }
    }

    #[cfg(test)]
    fn encoded_value(&self) -> &[value_block::ValueField] {
        match &self.kind {
            CatiaValueSchemaSelectionKind::Selected(value) => &value.encoded_value,
            CatiaValueSchemaSelectionKind::Terminal => &[],
        }
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaValueSchemaSelectionWire {
    id: String,
    parent: String,
    offset: u64,
    ordinal: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entry: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    name: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    encoded_value: Vec<value_block::ValueField>,
}

#[derive(Serialize)]
struct CatiaValueSchemaSelectionWireRef<'a> {
    id: &'a str,
    parent: &'a str,
    offset: u64,
    ordinal: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    entry: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    name: Option<&'a str>,
    #[serde(skip_serializing_if = "slice_is_empty")]
    encoded_value: &'a [value_block::ValueField],
}

impl Serialize for CatiaValueSchemaSelection {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let (entry, name, encoded_value) = match &self.kind {
            CatiaValueSchemaSelectionKind::Selected(value) => (
                Some(value.class.entry.as_str()),
                Some(value.class.name.as_str()),
                value.encoded_value.as_slice(),
            ),
            CatiaValueSchemaSelectionKind::Terminal => (None, None, &[][..]),
        };
        CatiaValueSchemaSelectionWireRef {
            id: &self.id,
            parent: &self.parent,
            offset: self.offset,
            ordinal: self.ordinal,
            entry,
            name,
            encoded_value,
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaValueSchemaSelection> for CatiaValueSchemaSelectionWire {
    fn from(value: CatiaValueSchemaSelection) -> Self {
        let (entry, name, encoded_value) = match value.kind {
            CatiaValueSchemaSelectionKind::Selected(selected) => (
                Some(selected.class.entry),
                Some(selected.class.name),
                selected.encoded_value,
            ),
            CatiaValueSchemaSelectionKind::Terminal => (None, None, Vec::new()),
        };
        Self {
            id: value.id,
            parent: value.parent,
            offset: value.offset,
            ordinal: value.ordinal,
            entry,
            name,
            encoded_value,
        }
    }
}

impl TryFrom<CatiaValueSchemaSelectionWire> for CatiaValueSchemaSelection {
    type Error = String;

    fn try_from(wire: CatiaValueSchemaSelectionWire) -> Result<Self, Self::Error> {
        let kind = match (wire.entry, wire.name) {
            (None, None) => {
                if !wire.encoded_value.is_empty() {
                    return Err(
                        "value schema terminal sentinel cannot carry an encoded value".to_owned(),
                    );
                }
                CatiaValueSchemaSelectionKind::Terminal
            }
            (Some(entry), Some(name)) => {
                CatiaValueSchemaSelectionKind::Selected(CatiaValueSchemaSelectionValue {
                    class: CatiaDesignClass { entry, name },
                    encoded_value: wire.encoded_value,
                })
            }
            _ => {
                return Err(
                    "value schema selection entry and name must both be present or both absent"
                        .to_owned(),
                );
            }
        };
        Ok(Self {
            id: wire.id,
            parent: wire.parent,
            offset: wire.offset,
            ordinal: wire.ordinal,
            kind,
        })
    }
}

/// One exact `7C02` source-schema catalog.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(from = "CatiaCatalogWire", into = "CatiaCatalogWire")]
pub(crate) struct CatiaCatalog {
    /// Globally unique catalog identity.
    pub(crate) id: String,
    /// Byte offset of the `7C02` marker.
    byte_offset: u64,
    /// Total framed byte length.
    byte_len: u64,
    /// Catalog entries in serialized order.
    #[serde(default)]
    pub(crate) entries: Vec<CatiaCatalogEntry>,
}

// The stored header carries no entries until the entry arena is joined.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
struct CatiaCatalogWire {
    /// Globally unique catalog identity.
    id: String,
    /// Byte offset of the `7C02` marker.
    byte_offset: u64,
    /// Total framed byte length.
    byte_len: u64,
    /// Catalog entries in serialized order.
    #[serde(default)]
    entries: Vec<CatiaCatalogEntry>,
}

impl CatiaCatalogWire {
    fn header(catalog: &CatiaCatalog) -> Self {
        Self {
            id: catalog.id.clone(),
            byte_offset: catalog.byte_offset,
            byte_len: catalog.byte_len,
            entries: Vec::new(),
        }
    }
}

impl From<CatiaCatalog> for CatiaCatalogWire {
    fn from(catalog: CatiaCatalog) -> Self {
        Self {
            id: catalog.id,
            byte_offset: catalog.byte_offset,
            byte_len: catalog.byte_len,
            entries: catalog.entries,
        }
    }
}

impl From<CatiaCatalogWire> for CatiaCatalog {
    fn from(wire: CatiaCatalogWire) -> Self {
        Self {
            id: wire.id,
            byte_offset: wire.byte_offset,
            byte_len: wire.byte_len,
            entries: wire.entries,
        }
    }
}

/// One source-schema name from a [`CatiaCatalog`].
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaCatalogEntry {
    /// Globally unique catalog-entry identity.
    pub(crate) id: String,
    /// Containing [`CatiaCatalog`] identity.
    parent: String,
    /// Stable serialized order within the catalog.
    pub(crate) ordinal: u32,
    /// Byte offset of the inclusive length field.
    byte_offset: u64,
    /// Decoded ASCII schema name.
    pub(crate) value: String,
}

/// One definition selector resolved against an object graph's source schema.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDefinitionSchemaSelection {
    /// Byte offset of the selector marker within the definition prefix.
    pub(crate) offset: u64,
    /// Stored zero-based source-schema ordinal.
    pub(crate) ordinal: u32,
    /// Selected catalog entry when the ordinal is in range.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) entry: Option<String>,
    /// UTF-8 source-schema name stored by the selected entry.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name: Option<String>,
}

/// One schema selector and its following encoded `7C07` value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntityValueSchemaSelection {
    /// Byte offset of the selector marker within the value payload.
    pub(crate) offset: u64,
    /// Stored zero-based source-schema ordinal.
    pub(crate) ordinal: u32,
    /// Selected catalog entry.
    pub(crate) entry: String,
    /// UTF-8 source-schema name stored by the selected entry.
    pub(crate) name: String,
    /// Complete token sequence after this selector and before the next selector.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) encoded_value: Vec<value_block::ValueField>,
    /// Exact packets wholly contained by `encoded_value`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) packets: Vec<entity_table::EntityValuePacket>,
}

/// One repeated-reference preamble selector resolved through its graph catalog.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRepeatedReferenceSchemaSelection {
    /// Serialized order of the blob and schema ordinal.
    order: CatiaRepeatedReferenceSchemaOrder,
    /// Byte offset of the schema ordinal within the payload.
    offset: u64,
    /// Stored zero-based source-schema ordinal.
    ordinal: u32,
    /// Selected catalog entry when the ordinal is in range.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entry: Option<String>,
    /// UTF-8 source-schema name stored by the selected entry.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    name: Option<String>,
}

/// One exact schema selector used by a typed entity program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntitySchemaValue {
    /// Byte offset of the selector within its definition or value payload.
    #[serde(default)]
    pub(crate) offset: u64,
    /// Stored zero-based source-schema ordinal.
    #[serde(default)]
    pub(crate) ordinal: u32,
    /// Selected source-schema entry.
    pub(crate) entry: String,
    /// UTF-8 value stored by the selected entry.
    pub(crate) value: String,
}

/// One complete relation-expression value program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(
    from = "CatiaRelationExpressionWire",
    into = "CatiaRelationExpressionWire"
)]
pub(crate) struct CatiaRelationExpression {
    /// Exact wire framing and its framing-specific roles.
    pub(crate) framing: CatiaRelationExpressionFraming,
    /// Stored source expression selected by the second value field.
    pub(crate) expression: CatiaEntitySchemaValue,
    /// Exact `param` role selector.
    parameter_role: CatiaEntitySchemaValue,
    /// Stored source type signature.
    type_signature: CatiaEntitySchemaValue,
    /// Exact `RelationExpFct` function selector.
    function_role: CatiaEntitySchemaValue,
}

impl CatiaRelationExpression {
    /// Parsed parameter and value types when the source signature has the typed form.
    pub(crate) fn signature(&self) -> Option<CatiaRelationTypeSignature> {
        let placeholder = match &self.framing {
            CatiaRelationExpressionFraming::PlaceholderState { placeholder, .. } => {
                Some(placeholder.value.as_str())
            }
            CatiaRelationExpressionFraming::ParserVersion { .. }
            | CatiaRelationExpressionFraming::BooleanParserVersion { .. }
            | CatiaRelationExpressionFraming::OpenedBooleanParserVersion { .. } => None,
        };
        relation_type_signature(placeholder, &self.type_signature.value)
    }
}

#[derive(Serialize, Deserialize)]
pub(super) struct CatiaRelationExpressionWire {
    framing: CatiaRelationExpressionFraming,
    expression: CatiaEntitySchemaValue,
    parameter_role: CatiaEntitySchemaValue,
    type_signature: CatiaEntitySchemaValue,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    signature: Option<CatiaRelationTypeSignature>,
    function_role: CatiaEntitySchemaValue,
}

impl From<CatiaRelationExpression> for CatiaRelationExpressionWire {
    fn from(value: CatiaRelationExpression) -> Self {
        let signature = value.signature();
        Self::from_with_signature(value, signature)
    }
}

impl CatiaRelationExpressionWire {
    fn from_with_signature(
        value: CatiaRelationExpression,
        signature: Option<CatiaRelationTypeSignature>,
    ) -> Self {
        Self {
            framing: value.framing,
            expression: value.expression,
            parameter_role: value.parameter_role,
            type_signature: value.type_signature,
            signature,
            function_role: value.function_role,
        }
    }
}

impl From<CatiaRelationExpressionWire> for CatiaRelationExpression {
    fn from(wire: CatiaRelationExpressionWire) -> Self {
        Self {
            framing: wire.framing,
            expression: wire.expression,
            parameter_role: wire.parameter_role,
            type_signature: wire.type_signature,
            function_role: wire.function_role,
        }
    }
}

/// Mutually exclusive role framing of one relation-expression value program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaRelationExpressionFraming {
    /// Local placeholder followed by the exact `opened` state selector.
    PlaceholderState {
        /// Expression-local placeholder.
        placeholder: CatiaEntitySchemaValue,
        /// Exact `opened` selector.
        state_role: CatiaEntitySchemaValue,
    },
    /// Exact `ParserVersion` role selector without a prefix role.
    ParserVersion {
        /// Exact `ParserVersion` selector.
        parser_version_role: CatiaEntitySchemaValue,
    },
    /// Exact `Boolean` and `ParserVersion` role selectors.
    BooleanParserVersion {
        /// Exact `Boolean` prefix selector.
        prefix_role: CatiaEntitySchemaValue,
        /// Exact `ParserVersion` selector.
        parser_version_role: CatiaEntitySchemaValue,
    },
    /// Exact `Boolean`, `ParserVersion`, and `opened` role selectors.
    OpenedBooleanParserVersion {
        /// Exact `Boolean` prefix selector.
        prefix_role: CatiaEntitySchemaValue,
        /// Exact `ParserVersion` selector.
        parser_version_role: CatiaEntitySchemaValue,
        /// Exact `opened` selector.
        state_role: CatiaEntitySchemaValue,
    },
}

/// Typed roles in a relation-expression source signature.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRelationTypeSignature {
    /// Ordered expression-local inputs named inside the signature.
    pub(crate) inputs: Vec<CatiaRelationTypeInput>,
    /// Source result type named after the closing parenthesis.
    pub(crate) result_type: String,
}

/// One typed input clause in a relation-expression source signature.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRelationTypeInput {
    /// Expression-local parameter named before `#In`.
    pub(crate) parameter: String,
    /// Source input type named after `#In`.
    pub(crate) input_type: String,
}

/// Evaluation state of one complete entity-record suffix value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaEntityEvaluation {
    /// No evaluated scalar: the legacy scalar form's `E7`.
    Unset,
    /// The `E6` form carries one finite IEEE-754 binary64 scalar.
    Scalar {
        /// Exact stored binary64 bits.
        bits: u64,
    },
    /// The `E7` form: the value 1.0 with no payload.
    UnitLiteral,
    /// The `E8` form: the value 0.0 with no payload.
    ZeroLiteral,
}

impl CatiaEntityEvaluation {
    /// The stored binary64 bits, or `None` for an unset evaluation.
    pub(crate) fn bits(&self) -> Option<u64> {
        match self {
            Self::Unset => None,
            Self::Scalar { bits } => Some(*bits),
            Self::UnitLiteral => Some(1.0_f64.to_bits()),
            Self::ZeroLiteral => Some(0.0_f64.to_bits()),
        }
    }
}

/// Wire encoding of one entity-record suffix evaluation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaEntityEvaluationEncoding {
    /// The evaluation opcode directly precedes its payload.
    Direct,
    /// `E6 00 00 00` precedes the scalar's `E6` opcode.
    ZeroPaddedScalar,
}

/// Payload of one complete entity-record suffix value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaEntitySuffixPayload {
    /// An unset or finite scalar evaluation with exact framing.
    Evaluation {
        /// Byte offset of the effective evaluation opcode within the record suffix.
        #[serde(default)]
        opcode_offset: u64,
        /// Stored scalar or unset evaluation.
        evaluation: CatiaEntityEvaluation,
        /// Exact evaluation framing variant.
        encoding: CatiaEntityEvaluationEncoding,
    },
    /// One canonical one-byte atom.
    Atom {
        /// Decoded atom value.
        value: u32,
    },
    /// One source-schema selector followed by one typed value.
    SchemaSelected {
        /// Byte offset of the selector marker within the record suffix.
        #[serde(default)]
        selector_offset: u64,
        /// Stored zero-based source-schema ordinal.
        selector: u32,
        /// Typed value following the selector.
        value: CatiaEntitySuffixSchemaValue,
    },
    /// One zero-payload `E9` control state.
    ControlE9,
    /// One zero-payload `37` separator.
    Separator37,
}

/// Exact trailer framing of one complete entity-record suffix value.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
enum CatiaEntitySuffixTrailer {
    /// No trailer bytes follow the payload.
    Empty,
    /// Exact trailer token `81 49`.
    Token8149,
    /// Exact trailer token `81 4A`.
    Token814A,
    /// Exact trailer token `81 52`.
    Token8152,
    /// Exact trailer token `81 DB`.
    Token81DB,
    /// Exact trailer token `81 92`.
    Token8192,
    /// Exact trailer token `81 93`.
    Token8193,
    /// Exact fixed trailer `FE F6 00{16}`.
    FixedZeroFrame,
}

/// One complete typed value in an entity-record suffix.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntitySuffixValue {
    /// Three canonical compact atoms preceding the field code.
    prefix_atoms: [u32; 3],
    /// Stored width of each prefix atom.
    pub(crate) prefix_atom_widths: NativeBytes<[u8; 3]>,
    /// Exact field code preceding the payload.
    prefix_code: u8,
    /// Stored suffix payload.
    pub(crate) payload: CatiaEntitySuffixPayload,
    /// Exact framing closing the suffix production.
    trailer: CatiaEntitySuffixTrailer,
}

/// State byte following one escaped word in an entity-record suffix.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
enum CatiaEntitySuffixEscapedWordState {
    /// Stored state byte `00`.
    State00,
    /// Stored state byte `01`.
    State01,
    /// Stored state byte `03`.
    State03,
    /// Stored state byte `04`.
    State04,
    /// Stored state byte `09`.
    State09,
}

/// One complete escaped-word entity-record suffix.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntitySuffixEscapedWord {
    /// Fixed-width little-endian word following the `80` escape.
    word: u32,
    /// Exact trailing state.
    state: CatiaEntitySuffixEscapedWordState,
}

/// One complete non-value entity-record suffix framing.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaEntitySuffixFraming {
    /// One escaped fixed-width word followed by an exact state.
    EscapedWord(CatiaEntitySuffixEscapedWord),
    /// Standalone token `81 49`.
    Token8149,
    /// Standalone fixed frame `FE F6 <payload[16]>`.
    FixedFeF6 {
        /// Exact fixed-width payload.
        payload: NativeBytes<Vec<u8>>,
    },
    /// One paged compact atom followed by state byte `01`.
    PagedAtomState01 {
        /// Decoded compact-atom value.
        value: u32,
    },
}

/// One suffix selector resolved through its graph's source-schema catalog.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntitySuffixSchemaSelection {
    /// Byte offset of the selector marker within the record suffix.
    #[serde(default)]
    pub(crate) offset: u64,
    /// Stored zero-based source-schema ordinal.
    pub(crate) ordinal: u32,
    /// Selected catalog entry.
    pub(crate) entry: String,
    /// UTF-8 source-schema name stored by the selected entry.
    pub(crate) name: String,
    /// Typed value following the selector, with nested schema resolution.
    pub(crate) value: CatiaEntitySuffixSchemaValue,
}

/// Catalog-resolved value following an entity-suffix schema selector.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaEntitySuffixSchemaValue {
    /// One canonical compact atom.
    Atom {
        /// Decoded atom value.
        value: u32,
    },
    /// One direct scalar evaluation.
    Evaluation {
        /// Byte offset of the evaluation opcode within the record suffix.
        #[serde(default)]
        opcode_offset: u64,
        /// Decoded evaluation.
        evaluation: CatiaEntityEvaluation,
    },
    /// One zero-payload `37` separator.
    Separator37,
    /// One nested source-schema selector.
    SchemaSelector {
        /// Byte offset of the selector marker within the record suffix.
        #[serde(default)]
        offset: u64,
        /// Stored zero-based source-schema ordinal.
        ordinal: u32,
        /// Catalog class selected by `ordinal`.
        #[serde(flatten)]
        resolution: Option<CatiaDesignClass>,
    },
}

/// Unresolved suffix payload value. Same shape as [`CatiaEntitySuffixSchemaValue`].
pub(crate) type CatiaEntitySuffixSelectedValue = CatiaEntitySuffixSchemaValue;

/// One complete named parameter-value record.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaParameterValue {
    /// Stored parameter name.
    pub(crate) name: CatiaEntitySchemaValue,
    /// Stored scope, expression, or presentation binding.
    pub(crate) binding: CatiaEntitySchemaValue,
    /// Stored evaluation state.
    pub(crate) evaluation: CatiaEntityEvaluation,
    /// Byte offset of the evaluation opcode within the record suffix.
    #[serde(default)]
    evaluation_opcode_offset: u64,
}

/// One complete source-schema `Range` interval carried by an entity value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRangeInterval {
    /// Exact source-schema selector naming `Range`.
    pub(crate) range: CatiaEntitySchemaValue,
    /// Complete selected interval framing and nullable slots.
    pub(crate) interval: entity_table::RangeInterval,
    /// Finite nominal carried by an admitted scalar suffix dialect.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) nominal: Option<CatiaRangeNominal>,
    /// Exact same-graph payload-reference occurrences selecting this interval.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) incoming_references: Vec<CatiaEntityIncomingReference>,
    /// Exact same-graph object-head storage selectors selecting this interval.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) incoming_storage_references: Vec<CatiaEntityIncomingStorageReference>,
    /// Complete same-storage `GSMProject` frame and cylinder-face incidence.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) project_target: Option<project_range::ProjectRangeTarget>,
}

/// Exact scalar-suffix dialect associating a nominal with a `Range` interval.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaRangeNominalFraming {
    /// Prefix code `D8` and trailer `81 93`.
    D8Token8193,
    /// Prefix code `D8` and trailer `81 DB`.
    D8Token81DB,
    /// Prefix code `DC` and trailer `81 DB`.
    DCToken81DB,
    /// Prefix code `DF` and trailer `81 92`.
    DFToken8192,
}

/// One finite nominal associated with a complete `Range` interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRangeNominal {
    /// Exact scalar-suffix dialect.
    pub(crate) framing: CatiaRangeNominalFraming,
    /// Exact finite binary64 nominal bits.
    pub(crate) bits: u64,
    /// Byte offset of the evaluation opcode within the record suffix.
    #[serde(default)]
    pub(crate) evaluation_opcode_offset: u64,
}

/// Exact framing of one complete constraint-range value.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaConstraintRangeFraming {
    /// `CstAttr_Dimension` selected with prefix code `B8`.
    DimensionB8,
    /// `CstAttr_Dimension` selected with prefix code `C1`.
    DimensionC1,
    /// `CstAttr_Dimension` selected with prefix code `DC`.
    DimensionDC,
    /// `CstAttr_Dimension` selected with prefix code `DF` and trailer `81 92`.
    DimensionDF,
    /// `ComplexCst` selected with prefix code `C9`.
    ComplexC9,
}

/// One complete constraint-range value.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaConstraintRange {
    /// Exact `Range` role selector.
    pub(crate) range: CatiaEntitySchemaValue,
    /// Exact constraint role selector encoded by `framing`.
    pub(crate) constraint: CatiaEntitySchemaValue,
    /// Exact role and prefix-code framing.
    pub(crate) framing: CatiaConstraintRangeFraming,
    /// Stored evaluation state.
    pub(crate) evaluation: CatiaEntityEvaluation,
    /// Byte offset of the evaluation opcode within the record suffix.
    #[serde(default)]
    pub(crate) evaluation_opcode_offset: u64,
    /// Exact same-graph payload-reference occurrences selecting this range.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) incoming_references: Vec<CatiaEntityIncomingReference>,
    /// Exact same-graph object-head storage selectors selecting this range.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) incoming_storage_references: Vec<CatiaEntityIncomingStorageReference>,
}

/// One exact payload-reference occurrence selecting an entity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntityIncomingReference {
    /// Object record carrying the reference occurrence.
    pub(crate) object_record: String,
    /// Entity paired with the source object record when that record has an identity.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) source_entity: Option<CatiaEntityReference>,
    /// Byte offset of the reference field within that object's payload.
    pub(crate) payload_offset: u64,
    /// Structural container of the reference occurrence.
    pub(crate) source: CatiaObjectRecordReferenceSource,
}

/// One exact object-head storage selector selecting an entity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaEntityIncomingStorageReference {
    /// Object record carrying the storage selector.
    pub(crate) object_record: String,
    /// Entity paired with the source object record when that record has an identity.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) source_entity: Option<CatiaEntityReference>,
}

/// One definition-selected entity whose complete value occupies its suffix.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDefinitionValue {
    /// Exact source-schema definition selected by the entity.
    pub(crate) definition: CatiaEntitySchemaValue,
    /// Complete typed suffix payload bound to the definition.
    pub(crate) payload: CatiaEntitySuffixPayload,
    /// Catalog-resolved selector when the payload is schema-selected.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) schema_selection: Option<CatiaEntitySuffixSchemaSelection>,
}

/// One value selected through a complete two-definition role chain.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDefinitionChainValue {
    /// Definition repeated by the suffix's fixed-width schema selector.
    pub(crate) selector: CatiaEntitySchemaValue,
    /// Second definition carrying the value's role within the selected schema.
    pub(crate) role: CatiaEntitySchemaValue,
    /// Stored selected value.
    pub(crate) value: CatiaEntitySuffixSchemaValue,
}

/// One complete formula relation stored by an entity and its object payload.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaFormulaRelation {
    /// Complete relation-expression incidence selected by the second payload reference.
    #[serde(
        default = "default_payload_entity_reference",
        deserialize_with = "deserialize_payload_entity_reference"
    )]
    pub(crate) expression_entity: CatiaPayloadEntityReference,
    /// Output parameter incidence selected by the third payload reference.
    #[serde(
        default = "default_payload_entity_reference",
        deserialize_with = "deserialize_payload_entity_reference"
    )]
    pub(crate) output_entity: CatiaPayloadEntityReference,
    /// Named parameter records selected by expression-local symbols, in occurrence order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) parameter_dependencies: Vec<CatiaRelationParameterDependency>,
}

/// One relation-expression symbol and every matching named parameter.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRelationParameterDependency {
    /// UTF-8 byte offset of this occurrence within the source expression.
    #[serde(default)]
    source_offset: u64,
    /// Exact expression-local symbol occurrence.
    symbol: String,
    /// Entity incidences carrying matching named parameter bindings.
    #[serde(
        default,
        skip_serializing_if = "Vec::is_empty",
        deserialize_with = "deserialize_relation_dependency_candidates"
    )]
    pub(crate) candidates: Vec<CatiaEntityReference>,
}

/// One declared relation-program input and its uniquely selected entity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaRelationProgramInput {
    /// Expression-local parameter in signature order.
    pub(crate) parameter: String,
    /// Declared source value type.
    pub(crate) value_type: String,
    /// Unique same-graph named parameter selected by every source occurrence.
    pub(crate) entity: CatiaEntityReference,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum CatiaRelationDependencyCandidate {
    Reference(CatiaEntityReference),
    LegacyEntity(String),
}

fn deserialize_relation_dependency_candidates<'de, D>(
    deserializer: D,
) -> Result<Vec<CatiaEntityReference>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    Vec::<CatiaRelationDependencyCandidate>::deserialize(deserializer).map(|candidates| {
        candidates
            .into_iter()
            .map(|candidate| match candidate {
                CatiaRelationDependencyCandidate::Reference(reference) => reference,
                CatiaRelationDependencyCandidate::LegacyEntity(entity) => {
                    CatiaEntityReference::resolved_or_unresolved(0, Some(entity), None)
                }
            })
            .collect()
    })
}

/// One exact compound relation-program instance frame.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(
    try_from = "CatiaRelationProgramInstanceWire",
    into = "CatiaRelationProgramInstanceWire"
)]
pub(crate) struct CatiaRelationProgramInstance {
    /// Exact object-head and payload production with the framing-specific incidence.
    pub(crate) framing: CatiaRelationProgramInstanceFraming,
    /// Entity incidence carried by the frame's program slot.
    pub(crate) program_entity: CatiaEntityReference,
    /// Entity identity stored once as an atom and once as a reference.
    pub(crate) repeated_entity: CatiaEntityReference,
    /// Every reference occurrence in exact payload order, including repeated identities.
    pub(crate) reference_incidences: Vec<CatiaPayloadEntityReference>,
    /// Selected entity when it carries a complete relation-expression program.
    pub(crate) relation_expression: Option<String>,
    /// Named parameter records selected by expression-local symbols, in occurrence order.
    pub(crate) parameter_dependencies: Vec<CatiaRelationParameterDependency>,
    /// Complete declared inputs in signature order; absent when any binding is incomplete.
    pub(crate) inputs: Option<Vec<CatiaRelationProgramInput>>,
}

impl CatiaRelationProgramInstance {
    /// Same-graph incidence carried by the `ref(h)` slot of a lead-`12` frame.
    #[must_use]
    pub(crate) fn lead12_context_entity(&self) -> Option<&CatiaEntityReference> {
        match &self.framing {
            CatiaRelationProgramInstanceFraming::Lead12 { context_entity } => Some(context_entity),
            CatiaRelationProgramInstanceFraming::Lead54 { .. } => None,
        }
    }

    /// Trailing same-graph entity incidence carried only by lead-`54`.
    #[must_use]
    pub(crate) fn lead54_trailing_entity(&self) -> Option<&CatiaEntityReference> {
        match &self.framing {
            CatiaRelationProgramInstanceFraming::Lead54 { trailing_entity } => {
                Some(trailing_entity)
            }
            CatiaRelationProgramInstanceFraming::Lead12 { .. } => None,
        }
    }

    /// Result entity selected by the framing-specific `paramout` slot.
    #[must_use]
    pub(crate) fn output_entity(&self) -> Option<&CatiaEntityReference> {
        let slot = match &self.framing {
            CatiaRelationProgramInstanceFraming::Lead12 { context_entity } => context_entity,
            CatiaRelationProgramInstanceFraming::Lead54 { trailing_entity } => trailing_entity,
        };
        (slot.class_name() == Some("paramout")).then_some(slot)
    }
}

#[derive(Serialize, Deserialize)]
pub(super) struct CatiaRelationProgramInstanceWire {
    #[serde(default)]
    framing: CatiaRelationProgramInstanceFramingTag,
    #[serde(default)]
    program_entity: Option<CatiaEntityReference>,
    #[serde(default)]
    repeated_entity: Option<CatiaEntityReference>,
    #[serde(
        default,
        skip_serializing_if = "Vec::is_empty",
        deserialize_with = "deserialize_relation_reference_incidences"
    )]
    reference_incidences: Vec<CatiaPayloadEntityReference>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    relation_expression: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    parameter_dependencies: Vec<CatiaRelationParameterDependency>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    inputs: Option<Vec<CatiaRelationProgramInput>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    output_entity: Option<CatiaEntityReference>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    lead12_context_entity: Option<CatiaEntityReference>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    lead54_trailing_entity: Option<CatiaEntityReference>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
enum CatiaRelationProgramInstanceFramingTag {
    #[default]
    Lead12,
    Lead54,
}

impl From<CatiaRelationProgramInstance> for CatiaRelationProgramInstanceWire {
    fn from(value: CatiaRelationProgramInstance) -> Self {
        let output_entity = value.output_entity().cloned();
        Self::from_with_output(value, output_entity)
    }
}

impl CatiaRelationProgramInstanceWire {
    fn from_with_output(
        value: CatiaRelationProgramInstance,
        output_entity: Option<CatiaEntityReference>,
    ) -> Self {
        let (framing, lead12_context_entity, lead54_trailing_entity) = match value.framing {
            CatiaRelationProgramInstanceFraming::Lead12 { context_entity } => (
                CatiaRelationProgramInstanceFramingTag::Lead12,
                Some(context_entity),
                None,
            ),
            CatiaRelationProgramInstanceFraming::Lead54 { trailing_entity } => (
                CatiaRelationProgramInstanceFramingTag::Lead54,
                None,
                Some(trailing_entity),
            ),
        };
        Self {
            framing,
            program_entity: Some(value.program_entity),
            repeated_entity: Some(value.repeated_entity),
            reference_incidences: value.reference_incidences,
            relation_expression: value.relation_expression,
            parameter_dependencies: value.parameter_dependencies,
            inputs: value.inputs,
            output_entity,
            lead12_context_entity,
            lead54_trailing_entity,
        }
    }
}

impl TryFrom<CatiaRelationProgramInstanceWire> for CatiaRelationProgramInstance {
    type Error = String;

    fn try_from(wire: CatiaRelationProgramInstanceWire) -> Result<Self, Self::Error> {
        let framing = match wire.framing {
            CatiaRelationProgramInstanceFramingTag::Lead12 => {
                let context_entity = wire.lead12_context_entity.ok_or_else(|| {
                    "lead-12 relation program requires lead12_context_entity".to_owned()
                })?;
                CatiaRelationProgramInstanceFraming::Lead12 { context_entity }
            }
            CatiaRelationProgramInstanceFramingTag::Lead54 => {
                let trailing_entity = wire.lead54_trailing_entity.ok_or_else(|| {
                    "lead-54 relation program requires lead54_trailing_entity".to_owned()
                })?;
                CatiaRelationProgramInstanceFraming::Lead54 { trailing_entity }
            }
        };
        Ok(Self {
            framing,
            program_entity: wire
                .program_entity
                .unwrap_or(CatiaEntityReference::Unresolved { entity_id: 0 }),
            repeated_entity: wire
                .repeated_entity
                .unwrap_or(CatiaEntityReference::Unresolved { entity_id: 0 }),
            reference_incidences: wire.reference_incidences,
            relation_expression: wire.relation_expression,
            parameter_dependencies: wire.parameter_dependencies,
            inputs: wire.inputs,
        })
    }
}

/// One exact entity-reference occurrence in an object payload.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaPayloadEntityReference {
    /// Byte offset of the reference field within the object payload.
    payload_offset: u64,
    /// Stored entity identity and its same-graph resolution.
    pub(crate) reference: CatiaEntityReference,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum StoredCatiaPayloadEntityReference {
    Current(CatiaPayloadEntityReference),
    Legacy(CatiaEntityReference),
}

fn deserialize_relation_reference_incidences<'de, D>(
    deserializer: D,
) -> Result<Vec<CatiaPayloadEntityReference>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    Vec::<StoredCatiaPayloadEntityReference>::deserialize(deserializer).map(|incidences| {
        incidences
            .into_iter()
            .map(stored_payload_entity_reference)
            .collect()
    })
}

fn deserialize_payload_entity_reference<'de, D>(
    deserializer: D,
) -> Result<CatiaPayloadEntityReference, D::Error>
where
    D: serde::Deserializer<'de>,
{
    StoredCatiaPayloadEntityReference::deserialize(deserializer)
        .map(stored_payload_entity_reference)
}

fn default_payload_entity_reference() -> CatiaPayloadEntityReference {
    CatiaPayloadEntityReference {
        payload_offset: 0,
        reference: CatiaEntityReference::Unresolved { entity_id: 0 },
    }
}

fn stored_payload_entity_reference(
    incidence: StoredCatiaPayloadEntityReference,
) -> CatiaPayloadEntityReference {
    match incidence {
        StoredCatiaPayloadEntityReference::Current(incidence) => incidence,
        StoredCatiaPayloadEntityReference::Legacy(reference) => CatiaPayloadEntityReference {
            payload_offset: 0,
            reference,
        },
    }
}

/// One stored entity identity and its optional same-graph resolution.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(from = "CatiaEntityReferenceWire")]
pub(crate) enum CatiaEntityReference {
    /// The stored identity is the graph's terminal null identity.
    Null { entity_id: u32 },
    /// Stored identity with no same-graph entity.
    Unresolved { entity_id: u32 },
    /// Same-graph entity selected by that identity.
    Resolved {
        entity_id: u32,
        entity: String,
        class_name: Option<String>,
    },
}

impl CatiaEntityReference {
    /// Stored identity with optional same-graph resolution.
    pub(crate) fn resolved_or_unresolved(
        entity_id: u32,
        entity: Option<String>,
        class_name: Option<String>,
    ) -> Self {
        match entity {
            None => Self::Unresolved { entity_id },
            Some(entity) => Self::Resolved {
                entity_id,
                entity,
                class_name,
            },
        }
    }

    pub(crate) fn entity_id(&self) -> u32 {
        match *self {
            Self::Null { entity_id }
            | Self::Unresolved { entity_id }
            | Self::Resolved { entity_id, .. } => entity_id,
        }
    }

    pub(crate) fn is_null(&self) -> bool {
        matches!(self, Self::Null { .. })
    }

    pub(crate) fn entity(&self) -> Option<&str> {
        match self {
            Self::Resolved { entity, .. } => Some(entity.as_str()),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    pub(crate) fn class_name(&self) -> Option<&str> {
        match self {
            Self::Resolved { class_name, .. } => class_name.as_deref(),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    /// Bytes of entity and class text the reference holds.
    fn text_len(&self) -> Option<usize> {
        self.entity()
            .map_or(0, str::len)
            .checked_add(self.class_name().map_or(0, str::len))
    }

    #[cfg(test)]
    fn with_entity_id(self, entity_id: u32) -> Self {
        match self {
            Self::Null { .. } => Self::Null { entity_id },
            Self::Unresolved { .. } => Self::Unresolved { entity_id },
            Self::Resolved {
                entity, class_name, ..
            } => Self::Resolved {
                entity_id,
                entity,
                class_name,
            },
        }
    }

    #[cfg(test)]
    pub(crate) fn without_entity(self) -> Self {
        Self::Unresolved {
            entity_id: self.entity_id(),
        }
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaEntityReferenceWire {
    entity_id: u32,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entity: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    class_name: Option<String>,
}

#[derive(Serialize)]
struct CatiaEntityReferenceWireRef<'a> {
    entity_id: u32,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    entity: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    class_name: Option<&'a str>,
}

impl Serialize for CatiaEntityReference {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        CatiaEntityReferenceWireRef {
            entity_id: self.entity_id(),
            is_null: self.is_null(),
            entity: self.entity(),
            class_name: self.class_name(),
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaEntityReference> for CatiaEntityReferenceWire {
    fn from(value: CatiaEntityReference) -> Self {
        match value {
            CatiaEntityReference::Null { entity_id } => Self {
                entity_id,
                is_null: true,
                entity: None,
                class_name: None,
            },
            CatiaEntityReference::Unresolved { entity_id } => Self {
                entity_id,
                is_null: false,
                entity: None,
                class_name: None,
            },
            CatiaEntityReference::Resolved {
                entity_id,
                entity,
                class_name,
            } => Self {
                entity_id,
                is_null: false,
                entity: Some(entity),
                class_name,
            },
        }
    }
}

impl From<CatiaEntityReferenceWire> for CatiaEntityReference {
    fn from(wire: CatiaEntityReferenceWire) -> Self {
        match (wire.is_null, wire.entity) {
            (true, _) => Self::Null {
                entity_id: wire.entity_id,
            },
            (false, None) => Self::Unresolved {
                entity_id: wire.entity_id,
            },
            (false, Some(entity)) => Self::Resolved {
                entity_id: wire.entity_id,
                entity,
                class_name: wire.class_name,
            },
        }
    }
}

/// One complete reference-signature packet and its same-graph entity incidences.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaReferenceSignature {
    /// Exact complete packet production.
    #[serde(flatten)]
    pub(crate) production: entity_table::ReferenceSignature,
    /// Entity incidence selected by the first fixed-width reference.
    pub(crate) first_entity: CatiaEntityReference,
    /// Entity incidence selected by the second fixed-width reference.
    pub(crate) second_entity: CatiaEntityReference,
}

#[derive(Serialize, Deserialize)]
pub(super) struct CatiaReferenceSignatureWire {
    #[serde(flatten)]
    production: entity_table::ReferenceSignatureWire,
    first_entity: CatiaEntityReference,
    second_entity: CatiaEntityReference,
}

impl From<CatiaReferenceSignature> for CatiaReferenceSignatureWire {
    fn from(value: CatiaReferenceSignature) -> Self {
        Self {
            production: value.production.into(),
            first_entity: value.first_entity,
            second_entity: value.second_entity,
        }
    }
}

impl TryFrom<CatiaReferenceSignatureWire> for CatiaReferenceSignature {
    type Error = String;

    fn try_from(wire: CatiaReferenceSignatureWire) -> Result<Self, Self::Error> {
        Ok(Self {
            production: wire.production.try_into().map_err(str::to_owned)?,
            first_entity: wire.first_entity,
            second_entity: wire.second_entity,
        })
    }
}

/// Source-ordered descriptor records sharing one exact reference pair.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(try_from = "CatiaReferenceSignatureCohortWire")]
pub(crate) struct CatiaReferenceSignatureCohort {
    references: entity_table::ConsecutiveReferences,
    /// Globally unique cohort identity.
    id: String,
    /// Containing object graph.
    parent: String,
    /// Zero-based order of the cohort's first member within the graph.
    ordinal: u64,
    /// Common same-graph incidence selected by the first identity.
    first_entity: CatiaEntityReference,
    /// Common same-graph incidence selected by the second identity.
    second_entity: CatiaEntityReference,
    /// Unique schema selected by descriptor-bearing members after `_SpecList`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) schema_selection: Option<CatiaReferenceSignatureSchemaSelection>,
    /// Descriptor-bearing entity records in source order.
    pub(crate) members: Vec<String>,
}

impl CatiaReferenceSignatureCohort {
    /// First reference identity shared by the cohort.
    fn first_reference(&self) -> u32 {
        self.references.first()
    }
    /// Second reference identity shared by the cohort.
    fn second_reference(&self) -> u32 {
        self.references.second()
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaReferenceSignatureCohortWire {
    /// Globally unique cohort identity.
    id: String,
    /// Containing object graph.
    parent: String,
    /// Zero-based order of the cohort's first member within the graph.
    ordinal: u64,
    /// First identity shared by every member.
    first_reference: u32,
    /// Common same-graph incidence selected by the first identity.
    first_entity: CatiaEntityReference,
    /// Consecutive second identity shared by every member.
    second_reference: u32,
    /// Common same-graph incidence selected by the second identity.
    second_entity: CatiaEntityReference,
    /// Unique schema selected by descriptor-bearing members after `_SpecList`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    schema_selection: Option<CatiaReferenceSignatureSchemaSelection>,
    /// Descriptor-bearing entity records in source order.
    members: Vec<String>,
}

#[derive(Serialize)]
struct CatiaReferenceSignatureCohortWireRef<'a> {
    id: &'a str,
    parent: &'a str,
    ordinal: u64,
    first_reference: u32,
    first_entity: &'a CatiaEntityReference,
    second_reference: u32,
    second_entity: &'a CatiaEntityReference,
    #[serde(skip_serializing_if = "Option::is_none")]
    schema_selection: &'a Option<CatiaReferenceSignatureSchemaSelection>,
    members: &'a [String],
}

impl Serialize for CatiaReferenceSignatureCohort {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        CatiaReferenceSignatureCohortWireRef {
            id: &self.id,
            parent: &self.parent,
            ordinal: self.ordinal,
            first_reference: self.first_reference(),
            first_entity: &self.first_entity,
            second_reference: self.second_reference(),
            second_entity: &self.second_entity,
            schema_selection: &self.schema_selection,
            members: &self.members,
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaReferenceSignatureCohort> for CatiaReferenceSignatureCohortWire {
    fn from(value: CatiaReferenceSignatureCohort) -> Self {
        Self {
            first_reference: value.first_reference(),
            second_reference: value.second_reference(),
            id: value.id,
            parent: value.parent,
            ordinal: value.ordinal,
            first_entity: value.first_entity,
            second_entity: value.second_entity,
            schema_selection: value.schema_selection,
            members: value.members,
        }
    }
}
impl TryFrom<CatiaReferenceSignatureCohortWire> for CatiaReferenceSignatureCohort {
    type Error = &'static str;
    fn try_from(wire: CatiaReferenceSignatureCohortWire) -> Result<Self, Self::Error> {
        let references = entity_table::ConsecutiveReferences::new(wire.first_reference)
            .ok_or("first_reference has no consecutive successor")?;
        if references.second() != wire.second_reference {
            return Err("second_reference must follow first_reference");
        }
        Ok(Self {
            references,
            id: wire.id,
            parent: wire.parent,
            ordinal: wire.ordinal,
            first_entity: wire.first_entity,
            second_entity: wire.second_entity,
            schema_selection: wire.schema_selection,
            members: wire.members,
        })
    }
}

/// Cohort-level schema incidence selected after the `_SpecList` marker.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaReferenceSignatureSchemaSelection {
    /// Stored zero-based source-schema ordinal.
    ordinal: u32,
    /// Selected catalog entry.
    entry: String,
    /// UTF-8 source-schema name stored by the selected entry.
    name: String,
}

/// One exact self-defining schema-configuration `Configuration` object production.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaSchemaConfigurationRecord {
    /// Byte offset of the schema reference within the object payload.
    #[serde(default)]
    schema_payload_offset: u64,
    /// Stored value-schema ordinal selected by the first reference.
    schema_ordinal: u32,
    /// Selected schema-catalog entry.
    schema_entry: String,
    /// Selected schema-catalog name.
    schema_name: String,
    /// Entity selected by the second stored reference.
    #[serde(deserialize_with = "deserialize_payload_entity_reference")]
    pub(crate) entity_reference: CatiaPayloadEntityReference,
}

/// One exact schema-configuration `configrow` successor-link production.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaSchemaConfigurationRowLink {
    /// Stored class identity whose catalog name is `configrow`.
    pub(crate) class_reference: CatiaEntityReference,
    /// Byte offset of the successor atom within the object payload.
    #[serde(default)]
    successor_payload_offset: u64,
    /// Stored successor identity.
    pub(crate) successor: CatiaEntityReference,
}

/// Exact framing production for a compound relation-program instance.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum CatiaRelationProgramInstanceFraming {
    /// Compact `0x12` object head and its 20-token payload.
    Lead12 {
        /// Same-graph incidence carried by the `ref(h)` slot.
        context_entity: CatiaEntityReference,
    },
    /// Separator-form `0x54` object head and its 18-token payload.
    Lead54 {
        /// Trailing same-graph entity incidence.
        trailing_entity: CatiaEntityReference,
    },
}

/// Field order used by a repeated-reference schema preamble.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
enum CatiaRepeatedReferenceSchemaOrder {
    /// The binary descriptor precedes the schema ordinal.
    BlobThenSchema,
    /// The schema ordinal precedes the binary descriptor.
    SchemaThenBlob,
}

/// One outer `7C08` ownership graph in source order.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaObjectGraph {
    /// Globally unique graph identity.
    pub(crate) id: String,
    /// Byte offset of the `7C08` root.
    pub(crate) byte_offset: u64,
    /// Total framed byte length.
    pub(crate) byte_len: u64,
    /// Physically containing FINJPL segment, when the graph is not in the outer preamble.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) finjpl_segment: Option<String>,
    /// Exact declared outer container whose physical stream contains this graph.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) outer_container: Option<CatiaOuterContainerBinding>,
    /// Byte offset of the associated schema catalog.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) catalog_byte_offset: Option<u64>,
    /// Associated schema catalog.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) catalog: Option<String>,
    /// Consecutive `7C09` records in serialized order.
    #[serde(default)]
    pub(crate) records: Vec<CatiaObjectRecord>,
}

/// Outer `Data` declaration and its selected physical stream.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaOuterContainerBinding {
    /// Byte offset of the declaration in the reconstructed outer `Data` stream.
    pub(crate) data_offset: u64,
    /// Source ordinal stored by the declaration.
    pub(crate) ordinal: u32,
    /// Concrete container class.
    pub(crate) class_name: String,
    /// Declared base container class.
    pub(crate) base_class: String,
    /// Raw descriptor key of the content stream referenced by the UUID metadata.
    pub(crate) stream_name: String,
}

/// Paired entity-table identity for one object record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CatiaObjectEntity {
    /// Positionally paired `7C05` entity-table record.
    pub(crate) record: String,
    /// Stored entity-table identity used to select this record.
    pub(crate) id: u32,
}

/// Class role resolved through the graph schema catalog.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CatiaObjectClass {
    /// Head role identifying the per-file class ordinal.
    pub(crate) ordinal: u32,
    /// UTF-8 class name resolved through the graph's schema catalog.
    pub(crate) name: Option<String>,
    /// Exact schema-catalog entry selected by `class_ref`.
    pub(crate) entry: Option<String>,
}

/// Storage role resolved through the same graph.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct CatiaObjectStorage {
    /// Head role selecting class-specific storage.
    pub(crate) reference: u32,
    /// Same-graph field record selected by `storage_ref`.
    pub(crate) record: Option<String>,
    /// Design object containing the selected storage record.
    pub(crate) design_object: Option<String>,
}

/// One `7C09` object record.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "CatiaObjectRecordWire", into = "CatiaObjectRecordWire")]
pub(crate) struct CatiaObjectRecord {
    /// Globally unique record identity.
    pub(crate) id: String,
    /// Containing [`CatiaObjectGraph`] identity.
    pub(crate) parent: String,
    /// Design object selected by this record's owner entity identity.
    pub(crate) design_object: Option<String>,
    /// Paired entity-table identity.
    pub(crate) entity: Option<CatiaObjectEntity>,
    /// Stable serialized order within the graph.
    pub(crate) ordinal: u64,
    /// Byte offset of the `7C09` record.
    pub(crate) byte_offset: u64,
    /// Total framed byte length.
    pub(crate) byte_len: u64,
    /// First head byte.
    pub(crate) lead: u8,
    /// Decoded head tokens in serialized order.
    pub(crate) head: Vec<HeadToken>,
    /// Complete alternate inline body when the record has no nested `7C0A`.
    pub(crate) inline_body: Option<Vec<u8>>,
    /// Structurally assigned owner slot.
    pub(crate) owner: Option<CatiaObjectOwner>,
    /// Class role when the head carries a class ordinal.
    pub(crate) class: Option<CatiaObjectClass>,
    /// Storage role when the head carries a storage ordinal.
    pub(crate) storage: Option<CatiaObjectStorage>,
    /// Typed nested payload, empty for an inline record.
    pub(crate) payload: ObjectPayload,
    /// Repeated-reference preamble selector resolved through the graph catalog.
    pub(crate) repeated_reference_schema_selection: Option<CatiaRepeatedReferenceSchemaSelection>,
    /// Ordered same-graph payload-reference links.
    pub(crate) references: Vec<CatiaObjectRecordReference>,
}

/// Structurally assigned owner role in a `7C09` head.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaObjectOwner {
    /// Stored entity identity selecting the design object.
    Entity(u32),
    /// Literal occupying the assigned slot without establishing ownership.
    UnassignedLiteral(u8),
}

impl From<object_graph::HeadOwner> for CatiaObjectOwner {
    fn from(owner: object_graph::HeadOwner) -> Self {
        match owner {
            object_graph::HeadOwner::Entity(value) => Self::Entity(value),
            object_graph::HeadOwner::UnassignedLiteral(value) => Self::UnassignedLiteral(value),
        }
    }
}

impl CatiaObjectRecord {
    /// Structural payload classification.
    pub(crate) fn subtype(&self) -> PayloadSubtype {
        object_graph::classify(&self.payload.fields)
    }
    /// Counted reference suffix of the payload.
    pub(crate) fn repeated_reference_suffix(
        &self,
    ) -> Option<object_graph::RepeatedReferenceSuffix> {
        object_graph::repeated_reference_suffix(&self.payload)
    }

    pub(crate) fn entity_record(&self) -> Option<&str> {
        self.entity.as_ref().map(|entity| entity.record.as_str())
    }

    pub(crate) fn entity_id(&self) -> Option<u32> {
        self.entity.as_ref().map(|entity| entity.id)
    }

    fn class_ref(&self) -> Option<u32> {
        self.class.as_ref().map(|class| class.ordinal)
    }

    pub(crate) fn class_name(&self) -> Option<&str> {
        self.class.as_ref().and_then(|class| class.name.as_deref())
    }

    pub(crate) fn class_entry(&self) -> Option<&str> {
        self.class.as_ref().and_then(|class| class.entry.as_deref())
    }

    pub(crate) fn storage_ref(&self) -> Option<u32> {
        self.storage.as_ref().map(|storage| storage.reference)
    }

    pub(crate) fn storage_record(&self) -> Option<&str> {
        self.storage
            .as_ref()
            .and_then(|storage| storage.record.as_deref())
    }

    fn storage_design_object(&self) -> Option<&str> {
        self.storage
            .as_ref()
            .and_then(|storage| storage.design_object.as_deref())
    }

    pub(crate) fn owner_entity_id(&self) -> Option<u32> {
        match self.owner {
            Some(CatiaObjectOwner::Entity(entity_id)) => Some(entity_id),
            Some(CatiaObjectOwner::UnassignedLiteral(_)) | None => None,
        }
    }

    pub(crate) fn has_unassigned_owner(&self) -> bool {
        matches!(self.owner, Some(CatiaObjectOwner::UnassignedLiteral(_)))
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaObjectRecordWire {
    id: String,
    parent: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    design_object: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entity_record: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entity_id: Option<u32>,
    ordinal: u64,
    byte_offset: u64,
    byte_len: u64,
    lead: u8,
    head: Vec<HeadToken>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    inline_body: Option<NativeBytes<Vec<u8>>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    owner: Option<CatiaObjectOwner>,
    class_ref: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    class_name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    class_entry: Option<String>,
    storage_ref: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    storage_record: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    storage_design_object: Option<String>,
    payload: ObjectPayload,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    repeated_reference_suffix: Option<object_graph::RepeatedReferenceSuffix>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    repeated_reference_schema_selection: Option<CatiaRepeatedReferenceSchemaSelection>,
    subtype: PayloadSubtype,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    references: Vec<CatiaObjectRecordReference>,
}

impl From<CatiaObjectRecord> for CatiaObjectRecordWire {
    fn from(value: CatiaObjectRecord) -> Self {
        let subtype = value.subtype();
        let repeated_reference_suffix = value.repeated_reference_suffix();
        Self::from_parts(value, subtype, repeated_reference_suffix)
    }
}

impl CatiaObjectRecordWire {
    fn from_parts(
        value: CatiaObjectRecord,
        subtype: PayloadSubtype,
        repeated_reference_suffix: Option<object_graph::RepeatedReferenceSuffix>,
    ) -> Self {
        let (entity_record, entity_id) = match value.entity {
            Some(entity) => (Some(entity.record), Some(entity.id)),
            None => (None, None),
        };
        let (class_ref, class_name, class_entry) = match value.class {
            Some(class) => (Some(class.ordinal), class.name, class.entry),
            None => (None, None, None),
        };
        let (storage_ref, storage_record, storage_design_object) = match value.storage {
            Some(storage) => (
                Some(storage.reference),
                storage.record,
                storage.design_object,
            ),
            None => (None, None, None),
        };
        Self {
            id: value.id,
            parent: value.parent,
            design_object: value.design_object,
            entity_record,
            entity_id,
            ordinal: value.ordinal,
            byte_offset: value.byte_offset,
            byte_len: value.byte_len,
            lead: value.lead,
            head: value.head,
            inline_body: (value.inline_body).map(Into::into),
            owner: value.owner,
            class_ref,
            class_name,
            class_entry,
            storage_ref,
            storage_record,
            storage_design_object,
            payload: value.payload,
            repeated_reference_suffix,
            repeated_reference_schema_selection: value.repeated_reference_schema_selection,
            subtype,
            references: value.references,
        }
    }
}

impl TryFrom<CatiaObjectRecordWire> for CatiaObjectRecord {
    type Error = String;

    fn try_from(wire: CatiaObjectRecordWire) -> Result<Self, Self::Error> {
        if wire.subtype != object_graph::classify(&wire.payload.fields) {
            return Err("subtype disagrees with payload".to_owned());
        }
        if wire.repeated_reference_suffix != object_graph::repeated_reference_suffix(&wire.payload)
        {
            return Err("repeated_reference_suffix disagrees with payload".to_owned());
        }

        let entity = match (wire.entity_record, wire.entity_id) {
            (None, None) => None,
            (Some(record), Some(id)) => Some(CatiaObjectEntity { record, id }),
            _ => {
                return Err(
                    "object record entity_record and entity_id must both be present or both absent"
                        .to_owned(),
                );
            }
        };
        let class = match wire.class_ref {
            Some(class_ref) => Some(CatiaObjectClass {
                ordinal: class_ref,
                name: wire.class_name,
                entry: wire.class_entry,
            }),
            None if wire.class_name.is_some() || wire.class_entry.is_some() => {
                return Err("object record class name/entry requires class_ref".to_owned());
            }
            None => None,
        };
        let storage = match wire.storage_ref {
            Some(storage_ref) => Some(CatiaObjectStorage {
                reference: storage_ref,
                record: wire.storage_record,
                design_object: wire.storage_design_object,
            }),
            None if wire.storage_record.is_some() || wire.storage_design_object.is_some() => {
                return Err("object record storage links require storage_ref".to_owned());
            }
            None => None,
        };
        Ok(Self {
            id: wire.id,
            parent: wire.parent,
            design_object: wire.design_object,
            entity,
            ordinal: wire.ordinal,
            byte_offset: wire.byte_offset,
            byte_len: wire.byte_len,
            lead: wire.lead,
            head: wire.head,
            inline_body: wire.inline_body.map(NativeBytes::into_inner),
            owner: wire.owner,
            class,
            storage,
            payload: wire.payload,
            repeated_reference_schema_selection: wire.repeated_reference_schema_selection,
            references: wire.references,
        })
    }
}

/// One typed payload reference from a `7C09` record.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(from = "CatiaObjectRecordReferenceWire")]
pub(crate) enum CatiaObjectRecordReference {
    /// The stored identity is the graph's terminal null identity.
    Null {
        entity_id: u32,
        payload_offset: u64,
        source: CatiaObjectRecordReferenceSource,
    },
    /// Stored identity with no same-graph target.
    Unresolved {
        entity_id: u32,
        payload_offset: u64,
        source: CatiaObjectRecordReferenceSource,
    },
    /// Same-graph record selected by that identity.
    Resolved {
        entity_id: u32,
        payload_offset: u64,
        source: CatiaObjectRecordReferenceSource,
        target: String,
        design_object: Option<String>,
    },
}

impl CatiaObjectRecordReference {
    pub(crate) fn from_parts(
        entity_id: u32,
        payload_offset: u64,
        source: CatiaObjectRecordReferenceSource,
        is_null: bool,
        target: Option<String>,
        design_object: Option<String>,
    ) -> Self {
        match (is_null, target) {
            (true, _) => Self::Null {
                entity_id,
                payload_offset,
                source,
            },
            (false, None) => Self::Unresolved {
                entity_id,
                payload_offset,
                source,
            },
            (false, Some(target)) => Self::Resolved {
                entity_id,
                payload_offset,
                source,
                target,
                design_object,
            },
        }
    }

    pub(crate) fn entity_id(&self) -> u32 {
        match *self {
            Self::Null { entity_id, .. }
            | Self::Unresolved { entity_id, .. }
            | Self::Resolved { entity_id, .. } => entity_id,
        }
    }

    pub(crate) fn payload_offset(&self) -> u64 {
        match *self {
            Self::Null { payload_offset, .. }
            | Self::Unresolved { payload_offset, .. }
            | Self::Resolved { payload_offset, .. } => payload_offset,
        }
    }

    pub(crate) fn source(&self) -> &CatiaObjectRecordReferenceSource {
        match self {
            Self::Null { source, .. }
            | Self::Unresolved { source, .. }
            | Self::Resolved { source, .. } => source,
        }
    }

    pub(crate) fn is_null(&self) -> bool {
        matches!(self, Self::Null { .. })
    }

    pub(crate) fn target(&self) -> Option<&str> {
        match self {
            Self::Resolved { target, .. } => Some(target.as_str()),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    pub(crate) fn design_object(&self) -> Option<&str> {
        match self {
            Self::Resolved { design_object, .. } => design_object.as_deref(),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaObjectRecordReferenceWire {
    entity_id: u32,
    payload_offset: u64,
    source: CatiaObjectRecordReferenceSource,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    target: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    design_object: Option<String>,
}

#[derive(Serialize)]
struct CatiaObjectRecordReferenceWireRef<'a> {
    entity_id: u32,
    payload_offset: u64,
    source: &'a CatiaObjectRecordReferenceSource,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    target: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    design_object: Option<&'a str>,
}

impl Serialize for CatiaObjectRecordReference {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        CatiaObjectRecordReferenceWireRef {
            entity_id: self.entity_id(),
            payload_offset: self.payload_offset(),
            source: self.source(),
            is_null: self.is_null(),
            target: self.target(),
            design_object: self.design_object(),
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaObjectRecordReference> for CatiaObjectRecordReferenceWire {
    fn from(value: CatiaObjectRecordReference) -> Self {
        match value {
            CatiaObjectRecordReference::Null {
                entity_id,
                payload_offset,
                source,
            } => Self {
                entity_id,
                payload_offset,
                source,
                is_null: true,
                target: None,
                design_object: None,
            },
            CatiaObjectRecordReference::Unresolved {
                entity_id,
                payload_offset,
                source,
            } => Self {
                entity_id,
                payload_offset,
                source,
                is_null: false,
                target: None,
                design_object: None,
            },
            CatiaObjectRecordReference::Resolved {
                entity_id,
                payload_offset,
                source,
                target,
                design_object,
            } => Self {
                entity_id,
                payload_offset,
                source,
                is_null: false,
                target: Some(target),
                design_object,
            },
        }
    }
}

impl From<CatiaObjectRecordReferenceWire> for CatiaObjectRecordReference {
    fn from(wire: CatiaObjectRecordReferenceWire) -> Self {
        Self::from_parts(
            wire.entity_id,
            wire.payload_offset,
            wire.source,
            wire.is_null,
            wire.target,
            wire.design_object,
        )
    }
}

/// Structural container of one payload-reference occurrence.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaObjectRecordReferenceSource {
    /// Standalone compact or fixed-width payload field.
    Field,
    /// Item in one count-framed list.
    ListItem {
        /// Byte offset of the list's `0x3b` tag within the payload.
        list_payload_offset: u64,
        /// Zero-based item position within the list, including atom items.
        item_ordinal: u64,
    },
}

/// One exact schema class retained on a grouped design object.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub(crate) struct CatiaDesignClass {
    /// Selected source-schema entry.
    pub(crate) entry: String,
    /// UTF-8 class name stored by the entry.
    pub(crate) name: String,
}

/// One exact outbound relation occurrence in a grouped design object.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDesignObjectRelation {
    /// Field record containing the relation.
    pub(crate) source_field: String,
    /// Exact schema class of the source field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) source_class: Option<CatiaDesignClass>,
    /// Structural source of the relation occurrence.
    pub(crate) source: CatiaDesignObjectRelationSource,
    /// Stored target entity identity.
    pub(crate) target_entity_id: u32,
    /// Exact field record selected by the stored identity.
    pub(crate) target_field: String,
    /// Exact schema class of the selected target field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) target_class: Option<CatiaDesignClass>,
    /// Design object containing the selected field record, when it has an owner group.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) target_design_object: Option<String>,
}

/// Structural source of one exact outbound relation occurrence.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaDesignObjectRelationSource {
    /// Class-specific storage selector in the field-record head.
    Storage,
    /// Reference occurrence in the field-record payload.
    Payload {
        /// Byte offset of the reference occurrence within the payload.
        payload_offset: u64,
        /// Structural container of the payload reference occurrence.
        container: CatiaObjectRecordReferenceSource,
    },
}

/// One cell in a row-aligned design-object reference table.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(from = "CatiaDesignReferenceCellWire")]
pub(crate) enum CatiaDesignReferenceCell {
    /// The stored identity is the graph's terminal null identity.
    Null { payload_offset: u64, entity_id: u32 },
    /// Stored identity with no same-graph field.
    Unresolved { payload_offset: u64, entity_id: u32 },
    /// Same-graph field selected by that identity.
    Resolved {
        payload_offset: u64,
        entity_id: u32,
        field: String,
        field_class: Option<CatiaDesignClass>,
        design_object: Option<String>,
    },
}

impl CatiaDesignReferenceCell {
    fn from_parts(
        payload_offset: u64,
        entity_id: u32,
        is_null: bool,
        field: Option<String>,
        field_class: Option<CatiaDesignClass>,
        design_object: Option<String>,
    ) -> Self {
        match (is_null, field) {
            (true, _) => Self::Null {
                payload_offset,
                entity_id,
            },
            (false, None) => Self::Unresolved {
                payload_offset,
                entity_id,
            },
            (false, Some(field)) => Self::Resolved {
                payload_offset,
                entity_id,
                field,
                field_class,
                design_object,
            },
        }
    }

    #[cfg(test)]
    fn payload_offset(&self) -> u64 {
        match *self {
            Self::Null { payload_offset, .. }
            | Self::Unresolved { payload_offset, .. }
            | Self::Resolved { payload_offset, .. } => payload_offset,
        }
    }

    #[cfg(test)]
    fn entity_id(&self) -> u32 {
        match *self {
            Self::Null { entity_id, .. }
            | Self::Unresolved { entity_id, .. }
            | Self::Resolved { entity_id, .. } => entity_id,
        }
    }

    pub(crate) fn is_null(&self) -> bool {
        matches!(self, Self::Null { .. })
    }

    pub(crate) fn field(&self) -> Option<&str> {
        match self {
            Self::Resolved { field, .. } => Some(field.as_str()),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    pub(crate) fn field_class(&self) -> Option<&CatiaDesignClass> {
        match self {
            Self::Resolved { field_class, .. } => field_class.as_ref(),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    fn design_object(&self) -> Option<&str> {
        match self {
            Self::Resolved { design_object, .. } => design_object.as_deref(),
            Self::Null { .. } | Self::Unresolved { .. } => None,
        }
    }

    #[cfg(test)]
    fn with_payload_offset(self, payload_offset: u64) -> Self {
        match self {
            Self::Null { entity_id, .. } => Self::Null {
                payload_offset,
                entity_id,
            },
            Self::Unresolved { entity_id, .. } => Self::Unresolved {
                payload_offset,
                entity_id,
            },
            Self::Resolved {
                entity_id,
                field,
                field_class,
                design_object,
                ..
            } => Self::Resolved {
                payload_offset,
                entity_id,
                field,
                field_class,
                design_object,
            },
        }
    }

    #[cfg(test)]
    fn with_entity_id(self, entity_id: u32) -> Self {
        match self {
            Self::Null { payload_offset, .. } => Self::Null {
                payload_offset,
                entity_id,
            },
            Self::Unresolved { payload_offset, .. } => Self::Unresolved {
                payload_offset,
                entity_id,
            },
            Self::Resolved {
                payload_offset,
                field,
                field_class,
                design_object,
                ..
            } => Self::Resolved {
                payload_offset,
                entity_id,
                field,
                field_class,
                design_object,
            },
        }
    }
}

#[derive(Serialize, Deserialize)]
struct CatiaDesignReferenceCellWire {
    #[serde(default)]
    payload_offset: u64,
    entity_id: u32,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    field: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    field_class: Option<CatiaDesignClass>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    design_object: Option<String>,
}

#[derive(Serialize)]
struct CatiaDesignReferenceCellWireRef<'a> {
    payload_offset: u64,
    entity_id: u32,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    is_null: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    field: Option<&'a str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    field_class: Option<&'a CatiaDesignClass>,
    #[serde(skip_serializing_if = "Option::is_none")]
    design_object: Option<&'a str>,
}

impl Serialize for CatiaDesignReferenceCell {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let (payload_offset, entity_id) = match self {
            Self::Null {
                payload_offset,
                entity_id,
            }
            | Self::Unresolved {
                payload_offset,
                entity_id,
            }
            | Self::Resolved {
                payload_offset,
                entity_id,
                ..
            } => (*payload_offset, *entity_id),
        };
        CatiaDesignReferenceCellWireRef {
            payload_offset,
            entity_id,
            is_null: self.is_null(),
            field: self.field(),
            field_class: self.field_class(),
            design_object: self.design_object(),
        }
        .serialize(serializer)
    }
}

#[cfg(test)]
impl From<CatiaDesignReferenceCell> for CatiaDesignReferenceCellWire {
    fn from(value: CatiaDesignReferenceCell) -> Self {
        match value {
            CatiaDesignReferenceCell::Null {
                payload_offset,
                entity_id,
            } => Self {
                payload_offset,
                entity_id,
                is_null: true,
                field: None,
                field_class: None,
                design_object: None,
            },
            CatiaDesignReferenceCell::Unresolved {
                payload_offset,
                entity_id,
            } => Self {
                payload_offset,
                entity_id,
                is_null: false,
                field: None,
                field_class: None,
                design_object: None,
            },
            CatiaDesignReferenceCell::Resolved {
                payload_offset,
                entity_id,
                field,
                field_class,
                design_object,
            } => Self {
                payload_offset,
                entity_id,
                is_null: false,
                field: Some(field),
                field_class,
                design_object,
            },
        }
    }
}

impl From<CatiaDesignReferenceCellWire> for CatiaDesignReferenceCell {
    fn from(wire: CatiaDesignReferenceCellWire) -> Self {
        Self::from_parts(
            wire.payload_offset,
            wire.entity_id,
            wire.is_null,
            wire.field,
            wire.field_class,
            wire.design_object,
        )
    }
}

/// One source-ordered row in a parallel design-object reference table.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDesignReferenceRow {
    /// Cells in the order of the table's source fields.
    pub(crate) cells: Vec<CatiaDesignReferenceCell>,
    /// Design object containing distinct selected fields whose classes equal every column class.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) matching_design_object: Option<String>,
}

/// One source field and list framing forming a parallel-reference table column.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDesignReferenceColumn {
    /// Source field record containing the reference list.
    field: String,
    /// Exact source field class when its schema ordinal resolves.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) field_class: Option<CatiaDesignClass>,
    /// Byte offset of the list tag within the source field's payload.
    #[serde(default)]
    list_payload_offset: u64,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum StoredCatiaDesignReferenceColumn {
    Current(CatiaDesignReferenceColumn),
    LegacyField(String),
}

fn deserialize_design_reference_columns<'de, D>(
    deserializer: D,
) -> Result<Vec<CatiaDesignReferenceColumn>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    Vec::<StoredCatiaDesignReferenceColumn>::deserialize(deserializer).map(|columns| {
        columns
            .into_iter()
            .map(|column| match column {
                StoredCatiaDesignReferenceColumn::Current(column) => column,
                StoredCatiaDesignReferenceColumn::LegacyField(field) => {
                    CatiaDesignReferenceColumn {
                        field,
                        field_class: None,
                        list_payload_offset: 0,
                    }
                }
            })
            .collect()
    })
}

/// Equal-cardinality reference lists aligned by list-item ordinal.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
#[serde(try_from = "CatiaDesignParallelReferenceTableWire")]
pub(crate) struct CatiaDesignParallelReferenceTable {
    columns: Vec<CatiaDesignReferenceColumn>,
    rows: Vec<CatiaDesignReferenceRow>,
}

#[derive(Serialize, Deserialize)]
struct CatiaDesignParallelReferenceTableWire {
    #[serde(deserialize_with = "deserialize_design_reference_columns")]
    columns: Vec<CatiaDesignReferenceColumn>,
    rows: Vec<CatiaDesignReferenceRow>,
}

#[derive(Serialize)]
struct CatiaDesignParallelReferenceTableWireRef<'a> {
    columns: &'a [CatiaDesignReferenceColumn],
    rows: &'a [CatiaDesignReferenceRow],
}

impl Serialize for CatiaDesignParallelReferenceTable {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        CatiaDesignParallelReferenceTableWireRef {
            columns: &self.columns,
            rows: &self.rows,
        }
        .serialize(serializer)
    }
}

impl CatiaDesignParallelReferenceTable {
    fn new(
        columns: Vec<CatiaDesignReferenceColumn>,
        rows: Vec<CatiaDesignReferenceRow>,
    ) -> Option<Self> {
        rows.iter()
            .all(|row| row.cells.len() == columns.len())
            .then_some(Self { columns, rows })
    }

    pub(crate) fn columns(&self) -> &[CatiaDesignReferenceColumn] {
        &self.columns
    }

    pub(crate) fn rows(&self) -> &[CatiaDesignReferenceRow] {
        &self.rows
    }
}

#[cfg(test)]
impl From<CatiaDesignParallelReferenceTable> for CatiaDesignParallelReferenceTableWire {
    fn from(value: CatiaDesignParallelReferenceTable) -> Self {
        Self {
            columns: value.columns,
            rows: value.rows,
        }
    }
}

impl TryFrom<CatiaDesignParallelReferenceTableWire> for CatiaDesignParallelReferenceTable {
    type Error = String;

    fn try_from(wire: CatiaDesignParallelReferenceTableWire) -> Result<Self, Self::Error> {
        Self::new(wire.columns, wire.rows)
            .ok_or_else(|| "parallel reference row width disagrees with column count".to_owned())
    }
}

/// One serialized design object formed by a shared `7C09` owner identity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaDesignObject {
    /// Globally unique design-object identity.
    pub(crate) id: String,
    /// Containing [`CatiaObjectGraph`] identity.
    pub(crate) parent: String,
    /// Zero-based order of this owner group by its first field in the graph.
    pub(crate) ordinal: u64,
    /// Byte offset of the first field carrying this owner identity.
    pub(crate) first_field_byte_offset: u64,
    /// Owner entity identity stored by every field record.
    pub(crate) owner_entity_id: u32,
    /// Record selected by `owner_entity_id` when it lies inside the graph.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) owner_record: Option<String>,
    /// Design object whose field set contains `owner_record`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) owner_design_object: Option<String>,
    /// Exact class of a separator-form owner declaration.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) owner_class: Option<CatiaDesignClass>,
    /// Class-specific storage selector of a separator-form owner declaration.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) owner_storage_ref: Option<u32>,
    /// Field records carrying this owner identity, in serialized order.
    pub(crate) fields: Vec<String>,
    /// Distinct exact field classes, in first field order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) field_classes: Vec<CatiaDesignClass>,
    /// Entity records carrying definition-bound values, in field order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) definition_values: Vec<String>,
    /// Entity records carrying two-definition values, in field order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) definition_chain_values: Vec<String>,
    /// Exact inter-object reference occurrences in field and payload order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) relations: Vec<CatiaDesignObjectRelation>,
    /// Complete row-aligned table formed by parallel all-reference list fields.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) parallel_reference_table: Option<CatiaDesignParallelReferenceTable>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) sketch_membership: Option<Box<sketch_bindings::CatiaSketchMembership>>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) local_point_pairs: Vec<sketch_bindings::CatiaLocalPointPair>,
}

fn design_objects(
    ctx: &DecodeContext<'_>,
    graphs: &[CatiaObjectGraph],
    entity_records: &[CatiaEntityRecord],
) -> Result<Vec<CatiaDesignObject>, CodecError> {
    let definition_value_entities = entity_records
        .iter()
        .filter(|entity| entity.definition_value().is_some())
        .map(|entity| entity.id.as_str())
        .collect::<std::collections::HashSet<_>>();
    let definition_chain_value_entities = entity_records
        .iter()
        .filter(|entity| entity.definition_chain_value().is_some())
        .map(|entity| entity.id.as_str())
        .collect::<std::collections::HashSet<_>>();
    let mut objects = Vec::new();
    for graph in graphs {
        let record_indices = graph
            .records
            .iter()
            .enumerate()
            .filter_map(|(index, record)| Some((record.entity_id()?, index)))
            .collect::<std::collections::HashMap<_, _>>();
        let terminal_null_entity_id = terminal_null_entity_id(&record_indices);
        let mut fields = Vec::<(u32, Vec<&CatiaObjectRecord>)>::new();
        let mut owner_indices = HashMap::<u32, usize>::new();
        for record in &graph.records {
            if let Some(owner) = record.owner_entity_id() {
                let index = if let Some(index) = owner_indices.get(&owner) {
                    *index
                } else {
                    let index = fields.len();
                    fields.push((owner, Vec::new()));
                    owner_indices.insert(owner, index);
                    index
                };
                fields[index].1.push(record);
            }
        }
        for (ordinal, (owner_entity_id, records)) in fields.into_iter().enumerate() {
            let Some(first_record) = records.first() else {
                continue;
            };
            let owner_record = record_indices
                .get(&owner_entity_id)
                .and_then(|index| graph.records.get(*index));
            let id = design_object_id(graph.byte_offset, owner_entity_id);
            let owner_design_object = owner_record
                .and_then(CatiaObjectRecord::owner_entity_id)
                .filter(|owner| *owner != owner_entity_id && owner_indices.contains_key(owner))
                .map(|owner| design_object_id(graph.byte_offset, owner));
            let owner_class = match owner_record.filter(|record| record_has_separator_roles(record))
            {
                Some(record) => design_class(ctx, record)?,
                None => None,
            };
            let mut field_ids = Vec::new();
            let mut field_classes = Vec::new();
            let mut distinct_field_classes = HashSet::new();
            let mut definition_values = Vec::new();
            let mut definition_chain_values = Vec::new();
            let mut relations = Vec::new();
            for record in &records {
                field_ids.push(record.id.clone());
                if let Some(class) = design_class(ctx, record)? {
                    if distinct_field_classes.insert(class.clone()) {
                        field_classes.push(class);
                    }
                }
                if let Some(entity) = record.entity_record() {
                    if definition_value_entities.contains(entity) {
                        definition_values.push(entity.to_owned());
                    }
                    if definition_chain_value_entities.contains(entity) {
                        definition_chain_values.push(entity.to_owned());
                    }
                }
                if let (Some(target_field), Some(storage_ref)) =
                    (record.storage_record(), record.storage_ref())
                {
                    if let Some(target_record) = record_indices
                        .get(&storage_ref)
                        .and_then(|index| graph.records.get(*index))
                    {
                        let relation = CatiaDesignObjectRelation {
                            source_field: record.id.clone(),
                            source_class: design_class(ctx, record)?,
                            source: CatiaDesignObjectRelationSource::Storage,
                            target_entity_id: storage_ref,
                            target_field: target_field.to_owned(),
                            target_class: design_class(ctx, target_record)?,
                            target_design_object: record
                                .storage_design_object()
                                .map(std::borrow::ToOwned::to_owned),
                        };
                        relations.push(relation);
                    }
                }
                for reference in &record.references {
                    let Some(target_field) = reference.target() else {
                        continue;
                    };
                    let Some(target_record) = record_indices
                        .get(&reference.entity_id())
                        .and_then(|index| graph.records.get(*index))
                    else {
                        continue;
                    };
                    let relation = CatiaDesignObjectRelation {
                        source_field: record.id.clone(),
                        source_class: design_class(ctx, record)?,
                        source: CatiaDesignObjectRelationSource::Payload {
                            payload_offset: reference.payload_offset(),
                            container: reference.source().clone(),
                        },
                        target_entity_id: reference.entity_id(),
                        target_field: target_field.to_owned(),
                        target_class: design_class(ctx, target_record)?,
                        target_design_object: reference
                            .design_object()
                            .map(std::borrow::ToOwned::to_owned),
                    };
                    relations.push(relation);
                }
            }
            let parallel_reference_table = design_parallel_reference_table(
                ctx,
                &records,
                graph,
                &record_indices,
                terminal_null_entity_id,
            )?;
            let object = CatiaDesignObject {
                id,
                parent: graph.id.clone(),
                ordinal: u64_from_index(ordinal),
                first_field_byte_offset: first_record.byte_offset,
                owner_entity_id,
                owner_record: owner_record.map(|record| record.id.clone()),
                owner_design_object,
                owner_class,
                owner_storage_ref: owner_record
                    .filter(|record| record_has_separator_roles(record))
                    .and_then(CatiaObjectRecord::storage_ref),
                fields: field_ids,
                field_classes,
                definition_values,
                definition_chain_values,
                relations,
                parallel_reference_table,
                sketch_membership: None,
                local_point_pairs: Vec::new(),
            };
            objects.push(object);
        }
    }
    sketch_bindings::bind(ctx, graphs, entity_records, &mut objects)?;
    Ok(objects)
}

fn design_parallel_reference_table(
    ctx: &DecodeContext<'_>,
    records: &[&CatiaObjectRecord],
    graph: &CatiaObjectGraph,
    record_indices: &HashMap<u32, usize>,
    terminal_null_entity_id: Option<u32>,
) -> Result<Option<CatiaDesignParallelReferenceTable>, CodecError> {
    if records.len() < 2 {
        return Ok(None);
    }
    let mut columns = Vec::new();
    for record in records {
        let [PayloadField::List {
            declared_count,
            items,
            offset: list_offset,
        }, middle @ .., PayloadField::Terminator] = record.payload.fields.as_slice()
        else {
            return Ok(None);
        };
        if *declared_count < 2
            || usize::try_from(*declared_count).ok() != Some(items.len())
            || !middle
                .iter()
                .all(|field| matches!(field, PayloadField::Atom { .. }))
            || !items
                .iter()
                .all(|item| matches!(item, ListItem::Reference { .. }))
        {
            return Ok(None);
        }
        let column = (
            CatiaDesignReferenceColumn {
                field: record.id.clone(),
                field_class: design_class(ctx, record)?,
                list_payload_offset: u64_from_index(*list_offset),
            },
            items.as_slice(),
        );
        columns.push(column);
    }
    let Some((_, first_items)) = columns.first() else {
        return Ok(None);
    };
    let row_count = first_items.len();
    if columns
        .iter()
        .any(|(_, references)| references.len() != row_count)
    {
        return Ok(None);
    }
    let mut rows = Vec::new();
    for row in 0..row_count {
        let mut cells = Vec::new();
        for (_, references) in &columns {
            let ListItem::Reference {
                value: target_entity_id,
                offset: payload_offset,
            } = &references[row]
            else {
                return Ok(None);
            };
            let target = record_indices
                .get(target_entity_id)
                .and_then(|index| graph.records.get(*index));
            let target_class = match target {
                Some(record) => design_class(ctx, record)?,
                None => None,
            };
            let cell = CatiaDesignReferenceCell::from_parts(
                u64_from_index(*payload_offset),
                *target_entity_id,
                Some(*target_entity_id) == terminal_null_entity_id,
                target.map(|record| record.id.clone()),
                target_class,
                target
                    .and_then(|record| record.design_object.as_deref())
                    .map(std::borrow::ToOwned::to_owned),
            );
            cells.push(cell);
        }
        let matching_design_object = cells
            .first()
            .and_then(|cell| cell.design_object())
            .filter(|member| {
                columns.iter().zip(&cells).all(|((column, _), cell)| {
                    column.field_class.is_some()
                        && cell.field().is_some()
                        && cell.field_class() == column.field_class.as_ref()
                        && cell.design_object() == Some(*member)
                }) && {
                    let mut fields = HashSet::new();
                    cells.iter().all(|cell| fields.insert(cell.field()))
                }
            })
            .map(std::borrow::ToOwned::to_owned);
        let reference_row = CatiaDesignReferenceRow {
            cells,
            matching_design_object,
        };
        rows.push(reference_row);
    }
    let columns = columns
        .into_iter()
        .map(|(column, _)| column)
        .collect::<Vec<_>>();
    Ok(CatiaDesignParallelReferenceTable::new(columns, rows))
}

const CLASS_TEXT_OPERATION: &str = "retain CATIA schema class text";

/// Charge one retained copy of a schema class's entry identity and name. A
/// catalog entry is shared by every record, reference and selector that names
/// its ordinal, so each copy is charged before it is made.
fn charge_class_text(ctx: &DecodeContext<'_>, entry: &str, name: &str) -> Result<(), CodecError> {
    ctx.retain_bytes(
        u64_from_index(entry.len() + name.len()),
        CLASS_TEXT_OPERATION,
    )
}

/// Copy a class name that an entity reference keeps, charging the copy like
/// [`charge_class_text`] does. Many references can name one class.
fn retained_class_name(
    ctx: &DecodeContext<'_>,
    name: Option<&str>,
) -> Result<Option<String>, CodecError> {
    let Some(name) = name else {
        return Ok(None);
    };
    ctx.retain_bytes(u64_from_index(name.len()), CLASS_TEXT_OPERATION)?;
    Ok(Some(name.to_owned()))
}

fn design_class(
    ctx: &DecodeContext<'_>,
    record: &CatiaObjectRecord,
) -> Result<Option<CatiaDesignClass>, CodecError> {
    let (Some(entry), Some(name)) = (record.class_entry(), record.class_name()) else {
        return Ok(None);
    };
    charge_class_text(ctx, entry, name)?;
    Ok(Some(CatiaDesignClass {
        entry: entry.to_owned(),
        name: name.to_owned(),
    }))
}

fn record_has_separator_roles(record: &CatiaObjectRecord) -> bool {
    matches!(record.head.get(1), Some(HeadToken::Separator))
}

fn design_object_id(graph_offset: u64, owner_entity_id: u32) -> String {
    format!("catia:outer:design-object#{graph_offset:010}-{owner_entity_id:010}")
}

fn payload_references(
    payload: &ObjectPayload,
) -> impl Iterator<Item = (u32, usize, CatiaObjectRecordReferenceSource)> + '_ {
    payload.fields.iter().flat_map(|field| {
        let single = match field {
            PayloadField::Reference { value, offset } => {
                Some((*value, *offset, CatiaObjectRecordReferenceSource::Field))
            }
            _ => None,
        };
        let list = match field {
            PayloadField::List {
                declared_count,
                items,
                offset,
            } if usize::try_from(*declared_count).ok() == Some(items.len()) => {
                Some((items.as_slice(), *offset))
            }
            _ => None,
        };
        single
            .into_iter()
            .chain(list.into_iter().flat_map(|(items, list_offset)| {
                items
                    .iter()
                    .enumerate()
                    .filter_map(move |(item_ordinal, item)| match item {
                        ListItem::Reference { value, offset } => Some((
                            *value,
                            *offset,
                            CatiaObjectRecordReferenceSource::ListItem {
                                list_payload_offset: u64_from_index(list_offset),
                                item_ordinal: u64_from_index(item_ordinal),
                            },
                        )),
                        ListItem::Atom { .. } => None,
                    })
            }))
    })
}

fn resolved_payload_references(
    payload: &ObjectPayload,
    records: &[CatiaObjectRecord],
    record_indices: &HashMap<u32, usize>,
    terminal_null_entity_id: Option<u32>,
) -> Vec<CatiaObjectRecordReference> {
    let mut references = Vec::new();
    for (entity_id, payload_offset, source) in payload_references(payload) {
        let target = record_indices
            .get(&entity_id)
            .and_then(|index| records.get(*index));
        let record = CatiaObjectRecordReference::from_parts(
            entity_id,
            u64_from_index(payload_offset),
            source,
            Some(entity_id) == terminal_null_entity_id,
            target.map(|record| record.id.clone()),
            target
                .and_then(|record| record.design_object.as_deref())
                .map(std::borrow::ToOwned::to_owned),
        );
        references.push(record);
    }
    references
}

fn terminal_null_entity_id(record_indices: &HashMap<u32, usize>) -> Option<u32> {
    record_indices.keys().max()?.checked_add(1)
}

fn resolved_storage_link(
    storage_ref: Option<u32>,
    records: &[CatiaObjectRecord],
    record_indices: &HashMap<u32, usize>,
) -> (Option<String>, Option<String>) {
    let Some(index) = storage_ref.and_then(|identity| record_indices.get(&identity).copied())
    else {
        return (None, None);
    };
    let target = records.get(index);
    (
        target.map(|record| record.id.clone()),
        target
            .and_then(|record| record.design_object.as_deref())
            .map(std::borrow::ToOwned::to_owned),
    )
}

fn definition_schema_selections(
    ctx: &DecodeContext<'_>,
    selectors: &[entity_table::DefinitionSchemaSelector],
    catalog: Option<&CatiaCatalog>,
) -> Result<Vec<CatiaDefinitionSchemaSelection>, CodecError> {
    let mut selections = Vec::new();
    for selector in selectors {
        let catalog_entry = usize::try_from(selector.value)
            .ok()
            .and_then(|ordinal| catalog?.entries.get(ordinal));
        if let Some(entry) = catalog_entry {
            charge_class_text(ctx, &entry.id, &entry.value)?;
        }
        let selection = CatiaDefinitionSchemaSelection {
            offset: u64_from_index(selector.offset),
            ordinal: selector.value,
            entry: catalog_entry.map(|entry| entry.id.clone()),
            name: catalog_entry.map(|entry| entry.value.clone()),
        };
        selections.push(selection);
    }
    Ok(selections)
}

fn entity_value_schema_selections(
    ctx: &DecodeContext<'_>,
    fields: &[value_block::ValueField],
    catalog: Option<&CatiaCatalog>,
    packets: &[entity_table::EntityValuePacket],
) -> Result<Vec<CatiaEntityValueSchemaSelection>, CodecError> {
    let Some(catalog) = catalog else {
        return Ok(Vec::new());
    };
    let selector_indices = fields
        .iter()
        .enumerate()
        .filter_map(|(index, field)| {
            let value_block::ValueField::SchemaSelector { ordinal, .. } = field else {
                return None;
            };
            usize::try_from(*ordinal)
                .ok()
                .filter(|ordinal| *ordinal < catalog.entries.len())
                .map(|_| index)
        })
        .collect::<Vec<_>>();
    let mut packets_by_start = packets
        .iter()
        .enumerate()
        .filter_map(|(packet, value)| value.byte_range().map(|range| (range, packet)))
        .collect::<Vec<_>>();
    packets_by_start.sort_unstable_by_key(|(range, packet)| (range.start, *packet));
    let mut selections = Vec::new();
    for (rank, index) in selector_indices.iter().enumerate() {
        let value_block::ValueField::SchemaSelector { ordinal, offset } = &fields[*index] else {
            continue;
        };
        let Some(catalog_entry) = usize::try_from(*ordinal)
            .ok()
            .and_then(|ordinal| catalog.entries.get(ordinal))
        else {
            continue;
        };
        let value_end = selector_indices
            .get(rank + 1)
            .copied()
            .unwrap_or(fields.len());
        let value_start_offset = fields.get(index + 1).map(value_field_offset);
        let value_end_offset = fields.get(value_end).map(value_field_offset);
        let mut selected = Vec::new();
        if let Some(start) = value_start_offset {
            let first = packets_by_start.partition_point(|(range, _)| range.start < start);
            // A packet range never ends before it starts, so a packet that
            // starts past the value end cannot end inside it.
            selected.extend(
                packets_by_start[first..]
                    .iter()
                    .take_while(|(range, _)| value_end_offset.is_none_or(|end| range.start <= end))
                    .filter(|(range, _)| value_end_offset.is_none_or(|end| range.end <= end))
                    .map(|(_, packet)| *packet),
            );
            selected.sort_unstable();
        }
        let selected_packets = selected
            .into_iter()
            .map(|packet| packets[packet].clone())
            .collect();
        charge_class_text(ctx, &catalog_entry.id, &catalog_entry.value)?;
        let selection = CatiaEntityValueSchemaSelection {
            offset: u64_from_index(*offset),
            ordinal: *ordinal,
            entry: catalog_entry.id.clone(),
            name: catalog_entry.value.clone(),
            encoded_value: fields[index + 1..value_end].to_vec(),
            packets: selected_packets,
        };
        selections.push(selection);
    }
    Ok(selections)
}

fn entity_suffix_schema_selection(
    ctx: &DecodeContext<'_>,
    suffix_value: Option<&CatiaEntitySuffixValue>,
    catalog: Option<&CatiaCatalog>,
) -> Result<Option<CatiaEntitySuffixSchemaSelection>, CodecError> {
    let Some(suffix_value) = suffix_value else {
        return Ok(None);
    };
    let CatiaEntitySuffixPayload::SchemaSelected {
        selector_offset,
        selector,
        value,
    } = &suffix_value.payload
    else {
        return Ok(None);
    };
    let Some(entry) = usize::try_from(*selector)
        .ok()
        .and_then(|ordinal| catalog.and_then(|catalog| catalog.entries.get(ordinal)))
    else {
        return Ok(None);
    };
    let value = match value {
        CatiaEntitySuffixSchemaValue::Atom { value } => {
            CatiaEntitySuffixSchemaValue::Atom { value: *value }
        }
        CatiaEntitySuffixSchemaValue::Evaluation {
            opcode_offset,
            evaluation,
        } => CatiaEntitySuffixSchemaValue::Evaluation {
            opcode_offset: *opcode_offset,
            evaluation: evaluation.clone(),
        },
        CatiaEntitySuffixSchemaValue::Separator37 => CatiaEntitySuffixSchemaValue::Separator37,
        CatiaEntitySuffixSchemaValue::SchemaSelector {
            offset, ordinal, ..
        } => {
            let selected = usize::try_from(*ordinal)
                .ok()
                .and_then(|ordinal| catalog.and_then(|catalog| catalog.entries.get(ordinal)));
            if let Some(selected) = selected {
                charge_class_text(ctx, &selected.id, &selected.value)?;
            }
            CatiaEntitySuffixSchemaValue::SchemaSelector {
                offset: *offset,
                ordinal: *ordinal,
                resolution: selected.map(|entry| CatiaDesignClass {
                    entry: entry.id.clone(),
                    name: entry.value.clone(),
                }),
            }
        }
    };
    charge_class_text(ctx, &entry.id, &entry.value)?;
    Ok(Some(CatiaEntitySuffixSchemaSelection {
        offset: *selector_offset,
        ordinal: *selector,
        entry: entry.id.clone(),
        name: entry.value.clone(),
        value,
    }))
}

fn copy_value_schema(selection: &CatiaEntityValueSchemaSelection) -> CatiaEntitySchemaValue {
    CatiaEntitySchemaValue {
        offset: selection.offset,
        ordinal: selection.ordinal,
        entry: selection.entry.clone(),
        value: selection.name.clone(),
    }
}

fn copy_definition_schema(
    selection: &CatiaDefinitionSchemaSelection,
) -> Option<CatiaEntitySchemaValue> {
    let (Some(entry), Some(value)) = (selection.entry.as_ref(), selection.name.as_ref()) else {
        return None;
    };
    Some(CatiaEntitySchemaValue {
        offset: selection.offset,
        ordinal: selection.ordinal,
        entry: entry.to_owned(),
        value: value.to_owned(),
    })
}

fn value_production(
    ctx: &DecodeContext<'_>,
    entity: &CatiaEntityRecord,
    incidences: &EntityIncidenceIndex<'_>,
    value_fields: &[value_block::ValueField],
) -> Result<Option<CatiaEntityValueProduction>, CodecError> {
    if let Some(relation) = relation_expression(
        &entity.definition_schema_selections,
        &entity.value_schema_selections,
    ) {
        return Ok(Some(CatiaEntityValueProduction::RelationExpression(
            relation,
        )));
    }
    if let Some(parameter) = parameter_value(
        entity.lead,
        &entity.value_schema_selections,
        entity.suffix_value(),
    ) {
        return Ok(Some(CatiaEntityValueProduction::ParameterValue(parameter)));
    }
    if let Some(range) = resolved_constraint_range(
        ctx,
        entity.lead,
        &entity.value_schema_selections,
        entity.suffix_value(),
        incidences,
        entity.entity_id,
    )? {
        return Ok(Some(CatiaEntityValueProduction::ConstraintRange(range)));
    }
    if let Some(definition) = definition_value(
        entity.lead,
        &entity.definition_schema_selections,
        value_fields,
        entity.suffix_value(),
        entity.suffix_schema_selection.as_ref(),
    ) {
        return Ok(Some(CatiaEntityValueProduction::DefinitionValue(
            definition,
        )));
    }
    Ok(definition_chain_value(
        entity.lead,
        &entity.definition_schema_selections,
        value_fields,
        entity.suffix_value(),
        entity.suffix_schema_selection.as_ref(),
    )
    .map(CatiaEntityValueProduction::DefinitionChainValue))
}

fn relation_expression(
    definitions: &[CatiaDefinitionSchemaSelection],
    values: &[CatiaEntityValueSchemaSelection],
) -> Option<CatiaRelationExpression> {
    let [definition0, definition1] = definitions else {
        return None;
    };
    if definition0.name.as_deref() != Some("body")
        || definition1.name.as_deref() != Some("body")
        || definition0.entry != definition1.entry
    {
        return None;
    }
    let (framing, expression, parameter_role, type_signature, function_role) = match values {
        [prefix_role, expression, parser_version_role, parameter_role, type_signature, state_role, function_role]
            if prefix_role.name == "Boolean"
                && parser_version_role.name == "ParserVersion"
                && parameter_role.name == "param"
                && state_role.name == "opened"
                && function_role.name == "RelationExpFct" =>
        {
            (
                CatiaRelationExpressionFraming::OpenedBooleanParserVersion {
                    prefix_role: copy_value_schema(prefix_role),
                    parser_version_role: copy_value_schema(parser_version_role),
                    state_role: copy_value_schema(state_role),
                },
                expression,
                parameter_role,
                type_signature,
                function_role,
            )
        }
        [placeholder, expression, parameter_role, type_signature, state_role, function_role]
            if parameter_role.name == "param"
                && state_role.name == "opened"
                && function_role.name == "RelationExpFct" =>
        {
            (
                CatiaRelationExpressionFraming::PlaceholderState {
                    placeholder: copy_value_schema(placeholder),
                    state_role: copy_value_schema(state_role),
                },
                expression,
                parameter_role,
                type_signature,
                function_role,
            )
        }
        [prefix_role, expression, parser_version_role, parameter_role, type_signature, function_role]
            if prefix_role.name == "Boolean"
                && parser_version_role.name == "ParserVersion"
                && parameter_role.name == "param"
                && function_role.name == "RelationExpFct" =>
        {
            (
                CatiaRelationExpressionFraming::BooleanParserVersion {
                    prefix_role: copy_value_schema(prefix_role),
                    parser_version_role: copy_value_schema(parser_version_role),
                },
                expression,
                parameter_role,
                type_signature,
                function_role,
            )
        }
        [expression, parser_version_role, parameter_role, type_signature, function_role]
            if parser_version_role.name == "ParserVersion"
                && parameter_role.name == "param"
                && function_role.name == "RelationExpFct" =>
        {
            (
                CatiaRelationExpressionFraming::ParserVersion {
                    parser_version_role: copy_value_schema(parser_version_role),
                },
                expression,
                parameter_role,
                type_signature,
                function_role,
            )
        }
        _ => return None,
    };
    Some(CatiaRelationExpression {
        framing,
        expression: copy_value_schema(expression),
        parameter_role: copy_value_schema(parameter_role),
        type_signature: copy_value_schema(type_signature),
        function_role: copy_value_schema(function_role),
    })
}

fn relation_type_signature(
    placeholder: Option<&str>,
    source: &str,
) -> Option<CatiaRelationTypeSignature> {
    let source = source.strip_suffix('\n').unwrap_or(source);
    let (input_clause, result_type) = source.rsplit_once(") : ")?;
    let input_clause = input_clause.strip_prefix('(')?;
    if result_type.is_empty() || result_type.trim() != result_type {
        return None;
    }
    let inputs = if input_clause.is_empty() {
        Vec::new()
    } else {
        input_clause
            .split(',')
            .map(|clause| {
                let (parameter, input_type) = clause.split_once(':')?;
                let parameter = parameter.trim();
                let input_type = input_type.trim().strip_prefix("#In")?.trim();
                (relation_parameter_symbol(parameter) && !input_type.is_empty()).then(|| {
                    CatiaRelationTypeInput {
                        parameter: parameter.to_string(),
                        input_type: input_type.to_string(),
                    }
                })
            })
            .collect::<Option<Vec<_>>>()?
    };
    if placeholder.is_some_and(|placeholder| {
        inputs.is_empty() && !placeholder.trim().is_empty()
            || inputs
                .first()
                .is_some_and(|input| input.parameter != placeholder.trim())
    }) || inputs
        .iter()
        .map(|input| input.parameter.as_str())
        .collect::<HashSet<_>>()
        .len()
        != inputs.len()
    {
        return None;
    }
    Some(CatiaRelationTypeSignature {
        inputs,
        result_type: result_type.to_string(),
    })
}

fn relation_parameter_symbol(parameter: &str) -> bool {
    parameter
        .strip_prefix('#')
        .and_then(|parameter| parameter.strip_suffix('_'))
        .is_some_and(|digits| {
            !digits.is_empty() && digits.bytes().all(|byte| byte.is_ascii_digit())
        })
}

fn parameter_value(
    lead: u8,
    values: &[CatiaEntityValueSchemaSelection],
    suffix_value: Option<&CatiaEntitySuffixValue>,
) -> Option<CatiaParameterValue> {
    if lead != 2 {
        return None;
    }
    let [name, binding] = values else {
        return None;
    };
    let suffix_value = suffix_value?;
    if !(suffix_value.prefix_atoms == [5, 22, 2]
        && suffix_value.prefix_atom_widths == [1, 1, 1]
        && suffix_value.prefix_code == 0x6a
        && suffix_value.trailer == CatiaEntitySuffixTrailer::Token8152)
    {
        return None;
    }
    let CatiaEntitySuffixPayload::Evaluation {
        opcode_offset,
        evaluation,
        encoding: CatiaEntityEvaluationEncoding::Direct,
    } = &suffix_value.payload
    else {
        return None;
    };
    Some(CatiaParameterValue {
        name: copy_value_schema(name),
        binding: copy_value_schema(binding),
        evaluation: evaluation.clone(),
        evaluation_opcode_offset: *opcode_offset,
    })
}

fn constraint_range(
    lead: u8,
    values: &[CatiaEntityValueSchemaSelection],
    suffix_value: Option<&CatiaEntitySuffixValue>,
) -> Option<CatiaConstraintRange> {
    if lead != 2 {
        return None;
    }
    let [range, constraint] = values else {
        return None;
    };
    if range.name != "Range" {
        return None;
    }
    let suffix_value = suffix_value?;
    if suffix_value.prefix_atoms != [4, 22, 2] || suffix_value.prefix_atom_widths != [1, 1, 1] {
        return None;
    }
    let framing = match (
        constraint.name.as_str(),
        suffix_value.prefix_code,
        suffix_value.trailer,
    ) {
        ("CstAttr_Dimension", 0xb8, CatiaEntitySuffixTrailer::Empty) => {
            CatiaConstraintRangeFraming::DimensionB8
        }
        ("CstAttr_Dimension", 0xc1, CatiaEntitySuffixTrailer::Empty) => {
            CatiaConstraintRangeFraming::DimensionC1
        }
        ("CstAttr_Dimension", 0xdc, CatiaEntitySuffixTrailer::Token81DB) => {
            CatiaConstraintRangeFraming::DimensionDC
        }
        ("CstAttr_Dimension", 0xdf, CatiaEntitySuffixTrailer::Token8192) => {
            CatiaConstraintRangeFraming::DimensionDF
        }
        ("ComplexCst", 0xc9, CatiaEntitySuffixTrailer::Empty) => {
            CatiaConstraintRangeFraming::ComplexC9
        }
        _ => return None,
    };
    let CatiaEntitySuffixPayload::Evaluation {
        opcode_offset,
        evaluation,
        encoding: CatiaEntityEvaluationEncoding::Direct,
    } = &suffix_value.payload
    else {
        return None;
    };
    Some(CatiaConstraintRange {
        range: copy_value_schema(range),
        constraint: copy_value_schema(constraint),
        framing,
        evaluation: evaluation.clone(),
        evaluation_opcode_offset: *opcode_offset,
        incoming_references: Vec::new(),
        incoming_storage_references: Vec::new(),
    })
}

fn incidence_source_entity(
    ctx: &DecodeContext<'_>,
    record: &CatiaObjectRecord,
) -> Result<Option<CatiaEntityReference>, CodecError> {
    let Some(entity_id) = record.entity_id() else {
        return Ok(None);
    };
    let entity = record.entity_record().map(std::borrow::ToOwned::to_owned);
    let class_name = if entity.is_some() {
        retained_class_name(ctx, record.class_name())?
    } else {
        None
    };
    Ok(Some(CatiaEntityReference::resolved_or_unresolved(
        entity_id, entity, class_name,
    )))
}

/// The references and storage references that the records of one object
/// graph hold to each entity, in record order and then reference order.
pub(super) struct EntityIncidenceIndex<'a> {
    records: &'a [CatiaObjectRecord],
    references: HashMap<u32, Vec<(usize, usize)>>,
    storage: HashMap<u32, Vec<usize>>,
}

impl<'a> EntityIncidenceIndex<'a> {
    /// Indexes the records of `records` whose parent is `graph_id`.
    pub(super) fn new(records: &'a [CatiaObjectRecord], graph_id: &str) -> Self {
        let mut references = HashMap::<u32, Vec<(usize, usize)>>::new();
        let mut storage = HashMap::<u32, Vec<usize>>::new();
        for (record_index, record) in records.iter().enumerate() {
            if record.parent != graph_id {
                continue;
            }
            for (reference_index, reference) in record.references.iter().enumerate() {
                references
                    .entry(reference.entity_id())
                    .or_default()
                    .push((record_index, reference_index));
            }
            if let Some(entity_id) = record.storage_ref() {
                storage.entry(entity_id).or_default().push(record_index);
            }
        }
        Self {
            records,
            references,
            storage,
        }
    }

    pub(super) fn incidences(
        &self,
        ctx: &DecodeContext<'_>,
        entity_id: u32,
    ) -> Result<
        (
            Vec<CatiaEntityIncomingReference>,
            Vec<CatiaEntityIncomingStorageReference>,
        ),
        CodecError,
    > {
        let incoming_references = self
            .references
            .get(&entity_id)
            .into_iter()
            .flatten()
            .map(|&(record_index, reference_index)| {
                let record = &self.records[record_index];
                let reference = &record.references[reference_index];
                Ok(CatiaEntityIncomingReference {
                    object_record: record.id.clone(),
                    source_entity: incidence_source_entity(ctx, record)?,
                    payload_offset: reference.payload_offset(),
                    source: reference.source().clone(),
                })
            })
            .collect::<Result<_, CodecError>>()?;
        let incoming_storage_references = self
            .storage
            .get(&entity_id)
            .into_iter()
            .flatten()
            .map(|&record_index| {
                let record = &self.records[record_index];
                Ok(CatiaEntityIncomingStorageReference {
                    object_record: record.id.clone(),
                    source_entity: incidence_source_entity(ctx, record)?,
                })
            })
            .collect::<Result<_, CodecError>>()?;
        Ok((incoming_references, incoming_storage_references))
    }
}

fn resolved_range_interval(
    ctx: &DecodeContext<'_>,
    payload: &[u8],
    values: &[CatiaEntityValueSchemaSelection],
    suffix_value: Option<&CatiaEntitySuffixValue>,
    incidences: &EntityIncidenceIndex<'_>,
    entity_id: u32,
) -> Result<Option<CatiaRangeInterval>, CodecError> {
    let Some(mut interval) = range_interval(payload, values, suffix_value) else {
        return Ok(None);
    };
    (
        interval.incoming_references,
        interval.incoming_storage_references,
    ) = incidences.incidences(ctx, entity_id)?;
    Ok(Some(interval))
}

fn range_interval(
    payload: &[u8],
    values: &[CatiaEntityValueSchemaSelection],
    suffix_value: Option<&CatiaEntitySuffixValue>,
) -> Option<CatiaRangeInterval> {
    let mut matches = values
        .iter()
        .enumerate()
        .filter(|(_, selection)| selection.name == "Range");
    let (index, range) = matches.next()?;
    if matches.next().is_some() {
        return None;
    }
    let start = usize::try_from(range.offset)
        .ok()
        .and_then(|offset| offset.checked_add(5))?;
    let end = match values.get(index + 1) {
        Some(selection) => {
            let Ok(end) = usize::try_from(selection.offset) else {
                return None;
            };
            end
        }
        None => payload.len(),
    };
    let interval = entity_table::parse_range_interval(payload, start, end)?;
    Some(CatiaRangeInterval {
        range: copy_value_schema(range),
        interval,
        nominal: range_nominal(suffix_value),
        incoming_references: Vec::new(),
        incoming_storage_references: Vec::new(),
        project_target: None,
    })
}

fn range_nominal(suffix_value: Option<&CatiaEntitySuffixValue>) -> Option<CatiaRangeNominal> {
    let suffix = suffix_value?;
    if suffix.prefix_atoms != [4, 22, 2] || suffix.prefix_atom_widths != [1, 1, 1] {
        return None;
    }
    let framing = match (suffix.prefix_code, suffix.trailer) {
        (0xd8, CatiaEntitySuffixTrailer::Token8193) => CatiaRangeNominalFraming::D8Token8193,
        (0xd8, CatiaEntitySuffixTrailer::Token81DB) => CatiaRangeNominalFraming::D8Token81DB,
        (0xdc, CatiaEntitySuffixTrailer::Token81DB) => CatiaRangeNominalFraming::DCToken81DB,
        (0xdf, CatiaEntitySuffixTrailer::Token8192) => CatiaRangeNominalFraming::DFToken8192,
        _ => return None,
    };
    let CatiaEntitySuffixPayload::Evaluation {
        opcode_offset,
        ref evaluation,
        encoding: CatiaEntityEvaluationEncoding::Direct,
    } = suffix.payload
    else {
        return None;
    };
    let bits = evaluation.bits()?;
    Some(CatiaRangeNominal {
        framing,
        bits,
        evaluation_opcode_offset: opcode_offset,
    })
}

fn resolved_constraint_range(
    ctx: &DecodeContext<'_>,
    lead: u8,
    values: &[CatiaEntityValueSchemaSelection],
    suffix_value: Option<&CatiaEntitySuffixValue>,
    incidences: &EntityIncidenceIndex<'_>,
    entity_id: u32,
) -> Result<Option<CatiaConstraintRange>, CodecError> {
    let Some(mut range) = constraint_range(lead, values, suffix_value) else {
        return Ok(None);
    };
    (range.incoming_references, range.incoming_storage_references) =
        incidences.incidences(ctx, entity_id)?;
    Ok(Some(range))
}

fn definition_value(
    lead: u8,
    definitions: &[CatiaDefinitionSchemaSelection],
    value_fields: &[value_block::ValueField],
    suffix_value: Option<&CatiaEntitySuffixValue>,
    suffix_schema_selection: Option<&CatiaEntitySuffixSchemaSelection>,
) -> Option<CatiaDefinitionValue> {
    if lead != 2
        || !matches!(
            value_fields,
            [value_block::ValueField::Terminator { offset: 0 }]
        )
    {
        return None;
    }
    let [definition] = definitions else {
        return None;
    };
    let suffix_value = suffix_value?;
    let definition = copy_definition_schema(definition)?;
    Some(CatiaDefinitionValue {
        definition,
        payload: suffix_value.payload.clone(),
        schema_selection: suffix_schema_selection.cloned(),
    })
}

fn definition_chain_value(
    lead: u8,
    definitions: &[CatiaDefinitionSchemaSelection],
    value_fields: &[value_block::ValueField],
    suffix_value: Option<&CatiaEntitySuffixValue>,
    suffix_schema_selection: Option<&CatiaEntitySuffixSchemaSelection>,
) -> Option<CatiaDefinitionChainValue> {
    if lead != 2
        || !matches!(
            value_fields,
            [value_block::ValueField::Terminator { offset: 0 }]
        )
    {
        return None;
    }
    let [selector, role] = definitions else {
        return None;
    };
    let selector_value = copy_definition_schema(selector)?;
    let role = copy_definition_schema(role)?;
    let suffix_schema_selection = suffix_schema_selection?;
    if suffix_schema_selection.entry != selector_value.entry
        || suffix_schema_selection.name != selector_value.value
    {
        return None;
    }
    let suffix_value = suffix_value?;
    let CatiaEntitySuffixPayload::SchemaSelected { .. } = &suffix_value.payload else {
        return None;
    };
    Some(CatiaDefinitionChainValue {
        selector: selector_value,
        role,
        value: suffix_schema_selection.value.clone(),
    })
}

fn entity_suffix_value(suffix: &[u8]) -> Option<CatiaEntitySuffixValue> {
    let atom = |at: usize| {
        let lead = *suffix.get(at)?;
        match lead {
            0x80..=0xd0 => Some((u32::from(lead - 0x80), 1_u8)),
            0xd1..=0xe4 => Some((
                u32::from(lead - 0xd1) * 256 + u32::from(*suffix.get(at + 1)?) + 1,
                2,
            )),
            _ => None,
        }
    };
    let mut at = 0;
    let (prefix0, width0) = atom(at)?;
    at += usize::from(width0);
    let (prefix1, width1) = atom(at)?;
    at += usize::from(width1);
    let (prefix2, width2) = atom(at)?;
    at += usize::from(width2);
    let prefix_atoms = [prefix0, prefix1, prefix2];
    let prefix_atom_widths = [width0, width1, width2];
    let prefix_code = *suffix.get(at)?;
    let payload_offset = at + 1;
    let (payload, trailer_offset) = if suffix.get(payload_offset..payload_offset + 5)
        == Some(&[0xe6, 0x00, 0x00, 0x00, 0xe6])
    {
        let bits = View::u64_le_at(suffix, payload_offset + 5)?;
        f64::from_bits(bits).is_finite().then_some(())?;
        (
            CatiaEntitySuffixPayload::Evaluation {
                opcode_offset: u64_from_index(payload_offset + 4),
                evaluation: CatiaEntityEvaluation::Scalar { bits },
                encoding: CatiaEntityEvaluationEncoding::ZeroPaddedScalar,
            },
            payload_offset + 13,
        )
    } else if prefix_code == 0x32 {
        let selector = View::u32_le_at(suffix, payload_offset)?;
        let value_offset = payload_offset + 4;
        let (value, trailer_offset) = match *suffix.get(value_offset)? {
            0xe6 => {
                let bits = View::u64_le_at(suffix, value_offset + 1)?;
                f64::from_bits(bits).is_finite().then_some(())?;
                (
                    CatiaEntitySuffixSelectedValue::Evaluation {
                        opcode_offset: u64_from_index(value_offset),
                        evaluation: CatiaEntityEvaluation::Scalar { bits },
                    },
                    value_offset + 9,
                )
            }
            code @ (0xe7 | 0xe8) => (
                CatiaEntitySuffixSelectedValue::Evaluation {
                    opcode_offset: u64_from_index(value_offset),
                    evaluation: if code == 0xe7 {
                        CatiaEntityEvaluation::UnitLiteral
                    } else {
                        CatiaEntityEvaluation::ZeroLiteral
                    },
                },
                value_offset + 1,
            ),
            0x37 => (
                CatiaEntitySuffixSelectedValue::Separator37,
                value_offset + 1,
            ),
            0x32 => (
                CatiaEntitySuffixSelectedValue::SchemaSelector {
                    offset: u64_from_index(value_offset),
                    ordinal: View::u32_le_at(suffix, value_offset + 1)?,
                    resolution: None,
                },
                value_offset + 5,
            ),
            atom @ 0x80..=0xd0 => (
                CatiaEntitySuffixSelectedValue::Atom {
                    value: u32::from(atom - 0x80),
                },
                value_offset + 1,
            ),
            _ => return None,
        };
        (
            CatiaEntitySuffixPayload::SchemaSelected {
                selector_offset: u64_from_index(at),
                selector,
                value,
            },
            trailer_offset,
        )
    } else {
        match *suffix.get(payload_offset)? {
            code @ (0xe7 | 0xe8) => (
                CatiaEntitySuffixPayload::Evaluation {
                    opcode_offset: u64_from_index(payload_offset),
                    evaluation: if code == 0xe7 {
                        CatiaEntityEvaluation::UnitLiteral
                    } else {
                        CatiaEntityEvaluation::ZeroLiteral
                    },
                    encoding: CatiaEntityEvaluationEncoding::Direct,
                },
                payload_offset + 1,
            ),
            0xe9 => (CatiaEntitySuffixPayload::ControlE9, payload_offset + 1),
            0x37 => (CatiaEntitySuffixPayload::Separator37, payload_offset + 1),
            0xe6 => {
                let bits = View::u64_le_at(suffix, payload_offset + 1)?;
                f64::from_bits(bits).is_finite().then_some(())?;
                (
                    CatiaEntitySuffixPayload::Evaluation {
                        opcode_offset: u64_from_index(payload_offset),
                        evaluation: CatiaEntityEvaluation::Scalar { bits },
                        encoding: CatiaEntityEvaluationEncoding::Direct,
                    },
                    payload_offset + 9,
                )
            }
            atom @ 0x80..=0xd0 => (
                CatiaEntitySuffixPayload::Atom {
                    value: u32::from(atom - 0x80),
                },
                payload_offset + 1,
            ),
            _ => return None,
        }
    };
    let trailer = match suffix.get(trailer_offset..)? {
        [] => CatiaEntitySuffixTrailer::Empty,
        [0x81, 0x49] => CatiaEntitySuffixTrailer::Token8149,
        [0x81, 0x4a] => CatiaEntitySuffixTrailer::Token814A,
        [0x81, 0x52] => CatiaEntitySuffixTrailer::Token8152,
        [0x81, 0xdb] => CatiaEntitySuffixTrailer::Token81DB,
        [0x81, 0x92] => CatiaEntitySuffixTrailer::Token8192,
        [0x81, 0x93] => CatiaEntitySuffixTrailer::Token8193,
        [0xfe, 0xf6, rest @ ..] if rest.len() == 16 && rest.iter().all(|byte| *byte == 0) => {
            CatiaEntitySuffixTrailer::FixedZeroFrame
        }
        _ => return None,
    };
    Some(CatiaEntitySuffixValue {
        prefix_atoms,
        prefix_atom_widths: (prefix_atom_widths).into(),
        prefix_code,
        payload,
        trailer,
    })
}

fn entity_suffix_framing(suffix: &[u8]) -> Option<CatiaEntitySuffixFraming> {
    let framing = match suffix {
        [0x80, _, _, _, _, state] => {
            let state = match state {
                0x00 => CatiaEntitySuffixEscapedWordState::State00,
                0x01 => CatiaEntitySuffixEscapedWordState::State01,
                0x03 => CatiaEntitySuffixEscapedWordState::State03,
                0x04 => CatiaEntitySuffixEscapedWordState::State04,
                0x09 => CatiaEntitySuffixEscapedWordState::State09,
                _ => return None,
            };
            CatiaEntitySuffixFraming::EscapedWord(CatiaEntitySuffixEscapedWord {
                word: View::u32_le_at(suffix, 1)?,
                state,
            })
        }
        [0x81, 0x49] => CatiaEntitySuffixFraming::Token8149,
        [0xfe, 0xf6, payload @ ..] if payload.len() == 16 => CatiaEntitySuffixFraming::FixedFeF6 {
            payload: payload.to_vec().into(),
        },
        [lead @ 0xd1..=0xe4, low, 0x01] => CatiaEntitySuffixFraming::PagedAtomState01 {
            value: u32::from(*lead - 0xd1) * 256 + u32::from(*low) + 1,
        },
        _ => return None,
    };
    Some(framing)
}

fn object_production<'a>(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    entity: &CatiaEntityRecord,
    object: &'a CatiaObjectRecord,
    references: &CatiaEntityReferenceIndex<'_>,
    expressions: &HashMap<String, String>,
    expression_entities: &CatiaRelationExpressionEntityIndex,
    dependencies: &mut RelationDependencies<'a>,
) -> Result<Option<CatiaEntityObjectProduction>, CodecError> {
    if let Some((mut instance, selected_expression)) = relation_program_instance(
        ctx,
        entity.entity_id,
        object,
        references,
        expression_entities,
    )? {
        if let Some((program_entity_id, expression)) = selected_expression {
            if let Some(parameter_dependencies) = dependencies.of(
                ctx,
                RelationExpressionKey::Entity(&object.parent, program_entity_id),
                &expression.source,
                &object.parent,
            )? {
                instance.parameter_dependencies = parameter_dependencies;
                instance.inputs = expression.signature.as_ref().and_then(|signature| {
                    resolved_relation_program_inputs(signature, &instance.parameter_dependencies)
                });
            }
        }
        return Ok(Some(CatiaEntityObjectProduction::RelationProgramInstance(
            instance,
        )));
    }
    if let Some(record) = schema_configuration_record(
        ctx,
        entity.entity_id,
        object,
        &entity.value_schema_selections,
        references,
    )? {
        return Ok(Some(
            CatiaEntityObjectProduction::SchemaConfigurationRecord(record),
        ));
    }
    if let Some(link) = schema_configuration_row_link(ctx, entity.entity_id, object, references)? {
        return Ok(Some(
            CatiaEntityObjectProduction::SchemaConfigurationRowLink(link),
        ));
    }
    let Some((mut relation, expression_object, source)) = formula_relation(
        ctx,
        &entity.definition_schema_selections,
        entity.entity_id,
        object,
        expressions,
        references,
    )?
    else {
        return Ok(None);
    };
    relation.parameter_dependencies = dependencies
        .of(
            ctx,
            RelationExpressionKey::ObjectRecord(expression_object),
            source,
            &object.parent,
        )?
        .unwrap_or_default();
    Ok(Some(CatiaEntityObjectProduction::FormulaRelation(relation)))
}

/// The program entity and expression a relation-program instance selects.
type SelectedProgramExpression<'e> = Option<(u32, &'e CatiaRelationExpressionEntity)>;

/// A relation-program instance frame without its parameter dependencies or
/// inputs, and the program entity and expression the frame selects.
fn relation_program_instance<'e>(
    ctx: &DecodeContext<'_>,
    entity_id: u32,
    object: &CatiaObjectRecord,
    entity_references: &CatiaEntityReferenceIndex<'_>,
    relation_expressions: &'e CatiaRelationExpressionEntityIndex,
) -> Result<Option<(CatiaRelationProgramInstance, SelectedProgramExpression<'e>)>, CodecError> {
    if object.entity_id() != Some(entity_id)
        || object.owner_entity_id().is_none()
        || object.class_ref().is_none()
    {
        return Ok(None);
    }
    let graph = object.parent.as_str();
    let lead_12 = object.lead == 0x12 && object.storage_ref().is_none();
    let lead_54 = object.lead == 0x54 && object.storage_ref().is_some();
    let frame = if lead_12 {
        relation_program_instance_lead_12(entity_id, &object.payload.fields)
    } else if lead_54 {
        relation_program_instance_lead_54(entity_id, &object.payload.fields)
    } else {
        None
    };
    let Some((program_entity_id, repeated_reference_entity_id, framing_entity_id)) = frame else {
        return Ok(None);
    };
    let framing_entity = entity_references.reference(ctx, graph, framing_entity_id)?;
    let framing = if lead_12 {
        CatiaRelationProgramInstanceFraming::Lead12 {
            context_entity: framing_entity,
        }
    } else {
        CatiaRelationProgramInstanceFraming::Lead54 {
            trailing_entity: framing_entity,
        }
    };

    let selected_expression = relation_expressions.get(&(object.parent.clone(), program_entity_id));
    let mut reference_incidences = Vec::new();
    for field in &object.payload.fields {
        let PayloadField::Reference { value, offset } = field else {
            continue;
        };
        reference_incidences.push(CatiaPayloadEntityReference {
            payload_offset: u64_from_index(*offset),
            reference: entity_references.reference(ctx, graph, *value)?,
        });
    }
    let instance = CatiaRelationProgramInstance {
        framing,
        program_entity: entity_references.reference(ctx, graph, program_entity_id)?,
        repeated_entity: entity_references.reference(ctx, graph, repeated_reference_entity_id)?,
        reference_incidences,
        relation_expression: selected_expression.map(|expression| expression.entity.clone()),
        parameter_dependencies: Vec::new(),
        inputs: None,
    };
    Ok(Some((
        instance,
        selected_expression.map(|expression| (program_entity_id, expression)),
    )))
}

fn reference_signature(
    ctx: &DecodeContext<'_>,
    production: entity_table::ReferenceSignature,
    graph_id: &str,
    entity_references: &CatiaEntityReferenceIndex<'_>,
) -> Result<CatiaReferenceSignature, CodecError> {
    let first_entity = entity_references.reference(ctx, graph_id, production.first_reference())?;
    let second_entity =
        entity_references.reference(ctx, graph_id, production.second_reference())?;
    Ok(CatiaReferenceSignature {
        production,
        first_entity,
        second_entity,
    })
}

fn derive_reference_signature_cohorts(
    entity_records: &[CatiaEntityRecord],
) -> Vec<CatiaReferenceSignatureCohort> {
    let mut cohorts = Vec::<CatiaReferenceSignatureCohort>::new();
    let mut cohort_by_pair = HashMap::<(&str, u32), usize>::new();
    let mut next_ordinal_by_graph = HashMap::<&str, u64>::new();
    for entity in entity_records {
        let Some(signature) = &entity.reference_signature else {
            continue;
        };
        let key = (
            entity.object_graph.as_str(),
            signature.production.first_reference(),
        );
        if let Some(index) = cohort_by_pair.get(&key).copied() {
            let member = entity.id.clone();
            cohorts[index].members.push(member);
            continue;
        }
        let ordinal =
            if let Some(next) = next_ordinal_by_graph.get_mut(entity.object_graph.as_str()) {
                *next += 1;
                *next
            } else {
                next_ordinal_by_graph.insert(entity.object_graph.as_str(), 0);
                0
            };
        let Some((namespace, graph_key)) = entity.object_graph.split_once('#') else {
            continue;
        };
        let mut components = namespace.split(':');
        let (Some(format), Some(scope), Some(_kind)) =
            (components.next(), components.next(), components.next())
        else {
            continue;
        };
        if components.next().is_some() {
            continue;
        }
        let id = format!("{format}:{scope}:reference-signature-cohort#{graph_key}:{ordinal:08}");
        let index = cohorts.len();
        let parent = entity.object_graph.clone();
        let first_entity = signature.first_entity.clone();
        let second_entity = signature.second_entity.clone();
        let members = vec![entity.id.clone()];
        cohorts.push(CatiaReferenceSignatureCohort {
            id,
            parent,
            ordinal,
            references: signature.production.references(),
            first_entity,
            second_entity,
            schema_selection: None,
            members,
        });
        cohort_by_pair.insert(key, index);
    }
    let entities_by_id = entity_records
        .iter()
        .map(|entity| (entity.id.as_str(), entity))
        .collect::<std::collections::HashMap<_, _>>();
    for cohort in &mut cohorts {
        let mut selected = None::<&CatiaEntityValueSchemaSelection>;
        let mut valid = true;
        for member in &cohort.members {
            let Some(entity) = entities_by_id.get(member.as_str()) else {
                valid = false;
                break;
            };
            let selections = &entity.value_schema_selections;
            if selections.first().map(|selection| selection.name.as_str()) != Some("_SpecList")
                || selections.len() > 2
            {
                valid = false;
                break;
            }
            let Some(selection) = selections.get(1) else {
                continue;
            };
            if selected.as_ref().is_some_and(|selected| {
                selected.ordinal != selection.ordinal
                    || selected.entry != selection.entry
                    || selected.name != selection.name
            }) {
                valid = false;
                break;
            }
            selected = Some(selection);
        }
        cohort.schema_selection = if valid {
            selected.map(|selection| CatiaReferenceSignatureSchemaSelection {
                ordinal: selection.ordinal,
                entry: selection.entry.clone(),
                name: selection.name.clone(),
            })
        } else {
            None
        };
    }
    cohorts
}

fn schema_configuration_record(
    ctx: &DecodeContext<'_>,
    entity_id: u32,
    object: &CatiaObjectRecord,
    value_schema_selections: &[CatiaEntityValueSchemaSelection],
    entity_references: &CatiaEntityReferenceIndex<'_>,
) -> Result<Option<CatiaSchemaConfigurationRecord>, CodecError> {
    if object.entity_id() != Some(entity_id)
        || object.lead != 0x12
        || object.owner_entity_id().is_none()
        || object.class_ref() != Some(entity_id)
        || object.class_name() != Some("Configuration")
        || object.storage_ref().is_some()
    {
        return Ok(None);
    }
    let [PayloadField::Reference {
        value: schema_ordinal,
        offset: schema_offset,
    }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: referenced_entity_id,
        offset: entity_offset,
    }, PayloadField::Atom { value: 129, .. }, PayloadField::Terminator] =
        object.payload.fields.as_slice()
    else {
        return Ok(None);
    };
    let mut matching_selections = value_schema_selections
        .iter()
        .filter(|selection| selection.ordinal == *schema_ordinal);
    let (Some(selection), None) = (matching_selections.next(), matching_selections.next()) else {
        return Ok(None);
    };
    Ok(Some(CatiaSchemaConfigurationRecord {
        schema_payload_offset: u64_from_index(*schema_offset),
        schema_ordinal: *schema_ordinal,
        schema_entry: selection.entry.clone(),
        schema_name: selection.name.clone(),
        entity_reference: CatiaPayloadEntityReference {
            payload_offset: u64_from_index(*entity_offset),
            reference: entity_references.reference(ctx, &object.parent, *referenced_entity_id)?,
        },
    }))
}

fn schema_configuration_row_link(
    ctx: &DecodeContext<'_>,
    entity_id: u32,
    object: &CatiaObjectRecord,
    entity_references: &CatiaEntityReferenceIndex<'_>,
) -> Result<Option<CatiaSchemaConfigurationRowLink>, CodecError> {
    if object.entity_id() != Some(entity_id)
        || object.lead != 0x12
        || object.owner_entity_id().is_none()
        || object.class_name() != Some("configrow")
        || object.storage_ref().is_some()
    {
        return Ok(None);
    }
    let Some(class_entity_id) = object.class_ref() else {
        return Ok(None);
    };
    let [PayloadField::Atom { value: 250, .. }, PayloadField::Atom {
        value: successor_entity_id,
        offset: successor_offset,
    }, PayloadField::Terminator] = object.payload.fields.as_slice()
    else {
        return Ok(None);
    };
    Ok(Some(CatiaSchemaConfigurationRowLink {
        class_reference: entity_references.reference(ctx, &object.parent, class_entity_id)?,
        successor_payload_offset: u64_from_index(*successor_offset),
        successor: entity_references.reference(ctx, &object.parent, *successor_entity_id)?,
    }))
}

fn relation_program_instance_lead_12(
    entity_id: u32,
    fields: &[PayloadField],
) -> Option<(u32, u32, u32)> {
    let [PayloadField::Reference { .. }, PayloadField::Atom { value: 3, .. }, PayloadField::Reference {
        value: repeated_reference,
        ..
    }, PayloadField::Atom { .. }, PayloadField::Atom { .. }, PayloadField::Atom { value: 5, .. }, PayloadField::Atom { value: 89, .. }, PayloadField::Atom {
        value: 1_127_154_762,
        ..
    }, PayloadField::Reference { .. }, PayloadField::Atom {
        value: repeated_target,
        ..
    }, PayloadField::Reference { .. }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: repeated_target_reference,
        ..
    }, PayloadField::Reference {
        value: context_entity_id,
        ..
    }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: repeated_reference_copy,
        ..
    }, PayloadField::Atom {
        value: program_entity_id,
        ..
    }, PayloadField::Reference { .. }, PayloadField::Atom {
        value: stored_self, ..
    }, PayloadField::Terminator] = fields
    else {
        return None;
    };
    if repeated_reference != repeated_reference_copy
        || repeated_target != repeated_target_reference
        || *stored_self != entity_id
    {
        return None;
    }
    Some((*program_entity_id, *repeated_target, *context_entity_id))
}

fn relation_program_instance_lead_54(
    entity_id: u32,
    fields: &[PayloadField],
) -> Option<(u32, u32, u32)> {
    let [PayloadField::Atom { value: 244, .. }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: repeated_reference,
        ..
    }, PayloadField::Atom {
        value: program_entity_id,
        ..
    }, PayloadField::Atom {
        value: 2_142_008_808,
        ..
    }, PayloadField::Atom { value: 247, .. }, PayloadField::Atom {
        value: repeated_target,
        ..
    }, PayloadField::Reference { .. }, PayloadField::Atom {
        value: stored_self, ..
    }, PayloadField::Atom { value: 249, .. }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: repeated_target_reference,
        ..
    }, PayloadField::Reference { .. }, PayloadField::Atom { value: 2, .. }, PayloadField::Reference {
        value: repeated_reference_copy,
        ..
    }, PayloadField::Atom {
        value: trailing_entity_id,
        ..
    }, PayloadField::Atom { value: 129, .. }, PayloadField::Terminator] = fields
    else {
        return None;
    };
    if repeated_reference != repeated_reference_copy
        || repeated_target != repeated_target_reference
        || *stored_self != entity_id
    {
        return None;
    }
    Some((*program_entity_id, *repeated_target, *trailing_entity_id))
}

/// A formula relation without its parameter dependencies, and the expression
/// object and source text it selects.
fn formula_relation<'a, 'e>(
    ctx: &DecodeContext<'_>,
    definitions: &[CatiaDefinitionSchemaSelection],
    entity_id: u32,
    object: &'a CatiaObjectRecord,
    relation_expressions: &'e HashMap<String, String>,
    entity_references: &CatiaEntityReferenceIndex<'_>,
) -> Result<Option<(CatiaFormulaRelation, &'a str, &'e str)>, CodecError> {
    let [definition0, definition1] = definitions else {
        return Ok(None);
    };
    if definition0.name.as_deref() != Some("Formula")
        || definition1.name.as_deref() != Some("Formula")
        || definition0.entry != definition1.entry
    {
        return Ok(None);
    }
    let [PayloadField::Atom { value: 249, .. }, PayloadField::Atom { value: 4, .. }, PayloadField::Reference { value: owner, .. }, PayloadField::Reference {
        value: expression_entity_id,
        offset: expression_offset,
    }, PayloadField::Reference {
        value: parameter_entity_id,
        offset: parameter_offset,
    }, PayloadField::Atom { value: 129, .. }, PayloadField::Terminator] =
        object.payload.fields.as_slice()
    else {
        return Ok(None);
    };
    if *owner != entity_id {
        return Ok(None);
    }
    let [owner_reference, expression_reference, parameter_reference] = object.references.as_slice()
    else {
        return Ok(None);
    };
    if owner_reference.entity_id() != entity_id
        || expression_reference.entity_id() != *expression_entity_id
        || parameter_reference.entity_id() != *parameter_entity_id
        || owner_reference.target() != Some(object.id.as_str())
    {
        return Ok(None);
    }
    let Some(expression_object) = expression_reference.target() else {
        return Ok(None);
    };
    let Some(source) = relation_expressions.get(expression_object) else {
        return Ok(None);
    };
    let expression_entity =
        entity_references.reference(ctx, &object.parent, *expression_entity_id)?;
    let output_reference = if parameter_reference.is_null() {
        CatiaEntityReference::Null {
            entity_id: *parameter_entity_id,
        }
    } else {
        entity_references.reference(ctx, &object.parent, *parameter_entity_id)?
    };
    let relation = CatiaFormulaRelation {
        expression_entity: CatiaPayloadEntityReference {
            payload_offset: u64_from_index(*expression_offset),
            reference: expression_entity,
        },
        output_entity: CatiaPayloadEntityReference {
            payload_offset: u64_from_index(*parameter_offset),
            reference: output_reference,
        },
        parameter_dependencies: Vec::new(),
    };
    Ok(Some((relation, expression_object, source)))
}

type CatiaRelationExpressionIndex = HashMap<String, String>;
struct CatiaRelationExpressionEntity {
    entity: String,
    source: String,
    signature: Option<CatiaRelationTypeSignature>,
}
type CatiaRelationExpressionEntityIndex = HashMap<(String, u32), CatiaRelationExpressionEntity>;
type CatiaEntityByGraphIdentityIndex = HashMap<(String, u32), String>;
type CatiaEntityClassByGraphIdentityIndex = HashMap<(String, u32), String>;
type CatiaTerminalNullByGraphIndex = HashMap<String, u32>;
type CatiaParameterBindingIndex = HashMap<String, HashMap<String, Vec<CatiaEntityReference>>>;

struct CatiaEntityReferenceIndex<'a> {
    entities: &'a CatiaEntityByGraphIdentityIndex,
    classes: &'a CatiaEntityClassByGraphIdentityIndex,
    terminal_nulls: &'a CatiaTerminalNullByGraphIndex,
}

impl CatiaEntityReferenceIndex<'_> {
    /// The same-graph reference that `entity_id` makes in `graph_id`.
    fn reference(
        &self,
        ctx: &DecodeContext<'_>,
        graph_id: &str,
        entity_id: u32,
    ) -> Result<CatiaEntityReference, CodecError> {
        if self.terminal_nulls.get(graph_id).copied() == Some(entity_id) {
            return Ok(CatiaEntityReference::Null { entity_id });
        }
        let key = (graph_id.to_owned(), entity_id);
        let Some(entity) = self.entities.get(&key) else {
            return Ok(CatiaEntityReference::Unresolved { entity_id });
        };
        Ok(CatiaEntityReference::Resolved {
            entity_id,
            entity: entity.to_owned(),
            class_name: retained_class_name(ctx, self.classes.get(&key).map(String::as_str))?,
        })
    }
}

fn entity_class_index<'a>(
    records: impl IntoIterator<Item = &'a CatiaObjectRecord>,
) -> CatiaEntityClassByGraphIdentityIndex {
    let mut classes = HashMap::new();
    for record in records {
        let (Some(entity_id), Some(class_name)) = (record.entity_id(), record.class_name()) else {
            continue;
        };
        let graph = record.parent.clone();
        let class_name = class_name.to_owned();
        classes.insert((graph, entity_id), class_name);
    }
    classes
}

fn semantic_entity_indices(
    entities: &[CatiaEntityRecord],
    entity_classes: &CatiaEntityClassByGraphIdentityIndex,
) -> Result<
    (
        CatiaRelationExpressionIndex,
        CatiaRelationExpressionEntityIndex,
        CatiaEntityByGraphIdentityIndex,
        CatiaTerminalNullByGraphIndex,
        CatiaParameterBindingIndex,
    ),
    CodecError,
> {
    let mut relation_expressions = HashMap::new();
    let mut relation_expression_entities = HashMap::new();
    let mut entities_by_graph_identity = HashMap::new();
    let mut maxima = HashMap::<String, u32>::new();
    let mut parameter_bindings = CatiaParameterBindingIndex::new();
    for entity in entities {
        if let Some(expression) = entity.relation_expression() {
            let object_record = entity.object_record.clone();
            let source = expression.expression.value.clone();
            relation_expressions.insert(object_record, source);
            let graph = entity.object_graph.clone();
            let row = CatiaRelationExpressionEntity {
                entity: entity.id.clone(),
                source: expression.expression.value.clone(),
                signature: expression.signature(),
            };
            relation_expression_entities.insert((graph, entity.entity_id), row);
        }
        let graph = entity.object_graph.clone();
        let id = entity.id.clone();
        entities_by_graph_identity.insert((graph, entity.entity_id), id);
        if let Some(maximum) = maxima.get_mut(entity.object_graph.as_str()) {
            *maximum = (*maximum).max(entity.entity_id);
        } else {
            let graph = entity.object_graph.clone();
            maxima.insert(graph, entity.entity_id);
        }
        let Some(parameter) = entity.parameter_value() else {
            continue;
        };
        if !parameter_bindings.contains_key(entity.object_graph.as_str()) {
            let graph = entity.object_graph.clone();
            parameter_bindings.insert(graph, HashMap::new());
        }
        let Some(bindings) = parameter_bindings.get_mut(entity.object_graph.as_str()) else {
            return Err(CodecError::malformed(
                "CATIA parameter-binding graph disappeared",
            ));
        };
        if !bindings.contains_key(parameter.binding.value.as_str()) {
            let symbol = parameter.binding.value.clone();
            bindings.insert(symbol, Vec::new());
        }
        let Some(references) = bindings.get_mut(parameter.binding.value.as_str()) else {
            return Err(CodecError::malformed("CATIA parameter binding disappeared"));
        };

        let class_name = entity_classes.get(&(entity.object_graph.clone(), entity.entity_id));
        let reference = CatiaEntityReference::Resolved {
            entity_id: entity.entity_id,
            entity: entity.id.clone(),
            class_name: class_name.map(std::borrow::ToOwned::to_owned),
        };
        references.push(reference);
    }
    let mut terminal_nulls = HashMap::new();
    for (graph, maximum) in maxima {
        if let Some(identity) = maximum.checked_add(1) {
            terminal_nulls.insert(graph, identity);
        }
    }
    Ok((
        relation_expressions,
        relation_expression_entities,
        entities_by_graph_identity,
        terminal_nulls,
        parameter_bindings,
    ))
}

/// One relation expression, as a relation selects it.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum RelationExpressionKey<'a> {
    /// A formula expression selected by its object record.
    ObjectRecord(&'a str),
    /// A program expression selected by its graph and entity identity.
    Entity(&'a str, u32),
}

/// Dependency text all relations may keep, per input byte. Many relations can
/// share one expression and one symbol can bind many same-named parameters, so
/// the copies grow with the product of those counts.
pub(crate) const MAX_RELATION_DEPENDENCY_BYTES_PER_INPUT_BYTE: usize = 4;

/// Parameter dependencies of relation expressions.
///
/// Each expression is scanned for symbols once. Every relation copies the
/// dependencies into its own record, so each copy charges its text as
/// retained bytes before it is built. A copy past the remaining allowance is
/// not made.
struct RelationDependencies<'a> {
    parameter_bindings: &'a CatiaParameterBindingIndex,
    symbols: HashMap<RelationExpressionKey<'a>, Vec<(u64, String)>>,
    remaining_bytes: usize,
    bounded_relations: usize,
}

impl<'a> RelationDependencies<'a> {
    fn new(parameter_bindings: &'a CatiaParameterBindingIndex, allowance_bytes: usize) -> Self {
        Self {
            parameter_bindings,
            symbols: HashMap::new(),
            remaining_bytes: allowance_bytes,
            bounded_relations: 0,
        }
    }

    /// The dependencies of one relation, or `None` past the allowance.
    fn of(
        &mut self,
        ctx: &cadmpeg_core::decode::DecodeContext<'_>,
        expression: RelationExpressionKey<'a>,
        source: &str,
        graph: &str,
    ) -> Result<Option<Vec<CatiaRelationParameterDependency>>, CodecError> {
        let symbols = self
            .symbols
            .entry(expression)
            .or_insert_with(|| relation_symbols(source));
        let bindings = self.parameter_bindings.get(graph);
        let bound = |symbol: &str| {
            bindings
                .and_then(|bindings| bindings.get(symbol))
                .map_or(&[][..], Vec::as_slice)
        };
        let mut retained = Some(0usize);
        for (_, symbol) in symbols.iter() {
            retained = retained.and_then(|total| total.checked_add(symbol.len()));
            for candidate in bound(symbol) {
                retained = retained
                    .zip(candidate.text_len())
                    .and_then(|(total, text)| total.checked_add(text));
            }
        }
        let Some((retained, remaining)) = retained
            .and_then(|retained| Some((retained, self.remaining_bytes.checked_sub(retained)?)))
        else {
            self.bounded_relations += 1;
            return Ok(None);
        };
        self.remaining_bytes = remaining;
        ctx.retain_bytes(
            u64_from_index(retained),
            "retain CATIA relation parameter dependencies",
        )?;
        Ok(Some(
            symbols
                .iter()
                .map(|(source_offset, symbol)| CatiaRelationParameterDependency {
                    source_offset: *source_offset,
                    symbol: symbol.clone(),
                    candidates: bound(symbol).to_vec(),
                })
                .collect(),
        ))
    }
}

/// Signature inputs keyed by parameter name.
///
/// A dependency symbol matches an input when the symbol is the input's
/// parameter followed by optional ASCII whitespace and either nothing or a
/// `/` and one or more ASCII digits.
pub(crate) struct RelationInputIndex<'a> {
    /// Inputs keyed by parameter without its trailing ASCII whitespace, each
    /// with that trailing whitespace.
    by_trimmed_parameter: HashMap<&'a str, Vec<(usize, &'a str)>>,
}

fn is_relation_space(character: char) -> bool {
    character.is_ascii_whitespace()
}

impl<'a> RelationInputIndex<'a> {
    pub(crate) fn new(inputs: &'a [CatiaRelationTypeInput]) -> Self {
        let mut by_trimmed_parameter = HashMap::<&str, Vec<(usize, &str)>>::new();
        for (index, input) in inputs.iter().enumerate() {
            let parameter = input.parameter.as_str();
            let trimmed = parameter.trim_end_matches(is_relation_space);
            by_trimmed_parameter
                .entry(trimmed)
                .or_default()
                .push((index, &parameter[trimmed.len()..]));
        }
        Self {
            by_trimmed_parameter,
        }
    }

    /// Indices of the inputs `dependency` matches, unordered.
    pub(crate) fn matches<'s>(
        &'s self,
        dependency: &'s CatiaRelationParameterDependency,
    ) -> impl Iterator<Item = usize> + 's {
        let symbol = dependency.symbol.as_str();
        // A parameter ends where the rest of the symbol is whitespace ...
        let trailing_space = Some(symbol);
        // ... or whitespace and then a final `/` ordinal.
        let before_ordinal = symbol
            .rfind('/')
            .filter(|&slash| {
                let ordinal = &symbol[slash + 1..];
                !ordinal.is_empty() && ordinal.bytes().all(|byte| byte.is_ascii_digit())
            })
            .map(|slash| &symbol[..slash]);
        trailing_space
            .into_iter()
            .chain(before_ordinal)
            .flat_map(move |head| self.parameters_ending_in_space_of(head))
    }

    /// Inputs whose parameter is `head` with some prefix of its trailing
    /// whitespace.
    fn parameters_ending_in_space_of<'s>(
        &'s self,
        head: &'s str,
    ) -> impl Iterator<Item = usize> + 's {
        let trimmed = head.trim_end_matches(is_relation_space);
        let space = &head[trimmed.len()..];
        self.by_trimmed_parameter
            .get(trimmed)
            .into_iter()
            .flatten()
            .filter(move |(_, tail)| space.starts_with(tail))
            .map(|(index, _)| *index)
    }
}

fn resolved_relation_program_inputs(
    signature: &CatiaRelationTypeSignature,
    dependencies: &[CatiaRelationParameterDependency],
) -> Option<Vec<CatiaRelationProgramInput>> {
    let index = RelationInputIndex::new(&signature.inputs);
    let mut dependencies_by_input = vec![Vec::new(); signature.inputs.len()];
    for dependency in dependencies {
        let mut matches = index.matches(dependency);
        let (Some(input), None) = (matches.next(), matches.next()) else {
            return None;
        };
        dependencies_by_input[input].push(dependency);
    }
    let mut entity_ids = HashSet::new();
    let mut inputs = Vec::new();
    for (input, matching) in signature.inputs.iter().zip(&dependencies_by_input) {
        let mut selected = None::<&CatiaEntityReference>;
        let mut occurrence_count = 0usize;
        for dependency in matching {
            occurrence_count += 1;
            let [candidate] = dependency.candidates.as_slice() else {
                return None;
            };
            if candidate.is_null() || candidate.entity().is_none() {
                return None;
            }
            match selected {
                Some(previous) if previous != candidate => return None,
                Some(_) => {}
                None => selected = Some(candidate),
            }
        }
        let entity = (occurrence_count != 0).then_some(selected).flatten()?;
        if !entity_ids.insert(entity.entity_id()) {
            return None;
        }
        let input = CatiaRelationProgramInput {
            parameter: input.parameter.clone(),
            value_type: input.input_type.clone(),
            entity: entity.clone(),
        };
        inputs.push(input);
    }
    Some(inputs)
}

pub(crate) fn relation_symbols(source: &str) -> Vec<(u64, String)> {
    let bytes = source.as_bytes();
    let mut symbols = Vec::new();
    let mut at = 0;
    while at < bytes.len() {
        if bytes[at] == b'"' {
            at += 1;
            while bytes.get(at).is_some_and(|byte| *byte != b'"') {
                at += 1;
            }
            at += usize::from(at < bytes.len());
            continue;
        }
        if bytes[at] != b'#' {
            at += 1;
            continue;
        }
        let start = at;
        at += 1;
        let digits_start = at;
        while bytes.get(at).is_some_and(u8::is_ascii_digit) {
            at += 1;
        }
        if at == digits_start || bytes.get(at) != Some(&b'_') {
            at = start + 1;
            continue;
        }
        at += 1;
        let bare_end = at;
        while bytes.get(at).is_some_and(u8::is_ascii_whitespace) {
            at += 1;
        }
        if bytes.get(at) != Some(&b'/') {
            let source_offset = u64_from_index(start);
            let symbol = source[start..bare_end].to_owned();
            symbols.push((source_offset, symbol));
            at = bare_end;
            continue;
        }
        at += 1;
        let ordinal_start = at;
        while bytes.get(at).is_some_and(u8::is_ascii_digit) {
            at += 1;
        }
        if at == ordinal_start {
            at = start + 1;
            continue;
        }
        let source_offset = u64_from_index(start);
        let symbol = source[start..at].to_owned();
        symbols.push((source_offset, symbol));
    }
    symbols
}

fn value_field_offset(field: &value_block::ValueField) -> usize {
    match field {
        value_block::ValueField::SchemaSelector { offset, .. }
        | value_block::ValueField::Binary64 { offset, .. }
        | value_block::ValueField::Marker { offset, .. }
        | value_block::ValueField::Opcode { offset, .. }
        | value_block::ValueField::Separator { offset }
        | value_block::ValueField::Inline { offset, .. }
        | value_block::ValueField::ByteString { offset, .. }
        | value_block::ValueField::Atom { offset, .. }
        | value_block::ValueField::Terminator { offset }
        | value_block::ValueField::Literal { offset, .. } => *offset,
    }
}

fn repeated_reference_schema_selection(
    ctx: &DecodeContext<'_>,
    preamble: Option<&object_graph::ReferenceSchemaPreamble>,
    catalog: Option<&CatiaCatalog>,
) -> Result<Option<CatiaRepeatedReferenceSchemaSelection>, CodecError> {
    let Some(preamble) = preamble else {
        return Ok(None);
    };
    let (order, ordinal, offset) = match preamble {
        object_graph::ReferenceSchemaPreamble::BlobThenSchema { schema_ref, offset } => (
            CatiaRepeatedReferenceSchemaOrder::BlobThenSchema,
            *schema_ref,
            *offset,
        ),
        object_graph::ReferenceSchemaPreamble::SchemaThenBlob { schema_ref, offset } => (
            CatiaRepeatedReferenceSchemaOrder::SchemaThenBlob,
            *schema_ref,
            *offset,
        ),
    };
    let catalog_entry = usize::try_from(ordinal)
        .ok()
        .and_then(|ordinal| catalog?.entries.get(ordinal));
    if let Some(entry) = catalog_entry {
        charge_class_text(ctx, &entry.id, &entry.value)?;
    }
    Ok(Some(CatiaRepeatedReferenceSchemaSelection {
        order,
        offset: u64_from_index(offset),
        ordinal,
        entry: catalog_entry.map(|entry| entry.id.clone()),
        name: catalog_entry.map(|entry| entry.value.clone()),
    }))
}

/// One stored entity identity in a pre-`7C05` design stream.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyEntityIdentity {
    /// Offset of the `EA` identity delimiter.
    byte_offset: u64,
    /// Little-endian identity following the delimiter.
    pub(crate) entity_id: u32,
    /// Stored record lead following the identity.
    pub(crate) lead: legacy_entity::CatiaLegacyIdentityLead,
}

/// One complete compact legacy schema program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacySchemaProgram {
    /// Offset of the first program byte after the fixed prefix.
    pub(crate) byte_offset: u64,
    /// Offset of the production following the program.
    #[serde(alias = "footer_byte_offset")]
    pub(crate) boundary_byte_offset: u64,
    /// Production that closes the program.
    #[serde(default)]
    pub(crate) boundary: CatiaLegacySchemaProgramBoundary,
    /// Exact program bytes, including the terminal `FE`.
    pub(crate) data: NativeBytes<Vec<u8>>,
    /// Complete inclusive-length identifier packets in source order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) identifiers: Vec<CatiaLegacySchemaIdentifier>,
}

/// Production that closes a compact legacy schema program.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum CatiaLegacySchemaProgramBoundary {
    /// Fixed vendor footer preceded by the terminal `FE`.
    #[default]
    VendorFooter,
    /// Validated outer stream directory preceded by the terminal `FE`.
    StreamDirectory,
}

/// One complete inclusive-length identifier packet in a compact schema program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacySchemaIdentifier {
    /// Offset of the inclusive-length byte.
    pub(crate) byte_offset: u64,
    /// Stored identifier.
    pub(crate) value: String,
}

/// Framing production used by a legacy schema text field.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum CatiaLegacyTextEncoding {
    /// Nonzero one-byte inclusive length.
    U8InclusiveLength,
    /// Zero selector and little-endian `u32` byte length.
    ZeroU32Length,
    /// Nonzero inclusive length followed by an `E3` paged-role tail.
    U8InclusiveLengthE3RoleTail,
}

/// Framing production used by a legacy role selector.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum CatiaLegacyRoleSelectorEncoding {
    /// `80` followed by a nonzero little-endian `u32`.
    FixedU32,
    /// Page byte `D1..E4` followed by one low byte.
    Paged,
}

/// One length-framed legacy schema role and its selector.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyRoleSelector {
    /// Offset of the literal length or schema-selector byte.
    byte_offset: u64,
    /// Stored identity whose interval contains the role.
    #[serde(default)]
    pub(crate) entity_id: u32,
    /// Stored literal or unresolved role name.
    pub(crate) name: legacy_entity::LegacyRoleName,
    /// Selector framing production.
    pub(crate) encoding: CatiaLegacyRoleSelectorEncoding,
    /// Stored selector following the role name.
    pub(crate) selector: u32,
    /// Field code when an `E8 <field-code:u16le> 01` opener follows immediately.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) field_code: Option<u16>,
}

impl CatiaLegacyRoleSelector {
    pub(crate) fn end_offset(&self) -> Option<u64> {
        let selector_len = match self.encoding {
            CatiaLegacyRoleSelectorEncoding::FixedU32 => 5,
            CatiaLegacyRoleSelectorEncoding::Paged => 2,
        };
        self.byte_offset
            .checked_add(u64_from_index(self.name.byte_len()))?
            .checked_add(selector_len)
    }
}

/// One complete legacy schema text field.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyTextField {
    /// Offset of the field opener.
    pub(crate) byte_offset: u64,
    /// Stored identity whose interval contains the field.
    pub(crate) entity_id: u32,
    /// Text framing production.
    pub(crate) encoding: CatiaLegacyTextEncoding,
    /// Immediately preceding length-framed role and selector.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) role: Option<CatiaLegacyRoleSelector>,
    /// Decoded UTF-8 value.
    pub(crate) value: String,
}

impl legacy_entity::LegacyValueNameField for CatiaLegacyTextField {
    fn entity_id(&self) -> u32 {
        self.entity_id
    }

    fn offset(&self) -> u64 {
        self.byte_offset
    }

    fn value(&self) -> &str {
        &self.value
    }

    fn role_field_code(&self) -> Option<u16> {
        self.role.as_ref().and_then(|role| role.field_code)
    }
}

/// One legacy schema field bounded by consecutive role selectors.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacySchemaField {
    /// Offset of the `E8 <field-code:u16le> 01` opener.
    byte_offset: u64,
    /// Stored identity whose interval contains the field.
    entity_id: u32,
    /// Role selector that binds this field.
    role_byte_offset: u64,
    /// Following role selector that closes the payload.
    pub(crate) boundary_role_byte_offset: u64,
    /// Stored schema field code.
    pub(crate) field_code: u16,
    /// Exact bytes after the opener and before the boundary role.
    pub(crate) payload: NativeBytes<Vec<u8>>,
}

/// One typed parameter role in a legacy relation signature.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyRelationParameter {
    /// Expression-local parameter.
    pub(crate) parameter: String,
    /// Source value type.
    pub(crate) value_type: String,
}

/// One complete legacy expression and type-signature pair.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyRelation {
    /// Stored owner identity.
    entity_id: u32,
    /// Selector carried by the expression field's `body` role.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    body_selector: Option<u32>,
    /// Selector carried by the type-signature field's `param` role.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    parameter_selector: Option<u32>,
    /// Parameter identity selected by exact self-`body` and target-`param` roles.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) parameter_entity_id: Option<u32>,
    /// Expression-field opener offset.
    pub(crate) expression_offset: u64,
    /// Exact expression or rule program.
    pub(crate) expression: String,
    /// Signature-field opener offset.
    signature_offset: u64,
    /// Exact stored type signature.
    type_signature: String,
    /// Ordered input parameters.
    pub(crate) inputs: Vec<CatiaLegacyRelationParameter>,
    /// Output parameter for a `VoidType` relation.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) output: Option<CatiaLegacyRelationParameter>,
    /// Source result type.
    pub(crate) result_type: String,
}

/// One complete legacy `synchrone` relation-update field.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyRelationSynchronousState {
    /// Offset of the `synchrone` role-name length byte.
    role_byte_offset: u64,
    /// Stored containing identity.
    entity_id: u32,
    /// Selector carried by the `synchrone` role.
    pub(crate) selector: u32,
    /// Whether the relation updates synchronously.
    pub(crate) synchronous: bool,
}

/// Value selected by one complete legacy type descriptor.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaLegacyTypeValue {
    /// Inclusive-length UTF-8 type name.
    Name {
        /// Stored type name.
        value: String,
    },
    /// Compact unresolved selector identity.
    Selector {
        /// Stored selector identity.
        value: u32,
    },
}

/// One complete type descriptor in a legacy identity interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyTypeDescriptor {
    /// Offset of the fixed descriptor prefix.
    byte_offset: u64,
    /// Stored containing identity.
    pub(crate) entity_id: u32,
    /// Stored literal name or unresolved selector.
    pub(crate) value: CatiaLegacyTypeValue,
}

/// Evaluation stored by a complete legacy scalar packet.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum CatiaLegacyScalarEvaluation {
    /// Finite binary64 scalar.
    Value {
        /// Exact IEEE-754 bits.
        bits: u64,
    },
    /// Stored unset evaluation.
    Unset,
}

/// Fixed prefix selecting one legacy scalar production.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum CatiaLegacyScalarEncoding {
    /// `FE 84 88 82 FE`.
    Named84,
    /// `FE 85 88 82 FE`.
    Standalone85,
}

/// One complete typed scalar packet in a legacy identity interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyScalarValue {
    /// Stable native identity derived from the containing run and packet offset.
    pub(crate) id: String,
    /// Offset of the packet prefix.
    pub(crate) byte_offset: u64,
    /// Stored containing identity.
    pub(crate) entity_id: u32,
    /// Fixed scalar-prefix production.
    pub(crate) encoding: CatiaLegacyScalarEncoding,
    /// Unique co-owned `name` text field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    name_field: Option<u64>,
    /// Unique co-owned stored name.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name: Option<String>,
    /// Stored evaluation.
    pub(crate) evaluation: CatiaLegacyScalarEvaluation,
}

/// One complete legacy UTF-8 string-value packet.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyStringValue {
    /// Stable native identity derived from the containing run and packet offset.
    pub(crate) id: String,
    /// Offset of the packet prefix.
    pub(crate) byte_offset: u64,
    /// Stored containing identity.
    pub(crate) entity_id: u32,
    /// Unique co-owned `name` text field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name_field: Option<u64>,
    /// Unique co-owned stored name.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name: Option<String>,
    /// Stored UTF-8 value.
    pub(crate) value: String,
}

/// Stored encoding of one complete legacy signed integer.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum CatiaLegacyIntegerEncoding {
    /// One byte stores values zero through 126 as `value + 0x81`.
    Inline,
    /// `80` introduces one signed little-endian 32-bit value.
    WideI32,
}

/// One complete legacy signed-integer packet.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyIntegerValue {
    /// Stable native identity derived from the containing run and packet offset.
    pub(crate) id: String,
    /// Offset of the packet prefix.
    pub(crate) byte_offset: u64,
    /// Stored containing identity.
    pub(crate) entity_id: u32,
    /// Stored integer encoding.
    encoding: CatiaLegacyIntegerEncoding,
    /// Unique co-owned `name` text field.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name_field: Option<u64>,
    /// Unique co-owned stored name.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) name: Option<String>,
    /// Stored signed value.
    pub(crate) value: i32,
}

/// A monotonically identified pre-`7C05` run and its terminating catalog.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaLegacyEntityRun {
    /// Stable native identity.
    pub(crate) id: String,
    /// Offset of the first identity delimiter.
    pub(crate) byte_offset: u64,
    /// Bytes from the first identity delimiter to the catalog opener.
    byte_len: u64,
    /// Offset of the fixed schema-catalog opening production.
    pub(crate) catalog_offset: u64,
    /// Complete compact schema program following the catalog opener.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) schema_program: Option<CatiaLegacySchemaProgram>,
    /// Exact declared outer container whose physical stream contains this run.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) outer_container: Option<CatiaOuterContainerBinding>,
    /// Stored identities in source order.
    pub(crate) identities: Vec<CatiaLegacyEntityIdentity>,
    /// Complete length-framed role selectors in identity-interval order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) role_selectors: Vec<CatiaLegacyRoleSelector>,
    /// Complete schema text fields in identity-interval order.
    pub(crate) text_fields: Vec<CatiaLegacyTextField>,
    /// Complete role-bounded schema fields in identity-interval order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) schema_fields: Vec<CatiaLegacySchemaField>,
    /// Complete expression/signature pairs.
    pub(crate) relations: Vec<CatiaLegacyRelation>,
    /// Complete `synchrone` relation-update fields.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) synchronous_states: Vec<CatiaLegacyRelationSynchronousState>,
    /// Complete literal or selector type descriptors.
    pub(crate) type_descriptors: Vec<CatiaLegacyTypeDescriptor>,
    /// Complete typed scalar packets.
    pub(crate) scalar_values: Vec<CatiaLegacyScalarValue>,
    /// Complete UTF-8 string-value packets.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) string_values: Vec<CatiaLegacyStringValue>,
    /// Complete signed-integer packets.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) integer_values: Vec<CatiaLegacyIntegerValue>,
}

/// One zero-entity face-local surface-support occurrence.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntitySupportOccurrence {
    /// Byte offset of the framed `21xx` record.
    byte_offset: u64,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    pub(crate) tag: NativeBytes<[u8; 2]>,
    /// Face-local support slot stored at record offset 12.
    pub(crate) face_local_slot: u32,
    /// Stored UV endpoints when the record family carries them inline.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) uv_endpoints: Option<[[FiniteReal; 2]; 2]>,
    /// Complete parameter-space curve carried by the support record.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) pcurve: Option<cadmpeg_ir::geometry::pcurve::PcurveGeometry>,
    /// Exact model-space carrier derived from the pcurve and owning surface.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) model_curve: Option<cadmpeg_ir::geometry::CurveGeometry>,
    /// Exact procedural model-space carrier derived from the pcurve and owning surface.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) model_curve_construction: Option<cadmpeg_ir::geometry::ProceduralCurveDefinition>,
    /// Model-carrier parameters at the two stored UV endpoints.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) model_parameters: Option<[FiniteReal; 2]>,
    /// Surface point at the midpoint of the bounded pcurve parameter interval.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) model_midpoint: Option<FinitePoint3>,
    /// UV endpoints lifted through the owning surface carrier.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) model_endpoints: Option<[FinitePoint3; 2]>,
}

/// One counted zero-entity `5fxx` face record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityFace {
    /// Byte offset of the framed face record.
    byte_offset: u64,
    /// One-based global record ordinal.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    tag: NativeBytes<[u8; 2]>,
    /// Counted allocation values in storage order.
    pub(crate) allocations: Vec<u32>,
    /// Ordered loop terminals derived from the allocation lane.
    pub(crate) loop_terminals: Vec<u32>,
    /// Positionally aligned loop records.
    pub(crate) loops: Vec<CatiaZeroEntityLoop>,
    /// Terminal control byte following the allocation lane.
    pub(crate) terminal_control: u8,
}

/// One counted zero-entity `62xx` loop record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityLoop {
    /// Byte offset of the framed loop record.
    byte_offset: u64,
    /// One-based global record ordinal.
    record_ordinal: u32,
    /// Complete two-byte record tag.
    tag: NativeBytes<[u8; 2]>,
    /// Nonterminal even-lane logical member identifiers.
    pub(crate) member_ids: Vec<u32>,
    /// Backward distances from the loop to physical-edge stride records.
    pub(crate) edge_stride_distances: Vec<u32>,
    /// Physical-edge stride records selected by the backward distances.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) edge_stride_records: Vec<String>,
    /// Face-local support record ordinals selected by the logical members.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) support_record_ordinals: Vec<u32>,
    /// Terminal even-lane logical identifier.
    pub(crate) terminal_id: u32,
    /// Difference between the terminal and first member identifiers.
    pub(crate) gap: u32,
    /// Stored loop-class byte.
    pub(crate) loop_class: u8,
    /// Absolute coedge senses in member order; `true` is forward.
    pub(crate) forward_senses: Vec<bool>,
    /// Complete sense-oriented model-space endpoint pairs in member order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub(crate) oriented_model_endpoints: Vec<[FinitePoint3; 2]>,
}

/// One zero-entity surface carrier and its maximal following support run.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntitySupportRun {
    /// Stable native-run identity.
    id: String,
    /// Byte offset of the owning surface-carrier record.
    pub(crate) carrier_byte_offset: u64,
    /// One-based global record ordinal of the owning surface carrier.
    pub(crate) carrier_record_ordinal: u32,
    /// Positionally aligned face record when the complete rosters agree.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) face: Option<CatiaZeroEntityFace>,
    /// Face-local support occurrences in storage order.
    pub(crate) supports: Vec<CatiaZeroEntitySupportOccurrence>,
}

/// One zero-entity `5e1a` allocation tuple.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityEdgeStride {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Five allocation values following the fixed tagged-one prefix.
    pub(crate) allocations: [u32; 5],
}

/// One positional zero-entity `0638` oriented use.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityOrientedUse {
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// One-based global record ordinal in the zero-entity stream.
    record_ordinal: u32,
    /// Positional side number.
    side: u32,
    /// Two stored allocation values.
    pub(crate) allocations: [u32; 2],
}

/// One zero-entity `2569` header and its two positional uses.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityOrientedUsePair {
    /// Stable native-pair identity.
    id: String,
    /// Byte offset of the `2569` header.
    header_byte_offset: u64,
    /// One-based global record ordinal of the `2569` header.
    pub(crate) header_record_ordinal: u32,
    /// Stored base columns.
    pub(crate) base_columns: [u32; 2],
    /// Side-one then side-two oriented uses.
    pub(crate) uses: [CatiaZeroEntityOrientedUse; 2],
}

/// One counted zero-entity `05xx` vertex-incidence record.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityVertexIncidence {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    byte_offset: u64,
    /// One-based global record ordinal in the zero-entity stream.
    pub(crate) record_ordinal: u32,
    /// Complete two-byte record tag.
    tag: NativeBytes<[u8; 2]>,
    /// Stored allocation values.
    pub(crate) allocations: Vec<u32>,
    /// Immediately following `5d06` vertex-owner record.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) vertex_record: Option<String>,
}

/// One complete zero-entity face-roster, shell, and body ownership hierarchy.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityOwnershipRoot {
    /// Stable native-root identity.
    pub(crate) id: String,
    /// Byte offset of the counted `6142` face-roster record.
    face_roster_byte_offset: u64,
    /// One-based global record ordinal of the face-roster record.
    pub(crate) face_roster_record_ordinal: u32,
    /// Descending one-based face-allocation slots.
    pub(crate) face_slots: Vec<u32>,
    /// Byte offset of the `6006` shell root.
    pub(crate) shell_byte_offset: u64,
    /// One-based global record ordinal of the shell root.
    pub(crate) shell_record_ordinal: u32,
    /// Byte offset of the `6508` body root.
    body_byte_offset: u64,
    /// One-based global record ordinal of the body root.
    pub(crate) body_record_ordinal: u32,
}

/// One framed record in the zero-entity global identity namespace.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct CatiaZeroEntityRecord {
    /// Stable native-record identity.
    id: String,
    /// Byte offset of the framed record.
    pub(crate) byte_offset: u64,
    /// Exclusive logical byte end, including any inline continuation.
    pub(crate) logical_end: u64,
    /// Complete two-byte record tag.
    pub(crate) tag: NativeBytes<[u8; 2]>,
    /// One-based global record ordinal.
    pub(crate) record_ordinal: u32,
}

macro_rules! define_catia_arenas {
    (
        $(
            $field:ident: $record:ty {
                $(
                    $(#[$attr:meta])*
                    $vis:vis $stored:ident;
                )?
                $(
                    => $owner:ident.$children:ident;
                )?
            }
        ),+ $(,)?
    ) => {
        /// Complete CATIA native arena manifest in stable order.
        ///
        /// The manifest states what `native_store_paths_cover_every_declared_arena`
        /// checks the store against, and nothing in the decode reads it, so it is
        /// built for that test alone.
        #[cfg(test)]
        const CATIA_ARENA_NAMES: &[&str] = &[
            $(stringify!($field)),+
        ];

        /// CATIA-native records retained outside the format-neutral model.
        #[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
        #[serde(try_from = "CatiaNativeWire", into = "CatiaNativeWire")]
        pub(crate) struct CatiaNative {
            $(
                $(
                    $(#[$attr])*
                    #[serde(default)]
                    $vis $field: Vec<$record>,
                )?
            )*
        }

        #[derive(Serialize, Deserialize)]
        struct CatiaNativeWire {
            $($( $(#[$attr])* #[serde(default)]
                $field: define_catia_arenas!(@native_type $field, $stored, $record),
            )?)*
        }

        impl From<CatiaNative> for CatiaNativeWire {
            fn from(mut native: CatiaNative) -> Self {
                let nodes = edge_node_wires(std::mem::take(&mut native.consolidated_edge_nodes), &native.consolidated_vertex_identities);
                Self {
                    $($( $field: define_catia_arenas!(@native_value $field, $stored, native, nodes), )?)*
                }
            }
        }

        impl TryFrom<CatiaNativeWire> for CatiaNative {
            type Error = String;
            fn try_from(mut wire: CatiaNativeWire) -> Result<Self, Self::Error> {
                let nodes = load_edge_nodes(std::mem::take(&mut wire.consolidated_edge_nodes), &wire.consolidated_vertex_identities)?;
                Ok(Self {
                    $($( $field: define_catia_arenas!(@native_value $field, $stored, wire, nodes), )?)*
                })
            }
        }

        /// Owning, flattened arena payload shared by borrowed and consuming stores.
        struct CatiaArenaProjection {
            $(
                $(
                    $field: define_catia_arenas!(@type $field, $stored, $record),
                )?
            )*
            $(
                $(
                    $field: define_catia_arenas!(
                        @flattened_type $field, $owner, $children, $record
                    ),
                )?
            )*
        }

        impl CatiaArenaProjection {
            fn from_owned(mut native: CatiaNative) -> Self {
                $(
                    $(
                        define_catia_arenas!(
                            @flattened_prepare native, $field, $owner, $children
                        );
                    )?
                )*
                $(
                    $(
                        define_catia_arenas!(@prepare $field, native, $stored, $field);
                    )?
                )*
                Self {
                    $(
                        $(
                            $field: define_catia_arenas!(
                                @stored_value $stored, native, $field, $field
                            ),
                        )?
                    )*
                    $(
                        $(
                            $field: define_catia_arenas!(
                                @flattened_value $owner, $children, $field
                            ),
                        )?
                    )*
                }
            }
        }

        type CatiaFamilyRow =
            FamilyRow<CatiaArenaProjection, (), cadmpeg_ir::NativeNamespace, ()>;

        /// Declarative CATIA native-family catalogue.
        const CATIA_FAMILIES: &[CatiaFamilyRow] = &[
            $(
                $(
                    define_catia_arenas!(@family $stored, $field),
                )?
            )*
            $(
                $(
                    define_catia_arenas!(@flattened_family $owner, $children, $field),
                )?
            )*
        ];

        impl Default for CatiaNative {
            fn default() -> Self {
                Self {
                    $(
                        $(
                            $field: define_catia_arenas!(@default $stored),
                        )?
                    )*
                }
            }
        }
    };
    (@native_type consolidated_edge_nodes, $kind:ident, $record:ty) => { Vec<CatiaConsolidatedEdgeNodeWire> };
    (@native_type $field:ident, $kind:ident, $record:ty) => { Vec<$record> };
    (@native_value consolidated_edge_nodes, $kind:ident, $owner:ident, $nodes:ident) => { $nodes };
    (@native_value $field:ident, $kind:ident, $owner:ident, $nodes:ident) => { $owner.$field };
    (@type consolidated_edge_nodes, $kind:ident, $record:ty) => { Vec<CatiaConsolidatedEdgeNodeWire> };
    (@type entity_records, $kind:ident, $record:ty) => { Vec<CatiaEntityRecordWire> };
    (@type object_graph_records, $kind:ident, $record:ty) => { Vec<CatiaObjectRecordWire> };
    (@type value_blocks, $kind:ident, $record:ty) => { Vec<CatiaValueBlockWire> };
    (@type schema_configuration_row_chains, $kind:ident, $record:ty) => {
        Vec<schema_configuration_chain::ChainWire>
    };
    (@prepare consolidated_edge_nodes, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = edge_node_wires(std::mem::take(&mut $native.consolidated_edge_nodes), &$native.consolidated_vertex_identities);
    };
    (@prepare entity_records, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = std::mem::take(&mut $native.entity_records).into_iter()
                .map(CatiaEntityRecordWire::from).collect::<Vec<_>>();
    };
    (@prepare object_graph_records, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = std::mem::take(&mut $native.object_graph_records).into_iter()
                .map(CatiaObjectRecordWire::from).collect::<Vec<_>>();
    };
    (@prepare value_blocks, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = std::mem::take(&mut $native.value_blocks).into_iter()
                .map(CatiaValueBlockWire::from).collect::<Vec<_>>();
    };
    (@prepare schema_configuration_row_chains, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = std::mem::take(&mut $native.schema_configuration_row_chains).into_iter()
                .map(schema_configuration_chain::ChainWire::from).collect::<Vec<_>>();
    };
    (@stored_value stored, $native:ident, consolidated_edge_nodes, $binding:ident) => { $binding };
    (@stored_value stored, $native:ident, entity_records, $binding:ident) => { $binding };
    (@stored_value stored, $native:ident, object_graph_records, $binding:ident) => { $binding };
    (@stored_value stored, $native:ident, value_blocks, $binding:ident) => { $binding };
    (@stored_value stored, $native:ident, schema_configuration_row_chains, $binding:ident) => { $binding };
    (@type catalogs, $kind:ident, $record:ty) => {
        Vec<CatiaCatalogWire>
    };
    (@type $field:ident, $kind:ident, $record:ty) => {
        Vec<$record>
    };
    (@flattened_type object_graph_records, $owner:ident, $children:ident, $record:ty) => {
        Vec<CatiaObjectRecordWire>
    };
    (@flattened_type $field:ident, $owner:ident, $children:ident, $record:ty) => {
        Vec<$record>
    };
    (@flattened_collect $native:ident, object_graph_records, $owner:ident, $children:ident) => {
        $native.$owner.iter_mut()
                .flat_map(|parent| std::mem::take(&mut parent.$children))
                .map(CatiaObjectRecordWire::from)
                .collect::<Vec<_>>()
    };
    (@flattened_collect $native:ident, $field:ident, $owner:ident, $children:ident) => {
        $native.$owner.iter_mut()
                .flat_map(|parent| std::mem::take(&mut parent.$children))
                .collect::<Vec<_>>()
    };
    (@flattened_prepare $native:ident, $field:ident, $owner:ident, $children:ident) => {
        let $field = define_catia_arenas!(
            @flattened_collect $native, $field, $owner, $children
        );
    };
    (@prepare catalogs, $native:ident, $kind:ident, $binding:ident) => {
        let $binding = ($native.catalogs.iter().map(|catalog| CatiaCatalogWire::header(catalog))).collect::<Vec<_>>();
    };
    (@prepare $field:ident, $native:ident, $kind:ident, $binding:ident) => {};
    (@stored_value stored, $native:ident, catalogs, $binding:ident) => {
        $binding
    };
    (@stored_value stored, $native:ident, $field:ident, $binding:ident) => {
        $native.$field
    };
    (@flattened_value $owner:ident, $children:ident, $field:ident) => {
        $field
    };
    (@family $kind:ident, $field:ident) => {
        CatiaFamilyRow {
            arena: stringify!($field),
            exactness: (),
            phase: Phase::ArenaOnly,
            emit: |ctx, projection, row, namespace| {
                namespace.set_arena(ctx, row.arena, &projection.$field)
            },
            len: |projection| projection.$field.len(),
            counts_toward_emptiness: true,
        }
    };
    (@flattened_family $owner:ident, $children:ident, $field:ident) => {
        define_catia_arenas!(@family flattened, $field)
    };
    (@default stored) => {
        Vec::new()
    };
}

define_catia_arenas! {
    alias_rows: CatiaAliasRow {
        /// Exact outer alias-row cores in source order.
        pub(crate) stored;
    },
    inline_fields: CatiaInlineField {
        /// Strict inline field incidences and complete wide schema paths.
        pub(crate) stored;
    },
    storage_property_members: CatiaStoragePropertyMember {
        /// Complete bounded storage-property members in source order.
        pub(crate) stored;
    },
    catalog_entries: CatiaCatalogEntry {
        => catalogs.entries;
    },
    catalogs: CatiaCatalog {
        /// Framed source-schema name catalogs.
        pub(crate) stored;
    },
    consolidated_circles: CatiaConsolidatedCircle {
        /// Exact consolidated arc-length circle supports.
        pub(crate) stored;
    },
    consolidated_class61_records: class61::CatiaConsolidatedClass61Record {
        /// Complete consolidated class-`0x61` records.
        pub(crate) stored;
    },
    consolidated_class5b5c_records: CatiaConsolidatedClass5b5cRecord {
        /// Complete source-local consolidated class-`0x5b`/`0x5c` records.
        pub(crate) stored;
    },
    consolidated_chamfers: CatiaConsolidatedChamfer {
        /// Complete compact two-support chamfer constructions.
        pub(crate) stored;
    },
    object_chamfers: CatiaObjectChamfer {
        /// Complete object-id two-support chamfer constructions.
        pub(crate) stored;
    },
    consolidated_cones: CatiaConsolidatedCone {
        /// Exact consolidated cone charts.
        pub(crate) stored;
    },
    consolidated_cylinders: CatiaConsolidatedCylinder {
        /// Exact consolidated cylinder charts.
        pub(crate) stored;
    },
    consolidated_a5_charts: CatiaConsolidatedA5Chart {
        /// Source-framed freeform chart sides.
        pub(crate) stored;
    },
    consolidated_domain_relations: CatiaConsolidatedDomainRelation {
        /// Complete source-local class-24 and class-25 scalar parameter relations.
        pub(crate) stored;
    },
    consolidated_a_class25_maps: CatiaConsolidatedAClass25Map {
        /// Complete source-local A-family class-25 sampled parameter maps.
        pub(crate) stored;
    },
    consolidated_edge_nodes: CatiaConsolidatedEdgeNode {
        /// Structurally complete consolidated edge nodes.
        pub(crate) stored;
    },
    consolidated_four_reference_edges: CatiaConsolidatedFourReferenceEdge {
        /// Complete compact class-0x5e records with four unassigned operands.
        pub(crate) stored;
    },
    consolidated_edge_runs: CatiaConsolidatedEdgeRun {
        /// Complete consolidated historical edge runs.
        pub(crate) stored;
    },
    consolidated_class60_records: CatiaConsolidatedClass60Record {
        /// Complete counted allocation-reference lists.
        pub(crate) stored;
    },
    consolidated_line_profiles: CatiaConsolidatedLineProfile {
        /// Exact consolidated B-family metric line profiles.
        pub(crate) stored;
    },
    consolidated_owner_packets: CatiaConsolidatedOwnerPacket {
        /// Exact consolidated owner packets and their allocation links.
        pub(crate) stored;
    },
    consolidated_parameter_points: CatiaConsolidatedParameterPoint {
        /// Exact consolidated parameter-space records.
        pub(crate) stored;
    },
    consolidated_plane_carriers: CatiaConsolidatedPlaneCarrier {
        /// Structurally complete consolidated class-`0x27` plane carriers.
        pub(crate) stored;
    },
    consolidated_pcurves: CatiaConsolidatedPcurve {
        /// Consolidated pcurve jets retained before support resolution.
        pub(crate) stored;
    },
    consolidated_reference_lists: CatiaConsolidatedReferenceList {
        /// Exact consolidated persistent-reference lists.
        pub(crate) stored;
    },
    consolidated_revolutions: CatiaConsolidatedRevolution {
        /// Consolidated revolution carriers retained before profile resolution.
        pub(crate) stored;
    },
    consolidated_rolling_ball_constructions: CatiaConsolidatedRollingBallConstruction {
        /// Source-closed rolling-ball constructions and their support records.
        #[serde(skip_serializing_if = "Vec::is_empty")]
        pub(crate) stored;
    },
    consolidated_rolling_ball_continuations: CatiaRollingBallContinuation {
        /// Exact numeric continuation limits and optional scalar jets.
        pub(crate) stored;
    },
    consolidated_spheres: CatiaConsolidatedSphere {
        /// Exact consolidated sphere charts.
        pub(crate) stored;
    },
    consolidated_tori: CatiaConsolidatedTorus {
        /// Exact consolidated torus charts.
        pub(crate) stored;
    },
    consolidated_vertex_identities: CatiaConsolidatedVertexIdentity {
        /// Scoped endpoint identities and their consolidated edge incidence.
        pub(crate) stored;
    },
    design_objects: CatiaDesignObject {
        /// Design objects grouped by their serialized owner entity identity.
        pub(crate) stored;
    },
    e5_edges: CatiaE5EdgeRecord {
        /// Source-bounded E5 edge operands and allocation terminals.
        pub(crate) stored;
    },
    e5_curve_supports: CatiaE5CurveSupportRecord {
        /// Complete E5 reference/co-facet correspondence programs.
        pub(crate) stored;
    },
    e5_nurbs_limit_programs: CatiaE5NurbsLimitRecord {
        /// Complete source limit programs retained before geometry admission.
        pub(crate) stored;
    },
    entity_records: CatiaEntityRecord {
        /// Exact `7C05` entity-table records paired with object records.
        pub(crate) stored;
    },
    external_references: CatiaExternalReference {
        /// External CATIA document references in source order.
        pub(crate) stored;
    },
    finjpl_segments: CatiaFinjplSegment {
        /// Complete bounded outer FINJPL segments.
        pub(crate) stored;
    },
    legacy_entity_runs: CatiaLegacyEntityRun {
        /// Monotone entity identities in pre-`7C05` design streams.
        pub(crate) stored;
    },
    object_graph_records: CatiaObjectRecord {
        => object_graphs.records;
    },
    object_graphs: CatiaObjectGraph {
        /// Outer ownership graphs.
        pub(crate) stored;
    },
    preview_images: CatiaPreviewImage {
        /// Exact JPEG previews extracted from summary-information records.
        pub(crate) stored;
    },
    sampled_parameter_maps: CatiaSampledParameterMap {
        /// Complete source-local A8 sampled parameter correspondences.
        pub(crate) stored;
    },
    reference_signature_cohorts: CatiaReferenceSignatureCohort {
        /// Source-ordered descriptor cohorts grouped by exact reference pair.
        pub(crate) stored;
    },
    schema_configuration_row_chains: CatiaSchemaConfigurationRowChain {
        /// Complete schema-configuration-row successor chains.
        pub(crate) stored;
    },
    value_blocks: CatiaValueBlock {
        /// Framed value blocks adjacent to source-schema catalogs.
        pub(crate) stored;
    },
    value_schema_selections: CatiaValueSchemaSelection {
        => value_blocks.schema_selections;
    },
    zero_entity_allocation_edges: CatiaZeroEntityAllocationEdge {
        /// Complete source edge/use/support/vertex allocation chains.
        pub(crate) stored;
    },
    zero_entity_edge_strides: CatiaZeroEntityEdgeStride {
        /// Zero-entity edge-stride allocation tuples.
        pub(crate) stored;
    },
    zero_entity_oriented_use_pairs: CatiaZeroEntityOrientedUsePair {
        /// Zero-entity side-pair headers and positional oriented uses.
        pub(crate) stored;
    },
    zero_entity_ownership_roots: CatiaZeroEntityOwnershipRoot {
        /// Complete zero-entity face-roster, shell, and body roots.
        pub(crate) stored;
    },
    zero_entity_records: CatiaZeroEntityRecord {
        /// Complete zero-entity framed-record identity namespace.
        pub(crate) stored;
    },
    zero_entity_support_runs: CatiaZeroEntitySupportRun {
        /// Zero-entity surface carriers and their face-local support tapes.
        pub(crate) stored;
    },
    zero_entity_vertex_incidences: CatiaZeroEntityVertexIncidence {
        /// Zero-entity counted vertex-incidence records.
        pub(crate) stored;
    },
}
const CATIA_CATALOGUE: Catalogue<
    'static,
    CatiaArenaProjection,
    (),
    cadmpeg_ir::NativeNamespace,
    (),
> = Catalogue::new(CATIA_FAMILIES);

fn store_projection(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    projection: &CatiaArenaProjection,
    namespace: &mut cadmpeg_ir::NativeNamespace,
) -> Result<(), cadmpeg_ir::NativeConvertError> {
    CATIA_CATALOGUE.emit_all(ctx, projection, namespace)?;
    Ok(())
}

fn consolidated_circles(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedCircle> {
    let mut circles = Vec::new();
    for (index, circle) in
        crate::families::b2::records::b2_circles_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedCircle {
            id: format!("catia:consolidated:circle#{index:00}"),
            byte_offset: u64_from_index(circle.pos),
            layout: circle.layout,
            record_id: circle.record_id,
            frame_token: circle.frame_token,
            center_pair: circle.center_pair,
            radius: circle.radius,
            range: circle.range,
            chart_shift: circle.chart_shift,
        };
        circles.push(value);
    }
    circles
}

fn legacy_role_selector(role: legacy_entity::LegacyRoleSelector) -> CatiaLegacyRoleSelector {
    CatiaLegacyRoleSelector {
        byte_offset: u64_from_index(role.offset),
        entity_id: role.entity_id,
        name: role.name,
        encoding: match role.encoding {
            legacy_entity::LegacyRoleSelectorEncoding::FixedU32 => {
                CatiaLegacyRoleSelectorEncoding::FixedU32
            }
            legacy_entity::LegacyRoleSelectorEncoding::Paged => {
                CatiaLegacyRoleSelectorEncoding::Paged
            }
        },
        selector: role.selector,
        field_code: role.field_code,
    }
}

fn legacy_entity_runs(bytes: &[u8]) -> Vec<CatiaLegacyEntityRun> {
    let mut converted = Vec::new();
    for (index, run) in legacy_entity::parse_runs(bytes).into_iter().enumerate() {
        let id = format!("catia:legacy:entity-run#{index:08}");
        let byte_offset = run.first_identity.offset;
        let identities = run
            .identities()
            .map(|identity| CatiaLegacyEntityIdentity {
                byte_offset: u64_from_index(identity.offset),
                entity_id: identity.entity_id,
                lead: identity.lead,
            })
            .collect::<Vec<_>>();
        let schema_program = run.schema_program.map(|program| CatiaLegacySchemaProgram {
            byte_offset: u64_from_index(program.offset),
            boundary_byte_offset: u64_from_index(program.boundary_offset),
            boundary: match program.boundary {
                legacy_entity::LegacySchemaProgramBoundary::VendorFooter => {
                    CatiaLegacySchemaProgramBoundary::VendorFooter
                }
                legacy_entity::LegacySchemaProgramBoundary::StreamDirectory => {
                    CatiaLegacySchemaProgramBoundary::StreamDirectory
                }
            },
            data: (program.bytes).into(),
            identifiers: program
                .identifiers
                .into_iter()
                .map(|identifier| CatiaLegacySchemaIdentifier {
                    byte_offset: u64_from_index(identifier.offset),
                    value: identifier.value,
                })
                .collect::<Vec<_>>(),
        });
        let role_selectors = run
            .role_selectors
            .into_iter()
            .map(legacy_role_selector)
            .collect::<Vec<_>>();
        let text_fields = run
            .text_fields
            .into_iter()
            .map(|field| CatiaLegacyTextField {
                byte_offset: u64_from_index(field.offset),
                entity_id: field.entity_id,
                encoding: match field.encoding {
                    legacy_entity::LegacyTextEncoding::U8InclusiveLength => {
                        CatiaLegacyTextEncoding::U8InclusiveLength
                    }
                    legacy_entity::LegacyTextEncoding::ZeroU32Length => {
                        CatiaLegacyTextEncoding::ZeroU32Length
                    }
                    legacy_entity::LegacyTextEncoding::U8InclusiveLengthE3RoleTail => {
                        CatiaLegacyTextEncoding::U8InclusiveLengthE3RoleTail
                    }
                },
                role: field.role.map(legacy_role_selector),
                value: field.value,
            })
            .collect::<Vec<_>>();
        let relations = run
            .relations
            .into_iter()
            .map(|relation| {
                let (inputs, output, result_type) = relation.signature.into_parts();
                let parameter = |parameter: legacy_entity::LegacyRelationParameter| {
                    CatiaLegacyRelationParameter {
                        parameter: parameter.parameter,
                        value_type: parameter.value_type,
                    }
                };
                CatiaLegacyRelation {
                    entity_id: relation.entity_id,
                    body_selector: relation.body_selector,
                    parameter_selector: relation.parameter_selector,
                    parameter_entity_id: relation.parameter_entity_id,
                    expression_offset: u64_from_index(relation.expression_offset),
                    expression: relation.expression,
                    signature_offset: u64_from_index(relation.signature_offset),
                    type_signature: relation.type_signature,
                    inputs: inputs.into_iter().map(parameter).collect::<Vec<_>>(),
                    output: output.map(parameter),
                    result_type,
                }
            })
            .collect::<Vec<_>>();
        let scalar_values = run
            .scalar_values
            .into_iter()
            .map(|value| CatiaLegacyScalarValue {
                id: format!("catia:legacy:scalar#{index:08}-{:016}", value.offset),
                byte_offset: u64_from_index(value.offset),
                entity_id: value.entity_id,
                encoding: match value.encoding {
                    legacy_entity::LegacyScalarEncoding::Named84 => {
                        CatiaLegacyScalarEncoding::Named84
                    }
                    legacy_entity::LegacyScalarEncoding::Standalone85 => {
                        CatiaLegacyScalarEncoding::Standalone85
                    }
                },
                name_field: value.name_offset.map(u64_from_index),
                name: value.name,
                evaluation: match value.evaluation {
                    legacy_entity::LegacyScalarEvaluation::Value(bits) => {
                        CatiaLegacyScalarEvaluation::Value { bits }
                    }
                    legacy_entity::LegacyScalarEvaluation::Unset => {
                        CatiaLegacyScalarEvaluation::Unset
                    }
                },
            })
            .collect::<Vec<_>>();
        let string_values = run
            .string_values
            .into_iter()
            .map(|value| CatiaLegacyStringValue {
                id: format!("catia:legacy:string#{index:08}-{:016}", value.offset),
                byte_offset: u64_from_index(value.offset),
                entity_id: value.entity_id,
                name_field: value.name_offset.map(u64_from_index),
                name: value.name,
                value: value.value,
            })
            .collect::<Vec<_>>();
        let integer_values = run
            .integer_values
            .into_iter()
            .map(|value| CatiaLegacyIntegerValue {
                id: format!("catia:legacy:integer#{index:08}-{:016}", value.offset),
                byte_offset: u64_from_index(value.offset),
                entity_id: value.entity_id,
                encoding: match value.encoding {
                    legacy_entity::LegacyIntegerEncoding::Inline => {
                        CatiaLegacyIntegerEncoding::Inline
                    }
                    legacy_entity::LegacyIntegerEncoding::WideI32 => {
                        CatiaLegacyIntegerEncoding::WideI32
                    }
                },
                name_field: value.name_offset.map(u64_from_index),
                name: value.name,
                value: value.value,
            })
            .collect::<Vec<_>>();
        let row = CatiaLegacyEntityRun {
            id,
            byte_offset: u64_from_index(byte_offset),
            byte_len: u64_from_index(run.catalog_offset - byte_offset),
            catalog_offset: u64_from_index(run.catalog_offset),
            schema_program,
            outer_container: None,
            identities,
            role_selectors,
            text_fields,
            schema_fields: run
                .schema_fields
                .into_iter()
                .map(|field| CatiaLegacySchemaField {
                    byte_offset: u64_from_index(field.offset),
                    entity_id: field.entity_id,
                    role_byte_offset: u64_from_index(field.role_offset),
                    boundary_role_byte_offset: u64_from_index(field.boundary_role_offset),
                    field_code: field.field_code,
                    payload: (field.payload).into(),
                })
                .collect::<Vec<_>>(),
            relations,
            synchronous_states: run
                .synchronous_states
                .into_iter()
                .map(|state| CatiaLegacyRelationSynchronousState {
                    role_byte_offset: u64_from_index(state.role_offset),
                    entity_id: state.entity_id,
                    selector: state.selector,
                    synchronous: state.synchronous,
                })
                .collect::<Vec<_>>(),
            type_descriptors: run
                .type_descriptors
                .into_iter()
                .map(|descriptor| CatiaLegacyTypeDescriptor {
                    byte_offset: u64_from_index(descriptor.offset),
                    entity_id: descriptor.entity_id,
                    value: match descriptor.value {
                        legacy_entity::LegacyTypeValue::Name(value) => {
                            CatiaLegacyTypeValue::Name { value }
                        }
                        legacy_entity::LegacyTypeValue::Selector(value) => {
                            CatiaLegacyTypeValue::Selector { value }
                        }
                    },
                })
                .collect::<Vec<_>>(),
            scalar_values,
            string_values,
            integer_values,
        };
        converted.push(row);
    }
    converted
}

pub(crate) fn legacy_evaluation_roles(
    roles: &[CatiaLegacyRoleSelector],
) -> impl Iterator<Item = (u32, u64, u64)> + '_ {
    roles.iter().filter_map(|role| {
        if role.field_code != Some(0x17c4) {
            return None;
        }
        let value_offset = role.end_offset()?.checked_add(6)?;
        Some((role.entity_id, value_offset, role.byte_offset))
    })
}

fn consolidated_class5b5c_records(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Result<Vec<CatiaConsolidatedClass5b5cRecord>, CodecError> {
    let mut control_records =
        crate::families::b2::records::b2_class5b5c_records_from_records(bytes, records)?;
    control_records.sort_by(|left, right| {
        (left.source_index, left.source_offset).cmp(&(right.source_index, right.source_offset))
    });
    let mut output = Vec::new();
    for (index, record) in control_records.into_iter().enumerate() {
        let value = CatiaConsolidatedClass5b5cRecord {
            id: format!("catia:consolidated:class5b5c-record#{index:00}"),
            frame: record.frame.into(),
            source_index: u64_from_index(record.source_index),
            source_offset: u64_from_index(record.source_offset),
            class: record.class,
        };
        output.push(value);
    }
    Ok(output)
}

fn consolidated_cones(bytes: &[u8], records: &[ConsolidatedRecord]) -> Vec<CatiaConsolidatedCone> {
    let mut cones = Vec::new();
    for (index, cone) in
        crate::families::b2::records::b2_cones_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedCone {
            id: format!("catia:consolidated:cone#{index:00}"),
            byte_offset: u64_from_index(cone.pos),
            apex: cone.apex.coordinates().into(),
            direction_x: cone.frame.reference(),
            direction_y: cone.t2,
            axis: cone.frame.axis(),
            half_angle: cone.half_angle,
            reference_radius: cone.reference_radius,
            angular_range: cone.angular_range,
            slant_range: cone.slant_range,
            angular_scale: cone.angular_scale,
            angular_domain: cone.angular_domain,
        };
        cones.push(value);
    }
    cones
}

fn consolidated_cylinders(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedCylinder> {
    let mut cylinders = Vec::new();
    for (index, cylinder) in
        crate::families::b2::records::b2_cylinders_from_records(bytes, records).enumerate()
    {
        let payload = match cylinder.layout {
            crate::families::b2::records::B2CylinderLayout::RangeOrigin { stored_vector } => {
                CatiaConsolidatedCylinderPayload::RangeOrigin {
                    stored_vector,
                    axis: cylinder.frame.axis(),
                    reference_direction: cylinder.frame.reference(),
                    range_origin: cylinder.range_origin().unwrap_or_else(|| {
                        crate::families::b2::records::cylinder_range_origin(
                            cylinder.radius.get(),
                            cylinder.u_range.endpoints(),
                        )
                    }),
                }
            }
            crate::families::b2::records::B2CylinderLayout::Full52 => {
                CatiaConsolidatedCylinderPayload::Layout52 {
                    frame_token: cylinder.frame_token(),
                    axis: cylinder.frame.axis(),
                    reference_direction: cylinder.frame.reference(),
                }
            }
            crate::families::b2::records::B2CylinderLayout::Full5a { frame_token } => {
                CatiaConsolidatedCylinderPayload::Layout5a {
                    frame_token,
                    axis: cylinder.frame.axis(),
                    reference_direction: cylinder.frame.reference(),
                }
            }
        };
        let value = CatiaConsolidatedCylinder {
            id: format!("catia:consolidated:cylinder#{index:00}"),
            byte_offset: u64_from_index(cylinder.pos),
            header: cylinder.header,
            origin: cylinder.origin.coordinates().into(),
            radius: cylinder.radius,
            u_range: cylinder.u_range,
            v_range: cylinder.v_range,
            payload,
        };
        cylinders.push(value);
    }
    cylinders
}

fn consolidated_parameter_points(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedParameterPoint> {
    let mut points = Vec::new();
    for (index, point) in
        crate::families::b2::records::b2_parameter_points_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedParameterPoint {
            id: format!("catia:consolidated:parameter-point#{index:00}"),
            byte_offset: u64_from_index(point.pos),
            byte_len: u64_from_index(point.end - point.pos),
            operand: point.operand,
            control: point.control,
            payload: point.payload,
        };
        points.push(value);
    }
    points
}

fn consolidated_plane_carriers(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedPlaneCarrier> {
    let mut carriers = Vec::new();
    for (index, carrier) in
        crate::families::b2::records::b2_plane_carriers_from_records(bytes, records)
            .into_iter()
            .enumerate()
    {
        let value = CatiaConsolidatedPlaneCarrier {
            id: format!("catia:consolidated:plane-carrier#{index:00}"),
            byte_offset: u64_from_index(carrier.pos),
            byte_len: u64_from_index(carrier.end - carrier.pos),
            width: carrier.width,
            flag: carrier.flag,
            header_token: carrier.header_token,
            payload: carrier.payload,
        };
        carriers.push(value);
    }
    carriers
}

fn consolidated_reference_lists(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedReferenceList> {
    let mut lists = Vec::new();
    for (index, list) in
        crate::families::b2::records::b2_reference_lists_from_records(bytes, records)
            .into_iter()
            .enumerate()
    {
        let value = CatiaConsolidatedReferenceList {
            id: format!("catia:consolidated:reference-list#{index:00}"),
            byte_offset: u64_from_index(list.pos),
            references: list.references,
        };
        lists.push(value);
    }
    lists
}

fn consolidated_pcurves(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedPcurve> {
    let a = crate::wire::records::family_pcurves_from_records(
        bytes,
        records,
        crate::wire::records::ConsolidatedFamily::A,
    );
    let b = crate::wire::records::family_pcurves_from_records(
        bytes,
        records,
        crate::wire::records::ConsolidatedFamily::B,
    );
    let mut pcurves = a
        .into_iter()
        .map(|pcurve| (pcurve, CatiaConsolidatedFamily::A))
        .chain(
            b.into_iter()
                .map(|pcurve| (pcurve, CatiaConsolidatedFamily::B)),
        )
        .collect::<Vec<_>>();
    pcurves.sort_by_key(|(left, _)| left.pos);
    let mut native = Vec::new();
    for (index, (pcurve, family)) in pcurves.into_iter().enumerate() {
        let (knots, points, first_derivatives, second_derivatives) = pcurve.native_lanes();
        let value = CatiaConsolidatedPcurve {
            id: format!("catia:consolidated:pcurve#{index:00}"),
            byte_offset: u64_from_index(pcurve.pos),
            family,
            support_id: pcurve.support_id,
            degree: crate::wire::records::ConsolidatedPcurve::DEGREE,
            extrapolation_sites: pcurve.extrapolation_sites,
            knots,
            points,
            first_derivatives,
            second_derivatives,
            range: pcurve.range,
            tail: (pcurve.tail).into(),
        };
        native.push(value);
    }
    native
}

fn consolidated_rolling_ball_constructions(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedRollingBallConstruction> {
    crate::families::b2::records::b2_rolling_ball_constructions_from_records(bytes, records)
        .into_iter()
        .enumerate()
        .map(
            |(index, construction)| CatiaConsolidatedRollingBallConstruction {
                id: format!("catia:consolidated:rolling-ball-construction#{index:00}"),
                byte_offset: u64_from_index(construction.pos),
                source_index: u64_from_index(construction.source_index),
                carrier_byte_offset: u64_from_index(construction.carrier_pos),
                support_surface_byte_offsets: construction
                    .support_surface_positions
                    .map(u64_from_index),
                support_pcurve_byte_offsets: construction
                    .support_pcurve_positions
                    .map(u64_from_index),
                construction_radius: construction.construction_radius,
            },
        )
        .collect()
}

fn consolidated_revolutions(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
    circles: &[CatiaConsolidatedCircle],
) -> Vec<CatiaConsolidatedRevolution> {
    let mut resolved_profiles = HashMap::new();
    for resolved in
        crate::families::b2::records::b2_resolved_revolutions_from_records(bytes, records)
    {
        resolved_profiles.insert(
            u64_from_index(resolved.revolution.pos),
            u64_from_index(resolved.profile.pos),
        );
    }
    let mut circle_ids = HashMap::new();
    for circle in circles {
        let id = circle.id.clone();
        circle_ids.insert(circle.byte_offset, id);
    }
    let mut revolutions = Vec::new();
    for (index, revolution) in
        crate::families::b2::records::b2_revolutions_from_records(bytes, records).enumerate()
    {
        let profile_circle = resolved_profiles
            .get(&(u64_from_index(revolution.pos)))
            .and_then(|offset| circle_ids.get(offset))
            .cloned();
        let value = CatiaConsolidatedRevolution {
            id: format!("catia:consolidated:revolution#{index:00}"),
            byte_offset: u64_from_index(revolution.pos),
            reference_token: revolution.reference_token,
            profile_reference: revolution.profile_reference,
            origin: revolution.origin.coordinates().into(),
            direction_x: revolution.profile_frame.axis(),
            direction_y: revolution.profile_frame.reference(),
            axis: revolution.axis,
            angular_range: revolution.angular_range,
            profile_range: revolution.profile_range,
            profile_circle,
            angular_scale: revolution.angular_scale,
        };
        revolutions.push(value);
    }
    revolutions
}

fn consolidated_line_profiles(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedLineProfile> {
    let mut profiles = Vec::new();
    for (index, line) in
        crate::families::b2::records::b2_line_profiles_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedLineProfile {
            id: format!("catia:consolidated:line-profile#{index:00}"),
            byte_offset: u64_from_index(line.pos),
            origin: line.origin.coordinates().into(),
            direction: line.direction,
            range: line.range,
        };
        profiles.push(value);
    }
    profiles
}

fn consolidated_spheres(
    bytes: &[u8],
    records: &[ConsolidatedRecord],
) -> Vec<CatiaConsolidatedSphere> {
    let mut spheres = Vec::new();
    for (index, sphere) in
        crate::families::b2::records::b2_spheres_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedSphere {
            id: format!("catia:consolidated:sphere#{index:00}"),
            byte_offset: u64_from_index(sphere.pos),
            center: sphere.center.coordinates().into(),
            direction_x: sphere.frame.reference(),
            direction_y: sphere.direction_y,
            axis: sphere.frame.axis(),
            radius: sphere.radius,
            azimuth_range: sphere.azimuth_range,
            latitude_range: sphere.latitude_range,
        };
        spheres.push(value);
    }
    spheres
}

fn consolidated_tori(bytes: &[u8], records: &[ConsolidatedRecord]) -> Vec<CatiaConsolidatedTorus> {
    let mut tori = Vec::new();
    for (index, torus) in
        crate::families::b2::records::b2_tori_from_records(bytes, records).enumerate()
    {
        let value = CatiaConsolidatedTorus {
            id: format!("catia:consolidated:torus#{index:00}"),
            byte_offset: u64_from_index(torus.pos),
            center: torus.center.coordinates().into(),
            direction_x: torus.frame.reference(),
            direction_y: torus.direction_y,
            axis: torus.frame.axis(),
            major_radius: torus.major_radius,
            minor_radius: torus.minor_radius,
            major_angular_range: torus.major_angular_range,
            major_angular_domain: torus.major_angular_domain,
            minor_angular_range: torus.minor_angular_range,
            minor_angular_domain: torus.minor_angular_domain,
            major_scale: torus.major_scale,
            minor_scale: torus.minor_scale,
        };
        tori.push(value);
    }
    tori
}

fn zero_entity_support_runs(
    runs: Vec<crate::families::zero_entity::records::ZeroEntitySupportRun>,
    records: &[CatiaZeroEntityRecord],
) -> Vec<CatiaZeroEntitySupportRun> {
    let mut output = Vec::new();

    for (index, run) in runs.into_iter().enumerate() {
        let face = if let Some(face) = run.face {
            let mut loop_terminals = Vec::new();
            if let Some(&first) = face.allocations.first() {
                for allocation in &face.allocations[1..] {
                    if let Some(terminal) = first.checked_sub(*allocation) {
                        loop_terminals.push(terminal);
                    }
                }
            }
            let terminal_control = face.terminal_control.as_byte();
            let loops = face.loops.unwrap_or_default();
            let mut native_loops = Vec::new();

            for loop_record in loops {
                let mut edge_stride_records = Vec::new();
                for distance in &loop_record.edge_stride_distances {
                    let Some(record) = loop_record
                        .record_ordinal
                        .checked_sub(*distance)
                        .and_then(|ordinal| zero_entity_record(records, ordinal))
                        .filter(|record| record.tag == [0x5e, 0x1a])
                    else {
                        edge_stride_records.clear();
                        break;
                    };
                    edge_stride_records.push(record.id.clone());
                }
                let mut member_ids = Vec::new();

                member_ids.extend(loop_record.members.member_ids());
                native_loops.push(CatiaZeroEntityLoop {
                    byte_offset: u64_from_index(loop_record.pos),
                    record_ordinal: loop_record.record_ordinal,
                    tag: (loop_record.tag).into(),
                    member_ids,
                    edge_stride_distances: loop_record.edge_stride_distances,
                    edge_stride_records,
                    support_record_ordinals: loop_record.support_record_ordinals,
                    terminal_id: loop_record.members.terminal_id(),
                    gap: loop_record.members.gap(),
                    loop_class: loop_record.loop_class.as_byte(),
                    forward_senses: loop_record.forward_senses,
                    oriented_model_endpoints: loop_record.oriented_model_endpoints,
                });
            }
            Some(CatiaZeroEntityFace {
                byte_offset: u64_from_index(face.pos),
                record_ordinal: face.record_ordinal,
                tag: (face.tag).into(),
                allocations: face.allocations,
                loop_terminals,
                loops: native_loops,
                terminal_control,
            })
        } else {
            None
        };
        let mut supports = Vec::new();

        for support in run.supports {
            supports.push(CatiaZeroEntitySupportOccurrence {
                byte_offset: u64_from_index(support.pos),
                record_ordinal: support.record_ordinal,
                tag: (support.tag).into(),
                face_local_slot: support.face_local_slot,
                uv_endpoints: support.uv_endpoints,
                pcurve: support.pcurve,
                model_curve: support.model_curve,
                model_curve_construction: support.model_curve_construction,
                model_parameters: support.model_parameters,
                model_midpoint: support.model_midpoint,
                model_endpoints: support.model_endpoints,
            });
        }
        output.push(CatiaZeroEntitySupportRun {
            id: format!("catia:zero-entity:support-run#{index}"),
            carrier_byte_offset: u64_from_index(run.carrier_pos),
            carrier_record_ordinal: run.carrier_record_ordinal,
            face,
            supports,
        });
    }
    output
}

fn zero_entity_edge_strides(bytes: &[u8], range: Range<usize>) -> Vec<CatiaZeroEntityEdgeStride> {
    let records =
        crate::families::zero_entity::records::zero_entity_edge_strides_in_range(bytes, range);
    let mut output = Vec::new();

    for (index, record) in records.into_iter().enumerate() {
        output.push(CatiaZeroEntityEdgeStride {
            id: format!("catia:zero-entity:edge-stride#{index}"),
            byte_offset: u64_from_index(record.pos),
            record_ordinal: record.record_ordinal,
            allocations: record.allocations,
        });
    }
    output
}

fn zero_entity_oriented_use_pairs(
    bytes: &[u8],
    range: Range<usize>,
) -> Vec<CatiaZeroEntityOrientedUsePair> {
    use crate::families::zero_entity::records::ZeroEntityUseSlot;

    let pairs = crate::families::zero_entity::records::zero_entity_oriented_use_pairs_in_range(
        bytes, range,
    );
    let mut output = Vec::new();

    for (index, pair) in pairs.into_iter().enumerate() {
        output.push(CatiaZeroEntityOrientedUsePair {
            id: format!("catia:zero-entity:oriented-use-pair#{index}"),
            header_byte_offset: u64_from_index(pair.header_pos),
            header_record_ordinal: pair.header_record_ordinal,
            base_columns: pair.base_columns(),
            uses: [
                (ZeroEntityUseSlot::First, &pair.uses[0]),
                (ZeroEntityUseSlot::Second, &pair.uses[1]),
            ]
            .map(|(slot, use_)| CatiaZeroEntityOrientedUse {
                byte_offset: u64_from_index(use_.pos),
                record_ordinal: use_.record_ordinal,
                side: slot.side(),
                allocations: pair.allocations(slot),
            }),
        });
    }
    output
}

fn zero_entity_ownership_roots(
    bytes: &[u8],
    range: Range<usize>,
) -> Result<Vec<CatiaZeroEntityOwnershipRoot>, CodecError> {
    let roots =
        crate::families::zero_entity::records::zero_entity_ownership_roots_in_range(bytes, range);
    let mut output = Vec::new();

    for (index, root) in roots.into_iter().enumerate() {
        let shell_record_ordinal = root.shell_record_ordinal()?;
        let body_record_ordinal = root.body_record_ordinal()?;
        output.push(CatiaZeroEntityOwnershipRoot {
            id: format!("catia:zero-entity:ownership-root#{index}"),
            face_roster_byte_offset: u64_from_index(root.face_roster_pos),
            face_roster_record_ordinal: root.face_roster_record_ordinal,
            face_slots: root.face_slots,
            shell_byte_offset: u64_from_index(root.shell_pos),
            shell_record_ordinal,
            body_byte_offset: u64_from_index(root.body_pos),
            body_record_ordinal,
        });
    }
    Ok(output)
}

fn zero_entity_vertex_incidences(
    bytes: &[u8],
    range: Range<usize>,
    records: &[CatiaZeroEntityRecord],
) -> Vec<CatiaZeroEntityVertexIncidence> {
    let incidences =
        crate::families::zero_entity::records::zero_entity_vertex_incidences_in_range(bytes, range);
    let mut output = Vec::new();

    for (index, record) in incidences.into_iter().enumerate() {
        let vertex_record =
            zero_entity_vertex_owner(records, record.record_ordinal).map(|owner| owner.id.clone());
        output.push(CatiaZeroEntityVertexIncidence {
            id: format!("catia:zero-entity:vertex-incidence#{index}"),
            byte_offset: u64_from_index(record.pos),
            record_ordinal: record.record_ordinal,
            tag: (record.tag()).into(),
            allocations: record.allocations.as_slice().to_vec(),
            vertex_record,
        });
    }
    output
}

fn zero_entity_records(bytes: &[u8], range: Range<usize>) -> Vec<CatiaZeroEntityRecord> {
    let records =
        crate::families::zero_entity::records::zero_entity_record_inventory_in_range(bytes, range);
    let mut output = Vec::new();

    for record in records {
        output.push(CatiaZeroEntityRecord {
            id: format!("catia:zero-entity:record#{}", record.record_ordinal),
            byte_offset: u64_from_index(record.pos),
            logical_end: u64_from_index(record.end),
            tag: (record.tag).into(),
            record_ordinal: record.record_ordinal,
        });
    }
    output
}

impl CatiaNative {
    /// Decode CATIA-native records using container-bounded consolidated
    /// record sources.
    #[cfg(test)]
    pub(crate) fn decode_with_record_ranges(bytes: &[u8], ranges: &[Range<usize>]) -> Self {
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            bytes,
            &arena,
            &cadmpeg_core::decode::DecodePolicy::service(),
        )
        .expect("test record source fits the service profile");
        let sources: Vec<_> = ranges
            .iter()
            .map(|range| {
                vec![
                    crate::wire::records::SourceExtent::within(bytes, range.start, range.end)
                        .expect("bounded test source"),
                ]
            })
            .collect();
        Self::decode_with_record_sources(
            &ctx,
            bytes,
            &sources,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .expect("decode the records")
    }

    /// Decode CATIA-native records from descriptor-scoped logical sources.
    pub(crate) fn decode_with_record_sources(
        ctx: &cadmpeg_core::decode::DecodeContext<'_>,
        bytes: &[u8],
        sources: &[Vec<crate::wire::records::SourceExtent>],
        refusal: &mut crate::nurbs::LaneRefusals,
    ) -> Result<Self, cadmpeg_core::CodecError> {
        let consolidated_records = crate::wire::records::consolidated_records_in_sources(
            bytes,
            sources.iter().map(|source| source.iter()),
        )?;
        let mut native = Self::decode_with_records(ctx, bytes, &consolidated_records, refusal)?;
        native.sampled_parameter_maps =
            parameter_map::derive(ctx, bytes, sources, &consolidated_records)?;
        Ok(native)
    }

    fn decode_with_records(
        ctx: &cadmpeg_core::decode::DecodeContext<'_>,
        bytes: &[u8],
        consolidated_records: &[ConsolidatedRecord],
        refusal: &mut crate::nurbs::LaneRefusals,
    ) -> Result<Self, cadmpeg_core::CodecError> {
        let outer_directory = container::parse_outer_stream_directory(bytes);
        let outer_container_declarations = match outer_directory.as_ref() {
            Some(outer) => container::outer_container_declarations(bytes, outer),
            None => Vec::new(),
        };
        let parsed_finjpl = container::finjpl_segments(&container::BodyExtent::whole(bytes));
        let storage_property_members = storage_property::parse(bytes, &parsed_finjpl)?;
        let parsed_alias_rows = object_graph::surface_aliases(bytes, &parsed_finjpl);
        let mut finjpl_segments = Vec::new();
        for (index, segment) in parsed_finjpl.into_iter().enumerate() {
            let id = format!("catia:outer:finjpl#{index}");
            let family = finjpl_family(segment.kind()).to_owned();
            let data = bytes[segment.range.clone()].to_vec();
            finjpl_segments.push(CatiaFinjplSegment {
                id,
                byte_offset: u64_from_index(segment.range.start),
                byte_len: u64_from_index(segment.range.end - segment.range.start),
                type_word: segment.type_word,
                family,
                name: segment.name,
                data: (data).into(),
            });
        }
        let catalog_scan = catalog::parse(bytes);
        refusal.push_catalog_scan_bounded(catalog_scan.bounded_candidates);
        let mut parsed_catalogs = catalog_scan.catalogs;
        let entity_runs = entity_table::parse_runs(ctx, bytes)?;
        let paired_object_graph_roots = entity_runs
            .iter()
            .filter_map(|run| {
                let end = run.last()?.pos.checked_add(run.last()?.total_len())?;
                (bytes.get(end) == Some(&0xde)).then_some((end + 1, run.len()))
            })
            .collect::<std::collections::HashMap<_, _>>();
        let mut alias_rows = Vec::new();
        for row in parsed_alias_rows {
            let row = CatiaAliasRow::from_source(row);
            alias_rows.push(row);
        }
        let mut parsed_object_graphs =
            object_graph::parse_all_with_paired_roots(bytes, &paired_object_graph_roots);
        let mut parsed_value_blocks = value_block::parse(bytes);
        filter_nested_inventory(
            &mut parsed_object_graphs,
            &mut parsed_value_blocks,
            &mut parsed_catalogs,
        );
        let mut catalogs = Vec::new();
        for catalog in parsed_catalogs {
            let catalog = CatiaCatalog::from_source(catalog);
            catalogs.push(catalog);
        }
        let mut entity_runs = entity_runs
            .into_iter()
            .filter_map(|run| {
                let end = run.last()?.pos.checked_add(run.last()?.total_len())?;
                (bytes.get(end) == Some(&0xde)).then_some(((end + 1, run.len()), run))
            })
            .collect::<std::collections::HashMap<_, _>>();
        let mut entity_records = Vec::new();
        let mut object_graphs = Vec::new();
        for graph in parsed_object_graphs {
            let entities = entity_runs
                .remove(&(graph.pos, graph.records.len()))
                .unwrap_or_default();
            let finjpl_segment = containing_finjpl_segment(
                u64_from_index(graph.pos),
                u64_from_index(graph.total_len),
                &finjpl_segments,
            )
            .map(std::borrow::ToOwned::to_owned);
            let outer_container = outer_directory
                .as_ref()
                .and_then(|outer| {
                    container::outer_container_for_extent(
                        outer,
                        &outer_container_declarations,
                        u64_from_index(graph.pos),
                        u64_from_index(graph.total_len),
                    )
                })
                .map(CatiaOuterContainerBinding::from_source);
            let (graph, mut entities) =
                native_object_graph(graph, entities, finjpl_segment, outer_container);

            entity_records.append(&mut entities);
            object_graphs.push(graph);
        }
        let mut catalogs_by_offset = HashMap::new();
        for catalog in &catalogs {
            catalogs_by_offset
                .entry(catalog.byte_offset)
                .or_insert(catalog);
        }
        let mut entities_by_graph = HashMap::<String, Vec<usize>>::new();
        for (index, entity) in entity_records.iter().enumerate() {
            entities_by_graph
                .entry(entity.object_graph.clone())
                .or_default()
                .push(index);
        }
        for graph in &mut object_graphs {
            let catalog = graph
                .catalog_byte_offset
                .and_then(|offset| catalogs_by_offset.get(&offset).copied());
            graph.catalog = catalog.map(|catalog| catalog.id.clone());
            for record in &mut graph.records {
                if let Some(class) = &mut record.class {
                    let entry = usize::try_from(class.ordinal)
                        .ok()
                        .and_then(|ordinal| catalog?.entries.get(ordinal));
                    if let Some(entry) = entry {
                        charge_class_text(ctx, &entry.id, &entry.value)?;
                    }
                    class.entry = entry.map(|entry| entry.id.clone());
                    class.name = entry.map(|entry| entry.value.clone());
                }
                record.repeated_reference_schema_selection = repeated_reference_schema_selection(
                    ctx,
                    object_graph::repeated_reference_schema_preamble(&record.payload).as_ref(),
                    catalog,
                )?;
            }
            let incidences = EntityIncidenceIndex::new(&graph.records, &graph.id);
            for &index in entities_by_graph.get(&graph.id).into_iter().flatten() {
                let entity = &mut entity_records[index];
                entity.definition_schema_selections = definition_schema_selections(
                    ctx,
                    &entity_table::parse_definition_schema_selectors(entity.definition_prefix()),
                    catalog,
                )?;
                let value_fields = entity.value_fields();
                let value_packets = entity.value_packets(&value_fields);
                entity.value_schema_selections =
                    entity_value_schema_selections(ctx, &value_fields, catalog, &value_packets)?;
                entity.parse_suffix();
                entity.suffix_schema_selection =
                    entity_suffix_schema_selection(ctx, entity.suffix_value(), catalog)?;
                entity.value_production =
                    value_production(ctx, entity, &incidences, &value_fields)?;
                entity.range_interval = resolved_range_interval(
                    ctx,
                    entity.value_payload(),
                    &entity.value_schema_selections,
                    entity.suffix_value(),
                    &incidences,
                    entity.entity_id,
                )?;
            }
        }
        let entity_classes_by_graph_identity =
            entity_class_index(object_graphs.iter().flat_map(|graph| &graph.records));
        let (
            relation_expressions,
            relation_expression_entities,
            entities_by_graph_identity,
            terminal_nulls_by_graph,
            parameter_bindings,
        ) = semantic_entity_indices(&entity_records, &entity_classes_by_graph_identity)?;
        let entity_references = CatiaEntityReferenceIndex {
            entities: &entities_by_graph_identity,
            classes: &entity_classes_by_graph_identity,
            terminal_nulls: &terminal_nulls_by_graph,
        };
        // The first graph with an id owns it, and within that graph the first
        // record with an id, as front-to-back searches resolve them.
        let mut object_records = HashMap::<&str, HashMap<&str, &CatiaObjectRecord>>::new();
        for graph in &object_graphs {
            if let std::collections::hash_map::Entry::Vacant(slot) =
                object_records.entry(graph.id.as_str())
            {
                let records = slot.insert(HashMap::new());
                for record in &graph.records {
                    records.entry(record.id.as_str()).or_insert(record);
                }
            }
        }
        let mut relation_dependencies = RelationDependencies::new(
            &parameter_bindings,
            bytes
                .len()
                .checked_mul(MAX_RELATION_DEPENDENCY_BYTES_PER_INPUT_BYTE)
                .unwrap_or(bytes.len()),
        );
        for entity in &mut entity_records {
            if let Some(signature) = entity.reference_signature.take() {
                entity.reference_signature = Some(reference_signature(
                    ctx,
                    signature.production,
                    &entity.object_graph,
                    &entity_references,
                )?);
            }
            let Some(object) = object_records
                .get(entity.object_graph.as_str())
                .and_then(|records| records.get(entity.object_record.as_str()).copied())
            else {
                continue;
            };
            entity.object_production = object_production(
                ctx,
                entity,
                object,
                &entity_references,
                &relation_expressions,
                &relation_expression_entities,
                &mut relation_dependencies,
            )?;
        }
        let inline_fields = inline_field::derive(&object_graphs, &entity_records, &catalogs);
        let reference_signature_cohorts = derive_reference_signature_cohorts(&entity_records);
        refusal.push_relation_dependencies_bounded(relation_dependencies.bounded_relations);
        let row_chains = derive_schema_configuration_row_chains(
            ctx,
            &entity_records,
            &entity_references,
            object_graphs.iter().flat_map(|graph| &graph.records),
        )?;
        refusal.push_configuration_row_order_bounded(row_chains.bounded_links);
        let schema_configuration_row_chains = row_chains.chains;
        alias_rows.retain(|row| {
            // A marker inside the first four bytes of the image has no row
            // frame, so the row is not an independent alias core. Refuse it
            // here rather than aliasing its frame with the file head.
            let Some(row_start) = row.row_byte_offset() else {
                return false;
            };
            !object_graphs
                .iter()
                .any(|graph| extents_overlap(row_start, 24, graph.byte_offset, graph.byte_len))
                && !parsed_value_blocks.iter().any(|block| {
                    extents_overlap(
                        row_start,
                        24,
                        u64_from_index(block.pos),
                        u64_from_index(block.total_len()),
                    )
                })
                && !catalogs.iter().any(|catalog| {
                    extents_overlap(row_start, 24, catalog.byte_offset, catalog.byte_len)
                })
        });
        resolve_alias_surface_tags(&mut alias_rows);
        let design_objects = design_objects(ctx, &object_graphs, &entity_records)?;
        let part_graph = {
            let mut graphs = object_graphs.iter().filter(|graph| {
                graph
                    .outer_container
                    .as_ref()
                    .is_some_and(|container| container.class_name == "CATPrtCont")
            });
            match (graphs.next(), graphs.next()) {
                (Some(graph), None) => Some(graph),
                _ => None,
            }
        };
        if let Some(graph) = part_graph {
            for row in &mut alias_rows {
                let Some(index) = usize::from(row.entity_record_ordinal()).checked_sub(1) else {
                    continue;
                };
                let Some(record) = graph.records.get(index) else {
                    continue;
                };
                row.object_graph = Some(graph.id.clone());
                row.object_record = Some(record.id.clone());
                row.design_object = record
                    .design_object
                    .as_ref()
                    .map(std::borrow::ToOwned::to_owned);
            }
        }
        let mut value_blocks = Vec::new();
        for block in parsed_value_blocks {
            let Some(catalog_pos) = block.pos.checked_add(block.total_len()).map(u64_from_index)
            else {
                continue;
            };
            let Some(catalog) = catalogs
                .iter()
                .find(|catalog| catalog.byte_offset == catalog_pos)
            else {
                continue;
            };
            let block_pos = u64_from_index(block.pos);
            let object_graph = object_graphs.iter().find(|graph| {
                graph
                    .byte_offset
                    .checked_add(graph.byte_len)
                    .is_some_and(|end| end == block_pos)
            });
            let value = CatiaValueBlock::from_parts(block, catalog, object_graph);
            value_blocks.push(value);
        }
        let preview_images = preview_views(&finjpl_segments);
        let external_references = external_reference_views(&finjpl_segments);
        let mut legacy_entity_runs = legacy_entity_runs(bytes);
        for run in &mut legacy_entity_runs {
            run.outer_container = outer_directory
                .as_ref()
                .and_then(|outer| {
                    container::outer_container_for_extent(
                        outer,
                        &outer_container_declarations,
                        run.byte_offset,
                        run.byte_len,
                    )
                })
                .map(CatiaOuterContainerBinding::from_source);
        }
        let consolidated_circles = consolidated_circles(bytes, consolidated_records);
        let consolidated_a5_charts = a5_chart::derive(bytes, consolidated_records)?;
        let consolidated_class61_records = class61::records(bytes, consolidated_records)?;
        let consolidated_class5b5c_records =
            consolidated_class5b5c_records(bytes, consolidated_records)?;
        let consolidated_parameter_points =
            consolidated_parameter_points(bytes, consolidated_records);
        let consolidated_chamfers =
            consolidated_chamfers(bytes, consolidated_records, &consolidated_parameter_points);
        let object_chamfers = object_chamfers(bytes);
        let consolidated_cones = consolidated_cones(bytes, consolidated_records);
        let consolidated_cylinders = consolidated_cylinders(bytes, consolidated_records);
        let consolidated_class60_records = class60::records(bytes, consolidated_records)?;
        let consolidated_line_profiles = consolidated_line_profiles(bytes, consolidated_records);
        let mut consolidated_owner_packets =
            consolidated_owner_packets(bytes, consolidated_records)?;
        resolve_owner_chart_support_aliases(&mut consolidated_owner_packets, &alias_rows);
        let consolidated_pcurves = consolidated_pcurves(bytes, consolidated_records);
        let consolidated_plane_carriers = consolidated_plane_carriers(bytes, consolidated_records);
        let consolidated_reference_lists =
            consolidated_reference_lists(bytes, consolidated_records);
        let consolidated_revolutions =
            consolidated_revolutions(bytes, consolidated_records, &consolidated_circles);
        let consolidated_rolling_ball_constructions =
            consolidated_rolling_ball_constructions(bytes, consolidated_records);
        let consolidated_spheres = consolidated_spheres(bytes, consolidated_records);
        let consolidated_tori = consolidated_tori(bytes, consolidated_records);
        let consolidated_domain_relations = domain_relation::derive(bytes, consolidated_records)?;
        let consolidated_a_class25_maps = a_class25_map::derive(bytes, consolidated_records)?;
        let zero_entity_range = container::outer_preamble_range(bytes).unwrap_or_else(|| {
            if bytes.starts_with(container::OUTER_MAGIC) {
                0..0
            } else {
                0..bytes.len()
            }
        });
        let zero_entity_records = zero_entity_records(bytes, zero_entity_range.clone());
        let zero_entity_edge_strides = zero_entity_edge_strides(bytes, zero_entity_range.clone());
        let zero_entity_oriented_use_pairs =
            zero_entity_oriented_use_pairs(bytes, zero_entity_range.clone());
        let zero_entity_ownership_roots =
            zero_entity_ownership_roots(bytes, zero_entity_range.clone())?;
        let parsed_zero_entity_support_runs =
            crate::families::zero_entity::records::zero_entity_support_runs_in_range(
                ctx,
                bytes,
                zero_entity_range.clone(),
                refusal,
            )?;
        let zero_entity_allocation_edges = zero_entity_allocation::derive(
            crate::families::zero_entity::allocation::parse(
                bytes,
                zero_entity_range.clone(),
                &parsed_zero_entity_support_runs,
            )?,
            &zero_entity_records,
        )?;
        let zero_entity_support_runs =
            zero_entity_support_runs(parsed_zero_entity_support_runs, &zero_entity_records);
        let zero_entity_vertex_incidences =
            zero_entity_vertex_incidences(bytes, zero_entity_range, &zero_entity_records);
        let consolidated_edge_nodes =
            consolidated_edge_nodes(bytes, consolidated_records, &consolidated_circles)?;
        let consolidated_edge_runs = consolidated_edge_runs(
            ctx,
            bytes,
            consolidated_records,
            &consolidated_pcurves,
            &consolidated_edge_nodes,
            refusal,
        )?;
        let consolidated_vertex_identities =
            consolidated_vertex_identities(&consolidated_edge_nodes);
        let e5_curve_supports = e5_curve_support::derive(ctx, bytes)?;
        let e5_edges = e5_edge::derive(ctx, bytes)?;
        let e5_nurbs_limit_programs = e5_nurbs_limits::derive(ctx, bytes)?;
        let consolidated_four_reference_edges =
            four_reference_edge::derive(ctx, bytes, consolidated_records)?;
        let consolidated_rolling_ball_continuations =
            rolling_ball_continuation::derive(ctx, bytes, consolidated_records)?;
        Ok(Self {
            sampled_parameter_maps: Vec::new(),
            alias_rows,
            inline_fields,
            storage_property_members,
            catalogs,
            consolidated_circles,
            consolidated_class61_records,
            consolidated_class5b5c_records,
            consolidated_chamfers,
            object_chamfers,
            consolidated_cones,
            consolidated_cylinders,
            consolidated_a5_charts,
            consolidated_domain_relations,
            consolidated_a_class25_maps,
            consolidated_four_reference_edges,
            consolidated_edge_nodes,
            consolidated_edge_runs,
            consolidated_class60_records,
            consolidated_line_profiles,
            consolidated_owner_packets,
            consolidated_parameter_points,
            consolidated_plane_carriers,
            consolidated_pcurves,
            consolidated_reference_lists,
            consolidated_revolutions,
            consolidated_rolling_ball_constructions,
            consolidated_rolling_ball_continuations,
            consolidated_spheres,
            consolidated_tori,
            consolidated_vertex_identities,
            design_objects,
            e5_curve_supports,
            e5_edges,
            e5_nurbs_limit_programs,
            entity_records,
            external_references,
            finjpl_segments,
            legacy_entity_runs,
            object_graphs,
            preview_images,
            reference_signature_cohorts,
            schema_configuration_row_chains,
            value_blocks,
            zero_entity_allocation_edges,
            zero_entity_edge_strides,
            zero_entity_oriented_use_pairs,
            zero_entity_ownership_roots,
            zero_entity_records,
            zero_entity_support_runs,
            zero_entity_vertex_incidences,
        })
    }

    /// Store this namespace while moving child arenas out of their typed owners.
    pub(crate) fn store_owned(
        self,
        ctx: &cadmpeg_core::decode::DecodeContext<'_>,
        namespace: &mut cadmpeg_ir::NativeNamespace,
    ) -> Result<(), cadmpeg_ir::NativeConvertError> {
        let projection = CatiaArenaProjection::from_owned(self);
        store_projection(ctx, &projection, namespace)
    }
}

#[cfg(test)]
mod test_only;
/// Remove inventories nested inside another frame.
fn filter_nested_inventory(
    graphs: &mut Vec<object_graph::ObjectGraph>,
    blocks: &mut Vec<value_block::ValueBlock>,
    catalogs: &mut Vec<catalog::Catalog>,
) {
    let graph_owners = ExtentOwners::new(graphs.iter().map(|graph| (graph.pos, graph.total_len)));
    blocks.retain(|block| !graph_owners.contains(block.pos, block.total_len()));
    let block_owners = ExtentOwners::new(blocks.iter().map(|block| (block.pos, block.total_len())));
    graphs.retain(|graph| !block_owners.contains(graph.pos, graph.total_len));
    let graph_owners = ExtentOwners::new(graphs.iter().map(|graph| (graph.pos, graph.total_len)));
    catalogs.retain(|catalog| {
        !graph_owners.contains(catalog.pos, catalog.total_len)
            && !block_owners.contains(catalog.pos, catalog.total_len)
    });
}

/// Owner extents sorted by start, answering whether any owner contains a
/// candidate extent as [`crate::object_graph::extent_contains`] defines it.
struct ExtentOwners {
    /// Owner start and end, ascending by start; an owner whose end overflows
    /// contains nothing and is left out.
    owners: Vec<(usize, usize)>,
    /// The largest owner end among `owners[..=index]`.
    max_end: Vec<usize>,
}

impl ExtentOwners {
    fn new(extents: impl IntoIterator<Item = (usize, usize)>) -> Self {
        let mut owners = extents
            .into_iter()
            .filter_map(|(start, len)| Some((start, start.checked_add(len)?)))
            .collect::<Vec<_>>();
        owners.sort_unstable();
        let mut max_end = Vec::new();
        for &(_, end) in &owners {
            max_end.push(
                max_end
                    .last()
                    .map_or(end, |&previous: &usize| previous.max(end)),
            );
        }
        Self { owners, max_end }
    }

    fn contains(&self, start: usize, len: usize) -> bool {
        let Some(end) = start.checked_add(len) else {
            return false;
        };
        let before = self.owners.partition_point(|&(owner, _)| owner < start);
        before
            .checked_sub(1)
            .is_some_and(|last| self.max_end[last] >= end)
    }
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod consolidated_cylinder_tests {
    use super::consolidated_cylinders;

    #[test]
    fn cylinder_stream_yields_one_standalone_cylinder() {
        let bytes = crate::test_support::test_b2::b2_cylinder_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let cylinders = consolidated_cylinders(&bytes, &records);
        assert_eq!(cylinders.len(), 1);
    }
}

#[cfg(test)]
mod consolidated_pcurve_tests {

    #[test]
    fn a5_pcurve_stream_yields_one_two_point_pcurve() {
        let bytes = crate::test_support::test_a5a8::a5_pcurve_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let pcurves = super::consolidated_pcurves(&bytes, &records);
        assert_eq!(pcurves.len(), 1);
        assert_eq!(pcurves[0].points.len(), 2);
    }
}
