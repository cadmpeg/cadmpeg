// SPDX-License-Identifier: Apache-2.0
//! Container parser tests over synthetic CATPart streams.

#![allow(clippy::doc_markdown, clippy::unwrap_used)]

use cadmpeg_core::container::ContainerRole;

use super::{
    identify_variant, outer_container_declarations, parse_directory_region,
    reconstruct_logical_stream, scan_bytes, summarize, Census, ContainerScan, Descriptor, Extent,
    InnerDir, EDGE_DELIMITER, OUTER_MAGIC,
};
use std::io::Cursor;

use cadmpeg_ir::codec::{Codec, Confidence};

use crate::test_support::test_container::{
    external_reference_segment, finjpl_stream, outer_body_catpart, outer_directory_catpart,
    standard_catpart, summary_preview_segment,
};
use crate::test_support::test_e5::append_e5_record;
use crate::variant::Variant;
use crate::CatiaCodec;

fn summarize_service(scan: &ContainerScan<'_>) -> cadmpeg_ir::ContainerSummary {
    summarize(scan).expect("summarize the inspection")
}

fn brep_service(data: &[u8], dir: &InnerDir) -> Option<Vec<u8>> {
    crate::test_support::with_service_context(|ctx| {
        super::brep_stream(ctx, data, dir).map(|streams| streams.0)
    })
    .expect("parse the B-rep stream")
}

fn main_data_stream_service(data: &[u8], dir: &InnerDir) -> Option<Vec<u8>> {
    crate::test_support::with_service_context(|ctx| super::main_data_stream(ctx, data, dir))
        .expect("parse the main data stream")
}

#[test]
fn logical_stream_bytes_refuse_retained_limit() {
    let descriptor = test_descriptor("MainDataStream", 1, 3);
    let directory = InnerDir {
        inner: 0,
        descriptors: vec![test_descriptor("MainDataStream", 1, 3)],
    };
    let limited = crate::test_support::with_retained_limit(2, |ctx| {
        super::main_data_stream(ctx, b"01234", &directory)
    });
    assert!(
        matches!(limited, Err(cadmpeg_core::CodecError::ResourceLimit(limit))
        if limit.operation == "catia_logical_stream_bytes")
    );
    assert_eq!(reconstruct_logical_stream(b"01234", &descriptor, 0), b"123");
}

fn append_e5_test_record(bytes: &mut Vec<u8>, id: u32) {
    append_e5_test_record_with_payload(bytes, id, &[]);
}

fn append_e5_test_record_with_payload(bytes: &mut Vec<u8>, id: u32, payload: &[u8]) {
    bytes.extend_from_slice(super::E5_MARKER);
    bytes.extend_from_slice(&[0xfe, 0x00]);
    bytes.extend_from_slice(
        &(u16::try_from(payload.len()).expect("fixture value fits u16")).to_le_bytes(),
    );
    bytes.extend_from_slice(&[0x00, 0x00]);
    bytes.extend_from_slice(&id.to_le_bytes());
    bytes.extend_from_slice(payload);
}

fn outer_with_preamble(body: &[u8]) -> Vec<u8> {
    let directory_length = 32usize;
    let directory_offset = 512usize;
    let mut bytes = vec![0u8; directory_length];
    bytes[..super::OUTER_MAGIC.len()].copy_from_slice(super::OUTER_MAGIC);
    bytes[8..12].copy_from_slice(
        &(u32::try_from(directory_offset).expect("fixture value fits u32")).to_be_bytes(),
    );
    bytes[12..16].copy_from_slice(
        &(u32::try_from(directory_length).expect("fixture value fits u32")).to_be_bytes(),
    );
    bytes.extend_from_slice(body);
    bytes.resize(directory_offset + directory_length, 0);
    bytes
}

fn test_descriptor(name: &str, physical_offset: u32, length: u32) -> Descriptor {
    Descriptor {
        name: name.to_string(),
        desc_offset: 0,
        extents: vec![Extent {
            phys_off: physical_offset,
            phys_len: length,
            trailing_word: 0,
        }],
    }
}

fn fbb_only_tables_with_shared_delimiter() -> Vec<u8> {
    let mut bytes = vec![0x30, 0x04, 0x04, 0xff, 0xd2, 0xd2, 0xd2, 0xd2];
    for (kind, handles) in [(1u8, [1u8, 2]), (2, [2, 3])] {
        bytes.extend_from_slice(&[0x01, kind, 0x01, 0x02, 0x02]);
        bytes.extend_from_slice(&handles);
        bytes.extend_from_slice(super::EDGE_DELIMITER.as_slice());
    }
    bytes.extend_from_slice(&[0x01, 0x06, 0x00]);
    bytes
}

#[test]
fn nested_fbb_spine_precedes_a_coherent_e5_stream() {
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, standard_catpart()))
        .expect("scan the container");
    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx,
            scan.inner.as_ref(),
            scan.brep.as_deref(),
            scan.main_data_stream(),
            &scan.census,
            true,
        ))
        .expect("identify the container variant"),
        Variant::StandardNested
    );
}

#[test]
fn coherent_e5_stream_overrides_zero_entity_markers() {
    let census = Census {
        a9_records: 1,
        ..Census::default()
    };
    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx, None, None, None, &census, true
        ))
        .expect("identify the container variant"),
        Variant::E5Stream
    );
}

#[test]
fn scan_selects_a_coherent_e5_walk_over_a_zero_entity_record() {
    let mut body = vec![0xa9, 0x03, 0x10, 0x00, 0, 0, 0, 0, 0, 0, 0, 0];
    for id in 0..10 {
        append_e5_test_record(&mut body, id);
    }
    let scan = crate::test_support::with_service_context(|ctx| {
        scan_bytes(ctx, outer_with_preamble(&body))
    })
    .expect("scan the container");
    assert_eq!(scan.census.a9_records, 1);
    assert_eq!(scan.variant, Variant::E5Stream);
}

#[test]
fn coherent_e5_stream_overrides_an_inner_body_without_brep_streams() {
    let inner = InnerDir {
        inner: 0,
        descriptors: Vec::new(),
    };
    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx,
            Some(&inner),
            None,
            None,
            &Census::default(),
            true
        ))
        .expect("identify the container variant"),
        Variant::E5Stream
    );
}

#[test]
fn fbb_only_grammar_wins_when_its_delimiter_is_shared_with_standard() {
    let inner = InnerDir {
        inner: 0,
        descriptors: Vec::new(),
    };
    let brep = fbb_only_tables_with_shared_delimiter();
    let census = Census {
        fbb_runs: 1,
        edge_delimiters: 2,
        ..Census::default()
    };

    assert_eq!(
        crate::test_support::with_service_context(|ctx| {
            crate::families::standard::fbb::standard_edge_count(ctx, &brep)
        })
        .expect("compute the standard edge count"),
        None
    );
    assert_eq!(
        crate::families::standard::fbb::fbb_only_edge_count(&brep),
        Some(2)
    );
    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx,
            Some(&inner),
            Some(&brep),
            Some(&brep),
            &census,
            false
        ))
        .expect("identify the container variant"),
        Variant::FbbOnly
    );
}

#[test]
fn unadmitted_fbb_region_is_unknown_even_with_delimiter_markers() {
    let inner = InnerDir {
        inner: 0,
        descriptors: Vec::new(),
    };
    let mut brep = vec![0x30, 0x04, 0x04, 0xff, 0, 0, 0, 0];
    brep.extend_from_slice(EDGE_DELIMITER.as_slice());
    let census = Census {
        fbb_runs: 1,
        edge_delimiters: 1,
        ..Census::default()
    };

    assert_eq!(
        crate::test_support::with_service_context(|ctx| {
            crate::families::standard::fbb::standard_edge_count(ctx, &brep)
        })
        .expect("compute the standard edge count"),
        None
    );
    assert_eq!(
        crate::families::standard::fbb::fbb_only_edge_count(&brep),
        None
    );
    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx,
            Some(&inner),
            Some(&brep),
            Some(&brep),
            &census,
            false
        ))
        .expect("identify the container variant"),
        Variant::Unknown
    );

    let no_vertex_brep = vec![0x30, 0x04, 0x04, 0xff, 0, 0, 0, 0];
    let no_vertex_census = Census {
        fbb_runs: 1,
        ..Census::default()
    };
    for coherent_e5 in [false, true] {
        assert_eq!(
            crate::test_support::with_service_context(|ctx| identify_variant(
                ctx,
                Some(&inner),
                Some(&no_vertex_brep),
                Some(&no_vertex_brep),
                &no_vertex_census,
                coherent_e5,
            ))
            .expect("service resource budget"),
            Variant::Unknown
        );
    }
}

#[test]
fn coherent_e5_stream_precedes_a_partial_fbb_spine() {
    let inner = InnerDir {
        inner: 0,
        descriptors: Vec::new(),
    };
    let brep = fbb_only_tables_with_shared_delimiter();
    let census = Census {
        fbb_runs: 1,
        edge_delimiters: 2,
        ..Census::default()
    };

    assert_eq!(
        crate::test_support::with_service_context(|ctx| identify_variant(
            ctx,
            Some(&inner),
            Some(&brep),
            Some(&brep),
            &census,
            true
        ))
        .expect("identify the container variant"),
        Variant::E5Stream
    );
}

#[test]
fn e5_stream_requires_declared_stride_or_coordinate_rows_between_records() {
    let mut body = Vec::new();
    for id in 0..10 {
        append_e5_test_record(&mut body, id);
        body.push(0x7f);
    }
    assert!(super::e5_record_stream(&outer_with_preamble(&body)).is_none());

    let mut body = Vec::new();
    for id in 0..10 {
        append_e5_test_record(&mut body, id);
        if id != 9 {
            body.extend_from_slice(&[0x05, 0x08, 0x01]);
            body.extend_from_slice(&[0; 12]);
        }
    }
    assert!(super::e5_record_stream(&outer_with_preamble(&body)).is_some());
}

#[test]
fn e5_stream_ignores_markers_inside_framed_payloads() {
    let mut false_record = Vec::new();
    append_e5_test_record(&mut false_record, 100);
    let mut body = Vec::new();
    append_e5_test_record_with_payload(&mut body, 0, &false_record);
    for id in 1..9 {
        append_e5_test_record(&mut body, id);
    }
    assert!(super::e5_record_stream(&outer_with_preamble(&body)).is_none());
}

#[test]
fn e5_stream_and_finjpl_inventory_exclude_the_trailing_directory() {
    let directory_length = 192usize;
    let directory_offset = 512usize;
    let mut bytes = vec![0u8; directory_length];
    bytes[..super::OUTER_MAGIC.len()].copy_from_slice(super::OUTER_MAGIC);
    bytes[8..12].copy_from_slice(
        &(u32::try_from(directory_offset).expect("fixture value fits u32")).to_be_bytes(),
    );
    bytes[12..16].copy_from_slice(
        &(u32::try_from(directory_length).expect("fixture value fits u32")).to_be_bytes(),
    );
    bytes.resize(directory_offset, 0);

    let mut directory = vec![0u8; super::DIR_MAGIC.len()];
    directory[..super::DIR_MAGIC.len()].copy_from_slice(super::DIR_MAGIC);
    directory.extend_from_slice(super::FINJPL_MARKER);
    directory.extend_from_slice(&0x0000_008eu32.to_be_bytes());
    for id in 0..10 {
        append_e5_test_record(&mut directory, id);
    }
    directory.resize(directory_length, 0);
    bytes.extend_from_slice(&directory);

    assert!(super::e5_record_stream(&bytes).is_none());
    let scan = crate::test_support::with_service_context(|ctx| super::scan_bytes(ctx, bytes))
        .expect("scan the container");
    assert!(scan.finjpl_segments.is_empty());
    assert_eq!(scan.census.e5_markers, 0);
}

#[test]
fn all_e5_record_spans_cross_other_framed_records() {
    let mut body = Vec::new();
    append_e5_test_record(&mut body, 1);
    let interstitial = body.len();
    append_e5_record(&mut body, 0xf4, 44, &[0; 9]);
    body[interstitial + 2] = 0x13;
    append_e5_test_record(&mut body, 2);
    assert_eq!(super::all_e5_record_spans(&body).count(), 2);
}

#[test]
fn interstitial_e5_payload_markers_do_not_enter_geometry_inventory() {
    let mut body = Vec::new();
    append_e5_test_record(&mut body, 1);
    let mut nested = Vec::new();
    for id in 999..1009 {
        append_e5_test_record(&mut nested, id);
    }
    for flag in [0x13, 0x83] {
        let mut interstitial = Vec::new();
        append_e5_record(&mut interstitial, 0xf4, 100, &nested);
        interstitial[2] = flag;
        body.extend_from_slice(&interstitial);
    }
    append_e5_test_record(&mut body, 2);
    let ids: Vec<_> = super::all_e5_record_spans(&body)
        .map(|span| cadmpeg_core::decode::View::u32_le_at(&body, span.start + 9))
        .collect();
    assert_eq!(ids, [Some(1), Some(2)]);
    assert_eq!(
        crate::test_support::with_service_context(|_ctx| {
            super::coherent_e5_record_count(&body)
        }),
        1
    );
}

#[test]
fn equal_unpreferred_e5_segment_walks_are_ambiguous() {
    let mut body = Vec::new();
    for segment in 0..2 {
        body.extend_from_slice(super::FINJPL_MARKER);
        body.extend_from_slice(&0x0000_0080u32.to_be_bytes());
        for id in 0..10 {
            append_e5_test_record(&mut body, segment * 10 + id);
        }
    }
    assert!(super::e5_record_stream(&outer_with_preamble(&body)).is_none());
}

#[test]
fn brep_stream_requires_unique_canonical_descriptors() {
    let data = (0..32u8).collect::<Vec<_>>();
    let tied = InnerDir {
        inner: 0,
        descriptors: vec![
            test_descriptor("MainDataStream", 0, 4),
            test_descriptor("MainDataStream", 4, 4),
            test_descriptor("SurfacicReps", 8, 2),
        ],
    };
    assert!(brep_service(&data, &tied).is_none());

    let noncanonical = InnerDir {
        inner: 0,
        descriptors: vec![
            test_descriptor("MainDataStream", 0, 4),
            test_descriptor("SurfacicRepsAlias", 4, 4),
        ],
    };
    assert!(brep_service(&data, &noncanonical).is_none());

    let unique = InnerDir {
        inner: 0,
        descriptors: vec![
            test_descriptor("MainDataStream", 0, 4),
            test_descriptor("MainDataStream", 4, 5),
            test_descriptor("SurfacicReps", 9, 2),
        ],
    };
    assert_eq!(
        brep_service(&data, &unique),
        Some(data[4..9].iter().chain(&data[9..11]).copied().collect())
    );
    assert_eq!(
        main_data_stream_service(&data, &unique),
        Some(data[4..9].to_vec())
    );
}

#[test]
fn extent_parser_retains_the_raw_trailing_word() {
    let mut directory = vec![0; 24];
    for (offset, value) in [(4, 40u32), (8, 8), (12, 8), (16, 0), (20, 0xa501_0080)] {
        directory[offset..offset + 4].copy_from_slice(&value.to_be_bytes());
    }
    let (extents, logical_length) =
        super::parse_extents(&directory, 0, 1, 0, 64).expect("complete extent");
    assert_eq!(logical_length, 8);
    assert_eq!(extents[0].trailing_word, 0xa501_0080);
    assert!(super::parse_extents(&directory, 0, 1, usize::MAX, usize::MAX).is_none());
}

#[test]
fn descriptor_name_is_anchored_to_the_descriptor_tail() {
    let mut directory = vec![0u8; 0x80];
    let ds = 0x40;
    let name = b"MainDataStream";
    let name_start = ds - 3 - name.len() * 2;
    for (index, byte) in name.iter().enumerate() {
        directory[name_start + index * 2] = *byte;
    }
    directory[ds - 3..ds].copy_from_slice(&[0, 0, 0]);

    assert_eq!(super::descriptor_name(&directory, ds), "MainDataStream");
}

#[test]
fn descriptor_name_excludes_a_printable_length_cell() {
    for name in ["4bbc295c_1048_62eb7b6f_1825", "MainDataStream"] {
        let mut directory = vec![0u8; 0x80];
        let ds = 0x60;
        let name_start = ds - 3 - name.len() * 2;
        let cell = u16::try_from(name.len() * 2 + 2).unwrap();
        directory[name_start - 2..name_start].copy_from_slice(&cell.to_le_bytes());
        for (index, byte) in name.bytes().enumerate() {
            directory[name_start + index * 2] = byte;
        }
        assert_eq!(super::descriptor_name(&directory, ds), name);
    }
}

#[test]
fn descriptor_name_ignores_unrelated_utf16_runs_and_requires_the_tail() {
    let mut directory = vec![0u8; 0x80];
    for (index, byte) in b"UNRELATED_LONGER_RUN".iter().enumerate() {
        directory[8 + index * 2] = *byte;
    }
    let ds = 0x40;
    let name = b"Data";
    let name_start = ds - 3 - name.len() * 2;
    for (index, byte) in name.iter().enumerate() {
        directory[name_start + index * 2] = *byte;
    }
    directory[ds - 3..ds].copy_from_slice(&[0, 0, 1]);
    assert!(super::descriptor_name(&directory, ds).is_empty());

    directory[ds - 3..ds].copy_from_slice(&[0, 0, 0]);
    assert_eq!(super::descriptor_name(&directory, ds), "Data");
}

#[test]
fn descriptor_name_accepts_the_legacy_fixed_header_form() {
    let mut directory = vec![0u8; 0x80];
    let ds = 0x10;
    let name = b"RootStorage";
    let name_start = ds + 0x10;
    for (index, byte) in name.iter().enumerate() {
        directory[name_start + index * 2] = *byte;
    }
    directory[name_start + name.len() * 2..name_start + name.len() * 2 + 2]
        .copy_from_slice(&[0, 0]);

    assert_eq!(super::descriptor_name(&directory, ds), "RootStorage");
}

#[test]
fn directory_parser_accepts_a_structurally_bounded_extent_roster_above_64() {
    let descriptor_start = 16;
    let extent_count_offset = descriptor_start + 0x50;
    let extent_count = 65usize;
    let directory_end = extent_count_offset + 4 + extent_count * 20;
    let mut directory = vec![0u8; directory_end];
    directory[..super::DIR_MAGIC.len()].copy_from_slice(super::DIR_MAGIC);
    directory[descriptor_start + 0x0c..descriptor_start + 0x10].copy_from_slice(
        &(u32::try_from(extent_count).expect("fixture value fits u32")).to_be_bytes(),
    );
    directory[extent_count_offset..extent_count_offset + 4].copy_from_slice(
        &(u32::try_from(extent_count).expect("fixture value fits u32")).to_be_bytes(),
    );
    for index in 0..extent_count {
        let extent = extent_count_offset + 4 + index * 20;
        directory[extent..extent + 4].copy_from_slice(
            &(u32::try_from(index).expect("fixture value fits u32")).to_be_bytes(),
        );
        directory[extent + 4..extent + 8].copy_from_slice(&1u32.to_be_bytes());
        directory[extent + 8..extent + 12].copy_from_slice(&1u32.to_be_bytes());
        directory[extent + 12..extent + 16].copy_from_slice(
            &(u32::try_from(index).expect("fixture value fits u32")).to_be_bytes(),
        );
    }

    let parsed =
        parse_directory_region(&directory, 0, 0, directory.len()).expect("bounded extent roster");
    let descriptor = parsed
        .descriptors
        .iter()
        .find(|descriptor| descriptor.desc_offset == descriptor_start)
        .expect("descriptor at synthesized header");
    assert_eq!(
        descriptor.logical_length(),
        cadmpeg_core::decode::u64_from_index(extent_count)
    );
    assert_eq!(descriptor.extents.len(), extent_count);
}

#[test]
fn logical_stream_reconstruction_is_atomic_over_its_extent_roster() {
    let descriptor = Descriptor {
        name: "MAIN".to_string(),
        desc_offset: 0,
        extents: vec![
            Extent {
                phys_off: 1,
                phys_len: 2,
                trailing_word: 0,
            },
            Extent {
                phys_off: 7,
                phys_len: 2,
                trailing_word: 0,
            },
        ],
    };
    assert_eq!(
        reconstruct_logical_stream(b"0123456789", &descriptor, 0),
        b"1278"
    );

    let mut outside = descriptor.clone();
    outside.extents[1].phys_off = 9;
    assert!(reconstruct_logical_stream(b"0123456789", &outside, 0).is_empty());
}

#[test]
fn extent_trailing_words_do_not_change_logical_reconstruction() {
    for words in [[0, 0], [1, 2], [0xa501_0080, 7]] {
        let mut directory = vec![0; 44];
        for (index, (physical, length, logical, word)) in
            [(7u32, 2u32, 0u32, words[0]), (1, 1, 2, words[1])]
                .into_iter()
                .enumerate()
        {
            let start = 4 + index * 20;
            for (field, value) in [physical, length, length, logical, word]
                .into_iter()
                .enumerate()
            {
                let offset = start + field * 4;
                directory[offset..offset + 4].copy_from_slice(&value.to_be_bytes());
            }
        }
        let (extents, length) =
            super::parse_extents(&directory, 0, 2, 0, 10).expect("complete extent roster");
        assert_eq!(length, 3);
        assert_eq!(extents[0].trailing_word, words[0]);
        assert_eq!(extents[1].trailing_word, words[1]);
        let descriptor = Descriptor {
            name: "MainDataStream".to_string(),
            desc_offset: 0,
            extents,
        };
        assert_eq!(
            reconstruct_logical_stream(b"0123456789", &descriptor, 0),
            b"781"
        );
    }
}

#[test]
fn logical_stream_reconstruction_rejects_overflowing_physical_offsets() {
    let descriptor = Descriptor {
        name: "MAIN".to_string(),
        desc_offset: 0,
        extents: vec![Extent {
            phys_off: 1,
            phys_len: 1,
            trailing_word: 0,
        }],
    };
    assert!(reconstruct_logical_stream(&[0], &descriptor, usize::MAX).is_empty());
}

#[test]
fn container_summary_exposes_extent_words_in_logical_order() {
    let scan = ContainerScan {
        data: Vec::new().into(),
        outer_dir_offset: 0,
        outer_dir_length: 0,
        outer: Some(InnerDir {
            inner: 0,
            descriptors: vec![Descriptor {
                name: "MAIN".to_string(),
                desc_offset: 16,
                extents: vec![
                    Extent {
                        phys_off: 40,
                        phys_len: 4,
                        trailing_word: 0xa501_0080,
                    },
                    Extent {
                        phys_off: 80,
                        phys_len: 8,
                        trailing_word: 0,
                    },
                ],
            }],
        }),
        inner: None,
        brep: None,
        main_data_stream: None,
        e5_record_range: None,
        previews: Vec::new(),
        last_save_version: None,
        external_references: Vec::new(),
        finjpl_segments: Vec::new(),
        outer_container_declarations: Vec::new(),
        has_outer_container_declarations: false,
        census: Census::default(),
        variant: Variant::Unknown,
    };
    let summary = summarize_service(&scan);
    assert_eq!(
        summary.entries[0].attributes["extent_words"],
        "0xa5010080,0x00000000"
    );
}

#[test]
fn truncated_uuid_without_metadata_does_not_assign_graph_ownership() {
    let mut data = vec![0; 40];
    data[8..12].copy_from_slice(b"\x01\x00\x03\x00");
    data[12..16].copy_from_slice(&2u32.to_le_bytes());
    data[16..24].copy_from_slice(b"\x01\x00\x6c\x00\x02\x00\x00\x00");
    data[32..36].copy_from_slice(b"\x02\x00\x81\x20");
    data.extend_from_slice(b"CATPrtCont\0CATProdCont\0\0");
    data.extend_from_slice(b"\x03\x00\xf7\x00\x03\x00\x00\x00");
    data.extend_from_slice(&0x4bbc_295cu32.to_be_bytes());
    data.extend_from_slice(&0x0000_1048u32.to_be_bytes());
    data.extend_from_slice(&0x62eb_7b6fu32.to_be_bytes());
    data.extend_from_slice(&0x0000_1825u32.to_be_bytes());
    let data_len = u32::try_from(data.len()).expect("bounded declaration");
    let outer = InnerDir {
        inner: 0,
        descriptors: vec![
            Descriptor {
                name: "Data".to_string(),
                desc_offset: 10,
                extents: vec![Extent {
                    phys_off: 0,
                    phys_len: data_len,
                    trailing_word: 0,
                }],
            },
            Descriptor {
                name: "1048_62eb7b6f_1825".to_string(),
                desc_offset: 20,
                extents: vec![Extent {
                    phys_off: data_len,
                    phys_len: 1,
                    trailing_word: 0,
                }],
            },
        ],
    };
    data.push(0);

    // Preserve the original truncated UUID and absent metadata table as a negative.
    let inventory = super::outer_container_inventory(&data, &outer);
    assert!(inventory.has_declarations);
    assert!(inventory.resolved.is_empty());
    let mut prefixed_outer = outer.clone();
    prefixed_outer.descriptors[1].name = "_1048_62eb7b6f_1825".to_owned();
    assert!(outer_container_declarations(&data, &prefixed_outer).is_empty());

    let incomplete = super::parse_outer_container_declarations(
        &data[..usize::try_from(data_len).expect("bounded declaration") - 1],
        |_| Some("content".to_owned()),
    );
    assert!(!incomplete.has_declarations);
    let duplicated = data[..usize::try_from(data_len).expect("bounded declaration")].repeat(2);
    let duplicated =
        super::parse_outer_container_declarations(&duplicated, |_| Some("content".to_owned()));
    assert!(duplicated.has_declarations);
    assert!(duplicated.resolved.is_empty());
}

#[test]
fn outer_data_declaration_uses_the_terminal_marker_after_long_class_names() {
    let long_class = "C".repeat(193);
    let mut data = vec![0; 40];
    data[8..12].copy_from_slice(b"\x01\x00\x03\x00");
    data[12..16].copy_from_slice(&2u32.to_le_bytes());
    data[16..24].copy_from_slice(b"\x01\x00\x6c\x00\x02\x00\x00\x00");
    data[32..36].copy_from_slice(b"\x02\x00\x81\x20");
    data.extend_from_slice(long_class.as_bytes());
    data.extend_from_slice(b"\0CATProdCont\0\0");
    data.extend_from_slice(b"\x03\x00\xf7\x00\x03\x00\x00\x00");
    data.extend_from_slice(&0x4bbc_295cu32.to_be_bytes());
    data.extend_from_slice(&0x0000_1048u32.to_be_bytes());
    data.extend_from_slice(&0x62eb_7b6fu32.to_be_bytes());
    data.extend_from_slice(&0x0000_1825u32.to_be_bytes());
    let data_len = u32::try_from(data.len()).expect("bounded declaration");
    let outer = InnerDir {
        inner: 0,
        descriptors: vec![
            Descriptor {
                name: "Data".to_string(),
                desc_offset: 10,
                extents: vec![Extent {
                    phys_off: 0,
                    phys_len: data_len,
                    trailing_word: 0,
                }],
            },
            Descriptor {
                name: "1048_62eb7b6f_1825".to_string(),
                desc_offset: 20,
                extents: vec![Extent {
                    phys_off: data_len,
                    phys_len: 1,
                    trailing_word: 0,
                }],
            },
        ],
    };
    data.push(0);

    assert!(outer_container_declarations(&data, &outer).is_empty());
    let declarations = super::parse_outer_container_declarations(&data, |name| {
        assert_eq!(name, "4bbc295c_1048_62eb7b6f_1825");
        Some("resolved-content".to_owned())
    })
    .resolved;

    assert_eq!(declarations.len(), 1);
    assert_eq!(declarations[0].class_name, long_class);
    assert_eq!(declarations[0].base_class, "CATProdCont");
}

#[test]
fn detect_high_on_outer_magic() {
    assert_eq!(
        cadmpeg_test_support::detection::confidence(&CatiaCodec, OUTER_MAGIC),
        Confidence::High
    );
    assert_eq!(
        cadmpeg_test_support::detection::confidence(&CatiaCodec, &standard_catpart()),
        Confidence::High
    );
    assert_eq!(
        cadmpeg_test_support::detection::confidence(&CatiaCodec, b"PK\x03\x04 not catia"),
        Confidence::No
    );
}

#[test]
fn summary_preview_parser_extracts_exact_jpeg_and_dimensions() {
    let bytes = summary_preview_segment();
    let segments = super::finjpl_segments(&crate::container::BodyExtent::whole(&bytes));
    assert_eq!(segments[0].name.as_deref(), Some("CATSummaryInformation"));
    let previews = super::preview_images(&bytes);
    assert_eq!(previews.len(), 1);
    assert_eq!(previews[0].width, 640);
    assert_eq!(previews[0].height, 288);
    assert_eq!(previews[0].components, 1);
    assert_eq!(&bytes[previews[0].range.clone()][..2], [0xff, 0xd8]);
    assert_eq!(
        &bytes[previews[0].range.clone()][previews[0].range.len() - 2..],
        [0xff, 0xd9]
    );
    let summary = summarize_service(
        &crate::test_support::with_service_context(|ctx| {
            crate::container::scan_bytes(ctx, outer_body_catpart(&bytes))
        })
        .expect("scan the container"),
    );
    assert!(summary.entries.iter().any(|entry| {
        entry.role == ContainerRole::FinjplSegment && entry.name == "CATSummaryInformation"
    }));

    let mut truncated = bytes;
    let eoi = truncated
        .windows(2)
        .position(|value| value == [0xff, 0xd9])
        .unwrap();
    truncated.truncate(eoi + 1);
    assert!(super::preview_images(&truncated).is_empty());
}

#[test]
fn summary_version_parser_requires_one_consistent_tuple() {
    let bytes = summary_preview_segment();
    let version = super::last_save_version(&bytes).unwrap();
    assert_eq!(version.version, 5);
    assert_eq!(version.release, 27);
    assert_eq!(version.service_pack, 2);
    assert_eq!(version.hot_fix, 0);
    assert_eq!(version.build_date, "03-10-2017.22.00");

    let mut conflicting = bytes;
    let mut other = summary_preview_segment();
    let release = other
        .windows(11)
        .position(|value| value == b"<Release>27")
        .unwrap();
    other[release + 9] = b'2';
    other[release + 10] = b'8';
    conflicting.extend_from_slice(&other);
    assert!(super::last_save_version(&conflicting).is_none());

    let mut non_summary = summary_preview_segment();
    non_summary[8..12].copy_from_slice(&0x0101_0002u32.to_be_bytes());
    assert!(super::last_save_version(&non_summary).is_none());
    assert!(super::preview_images(&non_summary).is_empty());
    let native = crate::native::CatiaNative::decode(&non_summary);
    assert!(native.preview_images.is_empty());
}

#[test]
fn storage_property_parser_enumerates_external_catia_documents() {
    let mut bytes = external_reference_segment("Support.CATPart");
    bytes.extend_from_slice(&external_reference_segment("Assembly.CATProduct"));
    bytes.extend_from_slice(&external_reference_segment("notes.txt"));
    let references = super::external_references(&bytes);
    assert_eq!(references.len(), 2);
    assert_eq!(references[0].target, "Support.CATPart");
    assert_eq!(references[1].target, "Assembly.CATProduct");

    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, outer_body_catpart(&bytes))
    })
    .expect("scan the container");
    let summary = summarize_service(&scan);
    assert_eq!(
        summary
            .entries
            .iter()
            .filter(|entry| entry.role == ContainerRole::ExternalReference)
            .map(|entry| entry.name.as_str())
            .collect::<Vec<_>>(),
        ["Support.CATPart", "Assembly.CATProduct"]
    );

    let native = crate::native::CatiaNative::decode(&bytes);
    assert_eq!(native.external_references.len(), 2);
    assert_eq!(native.external_references[0].target, "Support.CATPart");
    assert_eq!(
        native.external_references[0].segment,
        native.finjpl_segments[0].id
    );
    assert_eq!(
        native.external_references[1].segment,
        native.finjpl_segments[1].id
    );
    for reference in &native.external_references {
        let segment = native
            .finjpl_segments
            .iter()
            .find(|segment| segment.id == reference.segment)
            .expect("external-reference segment");
        assert!(reference.byte_offset >= segment.byte_offset);
        assert!(reference.byte_offset < segment.byte_offset + segment.byte_len);
    }
}

#[test]
fn summary_preview_requires_a_coherent_frame_header() {
    let valid = summary_preview_segment();
    let frame = valid
        .windows(2)
        .position(|bytes| bytes == [0xff, 0xc0])
        .expect("fixture SOF marker");

    let mut zero_height = valid.clone();
    zero_height[frame + 5..frame + 7].copy_from_slice(&0u16.to_be_bytes());
    assert!(super::preview_images(&zero_height).is_empty());

    let mut inconsistent_components = valid;
    inconsistent_components[frame + 9] = 2;
    assert!(super::preview_images(&inconsistent_components).is_empty());
    assert!(crate::native::CatiaNative::decode(&inconsistent_components)
        .preview_images
        .is_empty());
}

#[test]
fn summary_preview_requires_one_complete_jpeg_candidate() {
    let valid = summary_preview_segment();
    let image_start = valid
        .windows(3)
        .position(|bytes| bytes == [0xff, 0xd8, 0xff])
        .expect("fixture JPEG SOI");

    let mut malformed_prefix = valid.clone();
    malformed_prefix.splice(image_start..image_start, [0xff, 0xd8, 0xff, 0xd9]);
    let previews = super::preview_images(&malformed_prefix);
    let [preview] = previews.as_slice() else {
        panic!("one complete preview after malformed SOI")
    };
    assert_eq!(&malformed_prefix[preview.range.clone()][..2], [0xff, 0xd8]);

    let image_end = valid
        .windows(2)
        .enumerate()
        .skip(image_start)
        .find_map(|(at, bytes)| (bytes == [0xff, 0xd9]).then_some(at + 2))
        .expect("fixture JPEG EOI");
    let image = valid[image_start..image_end].to_vec();
    let mut duplicate = valid;
    duplicate.extend(image);
    assert!(super::preview_images(&duplicate).is_empty());
}

fn reference_jpeg_extent(data: &[u8], start: usize) -> Option<(usize, u16, u16, u8)> {
    if data.get(start..start + 2) != Some(&[0xff, 0xd8]) {
        return None;
    }
    let mut at = start + 2;
    let mut frame = None;
    let mut in_entropy = false;
    while at + 1 < data.len() {
        if data[at] != 0xff {
            if in_entropy {
                at += 1;
                continue;
            }
            return None;
        }
        while data.get(at) == Some(&0xff) {
            at += 1;
        }
        let marker = *data.get(at)?;
        at += 1;
        if in_entropy && marker == 0x00 {
            continue;
        }
        if marker == 0xd9 {
            let (width, height, components) = frame?;
            return Some((at, width, height, components));
        }
        if matches!(marker, 0x01 | 0xd0..=0xd8) {
            continue;
        }
        let length = usize::from(u16::from_be_bytes(data.get(at..at + 2)?.try_into().ok()?));
        if length < 2 {
            return None;
        }
        let payload = at + 2;
        let end = at.checked_add(length)?;
        if end > data.len() {
            return None;
        }
        if matches!(marker, 0xc0..=0xc3 | 0xc5..=0xc7 | 0xc9..=0xcb | 0xcd..=0xcf) {
            if length < 8 {
                return None;
            }
            let width = u16::from_be_bytes(data.get(payload + 3..payload + 5)?.try_into().ok()?);
            let height = u16::from_be_bytes(data.get(payload + 1..payload + 3)?.try_into().ok()?);
            let components = data[payload + 5];
            let expected_length = 8 + 3 * usize::from(components);
            if width == 0
                || height == 0
                || components == 0
                || length != expected_length
                || frame.is_some()
            {
                return None;
            }
            frame = Some((width, height, components));
        }
        in_entropy = marker == 0xda;
        at = end;
    }
    None
}

fn jpeg_candidate_walk_steps(bytes: &[u8]) -> usize {
    let mut walk = super::JpegCandidateWalk::new(bytes);
    for start in 0..bytes.len() {
        if bytes[start..].starts_with(&[0xff, 0xd8, 0xff]) {
            assert_eq!(walk.extent(start), None);
        }
    }
    walk.steps
}

#[test]
fn jpeg_candidate_walk_matches_independent_marker_walks() {
    let valid = summary_preview_segment();
    let image_start = valid
        .windows(3)
        .position(|bytes| bytes == [0xff, 0xd8, 0xff])
        .expect("fixture JPEG SOI");
    let alphabet = [
        0xff, 0xff, 0xff, 0xd8, 0xd9, 0xda, 0xc0, 0xe0, 0x00, 0x00, 0x01, 0x02, 0x08, 0x0b, 0xd0,
    ];
    let mut state = 0x2545_f491_u32;
    let mut next = || {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        usize::try_from(state).expect("a u32 fits usize")
    };
    for case in 0..400 {
        let mut bytes = if case % 4 == 0 {
            valid[image_start..].to_vec()
        } else {
            Vec::new()
        };
        let length = 16 + next() % 240;
        for _ in 0..length {
            let byte = alphabet[next() % alphabet.len()];
            let at = next() % (bytes.len() + 1);
            bytes.insert(at, byte);
        }
        let mut walk = super::JpegCandidateWalk::new(&bytes);
        for start in 0..bytes.len() {
            if bytes[start..].starts_with(&[0xff, 0xd8, 0xff]) {
                assert_eq!(
                    walk.extent(start),
                    reference_jpeg_extent(&bytes, start),
                    "case {case} start {start}"
                );
            }
        }
    }
}

#[test]
fn jpeg_candidate_walk_is_linear_on_repeated_start_markers() {
    let bytes = [0xff, 0xd8].repeat(1 << 15);
    assert!(jpeg_candidate_walk_steps(&bytes) <= 8 * bytes.len());
}

#[test]
fn jpeg_candidate_walk_is_linear_on_segments_ending_inside_one_fill_run() {
    let candidates = 4096usize;
    let run_start = 6 * candidates;
    let mut bytes = Vec::new();
    for index in 0..candidates {
        let length = u16::try_from(run_start + index - 6 * index - 4).expect("segment length");
        bytes.extend_from_slice(&[0xff, 0xd8, 0xff, 0xe0]);
        bytes.extend_from_slice(&length.to_be_bytes());
    }
    bytes.resize(run_start + 4 * candidates, 0xff);
    assert!(jpeg_candidate_walk_steps(&bytes) <= 8 * bytes.len());
}

#[test]
fn scan_parses_directory_and_identifies_standard() {
    let f = standard_catpart();
    let scan =
        crate::test_support::with_service_context(|ctx| crate::container::scan_bytes(ctx, f))
            .expect("scan the container");
    assert_eq!(scan.variant, Variant::StandardNested);
    let dir = scan.inner.expect("inner directory");
    assert!(dir.descriptors.iter().any(|d| d.name == "MainDataStream"));
    assert!(dir.descriptors.iter().any(|d| d.name == "SurfacicReps"));
    let brep = scan.brep.expect("reconstructed brep stream");
    // The BREP stream is MainDataStream followed by SurfacicReps.
    assert!(brep.windows(3).any(|w| w == [0x05, 0x08, 0x01]));
    assert!(brep.windows(3).any(|w| w == [0x00, 0x33, 0x33]));
    assert_eq!(scan.census.fbb_runs, 1);
    assert_eq!(scan.census.fbb_face_rows, 2);
    assert!(scan.census.edge_delimiters >= 1);
    assert_eq!(scan.census.vertex_markers, 3);
}

#[test]
fn scan_parses_outer_directory_with_absolute_extents() {
    let bytes = outer_directory_catpart();
    let directory_offset =
        usize::try_from(u32::from_be_bytes(bytes[8..12].try_into().unwrap())).unwrap();
    assert_eq!(
        crate::container::outer_stream_directory_range(&bytes),
        Some(directory_offset..bytes.len())
    );
    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, bytes.clone())
    })
    .expect("scan the container");
    let outer = scan.outer.as_ref().expect("outer directory");
    assert_eq!(outer.inner, 0);
    assert_eq!(outer.descriptors.len(), 1);
    let descriptor = &outer.descriptors[0];
    assert_eq!(descriptor.name, "RootStorage");
    assert_eq!(
        reconstruct_logical_stream(&bytes, descriptor, outer.inner),
        b"outer logical stream"
    );

    let summary = summarize_service(&scan);
    let entry = summary
        .entries
        .iter()
        .find(|entry| entry.name == "RootStorage")
        .expect("outer stream summary");
    assert_eq!(entry.attributes["directory"], "outer");
}

#[test]
fn inspect_enumerates_streams_and_names_variant() {
    let f = standard_catpart();
    let mut cur = Cursor::new(f);
    let summary = CatiaCodec
        .inspect(&mut cur, &cadmpeg_core::decode::InspectOptions::default())
        .unwrap();
    assert_eq!(summary.format(), "catia");
    assert_eq!(summary.container_kind, "v5-cfv2");
    assert!(summary.entries.iter().any(|e| e.name == "MainDataStream"));
    assert!(summary.entries.iter().any(|e| e.name == "SurfacicReps"));
    assert!(summary.notes.iter().any(|n| n.contains("standard nested")));
}

#[test]
fn finjpl_parser_splits_segments_and_classifies_type_words() {
    use crate::container::FinjplKind;

    let bytes = finjpl_stream();
    let segments = super::finjpl_segments(&crate::container::BodyExtent::whole(&bytes));
    assert_eq!(segments.len(), 2);
    assert_eq!(segments[0].kind(), FinjplKind::Storage);
    assert_eq!(segments[0].type_word, 0x0000_008e);
    assert_eq!(segments[0].range, 2..17);
    assert_eq!(segments[1].kind(), FinjplKind::ProjectFlags);
}

#[test]
fn e5_stream_selection_prefers_coherent_storage_segment_over_stray_preamble_marker() {
    let mut bytes = vec![0u8; 32];
    bytes[..8].copy_from_slice(OUTER_MAGIC);
    bytes[8..12].copy_from_slice(&512u32.to_be_bytes());
    bytes[12..16].copy_from_slice(&32u32.to_be_bytes());
    append_e5_record(&mut bytes, 0xfe, 1, &[]);
    bytes.extend_from_slice(b"FINJPL  ");
    bytes.extend_from_slice(&0x0000_0080u32.to_be_bytes());
    for id in 10..21 {
        append_e5_record(&mut bytes, 0xfe, id, &[]);
    }
    bytes.extend_from_slice(b"FINJPL  ");
    bytes.extend_from_slice(&0x0000_008eu32.to_be_bytes());
    let expected_start = bytes.len() - 12;
    for id in 30..41 {
        append_e5_record(&mut bytes, 0xfe, id, &[]);
    }
    bytes.resize(544, 0);

    let range = crate::container::e5_record_stream(&bytes).expect("coherent E5 stream");
    assert_eq!(range.start, expected_start);
    assert_eq!(&bytes[range.start..range.start + 8], b"FINJPL  ");
}

#[test]
fn consolidated_record_sources_follow_physical_stream_extents() {
    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, standard_catpart())
    })
    .expect("scan the container");
    let inner = scan.inner.as_ref().expect("inner stream directory");
    let expected = inner
        .descriptors
        .iter()
        .flat_map(|descriptor| {
            descriptor.extents.iter().map(|extent| {
                let start = inner.inner + cadmpeg_core::decode::index_from_u32(extent.phys_off);
                start..start + cadmpeg_core::decode::index_from_u32(extent.phys_len)
            })
        })
        .collect::<Vec<_>>();
    let expected_sources = inner
        .descriptors
        .iter()
        .map(|descriptor| {
            descriptor
                .extents
                .iter()
                .map(|extent| {
                    let start = inner.inner + cadmpeg_core::decode::index_from_u32(extent.phys_off);
                    start..start + cadmpeg_core::decode::index_from_u32(extent.phys_len)
                })
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    assert_eq!(super::consolidated_record_ranges(&scan), expected);
    assert_eq!(
        super::consolidated_record_sources(&scan)
            .into_iter()
            .map(|source| source
                .into_iter()
                .map(|extent| extent.range())
                .collect::<Vec<_>>())
            .collect::<Vec<_>>(),
        expected_sources
    );
    assert!(super::consolidated_record_ranges(&scan)
        .iter()
        .all(|range| !range.contains(&inner.inner)));
}

#[test]
fn flagged_fbb_marker_is_structural() {
    assert!(crate::container::is_fbb_row(&[
        0xb0, 0x04, 0x04, 0xff, 0x99, 0x1f, 0x1a, 0xd1,
    ]));
    assert!(!crate::container::is_fbb_row(&[
        0x20, 0x04, 0x04, 0xff, 0xff, 0xc4, 0xb2, 0xaa,
    ]));
}

#[test]
fn fbb_census_separates_groups_from_face_rows() {
    let row = [0x30, 0x04, 0x04, 0xff, 0, 1, 2, 3];
    let mut body = row.to_vec();
    body.extend_from_slice(&row);
    body.extend_from_slice(&[0xaa; 8]);
    body.extend_from_slice(&row);

    let ranges = crate::container::fbb_run_ranges(&body);
    assert_eq!(ranges, vec![0..16, 24..32]);
    let scan = crate::test_support::with_service_context(|ctx| {
        crate::container::scan_bytes(ctx, standard_catpart())
    })
    .expect("scan the container");
    assert_eq!(scan.census.fbb_runs, 1);
    assert_eq!(scan.census.fbb_face_rows, 2);
}

#[test]
fn brep_surface_extents_append_directly_to_the_retained_destination() {
    let data = [1_u8, 2, 3, 4, 5, 6];
    let directory = InnerDir {
        inner: 0,
        descriptors: vec![
            test_descriptor("MainDataStream", 0, 4),
            test_descriptor("SurfacicReps", 4, 2),
        ],
    };
    crate::test_support::with_retained_limit(8, |ctx| {
        assert_eq!(
            super::brep_stream(ctx, &data, &directory)
                .expect("eight retained vector capacity bytes")
                .0,
            Some(data.to_vec())
        );
    });
}

#[test]
fn container_scan_rejects_wrong_magic_and_truncated_header() {
    for bytes in [&[][..], &b"garbage!"[..]] {
        let result = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, bytes));
        assert!(matches!(
            result,
            Err(cadmpeg_core::CodecError::WrongFormat(_))
        ));
    }
    for length in 8..16 {
        let mut bytes = super::OUTER_MAGIC.to_vec();
        bytes.resize(length, 0);
        let result = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, bytes));
        assert!(matches!(
            result,
            Err(cadmpeg_core::CodecError::Malformed(_))
        ));
    }
}

#[test]
fn main_stream_is_the_shared_brep_prefix() {
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, standard_catpart()))
        .expect("synthetic container admission");
    let main = scan.main_data_stream().expect("main stream");
    let brep = scan.brep.as_deref().expect("BREP stream");
    assert_eq!(main.as_ptr(), brep.as_ptr());
    assert!(main.len() < brep.len());
}

#[test]
fn contiguous_logical_streams_borrow_the_source_image() {
    let scan =
        crate::test_support::with_service_context(|ctx| scan_bytes(ctx, outer_directory_catpart()))
            .expect("synthetic outer directory admission");
    let streams =
        crate::test_support::with_service_context(|ctx| super::logical_record_streams(ctx, &scan))
            .expect("split the logical record streams");
    assert_eq!(streams.len(), 1);
    assert!(matches!(streams[0], std::borrow::Cow::Borrowed(_)));
}

#[test]
fn adjacent_descriptor_extents_borrow_one_root_window() {
    let mut scan =
        crate::test_support::with_service_context(|ctx| scan_bytes(ctx, outer_directory_catpart()))
            .expect("synthetic directory admission");
    let descriptor = &mut scan.outer.as_mut().expect("outer directory").descriptors[0];
    let extent = descriptor.extents[0].clone();
    let half = extent.phys_len / 2;
    assert!(half > 0);
    descriptor.extents = vec![
        Extent {
            phys_len: half,
            ..extent.clone()
        },
        Extent {
            phys_off: extent.phys_off + half,
            phys_len: extent.phys_len - half,
            ..extent
        },
    ];
    let streams =
        crate::test_support::with_service_context(|ctx| super::logical_record_streams(ctx, &scan))
            .expect("split the logical record streams");
    assert_eq!(streams.len(), 1);
    assert!(matches!(streams[0], std::borrow::Cow::Borrowed(_)));
}

#[test]
fn descriptor_adjacency_stops_at_the_first_gap() {
    let mut scan =
        crate::test_support::with_service_context(|ctx| scan_bytes(ctx, outer_directory_catpart()))
            .expect("synthetic directory admission");
    let directory = scan.outer.as_mut().expect("outer directory");
    let descriptor = &mut directory.descriptors[0];
    let extent = descriptor.extents[0].clone();
    descriptor.extents = vec![extent; 4_096];
    assert!(
        super::contiguous_descriptor_range(descriptor, directory.inner, scan.data.len()).is_none()
    );
}

#[test]
fn canonical_record_streams_reuse_the_brep_storage() {
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, standard_catpart()))
        .expect("synthetic directory admission");
    let streams =
        crate::test_support::with_service_context(|ctx| super::logical_record_streams(ctx, &scan))
            .expect("logical sources");
    let main = scan.main_data_stream().expect("canonical main source");
    let brep = scan.brep.as_deref().expect("BREP storage");
    assert!(streams
        .iter()
        .any(|stream| stream.as_ptr() == main.as_ptr() && stream.len() == main.len()));
    assert!(streams
        .iter()
        .any(|stream| stream.as_ptr() == brep[main.len()..].as_ptr()
            && stream.len() == brep.len() - main.len()));
}

#[test]
fn outer_directory_catpart_yields_one_logical_record_stream() {
    let bytes = outer_directory_catpart();
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, bytes))
        .expect("scan the container");
    let streams =
        crate::test_support::with_service_context(|ctx| super::logical_record_streams(ctx, &scan))
            .expect("parse the logical record streams");
    assert_eq!(streams.len(), 1);
}

#[test]
fn fbb_run_ranges_cover_one_complete_run() {
    let bytes = [0x30, 0x04, 0x04, 0xff, 0, 0, 0, 0];
    let ranges = super::fbb_run_ranges(&bytes);
    assert_eq!(ranges, vec![0..8]);
}

#[test]
fn standard_catpart_summary_has_entries() {
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, standard_catpart()))
        .expect("scan the container");
    assert!(!summarize_service(&scan).entries.is_empty());
}

#[test]
fn standard_catpart_scan_reports_notes() {
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, standard_catpart()))
        .expect("scan the container");
    let notes = super::notes(&scan);
    assert!(!notes.is_empty());
}

#[test]
fn outer_container_declares_one_stream() {
    let (bytes, _) = crate::test_support::test_container::outer_container_catpart(b"graph");
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, bytes))
        .expect("scan the container");
    let outer = scan.outer.as_ref().expect("outer directory");
    assert_eq!(outer_container_declarations(&scan.data, outer).len(), 1);
}

#[test]
fn outer_directory_catpart_yields_one_record_source() {
    let bytes = outer_directory_catpart();
    let scan = crate::test_support::with_service_context(|ctx| scan_bytes(ctx, bytes))
        .expect("scan the container");
    assert_eq!(super::consolidated_record_sources(&scan).len(), 1);
}

#[test]
fn outer_stream_directory_parses_one_descriptor() {
    let bytes = outer_directory_catpart();
    let parsed = super::parse_outer_stream_directory(&bytes).expect("valid directory");
    assert_eq!(parsed.descriptors.len(), 1);
}

#[test]
fn e5_alternate_flag_marker_away_from_a_record_end_skips_no_bytes() {
    for family in [0x13, 0x83] {
        let mut inner = Vec::new();
        crate::test_support::test_e5::append_e5_record(
            &mut inner,
            0xff,
            7,
            &[0x85, 0x8d, 0x8a, 0x90, 0x8e, 0x8f, 0x21],
        );
        let mut stray = Vec::new();
        crate::test_support::test_e5::append_e5_record(&mut stray, 0xc0, 8, &inner);
        stray[2] = family;
        let mut bytes = vec![0x14, 0x27, 0x42];
        let inner_start = bytes.len() + stray.len() - inner.len();
        bytes.extend(stray);
        let inner_end = bytes.len();
        crate::test_support::test_e5::append_e5_record(
            &mut bytes,
            0xff,
            9,
            &[0x85, 0x8d, 0x8a, 0x90, 0x8e, 0x8f, 0x22],
        );
        assert_eq!(
            super::all_e5_record_spans(&bytes).collect::<Vec<_>>(),
            [inner_start..inner_end, inner_end..bytes.len()]
        );
    }
}

#[test]
fn absent_outer_declarations_do_not_create_modeling_scope() {
    let inventory = super::parse_outer_container_declarations(&[0; 80], |_| None);
    assert!(!inventory.has_declarations);
    assert!(inventory.resolved.is_empty());
    let mut class_strings = vec![0; 80];
    class_strings.extend_from_slice(b"CATPrtCont\0CATFeatCont\0");
    let inventory = super::parse_outer_container_declarations(&class_strings, |_| None);
    assert!(!inventory.has_declarations);
    assert!(inventory.resolved.is_empty());
}
