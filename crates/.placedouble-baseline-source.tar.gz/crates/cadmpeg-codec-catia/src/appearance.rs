// SPDX-License-Identifier: Apache-2.0
//! Transfer of byte-proven CATIA display colors to neutral appearance bindings.

use std::collections::BTreeMap;

use cadmpeg_ir::appearance::{Appearance, AppearanceBinding, AppearanceTarget};
use cadmpeg_ir::ids::{AppearanceBindingId, AppearanceId, FaceId};
use cadmpeg_ir::topology::Color;
use cadmpeg_ir::CadIr;

use crate::families::standard::fbb::standard_face_colors;
use crate::native::CatiaNative;
use crate::value_block::ValueField;
use cadmpeg_ir::hash::LowerHex;

#[derive(Debug, Default, PartialEq, Eq)]
pub(crate) struct TransferResult {
    transferred_packets: usize,
    unresolved_packets: usize,
    pub(crate) emitted_assets: usize,
    pub(crate) emitted_bindings: usize,
}

impl TransferResult {
    pub(crate) fn decoded_packets(&self) -> usize {
        self.transferred_packets + self.unresolved_packets
    }

    pub(crate) fn transferred_packets(&self) -> usize {
        self.transferred_packets
    }

    pub(crate) fn unresolved_packets(&self) -> usize {
        self.unresolved_packets
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Packet {
    Rgb([u8; 3]),
    Rgba([u8; 4]),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct SourcedPacket {
    packet: Packet,
    source_id: String,
}

impl SourcedPacket {
    fn rgba(&self) -> [u8; 4] {
        match self.packet {
            Packet::Rgb([r, g, b]) => [r, g, b, 0xff],
            Packet::Rgba(rgba) => rgba,
        }
    }

    fn is_rgb(&self) -> bool {
        matches!(self.packet, Packet::Rgb(_))
    }

    fn is_rgba(&self) -> bool {
        matches!(self.packet, Packet::Rgba(_))
    }
}

/// Retains presentation packets and binds eligible packets to model topology.
///
/// `01 R G B` stores opaque RGB and `03 R G B A` stores RGBA.
/// A packet population joins the standard FBB face colors only when its
/// values agree with those rows. The rows independently supply the
/// authoritative face colors (AP-01).
///
/// Every decoded packet reaches exactly one of the transferred and unresolved
/// populations. Their sum is the decoded packet count.
pub(crate) fn transfer(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    ir: &mut CadIr,
    native: &CatiaNative,
    graph_scope: &crate::decode::ModelingGraphScope,
    standard_fbb: Option<&[u8]>,
) -> Result<TransferResult, cadmpeg_core::CodecError> {
    let initial_assets = ir.model.appearances.len();
    let initial_bindings = ir.model.appearance_bindings.len();
    let mut packets = Vec::new();
    let mut source_packets = Vec::new();
    for block in &native.value_blocks {
        let in_modeling_scope = graph_scope.is_unscoped()
            || block
                .object_graph
                .as_ref()
                .is_some_and(|graph| graph_scope.contains(graph));
        for (ordinal, field) in crate::value_block::tokenize(&block.payload)
            .into_iter()
            .enumerate()
        {
            let Some(packet) = packet(&field) else {
                continue;
            };
            let ValueField::Inline { offset, .. } = field else {
                continue;
            };
            let source_id = format!("{}:field#{offset:010}:{ordinal:06}", block.id);
            let packet = SourcedPacket { packet, source_id };
            if in_modeling_scope {
                packets.push(packet);
            } else {
                source_packets.push(packet);
            }
        }
    }
    let mut result = TransferResult::default();
    for packet in &source_packets {
        insert_appearance(ctx, ir, packet.rgba())?;
        insert_source_binding(ctx, ir, packet)?;
    }
    result.unresolved_packets = source_packets.len();

    let mut all_faces = Vec::new();
    let mut body = Vec::new();
    for packet in &packets {
        match packet.packet {
            Packet::Rgb(_) => {
                all_faces.push(packet.rgba());
            }
            Packet::Rgba(rgba) => body.push(rgba),
        }
    }

    // Assets are meaningful independently of topology ownership. Retain every
    // decoded color even when its target incidence remains unresolved.
    for packet in &packets {
        insert_appearance(ctx, ir, packet.rgba())?;
    }

    let positional_colors = match standard_fbb {
        Some(bytes) => standard_face_colors(ctx, bytes)?,
        None => None,
    };
    let positional_bindings = positional_colors
        .filter(|colors| colors.len() == ir.geometry.faces.len())
        .and_then(|colors| Some((standard_faces_in_row_order(ir)?, colors)));
    if let Some((faces, colors)) = positional_bindings {
        let compatible = match all_faces.as_slice() {
            [] => body.len() > 1 && colors.as_slice() == body.as_slice(),
            [base] => {
                let mut overrides = Vec::new();
                for rgba in colors.iter().copied().filter(|rgba| rgba != base) {
                    overrides.push(rgba);
                }
                same_color_multiset(&overrides, &body)
            }
            _ => false,
        };
        for (index, (face, rgba)) in faces.into_iter().zip(colors).enumerate() {
            let appearance = insert_appearance(ctx, ir, rgba)?;
            insert_binding(ctx, ir, &appearance, AppearanceTarget::Face(face), index)?;
        }
        if compatible {
            result.transferred_packets += packets.len();
        } else {
            // AP-01: presentation-object colors can coexist with different
            // effective face colors. Keep their source targets independent.
            for packet in &packets {
                insert_source_binding(ctx, ir, packet)?;
            }
            result.unresolved_packets += packets.len();
        }
    } else {
        if all_faces.len() == 1 && !ir.geometry.faces.is_empty() {
            let appearance = insert_appearance(ctx, ir, all_faces[0])?;
            let faces = copy_face_ids(ir);
            for (index, face) in faces.into_iter().enumerate() {
                insert_binding(ctx, ir, &appearance, AppearanceTarget::Face(face), index)?;
            }
            result.transferred_packets += 1;
        } else {
            for packet in packets.iter().filter(|packet| packet.is_rgb()) {
                insert_source_binding(ctx, ir, packet)?;
            }
            result.unresolved_packets += all_faces.len();
        }

        match body.as_slice() {
            [rgba] if all_faces.is_empty() && ir.geometry.bodies.len() == 1 => {
                let appearance = insert_appearance(ctx, ir, *rgba)?;
                let target = AppearanceTarget::Body(ir.geometry.bodies[0].id.clone());
                insert_binding(ctx, ir, &appearance, target, 0)?;
                result.transferred_packets += 1;
            }
            values => {
                for packet in packets.iter().filter(|packet| packet.is_rgba()) {
                    insert_source_binding(ctx, ir, packet)?;
                }
                result.unresolved_packets += values.len();
            }
        }
    }
    result.emitted_assets = ir.model.appearances.len() - initial_assets;
    result.emitted_bindings = ir.model.appearance_bindings.len() - initial_bindings;
    Ok(result)
}

fn standard_faces_in_row_order(ir: &CadIr) -> Option<Vec<FaceId>> {
    let mut faces = ir
        .geometry
        .faces
        .iter()
        .map(|face| {
            let row = face.id.as_str().strip_prefix("catia:standard:face#")?;
            Some((row.parse::<usize>().ok()?, &face.id))
        })
        .collect::<Option<Vec<_>>>()?;
    faces.sort_unstable_by_key(|(row, _)| *row);
    faces
        .into_iter()
        .enumerate()
        .map(|(expected, (row, id))| (row == expected).then(|| id.clone()))
        .collect()
}

fn copy_face_ids(ir: &CadIr) -> Vec<FaceId> {
    let mut faces = Vec::new();
    for face in &ir.geometry.faces {
        let id = face.id.clone();
        faces.push(id);
    }
    faces
}

fn same_color_multiset(left: &[[u8; 4]], right: &[[u8; 4]]) -> bool {
    fn counts(values: &[[u8; 4]]) -> BTreeMap<[u8; 4], usize> {
        let mut counts = BTreeMap::new();
        for value in values {
            *counts.entry(*value).or_default() += 1;
        }
        counts
    }
    counts(left) == counts(right)
}

fn packet(field: &ValueField) -> Option<Packet> {
    let ValueField::Inline { bytes, .. } = field else {
        return None;
    };
    match bytes.as_slice() {
        [0x01, r, g, b] => Some(Packet::Rgb([*r, *g, *b])),
        [0x03, r, g, b, a] => Some(Packet::Rgba([*r, *g, *b, *a])),
        _ => None,
    }
}

fn insert_appearance(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    ir: &mut CadIr,
    rgba: [u8; 4],
) -> Result<AppearanceId, cadmpeg_core::CodecError> {
    let id = format!("catia:appearance:rgba#{}", LowerHex(&rgba));
    let id = AppearanceId::mint(id).map_err(cadmpeg_core::CodecError::malformed)?;
    if !ir
        .model
        .appearances
        .iter()
        .any(|appearance| appearance.id == id)
    {
        ctx.charge_entities(1, "admit CATIA appearance")?;
        let retained_id = id.clone();
        let schema = "CATIA V5 display color".to_owned();
        ir.model.appearances.push(Appearance {
            id: retained_id,
            name: None,
            library_id: None,
            asset_guid: None,
            visual_guid: None,
            physical_token: None,
            schema: Some(schema),
            category: None,
            base_color: Some(Color::from_rgba8(rgba[0], rgba[1], rgba[2], rgba[3])),
            properties: BTreeMap::new(),
            textures: Vec::new(),
        });
    }
    Ok(id)
}

fn insert_binding(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    ir: &mut CadIr,
    appearance: &AppearanceId,
    target: AppearanceTarget,
    index: usize,
) -> Result<(), cadmpeg_core::CodecError> {
    let key = appearance
        .as_str()
        .split_once('#')
        .map_or("", |(_, key)| key);
    let id = format!("catia:appearance:binding#{index}:{key}");
    let id = AppearanceBindingId::mint(id).map_err(cadmpeg_core::CodecError::malformed)?;
    insert_binding_record(ctx, ir, appearance, target, id)
}

fn insert_source_binding(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    ir: &mut CadIr,
    packet: &SourcedPacket,
) -> Result<(), cadmpeg_core::CodecError> {
    let appearance = insert_appearance(ctx, ir, packet.rgba())?;
    // Hex encoding preserves the source token while excluding key delimiters.
    let key = appearance
        .as_str()
        .split_once('#')
        .map_or("", |(_, key)| key);
    let id = format!(
        "catia:appearance:source-binding#source-{}:{key}",
        LowerHex(packet.source_id.as_bytes())
    );
    let id = AppearanceBindingId::mint(id).map_err(cadmpeg_core::CodecError::malformed)?;
    insert_binding_record(
        ctx,
        ir,
        &appearance,
        AppearanceTarget::Source {
            source_id: packet.source_id.clone(),
        },
        id,
    )
}

fn insert_binding_record(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    ir: &mut CadIr,
    appearance: &AppearanceId,
    target: AppearanceTarget,
    id: AppearanceBindingId,
) -> Result<(), cadmpeg_core::CodecError> {
    ctx.charge_entities(1, "admit CATIA appearance binding")?;
    let retained_appearance = appearance.clone();
    let object_type = "CATIA V5 display property".to_owned();
    ir.model.appearance_bindings.push(AppearanceBinding {
        id,
        target: target.into(),
        appearance: retained_appearance,
        source_entity_id: None,
        object_type: Some(object_type),
        visible: None,
        channels: BTreeMap::new(),
    });
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{insert_source_binding, packet, transfer, Packet, SourcedPacket, TransferResult};
    use crate::native::CatiaNative;
    use crate::native::CatiaValueBlock;
    use crate::value_block::ValueField;
    use cadmpeg_ir::appearance::AppearanceTarget;
    use cadmpeg_ir::ids::{BodyId, FaceId, ShellId, SurfaceId};
    use cadmpeg_ir::topology::{Body, BodyKind, Face, Sense};
    use cadmpeg_ir::CadIr;

    #[test]
    fn appearance_entity_limit_refuses_before_asset() {
        let mut ir = model(0);
        let native = native(vec![inline(&[0x01, 1, 2, 3])]);
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let mut policy = cadmpeg_core::decode::DecodePolicy::service();
        policy.limits.max_entities = 0;
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
            .expect("empty root fits service input limit");
        let error = transfer(
            &ctx,
            &mut ir,
            &native,
            &crate::decode::ModelingGraphScope::Unscoped,
            None,
        )
        .expect_err("one appearance exceeds zero entities");
        assert!(
            matches!(error, cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                && limit.operation == "admit CATIA appearance")
        );
        assert!(ir.model.appearances.is_empty());
    }

    #[test]
    fn appearance_binding_entity_limit_refuses_before_binding() {
        let mut ir = model(0);
        let native = native(vec![inline(&[0x01, 1, 2, 3])]);
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let mut policy = cadmpeg_core::decode::DecodePolicy::service();
        policy.limits.max_entities = 1;
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
            .expect("empty root fits service input limit");
        let error = transfer(
            &ctx,
            &mut ir,
            &native,
            &crate::decode::ModelingGraphScope::Unscoped,
            None,
        )
        .expect_err("asset and binding need two entities");
        assert!(
            matches!(error, cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                && limit.operation == "admit CATIA appearance binding")
        );
        assert_eq!(ir.model.appearances.len(), 1);
        assert!(ir.model.appearance_bindings.is_empty());
    }

    fn model(face_count: usize) -> CadIr {
        let mut ir = CadIr::empty();
        ir.geometry.bodies.push(Body {
            id: BodyId::mint("catia:test:body#body").expect("identity grammar"),
            kind: BodyKind::Solid,
            transform: None,
            name: None,
            color: None,
            visible: None,
            native_ref: None,
        });
        for index in 0..face_count {
            ir.geometry.faces.push(Face {
                id: FaceId::mint(format!("catia:standard:face#{index}")).expect("identity grammar"),
                shell: ShellId::mint("catia:test:shell#shell").expect("identity grammar"),
                surface: SurfaceId::mint(format!("catia:test:surface#surface-{index}"))
                    .expect("identity grammar"),
                sense: Sense::Forward,
                loops: cadmpeg_ir::topology::FaceLoops::unspecified(Vec::new()),
                name: None,
                color: None,
                tolerance: None,
                native_ref: None,
            });
        }
        ir
    }

    // This conversion consumes the input carrier at the typed construction boundary.
    #[allow(clippy::needless_pass_by_value)]
    fn native(fields: Vec<ValueField>) -> CatiaNative {
        let mut native = CatiaNative::default();
        let payload = fields
            .iter()
            .flat_map(|field| {
                let ValueField::Inline { bytes, .. } = field else {
                    panic!("appearance fixture requires inline fields");
                };
                [0x8e, bytes.code().expect("validated inline bytes"), 0x84]
                    .into_iter()
                    .chain(bytes.as_slice().iter().copied())
            })
            .collect::<Vec<_>>();
        native.value_blocks.push(CatiaValueBlock {
            id: "values".into(),
            byte_offset: 0,
            object_graph: None,
            catalog: "catalog".into(),
            payload,
            schema_selections: vec![],
        });
        native
    }

    fn inline(bytes: &[u8]) -> ValueField {
        ValueField::Inline {
            bytes: bytes.to_vec().try_into().expect("inline byte count"),
            offset: 0,
        }
    }

    fn six_face_brep(rgba: [u8; 4]) -> Vec<u8> {
        (0..6)
            .flat_map(|_| [0xb0, 4, 4, 0xff, rgba[3], rgba[2], rgba[1], rgba[0]])
            .collect()
    }

    #[test]
    fn accepts_only_exact_display_packets() {
        let inline = |bytes: Vec<u8>| ValueField::Inline {
            bytes: bytes.try_into().expect("inline byte count"),
            offset: 0,
        };
        assert_eq!(
            packet(&inline(vec![1, 0xd1, 0x1a, 0x1f])),
            Some(Packet::Rgb([0xd1, 0x1a, 0x1f]))
        );
        assert_eq!(
            packet(&inline(vec![3, 0xd1, 0x1a, 0x1f, 0x99])),
            Some(Packet::Rgba([0xd1, 0x1a, 0x1f, 0x99]))
        );
        assert_eq!(packet(&inline(vec![2, 0xd1, 0x1a, 0x1f])), None);
        assert_eq!(packet(&inline(vec![1, 0xd1, 0x1a, 0x1f, 0x99])), None);
        assert_eq!(packet(&inline(vec![3, 0xd1, 0x1a, 0x1f])), None);
        assert_eq!(
            packet(&ValueField::Marker {
                code: 0xe7,
                offset: 0
            }),
            None
        );
    }

    #[test]
    fn every_packet_is_accounted_for_across_target_populations() {
        for all_face_count in 0..=3 {
            for body_packet_count in 0..=3 {
                let fields = std::iter::repeat_with(|| inline(&[1, 0x10, 0x20, 0x30]))
                    .take(all_face_count)
                    .chain(
                        std::iter::repeat_with(|| inline(&[3, 0x40, 0x50, 0x60, 0xff]))
                            .take(body_packet_count),
                    )
                    .collect::<Vec<_>>();
                let native = native(fields);
                for face_count in [0, 2] {
                    for body_count in 0..=2 {
                        let mut ir = model(face_count);
                        let body = ir.geometry.bodies[0].clone();
                        ir.geometry.bodies = (0..body_count)
                            .map(|index| Body {
                                id: BodyId::compose(
                                    &cadmpeg_ir::identity_namespace!("catia", "test", "body"),
                                    index,
                                ),
                                ..body.clone()
                            })
                            .collect();
                        let result = crate::test_support::with_service_context(|ctx| {
                            transfer(
                                ctx,
                                &mut ir,
                                &native,
                                &crate::decode::ModelingGraphScope::Unscoped,
                                None,
                            )
                        })
                        .expect("transfer the appearance");
                        assert_eq!(
                            result.decoded_packets(),
                            all_face_count + body_packet_count,
                            "{all_face_count} all-face packets, {body_packet_count} body packets, \
                             {face_count} faces, {body_count} bodies",
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn transfers_unstyled_body_and_all_faces_without_inventing_targets() {
        let mut ir = model(6);
        assert_eq!(
            crate::test_support::with_service_context(|ctx| transfer(
                ctx,
                &mut ir,
                &CatiaNative::default(),
                &crate::decode::ModelingGraphScope::Unscoped,
                None
            ))
            .expect("transfer the appearance"),
            TransferResult::default()
        );
        assert!(ir.model.appearances.is_empty());

        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(vec![inline(&[3, 0xd1, 0x1a, 0x1f, 0xff])]),
                &crate::decode::ModelingGraphScope::Unscoped,
                None,
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_assets,
                result.emitted_bindings
            ),
            (1, 1, 0, 1, 1)
        );
        assert!(matches!(
            &ir.model.appearance_bindings[0].target.entity,
            AppearanceTarget::Body(_)
        ));
        assert_eq!(
            ir.model.appearance_bindings[0].id.as_str(),
            "catia:appearance:binding#0:d11a1fff"
        );

        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(vec![inline(&[1, 0xd1, 0x1a, 0x1f])]),
                &crate::decode::ModelingGraphScope::Unscoped,
                None,
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_assets,
                result.emitted_bindings
            ),
            (1, 1, 0, 1, 6)
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .all(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_))));
    }

    #[test]
    fn retains_unbound_override_asset_and_reports_its_packet() {
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(vec![
                    inline(&[1, 0xd1, 0x1a, 0x1f]),
                    inline(&[3, 0x14, 0x3d, 0xe0, 0xff]),
                ]),
                &crate::decode::ModelingGraphScope::Unscoped,
                None,
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_assets,
                result.emitted_bindings
            ),
            (2, 1, 1, 2, 7)
        );
        assert!(ir
            .model
            .appearances
            .iter()
            .any(|asset| asset.id.as_str().contains("143de0ff")));
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. }))
                .count(),
            1
        );
        assert!(ir.model.appearance_bindings.iter().any(|binding| {
            binding.appearance.as_str().contains("143de0ff")
                && matches!(
                    &binding.target.entity,
                    AppearanceTarget::Source { source_id }
                        if source_id == "values:field#0000000007:000001"
                )
        }));
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
            .all(|binding| binding.appearance.as_str().contains("d11a1fff")));
    }

    #[test]
    fn source_binding_identity_encodes_nested_source_delimiters() {
        let packet = SourcedPacket {
            packet: Packet::Rgba([0x14, 0x3d, 0xe0, 0xff]),
            source_id: "catia:outer:value-block#0001:field#0002".into(),
        };
        let mut ir = model(0);
        crate::test_support::with_service_context(|ctx| {
            insert_source_binding(ctx, &mut ir, &packet)
        })
        .expect("insert source binding");
        let binding = ir
            .model
            .appearance_bindings
            .first()
            .expect("source binding");
        assert_eq!(binding.id.as_str().matches('#').count(), 1);
        assert!(binding
            .id
            .as_str()
            .starts_with("catia:appearance:source-binding#source-"));
        assert!(matches!(
            &binding.target.entity,
            AppearanceTarget::Source { source_id } if source_id == &packet.source_id
        ));
    }

    #[test]
    fn positional_transparency_requires_matching_fbb_values() {
        let rgba = [0xd1, 0x1a, 0x1f, 0x99];
        let fields = (0..6)
            .map(|_| inline(&[3, rgba[0], rgba[1], rgba[2], rgba[3]]))
            .collect::<Vec<_>>();
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields.clone()),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&six_face_brep(rgba)),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_assets,
                result.emitted_bindings
            ),
            (6, 6, 0, 1, 6)
        );
        let ids = ir
            .model
            .appearance_bindings
            .iter()
            .map(|binding| &binding.id)
            .collect::<std::collections::HashSet<_>>();
        assert_eq!(ids.len(), 6);
        assert!(ir.model.appearances[0]
            .base_color
            .is_some_and(|color| color.a() == 0.6));

        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&six_face_brep([0x14, 0x3d, 0xe0, 0xff])),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_bindings
            ),
            (6, 0, 6, 12)
        );
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. }))
                .count(),
            6
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
            .all(|binding| binding.appearance.as_str().contains("143de0ff")));
    }

    #[test]
    fn positional_colors_require_standard_face_population_provenance() {
        let rgba = [0xd1, 0x1a, 0x1f, 0x99];
        let fields = (0..6)
            .map(|_| inline(&[3, rgba[0], rgba[1], rgba[2], rgba[3]]))
            .collect::<Vec<_>>();
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields),
                &crate::decode::ModelingGraphScope::Unscoped,
                None,
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_bindings,
            ),
            (6, 0, 6, 6)
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .all(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. })));
    }

    #[test]
    fn effective_face_colors_are_independent_of_presentation_packets() {
        for face_count in [5, 6] {
            let mut ir = model(face_count);
            let result = crate::test_support::with_service_context(|ctx| {
                transfer(
                    ctx,
                    &mut ir,
                    &CatiaNative::default(),
                    &crate::decode::ModelingGraphScope::Unscoped,
                    Some(&six_face_brep([210, 210, 255, 255])),
                )
            })
            .expect("service profile admits appearance transfer");
            assert_eq!(result.decoded_packets(), 0);
            let expected = if face_count == 6 { 6 } else { 0 };
            assert_eq!(result.emitted_bindings, expected);
            assert_eq!(ir.model.appearance_bindings.len(), expected);
            assert!(ir.model.appearance_bindings.iter().all(|binding| {
                matches!(binding.target.entity, AppearanceTarget::Face(_))
                    && binding.appearance.as_str().contains("d2d2ffff")
            }));
        }
    }

    #[test]
    fn positional_colors_follow_fbb_rows_after_face_arena_sorting() {
        let mut ir = model(12);
        ir.geometry.faces.sort_by(|a, b| a.id.cmp(&b.id));
        let brep = (0..12)
            .flat_map(|row| [0xb0, 4, 4, 0xff, 0xff, 0, 0, row])
            .collect::<Vec<_>>();
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &CatiaNative::default(),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&brep),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(result.emitted_bindings, 12);
        for (row, binding) in ir.model.appearance_bindings.iter().enumerate() {
            let AppearanceTarget::Face(id) = &binding.target.entity else {
                panic!("FBB row binds to a standard face");
            };
            assert_eq!(id.as_str(), format!("catia:standard:face#{row}"));
            assert!(binding
                .appearance
                .as_str()
                .ends_with(&format!("{row:02x}0000ff")));
        }
    }

    #[test]
    fn positional_population_supersedes_but_still_accounts_for_all_faces_packet() {
        let rgba = [0xd1, 0x1a, 0x1f, 0x99];
        let mut fields = vec![inline(&[1, 0xd1, 0x1a, 0x1f])];
        fields.extend((0..6).map(|_| inline(&[3, rgba[0], rgba[1], rgba[2], rgba[3]])));
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields.clone()),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&six_face_brep(rgba)),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_assets,
                result.emitted_bindings
            ),
            (7, 7, 0, 2, 6)
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .all(|binding| binding.appearance.as_str().contains("d11a1f99")));

        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&six_face_brep([0x14, 0x3d, 0xe0, 0xff])),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_bindings
            ),
            (7, 0, 7, 13)
        );
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. }))
                .count(),
            7
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
            .all(|binding| binding.appearance.as_str().contains("143de0ff")));
    }

    #[test]
    fn base_plus_override_population_uses_effective_fbb_face_colors() {
        let gray = [0x8c, 0x8c, 0x8c, 0xff];
        let blue = [0x0d, 0x26, 0xe6, 0xff];
        for target in 0..6 {
            let mut colors = [gray; 6];
            colors[target] = blue;
            let brep = colors
                .into_iter()
                .flat_map(|rgba| [0xb0, 4, 4, 0xff, rgba[3], rgba[2], rgba[1], rgba[0]])
                .collect::<Vec<_>>();
            let mut ir = model(6);
            let result = crate::test_support::with_service_context(|ctx| {
                transfer(
                    ctx,
                    &mut ir,
                    &native(vec![
                        inline(&[1, gray[0], gray[1], gray[2]]),
                        inline(&[3, blue[0], blue[1], blue[2], blue[3]]),
                    ]),
                    &crate::decode::ModelingGraphScope::Unscoped,
                    Some(&brep),
                )
            })
            .expect("transfer the appearance");
            assert_eq!(
                (
                    result.decoded_packets(),
                    result.transferred_packets,
                    result.unresolved_packets,
                    result.emitted_assets,
                    result.emitted_bindings
                ),
                (2, 2, 0, 2, 6)
            );
            for (index, binding) in ir.model.appearance_bindings.iter().enumerate() {
                let key = if index == target {
                    "0d26e6ff"
                } else {
                    "8c8c8cff"
                };
                assert!(binding.appearance.as_str().contains(key));
            }
        }
    }

    #[test]
    fn base_plus_distinct_overrides_requires_exact_fbb_multiset() {
        let colors = [
            [0xe6, 0x0d, 0x0d, 0xff],
            [0x0d, 0xcc, 0x1a, 0xff],
            [0x0d, 0x26, 0xe6, 0xff],
            [0xf2, 0xcc, 0x0d, 0xff],
            [0xd9, 0x0d, 0xbf, 0xff],
            [0x0d, 0xcc, 0xd9, 0xff],
        ];
        let fields = std::iter::once(inline(&[1, colors[0][0], colors[0][1], colors[0][2]]))
            .chain(
                colors[1..]
                    .iter()
                    .map(|rgba| inline(&[3, rgba[0], rgba[1], rgba[2], rgba[3]])),
            )
            .collect::<Vec<_>>();
        let brep = colors
            .into_iter()
            .flat_map(|rgba| [0xb0, 4, 4, 0xff, rgba[3], rgba[2], rgba[1], rgba[0]])
            .collect::<Vec<_>>();
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields.clone()),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&brep),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.decoded_packets(),
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_bindings
            ),
            (6, 6, 0, 6)
        );
        for (binding, rgba) in ir.model.appearance_bindings.iter().zip(colors) {
            assert!(binding.appearance.as_str().contains(&format!(
                "{:02x}{:02x}{:02x}{:02x}",
                rgba[0], rgba[1], rgba[2], rgba[3]
            )));
        }

        let mut mismatched = brep;
        mismatched[7] = 0xff;
        let mut ir = model(6);
        let result = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut ir,
                &native(fields),
                &crate::decode::ModelingGraphScope::Unscoped,
                Some(&mismatched),
            )
        })
        .expect("transfer the appearance");
        assert_eq!(
            (
                result.transferred_packets,
                result.unresolved_packets,
                result.emitted_bindings
            ),
            (0, 6, 12)
        );
        for (index, binding) in ir
            .model
            .appearance_bindings
            .iter()
            .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
            .enumerate()
        {
            let mut rgba = colors[index];
            if index == 0 {
                rgba[0] = 0xff;
            }
            assert!(binding.appearance.as_str().contains(&format!(
                "{:02x}{:02x}{:02x}{:02x}",
                rgba[0], rgba[1], rgba[2], rgba[3]
            )));
        }
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. }))
                .count(),
            6
        );
    }

    #[test]
    fn transfer_decodes_one_inline_appearance_packet() {
        let input = native(vec![inline(&[0x01, 1, 2, 3])]);
        let admitted = crate::test_support::with_service_context(|ctx| {
            transfer(
                ctx,
                &mut model(0),
                &input,
                &crate::decode::ModelingGraphScope::Unscoped,
                None,
            )
        })
        .expect("transfer the appearance");
        assert_eq!(admitted.decoded_packets(), 1);
    }
    #[test]
    fn presentation_sources_survive_unresolved_modeling_scope_without_topology_binding() {
        let mut ir = model(1);
        let mut native = native(vec![inline(&[0x03, 0, 0, 0, 0x7f])]);
        native.value_blocks[0].object_graph = Some("presentation-graph".to_string());
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let policy = cadmpeg_core::decode::DecodePolicy::service();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
            .expect("bounded synthetic presentation source");
        let result = transfer(
            &ctx,
            &mut ir,
            &native,
            &crate::decode::ModelingGraphScope::Unresolved,
            None,
        )
        .expect("retain presentation source");
        assert_eq!(result.decoded_packets(), 1);
        assert_eq!(result.transferred_packets(), 0);
        assert_eq!(result.unresolved_packets(), 1);
        assert_eq!(ir.model.appearances.len(), 1);
        assert_eq!(ir.model.appearance_bindings.len(), 1);
        assert!(matches!(
            &ir.model.appearance_bindings[0].target.entity,
            AppearanceTarget::Source { .. }
        ));
    }

    #[test]
    fn out_of_scope_presentation_packets_do_not_enter_model_color_populations() {
        let mut ir = model(1);
        let mut native = native(vec![inline(&[0x01, 10, 20, 30])]);
        native.value_blocks[0].object_graph = Some("part-graph".to_string());
        let mut source = native.value_blocks[0].clone();
        source.id = "presentation-values".to_string();
        source.object_graph = Some("presentation-graph".to_string());
        source.payload = vec![0x8e, 0xec, 0x84, 0x03, 0, 0, 0, 0x7f];
        native.value_blocks.push(source);
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let policy = cadmpeg_core::decode::DecodePolicy::service();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
            .expect("bounded synthetic presentation sources");
        let result = transfer(
            &ctx,
            &mut ir,
            &native,
            &crate::decode::ModelingGraphScope::Scoped("part-graph".to_string()),
            None,
        )
        .expect("separate topology and presentation targets");
        assert_eq!(result.decoded_packets(), 2);
        assert_eq!(result.transferred_packets(), 1);
        assert_eq!(result.unresolved_packets(), 1);
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
                .count(),
            1
        );
        assert_eq!(
            ir.model
                .appearance_bindings
                .iter()
                .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Source { .. }))
                .count(),
            1
        );
        assert!(ir
            .model
            .appearance_bindings
            .iter()
            .filter(|binding| matches!(binding.target.entity, AppearanceTarget::Face(_)))
            .all(|binding| binding.appearance.as_str().ends_with("0a141eff")));
    }

    #[test]
    fn source_only_colors_preserve_independent_fbb_face_colors() {
        for owner in [None, Some("presentation-graph".to_string())] {
            let mut ir = model(2);
            let mut native = native(vec![
                inline(&[0x03, 0, 0, 0, 0x7f]),
                inline(&[0x03, 0, 0, 0, 0x7f]),
            ]);
            native.value_blocks[0].object_graph = owner;
            let fbb = [0x30, 4, 4, 0xff, 0xff, 0xff, 0xd2, 0xd2].repeat(2);
            let arena = cadmpeg_core::decode::DecodeArena::new();
            let policy = cadmpeg_core::decode::DecodePolicy::service();
            let (ctx, _) =
                cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
                    .expect("bounded independent source packets");
            let result = transfer(
                &ctx,
                &mut ir,
                &native,
                &crate::decode::ModelingGraphScope::Unresolved,
                Some(&fbb),
            )
            .expect("independent FBB and source presentations");
            assert_eq!(result.decoded_packets(), 2);
            assert_eq!(result.transferred_packets(), 0);
            assert_eq!(result.unresolved_packets(), 2);
            assert_eq!(ir.model.appearances.len(), 2);
            assert_eq!(ir.model.appearance_bindings.len(), 4);
            let faces = ir
                .model
                .appearance_bindings
                .iter()
                .filter(|b| matches!(b.target.entity, AppearanceTarget::Face(_)))
                .collect::<Vec<_>>();
            assert_eq!(faces.len(), 2);
            assert!(faces
                .iter()
                .all(|b| b.appearance.as_str().ends_with("d2d2ffff")));
            let sources = ir
                .model
                .appearance_bindings
                .iter()
                .filter(|b| matches!(b.target.entity, AppearanceTarget::Source { .. }))
                .collect::<Vec<_>>();
            assert_eq!(sources.len(), 2);
            assert!(sources
                .iter()
                .all(|b| b.appearance.as_str().ends_with("0000007f")));
            assert!(!ir
                .model
                .appearance_bindings
                .iter()
                .any(|b| matches!(b.target.entity, AppearanceTarget::Body(_))));
        }
    }
}
