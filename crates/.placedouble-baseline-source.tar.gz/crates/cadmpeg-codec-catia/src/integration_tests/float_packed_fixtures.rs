use super::{assert_valid, decode};
use cadmpeg_ir::report::Severity;
use cadmpeg_test_support::wire;

const EPS_FIXTURE_POINT_MM: f64 = 1.0e-12;

fn assert_native_fixture(
    bytes: &[u8],
    expected_points: &[[f64; 3]],
    expected_loops: usize,
) -> cadmpeg_test_support::EditableDecodeResult {
    let result = decode(bytes.to_vec());
    let geometry = &result.ir().geometry;
    let count = expected_points.len();
    assert!(result.report().geometry_transferred());
    assert_eq!(geometry.bodies.len(), 1);
    assert_eq!(geometry.regions.len(), 1);
    assert_eq!(geometry.shells.len(), 1);
    assert_eq!(geometry.faces.len(), 1);
    assert_eq!(geometry.loops.len(), expected_loops);
    assert_eq!(geometry.surfaces.len(), 1);
    assert_eq!(geometry.coedges.len(), count);
    assert_eq!(geometry.edges.len(), count);
    assert_eq!(geometry.vertices.len(), count);
    assert_eq!(geometry.pcurves.len(), count);
    assert_eq!(geometry.points.len(), count);
    for expected in expected_points {
        assert!(geometry.points.iter().any(|point| {
            let position = point.position().get();
            (position.x - expected[0])
                .hypot(position.y - expected[1])
                .hypot(position.z - expected[2])
                <= EPS_FIXTURE_POINT_MM
        }));
    }
    for (key, expected) in [
        (crate::coverage::DECODED_OBJECT_STREAM_RUN_COUNT, 1),
        (crate::coverage::SELECTED_OBJECT_STREAM_RUN_COUNT, 1),
        (crate::coverage::EXHAUSTED_OBJECT_STREAM_SELECTION_COUNT, 0),
        (crate::coverage::UNSELECTED_OBJECT_STREAM_RUN_COUNT, 0),
        (
            crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_2A_COUNT,
            count,
        ),
        (
            crate::coverage::TYPED_OBJECT_STREAM_PARAMETER_INCIDENCE_COUNT,
            count,
        ),
        (
            crate::coverage::TYPED_OBJECT_STREAM_PARAMETER_INCIDENCE_MEMBER_COUNT,
            2 * count,
        ),
        (
            crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_ROSTER_COUNT,
            count,
        ),
        (
            crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_ROSTER_MEMBER_COUNT,
            count,
        ),
        (
            crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_TERMINAL_CONTROL_04_COUNT,
            count,
        ),
        (
            crate::coverage::TYPED_UNRESOLVED_OBJECT_STREAM_FACE_COUNT,
            0,
        ),
        (
            crate::coverage::TYPED_UNRESOLVED_OBJECT_STREAM_LOOP_COUNT,
            0,
        ),
    ] {
        assert_eq!(
            wire::coverage_count(result.report(), key.as_str()),
            expected,
            "{}",
            key.as_str()
        );
    }
    let [loss] = result.report().losses.as_slice() else {
        panic!("the fixture has one topology gauge warning");
    };
    assert_eq!(
        loss.code,
        crate::loss::CatiaLossCode::TopologyB5GaugeSubstituted
            .note("fixture")
            .code
    );
    assert_eq!(loss.severity, Severity::Warning);
    assert_valid(&result);
    result
}

#[test]
fn frozen_native_plane_fixture_transfers_its_complete_identity_chain() {
    assert_native_fixture(
        include_bytes!("../../tests/golden/fixtures/float_packed_native_plane.catpart"),
        &[[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
        1,
    );
}

#[test]
fn frozen_native_cone_fixture_preserves_radius_and_radial_plane_angle() {
    assert_native_fixture(
        include_bytes!("../../tests/golden/fixtures/float_packed_native_cone.catpart"),
        &[
            [4.364_654_691_212_069, 0.0, 0.723_230_863_929_924],
            [6.229_309_382_424_138, 0.0, 1.446_461_727_859_848],
            [0.0, 6.229_309_382_424_138, 1.446_461_727_859_848],
            [0.0, 4.364_654_691_212_069, 0.723_230_863_929_924],
        ],
        1,
    );
}

#[test]
fn frozen_native_plane_hole_uses_location_controls_with_nurbs_boundaries() {
    let result = assert_native_fixture(
        include_bytes!("../../tests/golden/fixtures/float_packed_native_plane_hole.catpart"),
        &[
            [0.0, 0.0, 0.0],
            [6.0, 0.0, 0.0],
            [0.0, 6.0, 0.0],
            [1.0, 1.0, 0.0],
            [1.0, 2.0, 0.0],
            [2.0, 1.0, 0.0],
        ],
        2,
    );
    assert_eq!(
        result.ir().geometry.faces[0].loops,
        cadmpeg_ir::topology::FaceLoops::classified(
            cadmpeg_ir::ids::LoopId::mint("catia:b5:loop#400".to_string())
                .expect("fixture identity"),
            vec![
                cadmpeg_ir::ids::LoopId::mint("catia:b5:loop#401".to_string())
                    .expect("fixture identity")
            ],
        )
    );
    assert!(result.ir().geometry.pcurves.iter().all(|pcurve| matches!(
        pcurve.geometry,
        cadmpeg_ir::geometry::pcurve::PcurveGeometry::Nurbs { .. }
    )));
}

#[test]
fn reflected_native_plane_fixture_retains_negative_exterior_orientation() {
    let result = assert_native_fixture(
        include_bytes!("../../tests/fixtures/float_packed_native_plane_negative.catpart"),
        &[[0.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 0.0, 0.0]],
        1,
    );
    assert_eq!(
        result.ir().geometry.faces[0].sense,
        cadmpeg_ir::topology::Sense::Reversed
    );
    let cadmpeg_ir::geometry::SurfaceGeometry::Solved(
        cadmpeg_ir::geometry::SolvedSurfaceGeometry::Plane(plane),
    ) = &result.ir().geometry.surfaces[0].geometry
    else {
        panic!("unchanged XY plane");
    };
    assert_eq!(plane.frame().axis().as_raw().z, 1.0);
}
