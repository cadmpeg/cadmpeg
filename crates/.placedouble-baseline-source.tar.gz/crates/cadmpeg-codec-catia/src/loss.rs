// SPDX-License-Identifier: Apache-2.0
//! Stable loss vocabulary for CATIA V5 `.CATPart` decoding.
//!
//! Every fallback, approximation, and drop the decoder reports carries a
//! stable machine-readable code from [`CatiaLossCode`]. Codes are the gating
//! surface: harness oracles and downstream tooling key on them, never on the
//! human-readable message text, so a reworded message is not a contract change
//! and a new drop path without a code does not compile.
//!
//! [`CatiaLossCode::note`] is the single practical construction path for a
//! decode-time [`LossNote`] in this crate: it fixes the loss category and
//! severity from the code so the two cannot drift apart across sites. The
//! caller supplies the loss message.
//! Local codes appear on
//! [`LossNote::code`] under the `catia` namespace.
//!
//! [`CatiaLossCode::shared_taxonomy`] is an exhaustive match with no fall-through
//! arm. A default arm would silently assign a category to a code added later,
//! and the categories this codec spans (geometry, topology, history, attribute,
//! container) have no honest common default.
//!

use cadmpeg_ir::report::loss::LossKind;

use cadmpeg_ir::report::{
    loss::{LossNote, LossTaxonomy},
    Severity,
};

/// Render an identity population into the caller's loss message.
pub(crate) fn identity_statement<T: std::fmt::Display>(ids: &[T]) -> impl std::fmt::Display + '_ {
    struct Statement<'a, T>(&'a [T]);
    impl<T: std::fmt::Display> std::fmt::Display for Statement<'_, T> {
        fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            const LISTED: usize = 8;
            for (index, id) in self.0.iter().take(LISTED).enumerate() {
                if index != 0 {
                    formatter.write_str(", ")?;
                }
                write!(formatter, "{id}")?;
            }
            if let Some(rest) = self.0.len().checked_sub(LISTED).filter(|rest| *rest > 0) {
                write!(formatter, " and {rest} more")?;
            }
            Ok(())
        }
    }
    Statement(ids)
}

/// A stable, machine-readable identifier for one CATIA V5 transfer loss.
///
/// Variants are grouped by the record family whose transfer degraded. The
/// string form (via [`CatiaLossCode::code`]) is the stable contract.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub(crate) enum CatiaLossCode {
    /// The storage layout matched no declared dialect's structural invariants.
    SourceDialectUnverified,
    /// A decode route refused source records and then transferred no model, so
    /// the decode continued to the next route or to the metadata fallback.
    SourceRouteFellThrough,
    /// Carrier populations assigned conflicting annotations to one identity.
    SourceAnnotationCollision,
    /// The `7C02` catalog scan skipped candidates at its walk allowance.
    SourceCatalogScanBounded,
    /// Verbatim vertex points and analytic surface carriers were decoded.
    GeometryCarrierSummary,
    /// A sheet fit extends a rolling section past its stored transverse interval.
    GeometryRollingSheetExtended,
    /// Corroborated affine stations replace disagreeing fitted vertex positions.
    TopologyAffineVertexReconciled,
    /// A planar shared-edge lift uses a native parameter-map fit tolerance.
    GeometryParameterMapAccuracyInferred,
    /// A model-space curve supplies a bounded plane projection.
    GeometryPlanePcurveProjected,
    /// A witnessed conic branch exceeds the incident face bounds.
    GeometryConicBranchBoundsInferred,
    /// A sheet face uses a fitted surface carrier.
    GeometrySheetSurfaceFitted,
    /// A transferred rolling-ball fit uses adjusted rail points.
    GeometryRollingBallRailsAdjusted,
    /// Transferred model retains unresolved curve or surface carriers.
    GeometryUnresolvedCarriers,
    /// No B-rep geometry was transferred for this storage variant.
    GeometryBrepNotTransferred,
    /// Plane surface records lacked valid tag-bridged parameter records.
    GeometryPlaneParametersInvalid,
    /// Analytic surface records had a non-finite or out-of-range payload.
    GeometryAnalyticPayloadInvalid,
    /// A record stated a parameter range that is non-finite or not increasing.
    GeometryParameterRangeInvalid,
    /// Equivalent support charts produce non-finite pcurve coordinates.
    GeometryPcurveRechartNonFinite,
    /// Binary32 coordinate uncertainty widened derived vertex tolerances.
    GeometryVertexToleranceWidened,
    /// Face-local free-form carriers retain identity without aliased geometry.
    GeometryFaceLocalFreeformNotTransferred,
    /// Revolution carriers retain profile identity without bound directrices.
    GeometryRevolutionProfileUnbound,
    /// Consolidated line-profile records were not transferred by the active route.
    GeometryLineProfileNotTransferred,
    /// Detected FBB face rows were not emitted as a B-rep boundary graph.
    TopologyBoundaryGraphNotEmitted,
    /// Candidate FBB face rows were withheld from the standard topology population.
    TopologyFbbRowsWithheld,
    /// B-rep topology graph was not built for this file.
    TopologyGraphNotBuilt,
    /// Closed sketch components and sheet bodies were inferred from a Fill boundary.
    TopologySheetComponentsInferred,
    /// A standard-family topology evidence search reached its local work bound.
    TopologyStandardSearchBounded,
    /// A planar face stated too many boundary points to classify its loops.
    TopologyPlanarBoundaryBounded,
    /// E5 carriers decoded, but the reference graph did not close.
    TopologyE5GraphUnclosed,
    /// Complete B5 topology transfers under an inferred face-orientation and body-kind gauge.
    TopologyB5GaugeSubstituted,
    /// Object-stream graph exceeded the bounded work slice.
    TopologyObjectStreamWorkSliceExhausted,
    /// Object-stream and NURBS carriers decoded, but the B5 graph did not close.
    TopologyB5GraphUnclosed,
    /// Fitted face subsets represent only part of a native body.
    TopologyOwnedPatchSubset,
    /// Unselected native body rosters stay outside the neutral bounded subset.
    TopologyUnselectedBodiesRetained,
    /// Visible body references lack one complete allocation-scope resolution.
    TopologyBodySelectionUnresolved,
    /// Non-rolling-ball face sense uses inferred roster and chart parity.
    TopologyOwnedPatchSenseInferred,
    /// An endpoint station admits both first-scalar and final-scalar tag readings.
    TopologyEndpointStationReadingInferred,
    /// Disagreeing native shared boundaries were reconciled for sheet transfer.
    TopologySharedBoundaryReconciled,
    /// Two-edge pcurve binding and face sense use inferred relations.
    TopologyTwoEdgeBindingInferred,
    /// A bounded sheet search skipped later candidates.
    TopologySheetPatchSearchBounded,
    /// A B5 face's carrier sense or loop orientation withheld the topology plan.
    TopologyB5FacesWithheld,
    /// B5 topology runs were read without the isolated geometry they reference.
    TopologyB5PopulationBounded,
    /// Zero-entity support runs retain face-local occurrences without closed topology.
    TopologyZeroEntitySupportsRetained,
    /// The local source-bound endpoint contributor search reached its comparison limit.
    TopologyZeroEntityCandidatesBounded,
    /// Zero-entity topology transferred under a derived or source-bound gauge.
    TopologyZeroEntityGaugeSubstituted,
    /// Zero-entity loop members bind supports, but no neutral topology transferred.
    TopologyZeroEntityNotTransferred,
    /// Zero-entity wire loops transferred; face topology remains unresolved.
    TopologyZeroEntityFaceUnresolved,
    /// Outer declarations do not select one physically contained object graph.
    HistoryModelingScopeUnresolved,
    /// Modeling-scope object-graph field records remain unresolved.
    HistoryObjectRecordsUnresolved,
    /// Legacy design runs retain unresolved selector, relation, and feature semantics.
    HistoryLegacyRunsUnresolved,
    /// Configuration-row links kept no intervening entities at their allowance.
    HistoryConfigurationRowOrderBounded,
    /// Relations kept no parameter dependencies at their allowance.
    HistoryRelationDependenciesBounded,
    /// Typed two-definition value chains stay native without a neutral parameter.
    HistoryDefinitionChainsRetained,
    /// Design parameters and `Range` nominals read stored `E7` and `E8` literals
    /// as the values one and zero.
    HistoryParameterLiteralAssumed,
    /// Materials, unbound NURBS caches, and document metadata were not transferred.
    AttributesMaterialsMetadataNotTransferred,
    /// Dimension scalars retain no admitted physical-quantity discriminator.
    AttributesDimensionQuantityUnresolved,
    /// Visualization value blocks lack a proven typed face or body target.
    AttributesVisualizationUnbound,
}

impl CatiaLossCode {
    /// Every code, in declaration order.
    #[cfg(test)]
    const ALL: &'static [CatiaLossCode] = &[
        Self::SourceDialectUnverified,
        Self::SourceRouteFellThrough,
        Self::SourceAnnotationCollision,
        Self::SourceCatalogScanBounded,
        Self::GeometryCarrierSummary,
        Self::GeometryRollingSheetExtended,
        Self::TopologyAffineVertexReconciled,
        Self::GeometryParameterMapAccuracyInferred,
        Self::GeometryPlanePcurveProjected,
        Self::GeometryConicBranchBoundsInferred,
        Self::GeometrySheetSurfaceFitted,
        Self::GeometryRollingBallRailsAdjusted,
        Self::GeometryUnresolvedCarriers,
        Self::GeometryBrepNotTransferred,
        Self::GeometryPlaneParametersInvalid,
        Self::GeometryAnalyticPayloadInvalid,
        Self::GeometryParameterRangeInvalid,
        Self::GeometryPcurveRechartNonFinite,
        Self::GeometryVertexToleranceWidened,
        Self::GeometryFaceLocalFreeformNotTransferred,
        Self::GeometryRevolutionProfileUnbound,
        Self::GeometryLineProfileNotTransferred,
        Self::TopologyBoundaryGraphNotEmitted,
        Self::TopologyFbbRowsWithheld,
        Self::TopologyGraphNotBuilt,
        Self::TopologySheetComponentsInferred,
        Self::TopologyStandardSearchBounded,
        Self::TopologyPlanarBoundaryBounded,
        Self::TopologyE5GraphUnclosed,
        Self::TopologyB5GaugeSubstituted,
        Self::TopologyObjectStreamWorkSliceExhausted,
        Self::TopologyB5GraphUnclosed,
        Self::TopologyOwnedPatchSubset,
        Self::TopologyUnselectedBodiesRetained,
        Self::TopologyBodySelectionUnresolved,
        Self::TopologyOwnedPatchSenseInferred,
        Self::TopologyEndpointStationReadingInferred,
        Self::TopologySharedBoundaryReconciled,
        Self::TopologyTwoEdgeBindingInferred,
        Self::TopologySheetPatchSearchBounded,
        Self::TopologyB5FacesWithheld,
        Self::TopologyB5PopulationBounded,
        Self::TopologyZeroEntitySupportsRetained,
        Self::TopologyZeroEntityCandidatesBounded,
        Self::TopologyZeroEntityGaugeSubstituted,
        Self::TopologyZeroEntityNotTransferred,
        Self::TopologyZeroEntityFaceUnresolved,
        Self::HistoryModelingScopeUnresolved,
        Self::HistoryObjectRecordsUnresolved,
        Self::HistoryLegacyRunsUnresolved,
        Self::HistoryConfigurationRowOrderBounded,
        Self::HistoryRelationDependenciesBounded,
        Self::HistoryDefinitionChainsRetained,
        Self::HistoryParameterLiteralAssumed,
        Self::AttributesMaterialsMetadataNotTransferred,
        Self::AttributesDimensionQuantityUnresolved,
        Self::AttributesVisualizationUnbound,
    ];

    /// The stable string identifier. This is the gating contract.
    #[must_use]
    const fn code(self) -> &'static str {
        match self {
            Self::TopologyStandardSearchBounded => "topology.standard-search-bounded",
            Self::TopologyPlanarBoundaryBounded => "topology.planar-boundary-bounded",
            Self::SourceDialectUnverified => "source.dialect-unverified",
            Self::SourceRouteFellThrough => "source.route-fell-through",
            Self::SourceAnnotationCollision => "source.annotation-identity-collision",
            Self::SourceCatalogScanBounded => "source.catalog-scan-bounded",
            Self::GeometryCarrierSummary => "geometry.carrier-summary",
            Self::GeometryRollingSheetExtended => "geometry.rolling-sheet-extended",
            Self::TopologyAffineVertexReconciled => "topology.affine-vertex-reconciled",
            Self::GeometryConicBranchBoundsInferred => "geometry.conic-branch-bounds-inferred",
            Self::GeometryParameterMapAccuracyInferred => {
                "geometry.parameter-map-accuracy-inferred"
            }
            Self::GeometryPlanePcurveProjected => "geometry.plane-pcurve-projected",
            Self::GeometrySheetSurfaceFitted => "geometry.sheet-surface-fitted",
            Self::GeometryRollingBallRailsAdjusted => "geometry.rolling-ball-rails-adjusted",
            Self::GeometryUnresolvedCarriers => "geometry.unresolved-carriers",
            Self::GeometryBrepNotTransferred => "geometry.brep-not-transferred",
            Self::GeometryPlaneParametersInvalid => "geometry.plane-parameters-invalid",
            Self::GeometryAnalyticPayloadInvalid => "geometry.analytic-payload-invalid",
            Self::GeometryParameterRangeInvalid => "geometry.parameter-range-invalid",
            Self::GeometryPcurveRechartNonFinite => "geometry.pcurve-rechart-non-finite",
            Self::GeometryVertexToleranceWidened => "geometry.vertex-tolerance-widened",
            Self::GeometryFaceLocalFreeformNotTransferred => {
                "geometry.face-local-freeform-not-transferred"
            }
            Self::GeometryRevolutionProfileUnbound => "geometry.revolution-profile-unbound",
            Self::GeometryLineProfileNotTransferred => "geometry.line-profile-not-transferred",
            Self::TopologyBoundaryGraphNotEmitted => "topology.boundary-graph-not-emitted",
            Self::TopologyFbbRowsWithheld => "topology.fbb-rows-withheld",
            Self::TopologyGraphNotBuilt => "topology.graph-not-built",
            Self::TopologySheetComponentsInferred => "topology.sheet-components-inferred",
            Self::TopologyE5GraphUnclosed => "topology.e5-graph-unclosed",
            Self::TopologyB5GaugeSubstituted => "topology.b5-gauge-substituted",
            Self::TopologyObjectStreamWorkSliceExhausted => {
                "topology.object-stream-work-slice-exhausted"
            }
            Self::TopologyB5GraphUnclosed => "topology.b5-graph-unclosed",
            Self::TopologyOwnedPatchSubset => "topology.owned-patch-subset",
            Self::TopologyUnselectedBodiesRetained => "topology.unselected-bodies-retained",
            Self::TopologyBodySelectionUnresolved => "topology.body-selection-unresolved",
            Self::TopologyOwnedPatchSenseInferred => "topology.owned-patch-sense-inferred",
            Self::TopologyEndpointStationReadingInferred => {
                "topology.endpoint-station-reading-inferred"
            }
            Self::TopologySharedBoundaryReconciled => "topology.shared-boundary-reconciled",
            Self::TopologyTwoEdgeBindingInferred => "topology.two-edge-binding-inferred",
            Self::TopologySheetPatchSearchBounded => "topology.sheet-patch-search-bounded",
            Self::TopologyB5FacesWithheld => "topology.b5-faces-withheld",
            Self::TopologyB5PopulationBounded => "topology.b5-population-bounded",
            Self::TopologyZeroEntitySupportsRetained => "topology.zero-entity-supports-retained",
            Self::TopologyZeroEntityCandidatesBounded => "topology.zero-entity-candidates-bounded",
            Self::TopologyZeroEntityGaugeSubstituted => "topology.zero-entity-gauge-substituted",
            Self::TopologyZeroEntityNotTransferred => "topology.zero-entity-not-transferred",
            Self::TopologyZeroEntityFaceUnresolved => "topology.zero-entity-face-unresolved",
            Self::HistoryModelingScopeUnresolved => "history.modeling-scope-unresolved",
            Self::HistoryObjectRecordsUnresolved => "history.object-records-unresolved",
            Self::HistoryLegacyRunsUnresolved => "history.legacy-runs-unresolved",
            Self::HistoryConfigurationRowOrderBounded => "history.configuration-row-order-bounded",
            Self::HistoryRelationDependenciesBounded => "history.relation-dependencies-bounded",
            Self::HistoryDefinitionChainsRetained => "history.definition-chains-retained",
            Self::HistoryParameterLiteralAssumed => "history.parameter-literal-assumed",
            Self::AttributesMaterialsMetadataNotTransferred => {
                "attributes.materials-metadata-not-transferred"
            }
            Self::AttributesDimensionQuantityUnresolved => {
                "attributes.dimension-quantity-unresolved"
            }
            Self::AttributesVisualizationUnbound => "attributes.visualization-unbound",
        }
    }

    /// The severity of this loss.
    #[must_use]
    const fn severity(self) -> Severity {
        match self {
            Self::GeometryCarrierSummary => Severity::Info,
            Self::GeometryUnresolvedCarriers
            | Self::GeometryBrepNotTransferred
            | Self::TopologyBoundaryGraphNotEmitted
            | Self::TopologyFbbRowsWithheld
            | Self::TopologyGraphNotBuilt
            | Self::TopologyE5GraphUnclosed
            | Self::TopologyObjectStreamWorkSliceExhausted
            | Self::TopologyB5GraphUnclosed
            | Self::TopologyZeroEntityNotTransferred
            | Self::TopologyZeroEntityFaceUnresolved
            | Self::HistoryModelingScopeUnresolved
            | Self::HistoryObjectRecordsUnresolved
            | Self::HistoryLegacyRunsUnresolved => Severity::Blocking,
            _ => Severity::Warning,
        }
    }

    /// The shared cross-codec category this loss reports under.
    const fn shared_taxonomy(self) -> LossTaxonomy {
        match self {
            Self::SourceDialectUnverified => LossTaxonomy::SourceDialectUnverified,
            Self::SourceRouteFellThrough
            | Self::SourceAnnotationCollision
            | Self::SourceCatalogScanBounded
            | Self::GeometryVertexToleranceWidened
            | Self::TopologySheetComponentsInferred
            | Self::HistoryParameterLiteralAssumed => LossTaxonomy::DecodeDiagnostic,
            Self::GeometryCarrierSummary => LossTaxonomy::CarrierSummary,
            Self::GeometryRollingSheetExtended
            | Self::GeometryParameterMapAccuracyInferred
            | Self::GeometryPlanePcurveProjected
            | Self::GeometryConicBranchBoundsInferred
            | Self::GeometrySheetSurfaceFitted
            | Self::GeometryRollingBallRailsAdjusted => LossTaxonomy::GeometryAgreementSampled,
            Self::GeometryUnresolvedCarriers
            | Self::GeometryBrepNotTransferred
            | Self::GeometryPlaneParametersInvalid
            | Self::GeometryAnalyticPayloadInvalid
            | Self::GeometryParameterRangeInvalid
            | Self::GeometryPcurveRechartNonFinite
            | Self::GeometryFaceLocalFreeformNotTransferred
            | Self::GeometryRevolutionProfileUnbound
            | Self::GeometryLineProfileNotTransferred => LossTaxonomy::GeometryNotTransferred,
            Self::TopologyStandardSearchBounded
            | Self::TopologyPlanarBoundaryBounded
            | Self::TopologyBoundaryGraphNotEmitted
            | Self::TopologyFbbRowsWithheld
            | Self::TopologyGraphNotBuilt
            | Self::TopologyE5GraphUnclosed
            | Self::TopologyB5GaugeSubstituted
            | Self::TopologyObjectStreamWorkSliceExhausted
            | Self::TopologyB5GraphUnclosed
            | Self::TopologyOwnedPatchSubset
            | Self::TopologyBodySelectionUnresolved
            | Self::TopologySheetPatchSearchBounded
            | Self::TopologyB5FacesWithheld
            | Self::TopologyB5PopulationBounded
            | Self::TopologyZeroEntityCandidatesBounded
            | Self::TopologyZeroEntitySupportsRetained
            | Self::TopologyZeroEntityNotTransferred
            | Self::TopologyZeroEntityFaceUnresolved => LossTaxonomy::TopologyNotTransferred,
            Self::TopologyZeroEntityGaugeSubstituted
            | Self::TopologyAffineVertexReconciled
            | Self::TopologyOwnedPatchSenseInferred
            | Self::TopologyEndpointStationReadingInferred
            | Self::TopologySharedBoundaryReconciled
            | Self::TopologyTwoEdgeBindingInferred => LossTaxonomy::TopologyGaugeSubstituted,
            Self::AttributesMaterialsMetadataNotTransferred
            | Self::AttributesDimensionQuantityUnresolved
            | Self::AttributesVisualizationUnbound => LossTaxonomy::AttributesNotTransferred,
            Self::HistoryModelingScopeUnresolved
            | Self::HistoryObjectRecordsUnresolved
            | Self::HistoryLegacyRunsUnresolved
            | Self::HistoryConfigurationRowOrderBounded
            | Self::HistoryRelationDependenciesBounded
            | Self::HistoryDefinitionChainsRetained => LossTaxonomy::FeatureHistoryRetained,
            Self::TopologyUnselectedBodiesRetained => LossTaxonomy::FeatureHistoryRetained,
        }
    }

    /// Namespaced [`LossKind`] for this local code, classified by taxonomy.
    #[must_use]
    pub(crate) fn kind(self) -> LossKind {
        LossKind::namespaced(
            const {
                match cadmpeg_ir::report::loss::LossNamespace::new("catia") {
                    Ok(namespace) => namespace,
                    Err(_) => panic!("reserved codec namespace"),
                }
            },
            self.code(),
            self.shared_taxonomy(),
        )
    }

    /// Build a [`LossNote`] for this code with the given per-instance message.
    ///
    /// The structured code is `catia/<local>`. Severity comes from the local
    /// code; the strict floor comes from the taxonomy.
    #[must_use]
    pub(crate) fn note(self, message: impl Into<String>) -> LossNote {
        LossNote::new(self.kind(), message).with_severity(self.severity())
    }
}

#[cfg(test)]
mod tests {
    use super::CatiaLossCode;
    use std::collections::BTreeSet;

    /// Value-level golden: the stable string form of every code, pinned.
    #[test]
    fn code_strings_are_pinned() {
        let codes: Vec<&str> = CatiaLossCode::ALL.iter().map(|c| c.code()).collect();
        assert_eq!(
            codes,
            [
                "source.dialect-unverified",
                "source.route-fell-through",
                "source.annotation-identity-collision",
                "source.catalog-scan-bounded",
                "geometry.carrier-summary",
                "geometry.rolling-sheet-extended",
                "topology.affine-vertex-reconciled",
                "geometry.parameter-map-accuracy-inferred",
                "geometry.plane-pcurve-projected",
                "geometry.conic-branch-bounds-inferred",
                "geometry.sheet-surface-fitted",
                "geometry.rolling-ball-rails-adjusted",
                "geometry.unresolved-carriers",
                "geometry.brep-not-transferred",
                "geometry.plane-parameters-invalid",
                "geometry.analytic-payload-invalid",
                "geometry.parameter-range-invalid",
                "geometry.pcurve-rechart-non-finite",
                "geometry.vertex-tolerance-widened",
                "geometry.face-local-freeform-not-transferred",
                "geometry.revolution-profile-unbound",
                "geometry.line-profile-not-transferred",
                "topology.boundary-graph-not-emitted",
                "topology.fbb-rows-withheld",
                "topology.graph-not-built",
                "topology.sheet-components-inferred",
                "topology.standard-search-bounded",
                "topology.planar-boundary-bounded",
                "topology.e5-graph-unclosed",
                "topology.b5-gauge-substituted",
                "topology.object-stream-work-slice-exhausted",
                "topology.b5-graph-unclosed",
                "topology.owned-patch-subset",
                "topology.unselected-bodies-retained",
                "topology.body-selection-unresolved",
                "topology.owned-patch-sense-inferred",
                "topology.endpoint-station-reading-inferred",
                "topology.shared-boundary-reconciled",
                "topology.two-edge-binding-inferred",
                "topology.sheet-patch-search-bounded",
                "topology.b5-faces-withheld",
                "topology.b5-population-bounded",
                "topology.zero-entity-supports-retained",
                "topology.zero-entity-candidates-bounded",
                "topology.zero-entity-gauge-substituted",
                "topology.zero-entity-not-transferred",
                "topology.zero-entity-face-unresolved",
                "history.modeling-scope-unresolved",
                "history.object-records-unresolved",
                "history.legacy-runs-unresolved",
                "history.configuration-row-order-bounded",
                "history.relation-dependencies-bounded",
                "history.definition-chains-retained",
                "history.parameter-literal-assumed",
                "attributes.materials-metadata-not-transferred",
                "attributes.dimension-quantity-unresolved",
                "attributes.visualization-unbound",
            ]
        );
    }

    /// Codes are unique and use the stable `family.detail` kebab shape.
    #[test]
    fn codes_are_unique_and_well_formed() {
        let mut seen = BTreeSet::new();
        for code in CatiaLossCode::ALL {
            let text = code.code();
            assert!(seen.insert(text), "duplicate code {text}");
            let (family, detail) = text.split_once('.').expect("family.detail shape");
            assert!(!family.is_empty() && !detail.is_empty());
            assert!(
                text.bytes().all(|b| b.is_ascii_lowercase()
                    || b.is_ascii_digit()
                    || b == b'.'
                    || b == b'-'),
                "code {text} is not lowercase kebab"
            );
        }
    }

    /// The note builder fixes severity from the codec-specific code.
    #[test]
    fn note_takes_severity_from_the_code() {
        for code in CatiaLossCode::ALL {
            let note = code.note("x");
            assert_eq!(note.severity, code.severity());
            assert_eq!(note.message, "x");
            assert!(note.provenance.is_none());
        }
    }
}
