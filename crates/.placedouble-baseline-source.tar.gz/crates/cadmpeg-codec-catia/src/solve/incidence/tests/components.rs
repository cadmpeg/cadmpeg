use crate::solve::incidence::compact_boundary_domain_viable;
use crate::solve::mesh_quotient::AssignmentOrder;
use crate::solve::mesh_quotient::MeshPartialEndpointConstraint;
use crate::solve::mesh_quotient::MeshQuotient;
use crate::solve::mesh_quotient::MAX_MESH_CONSTRAINT_OPERATIONS;
use crate::solve::missing_edge::MeshBoundaryEdgeCandidate;
use crate::solve::missing_edge::MeshFaceBoundaryAssignment;
use crate::solve::missing_edge::MeshFaceBoundaryDomain;
use crate::solve::tests::repeated_domain;
use cadmpeg_core::decode::WorkBudget;
use std::collections::HashSet;
use std::sync::Arc;

#[test]
fn incidence_components_join_only_through_shared_face_vertices() {
    let choices = vec![
        vec![[0, 1], [0, 2]],
        vec![[1, 3], [2, 3]],
        vec![[4, 5], [4, 6]],
        vec![[7, 8]],
    ];
    let edge_faces = [[0, 0], [0, 0], [0, 0], [0, 0]];
    assert_eq!(
        crate::solve::incidence::incidence_choice_components(&choices, &edge_faces, None, None)
            .expect("compute the incidence choice components"),
        vec![vec![0, 1], vec![2]]
    );
}

#[test]
fn incidence_component_preflight_ignores_disjoint_unassigned_cycles_on_the_same_face() {
    catia_test_context!(ctx);
    let choices = vec![vec![[0, 0], [1, 1]], vec![[2, 2], [3, 3]]];
    let edge_faces = [[0, 0], [0, 0]];

    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &choices,
        &edge_faces,
        1,
        4,
        None,
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("independent same-face cycle solutions");

    assert_eq!(solutions.len(), 4);
}

#[test]
fn incidence_component_composition_does_not_allocate_the_declared_point_product() {
    catia_test_context!(ctx);
    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &[vec![[usize::MAX - 1, usize::MAX - 1]]],
        &[[0, 0]],
        1,
        usize::MAX,
        None,
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("sparse component degree state");

    assert_eq!(solutions, vec![vec![[usize::MAX - 1, usize::MAX - 1]]]);
}

#[test]
fn incidence_component_preflight_retains_fixed_chain_frontiers() {
    catia_test_context!(ctx);
    let choices = vec![
        vec![[0, 1], [0, 2]],
        vec![[1, 3]],
        vec![[3, 4], [3, 5]],
        vec![[4, 0]],
    ];
    let edge_faces = [[0, 0]; 4];

    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &choices,
        &edge_faces,
        1,
        6,
        None,
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("fixed-chain component frontier");

    assert_eq!(solutions, vec![vec![[0, 1], [1, 3], [3, 4], [4, 0]]]);
}

#[test]
fn partial_incidence_constraint_joins_every_component_it_can_couple() {
    let components = vec![vec![0, 2], vec![1], vec![3, 5], vec![4]];
    let active = [true, false, false, true, false, false];

    assert_eq!(
        crate::solve::incidence::join_incidence_components_by_coupling(components, &active)
            .expect("join incidence components by coupling"),
        vec![vec![0, 2, 3, 5], vec![1], vec![4]],
    );
}

#[test]
fn incidence_components_order_by_endpoint_branch_width() {
    let choices = vec![
        vec![[0, 0], [1, 1]],
        vec![[2, 2], [3, 3], [4, 4]],
        vec![[5, 5], [6, 6]],
        vec![[7, 7]],
    ];
    let mut components = vec![vec![0, 2], vec![1], vec![3]];

    crate::solve::incidence::order_incidence_components_by_branch_width(&mut components, &choices)
        .expect("valid component edges");

    assert_eq!(components, vec![vec![3], vec![1], vec![0, 2]]);
}

#[test]
fn incidence_components_order_prerequisites_without_joining_domains() {
    catia_test_context!(ctx);
    let choices = vec![vec![[0, 0], [1, 1]], vec![[2, 2], [3, 3]], vec![[4, 4]]];
    let mut components = vec![vec![0], vec![1], vec![2]];
    let dependencies = [Vec::new(), vec![0], Vec::new()];

    crate::solve::incidence::order_incidence_components_by_constraints(
        &ctx,
        &mut components,
        &choices,
        AssignmentOrder::new(None, Some(&dependencies)),
    )
    .expect("order incidence components by constraints")
    .expect("acyclic component prerequisites");

    assert_eq!(components, vec![vec![2], vec![0], vec![1]]);
}

#[test]
fn incidence_components_reject_prerequisite_cycles() {
    catia_test_context!(ctx);
    let choices = vec![vec![[0, 0]], vec![[1, 1]]];
    let mut components = vec![vec![0], vec![1]];
    let predecessors = [Some(1), Some(0)];

    assert!(
        crate::solve::incidence::order_incidence_components_by_constraints(
            &ctx,
            &mut components,
            &choices,
            AssignmentOrder::new(Some(&predecessors), None),
        )
        .expect("order incidence components by constraints")
        .is_none()
    );

    let mut component = vec![vec![0, 1]];
    assert!(
        crate::solve::incidence::order_incidence_components_by_constraints(
            &ctx,
            &mut component,
            &choices,
            AssignmentOrder::new(Some(&predecessors), None),
        )
        .expect("order incidence components by constraints")
        .is_none()
    );
}

#[test]
fn incidence_components_keep_fixed_face_boundaries_independent() {
    let choices = vec![
        vec![[0, 1], [0, 2]],
        vec![[1, 2], [1, 3]],
        vec![[4, 5], [4, 6]],
        vec![[5, 6], [5, 7]],
    ];
    let edge_faces = [[0, 0]; 4];
    let use_ = |edge| MeshBoundaryEdgeCandidate {
        edge,
        start: 0,
        end: 1,
        reversed: None,
    };
    let fixed = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![use_(0), use_(1)], vec![use_(2), use_(3)]],
        },
    ])];
    assert_eq!(
        crate::solve::incidence::incidence_choice_components(
            &choices,
            &edge_faces,
            Some(&fixed),
            None
        )
        .expect("compute the incidence choice components"),
        vec![vec![0, 1], vec![2, 3]]
    );

    let alternatives = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![use_(0), use_(1)], vec![use_(2), use_(3)]],
        },
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![use_(0), use_(2)], vec![use_(1), use_(3)]],
        },
    ])];
    assert_eq!(
        crate::solve::incidence::incidence_choice_components(
            &choices,
            &edge_faces,
            Some(&alternatives),
            None
        )
        .expect("compute the incidence choice components"),
        vec![vec![0, 1, 2, 3]]
    );
}

#[test]
fn incidence_components_include_overlapping_quotient_domains() {
    let choices = vec![
        vec![[0, 1], [0, 2]],
        vec![[3, 4], [3, 5]],
        vec![[6, 7], [6, 8]],
    ];
    let edge_faces = [[0, 0], [1, 1], [2, 2]];
    let quotient = MeshQuotient::new(
        [
            HashSet::from([0, 1]),
            HashSet::from([0, 2]),
            HashSet::from([1, 3]),
            HashSet::from([3, 4]),
            HashSet::from([6, 7]),
            HashSet::from([6, 8]),
        ]
        .map(Arc::new)
        .to_vec(),
    );

    assert_eq!(
        crate::solve::incidence::incidence_choice_components(
            &choices,
            &edge_faces,
            None,
            Some(&quotient)
        )
        .expect("compute the incidence choice components"),
        vec![vec![0, 1], vec![2]]
    );
}

#[test]
fn incidence_components_solve_coupled_face_vertex_closures() {
    catia_test_context!(ctx);
    let a = vec![[0, 2], [0, 12], [2, 12]];
    let b = vec![[1, 3], [1, 1969], [3, 1969]];
    let c = vec![
        [0, 1],
        [0, 2],
        [0, 3],
        [0, 12],
        [0, 1969],
        [1, 2],
        [1, 3],
        [1, 12],
        [1, 1969],
        [2, 3],
        [2, 12],
        [2, 1969],
        [3, 12],
        [3, 1969],
        [12, 1969],
    ];
    let choices = vec![
        a.clone(),
        b.clone(),
        a,
        b,
        c,
        vec![[2, 3]],
        vec![[2, 12]],
        vec![[12, 1969]],
        vec![[3, 1969]],
    ];
    let edge_faces = [
        [1, 0],
        [3, 0],
        [2, 1],
        [2, 3],
        [2, 0],
        [0, 0],
        [1, 1],
        [2, 2],
        [3, 3],
    ];
    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &choices,
        &edge_faces,
        4,
        1970,
        None,
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("component closure solution");
    assert!(solutions
        .iter()
        .any(|solution| { solution[..5] == [[0, 2], [1, 3], [0, 12], [1, 1969], [0, 1]] }));
}

#[test]
fn incidence_components_reject_degree_cycles_in_the_wrong_edge_order() {
    catia_test_context!(ctx);
    let choices = vec![
        vec![[0, 1]],
        vec![[1, 2], [2, 3]],
        vec![[2, 3], [1, 2]],
        vec![[3, 0]],
    ];
    let edge_faces = [[0, 0]; 4];
    let mesh_assignments = vec![MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![(0..4)
                .map(|edge| MeshBoundaryEdgeCandidate {
                    edge,
                    start: 0,
                    end: 0,
                    reversed: None,
                })
                .collect()],
        },
    ])];

    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &choices,
        &edge_faces,
        1,
        4,
        Some(&mesh_assignments),
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("ordered component solution");

    assert_eq!(solutions.len(), 1);
    assert_eq!(solutions[0], [[0, 1], [1, 2], [2, 3], [3, 0]]);
}

#[test]
fn incidence_unordered_full_cycle_rejects_disconnected_degree_cycles() {
    catia_test_context!(ctx);
    let choices = vec![
        vec![[0, 1]],
        vec![[0, 1], [1, 2]],
        vec![[2, 3]],
        vec![[2, 3], [0, 3]],
    ];
    let edge_faces = [[0, 0]; 4];
    let domains = vec![MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2, 3])];

    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &choices,
        &edge_faces,
        1,
        4,
        Some(&domains),
        None,
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("connected cycle solution");

    assert_eq!(solutions, vec![vec![[0, 1], [1, 2], [2, 3], [0, 3]]]);
}

#[test]
fn deferred_boundary_enforces_anchored_gap_capacities() {
    let domain = crate::solve::missing_edge::MeshDeferredFaceBoundary {
        cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
            length: 6,
            exact_uses: vec![
                (
                    MeshBoundaryEdgeCandidate {
                        edge: 0,
                        start: 0,
                        end: 1,
                        reversed: Some(false),
                    },
                    1,
                ),
                (
                    MeshBoundaryEdgeCandidate {
                        edge: 3,
                        start: 3,
                        end: 4,
                        reversed: Some(false),
                    },
                    1,
                ),
            ],
        }],
        missing_edges: vec![1, 2, 4, 5],
    };
    let valid = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [0, 5]];
    let overfilled_first_gap = [[0, 1], [1, 2], [2, 3], [4, 5], [3, 4], [0, 5]];

    assert!(
        crate::solve::incidence::deferred_boundary_closes(&domain, &valid)
            .expect("compute the deferred boundary closes")
    );
    let assignment = crate::solve::incidence::deferred_boundary_assignment(&domain, &valid)
        .expect("compute the deferred boundary assignment")
        .expect("assign the deferred boundary");
    assert_eq!(
        assignment.boundaries[0]
            .iter()
            .map(|use_| (use_.edge, use_.start, use_.end, use_.reversed))
            .collect::<Vec<_>>(),
        vec![
            (0, 0, 1, Some(false)),
            (1, 1, 2, None),
            (2, 2, 3, None),
            (3, 3, 4, Some(false)),
            (4, 4, 5, None),
            (5, 5, 0, None),
        ]
    );
    assert!(
        !crate::solve::incidence::deferred_boundary_closes(&domain, &overfilled_first_gap)
            .expect("compute the deferred boundary closes")
    );
}

#[test]
fn deferred_boundary_materialization_assigns_canonical_positive_spans() {
    let domain = crate::solve::missing_edge::MeshDeferredFaceBoundary {
        cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
            length: 4,
            exact_uses: Vec::new(),
        }],
        missing_edges: vec![0, 1],
    };
    let assignment =
        crate::solve::incidence::deferred_boundary_assignment(&domain, &[[0, 1], [0, 1]])
            .expect("compute the deferred boundary assignment")
            .expect("assign the deferred boundary");

    assert_eq!(
        assignment.boundaries[0]
            .iter()
            .map(|use_| (use_.edge, use_.start, use_.end))
            .collect::<Vec<_>>(),
        vec![(0, 0, 3), (1, 3, 0)]
    );
}

#[test]
fn deferred_anchored_runs_propagate_forced_adjacencies() {
    catia_test_context!(ctx);
    let use_ = |edge, start| MeshBoundaryEdgeCandidate {
        edge,
        start,
        end: (start + 1) % 2,
        reversed: Some(false),
    };
    let domains = [MeshFaceBoundaryDomain::DeferredValidation(
        crate::solve::missing_edge::MeshDeferredFaceBoundary {
            cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                length: 2,
                exact_uses: vec![(use_(0, 0), 1), (use_(1, 1), 1)],
            }],
            missing_edges: Vec::new(),
        },
    )];
    let candidates = vec![vec![[0, 1]], vec![[0, 1]]];
    let mut quotient =
        crate::solve::mesh_quotient::initial_mesh_quotient(&candidates, 2, &[[0, 1], [2, 3]])
            .expect("build the initial mesh quotient")
            .expect("initial quotient");
    let budget = WorkBudget::new(100);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("propagate common ordered face quotients")
    .expect("forced deferred quotient");

    assert_eq!(
        quotient.find(0).expect("find the component root"),
        quotient.find(3).expect("find the component root")
    );
    assert_eq!(
        quotient.find(1).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
}

#[test]
fn deferred_quotient_retains_unknown_exact_run_direction() {
    catia_test_context!(ctx);
    let use_ = |edge, start| MeshBoundaryEdgeCandidate {
        edge,
        start,
        end: (start + 1) % 2,
        reversed: None,
    };
    let domains = [MeshFaceBoundaryDomain::DeferredValidation(
        crate::solve::missing_edge::MeshDeferredFaceBoundary {
            cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                length: 2,
                exact_uses: vec![(use_(0, 0), 1), (use_(1, 1), 1)],
            }],
            missing_edges: Vec::new(),
        },
    )];
    let candidates = vec![vec![[0, 1]], vec![[0, 1]]];
    let mut quotient =
        crate::solve::mesh_quotient::initial_mesh_quotient(&candidates, 2, &[[0, 1], [2, 3]])
            .expect("build the initial mesh quotient")
            .expect("initial quotient");
    let budget = WorkBudget::new(100);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("propagate common ordered face quotients")
    .expect("unknown exact direction is deferred");

    assert_ne!(
        quotient.find(0).expect("find the component root"),
        quotient.find(3).expect("find the component root")
    );
}

#[test]
fn deferred_gap_search_propagates_quotient_forced_edge_order() {
    catia_test_context!(ctx);
    let use_ = |edge, start| MeshBoundaryEdgeCandidate {
        edge,
        start,
        end: (start + 1) % 4,
        reversed: Some(false),
    };
    let domains = [MeshFaceBoundaryDomain::DeferredValidation(
        crate::solve::missing_edge::MeshDeferredFaceBoundary {
            cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                length: 4,
                exact_uses: vec![(use_(0, 0), 1), (use_(1, 2), 1)],
            }],
            missing_edges: vec![2, 3],
        },
    )];
    let candidates = vec![vec![[0, 1]], vec![[2, 3]], vec![[1, 2]], vec![[0, 3]]];
    let mut quotient = MeshQuotient::new(
        (0..8)
            .map(|node| Arc::new(HashSet::from([[0, 1, 2, 3, 1, 2, 3, 0][node]])))
            .collect(),
    );
    let budget = WorkBudget::new(10_000);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("propagate common ordered face quotients")
    .expect("deferred gap quotient");

    assert_eq!(
        quotient.find(1).expect("find the component root"),
        quotient.find(4).expect("find the component root")
    );
    assert_eq!(
        quotient.find(5).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
    assert_eq!(
        quotient.find(3).expect("find the component root"),
        quotient.find(6).expect("find the component root")
    );
    assert_eq!(
        quotient.find(7).expect("find the component root"),
        quotient.find(0).expect("find the component root")
    );
}

#[test]
fn ordered_structural_equations_propagate_without_direction_enumeration() {
    catia_test_context!(ctx);
    let domains = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![
                MeshBoundaryEdgeCandidate {
                    edge: 0,
                    start: 0,
                    end: 0,
                    reversed: None,
                },
                MeshBoundaryEdgeCandidate {
                    edge: 1,
                    start: 0,
                    end: 0,
                    reversed: None,
                },
            ]],
        },
    ])];
    let candidates = vec![vec![[0, 0]], vec![[0, 0]]];
    let mut quotient = MeshQuotient::new(repeated_domain(HashSet::from([0]), 4));
    quotient
        .merge(0, 1)
        .expect("merge the components")
        .expect("first closed edge");
    quotient
        .merge(2, 3)
        .expect("merge the components")
        .expect("second closed edge");
    let budget = WorkBudget::new(100);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("propagate common ordered face quotients")
    .expect("structural quotient");

    assert_eq!(
        quotient.find(0).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
}

#[test]
fn ordered_face_preparation_does_not_sign_whole_mesh_alternatives() {
    catia_test_context!(ctx);
    let use_ = |edge| MeshBoundaryEdgeCandidate {
        edge,
        start: 0,
        end: 0,
        reversed: Some(false),
    };
    let domains = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![use_(0)]],
        },
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![use_(1)]],
        },
    ])];
    let candidates = vec![Vec::new(), Vec::new()];
    let broad = Arc::new((0..100).collect::<HashSet<_>>());
    let mut quotient = MeshQuotient::new(vec![broad; 4]);
    let budget = WorkBudget::new(100);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("preparation does not enumerate whole-mesh alternatives")
    .expect("locally viable face domains");
    assert!(ctx.resource_refusal().is_none());

    assert_eq!(quotient.root_count().expect("count the component roots"), 4);
    assert!(!budget.exhausted());
}

#[test]
fn ordered_cycle_final_search_retains_domain_forced_directions() {
    catia_test_context!(ctx);
    let domains = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![
                MeshBoundaryEdgeCandidate {
                    edge: 0,
                    start: 0,
                    end: 0,
                    reversed: None,
                },
                MeshBoundaryEdgeCandidate {
                    edge: 1,
                    start: 0,
                    end: 0,
                    reversed: None,
                },
            ]],
        },
    ])];
    let candidates = vec![vec![[0, 1]], vec![[0, 1]]];
    let mut quotient = MeshQuotient::new(vec![
        Arc::new(HashSet::from([0])),
        Arc::new(HashSet::from([1])),
        Arc::new(HashSet::from([1])),
        Arc::new(HashSet::from([0])),
    ]);
    let budget = WorkBudget::new(100);

    crate::solve::mesh_quotient::propagate_common_ordered_face_quotients(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &budget,
    )
    .expect("propagate common ordered face quotients")
    .expect("supported cycle quotient");

    let solutions = crate::solve::incidence::component_incidence_pair_solutions(
        &ctx,
        &candidates,
        &[[0, 0]; 2],
        1,
        2,
        Some(&domains),
        Some(&quotient),
        None,
        &|_| Ok(true),
    )
    .expect("find the component incidence pair solutions")
    .expect("the final search retains the correlated cycle");
    assert_eq!(solutions, vec![vec![[0, 1], [0, 1]]]);
}

#[test]
fn ordered_components_retain_unknown_edges_in_the_abstract_quotient() {
    let domains = [MeshFaceBoundaryDomain::Ordered(vec![
        MeshFaceBoundaryAssignment {
            boundaries: vec![vec![
                MeshBoundaryEdgeCandidate {
                    edge: 0,
                    start: 0,
                    end: 0,
                    reversed: Some(false),
                },
                MeshBoundaryEdgeCandidate {
                    edge: 1,
                    start: 0,
                    end: 0,
                    reversed: Some(false),
                },
            ]],
        },
    ])];
    let candidates = vec![Vec::new(), Vec::new()];
    catia_test_context!(ctx);
    let mut quotient = MeshQuotient::new(repeated_domain(HashSet::from([0, 1]), 4));

    crate::solve::mesh_quotient::propagate_common_boundary_components(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &WorkBudget::new(MAX_MESH_CONSTRAINT_OPERATIONS),
    )
    .expect("propagate common boundary components")
    .expect("ordered component quotient");

    assert_eq!(
        quotient.find(0).expect("find the component root"),
        quotient.find(3).expect("find the component root")
    );
    assert_eq!(
        quotient.find(1).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
}

#[test]
fn unordered_components_close_cycles_in_the_abstract_quotient() {
    let domains = [MeshFaceBoundaryDomain::UnorderedFullCycle(vec![2, 0, 1])];
    let candidates = vec![Vec::new(); 3];
    catia_test_context!(ctx);
    let mut quotient = MeshQuotient::new(
        [0, 1, 1, 2, 2, 0]
            .into_iter()
            .map(|point| Arc::new(HashSet::from([point])))
            .collect(),
    );

    crate::solve::mesh_quotient::propagate_common_boundary_components(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &WorkBudget::new(MAX_MESH_CONSTRAINT_OPERATIONS),
    )
    .expect("propagate common boundary components")
    .expect("unordered component quotient");

    assert_eq!(
        quotient.find(1).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
    assert_eq!(
        quotient.find(3).expect("find the component root"),
        quotient.find(4).expect("find the component root")
    );
    assert_eq!(
        quotient.find(5).expect("find the component root"),
        quotient.find(0).expect("find the component root")
    );
}

#[test]
fn compact_unordered_boundary_rejects_partial_subtours() {
    let domain = MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2, 3, 4]);

    assert!(!compact_boundary_domain_viable(
        &domain,
        &[Some([0, 1]), Some([1, 2]), Some([2, 0]), None, None],
        None,
    )
    .expect("check that the compact boundary domain is viable"));
    assert!(compact_boundary_domain_viable(
        &domain,
        &[Some([0, 1]), Some([1, 2]), Some([2, 3]), None, None],
        None,
    )
    .expect("check that the compact boundary domain is viable"));
    assert!(compact_boundary_domain_viable(
        &domain,
        &[
            Some([0, 1]),
            Some([1, 2]),
            Some([2, 3]),
            Some([3, 4]),
            Some([4, 0]),
        ],
        None,
    )
    .expect("check that the compact boundary domain is viable"));
}

#[test]
fn compact_unordered_boundary_refuses_degree_overflow() {
    let domain = MeshFaceBoundaryDomain::UnorderedFullCycle((0..129).collect());
    let mut assignment = vec![Some([0, 0]); 128];
    assignment.push(None);
    assert!(!compact_boundary_domain_viable(&domain, &assignment, None)
        .expect("check that the compact boundary domain is viable"));
}

#[test]
fn unordered_component_enumeration_is_atomic_at_its_state_limit() {
    let quotient = MeshQuotient::new(repeated_domain(HashSet::from([0]), 16));
    let budget = WorkBudget::new(10_000);

    assert!(
        crate::solve::mesh_quotient::bounded_unordered_cycle_assignments(
            &(0..8).collect::<Vec<_>>(),
            &quotient,
            16,
            &budget,
        )
        .expect("compute the bounded unordered cycle assignments")
        .is_none()
    );
}

#[test]
fn deferred_components_select_gap_orders_in_the_abstract_quotient() {
    let use_ = |edge, start| MeshBoundaryEdgeCandidate {
        edge,
        start,
        end: (start + 1) % 4,
        reversed: Some(false),
    };
    let domains = [MeshFaceBoundaryDomain::DeferredValidation(
        crate::solve::missing_edge::MeshDeferredFaceBoundary {
            cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                length: 4,
                exact_uses: vec![(use_(0, 0), 1), (use_(1, 2), 1)],
            }],
            missing_edges: vec![2, 3],
        },
    )];
    let candidates = vec![Vec::new(); 4];
    catia_test_context!(ctx);
    let mut quotient = MeshQuotient::new(
        (0..8)
            .map(|node| Arc::new(HashSet::from([[0, 1, 2, 3, 1, 2, 3, 0][node]])))
            .collect(),
    );

    crate::solve::mesh_quotient::propagate_common_boundary_components(
        &ctx,
        &domains,
        &candidates,
        &mut quotient,
        &WorkBudget::new(MAX_MESH_CONSTRAINT_OPERATIONS),
    )
    .expect("propagate common boundary components")
    .expect("deferred component quotient");

    assert_eq!(
        quotient.find(1).expect("find the component root"),
        quotient.find(4).expect("find the component root")
    );
    assert_eq!(
        quotient.find(5).expect("find the component root"),
        quotient.find(2).expect("find the component root")
    );
    assert_eq!(
        quotient.find(3).expect("find the component root"),
        quotient.find(6).expect("find the component root")
    );
    assert_eq!(
        quotient.find(7).expect("find the component root"),
        quotient.find(0).expect("find the component root")
    );
}

#[test]
fn deferred_faces_share_one_endpoint_quotient() {
    catia_test_context!(ctx);
    let use_ = |edge, reversed| MeshBoundaryEdgeCandidate {
        edge,
        start: edge,
        end: (edge + 1) % 2,
        reversed: Some(reversed),
    };
    let domain = |second_reversed| {
        MeshFaceBoundaryDomain::DeferredValidation(
            crate::solve::missing_edge::MeshDeferredFaceBoundary {
                cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                    length: 2,
                    exact_uses: vec![(use_(0, false), 1), (use_(1, second_reversed), 1)],
                }],
                missing_edges: Vec::new(),
            },
        )
    };
    let choices = vec![vec![[0, 1]], vec![[0, 1]]];
    let quotient =
        crate::solve::mesh_quotient::initial_mesh_quotient(&choices, 2, &[[0, 1], [2, 3]])
            .expect("build the initial mesh quotient")
            .expect("initial quotient");
    let budget = WorkBudget::new(10_000);

    assert!(
        crate::solve::incidence::compact_boundary_domains_jointly_viable(
            &ctx,
            &[domain(false), domain(false)],
            &choices,
            &[Some([0, 1]), Some([0, 1])],
            None,
            &quotient,
            &budget,
        )
        .expect("check compact boundary domains jointly viable")
    );
    assert!(
        !crate::solve::incidence::compact_boundary_domains_jointly_viable(
            &ctx,
            &[domain(false), domain(true)],
            &choices,
            &[Some([0, 1]), Some([0, 1])],
            None,
            &quotient,
            &budget,
        )
        .expect("check compact boundary domains jointly viable")
    );
}

#[test]
fn compact_faces_share_one_physical_edge_direction_gauge() {
    catia_test_context!(ctx);
    let choices = vec![
        vec![[0, 1]],
        vec![[1, 2]],
        vec![[0, 2]],
        vec![[0, 3]],
        vec![[1, 3]],
    ];
    let assignment = choices
        .iter()
        .map(|choices| Some(choices[0]))
        .collect::<Vec<_>>();
    let domains = [
        MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2]),
        MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 3, 4]),
    ];
    let quotient = crate::solve::mesh_quotient::initial_mesh_quotient(
        &choices,
        4,
        &[[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]],
    )
    .expect("build the initial mesh quotient")
    .expect("initial quotient");
    let budget = WorkBudget::new(10_000);

    assert!(
        crate::solve::incidence::compact_boundary_domains_jointly_viable(
            &ctx,
            &domains,
            &choices,
            &assignment,
            None,
            &quotient,
            &budget,
        )
        .expect("check compact boundary domains jointly viable")
    );
}

#[test]
fn compact_face_quotient_states_accumulate_across_calls() {
    catia_test_context!(ctx);
    let use_ = |edge, reversed| MeshBoundaryEdgeCandidate {
        edge,
        start: edge,
        end: (edge + 1) % 2,
        reversed: Some(reversed),
    };
    let domain = |second_reversed| {
        MeshFaceBoundaryDomain::DeferredValidation(
            crate::solve::missing_edge::MeshDeferredFaceBoundary {
                cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
                    length: 2,
                    exact_uses: vec![(use_(0, false), 1), (use_(1, second_reversed), 1)],
                }],
                missing_edges: Vec::new(),
            },
        )
    };
    let choices = vec![vec![[0, 1]], vec![[0, 1]]];
    let assignment = [Some([0, 1]), Some([0, 1])];
    let quotient =
        crate::solve::mesh_quotient::initial_mesh_quotient(&choices, 2, &[[0, 1], [2, 3]])
            .expect("build the initial mesh quotient")
            .expect("initial quotient");
    let budget = WorkBudget::new(10_000);
    let first = domain(false);
    let conflicting = domain(true);
    let initial = vec![(quotient.clone(), HashSet::new())];

    let crate::solve::incidence::CompactBoundaryAdvanceOutcome::Complete(first_states) =
        crate::solve::incidence::advance_compact_boundary_domains(
            &ctx,
            [&first],
            &choices,
            &assignment,
            None,
            initial.clone(),
            &budget,
        )
        .expect("advance compact boundary domains")
    else {
        panic!("first face quotient");
    };
    assert!(matches!(
        crate::solve::incidence::advance_compact_boundary_domains(
            &ctx,
            [&conflicting],
            &choices,
            &assignment,
            None,
            initial,
            &budget,
        )
        .expect("advance compact boundary domains"),
        crate::solve::incidence::CompactBoundaryAdvanceOutcome::Complete(_)
    ));
    assert!(matches!(
        crate::solve::incidence::advance_compact_boundary_domains(
            &ctx,
            [&conflicting],
            &choices,
            &assignment,
            None,
            first_states,
            &budget,
        )
        .expect("advance compact boundary domains"),
        crate::solve::incidence::CompactBoundaryAdvanceOutcome::Rejected
    ));
}

#[test]
fn compact_face_quotient_state_cap_is_exhausted() {
    const EDGE_COUNT: usize = 14;
    let arena = cadmpeg_core::decode::DecodeArena::new();
    let policy = cadmpeg_core::decode::DecodePolicy::service();
    let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(&[], &arena, &policy)
        .expect("build the decode context");
    let choices = vec![Vec::new(); EDGE_COUNT];
    let quotient = MeshQuotient::new(
        (0..EDGE_COUNT * 2)
            .map(|node| {
                Arc::new(if node % 2 == 0 {
                    HashSet::from([0, 1])
                } else {
                    HashSet::from([1, 2])
                })
            })
            .collect(),
    );
    let boundary = (0..EDGE_COUNT)
        .map(|edge| MeshBoundaryEdgeCandidate {
            edge,
            start: 0,
            end: 0,
            reversed: None,
        })
        .collect();
    let domain = MeshFaceBoundaryDomain::Ordered(vec![MeshFaceBoundaryAssignment {
        boundaries: vec![boundary],
    }]);
    let assignment = (0..EDGE_COUNT).map(|_| Some([1, 1])).collect::<Vec<_>>();
    let budget = WorkBudget::new(MAX_MESH_CONSTRAINT_OPERATIONS);

    let outcome = crate::solve::incidence::advance_compact_boundary_domains(
        &ctx,
        [&domain],
        &choices,
        &assignment,
        None,
        vec![(quotient, HashSet::new())],
        &budget,
    )
    .expect("advance compact boundary domains");
    assert!(matches!(
        outcome,
        crate::solve::incidence::CompactBoundaryAdvanceOutcome::Exhausted
    ));
    assert!(!budget.exhausted());
}

mod component_search;

#[test]
fn independent_component_choices_yield_every_pair_solution() {
    let choices = vec![vec![[0, 0], [1, 1]], vec![[2, 2], [3, 3]]];
    let edge_faces = [[0, 0], [0, 0]];
    let run = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
        crate::solve::incidence::component_incidence_pair_solutions(
            ctx,
            &choices,
            &edge_faces,
            1,
            4,
            None,
            None,
            None,
            &|_| Ok(true),
        )
    };
    crate::test_support::with_service_context(|ctx| {
        assert_eq!(
            run(ctx)
                .expect("find the component incidence pair solutions")
                .expect("solutions")
                .len(),
            4
        );
    });
}

#[test]
fn incidence_components_order_a_single_prerequisite_chain() {
    let choices = vec![vec![[0, 0]], vec![[1, 1]]];
    let dependencies = [Vec::new(), vec![0]];
    let components = vec![vec![0], vec![1]];
    catia_test_context!(service_ctx);
    let mut service_components = components.clone();
    assert!(
        crate::solve::incidence::order_incidence_components_by_constraints(
            &service_ctx,
            &mut service_components,
            &choices,
            AssignmentOrder::new(None, Some(&dependencies)),
        )
        .expect("order incidence components by constraints")
        .is_some()
    );
}

#[test]
fn component_search_stops_at_the_first_visited_solution() {
    use std::ops::ControlFlow;

    let choices = vec![vec![[0, 0], [1, 1]], vec![[2, 2], [3, 3]]];
    let edge_faces = [[0, 0], [0, 0]];
    let outcome = crate::test_support::with_service_context(|ctx| {
        crate::solve::incidence::visit_component_incidence_pair_solutions(
            ctx,
            &choices,
            &edge_faces,
            1,
            4,
            None,
            None,
            None,
            &|_| Ok(true),
            &mut |_| Ok(ControlFlow::Break(())),
        )
    })
    .expect("visit component incidence pair solutions");
    assert!(matches!(
        outcome,
        crate::solve::incidence::IncidenceSolve::Solved(1)
    ));
}

#[test]
fn deferred_boundary_closes_a_four_cycle_over_two_missing_edges() {
    let domain = crate::solve::missing_edge::MeshDeferredFaceBoundary {
        cycles: vec![crate::solve::missing_edge::MeshDeferredBoundaryCycle {
            length: 4,
            exact_uses: Vec::new(),
        }],
        missing_edges: vec![0, 1],
    };
    let pairs = [[0, 1], [0, 1]];
    assert!(
        crate::solve::incidence::deferred_boundary_closes(&domain, &pairs)
            .expect("compute the deferred boundary closes")
    );
}

#[test]
fn compact_unordered_cycle_rejects_a_closed_triangle_subtour() {
    let domain = MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2, 3, 4]);
    let assignment = [Some([0, 1]), Some([1, 2]), Some([2, 0]), Some([3, 4]), None];
    assert!(!compact_boundary_domain_viable(&domain, &assignment, None)
        .expect("check that the compact boundary domain is viable"));
}

#[test]
fn compact_unordered_triangle_cycle_is_viable() {
    let domain = MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2]);
    let assignment = [Some([0, 1]), Some([1, 2]), Some([2, 0])];
    assert!(compact_boundary_domain_viable(&domain, &assignment, None)
        .expect("check that the compact boundary domain is viable"));
}

#[test]
fn component_face_closing_a_triangle_is_viable() {
    let faces = HashSet::from([0]);
    let assignment = [Some([0, 1]), Some([1, 2]), Some([2, 0])];
    let choices = vec![vec![[0, 1]], vec![[1, 2]], vec![[2, 0]]];
    let face_edges = vec![vec![0, 1, 2]];
    let domains = [MeshFaceBoundaryDomain::UnorderedFullCycle(vec![0, 1, 2])];
    catia_test_context!(service_ctx);
    assert!(crate::solve::incidence::component_incidence_faces_viable(
        &service_ctx,
        &faces,
        &assignment,
        &choices,
        &face_edges,
        Some(&domains),
        3,
    )
    .expect("check component incidence faces viable"));
}
