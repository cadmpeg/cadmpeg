// SPDX-License-Identifier: Apache-2.0
//! Framing and identity decode for outer `7C05` entity-table records.

use std::collections::HashSet;

use cadmpeg_core::decode::{DecodeContext, View};
use cadmpeg_core::CodecError;
use serde::{Deserialize, Serialize};

use crate::value_block;
use crate::wire::tokens::compact_atom;

/// One source-schema selector in a complete `7C06` definition prefix.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct DefinitionSchemaSelector {
    /// Stored zero-based source-schema ordinal following `0x32`.
    pub(crate) value: u32,
    /// Byte offset of `0x32` within the definition prefix.
    pub(crate) offset: usize,
}

/// One fully consumed nullable numeric-pair production in a nested `7C07` payload.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct NumericPair {
    /// Two one-byte compact atoms preceding the nested value frame.
    prefix_atoms: [u32; 2],
    /// Two source-ordered nullable scalar slots.
    pub(crate) slots: [NumericPairSlot; 2],
}

/// One slot in a complete [`NumericPair`].
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum NumericPairSlot {
    /// `0xE6` followed by the exact IEEE-754 binary64 bits.
    Binary64 {
        /// Stored little-endian binary64 bits.
        bits: u64,
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// `0xE8`: the value 0.0 with no payload.
    ZeroLiteral {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
}

/// Prefix atom of one complete schema-selected `Range` interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum RangeIntervalPrefix {
    /// One compact atom with its exact serialized width.
    Compact {
        /// Decoded compact-atom value.
        value: u32,
        /// Stored width, one or two bytes.
        width: u8,
    },
    /// Exact fixed-width `80 <word:u32le>` form.
    EscapedWord {
        /// Stored little-endian word.
        word: u32,
    },
}

/// One slot in a complete schema-selected `Range` interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum RangeIntervalSlot {
    /// `E6` followed by one finite IEEE-754 binary64 value.
    Binary64 {
        /// Exact stored bits.
        bits: u64,
        /// Byte offset of `E6` within the complete `7C07` payload.
        offset: usize,
    },
    /// `E8`: the value 0.0 with no payload.
    ZeroLiteral {
        /// Byte offset of `E8` within the complete `7C07` payload.
        offset: usize,
    },
}

impl RangeIntervalSlot {
    /// The slot's binary64 bits; `E8` is 0.0.
    pub(crate) fn bits(&self) -> u64 {
        match self {
            Self::Binary64 { bits, .. } => *bits,
            Self::ZeroLiteral { .. } => 0.0_f64.to_bits(),
        }
    }
}

/// Complete encoded value selected by a source-schema entry named `Range`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) struct RangeInterval {
    /// Atom preceding the fixed range type frame.
    pub(crate) prefix: RangeIntervalPrefix,
    /// Source-ordered lower and upper slots. An absent pair uses one of the
    /// no-slot productions.
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "deserialize_slots"
    )]
    pub(crate) slots: Option<[RangeIntervalSlot; 2]>,
}

/// One item in an embedded numeric value packet.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum NumericPacketItem {
    /// `0xE6` followed by the exact IEEE-754 binary64 bits.
    Binary64 {
        /// Stored little-endian binary64 bits.
        bits: u64,
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// `0xE7`: the value 1.0 with no payload.
    UnitLiteral {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// `0xE8`: the value 0.0 with no payload.
    ZeroLiteral {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// One zero-payload `0xE9` control marker.
    Control {
        /// Stored control code.
        code: u8,
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
}

/// Symbol in a reference-signature descriptor program.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum ReferenceSignatureSymbol {
    /// Symbol `E`.
    E,
    /// Symbol `S`.
    S,
    /// Symbol `T`.
    T,
}

/// Variable prefix form of a complete reference-signature packet.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum ReferenceSignaturePrefix {
    /// Compact atom `2`.
    #[default]
    Atom2,
    /// Compact atom `35`.
    Atom35,
}

/// One instruction in a complete reference-signature descriptor program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum ReferenceSignatureInstruction {
    /// One descriptor symbol: `E`, `S`, or `T`.
    Symbol {
        /// Decoded descriptor symbol.
        symbol: ReferenceSignatureSymbol,
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// One maximal decimal run.
    Decimal {
        /// Exact decimal digits.
        digits: String,
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// Opening parenthesis of a postfix call.
    OpenCall {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// Comma separating call arguments.
    Comma {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// Closing parenthesis of a postfix call.
    CloseCall {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
    /// Postfix hexadecimal selector `#<digit>`.
    Qualifier {
        /// Decoded selector nibble.
        selector: u8,
        /// Byte offset of `#` within the `7C07` payload.
        hash_offset: usize,
        /// Byte offset of the selector digit within the `7C07` payload.
        selector_offset: usize,
    },
    /// Infix difference operator.
    Difference {
        /// Byte offset within the `7C07` payload.
        offset: usize,
    },
}

/// One fully consumed reference-signature production in a nested `7C07` payload.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "ReferenceSignatureWire", into = "ReferenceSignatureWire")]
pub(crate) struct ReferenceSignature {
    references: ConsecutiveReferences,
    prefix: ReferenceSignaturePrefix,
    tokens: Vec<ReferenceSignatureToken>,
    signature_offset: usize,
    second_reference_offset: usize,
}

/// Consecutive fixed-width reference identities.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ConsecutiveReferences(u32);

impl ConsecutiveReferences {
    /// Consecutive references starting at the supplied identity.
    pub(crate) fn new(first: u32) -> Option<Self> {
        first.checked_add(1).map(|_| Self(first))
    }
    /// First reference identity.
    pub(crate) fn first(self) -> u32 {
        self.0
    }
    /// Second reference identity.
    pub(crate) fn second(self) -> u32 {
        self.0 + 1
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum ReferenceSignatureToken {
    Symbol(ReferenceSignatureSymbol),
    Decimal(String),
    OpenCall,
    Comma,
    CloseCall,
    Qualifier(u8),
    Difference,
}

impl From<ReferenceSignatureInstruction> for ReferenceSignatureToken {
    fn from(value: ReferenceSignatureInstruction) -> Self {
        match value {
            ReferenceSignatureInstruction::Symbol { symbol, .. } => Self::Symbol(symbol),
            ReferenceSignatureInstruction::Decimal { digits, .. } => Self::Decimal(digits),
            ReferenceSignatureInstruction::OpenCall { .. } => Self::OpenCall,
            ReferenceSignatureInstruction::Comma { .. } => Self::Comma,
            ReferenceSignatureInstruction::CloseCall { .. } => Self::CloseCall,
            ReferenceSignatureInstruction::Qualifier { selector, .. } => Self::Qualifier(selector),
            ReferenceSignatureInstruction::Difference { .. } => Self::Difference,
        }
    }
}

impl ReferenceSignatureToken {
    fn text(&self) -> String {
        match self {
            Self::Symbol(ReferenceSignatureSymbol::E) => "E".to_owned(),
            Self::Symbol(ReferenceSignatureSymbol::S) => "S".to_owned(),
            Self::Symbol(ReferenceSignatureSymbol::T) => "T".to_owned(),
            Self::Decimal(digits) => digits.clone(),
            Self::OpenCall => "(".to_owned(),
            Self::Comma => ",".to_owned(),
            Self::CloseCall => ")".to_owned(),
            Self::Qualifier(selector) => format!("#{selector:X}"),
            Self::Difference => "-".to_owned(),
        }
    }

    fn instruction(&self, offset: usize) -> ReferenceSignatureInstruction {
        match self {
            Self::Symbol(symbol) => ReferenceSignatureInstruction::Symbol {
                symbol: *symbol,
                offset,
            },
            Self::Decimal(digits) => ReferenceSignatureInstruction::Decimal {
                digits: digits.clone(),
                offset,
            },
            Self::OpenCall => ReferenceSignatureInstruction::OpenCall { offset },
            Self::Comma => ReferenceSignatureInstruction::Comma { offset },
            Self::CloseCall => ReferenceSignatureInstruction::CloseCall { offset },
            Self::Qualifier(selector) => ReferenceSignatureInstruction::Qualifier {
                selector: *selector,
                hash_offset: offset,
                selector_offset: offset + 1,
            },
            Self::Difference => ReferenceSignatureInstruction::Difference { offset },
        }
    }
}

impl ReferenceSignature {
    /// Consecutive reference identities.
    pub(crate) fn references(&self) -> ConsecutiveReferences {
        self.references
    }
    /// First reference identity.
    pub(crate) fn first_reference(&self) -> u32 {
        self.references.first()
    }
    /// Second reference identity.
    pub(crate) fn second_reference(&self) -> u32 {
        self.references.second()
    }
    /// Exact signature text.
    pub(crate) fn signature(&self) -> String {
        self.tokens
            .iter()
            .map(ReferenceSignatureToken::text)
            .collect()
    }
    /// Variable compact atom preceding the nested signature frame.
    pub(crate) fn prefix(&self) -> ReferenceSignaturePrefix {
        self.prefix
    }
    /// Offset of the first signature byte.
    #[cfg(test)]
    pub(crate) fn signature_offset(&self) -> usize {
        self.signature_offset
    }
    /// Byte offset of the second reference marker within the value payload.
    pub(crate) fn second_reference_offset(&self) -> usize {
        self.second_reference_offset
    }
    /// Source-ordered signature instructions.
    pub(crate) fn signature_program(&self) -> Vec<ReferenceSignatureInstruction> {
        let mut offset = self.signature_offset;
        self.tokens
            .iter()
            .map(|token| {
                let instruction = token.instruction(offset);
                offset += token.text().len();
                instruction
            })
            .collect()
    }

    /// Instruction and token counts without materializing the program.
    pub(crate) fn instruction_and_token_counts(&self) -> (usize, usize) {
        let qualifier_count = self
            .tokens
            .iter()
            .filter(|token| matches!(token, ReferenceSignatureToken::Qualifier(_)))
            .count();
        (self.tokens.len(), self.tokens.len() + qualifier_count)
    }
}

#[derive(Serialize, Deserialize)]
pub(crate) struct ReferenceSignatureWire {
    /// First fixed-width reference.
    first_reference: u32,
    /// Variable compact atom preceding the nested signature frame.
    #[serde(default)]
    prefix: ReferenceSignaturePrefix,
    /// Printable signature bytes between `0x81` and the first terminator.
    signature: String,
    /// Source-ordered instruction program spanning the complete signature.
    #[serde(default)]
    signature_program: Vec<ReferenceSignatureInstruction>,
    /// Byte offset of the first signature byte within the `7C07` payload.
    #[serde(default)]
    signature_offset: usize,
    /// Second fixed-width reference.
    second_reference: u32,
    /// Byte offset of the second reference marker within the `7C07` payload.
    #[serde(default)]
    second_reference_offset: usize,
}

impl From<ReferenceSignature> for ReferenceSignatureWire {
    fn from(value: ReferenceSignature) -> Self {
        Self {
            first_reference: value.first_reference(),
            second_reference: value.second_reference(),
            prefix: value.prefix(),
            signature: value.signature(),
            signature_program: value.signature_program(),
            signature_offset: value.signature_offset,
            second_reference_offset: value.second_reference_offset(),
        }
    }
}

impl TryFrom<ReferenceSignatureWire> for ReferenceSignature {
    type Error = &'static str;
    fn try_from(wire: ReferenceSignatureWire) -> Result<Self, Self::Error> {
        let references = ConsecutiveReferences::new(wire.first_reference)
            .ok_or("first_reference has no consecutive successor")?;
        if wire.second_reference != references.second() {
            return Err("second_reference must follow first_reference");
        }
        wire.signature_offset
            .checked_add(wire.signature.len())
            .ok_or("signature_offset overflows the signature extent")?;
        let program = reference_signature_program(&wire.signature, wire.signature_offset)
            .ok_or("signature is not a complete instruction program")?;
        if !reference_signature_has_one_outer_call(&program) {
            return Err("signature requires one outer call");
        }
        if wire.signature_program != program {
            return Err("signature_program disagrees with signature and signature_offset");
        }
        Ok(Self {
            references,
            prefix: wire.prefix,
            tokens: program
                .into_iter()
                .map(ReferenceSignatureToken::from)
                .collect(),
            signature_offset: wire.signature_offset,
            second_reference_offset: wire.second_reference_offset,
        })
    }
}

fn reference_signature_program(
    signature: &str,
    signature_offset: usize,
) -> Option<Vec<ReferenceSignatureInstruction>> {
    let bytes = signature.as_bytes();
    let mut program = Vec::new();
    let mut call_depth = 0_usize;
    let mut expects_operand = true;
    let mut at = 0;
    while at < bytes.len() {
        let start = at;
        let symbol = match bytes[start] {
            b'E' => ReferenceSignatureSymbol::E,
            b'S' => ReferenceSignatureSymbol::S,
            b'T' => ReferenceSignatureSymbol::T,
            byte if byte.is_ascii_digit() => {
                if !expects_operand {
                    return None;
                }
                at += 1;
                while bytes.get(at).is_some_and(u8::is_ascii_digit) {
                    at += 1;
                }
                program.push(ReferenceSignatureInstruction::Decimal {
                    digits: signature[start..at].to_owned(),
                    offset: signature_offset + start,
                });
                expects_operand = false;
                continue;
            }
            b'(' if !expects_operand => {
                program.push(ReferenceSignatureInstruction::OpenCall {
                    offset: signature_offset + start,
                });
                let next_depth = call_depth.checked_add(1)?;
                call_depth = next_depth;
                expects_operand = true;
                at += 1;
                continue;
            }
            b',' if call_depth != 0 && !expects_operand => {
                program.push(ReferenceSignatureInstruction::Comma {
                    offset: signature_offset + start,
                });
                expects_operand = true;
                at += 1;
                continue;
            }
            b')' if call_depth != 0 && !expects_operand => {
                program.push(ReferenceSignatureInstruction::CloseCall {
                    offset: signature_offset + start,
                });
                call_depth -= 1;
                expects_operand = false;
                at += 1;
                continue;
            }
            b'#' if !expects_operand => {
                let selector_offset = start.checked_add(1)?;
                let &selector_byte = bytes.get(selector_offset)?;
                let selector = match selector_byte {
                    byte @ b'0'..=b'9' => byte - b'0',
                    byte @ b'A'..=b'F' => byte - b'A' + 10,
                    _ => return None,
                };
                program.push(ReferenceSignatureInstruction::Qualifier {
                    selector,
                    hash_offset: signature_offset + start,
                    selector_offset: signature_offset + selector_offset,
                });
                at += 2;
                continue;
            }
            b'-' if !expects_operand => {
                program.push(ReferenceSignatureInstruction::Difference {
                    offset: signature_offset + start,
                });
                expects_operand = true;
                at += 1;
                continue;
            }
            _ => return None,
        };
        if !expects_operand {
            return None;
        }
        program.push(ReferenceSignatureInstruction::Symbol {
            symbol,
            offset: signature_offset + start,
        });
        expects_operand = false;
        at += 1;
    }
    (!expects_operand && call_depth == 0).then_some(program)
}

fn reference_signature_has_one_outer_call(program: &[ReferenceSignatureInstruction]) -> bool {
    if !matches!(
        program,
        [
            ReferenceSignatureInstruction::Decimal { digits, .. },
            ReferenceSignatureInstruction::OpenCall { .. },
            ..,
            ReferenceSignatureInstruction::CloseCall { .. }
        ] if digits == "2"
    ) {
        return false;
    }
    let mut depth = 0_usize;
    for (ordinal, instruction) in program.iter().enumerate().skip(1) {
        match instruction {
            ReferenceSignatureInstruction::OpenCall { .. } => depth += 1,
            ReferenceSignatureInstruction::CloseCall { .. } => {
                let Some(next) = depth.checked_sub(1) else {
                    return false;
                };
                depth = next;
                if depth == 0 && ordinal + 1 != program.len() {
                    return false;
                }
            }
            _ => {}
        }
    }
    depth == 0
}

/// One exact packet in a tokenized `7C07` value program.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub(crate) enum EntityValuePacket {
    /// `<compact_atom> <compact_atom> E8 <selector:u16le> 37 <atom> <atom>
    /// (<E6:f64>|<E7..E9>)+ FE+`.
    Numeric {
        /// Byte offset of the first prefix atom within the value payload.
        offset: usize,
        /// Two one-byte atoms preceding the packet opcode.
        prefix_atoms: [u32; 2],
        /// Stored little-endian numeric-packet selector.
        type_selector: u16,
        /// First one-byte atom after the `0x37` delimiter.
        layout_atom: u32,
        /// Second one-byte atom after the `0x37` delimiter.
        value_atom: u32,
        /// Tagged binary64 values and control markers in serialized order.
        items: Vec<NumericPacketItem>,
        /// Number of consecutive `0xFE` bytes closing the packet.
        terminator_count: usize,
    },
    /// `E8 <value-selector:u16le> 37 FE FE`.
    Compact {
        /// Byte offset of the `E8` opcode within the value payload.
        offset: usize,
        /// Stored little-endian value selector.
        value_selector: u16,
    },
    /// `E9 <type-selector:u16le> <layout:u8> 37 FE FE`.
    Layout {
        /// Byte offset of the opcode within the value payload.
        offset: usize,
        /// Stored little-endian type selector.
        type_selector: u16,
        /// Uninterpreted one-byte layout code.
        layout: u8,
        /// Byte offset of the layout code within the value payload.
        layout_offset: usize,
    },
    /// Exact `83 E9 C0 07 01 E1 E6 <f64le> 88 81{5} 82 E7 81 FE` packet.
    E9Scalar {
        /// Byte offset of the leading `83` atom within the value payload.
        offset: usize,
        /// Byte offset of the scalar's `E6` opcode within the value payload.
        scalar_offset: usize,
        /// Exact stored finite binary64 bits.
        bits: u64,
    },
}

impl EntityValuePacket {
    /// Complete byte range occupied by this packet within its value payload.
    pub(crate) fn byte_range(&self) -> Option<std::ops::Range<usize>> {
        match self {
            Self::Numeric {
                offset,
                items,
                terminator_count,
                ..
            } => {
                let item_end = match items.last()? {
                    NumericPacketItem::Binary64 { offset, .. } => offset.checked_add(9)?,
                    NumericPacketItem::UnitLiteral { offset }
                    | NumericPacketItem::ZeroLiteral { offset }
                    | NumericPacketItem::Control { offset, .. } => offset.checked_add(1)?,
                };
                Some(*offset..item_end.checked_add(*terminator_count)?)
            }
            Self::Compact { offset, .. } => Some(*offset..offset.checked_add(6)?),
            Self::Layout { offset, .. } => Some(*offset..offset.checked_add(7)?),
            Self::E9Scalar { offset, .. } => Some(*offset..offset.checked_add(25)?),
        }
    }
}

/// Decode every exact packet in source order from a `7C07` value payload.
#[must_use]
pub(crate) fn value_packets(
    payload: &[u8],
    fields: &[value_block::ValueField],
) -> Vec<EntityValuePacket> {
    let mut opcode_offsets = HashSet::new();
    let mut e8_opcode_offsets = HashSet::new();
    let mut marker_offsets = HashSet::new();
    let mut atom_offsets = HashSet::new();
    for field in fields {
        match field {
            value_block::ValueField::Opcode { code, offset } => {
                opcode_offsets.insert(*offset);
                if *code == 0xe8 {
                    e8_opcode_offsets.insert(*offset);
                }
            }
            value_block::ValueField::Marker { code: 0xe8, offset } => {
                marker_offsets.insert(*offset);
            }
            value_block::ValueField::Atom { offset, .. } => {
                atom_offsets.insert(*offset);
            }
            _ => {}
        }
    }
    let mut packets =
        numeric_value_packets(payload, &e8_opcode_offsets, &marker_offsets, &atom_offsets);
    packets.extend(e9_scalar_packets(payload, &opcode_offsets, &atom_offsets));
    for packet in (0..payload.len())
        .filter(|index| opcode_offsets.contains(index))
        .filter_map(|index| {
            if let Some([0xe9, _, _, layout, 0x37, 0xfe, 0xfe]) = payload.get(index..index + 7) {
                return Some(EntityValuePacket::Layout {
                    offset: index,
                    type_selector: View::u16_le_at(payload, index + 1)?,
                    layout: *layout,
                    layout_offset: index + 3,
                });
            }
            match payload.get(index..index + 6) {
                Some([0xe8, _, _, 0x37, 0xfe, 0xfe]) => Some(EntityValuePacket::Compact {
                    offset: index,
                    value_selector: View::u16_le_at(payload, index + 1)?,
                }),
                _ => None,
            }
        })
    {
        packets.push(packet);
    }
    packets.sort_by_key(|packet| match packet {
        EntityValuePacket::Numeric { offset, .. } => (*offset, 0u8),
        EntityValuePacket::E9Scalar { offset, .. } => (*offset, 1u8),
        EntityValuePacket::Compact { offset, .. } | EntityValuePacket::Layout { offset, .. } => {
            (*offset, 2u8)
        }
    });
    packets
}

fn e9_scalar_packets<'a>(
    payload: &'a [u8],
    opcode_offsets: &'a HashSet<usize>,
    atom_offsets: &'a HashSet<usize>,
) -> impl Iterator<Item = EntityValuePacket> + 'a {
    const PREFIX: [u8; 7] = [0x83, 0xe9, 0xc0, 0x07, 0x01, 0xe1, 0xe6];
    const TRAILER: [u8; 10] = [0x88, 0x81, 0x81, 0x81, 0x81, 0x81, 0x82, 0xe7, 0x81, 0xfe];

    (0..payload.len())
        .filter(|offset| {
            atom_offsets.contains(offset)
                && offset
                    .checked_add(1)
                    .is_some_and(|opcode| opcode_offsets.contains(&opcode))
        })
        .filter_map(|offset| {
            let scalar_offset = offset.checked_add(6)?;
            let scalar_end = scalar_offset.checked_add(9)?;
            let packet_end = offset.checked_add(25)?;
            (payload.get(offset..scalar_offset + 1) == Some(PREFIX.as_slice())
                && payload.get(scalar_end..packet_end) == Some(TRAILER.as_slice()))
            .then_some(())?;
            let bits = View::u64_le_at(payload, scalar_offset + 1)?;
            f64::from_bits(bits)
                .is_finite()
                .then_some(EntityValuePacket::E9Scalar {
                    offset,
                    scalar_offset,
                    bits,
                })
        })
}

fn numeric_value_packets(
    payload: &[u8],
    opcode_offsets: &HashSet<usize>,
    marker_offsets: &HashSet<usize>,
    atom_offsets: &HashSet<usize>,
) -> Vec<EntityValuePacket> {
    let mut candidates = Vec::new();
    for offset in (0..payload.len()).filter(|offset| {
        if !atom_offsets.contains(offset) {
            return false;
        }
        let Some((_, prefix1_offset)) = compact_atom(payload, *offset) else {
            return false;
        };
        if marker_offsets.contains(&prefix1_offset) {
            return true;
        }
        atom_offsets.contains(&prefix1_offset)
            && compact_atom(payload, prefix1_offset)
                .is_some_and(|(_, opcode_offset)| opcode_offsets.contains(&opcode_offset))
    }) {
        if let Some(candidate) = parse_numeric_value_packet(payload, offset) {
            candidates.push(candidate);
        }
    }
    // Candidates start at strictly increasing offsets and are non-empty, so a
    // candidate overlaps another exactly when an earlier one ends after its
    // start or the next one starts before its end.
    let mut isolated = Vec::new();
    let mut earlier_end = 0usize;
    for (index, (_, range)) in candidates.iter().enumerate() {
        let overlaps = earlier_end > range.start
            || candidates
                .get(index + 1)
                .is_some_and(|(_, next)| next.start < range.end);
        earlier_end = earlier_end.max(range.end);
        isolated.push(!overlaps);
    }
    candidates
        .into_iter()
        .zip(isolated)
        .filter_map(|((packet, _), isolated)| isolated.then_some(packet))
        .collect()
}

fn parse_numeric_value_packet(
    payload: &[u8],
    offset: usize,
) -> Option<(EntityValuePacket, std::ops::Range<usize>)> {
    let (prefix0, prefix1, selector, layout_atom, value_atom, mut at) = (|| {
        let (prefix0, at) = compact_atom(payload, offset)?;
        let (prefix1, at) = compact_atom(payload, at)?;
        (payload.get(at) == Some(&0xe8)).then_some(())?;
        let selector = View::u16_le_at(payload, at + 1)?;
        (payload.get(at + 3) == Some(&0x37)).then_some(())?;
        let (layout_atom, at) = one_byte_atom(payload, at + 4)?;
        let (value_atom, at) = one_byte_atom(payload, at)?;
        Some((prefix0, prefix1, selector, layout_atom, value_atom, at))
    })()?;
    let mut items = Vec::new();
    let mut binary64_count = 0usize;
    loop {
        let &code = payload.get(at)?;
        match code {
            0xe6 => {
                let end = at.checked_add(9)?;
                let bits = View::u64_le_at(payload, at + 1)?;
                items.push(NumericPacketItem::Binary64 { bits, offset: at });
                binary64_count += 1;
                at = end;
            }
            0xe7 => {
                items.push(NumericPacketItem::UnitLiteral { offset: at });
                at += 1;
            }
            0xe8 => {
                items.push(NumericPacketItem::ZeroLiteral { offset: at });
                at += 1;
            }
            code @ 0xe9 => {
                items.push(NumericPacketItem::Control { code, offset: at });
                at += 1;
            }
            0xfe => break,
            _ => return None,
        }
    }
    if binary64_count == 0 {
        return None;
    }
    let terminator_start = at;
    while payload.get(at) == Some(&0xfe) {
        at += 1;
    }
    let terminator_count = at - terminator_start;
    if offset == 0 && at == payload.len() && terminator_count >= 2 {
        return None;
    }
    let packet = EntityValuePacket::Numeric {
        offset,
        prefix_atoms: [prefix0, prefix1],
        type_selector: selector,
        layout_atom,
        value_atom,
        items,
        terminator_count,
    };
    let range = packet.byte_range()?;
    (range.end == at).then_some((packet, range))
}

/// One length-closed `7C05` entity-table record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct EntityRecord {
    /// Byte offset of the `7C05` marker.
    pub(crate) pos: usize,
    /// Byte between the `7C05` length and nested `7C06` marker.
    pub(crate) lead: u8,
    /// Stored entity identity.
    pub(crate) entity_id: u32,
    /// Inline body or nested definition/value frames.
    pub(crate) body: EntityBody,
}

/// Body of a length-closed `7C05` entity-table record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum EntityBody {
    /// Complete alternate inline body, including its lead byte.
    Inline(Vec<u8>),
    /// Nested `7C06` definition and `7C07` value frames.
    Nested {
        /// Exact definition prefix before the `0xEA` identity delimiter.
        prefix: Vec<u8>,
        /// Exact definition bytes after the identity.
        suffix: Vec<u8>,
        /// Exact nested `7C07` payload.
        value_payload: Vec<u8>,
        /// Exact bytes after the nested `7C07` frame.
        record_suffix: Vec<u8>,
    },
}

impl EntityRecord {
    /// Total framed byte length.
    pub(crate) fn total_len(&self) -> usize {
        match &self.body {
            EntityBody::Inline(bytes) => 6 + bytes.len(),
            EntityBody::Nested {
                prefix,
                suffix,
                value_payload,
                record_suffix,
            } => 24 + prefix.len() + suffix.len() + value_payload.len() + record_suffix.len(),
        }
    }

    /// Complete reference-signature view when the entire value payload has that production.
    pub(crate) fn reference_signature(&self) -> Option<ReferenceSignature> {
        match &self.body {
            EntityBody::Nested { value_payload, .. } => parse_reference_signature(value_payload),
            EntityBody::Inline(_) => None,
        }
    }
}

/// Parse every maximal contiguous run of length-closed `7C05` records.
pub(crate) fn parse_runs(
    ctx: &DecodeContext<'_>,
    data: &[u8],
) -> Result<Vec<Vec<EntityRecord>>, CodecError> {
    let candidate_runs = parse_candidate_runs(data);
    let mut runs = Vec::new();
    for candidates in candidate_runs {
        let Some(identities) = unique_monotone_run(&candidates) else {
            continue;
        };
        let mut records = Vec::new();
        let mut complete = true;
        for (candidate, identity) in candidates.iter().zip(identities) {
            ctx.charge_entities(1, "admit CATIA 7C05 native entity")?;

            let Some(record) = materialize_record(data, candidate, identity) else {
                complete = false;
                break;
            };
            records.push(record);
        }
        if complete {
            runs.push(records);
        }
    }
    Ok(runs)
}

/// Identify 7C05 runs paired to object graphs without retaining record bodies.
pub(crate) fn paired_object_graph_roots(data: &[u8]) -> std::collections::HashMap<usize, usize> {
    let mut roots = std::collections::HashMap::new();
    for candidates in parse_candidate_runs(data) {
        if unique_monotone_run(&candidates).is_none() {
            continue;
        }
        let Some(end) = candidates
            .last()
            .and_then(|last| last.pos.checked_add(last.total_len))
        else {
            continue;
        };
        if data.get(end) == Some(&0xde) {
            roots.insert(end + 1, candidates.len());
        }
    }
    roots
}

fn parse_candidate_runs(data: &[u8]) -> Vec<Vec<EntityRecordCandidates>> {
    let mut roots = Vec::new();
    let mut enclosing_end = 0usize;
    for pos in data
        .windows(2)
        .enumerate()
        .filter_map(|(pos, marker)| (marker == [0x7c, 0x05]).then_some(pos))
    {
        let Some(total_len) =
            View::u32_le_at(data, pos + 2).and_then(|len| usize::try_from(len).ok())
        else {
            continue;
        };
        let Some(end) = pos.checked_add(total_len).filter(|end| *end <= data.len()) else {
            continue;
        };
        if end <= enclosing_end {
            continue;
        }
        if let Some(candidate) = parse_candidate_variants(data, pos) {
            enclosing_end = enclosing_end.max(end);
            roots.push(candidate);
        }
    }
    let mut candidate_runs = Vec::<Vec<EntityRecordCandidates>>::new();
    for candidate in roots {
        if let Some(run) = candidate_runs.last_mut().filter(|run| {
            run.last()
                .is_some_and(|last| last.pos.checked_add(last.total_len) == Some(candidate.pos))
        }) {
            run.push(candidate);
        } else {
            let run = vec![candidate];
            candidate_runs.push(run);
        }
    }
    candidate_runs
}

#[derive(Debug, Clone, Copy)]
struct EntityIdentityCandidate {
    delimiter: usize,
    entity_id: u32,
}

#[derive(Clone)]
struct EntityRecordCandidates {
    pos: usize,
    total_len: usize,
    lead: u8,
    layout: EntityRecordLayout,
    identities: Vec<EntityIdentityCandidate>,
}

#[derive(Clone, Copy)]
enum EntityRecordLayout {
    Nested {
        definition_end: usize,
        value_end: usize,
    },
    Inline,
}

/// How many monotone paths reach one candidate. The run is unique only when
/// exactly one path reaches its final layer, so paths beyond the second are
/// never distinguished and never counted.
#[derive(Clone, Copy, PartialEq, Eq)]
enum PathCount {
    None,
    One,
    Many,
}

impl PathCount {
    /// Paths reaching a candidate through either of two disjoint predecessors.
    fn join(self, other: Self) -> Self {
        match (self, other) {
            (Self::None, count) | (count, Self::None) => count,
            (Self::One, Self::One) | (_, Self::Many) | (Self::Many, _) => Self::Many,
        }
    }
}

#[derive(Clone, Copy)]
struct MonotonePathState {
    identity: EntityIdentityCandidate,
    path_count: PathCount,
    predecessor: Option<usize>,
}

fn unique_monotone_run(records: &[EntityRecordCandidates]) -> Option<Vec<EntityIdentityCandidate>> {
    let first = records.first().map(|record| &record.identities)?;
    if first.is_empty() {
        return None;
    }
    let mut previous = Vec::new();

    previous.extend(first.iter().copied().map(|identity| MonotonePathState {
        identity,
        path_count: PathCount::One,
        predecessor: None,
    }));
    let mut layers = Vec::new();
    for record in &records[1..] {
        let mut ordered_predecessors = Vec::new();

        ordered_predecessors.extend(previous.iter().enumerate());
        ordered_predecessors.sort_by(|(_, left), (_, right)| {
            left.identity.entity_id.cmp(&right.identity.entity_id)
        });
        let mut cumulative = Vec::new();

        let mut cumulative_count = PathCount::None;
        for (index, state) in &ordered_predecessors {
            cumulative_count = cumulative_count.join(state.path_count);
            cumulative.push((
                cumulative_count,
                (cumulative_count == PathCount::One).then_some(*index),
            ));
        }
        let mut layer = Vec::new();
        for identity in &record.identities {
            let predecessor_count = ordered_predecessors
                .partition_point(|(_, state)| state.identity.entity_id < identity.entity_id);
            let (path_count, predecessor) = predecessor_count
                .checked_sub(1)
                .map_or((PathCount::None, None), |index| cumulative[index]);
            if path_count != PathCount::None {
                layer.push(MonotonePathState {
                    identity: *identity,
                    path_count,
                    predecessor,
                });
            }
        }
        if layer.is_empty() {
            return None;
        }

        layers.push(std::mem::replace(&mut previous, layer));
    }
    let final_layer = &previous;
    if final_layer
        .iter()
        .fold(PathCount::None, |count, state| count.join(state.path_count))
        != PathCount::One
    {
        return None;
    }
    let mut state_index = final_layer
        .iter()
        .position(|state| state.path_count == PathCount::One)?;
    let mut result = Vec::new();

    for layer in std::iter::once(final_layer).chain(layers.iter().rev()) {
        let state = &layer[state_index];
        result.push(state.identity);
        if let Some(predecessor) = state.predecessor {
            state_index = predecessor;
        }
    }
    result.reverse();
    Some(result)
}

fn parse_candidate_variants(data: &[u8], pos: usize) -> Option<EntityRecordCandidates> {
    let total_len = usize::try_from(View::u32_le_at(data, pos.checked_add(2)?)?).ok()?;
    let end = pos.checked_add(total_len)?;
    if total_len < 12 || end > data.len() {
        return None;
    }

    let lead = *data.get(pos + 6)?;
    if lead == 0x03 && data.get(pos + 7..pos + 9) != Some(&[0x7c, 0x06]) {
        let identities = identity_candidates(data, pos + 7, end, true);
        return (!identities.is_empty()).then_some(EntityRecordCandidates {
            pos,
            total_len,
            lead,
            layout: EntityRecordLayout::Inline,
            identities,
        });
    }
    if total_len < 19
        || lead > 0x02
        || data.get(pos.checked_add(7)?..pos.checked_add(9)?)? != [0x7c, 0x06]
    {
        return None;
    }
    let definition_len = View::u32_le_at(data, pos + 9)?;
    let definition_len_usize = usize::try_from(definition_len).ok()?;
    let definition_end = pos.checked_add(7)?.checked_add(definition_len_usize)?;
    if definition_len_usize < 11 || definition_end > end {
        return None;
    }
    let definition_start = pos + 13;
    let value_len = View::u32_le_at(data, definition_end + 2)?;
    let value_len_usize = usize::try_from(value_len).ok()?;
    let value_end = definition_end.checked_add(value_len_usize)?;
    if value_len_usize < 6 || value_end > end {
        return None;
    }
    let identities = identity_candidates(data, definition_start, definition_end, true);
    if data.get(definition_end..definition_end.checked_add(2)?)? != [0x7c, 0x07] {
        return None;
    }
    (!identities.is_empty()).then_some(EntityRecordCandidates {
        pos,
        total_len,
        lead,
        layout: EntityRecordLayout::Nested {
            definition_end,
            value_end,
        },
        identities,
    })
}

fn identity_candidates(
    data: &[u8],
    start: usize,
    end: usize,
    skip_fixed_fields: bool,
) -> Vec<EntityIdentityCandidate> {
    let mut identities = Vec::new();
    if end < start {
        return identities;
    }

    let mut at = start;
    while at < end {
        match data[at] {
            0xea => {
                if at
                    .checked_add(5)
                    .is_some_and(|candidate_end| candidate_end <= end)
                {
                    let Some(entity_id) = View::u32_le_at(data, at + 1) else {
                        break;
                    };
                    if entity_id != 0 {
                        identities.push(EntityIdentityCandidate {
                            delimiter: at,
                            entity_id,
                        });
                    }
                }
                at += 1;
            }
            0x32 if at
                .checked_add(5)
                .is_some_and(|candidate_end| candidate_end <= end) =>
            {
                at += 5;
            }
            0xfe if skip_fixed_fields
                && at.checked_add(1).and_then(|next| data.get(next)) == Some(&0xf6)
                && at.checked_add(18).is_some_and(|frame_end| frame_end <= end) =>
            {
                at += 18;
            }
            _ => at += 1,
        }
    }
    identities
}

fn materialize_record(
    data: &[u8],
    candidate: &EntityRecordCandidates,
    identity: EntityIdentityCandidate,
) -> Option<EntityRecord> {
    let record_end = candidate.pos.checked_add(candidate.total_len)?;
    let body = match candidate.layout {
        EntityRecordLayout::Inline => {
            let bytes = data.get(candidate.pos + 6..record_end)?;
            EntityBody::Inline(bytes.to_vec())
        }
        EntityRecordLayout::Nested {
            definition_end,
            value_end,
        } => {
            let definition_start = candidate.pos.checked_add(13)?;
            let identity_end = identity.delimiter.checked_add(5)?;
            let value_payload = data.get(definition_end + 6..value_end)?;
            let prefix = data.get(definition_start..identity.delimiter)?;
            EntityBody::Nested {
                prefix: prefix.to_vec(),
                suffix: data.get(identity_end..definition_end)?.to_vec(),
                value_payload: value_payload.to_vec(),
                record_suffix: data.get(value_end..record_end)?.to_vec(),
            }
        }
    };
    Some(EntityRecord {
        pos: candidate.pos,
        lead: candidate.lead,
        entity_id: identity.entity_id,
        body,
    })
}

pub(crate) fn parse_definition_schema_selectors(prefix: &[u8]) -> Vec<DefinitionSchemaSelector> {
    let mut selectors = Vec::new();
    let mut at = 0;
    while at < prefix.len() {
        let selector = match prefix.get(at) {
            Some(0x32) => View::u32_le_at(prefix, at + 1),
            _ => None,
        };
        if let Some(value) = selector {
            selectors.push(DefinitionSchemaSelector { value, offset: at });
            at += 5;
        } else {
            at += 1;
        }
    }
    selectors
}

pub(crate) fn parse_numeric_pair(payload: &[u8]) -> Option<NumericPair> {
    let (prefix0, mut at) = one_byte_atom(payload, 0)?;
    let (prefix1, next) = one_byte_atom(payload, at)?;
    at = next;
    if payload.get(at) != Some(&0xe8) {
        return None;
    }
    at += 1;
    let (type_atom, next) = compact_atom(payload, at)?;
    if type_atom != 4872 {
        return None;
    }
    at = next;
    if payload.get(at) != Some(&0x37) {
        return None;
    }
    at += 1;
    let (layout_atom, next) = one_byte_atom(payload, at)?;
    let (value_atom, next) = one_byte_atom(payload, next)?;
    if layout_atom != 3 || value_atom != 1 {
        return None;
    }
    at = next;

    let mut read_slot = || {
        let offset = at;
        match *payload.get(at)? {
            0xe6 => {
                let end = at.checked_add(9)?;
                let bits = View::u64_le_at(payload, at + 1)?;
                at = end;
                Some(NumericPairSlot::Binary64 { bits, offset })
            }
            0xe8 => {
                at += 1;
                Some(NumericPairSlot::ZeroLiteral { offset })
            }
            _ => None,
        }
    };
    let slots = [read_slot()?, read_slot()?];
    let has_binary64 = slots
        .iter()
        .any(|slot| matches!(slot, NumericPairSlot::Binary64 { .. }));
    (has_binary64 && payload.get(at..) == Some(&[0xfe, 0xfe])).then_some(NumericPair {
        prefix_atoms: [prefix0, prefix1],
        slots,
    })
}

pub(crate) fn parse_reference_signature(payload: &[u8]) -> Option<ReferenceSignature> {
    {
        if payload.first() != Some(&0x32) {
            return None;
        }
        let first_reference = View::u32_le_at(payload, 1)?;
        let (prefix_atom, mut at) = one_byte_atom(payload, 5)?;
        let prefix = match prefix_atom {
            2 => ReferenceSignaturePrefix::Atom2,
            35 => ReferenceSignaturePrefix::Atom35,
            _ => return None,
        };
        if payload.get(at) != Some(&0xe8) {
            return None;
        }
        at += 1;
        let (type_atom, next) = compact_atom(payload, at)?;
        if type_atom != 3851 {
            return None;
        }
        at = next;
        if payload.get(at) != Some(&0x37) {
            return None;
        }
        let (layout_atom, next) = one_byte_atom(payload, at + 1)?;
        at = next;
        if payload.get(at) != Some(&0x81) {
            return None;
        }
        at += 1;
        let signature_end = payload.get(at..)?.iter().position(|byte| *byte == 0xfe)? + at;
        let signature_offset = at;
        let signature_bytes = payload.get(signature_offset..signature_end)?;
        if signature_bytes.is_empty()
            || !signature_bytes
                .iter()
                .all(|byte| byte.is_ascii_graphic() || *byte == b' ')
        {
            return None;
        }
        let signature = std::str::from_utf8(signature_bytes).ok()?.to_owned();
        let signature_program = reference_signature_program(&signature, signature_offset)?;
        if !reference_signature_has_one_outer_call(&signature_program)
            || usize::try_from(layout_atom).ok() != signature_bytes.len().checked_add(1)
        {
            return None;
        }
        at = signature_end + 1;
        let second_reference_offset = at;
        if payload.get(at) != Some(&0x32) {
            return None;
        }
        let second_reference = View::u32_le_at(payload, at + 1)?;
        let references = ConsecutiveReferences::new(first_reference)?;
        if references.second() != second_reference {
            return None;
        }
        let (closing_atom, next) = one_byte_atom(payload, at + 5)?;
        let entity_instruction_count = signature_program
            .iter()
            .filter(|instruction| {
                matches!(
                    instruction,
                    ReferenceSignatureInstruction::Symbol {
                        symbol: ReferenceSignatureSymbol::E,
                        ..
                    }
                )
            })
            .count();
        if usize::try_from(closing_atom).ok() != entity_instruction_count.checked_add(1) {
            return None;
        }
        at = next;
        if payload.get(at) != Some(&0xe9) {
            return None;
        }
        let (closing_type_atom, next) = compact_atom(payload, at + 1)?;
        if closing_type_atom != 3864 {
            return None;
        }
        at = next;
        if payload.get(at..at + 5) != Some(&[0x08, 0x37, 0xfe, 0xfe, 0xfe]) {
            return None;
        }
        if at + 5 != payload.len() {
            return None;
        }
        let tokens = signature_program
            .into_iter()
            .map(ReferenceSignatureToken::from)
            .collect::<Vec<_>>();
        Some(ReferenceSignature {
            references,
            prefix,
            tokens,
            signature_offset,
            second_reference_offset,
        })
    }
}

fn one_byte_atom(data: &[u8], at: usize) -> Option<(u32, usize)> {
    let byte = *data.get(at)?;
    match byte {
        0x80..=0xd0 => Some((u32::from(byte - 0x80), at + 1)),
        _ => None,
    }
}

/// Parse one complete encoded value selected by a source-schema `Range`
/// entry. `start` begins after the selector word and `end` is the next
/// catalog-valid selector or the `7C07` payload end.
#[must_use]
pub(crate) fn parse_range_interval(
    payload: &[u8],
    start: usize,
    end: usize,
) -> Option<RangeInterval> {
    let bytes = payload.get(start..end)?;
    let (prefix, mut at) = if bytes.first() == Some(&0x80) && bytes.get(5) == Some(&0xe8) {
        (
            RangeIntervalPrefix::EscapedWord {
                word: View::u32_le_at(bytes, 1)?,
            },
            5,
        )
    } else {
        let (value, next) = compact_atom(bytes, 0)?;
        (
            RangeIntervalPrefix::Compact {
                value,
                width: u8::try_from(next).ok()?,
            },
            next,
        )
    };
    (bytes.get(at) == Some(&0xe8)).then_some(())?;
    let (type_atom, next) = compact_atom(bytes, at + 1)?;
    (type_atom == 3848 && bytes.get(next) == Some(&0x37)).then_some(())?;
    let body_at = next.checked_add(1)?;
    let slots = if bytes.get(body_at) == Some(&0xfe) {
        at = body_at;
        None
    } else {
        let (layout, next) = one_byte_atom(bytes, body_at)?;
        at = next;
        match layout {
            1 => None,
            3 => {
                let (value, next) = one_byte_atom(bytes, at)?;
                (value == 1).then_some(())?;
                at = next;
                let mut read_slot = || {
                    let offset = start + at;
                    match *bytes.get(at)? {
                        0xe6 => {
                            let scalar_end = at.checked_add(9)?;
                            let bits = View::u64_le_at(bytes, at + 1)?;
                            f64::from_bits(bits).is_finite().then_some(())?;
                            at = scalar_end;
                            Some(RangeIntervalSlot::Binary64 { bits, offset })
                        }
                        0xe8 => {
                            at += 1;
                            Some(RangeIntervalSlot::ZeroLiteral { offset })
                        }
                        _ => None,
                    }
                };
                Some([read_slot()?, read_slot()?])
            }
            _ => return None,
        }
    };
    (!bytes[at..].is_empty() && bytes[at..].iter().all(|byte| *byte == 0xfe)).then_some(())?;
    Some(RangeInterval { prefix, slots })
}

#[cfg(test)]
mod tests {
    use super::{
        parse_definition_schema_selectors, parse_numeric_pair, parse_range_interval,
        parse_reference_signature, unique_monotone_run, value_packets, DefinitionSchemaSelector,
        EntityBody, EntityIdentityCandidate, EntityRecord, EntityRecordCandidates,
        EntityRecordLayout, EntityValuePacket, NumericPacketItem, NumericPair, NumericPairSlot,
        PathCount, RangeInterval, RangeIntervalPrefix, RangeIntervalSlot, ReferenceSignature,
        ReferenceSignatureInstruction, ReferenceSignaturePrefix, ReferenceSignatureSymbol,
        ReferenceSignatureWire,
    };
    use crate::value_block;

    fn parse_runs(data: &[u8]) -> Vec<Vec<EntityRecord>> {
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let (ctx, _) = cadmpeg_core::decode::DecodeContext::from_root_bytes(
            data,
            &arena,
            &cadmpeg_core::decode::DecodePolicy::service(),
        )
        .expect("build the decode context");
        super::parse_runs(&ctx, data).expect("parse runs")
    }

    #[test]
    fn entity_table_native_entity_limit_refuses_before_record_allocation() {
        let bytes = record(&[0x11], 37);
        let arena = cadmpeg_core::decode::DecodeArena::new();
        let mut policy = cadmpeg_core::decode::DecodePolicy::service();
        policy.limits.max_entities = 0;
        let (ctx, _) =
            cadmpeg_core::decode::DecodeContext::from_root_bytes(&bytes, &arena, &policy)
                .expect("small entity record fits input limit");
        let error =
            super::parse_runs(&ctx, &bytes).expect_err("one native entity exceeds zero entities");
        assert!(
            matches!(error, cadmpeg_core::CodecError::ResourceLimit(limit)
            if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                && limit.operation == "admit CATIA 7C05 native entity")
        );
    }

    // The tuple carries one coupled result; a separate alias would add no invariant.
    #[allow(clippy::type_complexity)]
    fn nested_body(
        record: &EntityRecord,
    ) -> (
        usize,
        &[u8],
        Vec<DefinitionSchemaSelector>,
        &[u8],
        usize,
        &[u8],
        &[u8],
    ) {
        match &record.body {
            EntityBody::Nested {
                prefix,
                suffix,
                value_payload,
                record_suffix,
            } => (
                prefix.len() + suffix.len() + 11,
                prefix.as_slice(),
                parse_definition_schema_selectors(prefix),
                suffix.as_slice(),
                value_payload.len() + 6,
                value_payload.as_slice(),
                record_suffix.as_slice(),
            ),
            EntityBody::Inline(_) => panic!("expected nested entity body"),
        }
    }

    fn record_with_definition_suffix(
        prefix: &[u8],
        entity_id: u32,
        definition_suffix: &[u8],
    ) -> Vec<u8> {
        let mut bytes = vec![0x7c, 0x05, 0, 0, 0, 0, 0, 0x7c, 0x06];
        bytes.extend_from_slice(
            &u32::try_from(prefix.len() + definition_suffix.len() + 11)
                .expect("bounded test definition")
                .to_le_bytes(),
        );
        bytes.extend_from_slice(prefix);
        bytes.push(0xea);
        bytes.extend_from_slice(&entity_id.to_le_bytes());
        bytes.extend_from_slice(definition_suffix);
        bytes.extend_from_slice(&[0x7c, 0x07, 7, 0, 0, 0, 0xfe, 0xbb]);
        let len = u32::try_from(bytes.len()).expect("bounded test record");
        bytes[2..6].copy_from_slice(&len.to_le_bytes());
        bytes
    }

    fn record(prefix: &[u8], entity_id: u32) -> Vec<u8> {
        record_with_definition_suffix(prefix, entity_id, &[0xaa])
    }

    fn inline_record(prefix: &[u8], entity_id: u32, tail: &[u8]) -> Vec<u8> {
        let mut bytes = vec![0x7c, 0x05, 0, 0, 0, 0, 0x03];
        bytes.extend_from_slice(prefix);
        bytes.push(0xea);
        bytes.extend_from_slice(&entity_id.to_le_bytes());
        bytes.extend_from_slice(tail);
        let len = u32::try_from(bytes.len()).expect("bounded inline test record");
        bytes[2..6].copy_from_slice(&len.to_le_bytes());
        bytes
    }

    #[test]
    fn fixed_width_definition_atom_does_not_terminate_at_embedded_ea() {
        let prefix = [0x32, 0xea, 0, 0, 0, 0x11];
        let records = record(&prefix, 37);
        let runs = parse_runs(&records);
        let [run] = runs.as_slice() else {
            panic!("one entity-table run");
        };

        let (_, prefix_bytes, selectors, suffix, value_len, value_payload, record_suffix) =
            nested_body(&run[0]);
        assert_eq!(prefix_bytes, prefix);
        assert_eq!(
            selectors,
            [DefinitionSchemaSelector {
                value: 0x0000_00ea,
                offset: 0,
            }]
        );
        assert_eq!(run[0].entity_id, 37);
        assert_eq!(suffix, [0xaa]);
        assert_eq!(value_len, 7);
        assert_eq!(value_payload, [0xfe]);
        assert_eq!(record_suffix, [0xbb]);
    }

    #[test]
    fn entity_table_run_resolves_a_literal_ea_by_monotone_identity() {
        let mut records = record(&[0x11], 89);
        records.extend(record(&[0xe9, 0xea], 90));
        records.extend(record(&[0x12], 91));

        let runs = parse_runs(&records);
        let [run] = runs.as_slice() else {
            panic!("one uniquely resolved entity-table run");
        };
        assert_eq!(
            run.iter()
                .map(|record| record.entity_id)
                .collect::<Vec<_>>(),
            [89, 90, 91]
        );
        assert_eq!(nested_body(&run[1]).1, [0xe9, 0xea]);
    }

    #[test]
    fn fixed_frame_payload_does_not_create_an_identity_delimiter() {
        let mut first_frame = [0; 18];
        first_frame[..2].copy_from_slice(&[0xfe, 0xf6]);
        first_frame[2] = 0xea;
        first_frame[3..7].copy_from_slice(&100_u32.to_le_bytes());
        let mut second_frame = first_frame;
        second_frame[3..7].copy_from_slice(&101_u32.to_le_bytes());

        let mut records = record_with_definition_suffix(&[0x11], 1, &first_frame);
        records.extend(record_with_definition_suffix(&[0x12], 2, &second_frame));

        let runs = parse_runs(&records);
        let [run] = runs.as_slice() else {
            panic!("one frame-aware entity-table run");
        };
        assert_eq!(
            run.iter()
                .map(|record| record.entity_id)
                .collect::<Vec<_>>(),
            [1, 2]
        );
        assert_eq!(nested_body(&run[0]).3, first_frame);
        assert_eq!(nested_body(&run[1]).3, second_frame);
    }

    #[test]
    fn inline_fixed_frame_payload_does_not_create_an_identity_delimiter() {
        let mut frame = [0; 18];
        frame[..2].copy_from_slice(&[0xfe, 0xf6]);
        frame[2] = 0xea;
        frame[3..7].copy_from_slice(&100_u32.to_le_bytes());
        let bytes = inline_record(&[0x32, 7, 0, 0, 0], 37, &frame);

        let runs = parse_runs(&bytes);
        let [run] = runs.as_slice() else {
            panic!("one inline entity-table run");
        };
        assert_eq!(run[0].entity_id, 37);
        assert_eq!(run[0].body, EntityBody::Inline(bytes[6..].to_vec()));
    }

    #[test]
    fn entity_table_run_rejects_an_ambiguous_identity_delimiter() {
        assert!(parse_runs(&record(&[0xe9, 0xea], 90)).is_empty());
    }

    #[test]
    fn entity_table_does_not_descend_into_contained_records() {
        let nested = record(&[0x22], 90);
        let mut outer = record(&[0x11], 89);
        outer.extend_from_slice(&nested);
        let outer_len = u32::try_from(outer.len()).expect("bounded outer record");
        outer[2..6].copy_from_slice(&outer_len.to_le_bytes());

        let runs = parse_runs(&outer);
        let [run] = runs.as_slice() else {
            panic!("one outer entity-table run");
        };
        assert_eq!(run.len(), 1);
        assert_eq!(run[0].entity_id, 89);
        let record_suffix = nested_body(&run[0]).6;
        assert_eq!(record_suffix.first(), Some(&0xbb));
        assert_eq!(&record_suffix[1..], nested);
    }

    #[test]
    fn truncated_definition_selector_is_not_assigned() {
        assert!(parse_definition_schema_selectors(&[0x32, 1, 2, 3]).is_empty());
    }

    #[test]
    fn entity_table_runs_require_strictly_increasing_identities() {
        let mut records = record(&[0x11], 3);
        records.extend(record(&[0x12], 2));

        assert!(parse_runs(&records).is_empty());
    }

    #[test]
    fn numeric_pair_requires_one_complete_nested_production() {
        let payload = [
            0x91, 0x84, 0xe8, 0xe4, 0x07, 0x37, 0x83, 0x81, 0xe8, 0xe6, 0, 0, 0, 0, 0, 0, 0x12,
            0x40, 0xfe, 0xfe,
        ];

        assert_eq!(
            parse_numeric_pair(&payload),
            Some(NumericPair {
                prefix_atoms: [17, 4],
                slots: [
                    NumericPairSlot::ZeroLiteral { offset: 8 },
                    NumericPairSlot::Binary64 {
                        bits: 4.5_f64.to_bits(),
                        offset: 9,
                    },
                ],
            })
        );
    }

    #[test]
    fn numeric_pair_requires_exact_frame_and_two_nullable_slots() {
        let valid = [
            0x91, 0x84, 0xe8, 0xe4, 0x07, 0x37, 0x83, 0x81, 0xe8, 0xe6, 0, 0, 0, 0, 0, 0, 0x12,
            0x40, 0xfe, 0xfe,
        ];
        for (offset, replacement) in [(4, 0x06), (6, 0x82), (7, 0x82), (8, 0xe7)] {
            let mut malformed = valid;
            malformed[offset] = replacement;
            assert_eq!(parse_numeric_pair(&malformed), None);
        }
        assert_eq!(parse_numeric_pair(&valid[..19]), None);

        let mut extra_slot = valid.to_vec();
        extra_slot.splice(18..18, [0xe8]);
        assert_eq!(parse_numeric_pair(&extra_slot), None);

        let mut all_control = valid.to_vec();
        all_control.splice(9..18, [0xe8]);
        assert_eq!(parse_numeric_pair(&all_control), None);
    }

    #[test]
    fn marker_bytes_in_opaque_regions_do_not_create_numeric_pairs() {
        let opaque = [
            0x73, 0x83, 0xe8, 0xe0, 0x0a, 0x37, 0xd1, 0x51, 0x81, 0x4e, 0x29, 0x42, 0x27, 0x59,
            0xf4, 0xcb, 0x1b, 0x4f, 0xbe, 0x76, 0xaf, 0x2c, 0x10, 0xdf, 0x90, 0xe6, 0, 0, 0, 0, 0,
            0, 0, 0, 0xfe, 0xfe,
        ];

        assert_eq!(parse_numeric_pair(&opaque), None);
    }

    #[test]
    fn range_interval_decodes_nullable_bounds_and_exact_offsets() {
        let mut payload = vec![
            0x32, 0x23, 1, 0, 0, 0x87, 0xe8, 0xe0, 0x07, 0x37, 0x83, 0x81,
        ];
        payload.push(0xe6);
        payload.extend_from_slice(&(-0.2032_f64).to_bits().to_le_bytes());
        payload.push(0xe6);
        payload.extend_from_slice(&0.2032_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xfe, 0xfe]);

        assert_eq!(
            parse_range_interval(&payload, 5, payload.len()),
            Some(RangeInterval {
                prefix: RangeIntervalPrefix::Compact { value: 7, width: 1 },
                slots: Some([
                    RangeIntervalSlot::Binary64 {
                        bits: (-0.2032_f64).to_bits(),
                        offset: 12,
                    },
                    RangeIntervalSlot::Binary64 {
                        bits: 0.2032_f64.to_bits(),
                        offset: 21,
                    },
                ]),
            })
        );
    }

    #[test]
    fn range_interval_decodes_escaped_prefix_and_unset_bounds() {
        let payload = [
            0x32, 0x23, 1, 0, 0, 0x80, 0x6e, 0x89, 1, 0, 0xe8, 0xe0, 0x07, 0x37, 0x83, 0x81, 0xe8,
            0xe8, 0xfe, 0xfe,
        ];

        assert_eq!(
            parse_range_interval(&payload, 5, payload.len()),
            Some(RangeInterval {
                prefix: RangeIntervalPrefix::EscapedWord { word: 100_718 },
                slots: Some([
                    RangeIntervalSlot::ZeroLiteral { offset: 16 },
                    RangeIntervalSlot::ZeroLiteral { offset: 17 },
                ]),
            })
        );
    }

    #[test]
    fn range_interval_requires_the_complete_selected_value() {
        let valid = [0x82, 0xe8, 0xe0, 0x07, 0x37, 0x81, 0xfe];
        assert_eq!(
            parse_range_interval(&valid, 0, valid.len()),
            Some(RangeInterval {
                prefix: RangeIntervalPrefix::Compact { value: 2, width: 1 },
                slots: None,
            })
        );
        for malformed in [
            &valid[..6],
            &[0x82, 0xe8, 0xe0, 0x08, 0x37, 0x81, 0xfe],
            &[0x82, 0xe8, 0xe0, 0x07, 0x37, 0x82, 0xfe],
        ] {
            assert_eq!(parse_range_interval(malformed, 0, malformed.len()), None);
        }
    }

    #[test]
    fn range_interval_decodes_short_no_slot_body() {
        let valid = [0x82, 0xe8, 0xe0, 0x07, 0x37, 0xfe, 0xfe];
        assert_eq!(
            parse_range_interval(&valid, 0, valid.len()),
            Some(RangeInterval {
                prefix: RangeIntervalPrefix::Compact { value: 2, width: 1 },
                slots: None,
            })
        );
        let missing_terminator = [0x82, 0xe8, 0xe0, 0x07, 0x37];
        assert_eq!(
            parse_range_interval(&missing_terminator, 0, missing_terminator.len()),
            None
        );
        let trailing_non_terminator = [0x82, 0xe8, 0xe0, 0x07, 0x37, 0xfe, 0x81];
        assert_eq!(
            parse_range_interval(&trailing_non_terminator, 0, trailing_non_terminator.len()),
            None
        );
    }

    /// The complete reference-signature production the fixture payload carries.
    fn complete_reference_signature_wire() -> ReferenceSignatureWire {
        ReferenceSignatureWire {
            first_reference: 207,
            prefix: ReferenceSignaturePrefix::Atom2,
            signature: "2(E,0(E,4))".to_owned(),
            signature_program: vec![
                ReferenceSignatureInstruction::Decimal {
                    digits: "2".to_owned(),
                    offset: 12,
                },
                ReferenceSignatureInstruction::OpenCall { offset: 13 },
                ReferenceSignatureInstruction::Symbol {
                    symbol: ReferenceSignatureSymbol::E,
                    offset: 14,
                },
                ReferenceSignatureInstruction::Comma { offset: 15 },
                ReferenceSignatureInstruction::Decimal {
                    digits: "0".to_owned(),
                    offset: 16,
                },
                ReferenceSignatureInstruction::OpenCall { offset: 17 },
                ReferenceSignatureInstruction::Symbol {
                    symbol: ReferenceSignatureSymbol::E,
                    offset: 18,
                },
                ReferenceSignatureInstruction::Comma { offset: 19 },
                ReferenceSignatureInstruction::Decimal {
                    digits: "4".to_owned(),
                    offset: 20,
                },
                ReferenceSignatureInstruction::CloseCall { offset: 21 },
                ReferenceSignatureInstruction::CloseCall { offset: 22 },
            ],
            signature_offset: 12,
            second_reference: 208,
            second_reference_offset: 24,
        }
    }

    #[test]
    fn reference_signature_requires_one_complete_nested_production() {
        let payload = [
            0x32, 0xcf, 0, 0, 0, 0x82, 0xe8, 0xe0, 0x0a, 0x37, 0x8c, 0x81, b'2', b'(', b'E', b',',
            b'0', b'(', b'E', b',', b'4', b')', b')', 0xfe, 0x32, 0xd0, 0, 0, 0, 0x83, 0xe9, 0xe0,
            0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe,
        ];

        assert_eq!(
            parse_reference_signature(&payload),
            Some(
                complete_reference_signature_wire()
                    .try_into()
                    .expect("reference signature fixture has matching references and instructions")
            )
        );

        let mut nonconsecutive = payload;
        nonconsecutive[25] += 1;
        assert_eq!(parse_reference_signature(&nonconsecutive), None);

        for (offset, replacement) in [
            (5, 0x83),
            (8, 0x0b),
            (10, 0x8b),
            (12, b'E'),
            (29, 0x82),
            (32, 0x18),
        ] {
            let mut malformed = payload;
            malformed[offset] = replacement;
            assert_eq!(parse_reference_signature(&malformed), None);
        }

        let mut alternate_prefix = payload;
        alternate_prefix[5] = 0xa3;
        assert_eq!(
            parse_reference_signature(&alternate_prefix)
                .expect("alternate reference-signature prefix")
                .prefix(),
            ReferenceSignaturePrefix::Atom35
        );
    }

    #[test]
    fn reference_signature_wire_rejects_a_second_reference_that_does_not_follow_the_first() {
        let mut wire = complete_reference_signature_wire();
        wire.second_reference += 1;
        assert_eq!(
            ReferenceSignature::try_from(wire),
            Err("second_reference must follow first_reference")
        );
    }

    #[test]
    fn reference_signature_wire_rejects_a_program_disagreeing_with_the_signature() {
        let mut wire = complete_reference_signature_wire();
        wire.signature_program.pop();
        assert_eq!(
            ReferenceSignature::try_from(wire),
            Err("signature_program disagrees with signature and signature_offset")
        );

        let mut shifted = complete_reference_signature_wire();
        shifted.signature_offset += 1;
        assert_eq!(
            ReferenceSignature::try_from(shifted),
            Err("signature_program disagrees with signature and signature_offset")
        );
    }

    #[test]
    fn embedded_reference_markers_do_not_create_reference_signatures() {
        let payload = [
            0x90, 0x32, 0xcf, 0, 0, 0, 0x82, 0xe8, 0xe0, 0x0a, 0x37, 0x8c, 0x81, b'(', b'E', b')',
            0xfe, 0x32, 0xd0, 0, 0, 0, 0x83, 0xe9, 0xe0, 0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe,
        ];

        assert_eq!(parse_reference_signature(&payload), None);
    }

    #[test]
    fn reference_signature_requires_balanced_descriptor_delimiters() {
        let payload = [
            0x32, 1, 0, 0, 0, 0x82, 0xe8, 0xe0, 0x0a, 0x37, 0x84, 0x81, b'E', b')', 0xfe, 0x32, 2,
            0, 0, 0, 0x83, 0xe9, 0xe0, 0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe,
        ];

        assert_eq!(parse_reference_signature(&payload), None);
    }

    #[test]
    fn reference_signature_program_types_calls_qualifiers_and_differences() {
        let program = super::reference_signature_program("2(E#A(E,3)-0(T))", 12)
            .expect("complete descriptor program");
        assert!(super::reference_signature_has_one_outer_call(&program));
        assert!(program.iter().any(|instruction| matches!(
            instruction,
            ReferenceSignatureInstruction::Qualifier {
                selector: 10,
                hash_offset: 15,
                selector_offset: 16,
            }
        )));
        assert!(program.iter().any(|instruction| matches!(
            instruction,
            ReferenceSignatureInstruction::Difference { offset: 22 }
        )));

        for malformed in [
            "", "(E)", "2()", "2(E,)", "2(#3)", "2(E#G)", "2(E-)", "2(E))", "2 E",
        ] {
            assert_eq!(super::reference_signature_program(malformed, 0), None);
        }
    }

    #[test]
    fn reference_signature_counts_without_program_copy() {
        let program = super::reference_signature_program("2(E#A(E,3)-0(T))", 12)
            .expect("complete descriptor program");
        let signature = super::ReferenceSignature {
            references: super::ConsecutiveReferences::new(207).expect("consecutive"),
            prefix: super::ReferenceSignaturePrefix::Atom2,
            tokens: program
                .iter()
                .cloned()
                .map(super::ReferenceSignatureToken::from)
                .collect(),
            signature_offset: 12,
            second_reference_offset: 0,
        };
        let qualifier_count = program
            .iter()
            .filter(|instruction| {
                matches!(
                    instruction,
                    super::ReferenceSignatureInstruction::Qualifier { .. }
                )
            })
            .count();
        assert_eq!(
            signature.instruction_and_token_counts(),
            (program.len(), program.len() + qualifier_count)
        );
    }

    #[test]
    fn compact_value_packet_requires_the_double_terminated_production() {
        let payload = [0xe8, 0xe0, 0x0a, 0x37, 0xfe, 0xfe, 0xe8, 0x82, 0x37, 0xfe];
        let fields = value_block::tokenize(&payload);
        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Compact {
                offset: 0,
                value_selector: 0x0ae0,
            }]
        );
    }

    #[test]
    fn compact_value_packet_selector_is_independent_of_token_byte_classes() {
        let payload = [0xe8, 0xf4, 0x1a, 0x37, 0xfe, 0xfe];
        let fields = value_block::tokenize(&payload);
        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Compact {
                offset: 0,
                value_selector: 0x1af4,
            }]
        );
    }

    #[test]
    fn layout_value_packet_requires_the_layout_and_double_terminator() {
        let payload = [0xe9, 0xe0, 0x17, 0x08, 0x37, 0xfe, 0xfe, 0xfe];
        let fields = value_block::tokenize(&payload);
        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Layout {
                offset: 0,
                type_selector: 0x17e0,
                layout: 8,
                layout_offset: 3,
            }]
        );
    }

    #[test]
    fn layout_value_packet_selector_is_independent_of_token_byte_classes() {
        let payload = [0xe9, 0xf4, 0x17, 0x04, 0x37, 0xfe, 0xfe];
        let fields = value_block::tokenize(&payload);
        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Layout {
                offset: 0,
                type_selector: 0x17f4,
                layout: 4,
                layout_offset: 3,
            }]
        );
    }

    #[test]
    fn e9_scalar_packet_preserves_the_finite_value_and_offsets() {
        let mut payload = vec![0xaa, 0x83, 0xe9, 0xc0, 0x07, 0x01, 0xe1, 0xe6];
        payload.extend_from_slice(&5.5_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[
            0x88, 0x81, 0x81, 0x81, 0x81, 0x81, 0x82, 0xe7, 0x81, 0xfe, 0xbb,
        ]);
        let fields = value_block::tokenize(&payload);

        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::E9Scalar {
                offset: 1,
                scalar_offset: 7,
                bits: 5.5_f64.to_bits(),
            }]
        );
    }

    #[test]
    fn e9_scalar_packet_requires_the_exact_finite_production() {
        let mut valid = vec![0x83, 0xe9, 0xc0, 0x07, 0x01, 0xe1, 0xe6];
        valid.extend_from_slice(&5.5_f64.to_bits().to_le_bytes());
        valid.extend_from_slice(&[0x88, 0x81, 0x81, 0x81, 0x81, 0x81, 0x82, 0xe7, 0x81, 0xfe]);
        for (offset, replacement) in [(0, 0x84), (2, 0xc1), (4, 0x02), (15, 0x89), (23, 0xe8)] {
            let mut malformed = valid.clone();
            malformed[offset] = replacement;
            let fields = value_block::tokenize(&malformed);
            assert!(value_packets(&malformed, &fields).is_empty());
        }

        let fields = value_block::tokenize(&valid[..24]);
        assert!(value_packets(&valid[..24], &fields).is_empty());

        let mut non_finite = valid;
        non_finite[7..15].copy_from_slice(&f64::NAN.to_bits().to_le_bytes());
        let fields = value_block::tokenize(&non_finite);
        assert!(value_packets(&non_finite, &fields).is_empty());
    }

    #[test]
    fn e9_scalar_bytes_inside_a_byte_string_do_not_create_a_packet() {
        let mut payload = vec![0xe5, 25, 0, 0, 0, 0x83, 0xe9, 0xc0, 0x07, 0x01, 0xe1, 0xe6];
        payload.extend_from_slice(&5.5_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0x88, 0x81, 0x81, 0x81, 0x81, 0x81, 0x82, 0xe7, 0x81, 0xfe]);
        payload.push(0xfe);
        let fields = value_block::tokenize(&payload);

        assert!(value_packets(&payload, &fields).is_empty());
    }

    #[test]
    fn packet_shaped_bytes_inside_a_typed_value_do_not_create_packets() {
        let payload = [0x87, 0xe6, 0xe8, 1, 2, 0x37, 0xfe, 0xfe, 0, 0];
        let fields = value_block::tokenize(&payload);
        assert!(value_packets(&payload, &fields).is_empty());
    }

    #[test]
    fn numeric_packet_opcode_inside_binary64_does_not_create_a_packet() {
        let mut payload = vec![
            0x87, 0xe6, 0x81, 0x82, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe6,
        ];
        payload.extend_from_slice(&42.0_f64.to_bits().to_le_bytes());
        payload.push(0xfe);
        let fields = value_block::tokenize(&payload);

        assert!(value_packets(&payload, &fields).is_empty());
    }

    #[test]
    fn numeric_packet_literals_read_as_one_and_zero() {
        let mut payload = vec![0xaa, 0x81, 0x87, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe6];
        payload.extend_from_slice(&2.5_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xe7, 0xe8, 0xfe, 0xbb]);
        let fields = value_block::tokenize(&payload);
        let packets = value_packets(&payload, &fields);
        let [EntityValuePacket::Numeric { items, .. }] = packets.as_slice() else {
            panic!("one numeric packet: {packets:?}");
        };
        let values = items
            .iter()
            .map(|item| match item {
                NumericPacketItem::Binary64 { bits, .. } => f64::from_bits(*bits),
                NumericPacketItem::UnitLiteral { .. } => 1.0,
                NumericPacketItem::ZeroLiteral { .. } => 0.0,
                NumericPacketItem::Control { .. } => f64::NAN,
            })
            .collect::<Vec<_>>();
        assert_eq!(values, [2.5, 1.0, 0.0]);

        let literal_only = [
            0xaa, 0x81, 0x87, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe8, 0xe8, 0xe7, 0xfe, 0xbb,
        ];
        let fields = value_block::tokenize(&literal_only);
        assert!(value_packets(&literal_only, &fields).is_empty());
    }

    #[test]
    fn embedded_numeric_value_packet_preserves_exact_values_and_controls() {
        let mut payload = vec![0xaa, 0x81, 0x87, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84];
        payload.push(0xe7);
        payload.push(0xe6);
        payload.extend_from_slice(&(-32.0_f64).to_bits().to_le_bytes());
        payload.push(0xe9);
        payload.push(0xe6);
        payload.extend_from_slice(&180.902_997_326_510_7_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xfe, 0xbb]);
        let fields = value_block::tokenize(&payload);

        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Numeric {
                offset: 1,
                prefix_atoms: [1, 7],
                type_selector: 0x1af4,
                layout_atom: 3,
                value_atom: 4,
                items: vec![
                    NumericPacketItem::UnitLiteral { offset: 9 },
                    NumericPacketItem::Binary64 {
                        bits: (-32.0_f64).to_bits(),
                        offset: 10,
                    },
                    NumericPacketItem::Control {
                        code: 0xe9,
                        offset: 19,
                    },
                    NumericPacketItem::Binary64 {
                        bits: 180.902_997_326_510_7_f64.to_bits(),
                        offset: 20,
                    },
                ],
                terminator_count: 1,
            }]
        );
    }

    #[test]
    fn embedded_numeric_value_packet_accepts_compact_prefix_atoms() {
        let mut payload = vec![
            0x88, 0xd5, 0x3f, 0xe8, 0xe4, 0x07, 0x37, 0x88, 0x81, 0xe8, 0xe8, 0xe8, 0xe6,
        ];
        payload.extend_from_slice(&12.7_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xe8, 0xe6]);
        payload.extend_from_slice(&std::f64::consts::PI.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xe7, 0xfe]);
        let fields = value_block::tokenize(&payload);

        assert_eq!(
            value_packets(&payload, &fields),
            [EntityValuePacket::Numeric {
                offset: 0,
                prefix_atoms: [8, 1088],
                type_selector: 0x07e4,
                layout_atom: 8,
                value_atom: 1,
                items: vec![
                    NumericPacketItem::ZeroLiteral { offset: 9 },
                    NumericPacketItem::ZeroLiteral { offset: 10 },
                    NumericPacketItem::ZeroLiteral { offset: 11 },
                    NumericPacketItem::Binary64 {
                        bits: 12.7_f64.to_bits(),
                        offset: 12,
                    },
                    NumericPacketItem::ZeroLiteral { offset: 21 },
                    NumericPacketItem::Binary64 {
                        bits: std::f64::consts::PI.to_bits(),
                        offset: 22,
                    },
                    NumericPacketItem::UnitLiteral { offset: 31 },
                ],
                terminator_count: 1,
            }]
        );
    }

    #[test]
    fn malformed_numeric_value_packets_are_not_assigned() {
        for payload in [
            vec![0x81, 0x82, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe6, 0, 0],
            vec![0x81, 0x82, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe7, 0xfe],
            vec![
                0x81, 0x82, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe6, 0, 0, 0, 0, 0, 0, 0, 0, 0xaa,
            ],
        ] {
            let fields = value_block::tokenize(&payload);
            assert!(value_packets(&payload, &fields).is_empty());
        }
    }

    #[test]
    fn complete_numeric_pair_is_not_duplicated_as_an_embedded_packet() {
        let mut payload = vec![0x81, 0x82, 0xe8, 0xe4, 0x07, 0x37, 0x83, 0x81, 0xe6];
        payload.extend_from_slice(&42.0_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xe8, 0xfe, 0xfe]);
        let fields = value_block::tokenize(&payload);

        assert!(parse_numeric_pair(&payload).is_some());
        assert!(value_packets(&payload, &fields).is_empty());
    }

    #[test]
    fn a_monotone_run_is_unique_only_when_exactly_one_path_reaches_its_last_layer() {
        // The run is taken only when one monotone path reaches the final
        // layer, so the path count is a none/one/many classifier. `join`
        // states that directly: a second path makes the count `Many`, and a
        // third leaves it `Many` without ever being counted.
        assert!(PathCount::None.join(PathCount::None) == PathCount::None);
        assert!(PathCount::None.join(PathCount::One) == PathCount::One);
        assert!(PathCount::One.join(PathCount::None) == PathCount::One);
        assert!(PathCount::One.join(PathCount::One) == PathCount::Many);
        assert!(PathCount::Many.join(PathCount::One) == PathCount::Many);
        assert!(PathCount::One.join(PathCount::Many) == PathCount::Many);
        assert!(PathCount::Many.join(PathCount::Many) == PathCount::Many);

        let record = |entity_ids: &[u32]| EntityRecordCandidates {
            pos: 0,
            total_len: 12,
            lead: 0x01,
            layout: EntityRecordLayout::Inline,
            identities: entity_ids
                .iter()
                .enumerate()
                .map(|(ordinal, entity_id)| EntityIdentityCandidate {
                    delimiter: ordinal,
                    entity_id: *entity_id,
                })
                .collect(),
        };

        // One strictly increasing path: the run is the path.
        let unique = unique_monotone_run(&[record(&[1]), record(&[2]), record(&[3])])
            .expect("one monotone path");
        assert_eq!(
            unique
                .iter()
                .map(|identity| identity.entity_id)
                .collect::<Vec<_>>(),
            vec![1, 2, 3]
        );

        // Two paths, and three paths, are both `Many`; neither is a run.
        assert!(unique_monotone_run(&[record(&[1, 2]), record(&[3])]).is_none());
        assert!(unique_monotone_run(&[record(&[1, 2, 3]), record(&[4])]).is_none());

        // No predecessor is strictly below the successor: no path at all.
        assert!(unique_monotone_run(&[record(&[5]), record(&[4])]).is_none());
    }

    #[test]
    fn two_increasing_single_identity_records_form_a_monotone_run() {
        let candidate = |entity_id| EntityRecordCandidates {
            pos: 0,
            total_len: 12,
            lead: 0x01,
            layout: EntityRecordLayout::Inline,
            identities: vec![EntityIdentityCandidate {
                delimiter: 0,
                entity_id,
            }],
        };
        let records = [candidate(1), candidate(2)];

        assert!(unique_monotone_run(&records).is_some());
    }

    #[test]
    fn numeric_value_packet_parses_a_binary64_item() {
        let mut payload = vec![0xaa, 0x81, 0x87, 0xe8, 0xf4, 0x1a, 0x37, 0x83, 0x84, 0xe6];
        payload.extend_from_slice(&42.0_f64.to_bits().to_le_bytes());
        payload.extend_from_slice(&[0xfe, 0xbb]);
        assert!(super::parse_numeric_value_packet(&payload, 1).is_some());
    }

    #[test]
    fn definition_schema_prefix_yields_one_selector_at_offset_zero() {
        let prefix = [0x32, 4, 0, 0, 0];
        let admitted = super::parse_definition_schema_selectors(&prefix);
        assert_eq!(
            admitted,
            [super::DefinitionSchemaSelector {
                value: 4,
                offset: 0
            }]
        );
    }
}

// Each optional key below names itself in whatever it refuses.
cadmpeg_core::named_optional_field!(deserialize_slots, [RangeIntervalSlot; 2], "slots");
