// SPDX-License-Identifier: Apache-2.0
//! Freeform decode route composing a5a8 and consolidated NURBS record carriers.

pub(in crate::families) mod weighted_edges;
mod weighted_plane;

use cadmpeg_core::convert::f64_from_index;
use cadmpeg_core::decode::{u64_from_index, WorkBudget};

use cadmpeg_ir::codec::DecodeBody;
use cadmpeg_ir::document::CadIr;
use cadmpeg_ir::features::FinitePoint3;
use cadmpeg_ir::geometry::{
    nurbs::NurbsCurve,
    pcurve::{Pcurve, PcurveGeometry},
    surface_payloads::RevolutionSurfaceConstruction,
    Curve, CurveGeometry, IntcurveSupportContext, IntcurveSupportSide, ProceduralCurve,
    ProceduralCurveDefinition, ProceduralSurface, ProceduralSurfaceDefinition, RecordBounds,
    SolvedCurveGeometry, SolvedSurfaceGeometry, Surface, SurfaceCurveFamily, SurfaceGeometry,
};
use cadmpeg_ir::ids::{
    BodyId, CoedgeId, CurveId, EdgeId, FaceId, LoopId, PcurveId, PointId, ProceduralCurveId,
    ProceduralSurfaceId, RegionId, ShellId, SurfaceId, UnknownId, VertexId,
};
use cadmpeg_ir::math::{Point2, Point3, Vector3};
use cadmpeg_ir::scalar::{NonZeroLength, PositiveLength};
use cadmpeg_ir::topology::{
    Body, BodyKind, Coedge, Edge, Face, FaceLoops, Loop, LoopBoundary, LoopRing, PcurveUse, Point,
    Region, Sense, Shell, Vertex,
};
use cadmpeg_ir::units::OrthonormalFrame3;
use cadmpeg_ir::AnnotationBuilder;
use cadmpeg_ir::Exactness;
use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};

mod owned_patch;
mod parameter_cache;
mod rolling_ball_patch;

use crate::assemble::{
    annotate, insert_unresolved_carrier_loss, link_payload_carriers, neutral_model_is_admissible,
    preserve_raw_payload, quintic_jet_pcurve,
};
use crate::assemble::{cgm_source, cgm_source_key};
use crate::container::{self, ContainerScan};
use crate::families::b5::graph::controls::{
    B5EdgeTerminalControl, B5FramingControl, B5VertexIncidenceControl,
};
use crate::families::{FamilyEntityAdmission, FamilyOutput};
use crate::loss::{identity_statement, CatiaLossCode};
use crate::math::distance;

const EPS_TORUS_FRAME: f64 = 1.0e-12;
const EPS_APEX_ALIGNMENT: f64 = 1.0e-12;
const MAX_PATCH_RECORD_VISITS_PER_RECORD: usize = 64;

#[derive(Clone)]
struct FreeformSurfaceCarrier {
    pos: usize,
    geometry: SurfaceGeometry,
    source_object: cadmpeg_ir::SourceObjectAssociation,
    source_tag: String,
}

#[derive(Clone)]
pub(super) struct ConsolidatedRevolutionBinding {
    pub(super) geometry: SurfaceGeometry,
    pub(super) profile_sweep: f64,
}

/// Transfer resolved consolidated axis-and-profile revolution carriers.
pub(super) fn append_consolidated_revolutions(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    resolved: &[crate::families::b2::records::B2ResolvedRevolution],
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<Vec<ConsolidatedRevolutionBinding>, cadmpeg_core::CodecError> {
    let mut bindings = Vec::new();
    for carrier in resolved {
        let index = carrier.revolution_index;
        let revolution = &carrier.revolution;
        let profile = &carrier.profile;
        let direction_x = Vector3::from(revolution.profile_frame.axis().get());
        let direction_y = Vector3::from(revolution.profile_frame.reference().get());
        let axis = Vector3::from(revolution.axis.get());
        let origin = revolution.origin.get();
        let transverse_coordinate =
            origin.x * direction_x.x + origin.y * direction_x.y + origin.z * direction_x.z;
        let center = Point3::new(
            transverse_coordinate * direction_x.x
                + profile.center_pair[0] * direction_y.x
                + profile.center_pair[1] * axis.x,
            transverse_coordinate * direction_x.y
                + profile.center_pair[0] * direction_y.y
                + profile.center_pair[1] * axis.y,
            transverse_coordinate * direction_x.z
                + profile.center_pair[0] * direction_y.z
                + profile.center_pair[1] * axis.z,
        );
        let directrix = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!(
                "catia",
                "consolidated",
                "surface-revolution-directrix"
            ),
            index,
            CurveId::mint,
        )?;
        let Some(admitted_center) = FinitePoint3::new(center) else {
            continue;
        };
        let payload = cadmpeg_ir::geometry::analytic::CircleCurve::new(
            admitted_center,
            revolution.profile_frame.into(),
            profile.radius,
        );
        annotate(
            annotations,
            &directrix,
            "consolidated_b2_03_19",
            u64_from_index(profile.pos),
            format_args!("circle:{}", profile.record_id),
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: directrix.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Circle(payload)),
            source_object: Some(cgm_source("profile-circle", profile.record_id)?),
            native_ref: None,
        });
        let surface = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "consolidated", "surface-revolution-surface"),
            index,
            SurfaceId::mint,
        )?;
        let center_offset = Vector3::new(
            center.x - origin.x,
            center.y - origin.y,
            center.z - origin.z,
        );
        let axis_coordinate =
            center_offset.x * axis.x + center_offset.y * axis.y + center_offset.z * axis.z;
        let radial = Vector3::new(
            center_offset.x - axis.x * axis_coordinate,
            center_offset.y - axis.y * axis_coordinate,
            center_offset.z - axis.z * axis_coordinate,
        );
        let major_radius = radial.x.hypot(radial.y).hypot(radial.z);
        // The profile plane contains the axis: the record's right-handed
        // frame admission holds the profile-circle normal perpendicular to
        // the axis within 2e-12.
        let radial_follows_profile_reference = major_radius > 0.0
            && ((radial.x * direction_y.x + radial.y * direction_y.y + radial.z * direction_y.z)
                .abs()
                / major_radius
                - 1.0)
                .abs()
                <= EPS_TORUS_FRAME;
        let torus_geometry = PositiveLength::new(major_radius)
            .filter(|_| radial_follows_profile_reference)
            .and_then(|major_radius| {
                let ref_direction = Vector3::new(
                    radial.x / major_radius.get(),
                    radial.y / major_radius.get(),
                    radial.z / major_radius.get(),
                );
                let torus_center = Point3::new(
                    center.x - radial.x,
                    center.y - radial.y,
                    center.z - radial.z,
                );
                Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(
                    cadmpeg_ir::geometry::analytic::TorusSurface::new(
                        FinitePoint3::new(torus_center)?,
                        OrthonormalFrame3::from_units(
                            revolution.axis.into(),
                            cadmpeg_ir::units::UnitVector3::new(ref_direction)?,
                        )?,
                        major_radius,
                        NonZeroLength::from(profile.radius),
                    ),
                )))
            });
        annotate(
            annotations,
            &surface,
            "consolidated_b2_03_2d",
            u64_from_index(revolution.pos),
            format_args!("profile-reference:{}", revolution.profile_reference),
            Exactness::ByteExact,
        )?;
        let procedural_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "consolidated", "surface-revolution"),
            index,
            ProceduralSurfaceId::mint,
        )?;
        let surface_construction_id = procedural_id.clone();
        let cache = match &torus_geometry {
            Some(SurfaceGeometry::Solved(SolvedSurfaceGeometry::Torus(torus))) => {
                SolvedSurfaceGeometry::Torus(*torus)
            }
            _ => SolvedSurfaceGeometry::Unknown { record: None },
        };
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id: surface,
            geometry: SurfaceGeometry::Procedural {
                construction: surface_construction_id,
                cache: Some(cache),
            },
            source_object: None,
            native_ref: None,
        });
        admission.charge()?;
        ir.geometry.procedural_surfaces.push(ProceduralSurface::new(
            procedural_id,
            ProceduralSurfaceDefinition::Revolution(RevolutionSurfaceConstruction::legacy(
                directrix,
                (revolution.origin, revolution.axis.into()),
                revolution.angular_interval,
                Some(revolution.angular_range),
                Some(revolution.profile_range),
                false,
                None,
            )),
            None,
        ));
        if let Some(geometry) = torus_geometry {
            bindings.push(ConsolidatedRevolutionBinding {
                geometry,
                profile_sweep: (revolution.profile_range.upper()
                    - revolution.profile_range.lower())
                .abs()
                    / profile.radius.get(),
            });
        }
    }
    Ok(bindings)
}

fn typed_face_counts(
    records: &std::collections::BTreeMap<u32, crate::families::b5::graph::B5FaceRecord>,
    resolved_faces: &[crate::families::b5::graph::B5Face],
) -> [usize; 4] {
    let resolved_ids = resolved_faces
        .iter()
        .map(|face| face.object_id)
        .collect::<std::collections::HashSet<_>>();
    records.values().fold([0usize; 4], |mut counts, face| {
        match face.terminal_control {
            Some(B5FramingControl::Control03) => counts[0] += 1,
            Some(B5FramingControl::Control05) => counts[1] += 1,
            None => counts[2] += 1,
        }
        counts[3] += usize::from(!resolved_ids.contains(&face.object_id));
        counts
    })
}

fn typed_multi_surface_face_count(graph: &crate::families::b5::graph::B5Graph) -> usize {
    graph
        .face_records
        .values()
        .filter(|face| {
            let Some(&carrier) = face.references.first() else {
                return false;
            };
            let Some(canonical_carrier) =
                crate::families::b5::graph::canonical_surface_id(&graph.surface_aliases, carrier)
            else {
                return false;
            };
            face.references[1..].iter().any(|reference| {
                graph.surfaces.contains_key(reference)
                    && crate::families::b5::graph::canonical_surface_id(
                        &graph.surface_aliases,
                        *reference,
                    )
                    .is_some_and(|candidate| candidate != canonical_carrier)
            })
        })
        .count()
}

fn loop_metadata_counts<'a>(
    records: impl Iterator<Item = &'a crate::families::b5::graph::B5Loop>,
) -> [usize; 5] {
    records.fold([0usize; 5], |mut counts, loop_| {
        let index = match loop_.metadata.framing_controls {
            [B5FramingControl::Control03, B5FramingControl::Control03] => 0,
            [B5FramingControl::Control03, B5FramingControl::Control05] => 1,
            [B5FramingControl::Control05, B5FramingControl::Control03] => 2,
            [B5FramingControl::Control05, B5FramingControl::Control05] => 3,
        };
        counts[index] += 1;
        counts[4] += usize::from(loop_.metadata.extension.is_some());
        counts
    })
}

/// Object-stream class code of a `b5 03 5f` face record.
const B5_FACE_CLASS: u8 = 0x5f;

pub(super) fn try_decode_freeform_surfaces(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    scan: &ContainerScan,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Option<FamilyOutput>, cadmpeg_core::CodecError> {
    (|| -> Option<Result<FamilyOutput, cadmpeg_core::CodecError>> {
        macro_rules! admitted {
            ($value:expr) => {
                match $value {
                    Ok(value) => value,
                    Err(error) => return Some(Err(error)),
                }
            };
        }
        let logical_streams = match container::logical_record_streams(ctx, scan) {
            Ok(streams) => streams,
            Err(error) => return Some(Err(error)),
        };
        let selection_budget = cadmpeg_core::decode::WorkBudget::new(
            crate::families::b5::graph::MAX_OBJECT_STREAM_SELECTION_WORK,
        );
        let object_selection = crate::families::b5::graph::select_object_stream_population(
            &logical_streams,
            Some(&selection_budget),
        );
        let (
            object_stream_run_count,
            selected_object_stream_run_count,
            object_stream_selection_exhausted,
            object_source,
            object_frames,
            selected_object_records,
            census_object_records,
        ) = match object_selection {
            crate::families::b5::graph::ObjectStreamSelection::Exhausted { run_count } => (
                run_count,
                0,
                true,
                Vec::new(),
                Vec::new(),
                Vec::new(),
                Vec::new(),
            ),
            crate::families::b5::graph::ObjectStreamSelection::Unselected {
                run_count,
                census_records,
            } => (
                run_count,
                0,
                false,
                Vec::new(),
                Vec::new(),
                Vec::new(),
                census_records,
            ),
            crate::families::b5::graph::ObjectStreamSelection::Selected {
                source,
                frames,
                records,
                census_records,
                run_count,
            } => (run_count, 1, false, source, frames, records, census_records),
        };
        drop(logical_streams);
        let sources = container::consolidated_record_sources(scan);
        let consolidated_records =
            match crate::wire::records::consolidated_records_in_sources(&scan.data, &sources) {
                Ok(records) => records,
                Err(error) => return Some(Err(error)),
            };
        let mut b5_graph = match crate::families::b5::graph::parse_from_records(
            ctx,
            &object_source,
            &selected_object_records,
            &object_frames,
            true,
            Some(&selection_budget),
            refusal,
        ) {
            Ok(graph) => graph,
            Err(error) => return Some(Err(error)),
        };
        let face_terminal_controls = b5_graph.as_ref().map(|graph| {
            graph.faces.iter().fold([0usize; 3], |mut counts, face| {
                match face.terminal_control {
                    Some(B5FramingControl::Control03) => counts[0] += 1,
                    Some(B5FramingControl::Control05) => counts[1] += 1,
                    None => counts[2] += 1,
                }
                counts
            })
        });
        let typed_face_counts = if let Some(graph) = &b5_graph {
            Some(typed_face_counts(&graph.face_records, &graph.faces))
        } else {
            let records =
                crate::families::b5::graph::typed_face_records_from_records(&census_object_records);
            if records.is_empty() {
                None
            } else {
                Some(typed_face_counts(&records, &[]))
            }
        };
        let typed_multi_surface_face_count = b5_graph
            .as_ref()
            .map(typed_multi_surface_face_count)
            .unwrap_or_default();
        let typed_edge_records =
            crate::families::b5::graph::typed_edge_records_from_records(&census_object_records);
        let edge_terminal_controls = (!typed_edge_records.is_empty()).then(|| {
            typed_edge_records
                .values()
                .fold([0usize; 8], |mut counts, edge| {
                    let index = match edge.terminal_control {
                        B5EdgeTerminalControl::Control01 => 0,
                        B5EdgeTerminalControl::Control02 => 1,
                        B5EdgeTerminalControl::Control21 => 2,
                        B5EdgeTerminalControl::Control22 => 3,
                        B5EdgeTerminalControl::Control25 => 4,
                        B5EdgeTerminalControl::Control26 => 5,
                        B5EdgeTerminalControl::Control29 => 6,
                        B5EdgeTerminalControl::Control2A => 7,
                    };
                    counts[index] += 1;
                    counts
                })
        });
        let typed_vertex_incidence_links =
            crate::families::b5::graph::typed_vertex_incidence_links_from_records(
                &census_object_records,
            );
        let vertex_incidence_terminal_controls =
            (!typed_vertex_incidence_links.is_empty()).then(|| {
                typed_vertex_incidence_links
                    .values()
                    .fold([0usize; 2], |mut counts, link| {
                        match link.terminal_control {
                            B5VertexIncidenceControl::Control00 => counts[0] += 1,
                            B5VertexIncidenceControl::Control04 => counts[1] += 1,
                        }
                        counts
                    })
            });
        let resolved_loop_metadata_counts = b5_graph
            .as_ref()
            .map(|graph| loop_metadata_counts(graph.loops.values()));
        let typed_loop_records =
            crate::families::b5::graph::typed_loop_records_from_records(&census_object_records);
        let typed_loop_metadata_counts = (!typed_loop_records.is_empty()).then(|| {
            (
                loop_metadata_counts(typed_loop_records.values()),
                typed_loop_records
                    .keys()
                    .filter(|id| {
                        b5_graph
                            .as_ref()
                            .is_none_or(|graph| !graph.loops.contains_key(id))
                    })
                    .count(),
            )
        });
        let class_21_suffix_scalar_count = b5_graph.as_ref().map(|graph| {
            graph
                .pcurves
                .values()
                .filter(|pcurve| pcurve.class_21_suffix_scalar.is_some())
                .count()
        });
        let pcurves =
            crate::families::b5::graph::typed_class_21_pcurves_from_records(&census_object_records);
        let typed_class_21_pcurve_count = pcurves.len();
        let typed_parameter_incidences =
            crate::families::b5::graph::typed_parameter_incidences_from_records(
                &census_object_records,
            );
        let typed_parameter_incidence_member_count = typed_parameter_incidences
            .values()
            .map(|incidence| incidence.lanes.len())
            .sum();
        let typed_vertex_incidence_rosters =
            crate::families::b5::graph::typed_vertex_incidence_rosters_from_records(
                &census_object_records,
            );
        let typed_vertex_incidence_roster_member_count =
            typed_vertex_incidence_rosters.values().map(Vec::len).sum();
        let mut fallback_surfaces = if b5_graph.is_none() {
            match freeform_surface_carriers(&scan.data, &sources, &consolidated_records, refusal) {
                Ok(surfaces) => Some(surfaces),
                Err(error) => return Some(Err(error)),
            }
        } else {
            None
        };
        let b2_nurbs_curves = crate::families::b2::records::b2_nurbs_curves_from_records(
            &scan.data,
            &consolidated_records,
            refusal,
        );
        let b2_nurbs_curve_count = b2_nurbs_curves.len();
        let a5_nurbs_curves = crate::families::a5a8::records::a5_nurbs_curves_from_records(
            &scan.data,
            &consolidated_records,
            refusal,
        );
        let a5_nurbs_curve_count = a5_nurbs_curves.len();
        let b2_spatial_circles = (crate::families::b2::records::b2_spatial_circles_from_records(
            &scan.data,
            &consolidated_records,
        ))
        .collect::<Vec<_>>();
        let b2_line_profile_count = crate::families::b2::records::b2_line_profiles_from_records(
            &scan.data,
            &consolidated_records,
        )
        .count();
        let resolved_consolidated_revolutions =
            crate::families::b2::records::b2_resolved_revolutions_from_records(
                &scan.data,
                &consolidated_records,
            );
        let resolved_consolidated_revolution_count = resolved_consolidated_revolutions.len();
        let b2_spatial_circle_count = b2_spatial_circles.len();
        let no_a8_jets = if fallback_surfaces.as_ref().is_some_and(Vec::is_empty) {
            let jets = crate::families::a5a8::records::a8_freeform_curves(&scan.data);
            jets.is_empty()
        } else {
            false
        };
        let planar_two_edge_candidate =
            crate::families::b2::records::b2_plane_carriers_from_records(
                &scan.data,
                &consolidated_records,
            )
            .len()
                == 1
                && [
                    crate::wire::records::ConsolidatedFamily::A,
                    crate::wire::records::ConsolidatedFamily::B,
                ]
                .into_iter()
                .map(|family| {
                    crate::wire::records::family_pcurves_from_records(
                        &scan.data,
                        &consolidated_records,
                        family,
                    )
                    .len()
                })
                .sum::<usize>()
                    == 2;
        if no_a8_jets
            && b2_nurbs_curves.is_empty()
            && a5_nurbs_curves.is_empty()
            && b2_spatial_circles.is_empty()
            && b2_line_profile_count == 0
            && resolved_consolidated_revolution_count == 0
            && !planar_two_edge_candidate
        {
            return None;
        }
        let mut ir = CadIr::empty();
        let mut admission = FamilyEntityAdmission::new(ctx);
        let mut annotations = AnnotationBuilder::new();
        let mut unknowns = Vec::new();
        let payload_id = admitted!(
            UnknownId::mint(("catia:payload:unknown#freeform").to_owned())
                .map_err(cadmpeg_core::CodecError::malformed)
        );
        let payload_index = match preserve_raw_payload(
            ctx,
            &mut unknowns,
            &mut annotations,
            scan,
            payload_id.clone(),
        ) {
            Ok(index) => index,
            Err(error) => return Some(Err(error)),
        };
        // The graph is released before model validation. Keep the record identities the
        // topology loss notes must name.
        let b5_face_object_ids = (b5_graph
            .iter()
            .flat_map(|graph| graph.faces.iter().map(|face| face.object_id)))
        .collect::<Vec<_>>();
        let census_face_object_ids = (census_object_records
            .iter()
            .filter(|record| record.class == B5_FACE_CLASS)
            .map(|record| record.object_id))
        .collect::<Vec<_>>();
        let mut topology_ir = CadIr::empty();
        let mut topology_annotations = AnnotationBuilder::new().copy_transaction();
        let payload_stream = if scan.brep.is_some() {
            "MainDataStream+SurfacicReps"
        } else {
            "CATPart"
        };
        admitted!(annotate(
            &mut topology_annotations,
            &payload_id,
            payload_stream,
            0,
            scan.variant.id(),
            Exactness::Unknown
        ));
        let topology_transferred = if let Some(graph) = b5_graph.take() {
            let transferred = match crate::families::b5::transfer::transfer(
                &mut topology_ir,
                &mut topology_annotations,
                &graph,
                &payload_id,
                refusal,
                &mut admission,
            ) {
                Ok(transferred) => transferred,
                Err(error) => return Some(Err(error)),
            };
            drop(graph);
            if transferred {
                match neutral_model_is_admissible(ctx, &mut topology_ir, &unknowns) {
                    Ok(admissible) => admissible,
                    Err(limit) => return Some(Err(limit)),
                }
            } else {
                false
            }
        } else {
            false
        };
        if topology_transferred {
            ir = topology_ir;
            annotations = topology_annotations.into_retained();
        }
        let mut owned_carriers = BTreeMap::new();
        if !topology_transferred {
            let surfaces = match fallback_surfaces.take() {
                Some(surfaces) => surfaces,
                None => {
                    match freeform_surface_carriers(
                        &scan.data,
                        &sources,
                        &consolidated_records,
                        refusal,
                    ) {
                        Ok(surfaces) => surfaces,
                        Err(error) => return Some(Err(error)),
                    }
                }
            };
            for (index, surface) in surfaces.into_iter().enumerate() {
                let id = admitted!(crate::resource::compose_index_id(
                    &cadmpeg_ir::identity_namespace!("catia", "a8", "surf"),
                    index,
                    SurfaceId::mint
                ));
                admitted!(annotate(
                    &mut annotations,
                    &id,
                    "object_stream_a8_03",
                    u64_from_index(surface.pos),
                    &surface.source_tag,
                    Exactness::ByteExact
                ));
                admitted!(admission.charge());
                owned_carriers.insert(surface.pos, ir.geometry.surfaces.len());
                ir.geometry.surfaces.push(Surface {
                    id,
                    geometry: surface.geometry,
                    source_object: Some(surface.source_object),
                    native_ref: None,
                });
            }
        }
        // The bindings this call returns are read by the standard-family route
        // alone; here the call is made for the curves and surfaces it appends.
        if let Err(error) = append_consolidated_revolutions(
            &mut ir,
            &mut annotations,
            &resolved_consolidated_revolutions,
            &mut admission,
        ) {
            return Some(Err(error));
        }
        if let Err(error) =
            append_a8_rolling_ball_pools(&mut ir, &mut annotations, &scan.data, &mut admission)
        {
            return Some(Err(error));
        }
        owned_carriers.extend(admitted!(append_a5_rolling_ball_pools(
            &mut ir,
            &mut annotations,
            &scan.data,
            &consolidated_records,
            refusal,
            &mut admission,
        )));
        let body_selection = admitted!(container::body_selection::read(ctx, scan, &sources));
        let owned_patch_loss = if topology_transferred {
            None
        } else {
            admitted!(owned_patch::append(
                &mut ir,
                &mut annotations,
                &owned_patch::Stream {
                    data: &scan.data,
                    sources: &sources,
                    records: &consolidated_records,
                    selection: body_selection.as_ref(),
                },
                &owned_carriers,
                refusal,
                &mut admission,
            ))
        };
        if planar_two_edge_candidate {
            if let Err(error) = append_planar_two_edge_pool(
                &mut ir,
                &mut annotations,
                &scan.data,
                &consolidated_records,
                refusal,
                &mut admission,
            ) {
                return Some(Err(error));
            }
        }
        let line_profiles = admitted!(consolidated_line_profiles(
            &scan.data,
            &consolidated_records
        ));
        let mut standalone_wires = Vec::new();
        for profile in &line_profiles {
            let id = profile.curve.id.clone();
            standalone_wires.push((id, profile.range, profile.pos));
        }
        if let Err(error) = append_consolidated_line_profiles(
            &mut ir,
            &mut annotations,
            line_profiles,
            &mut admission,
        ) {
            return Some(Err(error));
        }
        for curve in b2_nurbs_curves {
            let id = admitted!(crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "b2", "nurbs-curve"),
                ir.geometry.curves.len(),
                CurveId::mint
            ));
            let parameter_range = curve.geometry.full_knot_endpoints();
            admitted!(annotate(
                &mut annotations,
                &id,
                "consolidated_b2_03_16",
                u64_from_index(curve.pos),
                format_args!("header_token:{:08x}", curve.header_token),
                Exactness::ByteExact
            ));
            admitted!(admission.charge());
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: id.clone(),
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve.geometry)),
                source_object: Some(admitted!(cgm_source_key(
                    "b2-nurbs-curve-frame",
                    format_args!("{:010}", curve.pos)
                ))),
                native_ref: None,
            });
            standalone_wires.push((id, parameter_range.endpoints(), curve.pos));
        }
        for curve in a5_nurbs_curves {
            let id = admitted!(crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "a5", "nurbs-curve"),
                ir.geometry.curves.len(),
                CurveId::mint
            ));
            let parameter_range = curve.geometry.full_knot_endpoints();
            admitted!(annotate(
                &mut annotations,
                &id,
                "consolidated_a5_13_16",
                u64_from_index(curve.pos),
                format_args!("header_token:{:08x}", curve.header_token),
                Exactness::ByteExact
            ));
            admitted!(admission.charge());
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: id.clone(),
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve.geometry)),
                source_object: Some(admitted!(cgm_source_key(
                    "a5-nurbs-curve-frame",
                    format_args!("{:010}", curve.pos)
                ))),
                native_ref: None,
            });
            standalone_wires.push((id, parameter_range.endpoints(), curve.pos));
        }
        for circle in b2_spatial_circles {
            let id = admitted!(crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "b2", "circle"),
                ir.geometry.curves.len(),
                CurveId::mint
            ));
            let parameter_range = [
                circle.range.lower() / circle.radius.get(),
                circle.range.upper() / circle.radius.get(),
            ];
            admitted!(annotate(
                &mut annotations,
                &id,
                "consolidated_b2_03_0f",
                u64_from_index(circle.pos),
                format_args!(
                    "header_token:{:08x}:range:{:?}:chart_shift:{}",
                    circle.header_token,
                    circle.range.endpoints(),
                    circle.chart_shift.get()
                ),
                Exactness::ByteExact
            ));
            admitted!(admission.charge());
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: id.clone(),
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Circle(
                    cadmpeg_ir::geometry::analytic::CircleCurve::new(
                        circle.center,
                        circle.frame,
                        circle.radius,
                    ),
                )),
                source_object: Some(admitted!(cgm_source_key(
                    "b2-spatial-circle-frame",
                    format_args!("{:010}", circle.pos)
                ))),
                native_ref: None,
            });
            standalone_wires.push((id, parameter_range, circle.pos));
        }
        let wire_topology_transferred = if !topology_transferred
            && ir.geometry.surfaces.is_empty()
            && standalone_wires.len() == ir.geometry.curves.len()
            && !standalone_wires.is_empty()
        {
            match attach_standalone_wires(
                &mut ir,
                &mut annotations,
                &standalone_wires,
                &mut admission,
            ) {
                Ok(transferred) => transferred,
                Err(error) => return Some(Err(error)),
            }
        } else {
            false
        };
        let surface_roster_census = if wire_topology_transferred {
            None
        } else {
            match scan.brep.as_deref() {
                Some(brep) => Some(admitted!(
                    crate::families::standard::records::surface_roster_census(ctx, brep)
                )),
                None => None,
            }
        };
        let mut losses = Vec::new();
        if !wire_topology_transferred {
            if topology_transferred {
                losses.push((CatiaLossCode::TopologyB5GaugeSubstituted).note(format!(
                "B5 topology was transferred. Its carrier-relative face-sense choices \
             and inferred body kind do not establish outward-shell orientation or source body dimension. Gauged b5 03 5f face records, by object id ({}): {}.",
                b5_face_object_ids.len(),
                identity_statement(&b5_face_object_ids)
            )));
            } else if object_stream_selection_exhausted {
                losses.push(
                    (CatiaLossCode::TopologyObjectStreamWorkSliceExhausted).note(format!(
            "The object-stream graph exceeds the bounded frame-index and record-materialization \
             work slice; its topology remains native. The {object_stream_run_count} object runs \
             stay inside retained record {payload_id}."
        )),
                );
            } else {
                losses.push((CatiaLossCode::TopologyB5GraphUnclosed).note(format!(
                    "Object-stream and consolidated NURBS carriers were decoded, but the \
             face/loop/pcurve/edge graph did not close. Unclosed b5 03 5f face records, by object \
             id ({}): {}. The records stay inside retained record {payload_id}.",
                    census_face_object_ids.len(),
                    identity_statement(&census_face_object_ids)
                )));
            }
        }
        losses.extend(owned_patch_loss);
        insert_unresolved_carrier_loss(&ir, &mut losses);
        if let Err(error) =
            link_payload_carriers(&ir, &mut unknowns[payload_index], &mut annotations)
        {
            return Some(Err(error));
        }
        let annotations = annotations.build();
        let mut coverage = cadmpeg_ir::report::decode::Coverage::default();
        coverage.record(
            crate::coverage::DECODED_OBJECT_STREAM_RUN_COUNT,
            object_stream_run_count,
        );
        coverage.record(
            crate::coverage::SELECTED_OBJECT_STREAM_RUN_COUNT,
            selected_object_stream_run_count,
        );
        coverage.record(
            crate::coverage::UNSELECTED_OBJECT_STREAM_RUN_COUNT,
            object_stream_run_count - selected_object_stream_run_count,
        );
        coverage.record(
            crate::coverage::EXHAUSTED_OBJECT_STREAM_SELECTION_COUNT,
            usize::from(object_stream_selection_exhausted),
        );
        if let Some(census) = surface_roster_census {
            coverage.record(crate::coverage::CLOSED_SURFACE_ROSTER_COUNT, census.rosters);
            coverage.record(
                crate::coverage::CLOSED_SURFACE_ROSTER_RECORD_COUNT,
                census.records,
            );
            coverage.record(
                crate::coverage::SUPPORTED_SURFACE_ROSTER_COUNT,
                census.supported_rosters,
            );
            coverage.record(
                crate::coverage::SUPPORTED_SURFACE_ROSTER_RECORD_COUNT,
                census.supported_records,
            );
        }
        coverage.record(
            crate::coverage::DECODED_B2_NURBS_CURVE_COUNT,
            b2_nurbs_curve_count,
        );
        coverage.record(
            crate::coverage::DECODED_A5_NURBS_CURVE_COUNT,
            a5_nurbs_curve_count,
        );
        coverage.record(
            crate::coverage::DECODED_B2_SPATIAL_CIRCLE_COUNT,
            b2_spatial_circle_count,
        );
        coverage.record(
            crate::coverage::ATTACHED_STANDALONE_WIRE_EDGE_COUNT,
            usize::from(wire_topology_transferred) * standalone_wires.len(),
        );
        if let Some([control_03, control_05, uncounted]) = face_terminal_controls {
            coverage.record(
                crate::coverage::RESOLVED_OBJECT_STREAM_FACE_TERMINAL_CONTROL_03_COUNT,
                control_03,
            );
            coverage.record(
                crate::coverage::RESOLVED_OBJECT_STREAM_FACE_TERMINAL_CONTROL_05_COUNT,
                control_05,
            );
            coverage.record(
                crate::coverage::RESOLVED_OBJECT_STREAM_UNCOUNTED_FACE_COUNT,
                uncounted,
            );
        }
        if topology_transferred {
            coverage.record(
                crate::coverage::TRANSFERRED_OBJECT_STREAM_FACE_COUNT,
                ir.geometry.faces.len(),
            );
            coverage.record(
                crate::coverage::TRANSFERRED_OBJECT_STREAM_LOOP_COUNT,
                ir.geometry.loops.len(),
            );
        }
        if let Some([control_03, control_05, uncounted, unresolved]) = typed_face_counts {
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_FACE_TERMINAL_CONTROL_03_COUNT,
                control_03,
            );
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_FACE_TERMINAL_CONTROL_05_COUNT,
                control_05,
            );
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_UNCOUNTED_FACE_COUNT,
                uncounted,
            );
            coverage.record(
                crate::coverage::TYPED_UNRESOLVED_OBJECT_STREAM_FACE_COUNT,
                unresolved,
            );
        }
        if typed_multi_surface_face_count != 0 {
            coverage.record(
                crate::coverage::TYPED_MULTI_SURFACE_OBJECT_STREAM_FACE_COUNT,
                typed_multi_surface_face_count,
            );
        }
        if let Some(counts) = edge_terminal_controls {
            for (key, count) in [
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_01_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_02_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_21_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_22_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_25_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_26_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_29_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_EDGE_TERMINAL_CONTROL_2A_COUNT,
            ]
            .into_iter()
            .zip(counts)
            {
                coverage.record(key, count);
            }
        }
        if let Some([control_00, control_04]) = vertex_incidence_terminal_controls {
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_TERMINAL_CONTROL_00_COUNT,
                control_00,
            );
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_TERMINAL_CONTROL_04_COUNT,
                control_04,
            );
        }
        if let Some([controls_03_03, controls_03_05, controls_05_03, controls_05_05, extended]) =
            resolved_loop_metadata_counts
        {
            for (key, count) in [
                (
                    crate::coverage::RESOLVED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_03_03_COUNT,
                    controls_03_03,
                ),
                (
                    crate::coverage::RESOLVED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_03_05_COUNT,
                    controls_03_05,
                ),
                (
                    crate::coverage::RESOLVED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_05_03_COUNT,
                    controls_05_03,
                ),
                (
                    crate::coverage::RESOLVED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_05_05_COUNT,
                    controls_05_05,
                ),
            ] {
                coverage.record(key, count);
            }
            coverage.record(
                crate::coverage::RESOLVED_OBJECT_STREAM_EXTENDED_LOOP_METADATA_COUNT,
                extended,
            );
        }
        if let Some((counts, unresolved)) = typed_loop_metadata_counts {
            for (key, count) in [
                crate::coverage::TYPED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_03_03_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_03_05_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_05_03_COUNT,
                crate::coverage::TYPED_OBJECT_STREAM_LOOP_FRAMING_CONTROLS_05_05_COUNT,
            ]
            .into_iter()
            .zip(counts[..4].iter().copied())
            {
                coverage.record(key, count);
            }
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_EXTENDED_LOOP_METADATA_COUNT,
                counts[4],
            );
            coverage.record(
                crate::coverage::TYPED_UNRESOLVED_OBJECT_STREAM_LOOP_COUNT,
                unresolved,
            );
        }
        if let Some(count) = class_21_suffix_scalar_count {
            coverage.record(
                crate::coverage::RESOLVED_OBJECT_STREAM_CLASS_21_PCURVE_SUFFIX_SCALAR_COUNT,
                count,
            );
        }
        if typed_class_21_pcurve_count != 0 {
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_CLASS_21_PCURVE_SUFFIX_SCALAR_COUNT,
                typed_class_21_pcurve_count,
            );
        }
        if !typed_parameter_incidences.is_empty() {
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_PARAMETER_INCIDENCE_COUNT,
                typed_parameter_incidences.len(),
            );
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_PARAMETER_INCIDENCE_MEMBER_COUNT,
                typed_parameter_incidence_member_count,
            );
        }
        if !typed_vertex_incidence_rosters.is_empty() {
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_ROSTER_COUNT,
                typed_vertex_incidence_rosters.len(),
            );
            coverage.record(
                crate::coverage::TYPED_OBJECT_STREAM_VERTEX_INCIDENCE_ROSTER_MEMBER_COUNT,
                typed_vertex_incidence_roster_member_count,
            );
        }
        Some(Ok(FamilyOutput {
            ir,
            report: DecodeBody {
                transfer: cadmpeg_ir::report::decode::DecodeTransfer::full(true),
                coverage,
                losses,
                notes: Vec::new(),
                transfer_ledger: cadmpeg_ir::report::decode::TransferLedger::default(),
            },
            annotations,
            unknowns,
            admitted_model_entities: admission.admitted(),
        }))
    })()
    .transpose()
}

fn attach_standalone_wires(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    wires: &[(CurveId, [f64; 2], usize)],
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<bool, cadmpeg_core::CodecError> {
    let mut plans = Vec::new();
    for (index, (curve_id, range, pos)) in wires.iter().enumerate() {
        let Some(geometry) = ir
            .geometry
            .curves
            .iter()
            .find(|curve| curve.id == *curve_id)
            .map(|curve| &curve.geometry)
        else {
            return Ok(false);
        };
        let Some(start) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::curve_point(admission.context(), geometry, range[0]),
            )?)?
        else {
            return Ok(false);
        };
        let Some(end) =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::curve_point(admission.context(), geometry, range[1]),
            )?)?
        else {
            return Ok(false);
        };
        let carrier_id = curve_id.clone();
        let Some(carrier) =
            cadmpeg_ir::topology::EdgeCarrier::new(Some(carrier_id), Some(*range)).ok()
        else {
            return Ok(false);
        };
        plans.push((index, carrier, *pos, start, end));
    }
    let body_id = BodyId::mint("catia:freeform:wire-body#0".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let region_id = RegionId::mint("catia:freeform:wire-region#0".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let shell_id = ShellId::mint("catia:freeform:wire-shell#0".to_owned())
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let mut edge_ids = Vec::new();
    for (index, ..) in &plans {
        let id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "freeform", "wire-edge"),
            *index,
            EdgeId::mint,
        )?;
        edge_ids.push(id);
    }
    let shell_owner_id = shell_id.clone();
    let shell_region_id = region_id.clone();
    if edge_ids.is_empty() {
        return Ok(false);
    }
    let shell = Shell::with_members(shell_id, shell_region_id, edge_ids, Vec::new());
    for id in [
        body_id.as_str(),
        region_id.as_str(),
        shell_owner_id.as_str(),
    ] {
        annotate(
            annotations,
            id,
            "consolidated_curve_wire",
            0,
            "standalone_wire_owner",
            Exactness::Inferred,
        )?;
    }
    for (index, carrier, pos, start, end) in plans {
        let point_ids = [
            PointId::mint(format!("catia:freeform:wire-point#{index}:start"))
                .map_err(cadmpeg_core::CodecError::malformed)?,
            PointId::mint(format!("catia:freeform:wire-point#{index}:end"))
                .map_err(cadmpeg_core::CodecError::malformed)?,
        ];
        let vertex_ids = [
            VertexId::mint(format!("catia:freeform:wire-vertex#{index}:start"))
                .map_err(cadmpeg_core::CodecError::malformed)?,
            VertexId::mint(format!("catia:freeform:wire-vertex#{index}:end"))
                .map_err(cadmpeg_core::CodecError::malformed)?,
        ];
        let edge_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "freeform", "wire-edge"),
            index,
            EdgeId::mint,
        )?;
        for id in [
            point_ids[0].as_str(),
            point_ids[1].as_str(),
            vertex_ids[0].as_str(),
            vertex_ids[1].as_str(),
            edge_id.as_str(),
        ] {
            annotate(
                annotations,
                id,
                "consolidated_curve_wire",
                u64_from_index(pos),
                "curve_domain_endpoint",
                Exactness::Derived,
            )?;
        }
        admission.charge()?;
        admission.charge()?;
        let vertex_point_ids = [point_ids[0].clone(), point_ids[1].clone()];
        let [start_point_id, end_point_id] = point_ids;
        ir.geometry.points.extend([
            Point::new(end_point_id, end, None),
            Point::new(start_point_id, start, None),
        ]);
        let edge_vertex_ids = [vertex_ids[0].clone(), vertex_ids[1].clone()];
        let [start_vertex_id, end_vertex_id] = vertex_ids;
        let [start_vertex_point_id, end_vertex_point_id] = vertex_point_ids;
        admission.charge()?;
        admission.charge()?;
        ir.geometry.vertices.extend([
            Vertex {
                id: end_vertex_id,
                point: end_vertex_point_id,
                tolerance: None,
                native_ref: None,
            },
            Vertex {
                id: start_vertex_id,
                point: start_vertex_point_id,
                tolerance: None,
                native_ref: None,
            },
        ]);
        let [start_edge_vertex_id, end_edge_vertex_id] = edge_vertex_ids;
        admission.charge()?;
        ir.geometry.edges.push(Edge {
            id: edge_id,
            carrier,
            ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                start_edge_vertex_id,
                end_edge_vertex_id,
            )),
            tolerance: None,
            native_ref: None,
        });
    }
    admission.charge()?;
    let region_body_id = body_id.clone();
    ir.geometry.bodies.push(Body {
        id: body_id,
        kind: BodyKind::Wire,
        transform: None,
        name: None,
        color: None,
        visible: None,
        native_ref: None,
    });
    admission.charge()?;
    let region_shells = vec![shell_owner_id];
    ir.geometry.regions.push(Region {
        id: region_id,
        body: region_body_id,
        shells: region_shells,
        native_ref: None,
    });
    admission.charge()?;
    ir.geometry.shells.push(shell);
    Ok(true)
}

fn freeform_surface_carriers(
    data: &[u8],
    sources: &[Vec<crate::wire::records::SourceExtent>],
    records: &[crate::wire::records::ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Result<Vec<FreeformSurfaceCarrier>, cadmpeg_core::CodecError> {
    let resolved = crate::families::a5a8::records::a8_surfaces_in_sources(data, sources, refusal)?;
    let a5 = crate::families::a5a8::records::a5_surfaces_from_records(data, records, refusal)?;
    let mut surfaces = Vec::new();
    for surface in resolved.into_iter().chain(a5) {
        let (source_object, source_tag) = freeform_surface_source(&surface)?;
        let source_tag = format!("freeform:{source_tag}");
        surfaces.push(FreeformSurfaceCarrier {
            pos: surface.pos,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(surface.geometry)),
            source_object,
            source_tag,
        });
    }
    for surface in crate::families::b2::records::b2_cylinders_from_records(data, records) {
        let source_object = cgm_source_key("b2-03-28-frame", format_args!("{:010}", surface.pos))?;
        let source_tag = format!("b2_03_28:frame_offset:{:010}", surface.pos);
        surfaces.push(FreeformSurfaceCarrier {
            pos: surface.pos,
            geometry: surface.surface_geometry(),
            source_object,
            source_tag,
        });
    }
    for surface in crate::families::b2::records::b2_cones_from_records(data, records) {
        let source_object = cgm_source_key("b2-03-29-frame", format_args!("{:010}", surface.pos))?;
        let source_tag = format!("b2_03_29:frame_offset:{:010}", surface.pos);
        surfaces.push(FreeformSurfaceCarrier {
            pos: surface.pos,
            geometry: crate::families::b2::records::b2_cone_geometry(&surface),
            source_object,
            source_tag,
        });
    }
    for surface in crate::families::b2::records::b2_spheres_from_records(data, records) {
        let source_object = cgm_source_key("b2-03-2a-frame", format_args!("{:010}", surface.pos))?;
        let source_tag = format!("b2_03_2a:frame_offset:{:010}", surface.pos);
        surfaces.push(FreeformSurfaceCarrier {
            pos: surface.pos,
            geometry: crate::families::b2::records::b2_sphere_geometry(&surface),
            source_object,
            source_tag,
        });
    }
    for surface in crate::families::b2::records::b2_tori_from_records(data, records) {
        let source_object = cgm_source_key("b2-03-2b-frame", format_args!("{:010}", surface.pos))?;
        let source_tag = format!("b2_03_2b:frame_offset:{:010}", surface.pos);
        surfaces.push(FreeformSurfaceCarrier {
            pos: surface.pos,
            geometry: crate::families::b2::records::b2_torus_geometry(&surface),
            source_object,
            source_tag,
        });
    }
    Ok(surfaces)
}

fn freeform_surface_source(
    surface: &crate::families::a5a8::records::FreeformSurface,
) -> Result<(cadmpeg_ir::SourceObjectAssociation, String), cadmpeg_core::CodecError> {
    Ok(match surface.identity {
        Some(object_id) => (
            cgm_source("surface", object_id)?,
            format!("object_id:{object_id:08x}"),
        ),
        None => (
            cgm_source_key("a5-surface-frame", format_args!("{:010}", surface.pos))?,
            format!("frame_offset:{:010}", surface.pos),
        ),
    })
}

/// Index standard carrier surfaces by their serialized carrier tag.
///
/// A consolidated pcurve support id is admitted as a standard carrier only
/// when that tag selects one decoded surface with known geometry. Duplicate
/// tags and unknown geometry remain explicitly unresolved; an allocation id
/// must not choose a face-local row by emission order.
fn standard_carrier_surface_ids(ir: &CadIr) -> HashMap<u32, Option<SurfaceId>> {
    let mut by_tag = HashMap::new();
    for surface in &ir.geometry.surfaces {
        let Some(source) = surface.source_object.as_ref() else {
            continue;
        };
        if source.format != cadmpeg_ir::codec_format!(crate::dialect::FORMAT) {
            continue;
        }
        let Some(tag) = source
            .object_id
            .as_str()
            .strip_prefix("cgm-carrier:")
            .and_then(|value| u32::from_str_radix(value, 16).ok())
        else {
            continue;
        };
        if let Some(selected) = by_tag.get_mut(&tag) {
            *selected = None;
            continue;
        }
        let candidate = (!matches!(
            surface.geometry,
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { .. })
        ))
        .then(|| surface.id.clone());
        by_tag.insert(tag, candidate);
    }
    by_tag
}

fn standard_carrier_endpoint_loci(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    pcurve: &PcurveGeometry,
    surface: &SurfaceGeometry,
    range: [f64; 2],
) -> Result<Option<[Point3; 2]>, cadmpeg_core::CodecError> {
    let start = match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::pcurve_uv(
        ctx, pcurve, range[0],
    ))? {
        Ok(start) => start,
        Err(cadmpeg_ir::eval::EvaluationFailure::ResourceLimit(limit)) => return Err(limit.into()),
        Err(_) => return Ok(None),
    };
    let end = match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::pcurve_uv(
        ctx, pcurve, range[1],
    ))? {
        Ok(end) => end,
        Err(cadmpeg_ir::eval::EvaluationFailure::ResourceLimit(limit)) => return Err(limit.into()),
        Err(_) => return Ok(None),
    };
    // A non-finite locus is kept as the evaluation reached it.
    let locus = |uv: cadmpeg_ir::units::FinitePoint2| -> Result<_, cadmpeg_core::CodecError> {
        match cadmpeg_ir::eval::decode::outer_refusal(cadmpeg_ir::eval::decode::surface_point(
            ctx, surface, uv.u, uv.v,
        ))? {
            Ok(point) => Ok(Some(point.get())),
            Err(failure) => Ok(failure.non_finite()?),
        }
    };
    let Some(start) = locus(start)? else {
        return Ok(None);
    };
    let Some(end) = locus(end)? else {
        return Ok(None);
    };
    Ok(Some([start, end]))
}

/// One exact consolidated line carrier: the curve it states, the wire interval
/// it owns, and the record position it was read at.
struct ConsolidatedLineProfile {
    curve: Curve,
    range: [f64; 2],
    pos: usize,
}

/// Every exact consolidated line carrier the records state, independently of
/// its parameter chart.
fn consolidated_line_profiles(
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
) -> Result<Vec<ConsolidatedLineProfile>, cadmpeg_core::CodecError> {
    let mut profiles = Vec::new();
    for (index, line) in
        crate::families::b2::records::b2_line_profiles_from_records(data, records).enumerate()
    {
        let id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "consolidated", "line-profile-curve"),
            index,
            CurveId::mint,
        )?;
        let payload =
            cadmpeg_ir::geometry::analytic::LineCurve::new(line.origin, line.direction.into());
        profiles.push(ConsolidatedLineProfile {
            curve: Curve {
                parameter_range: None,
                id,
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Line(payload)),
                source_object: Some(cgm_source_key(
                    "b2-03-0e-frame",
                    format_args!("{:010}", line.pos),
                )?),
                native_ref: None,
            },
            range: line.range.endpoints(),
            pos: line.pos,
        });
    }
    Ok(profiles)
}

/// Transfer every exact consolidated line carrier.
fn append_consolidated_line_profiles(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    profiles: Vec<ConsolidatedLineProfile>,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    for profile in profiles {
        annotate(
            annotations,
            &profile.curve.id,
            "consolidated_b2_03_0e",
            u64_from_index(profile.pos),
            "line_profile_carrier",
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        ir.geometry.curves.push(profile.curve);
    }
    Ok(())
}

fn append_planar_two_edge_pool(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    let planes = crate::families::b2::records::b2_plane_carriers_from_records(data, records);
    let [plane] = planes.as_slice() else {
        return Ok(());
    };
    let Some(geometry) = crate::families::b2::records::b2_plane_geometry(plane) else {
        return Ok(());
    };
    let Some(source_index) = records
        .iter()
        .find(|record| record.byte_offset() == plane.pos)
        .map(crate::wire::records::ConsolidatedRecord::source_index)
    else {
        return Ok(());
    };
    let Some(closed) =
        rolling_ball_patch::closed_patch(ir, &geometry, data, records, source_index, None, refusal)
    else {
        return Ok(());
    };
    let [Some(first), Some(second)] = closed
        .edges
        .each_ref()
        .map(|edge| rolling_ball_patch::fit_edge(ir, &geometry, edge, None))
    else {
        return Ok(());
    };
    let owners = records
        .windows(2)
        .filter(|pair| {
            pair[0].source_index() == source_index
                && pair[1].source_index() == source_index
                && pair[0].family() == crate::wire::records::ConsolidatedFamily::B
                && pair[0].class() == 0x62
                && pair[1].family() == crate::wire::records::ConsolidatedFamily::B
                && pair[1].class() == 0x5e
        })
        .map(|pair| pair[0].byte_offset())
        .collect::<Vec<_>>();
    let [owner_pos] = owners.as_slice() else {
        return Ok(());
    };
    let Some(face_orientation) =
        selected_singleton_face_orientation(data, records, source_index, *owner_pos)
    else {
        return Ok(());
    };
    attach_closed_two_edge_face(
        ir,
        annotations,
        TwoEdgeFace {
            closed: &closed,
            geometry,
            boundary_curves: [first, second],
            origin: ClosedFaceOrigin {
                source_kind: "planar",
                annotation_source: "consolidated_b2_03_27_face",
                carrier_pos: plane.pos,
                fitted_surface: false,
            },
            source_index,
            owner_pos: *owner_pos,
            desired_forward: Some(face_orientation),
            data,
            records,
        },
        refusal,
        admission,
    )?;
    Ok(())
}

fn selected_singleton_face_orientation(
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
    source_index: usize,
    owner_pos: usize,
) -> Option<bool> {
    let pair = records.windows(2).rfind(|pair| {
        pair[0].source_index() == source_index
            && pair[1].source_index() == source_index
            && pair[0].family() == crate::wire::records::ConsolidatedFamily::B
            && pair[0].class() == 0x61
            && pair[1].family() == crate::wire::records::ConsolidatedFamily::B
            && pair[1].class() == 0x5f
            && pair[1].byte_offset() < owner_pos
            && crate::wire::records::records_are_contiguous(pair)
    })?;
    let face_pos = pair[1].byte_offset();
    if records.iter().any(|record| {
        record.source_index() == source_index
            && record.byte_offset() > face_pos
            && record.byte_offset() < owner_pos
            && record.family() == crate::wire::records::ConsolidatedFamily::B
            && matches!(record.class(), 0x5f | 0x61 | 0x62)
    }) {
        return None;
    }
    crate::native::class61::singleton_face_orientation_bit(data, &pair[0])
}

fn append_a5_rolling_ball_pools(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<BTreeMap<usize, usize>, cadmpeg_core::CodecError> {
    let mut carriers = BTreeMap::new();
    let mut face_construction_positions = HashMap::new();
    for pair in records.windows(2) {
        if pair[1].family() == crate::wire::records::ConsolidatedFamily::B
            && pair[1].class() == 0x62
            && pair[0].source_index() == pair[1].source_index()
        {
            face_construction_positions
                .entry((pair[0].source_index(), pair[0].byte_offset()))
                .or_insert(pair[1].byte_offset());
        }
    }
    let rolling_ball_carriers =
        crate::families::b2::records::b2_rolling_ball_constructions_from_records(data, records)
            .into_iter()
            .filter_map(|construction| {
                let source = construction.source_index;
                let &owner = face_construction_positions.get(&(source, construction.pos))?;
                let start = records.partition_point(|record| record.source_index() < source);
                let end = start
                    + records[start..].partition_point(|record| record.source_index() == source);
                Some((construction.carrier_pos, (source, owner, start..end)))
            })
            .collect::<HashMap<_, _>>();
    let patch_limit = records
        .len()
        .max(1)
        .checked_mul(MAX_PATCH_RECORD_VISITS_PER_RECORD)
        .ok_or_else(|| cadmpeg_core::CodecError::malformed("CATIA patch work budget overflow"))?;
    let patch_budget = WorkBudget::new(patch_limit);
    for jet in crate::families::a5a8::records::a5_freeform_curves_from_records(data, records) {
        for second_limit in [false, true] {
            let Some(curve) = crate::families::a5a8::records::rolling_ball_limit_curve(
                &jet,
                second_limit,
                refusal,
            ) else {
                continue;
            };
            let side = usize::from(second_limit);
            let id = CurveId::mint(format!("catia:rolling-ball:limit#{}:{side}", jet.pos))
                .map_err(cadmpeg_core::CodecError::malformed)?;
            annotate(
                annotations,
                &id,
                "consolidated_a5_03_32",
                u64_from_index(jet.pos),
                format_args!("limit_{}", side + 1),
                Exactness::Derived,
            )?;
            admission.charge()?;
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id,
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve)),
                source_object: None,
                native_ref: None,
            });
        }
        let definition = jet.definition().ok_or_else(|| {
            cadmpeg_core::CodecError::malformed("invalid CATIA rolling-ball stations")
        })?;
        let surface_index = ir.geometry.surfaces.len();
        let surface_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "rolling-ball", "surf"),
            surface_index,
            SurfaceId::mint,
        )?;
        let procedural_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "rolling-ball", "construction"),
            ir.geometry.procedural_surfaces.len(),
            ProceduralSurfaceId::mint,
        )?;
        annotate(
            annotations,
            &surface_id,
            "consolidated_a5_03_32_cache",
            u64_from_index(jet.pos),
            format_args!("header_token:{:08x}", jet.header_token),
            Exactness::Unknown,
        )?;
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Procedural {
                construction: procedural_id.clone(),
                cache: None,
            },
            source_object: None,
            native_ref: None,
        });

        annotate(
            annotations,
            &procedural_id,
            "consolidated_a5_03_32",
            u64_from_index(jet.pos),
            format_args!("header_token:{:08x}", jet.header_token),
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        ir.geometry.procedural_surfaces.push(ProceduralSurface::new(
            procedural_id,
            definition,
            None,
        ));
        carriers.insert(jet.pos, surface_index);
        if let Some((source_index, owner_pos, source_records)) = rolling_ball_carriers
            .get(&jet.pos)
            .and_then(|(source, owner, range)| {
                patch_budget
                    .charge_by(range.len())
                    .then(|| (*source, *owner, &records[range.clone()]))
            })
        {
            let carrier = &ir.geometry.surfaces[surface_index].geometry;
            if let Some(closed) = rolling_ball_patch::closed_patch(
                ir,
                carrier,
                data,
                source_records,
                source_index,
                Some([0.0, 1.0]),
                refusal,
            ) {
                if let Some(patch) =
                    rolling_ball_patch::fit(ir, carrier, closed.u_range, closed.v_range)
                {
                    if let [Some(first), Some(second)] = closed.edges.each_ref().map(|edge| {
                        rolling_ball_patch::fit_edge(ir, carrier, edge, Some([0.0, 1.0]))
                    }) {
                        attach_closed_two_edge_face(
                            ir,
                            annotations,
                            TwoEdgeFace {
                                closed: &closed,
                                geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                                    patch,
                                )),
                                boundary_curves: [first, second],
                                origin: ClosedFaceOrigin {
                                    source_kind: "rolling-ball",
                                    annotation_source: "consolidated_a5_03_32_face",
                                    carrier_pos: jet.pos,
                                    fitted_surface: true,
                                },
                                source_index,
                                owner_pos,
                                desired_forward: None,
                                data,
                                records,
                            },
                            refusal,
                            admission,
                        )?;
                    }
                }
            }
        }
    }

    if patch_budget.exhausted() {
        refusal.push_sheet_patch_search_bounded(
            "rolling-ball patch search",
            patch_limit,
            "record visits",
        );
    }
    Ok(carriers)
}

#[derive(Clone, Copy)]
struct ClosedFaceOrigin {
    source_kind: &'static str,
    annotation_source: &'static str,
    carrier_pos: usize,
    fitted_surface: bool,
}

struct TwoEdgeFace<'a> {
    closed: &'a rolling_ball_patch::ClosedPatch,
    geometry: SurfaceGeometry,
    boundary_curves: [NurbsCurve; 2],
    origin: ClosedFaceOrigin,
    source_index: usize,
    owner_pos: usize,
    desired_forward: Option<bool>,
    data: &'a [u8],
    records: &'a [crate::wire::records::ConsolidatedRecord],
}

fn attach_closed_two_edge_face(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    face: TwoEdgeFace<'_>,
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    let TwoEdgeFace {
        closed,
        geometry,
        boundary_curves,
        origin:
            ClosedFaceOrigin {
                source_kind,
                annotation_source,
                carrier_pos,
                fitted_surface,
            },
        source_index,
        owner_pos,
        desired_forward,
        data,
        records,
    } = face;
    let source_records = records
        .iter()
        .filter(|record| record.source_index() == source_index)
        .cloned()
        .collect::<Vec<_>>();
    let next_owner = source_records
        .iter()
        .filter(|record| {
            record.family() == crate::wire::records::ConsolidatedFamily::B
                && record.class() == 0x62
                && record.byte_offset() > owner_pos
        })
        .map(crate::wire::records::ConsolidatedRecord::byte_offset)
        .min();
    let boundary_nodes =
        crate::families::b2::records::b2_edge_nodes_from_records(data, &source_records)
            .filter(|node| node.pos > owner_pos && next_owner.is_none_or(|next| node.pos < next))
            .collect::<Vec<_>>();
    if boundary_nodes.len() != 2 {
        return Ok(());
    }
    let Some((positions, same_order)) = closed.shared_vertices() else {
        return Ok(());
    };
    let [Some(first_point), Some(second_point)] = positions.map(FinitePoint3::new) else {
        return Ok(());
    };
    let Some(owner) = source_records
        .iter()
        .find(|record| record.byte_offset() == owner_pos)
    else {
        return Ok(());
    };
    if crate::families::b2::records::b2_two_edge_owner_relation(data, owner, &boundary_nodes)
        != Some(same_order)
    {
        return Ok(());
    }
    let Some(loop_is_forward) = closed.loop_is_forward(same_order) else {
        return Ok(());
    };
    let face_is_forward = desired_forward.unwrap_or(loop_is_forward);
    let reverse_loop = loop_is_forward != face_is_forward;
    let mint =
        |kind: &str, suffix: &str| format!("catia:{source_kind}:{kind}#{carrier_pos}:{suffix}");
    let body_id = BodyId::mint(mint("body", "0")).map_err(cadmpeg_core::CodecError::malformed)?;
    let region_id =
        RegionId::mint(mint("region", "0")).map_err(cadmpeg_core::CodecError::malformed)?;
    let shell_id =
        ShellId::mint(mint("shell", "0")).map_err(cadmpeg_core::CodecError::malformed)?;
    let face_id = FaceId::mint(mint("face", "0")).map_err(cadmpeg_core::CodecError::malformed)?;
    let loop_id = LoopId::mint(mint("loop", "0")).map_err(cadmpeg_core::CodecError::malformed)?;
    let point_ids = [0, 1]
        .map(|index| PointId::mint(mint("point", &index.to_string())))
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let vertex_ids = [0, 1]
        .map(|index| VertexId::mint(mint("vertex", &index.to_string())))
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let edge_ids = [0, 1]
        .map(|index| EdgeId::mint(mint("edge", &index.to_string())))
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let coedge_ids = [0, 1]
        .map(|index| CoedgeId::mint(mint("coedge", &index.to_string())))
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let pcurve_ids = [0, 1]
        .map(|index| PcurveId::mint(mint("pcurve", &index.to_string())))
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(cadmpeg_core::CodecError::malformed)?;
    let ring_coedges = if reverse_loop {
        coedge_ids.iter().rev().cloned().collect()
    } else {
        coedge_ids.clone()
    };
    let Ok(ring) = LoopRing::new(ring_coedges, Vec::new()) else {
        return Ok(());
    };
    let [first_id, second_id] = closed.edges.each_ref().map(|edge| {
        CurveId::mint(mint("boundary", &edge.pos.to_string()))
            .map_err(cadmpeg_core::CodecError::malformed)
    });
    let curve_ids = [first_id?, second_id?];
    let [Ok(first_carrier), Ok(second_carrier)] = [0, 1].map(|index| {
        cadmpeg_ir::topology::EdgeCarrier::new(
            Some(curve_ids[index].clone()),
            Some(closed.edges[index].range),
        )
    }) else {
        return Ok(());
    };
    let (surface_kind, surface_source, surface_tag, boundary_source) = if fitted_surface {
        (
            "patch",
            "consolidated_a5_03_32_patch",
            "closed_pcurve_fit",
            "consolidated_a5_03_32_boundary",
        )
    } else {
        (
            "surface",
            annotation_source,
            "plane_carrier",
            "consolidated_b2_03_27_boundary",
        )
    };
    let surface_id = SurfaceId::mint(format!("catia:{source_kind}:{surface_kind}#{carrier_pos}"))
        .map_err(cadmpeg_core::CodecError::malformed)?;
    annotate(
        annotations,
        &surface_id,
        surface_source,
        u64_from_index(carrier_pos),
        surface_tag,
        Exactness::Derived,
    )?;
    admission.charge()?;
    ir.geometry.surfaces.push(Surface {
        id: surface_id.clone(),
        geometry,
        source_object: None,
        native_ref: None,
    });
    for ((id, curve), edge) in curve_ids
        .into_iter()
        .zip(boundary_curves)
        .zip(&closed.edges)
    {
        annotate(
            annotations,
            &id,
            boundary_source,
            u64_from_index(edge.pos),
            "closed_pcurve_lift",
            Exactness::Derived,
        )?;
        admission.charge()?;
        ir.geometry.curves.push(Curve {
            id,
            parameter_range: None,
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(curve)),
            source_object: None,
            native_ref: None,
        });
    }
    for id in [
        body_id.as_str(),
        region_id.as_str(),
        shell_id.as_str(),
        face_id.as_str(),
        loop_id.as_str(),
    ] {
        annotate(
            annotations,
            id,
            annotation_source,
            u64_from_index(carrier_pos),
            "closed_two_edge_patch",
            Exactness::Inferred,
        )?;
    }
    annotations.field_exactness(&face_id, "sense", Exactness::Inferred)?;
    for (index, position) in [first_point, second_point].into_iter().enumerate() {
        for id in [point_ids[index].as_str(), vertex_ids[index].as_str()] {
            annotate(
                annotations,
                id,
                annotation_source,
                u64_from_index(carrier_pos),
                "shared_boundary_endpoint",
                Exactness::Derived,
            )?;
        }
        admission.charge()?;
        ir.geometry
            .points
            .push(Point::new(point_ids[index].clone(), position, None));
        admission.charge()?;
        ir.geometry.vertices.push(Vertex {
            id: vertex_ids[index].clone(),
            point: point_ids[index].clone(),
            tolerance: None,
            native_ref: None,
        });
    }
    for (index, carrier) in [first_carrier, second_carrier].into_iter().enumerate() {
        let end_vertices = if index == 0 || same_order {
            [vertex_ids[0].clone(), vertex_ids[1].clone()]
        } else {
            [vertex_ids[1].clone(), vertex_ids[0].clone()]
        };
        for id in [
            edge_ids[index].as_str(),
            coedge_ids[index].as_str(),
            pcurve_ids[index].as_str(),
        ] {
            annotate(
                annotations,
                id,
                annotation_source,
                u64_from_index(closed.edges[index].pos),
                "closed_boundary",
                Exactness::Derived,
            )?;
        }
        admission.charge()?;
        ir.geometry.edges.push(Edge {
            id: edge_ids[index].clone(),
            carrier,
            ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                end_vertices[0].clone(),
                end_vertices[1].clone(),
            )),
            tolerance: None,
            native_ref: None,
        });
        admission.charge()?;
        ir.geometry.pcurves.push(Pcurve {
            id: pcurve_ids[index].clone(),
            geometry: closed.edges[index].geometry.clone(),
            metadata: cadmpeg_ir::geometry::pcurve::PcurveMetadata::default(),
            native_ref: None,
        });
        admission.charge()?;
        ir.geometry.coedges.push(Coedge {
            id: coedge_ids[index].clone(),
            owner_loop: loop_id.clone(),
            edge: edge_ids[index].clone(),
            radial_next: coedge_ids[index].clone(),
            sense: if (index == 0 || !same_order) == reverse_loop {
                Sense::Reversed
            } else {
                Sense::Forward
            },
            pcurves: vec![PcurveUse {
                pcurve: pcurve_ids[index].clone(),
                isoparametric: None,
                parameter_range: None,
            }],
            use_curve: None,
            native_ref: None,
        });
    }
    admission.charge()?;
    ir.geometry.loops.push(Loop {
        id: loop_id.clone(),
        face: face_id.clone(),
        boundary: LoopBoundary::Ring(ring),
        native_ref: None,
    });
    admission.charge()?;
    ir.geometry.faces.push(Face {
        id: face_id.clone(),
        shell: shell_id.clone(),
        surface: surface_id,
        sense: if face_is_forward {
            Sense::Forward
        } else {
            Sense::Reversed
        },
        loops: FaceLoops::classified(loop_id, Vec::new()),
        name: None,
        color: None,
        tolerance: None,
        native_ref: None,
    });
    admission.charge()?;
    ir.geometry
        .shells
        .push(Shell::new(shell_id.clone(), region_id.clone()));
    admission.charge()?;
    ir.geometry.regions.push(Region {
        id: region_id.clone(),
        body: body_id.clone(),
        shells: vec![shell_id],
        native_ref: None,
    });
    admission.charge()?;
    ir.geometry.bodies.push(Body {
        id: body_id,
        kind: BodyKind::Sheet,
        transform: None,
        name: None,
        color: None,
        visible: None,
        native_ref: None,
    });
    refusal.push_two_edge_binding_inferred(owner_pos, desired_forward.is_some());
    if fitted_surface {
        refusal.push_sheet_surface_fitted(1, 0, 0, 0);
    }
    Ok(())
}

/// Append standalone freeform carriers and return the number of consolidated
/// surface curves bound to existing standard edges.
pub(super) fn append_freeform_surface_pools(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    source: (&[u8], &[Vec<crate::wire::records::SourceExtent>]),
    records: &[crate::wire::records::ConsolidatedRecord],
    surface_alias_tags: &HashMap<u32, Option<u32>>,
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<ConsolidatedCurveBindingCounts, cadmpeg_core::CodecError> {
    let (data, sources) = source;
    let mut surfaces =
        crate::families::a5a8::records::a8_surfaces_in_sources(data, sources, refusal)?;
    let a5 = crate::families::a5a8::records::a5_surfaces_from_records(data, records, refusal)?;

    surfaces.extend(a5);
    let mut carrier_ids = Vec::new();
    for surface in &surfaces {
        let (source_object, source_tag) = freeform_surface_source(surface)?;
        let index = ir.geometry.surfaces.len();
        let id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "freeform", "surf"),
            index,
            SurfaceId::mint,
        )?;
        carrier_ids.push(id.clone());
        annotate(
            annotations,
            &id,
            "object_stream_a8_03_or_consolidated_a5_03",
            u64_from_index(surface.pos),
            source_tag,
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id,
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                surface.geometry.clone(),
            )),
            source_object: Some(source_object),
            native_ref: None,
        });
    }

    let offsets = crate::families::b2::records::b2_offset_supports_from_records(data, records);
    let bindings = crate::families::b2::records::offset_support_carriers(&offsets, &surfaces);
    for (offset, carrier) in offsets
        .iter()
        .zip(bindings)
        .filter_map(|(offset, carrier)| Some((offset, carrier?)))
    {
        let surface_index = ir.geometry.surfaces.len();
        let surface_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "offset", "surf"),
            surface_index,
            SurfaceId::mint,
        )?;
        annotate(
            annotations,
            &surface_id,
            "consolidated_b2_03_31_cache",
            u64_from_index(offset.pos),
            format_args!("support_ref:{:08x}", offset.support_id),
            Exactness::Unknown,
        )?;
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });

        let procedural_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "offset", "construction"),
            ir.geometry.procedural_surfaces.len(),
            ProceduralSurfaceId::mint,
        )?;
        annotate(
            annotations,
            &procedural_id,
            "consolidated_b2_03_31",
            u64_from_index(offset.pos),
            format_args!("support_ref:{:08x}", offset.support_id),
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        let _attached = ir.geometry.add_procedural_surface(
            &surface_id,
            ProceduralSurface::new(
                procedural_id,
                ProceduralSurfaceDefinition::Offset(
                    cadmpeg_ir::geometry::surface_payloads::OffsetSurfaceConstruction::legacy(
                        carrier_ids[carrier].clone(),
                        offset.distance,
                        None,
                        None,
                        false,
                        cadmpeg_ir::geometry::LegacyExtensionFlags::Absent {},
                        None,
                    ),
                ),
                Some(RecordBounds::from_corners(offset.u_range, offset.v_range)),
            ),
        );
    }

    append_consolidated_line_profiles(
        ir,
        annotations,
        consolidated_line_profiles(data, records)?,
        admission,
    )?;

    for guide in crate::families::a5a8::records::a5_guide_curves_from_records(data, records) {
        let solution = {
            let mut points = Vec::new();
            let mut first = Vec::new();
            let mut second = Vec::new();
            for site in &guide.sites {
                points.push(site.point.get());
                {
                    let value = site.first_derivative;
                    first.push([value[0], value[1], value[2]]);
                }
                {
                    let value = site.second_derivative;
                    second.push([value[0], value[1], value[2]]);
                }
            }
            let distinct_knots = guide.knots();
            crate::nurbs::quintic_jet_bspline(
                guide.degree,
                &distinct_knots,
                &points,
                &first,
                &second,
            )
        };
        let Some((knots, control_points)) = solution else {
            continue;
        };
        let mut poles = Vec::new();

        poles.extend(
            control_points
                .into_iter()
                .map(|point| Point3::new(point[0], point[1], point[2])),
        );
        let geometry = NurbsCurve::from_lanes(guide.degree, knots, poles, None, false)?;
        let id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "guide", "curve"),
            ir.geometry.curves.len(),
            CurveId::mint,
        )?;
        annotate(
            annotations,
            &id,
            "consolidated_a5_03_39",
            u64_from_index(guide.pos),
            format_args!("header_token:{:08x}", guide.header_token),
            Exactness::Derived,
        )?;
        admission.charge()?;
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id,
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(geometry)),
            source_object: None,
            native_ref: None,
        });
    }

    append_a5_rolling_ball_pools(ir, annotations, data, records, refusal, admission)?;

    append_a8_rolling_ball_pools(ir, annotations, data, admission)?;
    let counts = append_resolved_consolidated_surface_curves(
        ir,
        annotations,
        data,
        records,
        FreeformSurfacePool {
            surfaces: &surfaces,
            surface_ids: &carrier_ids,
            surface_alias_tags,
        },
        refusal,
        admission,
    )?;
    Ok(counts)
}

type ConsolidatedCarrierKey = (usize, Option<u64>);

enum ConsolidatedCarrierChart<'a> {
    Identity,
    Cylinder {
        radius: f64,
    },
    Cone {
        cone: &'a crate::families::b2::records::B2Cone,
    },
    Torus {
        torus: &'a crate::families::b2::records::B2Torus,
    },
    /// Plane isometry carrying a stored chart onto a target plane's chart.
    Rigid {
        /// Row-major linear part.
        linear: [[f64; 2]; 2],
        /// Translation applied to positions only.
        offset: [f64; 2],
    },
}

#[derive(Clone, Copy, Default)]
pub(in crate::families) struct ConsolidatedCurveBindingCounts {
    pub(super) standard_edges: usize,
    pub(in crate::families) widened_vertices: usize,
    pub(in crate::families) max_vertex_widening: f64,
    pub(super) partner_supports: usize,
    pub(super) partner_face_pcurve_pairs: usize,
    pub(super) standard_face_surfaces: usize,
    /// Coedge pcurves bound after the endpoint-lift witness.
    pub(super) standard_face_pcurves: usize,
    /// Recharts rejected because the derived pcurve coordinates were non-finite.
    pub(super) rechart_numeric_failures: usize,
}

struct ConsolidatedStandardFaceBinding {
    coedges: Vec<(usize, PcurveGeometry)>,
    standard_surfaces: [SurfaceId; 2],
    edge_pcurves: [PcurveGeometry; 2],
    inferred_partner: Option<(usize, usize)>,
}

impl ConsolidatedCarrierChart<'_> {
    fn point(&self, [u, v]: [f64; 2]) -> [f64; 2] {
        match self {
            Self::Identity => [u, v],
            Self::Cylinder { radius } => [u / radius, v],
            Self::Cone { cone } => [
                u / cone.angular_scale.get(),
                (v - cone.slant_range.lower()) * cone.half_angle.get().cos(),
            ],
            Self::Torus { torus } => [u / torus.major_scale.get(), v / torus.minor_scale.get()],
            Self::Rigid { linear, offset } => [
                linear[0][0] * u + linear[0][1] * v + offset[0],
                linear[1][0] * u + linear[1][1] * v + offset[1],
            ],
        }
    }

    fn derivative(&self, [u, v]: [f64; 2]) -> [f64; 2] {
        match self {
            Self::Identity => [u, v],
            Self::Cylinder { radius } => [u / radius, v],
            Self::Cone { cone } => [
                u / cone.angular_scale.get(),
                v * cone.half_angle.get().cos(),
            ],
            Self::Torus { torus } => [u / torus.major_scale.get(), v / torus.minor_scale.get()],
            Self::Rigid { linear, .. } => [
                linear[0][0] * u + linear[0][1] * v,
                linear[1][0] * u + linear[1][1] * v,
            ],
        }
    }
}

fn consolidated_jet_pcurve(
    pcurve: &crate::wire::records::ConsolidatedPcurve,
    chart: &ConsolidatedCarrierChart<'_>,
    refusal: &mut crate::nurbs::LaneRefusals,
) -> Option<PcurveGeometry> {
    let mut points = Vec::new();
    let mut first = Vec::new();
    let mut second = Vec::new();
    let mut knots = Vec::new();
    for site in &pcurve.sites {
        points.push(chart.point(site.point.get()));
        first.push(chart.derivative(site.first_derivatives.get()));
        second.push(chart.derivative(site.second_derivatives.get()));
        knots.push(site.knot.get());
    }
    quintic_jet_pcurve(
        crate::wire::records::ConsolidatedPcurve::DEGREE,
        &knots,
        &points,
        (&first, &second),
        refusal,
        format_args!(
            "consolidated quintic-jet pcurve record at byte {}",
            pcurve.pos
        ),
    )
}

/// Transfer resolved consolidated surface curves, reusing an existing
/// pcurve-less standard edge construction when endpoint loci select one.
/// The freeform surface pool a consolidated surface curve binds against.
///
/// The surfaces, the ids they were emitted under, and the alias tags that
/// name them are one pool: the ids are index-aligned with the surfaces, and
/// the alias tags resolve a record's support onto the same pool.
#[derive(Clone, Copy)]
struct FreeformSurfacePool<'a> {
    /// Decoded freeform surfaces in emission order.
    surfaces: &'a [crate::families::a5a8::records::FreeformSurface],
    /// Ids the surfaces were emitted under, index-aligned with `surfaces`.
    surface_ids: &'a [SurfaceId],
    /// Support alias tags that resolve a record's support onto the pool.
    surface_alias_tags: &'a HashMap<u32, Option<u32>>,
}

fn append_resolved_consolidated_surface_curves(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    data: &[u8],
    records: &[crate::wire::records::ConsolidatedRecord],
    pool: FreeformSurfacePool<'_>,
    refusal: &mut crate::nurbs::LaneRefusals,
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<ConsolidatedCurveBindingCounts, cadmpeg_core::CodecError> {
    let FreeformSurfacePool {
        surfaces: freeform_surfaces,
        surface_ids: freeform_surface_ids,
        surface_alias_tags,
    } = pool;
    let ctx = admission.context();
    let mut standalone = HashMap::new();
    for cylinder in crate::families::b2::records::b2_cylinders_from_records(data, records) {
        standalone.insert(cylinder.pos, cylinder);
    }
    let mut cones = HashMap::new();
    for cone in crate::families::b2::records::b2_cones_from_records(data, records) {
        cones.insert(cone.pos, cone);
    }
    let mut spheres = HashMap::new();
    for sphere in crate::families::b2::records::b2_spheres_from_records(data, records) {
        spheres.insert(sphere.pos, sphere);
    }
    let mut tori = HashMap::new();
    for torus in crate::families::b2::records::b2_tori_from_records(data, records) {
        tori.insert(torus.pos, torus);
    }
    let mut planes = HashMap::new();
    for plane in crate::families::b2::records::b2_plane_carriers_from_records(data, records) {
        planes.insert(plane.pos, plane);
    }
    let mut complete_runs = HashMap::new();
    for run in crate::families::consolidated::records::consolidated_topology_edge_runs_from_records(
        data, records,
    )? {
        complete_runs.insert(run.edge.pcurves[0].pos, run);
    }

    let mut surface_ids = HashMap::<ConsolidatedCarrierKey, SurfaceId>::new();
    let standard_carrier_surfaces = standard_carrier_surface_ids(ir);
    let mut point_positions = HashMap::new();
    for point in &ir.geometry.points {
        let id = point.id.clone();
        point_positions.insert(id, point.position().get());
    }
    let mut vertex_positions = HashMap::new();
    let mut vertex_tolerances = HashMap::new();
    for vertex in &ir.geometry.vertices {
        if let Some(position) = point_positions.get(&vertex.point) {
            let id = vertex.id.clone();
            vertex_positions.insert(id, *position);
        }
        let id = vertex.id.clone();
        vertex_tolerances.insert(id, vertex.tolerance);
    }
    let mut curve_indices = HashMap::new();
    for (index, curve) in ir.geometry.curves.iter().enumerate() {
        let id = curve.id.clone();
        curve_indices.insert(id, index);
    }
    let mut face_surfaces = HashMap::new();
    let mut face_tolerances = HashMap::new();
    for face in &ir.geometry.faces {
        let face_id = face.id.clone();
        let surface_id = face.surface.clone();
        face_surfaces.insert(face_id, surface_id);
        let face_id = face.id.clone();
        face_tolerances.insert(face_id, face.tolerance);
    }
    let mut loop_surfaces = HashMap::new();
    for loop_ in &ir.geometry.loops {
        let Some(surface_id) = face_surfaces.get(&loop_.face) else {
            continue;
        };
        let loop_id = loop_.id.clone();
        let surface_id = surface_id.clone();
        loop_surfaces.insert(loop_id, surface_id);
    }
    let mut coedge_surfaces = Vec::new();
    let mut coedge_face_tolerances = Vec::new();
    for coedge in &ir.geometry.coedges {
        let surface = loop_surfaces.get(&coedge.owner_loop).cloned();
        coedge_surfaces.push(surface);
        let tolerance = ir
            .geometry
            .loops
            .iter()
            .find(|value| value.id == coedge.owner_loop)
            .and_then(|loop_| face_tolerances.get(&loop_.face).copied().flatten());
        coedge_face_tolerances.push(tolerance);
    }
    let mut attachable_edges = Vec::new();
    for (edge_index, edge) in ir.geometry.edges.iter().enumerate() {
        let candidate = (|| {
            let curve_id = edge.curve()?;
            let curve_index = *curve_indices.get(curve_id)?;
            let CurveGeometry::Procedural {
                construction,
                cache: Some(cache),
            } = &ir.geometry.curves[curve_index].geometry
            else {
                return None;
            };
            if !matches!(cache, SolvedCurveGeometry::Unknown { .. }) {
                return None;
            }
            let mut procedure_match = None;
            for (index, procedure) in ir.geometry.procedural_curves.iter().enumerate() {
                if procedure.id != *construction {
                    continue;
                }
                let ProceduralCurveDefinition::Intersection { context, .. } =
                    procedure.definition()
                else {
                    continue;
                };
                let sides = context.sides();
                let (Some(first), Some(second)) = (
                    (sides[0].pcurve.is_none())
                        .then_some(sides[0].surface.as_ref())
                        .flatten(),
                    (sides[1].pcurve.is_none())
                        .then_some(sides[1].surface.as_ref())
                        .flatten(),
                ) else {
                    continue;
                };
                if procedure_match.replace((index, [first, second])).is_some() {
                    return None;
                }
            }
            let (procedure_index, standard_surfaces) = procedure_match?;
            Some((
                edge_index,
                procedure_index,
                curve_id,
                standard_surfaces,
                [
                    *edge
                        .start()
                        .and_then(|vertex| vertex_positions.get(vertex))?,
                    *edge.end().and_then(|vertex| vertex_positions.get(vertex))?,
                ],
            ))
        })();
        let Some((edge_index, procedure_index, curve_id, surfaces, points)) = candidate else {
            continue;
        };
        let curve_id = curve_id.clone();
        let standard_surfaces = [surfaces[0].clone(), surfaces[1].clone()];
        attachable_edges.push((
            edge_index,
            procedure_index,
            curve_id,
            standard_surfaces,
            points,
        ));
    }
    let mut attached_curves = HashSet::new();
    let mut binding_counts = ConsolidatedCurveBindingCounts::default();
    let mut partner_support_blocks = HashSet::new();

    let mut pending = VecDeque::new();
    for resolved in
        crate::families::consolidated::records::resolve_consolidated_edge_blocks_from_records(
            ctx, data, records, refusal,
        )?
    {
        pending.push_back(resolved);
    }
    while let Some(mut resolved) = pending.pop_front() {
        let Some(run) = complete_runs.get(&resolved.block.pcurves[0].pos) else {
            continue;
        };
        let mut sides: [IntcurveSupportSide; 2] = std::array::from_fn(|_| IntcurveSupportSide {
            surface: None,
            pcurve: None,
        });
        let mut standard_endpoint_loci = None;
        for (side, binding) in resolved.supports.iter().enumerate() {
            let pcurve = &resolved.block.pcurves[side];
            let support_tag = match surface_alias_tags.get(&pcurve.support_id) {
                Some(canonical) => canonical.as_ref().copied(),
                None => Some(pcurve.support_id),
            };
            if let Some(surface_id) =
                support_tag.and_then(|tag| standard_carrier_surfaces.get(&tag))
            {
                let Some(surface_id) = surface_id else {
                    continue;
                };
                let Some(surface_geometry) = ir
                    .geometry
                    .surfaces
                    .iter()
                    .find(|surface| surface.id == *surface_id)
                    .map(|surface| &surface.geometry)
                else {
                    continue;
                };
                let Some(geometry) =
                    consolidated_jet_pcurve(pcurve, &ConsolidatedCarrierChart::Identity, refusal)
                else {
                    continue;
                };
                if standard_endpoint_loci.is_none() {
                    standard_endpoint_loci = standard_carrier_endpoint_loci(
                        admission.context(),
                        &geometry,
                        surface_geometry,
                        resolved.block.parameters.range.endpoints(),
                    )?;
                }
                sides[side] = IntcurveSupportSide {
                    surface: Some(surface_id.clone()),
                    pcurve: Some(geometry.into()),
                };
                continue;
            }
            if let Some(
                crate::families::consolidated::records::ConsolidatedSupportBinding::NurbsCarrier {
                    pos,
                    offset,
                },
            ) = binding
            {
                let Some((carrier_index, _)) = freeform_surfaces
                    .iter()
                    .enumerate()
                    .find(|(_, surface)| surface.pos == *pos)
                else {
                    continue;
                };
                let Some(support) = freeform_surface_ids.get(carrier_index) else {
                    continue;
                };
                let support = support.clone();
                let surface = if offset.get() == 0.0 {
                    support
                } else {
                    let key = (*pos, Some(offset.get().to_bits()));
                    if let Some(id) = surface_ids.get(&key) {
                        id.clone()
                    } else {
                        let id = crate::resource::compose_index_id(
                            &cadmpeg_ir::identity_namespace!(
                                "catia",
                                "consolidated",
                                "nurbs-offset"
                            ),
                            ir.geometry.surfaces.len(),
                            SurfaceId::mint,
                        )?;
                        annotate(
                            annotations,
                            &id,
                            "consolidated_a5_03_34_offset_cache",
                            u64_from_index(*pos),
                            "resolved_pcurve_support",
                            Exactness::Unknown,
                        )?;
                        admission.charge()?;
                        let surface_owner_id = id.clone();
                        ir.geometry.surfaces.push(Surface {
                            id: surface_owner_id,
                            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown {
                                record: None,
                            }),
                            source_object: None,
                            native_ref: None,
                        });
                        let procedural_id = crate::resource::compose_index_id(
                            &cadmpeg_ir::identity_namespace!(
                                "catia",
                                "consolidated",
                                "nurbs-offset-construction"
                            ),
                            ir.geometry.procedural_surfaces.len(),
                            ProceduralSurfaceId::mint,
                        )?;
                        annotate(
                            annotations,
                            &procedural_id,
                            "consolidated_a5_03_34_constant_normal_offset",
                            u64_from_index(*pos),
                            "resolved_pcurve_support",
                            Exactness::Derived,
                        )?;
                        admission.charge()?;
                        let procedural_owner_id = id.clone();
                        let _attached = ir.geometry.add_procedural_surface(&procedural_owner_id, ProceduralSurface::new(
                                procedural_id,
                                ProceduralSurfaceDefinition::Offset(
                                    cadmpeg_ir::geometry::surface_payloads::OffsetSurfaceConstruction::legacy(
                                        support,
                                        *offset,
                                        None,
                                        None,
                                        false,
                                        cadmpeg_ir::geometry::LegacyExtensionFlags::Absent {},
                                        None,
                                    ),
                                ),
                                None,
                            ));
                        let stored_id = id.clone();
                        surface_ids.insert(key, stored_id);
                        id
                    }
                };
                let chart = ConsolidatedCarrierChart::Identity;
                let Some(geometry) = consolidated_jet_pcurve(pcurve, &chart, refusal) else {
                    continue;
                };
                sides[side] = IntcurveSupportSide {
                    surface: Some(surface),
                    pcurve: Some(geometry.into()),
                };
                continue;
            }
            let (key, carrier, source_object, chart, annotation_kind, namespace) = match binding {
                Some(crate::families::consolidated::records::ConsolidatedSupportBinding::Cylinder { pos }) => {
                    let Some(cylinder) = standalone.get(pos) else {
                        continue;
                    };
                    let carrier = cylinder.surface_geometry();
                    let SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cylinder(cylinder_surface)) = carrier else {
                        continue;
                    };
 let radius = cylinder_surface.radius().get();
                    (
                        (*pos, None),
                        carrier,
                        None,
                        ConsolidatedCarrierChart::Cylinder { radius },
                        "consolidated_b2_03_28_cylinder",
                        cadmpeg_ir::identity_namespace!("catia", "consolidated", "cylinder"),
                    )
                }
            Some(crate::families::consolidated::records::ConsolidatedSupportBinding::Cone { pos }) => {
                let Some(cone) = cones.get(pos) else {
                    continue;
                };
                (
                    (*pos, None),
                    crate::families::b2::records::b2_cone_geometry(cone),
                    None,
                    ConsolidatedCarrierChart::Cone { cone },
                    "consolidated_b2_03_29_cone",
                    cadmpeg_ir::identity_namespace!("catia", "consolidated", "cone"),
                )
            }
            Some(crate::families::consolidated::records::ConsolidatedSupportBinding::Sphere { pos }) => {
                let Some(sphere) = spheres.get(pos) else {
                    continue;
                };
                (
                    (*pos, None),
                    crate::families::b2::records::b2_sphere_geometry(sphere),
                    None,
                    ConsolidatedCarrierChart::Identity,
                    "consolidated_b2_03_2a_sphere",
                    cadmpeg_ir::identity_namespace!("catia", "consolidated", "sphere"),
                )
            }
            Some(crate::families::consolidated::records::ConsolidatedSupportBinding::Torus { pos }) => {
                let Some(torus) = tori.get(pos) else {
                    continue;
                };
                (
                    (*pos, None),
                    crate::families::b2::records::b2_torus_geometry(torus),
                    None,
                    ConsolidatedCarrierChart::Torus { torus },
                    "consolidated_b2_03_2b_torus",
                    cadmpeg_ir::identity_namespace!("catia", "consolidated", "torus"),
                )
            }
            Some(crate::families::consolidated::records::ConsolidatedSupportBinding::Plane { pos }) => {
                let Some(plane) = planes.get(pos) else {
                    continue;
                };
                let Some(carrier) = crate::families::b2::records::b2_plane_geometry(plane)
                else {
                    continue;
                };
                (
                    (*pos, None),
                    carrier,
                    None,
                    ConsolidatedCarrierChart::Identity,
                    "consolidated_b2_03_27_plane",
                    cadmpeg_ir::identity_namespace!("catia", "consolidated", "plane"),
                )
            }
            Some(
                crate::families::consolidated::records::ConsolidatedSupportBinding::Circle { .. }
                | crate::families::consolidated::records::ConsolidatedSupportBinding::NurbsCarrier { .. },
            )
            | None => continue,
        };
            let surface = if let Some(id) = surface_ids.get(&key) {
                id.clone()
            } else {
                let id = crate::resource::compose_index_id(
                    &namespace,
                    ir.geometry.surfaces.len(),
                    SurfaceId::mint,
                )?;
                annotate(
                    annotations,
                    &id,
                    annotation_kind,
                    u64_from_index(key.0),
                    "resolved_pcurve_support",
                    Exactness::ByteExact,
                )?;
                admission.charge()?;
                let surface_owner_id = id.clone();
                ir.geometry.surfaces.push(Surface {
                    id: surface_owner_id,
                    geometry: carrier,
                    source_object,
                    native_ref: None,
                });
                let stored_id = id.clone();
                surface_ids.insert(key, stored_id);
                id
            };

            let Some(geometry) = consolidated_jet_pcurve(pcurve, &chart, refusal) else {
                continue;
            };
            sides[side] = IntcurveSupportSide {
                surface: Some(surface),
                pcurve: Some(geometry.into()),
            };
        }
        if resolved.endpoint_loci.is_none() {
            resolved.endpoint_loci = standard_endpoint_loci;
        }
        let resolved_side = match sides
            .each_ref()
            .map(|side| side.surface.is_some() && side.pcurve.is_some())
        {
            [true, false] => Some(0),
            [false, true] => Some(1),
            _ => None,
        };
        let inferred_partner = if let Some(resolved_side) = resolved_side {
            let partner = 1 - resolved_side;
            let resolved_geometry = ir
                .geometry
                .surfaces
                .iter()
                .find(|surface| Some(&surface.id) == sides[resolved_side].surface.as_ref())
                .map(|surface| &surface.geometry);
            if let (Some(resolved_geometry), Some(resolved_pcurve)) =
                (resolved_geometry, sides[resolved_side].pcurve.as_ref())
            {
                if let Some(partner_pcurve) = consolidated_jet_pcurve(
                    &resolved.block.pcurves[partner],
                    &ConsolidatedCarrierChart::Identity,
                    refusal,
                ) {
                    let mut candidates = Vec::new();

                    for (index, surface) in freeform_surfaces.iter().enumerate() {
                        candidates.push((
                            index,
                            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                                surface.geometry.clone(),
                            )),
                        ));
                    }
                    let carrier = unique_paired_surface_lift_match(
                        admission.context(),
                        &resolved_pcurve.geometry,
                        resolved_geometry,
                        &partner_pcurve,
                        resolved.block.parameters.range.endpoints(),
                        candidates
                            .iter()
                            .map(|(index, geometry)| (*index, geometry)),
                    )?;
                    if let Some(carrier) = carrier {
                        sides[partner] = IntcurveSupportSide {
                            surface: Some(freeform_surface_ids[carrier].clone()),
                            pcurve: Some(partner_pcurve.into()),
                        };
                        partner_support_blocks.insert(resolved.block.pcurves[0].pos);
                        Some((resolved_side, carrier))
                    } else {
                        None
                    }
                } else {
                    None
                }
            } else {
                None
            }
        } else {
            None
        };
        let exact_side_count = sides
            .iter()
            .filter(|side| side.surface.is_some() && side.pcurve.is_some())
            .count();
        if exact_side_count == 0 {
            continue;
        }
        let selected_attachment = resolved.endpoint_loci.as_ref().and_then(|loci| {
            unique_endpoint_pair_match(
                *loci,
                attachable_edges
                    .iter()
                    .enumerate()
                    .filter(|(_, (_, _, curve, _, _))| !attached_curves.contains(curve))
                    .map(|(index, (_, _, _, _, endpoints))| (index, *endpoints)),
            )
        });
        let attachment = selected_attachment.map(|(index, reversed)| {
            let (edge, procedure, curve, surfaces, _) = &attachable_edges[index];
            (
                (
                    *edge,
                    *procedure,
                    curve.clone(),
                    [surfaces[0].clone(), surfaces[1].clone()],
                ),
                reversed,
            )
        });
        macro_rules! option_or_none {
            ($value:expr) => {
                match $value {
                    Some(value) => value,
                    None => return Ok(None),
                }
            };
        }
        let attachment = match attachment {
            Some((identity, reversed)) => (|| -> Result<Option<_>, cadmpeg_core::CodecError> {
                if reversed {
                    let label = format!(
                            "consolidated surface-curve pcurve of the edge block at byte {} reversed onto its edge",
                            resolved.block.pcurves[0].pos);
                    let reversed_pcurves = sides.each_ref().map(|side| match &side.pcurve {
                        Some(pcurve) => crate::nurbs::reverse_pcurve_geometry(
                            &pcurve.geometry,
                            resolved.block.parameters.range.endpoints(),
                            refusal,
                            &label,
                        )
                        .map(Some),
                        None => Some(None),
                    });
                    let [Some(first), Some(second)] = reversed_pcurves else {
                        return Ok(None);
                    };
                    for (side, pcurve) in sides.iter_mut().zip([first, second]) {
                        side.pcurve = pcurve.map(Into::into);
                    }
                }
                let (_, _, _, standard_surfaces) = &identity;
                let unique_resolved_side = match sides
                    .each_ref()
                    .map(|side| side.surface.is_some() && side.pcurve.is_some())
                {
                    [true, false] => Some(0),
                    [false, true] => Some(1),
                    _ => None,
                };
                let resolved_side = inferred_partner
                    .map(|(resolved_side, _)| resolved_side)
                    .or(unique_resolved_side);
                let partner_pcurves = if let Some(resolved_side) = resolved_side {
                    let resolved_surface = option_or_none!(sides[resolved_side].surface.as_ref());
                    let resolved_geometry = &option_or_none!(ir
                        .geometry
                        .surfaces
                        .iter()
                        .find(|surface| &surface.id == resolved_surface))
                    .geometry;
                    let matches = standard_surfaces.each_ref().map(|id| {
                        ir.geometry
                            .surfaces
                            .iter()
                            .find(|surface| &surface.id == id)
                            .is_some_and(|surface| {
                                same_surface_locus(&surface.geometry, resolved_geometry)
                            })
                    });
                    let standard_resolved_side = match matches {
                        [true, false] => Some(0),
                        [false, true] => Some(1),
                        _ => None,
                    };
                    if let Some(standard_resolved_side) = standard_resolved_side {
                        let partner = 1 - resolved_side;
                        if let Some((_, carrier)) = inferred_partner {
                            let standard_partner = &standard_surfaces[1 - standard_resolved_side];
                            let standard_partner_geometry = &option_or_none!(ir
                                .geometry
                                .surfaces
                                .iter()
                                .find(|surface| &surface.id == standard_partner))
                            .geometry;
                            if !matches!(
                                standard_partner_geometry,
                                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { .. })
                            ) && *standard_partner_geometry
                                != SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                                    freeform_surfaces[carrier].geometry.clone(),
                                ))
                            {
                                return Ok(Some((identity, None)));
                            }
                        }
                        let standard_partner_geometry =
                            &option_or_none!(ir.geometry.surfaces.iter().find(|surface| {
                                surface.id == standard_surfaces[1 - standard_resolved_side]
                            }))
                            .geometry;
                        let partner_pcurve = match &sides[partner].pcurve {
                            Some(pcurve) => pcurve.geometry.clone(),
                            None => {
                                // The free side stores its jet in its own carrier's
                                // chart, which is not the standard partner face's
                                // chart. Recover the isometry between them from the
                                // block's shared 3D loci.
                                let partner_points = resolved.block.pcurves[partner]
                                    .sites
                                    .iter()
                                    .map(|site| site.point.get())
                                    .collect::<Vec<_>>();
                                let Some(chart) = (match resolved.shared_loci.as_deref() {
                                    Some(loci) => solve_planar_chart_rechart(
                                        admission.context(),
                                        &partner_points,
                                        loci,
                                        standard_partner_geometry,
                                    )?,
                                    None => None,
                                }) else {
                                    // The free side has no defined chart relation
                                    // to a non-planar or unresolved partner.
                                    return Ok(Some((identity, None)));
                                };
                                let Some(mut pcurve) = consolidated_jet_pcurve(
                                    &resolved.block.pcurves[partner],
                                    &chart,
                                    refusal,
                                ) else {
                                    return Ok(None);
                                };
                                if reversed {
                                    let label = format!(
                                            "consolidated partner pcurve of the edge block at byte {} reversed onto its edge",
                                            resolved.block.pcurves[0].pos);
                                    pcurve =
                                        option_or_none!(crate::nurbs::reverse_pcurve_geometry(
                                            &pcurve,
                                            resolved.block.parameters.range.endpoints(),
                                            refusal,
                                            &label,
                                        ));
                                }
                                pcurve
                            }
                        };
                        let standard_surface_geometry = &option_or_none!(ir
                            .geometry
                            .surfaces
                            .iter()
                            .find(
                                |surface| surface.id == standard_surfaces[standard_resolved_side]
                            ))
                        .geometry;
                        let resolved_pcurve = match rechart_equivalent_surface_pcurve(
                            &option_or_none!(sides[resolved_side].pcurve.as_ref()).geometry,
                            resolved_geometry,
                            standard_surface_geometry,
                        ) {
                            Ok(Some(pcurve)) => pcurve,
                            Ok(None) => return Ok(None),
                            Err(RechartFailure) => {
                                binding_counts.rechart_numeric_failures += 1;
                                return Ok(None);
                            }
                        };
                        let standard_geometries = if standard_resolved_side == 0 {
                            [resolved_pcurve, partner_pcurve]
                        } else {
                            [partner_pcurve, resolved_pcurve]
                        };
                        let edge = &ir.geometry.edges[identity.0];
                        let edge_id = &edge.id;
                        let edge_endpoints = [
                            *option_or_none!(edge
                                .start()
                                .and_then(|vertex| vertex_positions.get(vertex))),
                            *option_or_none!(edge
                                .end()
                                .and_then(|vertex| vertex_positions.get(vertex))),
                        ];
                        // The shared coincidence bound, widened by whatever the
                        // topology itself declares. A binding accepted here is one
                        // the endpoint-incidence contract also accepts.
                        let edge_allowance = [
                            edge.tolerance,
                            edge.start()
                                .and_then(|vertex| vertex_tolerances.get(vertex))
                                .copied()
                                .flatten(),
                            edge.end()
                                .and_then(|vertex| vertex_tolerances.get(vertex))
                                .copied()
                                .flatten(),
                        ]
                        .into_iter()
                        .flatten()
                        .map(cadmpeg_ir::scalar::PositiveReal::get)
                        .fold(cadmpeg_ir::units::COINCIDENCE_TOLERANCE, f64::max);
                        let mut coedges = Vec::new();
                        for (side, surface) in standard_surfaces.iter().enumerate() {
                            let mut selected_coedge = None;
                            for (index, coedge) in ir.geometry.coedges.iter().enumerate() {
                                if coedge.edge == *edge_id
                                    && coedge.pcurves.is_empty()
                                    && coedge_surfaces[index].as_ref() == Some(surface)
                                    && selected_coedge.replace(index).is_some()
                                {
                                    selected_coedge = None;
                                    break;
                                }
                            }
                            let Some(coedge) = selected_coedge else {
                                continue;
                            };
                            let mut geometry = standard_geometries[side].clone();
                            if matches!(
                                ir.geometry.coedges[coedge].sense,
                                cadmpeg_ir::topology::Sense::Reversed
                            ) {
                                let label = format!(
                                        "standard pcurve of the edge block at byte {} reversed onto coedge {coedge}",
                                        resolved.block.pcurves[0].pos);
                                let Some(reversed_geometry) = crate::nurbs::reverse_pcurve_geometry(
                                    &geometry,
                                    resolved.block.parameters.range.endpoints(),
                                    refusal,
                                    &label,
                                ) else {
                                    continue;
                                };
                                geometry = reversed_geometry;
                            }
                            // A pcurve binds to a face only when it lifts onto
                            // the edge through that face's carrier. Without the
                            // witness the side's chart is not this face's
                            // chart, and the pcurve does not describe the edge.
                            let Some(surface_geometry) = ir
                                .geometry
                                .surfaces
                                .iter()
                                .find(|value| &value.id == surface)
                                .map(|value| &value.geometry)
                            else {
                                continue;
                            };
                            let Some(solved_surface) = surface_geometry.solved() else {
                                continue;
                            };
                            let face_allowance = coedge_face_tolerances
                                .get(coedge)
                                .copied()
                                .flatten()
                                .map_or(edge_allowance, |value| edge_allowance.max(value.get()));
                            if pcurve_lift_reaches_endpoints(
                                admission.context(),
                                &geometry,
                                solved_surface,
                                resolved.block.parameters.range.endpoints(),
                                edge_endpoints,
                                face_allowance,
                            )? {
                                coedges.push((coedge, geometry));
                            }
                        }
                        if coedges.is_empty() {
                            None
                        } else {
                            Some(ConsolidatedStandardFaceBinding {
                                coedges,
                                standard_surfaces: [
                                    standard_surfaces[0].clone(),
                                    standard_surfaces[1].clone(),
                                ],
                                edge_pcurves: standard_geometries,
                                inferred_partner: inferred_partner
                                    .map(|(_, carrier)| (1 - standard_resolved_side, carrier)),
                            })
                        }
                    } else {
                        None
                    }
                } else {
                    None
                };
                Ok(Some((identity, partner_pcurves)))
            })()?,
            None => None,
        };
        let mut bound_new_standard_surface = false;
        if let Some((_, Some(binding))) = attachment.as_ref() {
            if let Some((standard_partner_side, carrier)) = binding.inferred_partner {
                let surface_id = &binding.standard_surfaces[standard_partner_side];
                if let Some(surface) = ir
                    .geometry
                    .surfaces
                    .iter_mut()
                    .find(|surface| &surface.id == surface_id)
                {
                    if matches!(
                        surface.geometry,
                        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { .. })
                    ) {
                        surface.geometry = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Nurbs(
                            freeform_surfaces[carrier].geometry.clone(),
                        ));
                        annotations.derived(&surface.id, "geometry")?;
                        binding_counts.standard_face_surfaces += 1;
                        bound_new_standard_surface = true;
                    }
                    let copy_side = |side: usize| IntcurveSupportSide {
                        surface: Some(binding.standard_surfaces[side].clone()),
                        pcurve: Some(binding.edge_pcurves[side].clone().into()),
                    };
                    sides = [copy_side(0), copy_side(1)];
                }
            }
        }
        if bound_new_standard_surface {
            // The new carrier can make both coedge pcurves resolvable. Replay this
            // block after mutating the face geometry and emit only on that replay.
            pending.push_back(resolved);
            continue;
        }
        let context = IntcurveSupportContext::over_interval(sides, resolved.block.parameters.range);
        let definition = if exact_side_count == 2 {
            ProceduralCurveDefinition::Intersection {
                context,
                discontinuity_flag: false,
                cache: None,
            }
        } else {
            ProceduralCurveDefinition::SurfaceCurve {
                family: SurfaceCurveFamily::Parametric {
                    context,
                    tail: None,
                },
            }
        };
        if let Some(((edge_index, procedure_index, curve_id, _), partner_pcurves)) = attachment {
            let attached_id = curve_id.clone();
            attached_curves.insert(attached_id);
            binding_counts.standard_edges += 1;
            if let Some(partner_pcurves) = partner_pcurves {
                if partner_pcurves.coedges.len() == 2 {
                    binding_counts.partner_face_pcurve_pairs += 1;
                }
                binding_counts.standard_face_pcurves += partner_pcurves.coedges.len();
                for (coedge_index, geometry) in partner_pcurves.coedges {
                    let pcurve_id = crate::resource::compose_index_id(
                        &cadmpeg_ir::identity_namespace!(
                            "catia",
                            "consolidated",
                            "standard-pcurve"
                        ),
                        ir.geometry.pcurves.len(),
                        PcurveId::mint,
                    )?;
                    annotate(
                        annotations,
                        &pcurve_id,
                        "consolidated_edge_run",
                        u64_from_index(run.edge.pcurves[0].pos),
                        "resolved_face_side_pcurve",
                        Exactness::Derived,
                    )?;
                    admission.charge()?;
                    let pcurve_owner_id = pcurve_id.clone();
                    ir.geometry.pcurves.push(Pcurve {
                        id: pcurve_owner_id,
                        geometry,
                        metadata: cadmpeg_ir::geometry::pcurve::PcurveMetadata::general(
                            None,
                            Some(cadmpeg_ir::units::FiniteVector::from(
                                resolved.block.parameters.range,
                            )),
                            None,
                        ),
                        native_ref: None,
                    });
                    ir.geometry.coedges[coedge_index].pcurves.push(
                        cadmpeg_ir::topology::PcurveUse {
                            pcurve: pcurve_id,
                            isoparametric: None,
                            parameter_range: None,
                        },
                    );
                    annotations.derived(&ir.geometry.coedges[coedge_index].id, "pcurves")?;
                }
            }
            ir.geometry.edges[edge_index].set_param_range(Some(
                cadmpeg_ir::topology::ParameterInterval::from(resolved.block.parameters.range),
            ));
            let procedural = &mut ir.geometry.procedural_curves[procedure_index];
            procedural.replace_definition(definition);
            annotate(
                annotations,
                &procedural.id,
                "consolidated_edge_run",
                u64_from_index(run.edge.pcurves[0].pos),
                "resolved_surface_curve_bound_to_standard_edge",
                Exactness::Derived,
            )?;
            annotations.derived(&procedural.id, "curve")?;
            annotations.derived(&procedural.id, "definition")?;
        } else {
            let curve_id = crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "consolidated", "curve"),
                ir.geometry.curves.len(),
                CurveId::mint,
            )?;
            annotate(
                annotations,
                &curve_id,
                "consolidated_edge_run",
                u64_from_index(run.edge.pcurves[0].pos),
                "procedural_curve_cache",
                Exactness::Unknown,
            )?;
            admission.charge()?;
            let curve_owner_id = curve_id.clone();
            ir.geometry.curves.push(Curve {
                parameter_range: None,
                id: curve_owner_id,
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Unknown { record: None }),
                source_object: None,
                native_ref: None,
            });
            let procedural_id = crate::resource::compose_index_id(
                &cadmpeg_ir::identity_namespace!("catia", "consolidated", "construction"),
                ir.geometry.procedural_curves.len(),
                ProceduralCurveId::mint,
            )?;
            annotate(
                annotations,
                &procedural_id,
                "consolidated_edge_run",
                u64_from_index(run.edge.pcurves[0].pos),
                "resolved_surface_curve",
                Exactness::Derived,
            )?;
            annotations.derived(&procedural_id, "curve")?;
            annotations.derived(&procedural_id, "definition")?;
            admission.charge()?;
            let _attached = ir
                .geometry
                .add_procedural_curve(&curve_id, ProceduralCurve::new(procedural_id, definition));
        }
    }
    binding_counts.partner_supports = partner_support_blocks.len();
    Ok(binding_counts)
}

/// Tolerance in millimetres for consolidated definition-site agreement.
const CONSOLIDATED_SITE_TOLERANCE: f64 = 2e-3;

/// Solve the plane isometry that carries a consolidated side's stored chart
/// onto `target`'s chart.
///
/// A consolidated side stores its definition sites in the carrier's own
/// orthonormal chart. When the shared 3D loci of the block lie on `target` and
/// `target` is a plane, both charts are isometric parameterizations of one
/// plane, so a single rigid 2D motion relates them. The motion is recovered
/// from the index-aligned site correspondence and is accepted only when it
/// reproduces every site.
fn solve_planar_chart_rechart(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    sites: &[[f64; 2]],
    loci: &[Point3],
    target: &SurfaceGeometry,
) -> Result<Option<ConsolidatedCarrierChart<'static>>, cadmpeg_core::CodecError> {
    if !matches!(
        target,
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(_))
    ) || sites.len() != loci.len()
    {
        return Ok(None);
    }
    // Target-chart image of each locus. A locus off the plane has no image,
    // because the plane inverse discards the normal component.
    let images = loci
        .iter()
        .map(|locus| -> Result<_, cadmpeg_core::decode::ResourceLimit> {
            let Some(uv) = cadmpeg_ir::eval::analytic_surface_parameters(target, *locus) else {
                return Ok(None);
            };
            let uv = cadmpeg_ir::math::Point2::from(uv);
            let Some(back) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, target, uv.u, uv.v),
                )?)?
            else {
                return Ok(None);
            };
            Ok(((back.x - locus.x)
                .hypot(back.y - locus.y)
                .hypot(back.z - locus.z)
                <= CONSOLIDATED_SITE_TOLERANCE)
                .then_some([uv.u, uv.v]))
        })
        .collect::<Result<Option<Vec<_>>, _>>()?;
    let Some(images) = images else {
        return Ok(None);
    };
    let count = images.len();
    if count < 2 {
        return Ok(None);
    }
    let Some(count) = f64_from_index(count) else {
        return Ok(None);
    };
    let scale = 1.0 / count;
    let mean = |values: &[[f64; 2]]| {
        values.iter().fold([0.0, 0.0], |acc, value| {
            [acc[0] + value[0] * scale, acc[1] + value[1] * scale]
        })
    };
    let stored_center = mean(sites);
    let image_center = mean(&images);
    // Two-dimensional orthogonal Procrustes. `dot` and `cross` accumulate the
    // rotation's cosine and sine lanes; the reflected solution swaps the sign
    // of the image's second chart coordinate.
    let centered = |values: &[[f64; 2]],
                    center: [f64; 2]|
     -> Result<Option<Vec<[f64; 2]>>, cadmpeg_core::CodecError> {
        if values
            .iter()
            .flatten()
            .chain(&center)
            .any(|value| !value.is_finite())
        {
            return Ok(None);
        }
        let mut offsets = values
            .iter()
            .map(|value| [value[0] - center[0], value[1] - center[1]])
            .collect::<Vec<_>>();
        let mut scale = offsets
            .iter()
            .flatten()
            .fold(0.0_f64, |scale, value| scale.max(value.abs()));
        if !scale.is_finite() {
            let frame = values
                .iter()
                .flatten()
                .chain(&center)
                .fold(0.0_f64, |scale, value| scale.max(value.abs()));
            offsets = values
                .iter()
                .map(|value| {
                    [
                        value[0] / frame - center[0] / frame,
                        value[1] / frame - center[1] / frame,
                    ]
                })
                .collect::<Vec<_>>();
            scale = offsets
                .iter()
                .flatten()
                .fold(0.0_f64, |scale, value| scale.max(value.abs()));
        }
        if scale == 0.0 {
            return Ok(None);
        }
        Ok(Some(
            offsets
                .into_iter()
                .map(|value| [value[0] / scale, value[1] / scale])
                .collect::<Vec<_>>(),
        ))
    };
    let Some(stored_offsets) = centered(sites, stored_center)? else {
        return Ok(None);
    };
    let Some(image_offsets) = centered(&images, image_center)? else {
        return Ok(None);
    };
    let (mut dot, mut cross) = (0.0, 0.0);
    let (mut reflected_dot, mut reflected_cross) = (0.0, 0.0);
    for ([su, sv], [iu, iv]) in stored_offsets.into_iter().zip(image_offsets) {
        dot += su * iu + sv * iv;
        cross += su * iv - sv * iu;
        reflected_dot += su * iu - sv * iv;
        reflected_cross += su * iv + sv * iu;
    }
    let candidates = [(dot, cross, 1.0), (reflected_dot, reflected_cross, -1.0)];
    let mut admissible = None;
    for (dot, cross, determinant) in candidates {
        let norm = dot.hypot(cross);
        if !norm.is_finite() || norm <= f64::EPSILON {
            continue;
        }
        let (cosine, sine) = (dot / norm, cross / norm);
        // A reflection about the target chart's first axis follows the
        // rotation, so its second column changes sign.
        let linear = [[cosine, -sine * determinant], [sine, cosine * determinant]];
        let offset = [
            image_center[0] - (linear[0][0] * stored_center[0] + linear[0][1] * stored_center[1]),
            image_center[1] - (linear[1][0] * stored_center[0] + linear[1][1] * stored_center[1]),
        ];
        let chart = ConsolidatedCarrierChart::Rigid { linear, offset };
        let residual = sites
            .iter()
            .zip(&images)
            .map(|(stored, image)| {
                let mapped = chart.point(*stored);
                (mapped[0] - image[0]).hypot(mapped[1] - image[1])
            })
            .fold(0.0f64, f64::max);
        if !residual.is_finite() {
            continue;
        }
        if residual <= CONSOLIDATED_SITE_TOLERANCE {
            if admissible.is_some() {
                return Ok(None);
            }
            admissible = Some(chart);
        }
    }
    Ok(admissible)
}

/// Does `pcurve`, mapped through `surface`, reach `endpoints` over `range`?
///
/// A consolidated side binds to a standard face only when its stored chart is
/// that face carrier's chart. This is the local geometric witness of that: the
/// pcurve's parameter-interval extremes must lift onto the edge's vertex
/// positions within `allowance`. Either endpoint assignment satisfies it,
/// because pcurve parameter direction is independent of edge sense.
///
/// A carrier with no geometry has no chart and therefore admits no witness.
fn pcurve_lift_reaches_endpoints(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    pcurve: &PcurveGeometry,
    surface: &SolvedSurfaceGeometry,
    range: [f64; 2],
    endpoints: [Point3; 2],
    allowance: f64,
) -> Result<bool, cadmpeg_core::decode::ResourceLimit> {
    if matches!(surface, SolvedSurfaceGeometry::Unknown { .. }) {
        return Ok(false);
    }
    // A non-finite lift is measured as a finite one is.
    let lift = |parameter| {
        let uv = match cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::pcurve_uv(ctx, pcurve, parameter),
        )? {
            Ok(uv) => uv,
            Err(cadmpeg_ir::eval::EvaluationFailure::ResourceLimit(limit)) => return Err(limit),
            Err(_) => return Ok(None),
        };
        match cadmpeg_ir::eval::decode::outer_refusal(
            cadmpeg_ir::eval::decode::surface_point_solved(ctx, surface, uv.u, uv.v),
        )? {
            Ok(point) => Ok(Some(point.get())),
            Err(failure) => failure.non_finite(),
        }
    };
    let (Some(start), Some(end)) = (lift(range[0])?, lift(range[1])?) else {
        return Ok(false);
    };
    let forward = distance(start, endpoints[0]).max(distance(end, endpoints[1]));
    let reversed = distance(start, endpoints[1]).max(distance(end, endpoints[0]));
    Ok(forward.min(reversed) <= allowance)
}

fn unique_endpoint_pair_match<T>(
    loci: [Point3; 2],
    candidates: impl Iterator<Item = (T, [Point3; 2])>,
) -> Option<(T, bool)> {
    const TOLERANCE: f64 = 2e-3;
    let close = |left: Point3, right: Point3| distance(left, right) < TOLERANCE;
    let mut matches = candidates.filter_map(|(identity, endpoints)| {
        let forward = close(loci[0], endpoints[0]) && close(loci[1], endpoints[1]);
        let reversed = close(loci[0], endpoints[1]) && close(loci[1], endpoints[0]);
        (forward != reversed).then_some((identity, reversed))
    });
    let winner = matches.next()?;
    matches.next().is_none().then_some(winner)
}

fn unique_paired_surface_lift_match<'a, T>(
    ctx: &cadmpeg_core::decode::DecodeContext<'_>,
    resolved_pcurve: &PcurveGeometry,
    resolved_surface: &SurfaceGeometry,
    partner_pcurve: &PcurveGeometry,
    parameter_range: [f64; 2],
    candidates: impl Iterator<Item = (T, &'a SurfaceGeometry)>,
) -> Result<Option<T>, cadmpeg_core::decode::ResourceLimit> {
    const TOLERANCE: f64 = 2e-3;
    let ordinary_midpoint = parameter_range[0] + (parameter_range[1] - parameter_range[0]) * 0.5;
    let midpoint = if ordinary_midpoint.is_finite() {
        ordinary_midpoint
    } else {
        let Some(midpoint) =
            cadmpeg_ir::math::interpolate(parameter_range[0], parameter_range[1], 0.5)
        else {
            return Ok(None);
        };
        midpoint.get()
    };
    let parameters = [parameter_range[0], midpoint, parameter_range[1]];
    let resolved_lift =
        |parameter| -> Result<Option<FinitePoint3>, cadmpeg_core::decode::ResourceLimit> {
            let Some(uv) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::pcurve_uv(ctx, resolved_pcurve, parameter),
                )?)?
            else {
                return Ok(None);
            };
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::surface_point(ctx, resolved_surface, uv.u, uv.v),
            )?)
        };
    let mut resolved_loci = [None; 3];
    let mut partner_uv = [None; 3];
    for (index, parameter) in parameters.into_iter().enumerate() {
        resolved_loci[index] = resolved_lift(parameter)?;
        partner_uv[index] =
            cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                cadmpeg_ir::eval::decode::pcurve_uv(ctx, partner_pcurve, parameter),
            )?)?;
        if resolved_loci[index].is_none() || partner_uv[index].is_none() {
            return Ok(None);
        }
    }
    let mut winner = None;
    for (identity, surface) in candidates {
        let mut matches = true;
        for (resolved, uv) in resolved_loci.iter().zip(&partner_uv) {
            let (Some(resolved), Some(uv)) = (resolved, uv) else {
                return Ok(None);
            };
            let Some(partner) =
                cadmpeg_ir::eval::finite_or_refusal(cadmpeg_ir::eval::decode::outer_refusal(
                    cadmpeg_ir::eval::decode::surface_point(ctx, surface, uv.u, uv.v),
                )?)?
            else {
                matches = false;
                break;
            };
            let distance = (resolved.x - partner.x)
                .hypot(resolved.y - partner.y)
                .hypot(resolved.z - partner.z);
            if distance.partial_cmp(&TOLERANCE) != Some(std::cmp::Ordering::Less) {
                matches = false;
                break;
            }
        }
        if matches {
            if winner.is_some() {
                return Ok(None);
            }
            winner = Some(identity);
        }
    }
    Ok(winner)
}

fn same_surface_locus(left: &SurfaceGeometry, right: &SurfaceGeometry) -> bool {
    if left == right {
        return true;
    }
    let (
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface_2)),
    ) = (left, right)
    else {
        return false;
    };
    let left_origin = cone_surface.origin();
    let left_axis = cone_surface.frame().axis().as_raw();
    let left_reference = cone_surface.frame().reference().as_raw();
    let left_radius = cone_surface.radius().get();
    let left_ratio = cone_surface.ratio().get();
    let left_angle = cone_surface.half_angle().get();
    let right_origin = cone_surface_2.origin();
    let right_axis = cone_surface_2.frame().axis().as_raw();
    let right_reference = cone_surface_2.frame().reference().as_raw();
    let right_radius = cone_surface_2.radius().get();
    let right_ratio = cone_surface_2.ratio().get();
    let right_angle = cone_surface_2.half_angle().get();
    if left_axis != right_axis
        || left_reference != right_reference
        || left_ratio.to_bits() != right_ratio.to_bits()
        || left_angle.to_bits() != right_angle.to_bits()
    {
        return false;
    }
    let tangent = left_angle.tan();
    if !tangent.is_finite() || tangent == 0.0 {
        return false;
    }
    let apex = |origin: Point3, axis: Vector3, radius: f64| {
        Point3::new(
            origin.x - axis.x * radius / tangent,
            origin.y - axis.y * radius / tangent,
            origin.z - axis.z * radius / tangent,
        )
    };
    let left_apex = apex(*left_origin, *left_axis, left_radius);
    let right_apex = apex(*right_origin, *right_axis, right_radius);
    let scale = [
        left_apex.x,
        left_apex.y,
        left_apex.z,
        right_apex.x,
        right_apex.y,
        right_apex.z,
    ]
    .into_iter()
    .map(f64::abs)
    .fold(1.0f64, f64::max);
    (left_apex.x - right_apex.x)
        .hypot(left_apex.y - right_apex.y)
        .hypot(left_apex.z - right_apex.z)
        <= EPS_APEX_ALIGNMENT * scale
}

/// A rechart produced a non-finite pcurve coordinate.
#[derive(Debug)]
struct RechartFailure;

fn rechart_equivalent_surface_pcurve(
    pcurve: &PcurveGeometry,
    source: &SurfaceGeometry,
    target: &SurfaceGeometry,
) -> Result<Option<PcurveGeometry>, RechartFailure> {
    if source == target {
        return Ok(Some(pcurve.clone()));
    }
    let (
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface)),
        SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(cone_surface_2)),
    ) = (source, target)
    else {
        return Ok(None);
    };
    let source_origin = cone_surface.origin();
    let source_axis = cone_surface.frame().axis().as_raw();
    let target_origin = cone_surface_2.origin();
    if !same_surface_locus(source, target) {
        return Ok(None);
    }
    let v_shift = (source_origin.x - target_origin.x) * source_axis.x
        + (source_origin.y - target_origin.y) * source_axis.y
        + (source_origin.z - target_origin.z) * source_axis.z;
    if !v_shift.is_finite() {
        return Err(RechartFailure);
    }
    match pcurve {
        PcurveGeometry::Line(line_pcurve) => {
            let origin = line_pcurve.origin().as_raw();
            let shifted_origin =
                cadmpeg_ir::units::FinitePoint2::new(Point2::new(origin.u, origin.v + v_shift))
                    .ok_or(RechartFailure)?;
            Ok(Some(PcurveGeometry::Line(
                cadmpeg_ir::geometry::pcurve::LinePcurve::new(
                    shifted_origin,
                    *line_pcurve.direction(),
                ),
            )))
        }
        PcurveGeometry::Nurbs { nurbs } => {
            use cadmpeg_ir::geometry::pcurve::PcurveNurbsPoles;
            let knots = nurbs.knots().clone();
            let mut poles = match nurbs.pole_rows() {
                PcurveNurbsPoles::Polynomial { points } => PcurveNurbsPoles::Polynomial {
                    points: points.clone(),
                },
                PcurveNurbsPoles::Rational { points } => PcurveNurbsPoles::Rational {
                    points: points.clone(),
                },
            };
            match &mut poles {
                PcurveNurbsPoles::Polynomial { points } => {
                    for point in points {
                        let raw = point.get();
                        *point = cadmpeg_ir::units::FinitePoint2::new(Point2::new(
                            raw.u,
                            raw.v + v_shift,
                        ))
                        .ok_or(RechartFailure)?;
                    }
                }
                PcurveNurbsPoles::Rational { points } => {
                    for pole in points {
                        let raw = pole.point.get();
                        pole.point = cadmpeg_ir::units::FinitePoint2::new(Point2::new(
                            raw.u,
                            raw.v + v_shift,
                        ))
                        .ok_or(RechartFailure)?;
                    }
                }
            }
            let shifted = cadmpeg_ir::geometry::pcurve::PcurveNurbs::new(
                nurbs.degree(),
                knots,
                poles,
                nurbs.periodic(),
            )
            .map_err(|_| RechartFailure)?;
            Ok(Some(PcurveGeometry::Nurbs { nurbs: shifted }))
        }
        _ => Ok(None),
    }
}

fn append_a8_rolling_ball_pools(
    ir: &mut CadIr,
    annotations: &mut AnnotationBuilder<impl cadmpeg_ir::annotations::AnnotationStorage>,
    data: &[u8],
    admission: &mut FamilyEntityAdmission<'_, '_>,
) -> Result<(), cadmpeg_core::CodecError> {
    for jet in crate::families::a5a8::records::a8_freeform_curves(data) {
        let Some(definition) = crate::families::a5a8::records::rolling_ball_jet_definition(&jet)
        else {
            continue;
        };
        let surface_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "a8-rolling-ball", "surf"),
            ir.geometry.surfaces.len(),
            SurfaceId::mint,
        )?;
        let procedural_id = crate::resource::compose_index_id(
            &cadmpeg_ir::identity_namespace!("catia", "a8-rolling-ball", "construction"),
            ir.geometry.procedural_surfaces.len(),
            ProceduralSurfaceId::mint,
        )?;
        annotate(
            annotations,
            &surface_id,
            "object_stream_a8_03_32_cache",
            u64_from_index(jet.pos),
            format_args!("object_id:{:08x}", jet.object_id),
            Exactness::Unknown,
        )?;
        admission.charge()?;
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Procedural {
                construction: procedural_id.clone(),
                cache: None,
            },
            source_object: Some(cgm_source("surface", jet.object_id)?),
            native_ref: None,
        });

        annotate(
            annotations,
            &procedural_id,
            "object_stream_a8_03_32",
            u64_from_index(jet.pos),
            format_args!(
                "object_id:{:08x}:multiplicities:{:?}",
                jet.object_id,
                jet.multiplicities()
            ),
            Exactness::ByteExact,
        )?;
        admission.charge()?;
        ir.geometry.procedural_surfaces.push(ProceduralSurface::new(
            procedural_id,
            definition,
            None,
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {

    use super::{
        append_consolidated_line_profiles, append_freeform_surface_pools,
        append_resolved_consolidated_surface_curves, attach_standalone_wires,
        consolidated_line_profiles, freeform_surface_carriers, pcurve_lift_reaches_endpoints,
        rechart_equivalent_surface_pcurve, same_surface_locus, standard_carrier_surface_ids,
        typed_face_counts, unique_endpoint_pair_match, unique_paired_surface_lift_match,
        ConsolidatedCarrierChart, FreeformSurfacePool, RechartFailure,
    };
    use cadmpeg_ir::document::CadIr;
    use cadmpeg_ir::geometry::{
        nurbs::NurbsCurve, pcurve::PcurveGeometry, Curve, CurveGeometry, IntcurveSupportContext,
        IntcurveSupportSide, ProceduralCurve, ProceduralCurveDefinition, SolvedCurveGeometry,
        SolvedSurfaceGeometry, Surface, SurfaceGeometry,
    };
    use cadmpeg_ir::ids::{
        CoedgeId, CurveId, EdgeId, FaceId, LoopId, PointId, ProceduralCurveId, ShellId, SurfaceId,
        VertexId,
    };
    use cadmpeg_ir::math::{Point2, Point3, Vector3};
    use cadmpeg_ir::topology::{Coedge, Edge, Face, Loop, Point, Sense, Vertex};
    use cadmpeg_ir::AnnotationBuilder;
    use std::collections::HashMap;

    fn solve_planar_chart_rechart(
        sites: &[[f64; 2]],
        loci: &[Point3],
        target: &SurfaceGeometry,
    ) -> Option<ConsolidatedCarrierChart<'static>> {
        crate::test_support::with_service_context(|ctx| {
            super::solve_planar_chart_rechart(ctx, sites, loci, target)
        })
        .expect("solve planar chart rechart")
    }

    fn with_admission<T>(run: impl FnOnce(&mut super::FamilyEntityAdmission<'_, '_>) -> T) -> T {
        crate::test_support::with_service_context(|ctx| {
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            run(&mut admission)
        })
    }

    #[test]
    fn freeform_surface_pool_entity_limit_refuses_before_curve_append() {
        let bytes = crate::test_support::test_a5a8::a5_freeform_curve_stream();
        crate::test_support::with_entity_limit(0, |ctx| {
            let mut ir = CadIr::empty();
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            let Err(error) = append_freeform_surface_pools(
                &mut ir,
                &mut AnnotationBuilder::new(),
                (
                    &bytes,
                    &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                ),
                &crate::wire::records::consolidated_records(&bytes),
                &HashMap::new(),
                &mut crate::nurbs::LaneRefusals::new(),
                &mut admission,
            ) else {
                panic!("an A5 limiting curve exceeds the zero-entity allowance");
            };
            assert!(matches!(
                error,
                cadmpeg_core::CodecError::ResourceLimit(limit)
                    if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                        && limit.operation == "admit CATIA family model entity"
            ));
            assert_eq!(ir.entity_count(), 0);
        });
    }

    #[test]
    fn freeform_wire_entity_limit_refuses_before_endpoint_append() {
        let mut ir = CadIr::empty();
        let curve_id = CurveId::mint("catia:test:curve#wire").expect("identity grammar");
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                NurbsCurve::from_lanes(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
                    None,
                    false,
                )
                .expect("valid linear wire curve"),
            )),
            source_object: None,
            native_ref: None,
        });
        crate::test_support::with_entity_limit(0, |ctx| {
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            let error = attach_standalone_wires(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &[(curve_id, [0.0, 1.0], 0)],
                &mut admission,
            )
            .expect_err("the first endpoint exceeds the zero-entity allowance");
            assert!(matches!(
                error,
                cadmpeg_core::CodecError::ResourceLimit(limit)
                    if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                        && limit.operation == "admit CATIA family model entity"
            ));
            assert!(ir.geometry.points.is_empty());
        });
    }

    #[test]
    fn consolidated_revolution_entity_limit_refuses_before_directrix_append() {
        let bytes = crate::test_support::test_b2::b2_resolved_revolution_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let resolved =
            crate::families::b2::records::b2_resolved_revolutions_from_records(&bytes, &records);
        assert_eq!(resolved.len(), 1);
        crate::test_support::with_entity_limit(0, |ctx| {
            let mut ir = CadIr::empty();
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            let Err(error) = super::append_consolidated_revolutions(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &resolved,
                &mut admission,
            ) else {
                panic!("the directrix exceeds the zero-entity allowance");
            };
            assert!(matches!(
                error,
                cadmpeg_core::CodecError::ResourceLimit(limit)
                    if limit.dimension == cadmpeg_core::decode::ResourceDimension::Entities
                        && limit.operation == "admit CATIA family model entity"
            ));
            assert_eq!(ir.entity_count(), 0);
        });
    }

    #[test]
    fn typed_face_counts_partition_the_parsed_record_identities() {
        use crate::families::b5::graph::{parse, parse_from_records, B5Record};
        use crate::test_support::test_b5::{append_b5_record, b5_closed_triangle_stream};

        let mut bytes = b5_closed_triangle_stream();
        append_b5_record(
            &mut bytes,
            0x5f,
            902,
            &[0x82, 0x18, 100, 0, 0x18, 0xe7, 0x03, 0x03],
        );
        let graph = crate::test_support::with_service_context(|ctx| {
            parse(ctx, &bytes, &mut crate::nurbs::LaneRefusals::new())
        })
        .expect("parse the freeform graph")
        .expect("one resolved and one unresolved face");
        assert_eq!(graph.face_records.len(), 2);
        assert_eq!(graph.faces.len(), 1);
        assert!(graph
            .faces
            .iter()
            .all(|face| graph.face_records.contains_key(&face.object_id)));
        assert_eq!(
            typed_face_counts(&graph.face_records, &graph.faces),
            [1, 1, 0, 1]
        );
        assert_eq!(typed_face_counts(&graph.face_records, &[]), [1, 1, 0, 2]);

        let record = B5Record {
            offset: 0,
            family: 0xb5,
            class: 0x5f,
            object_id: 902,
            payload: vec![0x82, 0x18, 100, 0, 0x18, 0xe7, 0x03, 0x03],
        };
        assert!(
            crate::test_support::with_service_context(|ctx| parse_from_records(
                ctx,
                &[],
                std::slice::from_ref(&record),
                &[],
                false,
                None,
                &mut crate::nurbs::LaneRefusals::new()
            ))
            .expect("parse from records")
            .is_some()
        );
        assert!(
            crate::test_support::with_service_context(|ctx| parse_from_records(
                ctx,
                &[],
                &[record.clone(), record],
                &[],
                false,
                None,
                &mut crate::nurbs::LaneRefusals::new()
            ))
            .expect("parse from records")
            .is_none()
        );
    }

    #[test]
    fn object_stream_selection_uses_the_unique_topology_root_run() {
        let topology = crate::test_support::test_b5::b5_closed_triangle_stream();
        let mut unrelated = vec![0xb5, 0x03, 0x5e, 0x01];
        unrelated.extend_from_slice(&99u32.to_le_bytes());
        unrelated.push(0x00);

        let selection = crate::families::b5::graph::select_object_stream_population(
            &[unrelated, topology.clone()],
            None,
        );
        assert_eq!(selection.run_count(), 2);
        assert!(selection.selected());
        assert_eq!(selection.source(), topology);
    }

    #[test]
    fn object_stream_selection_refuses_multiple_topology_root_runs() {
        let topology = crate::test_support::test_b5::b5_closed_triangle_stream();
        let selection = crate::families::b5::graph::select_object_stream_population(
            &[topology.clone(), topology],
            None,
        );

        assert_eq!(selection.run_count(), 2);
        assert!(!selection.selected());
        assert!(selection.source().is_empty());
    }

    #[test]
    fn object_stream_selection_stops_before_materializing_over_budget_records() {
        let topology = crate::test_support::test_b5::b5_closed_triangle_stream();
        let budget = cadmpeg_core::decode::WorkBudget::new(1);

        let selection =
            crate::families::b5::graph::select_object_stream_population(&[topology], Some(&budget));

        assert_eq!(selection.run_count(), 1);
        assert!(!selection.selected());
        assert!(selection.source().is_empty());
        assert!(selection.records().is_empty());
        assert!(selection.exhausted());
        assert!(budget.exhausted());
    }

    #[test]
    fn standalone_clamped_curve_becomes_a_valid_wire_edge() {
        let mut ir = CadIr::empty();
        let curve_id = CurveId::mint("catia:test:curve#0".to_string()).expect("identity grammar");
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                NurbsCurve::from_lanes(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    vec![Point3::new(2.0, 3.0, 5.0), Point3::new(7.0, 11.0, 13.0)],
                    None,
                    false,
                )
                .expect("valid linear NURBS"),
            )),
            source_object: None,
            native_ref: None,
        });
        assert!(with_admission(|admission| attach_standalone_wires(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &[(curve_id, [0.0, 1.0], 17)],
            admission
        ))
        .expect("attach standalone wires"));
        assert_eq!(
            ir.geometry.bodies[0].kind,
            cadmpeg_ir::topology::BodyKind::Wire
        );
        assert_eq!(
            ir.geometry.shells[0]
                .wire_edges()
                .cloned()
                .collect::<Vec<_>>(),
            [ir.geometry.edges[0].id.clone()]
        );
        assert_eq!(
            ir.geometry.points[1].position().get(),
            Point3::new(2.0, 3.0, 5.0)
        );
        assert_eq!(
            ir.geometry.points[0].position().get(),
            Point3::new(7.0, 11.0, 13.0)
        );
        ir.finalize();
        let validation =
            cadmpeg_ir::validate_neutral(&ir, Vec::new()).expect("validate the neutral model");
        assert!(validation.is_ok(), "{:?}", validation.findings);
    }

    #[test]
    fn rejected_later_wire_leaves_all_topology_arenas_unchanged() {
        let mut ir = CadIr::empty();
        let curve_id = CurveId::mint("catia:test:curve#0").expect("identity grammar");
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(
                NurbsCurve::from_lanes(
                    1,
                    vec![0.0, 0.0, 1.0, 1.0],
                    vec![Point3::new(0.0, 0.0, 0.0), Point3::new(1.0, 0.0, 0.0)],
                    None,
                    false,
                )
                .expect("valid linear NURBS"),
            )),
            source_object: None,
            native_ref: None,
        });
        let before = ir.clone();
        assert!(!with_admission(|admission| attach_standalone_wires(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &[(curve_id.clone(), [0.0, 1.0], 0), (curve_id, [1.0, 0.0], 1)],
            admission
        ))
        .expect("attach standalone wires"));
        assert_eq!(ir, before);
    }

    #[test]
    fn consolidated_line_profile_retains_its_stored_wire_interval() {
        let mut ir = CadIr::empty();
        let bytes = crate::test_support::test_b2::b2_line_profile_stream();
        let profiles =
            consolidated_line_profiles(&bytes, &crate::wire::records::consolidated_records(&bytes))
                .expect("compute the consolidated line profiles");
        let wires = profiles
            .iter()
            .map(|profile| (profile.curve.id.clone(), profile.range, profile.pos))
            .collect::<Vec<_>>();
        with_admission(|admission| {
            append_consolidated_line_profiles(
                &mut ir,
                &mut AnnotationBuilder::new(),
                profiles,
                admission,
            )
        })
        .expect("append consolidated line profiles");
        assert_eq!(wires.len(), 1);
        assert!(with_admission(|admission| attach_standalone_wires(
            &mut ir,
            &mut AnnotationBuilder::new(),
            &wires,
            admission
        ))
        .expect("attach standalone wires"));
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([-4.0, 9.0])
        );
        let expected_start = Point3::new(1.0, -0.4, -0.2);
        let expected_end = Point3::new(1.0, 7.4, 10.2);
        for (actual, expected) in [
            (ir.geometry.points[1].position().get(), expected_start),
            (ir.geometry.points[0].position().get(), expected_end),
        ] {
            assert!((actual.x - expected.x).abs() < 1.0e-12);
            assert!((actual.y - expected.y).abs() < 1.0e-12);
            assert!((actual.z - expected.z).abs() < 1.0e-12);
        }
        ir.finalize();
        let validation =
            cadmpeg_ir::validate_neutral(&ir, Vec::new()).expect("validate the neutral model");
        assert!(validation.is_ok(), "{:?}", validation.findings);
    }

    #[test]
    fn the_surface_pool_route_appends_the_line_profiles_the_standalone_route_appends() {
        let bytes = crate::test_support::test_b2::b2_line_profile_stream();
        let records = crate::wire::records::consolidated_records(&bytes);

        let mut standalone = CadIr::empty();
        with_admission(|admission| {
            append_consolidated_line_profiles(
                &mut standalone,
                &mut AnnotationBuilder::new(),
                consolidated_line_profiles(&bytes, &records)?,
                admission,
            )
        })
        .expect("append consolidated line profiles");

        let mut pooled = CadIr::empty();
        with_admission(|admission| {
            append_freeform_surface_pools(
                &mut pooled,
                &mut AnnotationBuilder::new(),
                (
                    &bytes,
                    &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                ),
                &records,
                &HashMap::new(),
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");

        assert_eq!(standalone.geometry.curves.len(), 1);
        assert_eq!(
            pooled.geometry.curves.len(),
            standalone.geometry.curves.len()
        );
        assert_eq!(
            pooled
                .geometry
                .curves
                .iter()
                .map(|curve| curve.id.clone())
                .collect::<Vec<_>>(),
            standalone
                .geometry
                .curves
                .iter()
                .map(|curve| curve.id.clone())
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn rolling_ball_pool_retains_both_exact_limiting_curves() {
        let mut ir = CadIr::empty();
        let bytes = crate::test_support::test_a5a8::a5_freeform_curve_stream();
        with_admission(|admission| {
            append_freeform_surface_pools(
                &mut ir,
                &mut AnnotationBuilder::new(),
                (
                    &bytes,
                    &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                ),
                &crate::wire::records::consolidated_records(&bytes),
                &HashMap::new(),
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");

        assert!(matches!(
            ir.geometry.curves.as_slice(),
            [Curve {
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(first)),
                ..
            }, Curve {
                geometry: CurveGeometry::Solved(SolvedCurveGeometry::Nurbs(second)),
                ..
            }] if first.degree() == 5
                && second.degree() == 5
                && first.pole_rows().raw_points().first() == Some(&Point3::new(1.0, 0.0, 0.0))
                && second.pole_rows().raw_points().first() == Some(&Point3::new(0.0, 1.0, 0.0))
        ));
    }

    #[test]
    fn freeform_fallback_uses_independent_cylinder_frame_offsets() {
        let mut bytes = crate::test_support::test_b2::b2_cylinder_stream();
        bytes.extend_from_slice(&crate::test_support::test_b2::b2_wide_cylinder_stream());

        let records = crate::wire::records::consolidated_records(&bytes);
        let carriers = crate::test_support::with_service_context(|_ctx| {
            freeform_surface_carriers(
                &bytes,
                &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                &records,
                &mut crate::nurbs::LaneRefusals::new(),
            )
            .expect("service decode")
        });
        assert_eq!(carriers.len(), 2);
        assert!(carriers[0].source_tag.starts_with("b2_03_28:"));
        assert!(carriers[1].source_tag.starts_with("b2_03_28:"));
        assert_ne!(carriers[0].source_tag, carriers[1].source_tag);
    }

    #[test]
    fn endpoint_pair_binding_requires_one_unordered_match() {
        let loci = [Point3::new(1.0, 2.0, 3.0), Point3::new(4.0, 5.0, 6.0)];
        let unique = unique_endpoint_pair_match(
            loci,
            [
                (
                    7,
                    [Point3::new(4.0, 5.0, 6.001), Point3::new(1.0, 2.0, 3.001)],
                ),
                (8, [Point3::new(0.0, 0.0, 0.0), Point3::new(4.0, 5.0, 6.0)]),
            ]
            .into_iter(),
        );
        assert_eq!(unique, Some((7, true)));

        let ambiguous = unique_endpoint_pair_match(
            loci,
            [
                (7, loci),
                (
                    8,
                    [Point3::new(1.0, 2.0, 3.001), Point3::new(4.0, 5.0, 6.001)],
                ),
            ]
            .into_iter(),
        );
        assert_eq!(ambiguous, None);
    }

    #[test]
    fn paired_surface_lifts_require_one_matching_carrier() {
        let plane = |z| {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, z),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            ))
        };
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, 0.0),
                Point2::new(1.0, 0.0),
            )
            .expect("valid LinePcurve fixture"),
        );
        let resolved = plane(0.0);
        let matching = plane(0.001);
        let distant = plane(1.0);
        assert_eq!(
            crate::test_support::with_service_context(|ctx| unique_paired_surface_lift_match(
                ctx,
                &pcurve,
                &resolved,
                &pcurve,
                [0.0, 1.0],
                [(7, &matching), (8, &distant)].into_iter(),
            )),
            Ok(Some(7))
        );
        assert_eq!(
            crate::test_support::with_service_context(|ctx| unique_paired_surface_lift_match(
                ctx,
                &pcurve,
                &resolved,
                &pcurve,
                [0.0, 1.0],
                [(7, &matching), (9, &matching)].into_iter(),
            )),
            Ok(None)
        );
    }

    #[test]
    fn paired_surface_lifts_keep_a_finite_midpoint_in_a_wide_parameter_range() {
        let plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(0.0, 0.0, 0.0),
                Vector3::new(0.0, 0.0, 1.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid plane"),
        ));
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.0, 0.0),
                Point2::new(1.0, 0.0),
            )
            .expect("valid pcurve"),
        );
        assert_eq!(
            crate::test_support::with_service_context(|ctx| unique_paired_surface_lift_match(
                ctx,
                &pcurve,
                &plane,
                &pcurve,
                [-f64::MAX, f64::MAX],
                [(7, &plane)].into_iter(),
            )),
            Ok(Some(7))
        );
    }

    #[test]
    fn cone_locus_equality_accepts_only_the_same_apex_shift() {
        let cone = |origin, radius| {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
                cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                    origin,
                    Vector3::new(-1.0, 0.0, 0.0),
                    Vector3::new(0.0, 1.0, 0.0),
                    radius,
                    1.0,
                    std::f64::consts::FRAC_PI_4,
                )
                .expect("valid ConeSurface fixture"),
            ))
        };
        let apex_form = cone(Point3::new(111.0, 0.0, 0.0), 0.0);
        let shifted = cone(Point3::new(107.5, 0.0, 0.0), 3.5);
        let other = cone(Point3::new(107.0, 0.0, 0.0), 3.5);
        assert!(same_surface_locus(&apex_form, &shifted));
        assert!(!same_surface_locus(&apex_form, &other));
    }

    #[test]
    fn equivalent_cone_pcurve_moves_to_the_target_axial_origin() {
        let cone = |origin, radius| {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
                cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                    origin,
                    Vector3::new(-1.0, 0.0, 0.0),
                    Vector3::new(0.0, 1.0, 0.0),
                    radius,
                    1.0,
                    std::f64::consts::FRAC_PI_4,
                )
                .expect("valid ConeSurface fixture"),
            ))
        };
        let source = cone(Point3::new(107.5, 0.0, 0.0), 3.5);
        let target = cone(Point3::new(111.0, 0.0, 0.0), 0.0);
        let pcurve = PcurveGeometry::Line(
            cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                Point2::new(0.25, 1.5),
                Point2::new(2.0, -0.5),
            )
            .expect("valid LinePcurve fixture"),
        );
        assert_eq!(
            rechart_equivalent_surface_pcurve(&pcurve, &source, &target)
                .expect("finite pcurve rechart"),
            Some(PcurveGeometry::Line(
                cadmpeg_ir::geometry::pcurve::LinePcurve::try_new(
                    Point2::new(0.25, 5.0),
                    Point2::new(2.0, -0.5)
                )
                .expect("valid LinePcurve fixture")
            ))
        );
    }

    #[test]
    fn equivalent_cone_rechart_reports_overflow_for_finite_nurbs_poles() {
        let cone = |origin, radius| {
            SurfaceGeometry::Solved(SolvedSurfaceGeometry::Cone(
                cadmpeg_ir::geometry::analytic::ConeSurface::try_new(
                    origin,
                    Vector3::new(-1.0, 0.0, 0.0),
                    Vector3::new(0.0, 1.0, 0.0),
                    radius,
                    1.0,
                    std::f64::consts::FRAC_PI_4,
                )
                .expect("valid ConeSurface fixture"),
            ))
        };
        let shift = f64::MAX * 0.5;
        let source = cone(
            Point3::new(-shift / std::f64::consts::FRAC_PI_4.tan(), 0.0, 0.0),
            shift,
        );
        let target = cone(Point3::new(0.0, 0.0, 0.0), 0.0);
        assert!(same_surface_locus(&source, &target));
        let pcurve = PcurveGeometry::Nurbs {
            nurbs: cadmpeg_ir::geometry::pcurve::PcurveNurbs::from_lanes(
                1,
                vec![0.0, 0.0, 1.0, 1.0],
                vec![
                    Point2::new(0.0, f64::MAX * 0.75),
                    Point2::new(1.0, f64::MAX * 0.75),
                ],
                None,
                false,
            )
            .expect("finite NURBS fixture"),
        };
        assert!(matches!(
            rechart_equivalent_surface_pcurve(&pcurve, &source, &target),
            Err(RechartFailure),
        ));
    }

    #[test]
    fn consolidated_surface_curve_reuses_one_matching_unresolved_edge() {
        let mut ir = CadIr::empty();
        let points = [
            Point3::new(1.0, 4.0, 3.0),
            Point3::new(2.0, 2.0 + 2.0 * 0.5f64.cos(), 3.0 + 2.0 * 0.5f64.sin()),
        ];
        let mut bytes = crate::test_support::test_b2::b2_cylinder_stream();
        for point in points {
            bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
            for value in [point.x, point.y, point.z] {
                bytes.extend_from_slice(
                    &(cadmpeg_core::convert::f32_from_f64(value).expect("fixture value fits f32"))
                        .to_le_bytes(),
                );
            }
        }
        let mut edge_run =
            crate::test_support::test_a5_bound::a5_native_edge_run_stream(6, 139, 142);
        let second_pcurve = crate::test_support::test_a5a8::a5_pcurve_stream().len();
        for (offset, value) in [10.0f64, 11.0, 20.0, 21.0].into_iter().enumerate() {
            let start = second_pcurve + 33 + 8 * offset;
            edge_run[start..start + 8].copy_from_slice(&value.to_le_bytes());
        }
        bytes.extend_from_slice(&edge_run);
        let cylinder = crate::families::b2::records::b2_cylinders(&bytes)
            .into_iter()
            .next()
            .expect("one exact cylinder")
            .surface_geometry();

        for (index, position) in points.into_iter().enumerate() {
            ir.geometry.points.push(Point::new(
                PointId::mint(format!("catia:test:point#point%23{index}"))
                    .expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(position)
                    .expect("a finite position is a point"),
                None,
            ));
            ir.geometry.vertices.push(Vertex {
                id: VertexId::mint(format!("catia:test:vertex#vertex%23{index}"))
                    .expect("identity grammar"),
                point: PointId::mint(format!("catia:test:point#point%23{index}"))
                    .expect("identity grammar"),
                tolerance: None,
                native_ref: None,
            });
        }
        let curve_id =
            CurveId::mint("catia:test:curve#standard-curve".to_string()).expect("identity grammar");
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });
        ir.geometry.edges.push(Edge {
            id: EdgeId::mint("catia:test:edge#standard-edge".to_string())
                .expect("identity grammar"),
            carrier: cadmpeg_ir::topology::EdgeCarrier::new(
                Some(curve_id.clone()),
                Some([0.0, 1.0]),
            )
            .expect("valid edge carrier"),
            ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                VertexId::mint("catia:test:vertex#vertex%231".to_string())
                    .expect("identity grammar"),
                VertexId::mint("catia:test:vertex#vertex%230".to_string())
                    .expect("identity grammar"),
            )),
            tolerance: None,
            native_ref: None,
        });
        let support_ids = [
            SurfaceId::mint("catia:test:surface#support%230".to_string())
                .expect("identity grammar"),
            SurfaceId::mint("catia:test:surface#support%231".to_string())
                .expect("identity grammar"),
        ];
        ir.geometry.surfaces.push(Surface {
            id: support_ids[0].clone(),
            geometry: cylinder,
            source_object: None,
            native_ref: None,
        });
        ir.geometry.surfaces.push(Surface {
            id: support_ids[1].clone(),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });
        for (side, support_id) in support_ids.iter().enumerate() {
            let face_id =
                FaceId::mint(format!("catia:test:face#face%23{side}")).expect("identity grammar");
            let loop_id =
                LoopId::mint(format!("catia:test:loop#loop%23{side}")).expect("identity grammar");
            let coedge_id = CoedgeId::mint(format!("catia:test:coedge#coedge%23{side}"))
                .expect("identity grammar");
            ir.geometry.faces.push(Face {
                id: face_id.clone(),
                shell: ShellId::mint("catia:test:shell#shell".to_string())
                    .expect("identity grammar"),
                surface: support_id.clone(),
                sense: Sense::Forward,
                loops: cadmpeg_ir::topology::FaceLoops::unspecified(vec![loop_id.clone()]),
                name: None,
                color: None,
                tolerance: None,
                native_ref: None,
            });
            ir.geometry.loops.push(Loop {
                id: loop_id.clone(),
                face: face_id,
                boundary: cadmpeg_ir::topology::LoopBoundary::Ring(
                    cadmpeg_ir::topology::LoopRing::new(vec![coedge_id.clone()], Vec::new())
                        .expect("valid loop ring"),
                ),
                native_ref: None,
            });
            ir.geometry.coedges.push(Coedge {
                id: coedge_id.clone(),
                owner_loop: loop_id,
                edge: EdgeId::mint("catia:test:edge#standard-edge".to_string())
                    .expect("identity grammar"),
                radial_next: CoedgeId::mint(format!("catia:test:coedge#coedge%23{}", 1 - side))
                    .expect("identity grammar"),
                sense: if side == 0 {
                    Sense::Forward
                } else {
                    Sense::Reversed
                },
                pcurves: Vec::new(),
                use_curve: None,
                native_ref: None,
            });
        }
        let _attached = ir.geometry.add_procedural_curve(
            &curve_id,
            ProceduralCurve::new(
                ProceduralCurveId::mint(
                    "catia:test:proceduralcurve#standard-intersection".to_string(),
                )
                .expect("identity grammar"),
                ProceduralCurveDefinition::Intersection {
                    context: IntcurveSupportContext::try_new(
                        std::array::from_fn(|side| IntcurveSupportSide {
                            surface: Some(support_ids[side].clone()),
                            pcurve: None,
                        }),
                        [0.0, 1.0],
                        std::array::from_fn(|_| Vec::new()),
                    )
                    .expect("valid IntcurveSupportContext fixture"),
                    discontinuity_flag: false,
                    cache: None,
                },
            ),
        );

        let attached = with_admission(|admission| {
            append_resolved_consolidated_surface_curves(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &bytes,
                &crate::wire::records::consolidated_records(&bytes),
                FreeformSurfacePool {
                    surfaces: &[],
                    surface_ids: &[],
                    surface_alias_tags: &HashMap::new(),
                },
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");
        assert_eq!(attached.standard_edges, 1);
        assert_eq!(attached.partner_face_pcurve_pairs, 0);
        assert_eq!(ir.geometry.pcurves.len(), 0);
        assert_eq!(ir.geometry.coedges[0].pcurves.len(), 0);
        assert_eq!(ir.geometry.coedges[1].pcurves.len(), 0);
        assert_eq!(ir.geometry.curves.len(), 1);
        assert_eq!(ir.geometry.edges[0].curve(), Some(&curve_id));
        let ProceduralCurveDefinition::SurfaceCurve { family } =
            ir.geometry.procedural_curves[0].definition()
        else {
            panic!("one exact support remains a parametric surface curve");
        };
        let context = family.context();
        assert_eq!(
            context
                .sides()
                .iter()
                .filter(|side| side.pcurve.is_some())
                .count(),
            1
        );
        let start = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &context.sides()[0]
                .pcurve
                .as_ref()
                .expect("first pcurve")
                .geometry,
            context.parameter_range().endpoints()[0],
        )
        .expect("reversed pcurve start");
        assert_eq!([start.u, start.v], [0.5, 1.0]);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
    }

    #[test]
    fn consolidated_pcurve_uses_unique_standard_carrier_tag() {
        let bytes = crate::test_support::test_a5_bound::a5_native_edge_run_stream_with_support(
            6, 139, 142, 0x1234,
        );
        let mut ir = CadIr::empty();
        let surface_id = SurfaceId::mint("catia:test:surface#standard-carrier".to_string())
            .expect("identity grammar");
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: Some(
                crate::assemble::cgm_source("carrier", 0x1234)
                    .expect("build the CGM source object"),
            ),
            native_ref: None,
        });

        let counts = with_admission(|admission| {
            append_resolved_consolidated_surface_curves(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &bytes,
                &crate::wire::records::consolidated_records(&bytes),
                FreeformSurfacePool {
                    surfaces: &[],
                    surface_ids: &[],
                    surface_alias_tags: &HashMap::new(),
                },
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");

        assert_eq!(counts.standard_edges, 0);
        let [procedural] = ir.geometry.procedural_curves.as_slice() else {
            panic!("one consolidated surface curve");
        };
        let context = match procedural.definition() {
            ProceduralCurveDefinition::Intersection { context, .. } => context,
            ProceduralCurveDefinition::SurfaceCurve { family } => family.context(),
            _ => panic!("consolidated surface-curve construction"),
        };
        assert!(context
            .sides()
            .iter()
            .all(|side| { side.surface.as_ref() == Some(&surface_id) && side.pcurve.is_some() }));
        let start = cadmpeg_ir::eval::decode::pcurve_uv(
            cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
            &context.sides()[0]
                .pcurve
                .as_ref()
                .expect("standard pcurve")
                .geometry,
            0.0,
        )
        .expect("standard pcurve start");
        assert_eq!(start, Point2::new(0.0, 0.0));
    }

    #[test]
    fn consolidated_pcurve_uses_unique_canonical_surface_alias_tag() {
        let bytes = crate::test_support::test_a5_bound::a5_native_edge_run_stream_with_support(
            6, 139, 142, 0x5678,
        );
        let mut ir = CadIr::empty();
        let surface_id = SurfaceId::mint("catia:test:surface#standard-carrier".to_string())
            .expect("identity grammar");
        ir.geometry.surfaces.push(Surface {
            id: surface_id.clone(),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                    Point3::new(0.0, 0.0, 0.0),
                    Vector3::new(0.0, 0.0, 1.0),
                    Vector3::new(1.0, 0.0, 0.0),
                )
                .expect("valid PlaneSurface fixture"),
            )),
            source_object: Some(
                crate::assemble::cgm_source("carrier", 0x1234)
                    .expect("build the CGM source object"),
            ),
            native_ref: None,
        });

        let counts = with_admission(|admission| {
            append_resolved_consolidated_surface_curves(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &bytes,
                &crate::wire::records::consolidated_records(&bytes),
                FreeformSurfacePool {
                    surfaces: &[],
                    surface_ids: &[],
                    surface_alias_tags: &HashMap::from([(0x5678, Some(0x1234))]),
                },
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");

        assert_eq!(counts.standard_edges, 0);
        let [procedural] = ir.geometry.procedural_curves.as_slice() else {
            panic!("one consolidated surface curve");
        };
        let context = match procedural.definition() {
            ProceduralCurveDefinition::Intersection { context, .. } => context,
            ProceduralCurveDefinition::SurfaceCurve { family } => family.context(),
            _ => panic!("consolidated surface-curve construction"),
        };
        assert!(context
            .sides()
            .iter()
            .all(|side| { side.surface.as_ref() == Some(&surface_id) && side.pcurve.is_some() }));
    }

    #[test]
    fn standard_carrier_index_rejects_duplicate_or_unknown_geometry() {
        let mut ir = CadIr::empty();
        for (id, geometry) in [
            (
                "known-0",
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
            ),
            (
                "known-1",
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
                    cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                        Point3::new(0.0, 0.0, 0.0),
                        Vector3::new(0.0, 0.0, 1.0),
                        Vector3::new(1.0, 0.0, 0.0),
                    )
                    .expect("valid PlaneSurface fixture"),
                )),
            ),
            (
                "unknown",
                SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            ),
        ] {
            ir.geometry.surfaces.push(Surface {
                id: SurfaceId::mint(format!("catia:test:surface#{id}")).expect("identity grammar"),
                geometry,
                source_object: Some(
                    crate::assemble::cgm_source("carrier", 0x1234)
                        .expect("build the CGM source object"),
                ),
                native_ref: None,
            });
        }

        assert_eq!(standard_carrier_surface_ids(&ir).get(&0x1234), Some(&None));
    }

    #[test]
    fn consolidated_plane_support_transfers_both_surface_curve_sides() {
        let plane_stream = crate::test_support::test_b2::b2_plane_carrier_stream();
        let plane_end = crate::families::b2::records::b2_plane_carriers(&plane_stream)[0].end;
        let mut bytes = plane_stream[..plane_end].to_vec();
        let points = [Point3::new(10.0, 20.0, 0.0), Point3::new(11.0, 20.0, 1.0)];
        for point in points {
            bytes.extend_from_slice(&[0x05, 0x08, 0x01]);
            for value in [point.x, point.y, point.z] {
                bytes.extend_from_slice(
                    &(cadmpeg_core::convert::f32_from_f64(value).expect("fixture value fits f32"))
                        .to_le_bytes(),
                );
            }
        }
        bytes.extend_from_slice(
            &crate::test_support::test_a5_bound::a5_native_edge_run_stream(6, 139, 142),
        );

        let mut ir = CadIr::empty();
        for (index, position) in points.into_iter().enumerate() {
            ir.geometry.points.push(Point::new(
                PointId::mint(format!("catia:test:point#point%23{index}"))
                    .expect("identity grammar"),
                cadmpeg_ir::features::FinitePoint3::new(position)
                    .expect("a finite position is a point"),
                None,
            ));
            ir.geometry.vertices.push(Vertex {
                id: VertexId::mint(format!("catia:test:vertex#vertex%23{index}"))
                    .expect("identity grammar"),
                point: PointId::mint(format!("catia:test:point#point%23{index}"))
                    .expect("identity grammar"),
                tolerance: None,
                native_ref: None,
            });
        }
        let curve_id = CurveId::mint("catia:test:curve#standard-plane-curve".to_string())
            .expect("identity grammar");
        ir.geometry.curves.push(Curve {
            parameter_range: None,
            id: curve_id.clone(),
            geometry: CurveGeometry::Solved(SolvedCurveGeometry::Unknown { record: None }),
            source_object: None,
            native_ref: None,
        });
        ir.geometry.edges.push(Edge {
            id: EdgeId::mint("catia:test:edge#standard-plane-edge".to_string())
                .expect("identity grammar"),
            carrier: cadmpeg_ir::topology::EdgeCarrier::unbounded(Some(curve_id.clone())),
            ends: Some(cadmpeg_ir::topology::EdgeEnds::new(
                VertexId::mint("catia:test:vertex#vertex%230".to_string())
                    .expect("identity grammar"),
                VertexId::mint("catia:test:vertex#vertex%231".to_string())
                    .expect("identity grammar"),
            )),
            tolerance: None,
            native_ref: None,
        });
        let plane = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(
                Point3::new(10.0, 20.0, 0.0),
                Vector3::new(0.0, -1.0, 0.0),
                Vector3::new(1.0, 0.0, 0.0),
            )
            .expect("valid PlaneSurface fixture"),
        ));
        let support_ids = [
            SurfaceId::mint("catia:test:surface#standard-plane%230".to_string())
                .expect("identity grammar"),
            SurfaceId::mint("catia:test:surface#standard-plane%231".to_string())
                .expect("identity grammar"),
        ];
        for support_id in &support_ids {
            ir.geometry.surfaces.push(Surface {
                id: support_id.clone(),
                geometry: plane.clone(),
                source_object: None,
                native_ref: None,
            });
        }
        let _attached = ir.geometry.add_procedural_curve(
            &curve_id,
            ProceduralCurve::new(
                ProceduralCurveId::mint(
                    "catia:test:proceduralcurve#standard-plane-intersection".to_string(),
                )
                .expect("identity grammar"),
                ProceduralCurveDefinition::Intersection {
                    context: IntcurveSupportContext::try_new(
                        std::array::from_fn(|side| IntcurveSupportSide {
                            surface: Some(support_ids[side].clone()),
                            pcurve: None,
                        }),
                        [0.0, 1.0],
                        std::array::from_fn(|_| Vec::new()),
                    )
                    .expect("valid IntcurveSupportContext fixture"),
                    discontinuity_flag: false,
                    cache: None,
                },
            ),
        );

        let attached = with_admission(|admission| {
            append_resolved_consolidated_surface_curves(
                &mut ir,
                &mut AnnotationBuilder::new(),
                &bytes,
                &crate::wire::records::consolidated_records(&bytes),
                FreeformSurfacePool {
                    surfaces: &[],
                    surface_ids: &[],
                    surface_alias_tags: &HashMap::new(),
                },
                &mut crate::nurbs::LaneRefusals::new(),
                admission,
            )
        })
        .expect("valid source object identity");
        assert_eq!(attached.standard_edges, 1);
        assert_eq!(
            ir.geometry.edges[0]
                .param_range()
                .map(cadmpeg_ir::units::FiniteVector::get),
            Some([0.0, 1.0])
        );
        let ProceduralCurveDefinition::Intersection { context, .. } =
            ir.geometry.procedural_curves[0].definition()
        else {
            panic!("plane support keeps an intersection construction");
        };
        assert!(context.sides().iter().all(|side| {
            side.surface
                .as_ref()
                .is_some_and(|id| id.as_str().starts_with("catia:consolidated:plane#"))
                && side.pcurve.is_some()
        }));
    }

    /// A plane whose chart origin and axes differ from the stored chart used by
    /// a consolidated side, together with definition sites on it. The stored
    /// chart is the target chart turned by `angle` about the site origin and
    /// shifted by `shift`, which is what a foreign carrier's chart looks like.
    fn foreign_plane_chart_sites(
        angle: f64,
        shift: [f64; 2],
    ) -> (SurfaceGeometry, Vec<[f64; 2]>, Vec<Point3>) {
        let origin = Point3::new(7.0, -2.0, 11.0);
        let u_axis = Vector3::new(0.0, 1.0, 0.0);
        let normal = Vector3::new(1.0, 0.0, 0.0);
        let target = SolvedSurfaceGeometry::Plane(
            cadmpeg_ir::geometry::analytic::PlaneSurface::try_new(origin, normal, u_axis)
                .expect("valid PlaneSurface fixture"),
        );
        // Sites in the target chart, deliberately not collinear so the
        // isometry between the charts is uniquely determined.
        let target_sites = [[0.0, 0.0], [3.0, 1.0], [5.0, -2.0], [8.0, 4.0]];
        let loci = target_sites
            .iter()
            .map(|[u, v]| {
                cadmpeg_ir::eval::decode::surface_point_solved(
                    cadmpeg_ir::eval::admission::EvaluationAdmission::Standard,
                    &target,
                    *u,
                    *v,
                )
                .expect("plane evaluates")
                .get()
            })
            .collect::<Vec<_>>();
        let (cosine, sine) = (angle.cos(), angle.sin());
        let stored = target_sites
            .iter()
            .map(|[u, v]| {
                [
                    cosine * u - sine * v + shift[0],
                    sine * u + cosine * v + shift[1],
                ]
            })
            .collect::<Vec<_>>();
        (SurfaceGeometry::Solved(target), stored, loci)
    }

    mod rechart_cases;

    #[test]
    fn identity_chart_jet_pcurve_lowers_to_a_pcurve() {
        use crate::wire::records::{ConsolidatedPcurve, ConsolidatedPcurveSite};
        let site = |knot, u| ConsolidatedPcurveSite {
            knot: cadmpeg_ir::scalar::FiniteReal::new(knot).expect("finite knot"),
            point: cadmpeg_ir::units::FiniteVector::new([u, 0.0]).expect("finite point"),
            first_derivatives: cadmpeg_ir::units::FiniteVector::new([1.0, 0.0])
                .expect("finite first jet"),
            second_derivatives: cadmpeg_ir::units::FiniteVector::new([0.0, 0.0])
                .expect("finite second jet"),
        };
        let pcurve = ConsolidatedPcurve {
            pos: 16,
            support_id: 1,
            extrapolation_sites: 0,
            sites: vec![site(0.0, 0.0), site(1.0, 1.0)]
                .try_into()
                .expect("ordered fixture sites"),
            range: cadmpeg_ir::topology::IncreasingParameterInterval::new([0.0, 1.0])
                .expect("increasing range"),
            tail: Vec::new(),
        };
        assert!(super::consolidated_jet_pcurve(
            &pcurve,
            &ConsolidatedCarrierChart::Identity,
            &mut crate::nurbs::LaneRefusals::new(),
        )
        .is_some());
    }

    #[test]
    fn b2_line_profile_stream_yields_one_line_profile() {
        let bytes = crate::test_support::test_b2::b2_line_profile_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let service = consolidated_line_profiles(&bytes, &records)
            .expect("compute the consolidated line profiles");
        assert_eq!(service.len(), 1);
    }

    #[test]
    fn a5_surface_pool_appends_one_surface() {
        let bytes = crate::test_support::test_a5a8::a5_surface_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let run = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
            let mut ir = CadIr::empty();
            let mut annotations = AnnotationBuilder::new();
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            append_freeform_surface_pools(
                &mut ir,
                &mut annotations,
                (
                    &bytes,
                    &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                ),
                &records,
                &HashMap::new(),
                &mut crate::nurbs::LaneRefusals::new(),
                &mut admission,
            )
            .map(|_| ir.geometry.surfaces.len())
        };
        assert_eq!(
            crate::test_support::with_service_context(run).expect("append freeform surface pools"),
            1
        );
    }

    #[test]
    fn a5_guide_curve_pool_appends_one_curve() {
        let bytes = crate::test_support::test_a5a8::a5_guide_curve_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let run = |ctx: &cadmpeg_core::decode::DecodeContext<'_>| {
            let mut ir = CadIr::empty();
            let mut annotations = AnnotationBuilder::new();
            let mut admission = super::FamilyEntityAdmission::new(ctx);
            append_freeform_surface_pools(
                &mut ir,
                &mut annotations,
                (
                    &bytes,
                    &[vec![crate::wire::records::SourceExtent::whole(&bytes)]],
                ),
                &records,
                &HashMap::new(),
                &mut crate::nurbs::LaneRefusals::new(),
                &mut admission,
            )
            .map(|_| ir.geometry.curves.len())
        };
        assert_eq!(
            crate::test_support::with_service_context(run).expect("append freeform surface pools"),
            1
        );
    }

    #[test]
    fn rechart_between_identical_surfaces_copies_the_pcurve() {
        let surface = SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None });
        let pcurve = PcurveGeometry::Nurbs {
            nurbs: cadmpeg_ir::geometry::pcurve::PcurveNurbs::from_lanes(
                1,
                vec![0.0, 0.0, 1.0, 1.0],
                vec![Point2::new(0.0, 0.0), Point2::new(1.0, 1.0)],
                None,
                false,
            )
            .expect("valid pcurve fixture"),
        };
        let copied = rechart_equivalent_surface_pcurve(&pcurve, &surface, &surface)
            .expect("compute the rechart equivalent surface pcurve");
        assert_eq!(copied, Some(pcurve));
    }

    #[test]
    fn carrier_index_lists_an_unknown_geometry_tag_without_a_surface_id() {
        let mut ir = CadIr::empty();
        ir.geometry.surfaces.push(Surface {
            id: SurfaceId::mint("catia:test:surface#tagged".to_owned()).expect("identity grammar"),
            geometry: SurfaceGeometry::Solved(SolvedSurfaceGeometry::Unknown { record: None }),
            source_object: Some(
                crate::assemble::cgm_source("carrier", 0x1234)
                    .expect("build the CGM source object"),
            ),
            native_ref: None,
        });
        let indexed = standard_carrier_surface_ids(&ir);
        assert_eq!(indexed.get(&0x1234), Some(&None));
    }

    #[test]
    fn b2_revolution_stream_resolves_one_revolution() {
        let bytes = crate::test_support::test_b2::b2_resolved_revolution_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let resolved =
            crate::families::b2::records::b2_resolved_revolutions_from_records(&bytes, &records);
        assert_eq!(resolved.len(), 1);
    }

    #[test]
    fn line_profile_curve_gets_the_consolidated_line_profile_id() {
        let bytes = crate::test_support::test_b2::b2_line_profile_stream();
        let records = crate::wire::records::consolidated_records(&bytes);
        let service = consolidated_line_profiles(&bytes, &records)
            .expect("compute the consolidated line profiles");
        assert_eq!(service.len(), 1);
        assert_eq!(
            service[0].curve.id.as_str(),
            "catia:consolidated:line-profile-curve#0"
        );
    }
}
